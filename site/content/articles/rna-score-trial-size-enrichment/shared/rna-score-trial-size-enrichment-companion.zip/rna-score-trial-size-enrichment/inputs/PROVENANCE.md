# Inputs and provenance (X26-20)

All model inputs of the analysis are four published percentages and one count. No patient-level data and no model weights were obtained or used.

## Quoted anchors (Ladon technical report, text read on 2026-11-14)
Source: Blank Bio. "Ladon: An RNA Foundation Model for Predicting Patient Outcomes" [Internet]. https://www.blank.bio/ladon-technical-report (page text 104,801 characters; the first 100,000 characters were read through a fetch tool that returns summaries of requested items, the last 4,801 characters were read for the reference list and citation block only). Authors listed: Byeon GW, Fradkin P, Hsu J, Nguyen V, Shi I, Tu W, Zhang M. Year 2026.

What the report text says about the treatment-benefit analysis in POPLAR (items retrieved as quotations by the fetch tool; the original figure panel was NOT viewed):
- "estimate[s] how the difference in 12-month PFS between treatment and control varies with a tumor's molecular features"; "The encoder is not fine-tuned."
- Training: "We fit this model on five trials and applied it to POPLAR"; the Methods list IMmotion150, IMmotion151, IMbrave150, OAK, IMpower133. OAK is therefore part of the training set of this benefit head.
- Prognostic adjustment first: "we first use a Ladon-derived score to regress out prognostic signal in both arms"; cross-fitting with censoring-weighted logistic regression; "one whole-cohort median shared between arms".
- Result text: atezolizumab: "28% of patients with high Ladon scores were progression-free at 12 months, against 6%" of those with low scores; docetaxel: "the two groups fared alike (14% and 13%)"; "patients at risk, not responders".
- Counts: "The plot includes 87 of 95 atezolizumab-treated patients with evaluable response"; the POPLAR RNA-profiled subset is n = 192 (Methods: IMmotion150 n = 177, IMmotion151 n = 823, OAK n = 699, POPLAR n = 192); "all 192 molecularly profiled patients" define the median threshold.
- Response evaluation (not used as input): the report evaluates immunotherapy response with AUROC per trial (six trials, equal-weight mean) and states a classifier context excluding the evaluated trial; no value from it is used here.
- DOI of the report as listed on the page: 10.5281/zenodo.24157116 (checked to resolve to Zenodo during review).
- NOT reported in the text read: the number of patients in each of the four score-by-arm groups, confidence intervals, hazard ratios, p-values, any power or sample-size calculation. The report states a goal of "smaller, more efficient trials" without a calculation.

Consequence: the four percentages are used as scenario anchors only. Cell sizes are an assumption of this analysis (192 / 4 = 48 per cell, varied 24-96). The percentages are rounded figures as printed.

## Other facts used as stated by their sources (abstract level)
- POPLAR: 144 patients randomised to atezolizumab, 143 to docetaxel; Fehrenbacher et al., Lancet 2016, doi:10.1016/S0140-6736(16)00587-0 (abstract read via Europe PMC).
- Brookes et al. 2004: a trial with 80% power for the overall effect had 29% power for an interaction of the same magnitude; fourfold sample size needed (abstract read).
- Schuler et al. 2022: sample size reductions of 10-30% attainable for continuous outcomes with prognostic models that explain a clinically realistic percentage of outcome variance (abstract read).
- EMA PROCOVA qualification opinion (adopted 15 Sep 2022): continuous outcomes, linear (ANCOVA) adjustment, prognostic score trained on independent historical control data (PDF text read locally with pdftotext).
- FDA guidance "Adjusting for Covariates in Randomized Clinical Trials for Drugs and Biological Products" (May 2023, final): only the web page summary was read; the guidance PDF was not read.

## Not available / not done
- No Ladon weights, patient-level scores, EGA data (access-controlled), or POPLAR/OAK individual data were used. No re-evaluation of Ladon is claimed.
