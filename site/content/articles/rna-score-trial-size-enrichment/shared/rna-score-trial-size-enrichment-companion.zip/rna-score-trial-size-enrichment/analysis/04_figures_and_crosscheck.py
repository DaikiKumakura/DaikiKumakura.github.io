"""Step 4: an independent library cross-check of the main sample sizes, and the three article figures.
Run after steps 1-3: python -X utf8 analysis/04_figures_and_crosscheck.py
"""
import json
import sys

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from statsmodels.stats.proportion import power_proportions_2indep

from common import ANCHOR, FIGS, TABLES, design_adjusted, design_enriched, design_unadjusted

sys.stdout.reconfigure(encoding="utf-8")
FIGS.mkdir(parents=True, exist_ok=True)
OI = {"blue": "#0072B2", "orange": "#E69F00", "green": "#009E73", "verm": "#D55E00", "sky": "#56B4E9", "grey": "#666666"}
plt.rcParams.update({"font.size": 9, "axes.spines.top": False, "axes.spines.right": False, "figure.dpi": 160})

# ------------------------------------------------------------------ cross-check with statsmodels (power at the analytic n)
d1, d4 = design_unadjusted(ANCHOR), design_enriched(ANCHOR)
p1_all = 0.5 * ANCHOR["H1"] + 0.5 * ANCHOR["L1"]
p0_all = 0.5 * ANCHOR["H0"] + 0.5 * ANCHOR["L0"]
rows = []
for name, diff, p0, n_arm in (("D1 all-comers", p1_all - p0_all, p0_all, d1["n_arm"]),
                              ("D4 enriched", ANCHOR["H1"] - ANCHOR["H0"], ANCHOR["H0"], d4["n_arm"])):
    pw = float(power_proportions_2indep(diff, p0, n_arm, ratio=1, alpha=0.05, alternative="two-sided", return_results=True).power)
    rows.append({"design": name, "n_arm_formula": n_arm, "power_statsmodels_pooled_null_variance": pw})
xc = pd.DataFrame(rows)
xc.to_csv(TABLES / "04_crosscheck_statsmodels.csv", index=False, float_format="%.5f")
print("== statsmodels power at the analytic n per arm (target 0.80)")
print(xc.round(4).to_string(index=False))
assert xc.power_statsmodels_pooled_null_variance.between(0.78, 0.82).all()

# ------------------------------------------------------------------ Figure 1: designs and their uncertainty
point = pd.read_csv(TABLES / "01_point_designs.csv")
draws = np.load(TABLES.parent / "01_posterior_draws_n48.npz")
unc = pd.read_csv(TABLES / "01_anchor_uncertainty.csv").set_index("cell_n_assumed").loc[48]  # full 200,000 draws
fig, ax = plt.subplots(1, 2, figsize=(10.2, 4.1), gridspec_kw={"width_ratios": [1.15, 1]})
labels = ["D1\nall-comers\nunadjusted", "D2\nall-comers\nscore-adjusted", "D3\nall-comers\ninteraction test", "D4\nenriched\n(high score)"]
x = np.arange(4)
ax[0].bar(x - 0.19, point["randomised"], 0.36, color=OI["blue"], label="randomised")
ax[0].bar(x + 0.19, point["screened"], 0.36, color=OI["orange"], label="screened for the score")
for i, (r, s) in enumerate(zip(point["randomised"], point["screened"])):
    ax[0].text(i - 0.19, r * 1.05, f"{r:,.0f}", ha="center", fontsize=8)
    ax[0].text(i + 0.19, s * 1.05, f"{s:,.0f}", ha="center", fontsize=8)
ax[0].set_yscale("log")
ax[0].set_ylim(100, 9000)
ax[0].set_xticks(x, labels)
ax[0].set_ylabel("patients (80% power, two-sided alpha 0.05)")
ax[0].set_title("a  Required patients at the quoted anchors", loc="left", fontsize=9.5)
ax[0].legend(frameon=False, loc="upper right")
bins = np.logspace(1.5, 4.5, 60)
for key, col, lab in (("n_high", OI["verm"], "D4 enriched"), ("n_all", OI["blue"], "D1 all-comers")):
    arr = draws[key]
    d = draws["d_high"] if key == "n_high" else draws["d_all"]
    ok = d > 0
    med = unc["n_high_randomised_q50"] if key == "n_high" else unc["n_all_randomised_q50"]
    never = unc["p_delta_high_le_0"] if key == "n_high" else unc["p_delta_all_le_0"]
    ax[1].hist(arr[ok], bins=bins, histtype="stepfilled", alpha=0.45, color=col,
               label=f"{lab}: median {med:,.0f}; never powered {100 * never:.0f}%")
ax[1].set_xscale("log")
ax[1].set_xlabel("randomised patients needed (draws from the anchors)")
ax[1].set_ylabel("count (first 20,000 of 200,000 draws)")
ax[1].set_title("b  Sampling uncertainty (48 per cell assumed)", loc="left", fontsize=9.5)
ax[1].legend(frameon=False, loc="upper right", fontsize=7)
fig.tight_layout()
fig.savefig(FIGS / "fig1_designs_and_uncertainty.png")
plt.close(fig)

# ------------------------------------------------------------------ Figure 2: what a prognostic score can save
sweep = pd.read_csv(TABLES / "02_prognostic_sweep.csv")
res1 = json.loads((TABLES / "01_results.json").read_text(encoding="utf-8"))
fig, ax = plt.subplots(figsize=(5.8, 4.0))
ax.plot(sweep["auc_within_arm_ctrl"], 100 * (1 - sweep["n_ratio_rd_adj_over_unadj"]), "-o", color=OI["blue"], ms=4,
        label="purely prognostic score (same logit shift in both arms)")
mean_auc = 0.5 * (res1["auc_atezolizumab_arm"] + res1["auc_docetaxel_arm"])
ax.plot([mean_auc], [res1["adjustment_saving_pct"]], "s", color=OI["verm"], ms=7,
        label="quoted anchors: AUC 0.69 in one arm, 0.51 in the other")
ax.axhspan(10, 30, color=OI["sky"], alpha=0.18, lw=0)
ax.text(0.505, 28.2, "10-30% reduction range quoted for continuous\noutcomes (Schuler et al., abstract)", fontsize=7.2, va="top")
ax.set_xlabel("AUC of the score for PFS12 within an arm (mean of the two arms for the anchors)")
ax.set_ylabel("reduction in randomised patients (%)\nrisk-difference estimand, standardised estimator")
ax.set_xlim(0.49, 0.95)
ax.set_ylim(-1, 50)
ax.legend(frameon=False, fontsize=7.8, loc="upper left", bbox_to_anchor=(0.0, 0.8))
ax.set_title("Reduction from prognostic adjustment (PFS12, control 14%, 10-point gain)", fontsize=9, loc="left")
fig.tight_layout()
fig.savefig(FIGS / "fig2_prognostic_adjustment.png")
plt.close(fig)

# ------------------------------------------------------------------ Figure 3: sensitivity of the enriched design
B = pd.read_csv(TABLES / "03_partB_enrichment_sensitivity.csv")
fig, ax = plt.subplots(1, 3, figsize=(10.4, 3.6), sharey=True)
all_n = float(B["all_comers_randomised"].iloc[0])
panels = [("purity of positive call rho", "a  PPV of the positive call", "PPV rho (share truly high-benefit)"),
          ("shrinkage of effect in high group (x of 14 pp)", "b  Effect in the high group shrinks", "effect as a fraction of 14 points"),
          ("assay failure (no valid score)", "c  Assay failure", "share without a valid score")]
for a, (axis, title, xl) in zip(ax, panels):
    s = B[B.axis == axis]
    a.plot(s["value"], s["randomised"], "-o", ms=4, color=OI["blue"], label="enriched: randomised")
    a.plot(s["value"], s["screened"], "-s", ms=4, color=OI["orange"], label="enriched: screened")
    a.axhline(all_n, color=OI["grey"], ls="--", lw=1, label="all-comers (anchors): randomised")
    a.set_yscale("log")
    a.set_title(title, loc="left", fontsize=9)
    a.set_xlabel(xl, fontsize=8)
ax[0].set_ylabel("patients (80% power)")
ax[0].invert_xaxis()
ax[1].invert_xaxis()
ax[0].legend(frameon=False, fontsize=7.2, loc="upper left")
fig.tight_layout()
fig.savefig(FIGS / "fig3_enrichment_sensitivity.png")
plt.close(fig)
print("figures written:", sorted(p.name for p in FIGS.iterdir()))
