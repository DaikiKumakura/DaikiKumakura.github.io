"""Shared definitions for the trial-size analysis (X26-20).

Endpoint: 12-month progression-free survival (PFS12), a binary status when every patient is followed for 12 months.
Estimand (main): marginal risk difference in PFS12, experimental minus control, in the analysed population.
Score: a binary "high / low" call with a fixed threshold (the report's whole-cohort median).
"""
from __future__ import annotations

from pathlib import Path

import numpy as np
from scipy.stats import norm

ROOT = Path(__file__).resolve().parents[1]
TABLES = ROOT / "outputs" / "tables"
FIGS = ROOT / "outputs" / "figures"
LOGS = ROOT / "outputs" / "logs"

ALPHA = 0.05
POWER = 0.80
Z_A = float(norm.ppf(1 - ALPHA / 2))
Z_B = float(norm.ppf(POWER))
Z_SUM2 = (Z_A + Z_B) ** 2

# Quoted anchors: PFS12 by score half and arm (Ladon technical report, POPLAR benefit analysis).
ANCHOR = {"H1": 0.28, "L1": 0.06, "H0": 0.14, "L0": 0.13}  # H/L = high/low score; 1 = atezolizumab, 0 = docetaxel
CELL_N = 48  # assumed patients per cell (192 profiled / 4); not reported
PREV = 0.5  # share of "high" in the shared-median split


def v(p: float) -> float:
    return p * (1.0 - p)


def design_unadjusted(c: dict, prev: float = PREV) -> dict:
    """All-comers, unadjusted risk difference. Returns delta, per-arm variance sum and n per arm."""
    p1 = prev * c["H1"] + (1 - prev) * c["L1"]
    p0 = prev * c["H0"] + (1 - prev) * c["L0"]
    delta = p1 - p0
    vs = v(p1) + v(p0)
    return {"delta": delta, "vsum": vs, "n_arm": Z_SUM2 * vs / delta**2 if delta != 0 else np.inf}


def design_adjusted(c: dict, prev: float = PREV) -> dict:
    """All-comers, standardised estimator adjusted for the binary score (post-stratification).
    n * Var = 2 E[p1(1-p1)] + 2 E[p0(1-p0)] + Var_S(p1 - p0) for 1:1 randomisation.
    Per arm: V = E[p1(1-p1)] + E[p0(1-p0)] + Var_S(p1-p0)/2.
    """
    e1 = prev * v(c["H1"]) + (1 - prev) * v(c["L1"])
    e0 = prev * v(c["H0"]) + (1 - prev) * v(c["L0"])
    dH, dL = c["H1"] - c["H0"], c["L1"] - c["L0"]
    delta = prev * dH + (1 - prev) * dL
    var_delta = prev * (dH - delta) ** 2 + (1 - prev) * (dL - delta) ** 2
    vs = e1 + e0 + var_delta / 2.0
    return {"delta": delta, "vsum": vs, "n_arm": Z_SUM2 * vs / delta**2 if delta != 0 else np.inf}


def design_enriched(c: dict, prev: float = PREV, miss: float = 0.0) -> dict:
    """High-score-only trial, unadjusted. screened = randomised / (prev * (1 - miss))."""
    delta = c["H1"] - c["H0"]
    vs = v(c["H1"]) + v(c["H0"])
    n_arm = Z_SUM2 * vs / delta**2 if delta != 0 else np.inf
    return {"delta": delta, "vsum": vs, "n_arm": n_arm, "screened": 2 * n_arm / (prev * (1 - miss))}


def interaction_total_n(c: dict) -> dict:
    """Total patients (all cells equal, N/4 each) for a 2x2 interaction contrast psi = d_H - d_L."""
    psi = (c["H1"] - c["H0"]) - (c["L1"] - c["L0"])
    s = sum(v(c[k]) for k in ("H1", "L1", "H0", "L0"))
    return {"psi": psi, "n_total": 4 * Z_SUM2 * s / psi**2 if psi != 0 else np.inf}


def auc_binary_split(p_high: float, p_low: float, prev: float = PREV) -> float:
    """AUC of a binary score for an event, event probabilities p_high / p_low in the two score groups."""
    pe = prev * p_high + (1 - prev) * p_low
    tpr = prev * p_high / pe
    fpr = prev * (1 - p_high) / (1 - pe)
    return 0.5 * (1 + tpr - fpr)
