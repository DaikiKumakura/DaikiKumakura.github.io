"""Step 1: required patients for four designs at the quoted anchors, and how uncertain those numbers are.

Designs (binary PFS12, two-sided alpha 0.05, power 0.80, 1:1 randomisation, normal approximation):
  D1 all-comers, unadjusted risk difference
  D2 all-comers, risk difference standardised over the binary score
  D3 all-comers, test of the score-by-treatment interaction (needs N/4 per cell)
  D4 enriched (high-score only), unadjusted
Uncertainty: independent Beta posteriors for the four cells (cell n assumed, see common.CELL_N).
Run: python -X utf8 analysis/01_anchor_designs.py
"""
import json
import sys

import numpy as np
import pandas as pd

from common import ANCHOR, CELL_N, PREV, TABLES, Z_A, Z_SUM2, auc_binary_split
from common import design_adjusted, design_enriched, design_unadjusted, interaction_total_n

sys.stdout.reconfigure(encoding="utf-8")
SEED = 20261114
DRAWS = 200_000
TABLES.mkdir(parents=True, exist_ok=True)

# ---------------------------------------------------------------- point estimates at the anchors
d1, d2, d4 = design_unadjusted(ANCHOR), design_adjusted(ANCHOR), design_enriched(ANCHOR)
d3 = interaction_total_n(ANCHOR)
rows = [
    ("D1 all-comers unadjusted", d1["delta"], 2 * d1["n_arm"], 2 * d1["n_arm"]),
    ("D2 all-comers adjusted for score", d2["delta"], 2 * d2["n_arm"], 2 * d2["n_arm"]),
    ("D3 all-comers, interaction test", d3["psi"], d3["n_total"], d3["n_total"]),
    ("D4 enriched (high score) unadjusted", d4["delta"], 2 * d4["n_arm"], d4["screened"]),
]
point = pd.DataFrame(rows, columns=["design", "effect_pp_scale", "randomised", "screened"])
point["effect_pp_scale"] *= 100
point["randomised_ceil"] = np.ceil(point["randomised"]).astype(int)
point["screened_ceil"] = np.ceil(point["screened"]).astype(int)
point.to_csv(TABLES / "01_point_designs.csv", index=False, float_format="%.4f")
print("== point estimates at the anchors (effect = pp of PFS12; D3 effect = interaction contrast)")
print(point.round(2).to_string(index=False))

# ---------------------------------------------------------------- pieces that explain the table
res = {
    "anchor": ANCHOR,
    "delta_all_pp": 100 * d1["delta"],
    "delta_high_pp": 100 * (ANCHOR["H1"] - ANCHOR["H0"]),
    "delta_low_pp": 100 * (ANCHOR["L1"] - ANCHOR["L0"]),
    "interaction_pp": 100 * d3["psi"],
    "n_ratio_D1_over_D2": d1["n_arm"] / d2["n_arm"],
    "adjustment_saving_pct": 100 * (1 - d2["n_arm"] / d1["n_arm"]),
    "randomised_ratio_D1_over_D4": d1["n_arm"] / d4["n_arm"],
    "screened_ratio_D1_over_D4": 2 * d1["n_arm"] / d4["screened"],
    "interaction_over_overall_n_ratio": d3["n_total"] / (2 * d1["n_arm"]),
    "auc_atezolizumab_arm": auc_binary_split(ANCHOR["H1"], ANCHOR["L1"]),
    "auc_docetaxel_arm": auc_binary_split(ANCHOR["H0"], ANCHOR["L0"]),
}
# Maitournam-Simon style ratio with equal variances: n_untargeted / n_targeted = (delta_T / delta_u)^2
res["maitournam_simon_equal_variance_ratio"] = (res["delta_high_pp"] / res["delta_all_pp"]) ** 2
print("\n== derived quantities")
for k, val in res.items():
    if k != "anchor":
        print(f"  {k}: {val:.4f}")

# ---------------------------------------------------------------- sampling uncertainty of the anchors
rng = np.random.default_rng(SEED)


def draw_cells(n_cell: float, draws: int) -> dict:
    out = {}
    for k, p in ANCHOR.items():
        a = p * n_cell + 1.0  # Beta(events + 1, non-events + 1): flat prior; counts are non-integer on purpose
        b = (1 - p) * n_cell + 1.0
        out[k] = rng.beta(a, b, size=draws)
    return out


def required(c: dict) -> dict:
    p1 = PREV * c["H1"] + (1 - PREV) * c["L1"]
    p0 = PREV * c["H0"] + (1 - PREV) * c["L0"]
    d_all = p1 - p0
    d_high = c["H1"] - c["H0"]
    with np.errstate(divide="ignore", invalid="ignore"):
        n_all = 2 * Z_SUM2 * (p1 * (1 - p1) + p0 * (1 - p0)) / d_all**2
        n_high = 2 * Z_SUM2 * (c["H1"] * (1 - c["H1"]) + c["H0"] * (1 - c["H0"])) / d_high**2
    return {"d_all": d_all, "d_high": d_high, "psi": d_high - (c["L1"] - c["L0"]), "n_all": n_all, "n_high": n_high}


def qn(n, d, q):
    """Quantile of the required randomised n; draws with a non-positive effect count as infinite (never powered)."""
    arr = np.where(d > 0, n, np.inf)
    return float(np.quantile(arr, q, method="nearest"))


unc_rows = []
for n_cell in (24, 36, CELL_N, 72, 96):
    c = draw_cells(n_cell, DRAWS)
    r = required(c)
    scr = r["n_high"] / PREV
    row = {
        "cell_n_assumed": n_cell,
        "psi_pp_median": 100 * np.median(r["psi"]),
        "psi_pp_q05": 100 * np.quantile(r["psi"], 0.05),
        "psi_pp_q95": 100 * np.quantile(r["psi"], 0.95),
        "p_psi_le_0": float(np.mean(r["psi"] <= 0)),
        "delta_high_pp_q05": 100 * np.quantile(r["d_high"], 0.05),
        "delta_high_pp_q95": 100 * np.quantile(r["d_high"], 0.95),
        "p_delta_high_le_0": float(np.mean(r["d_high"] <= 0)),
        "p_delta_all_le_0": float(np.mean(r["d_all"] <= 0)),
        "n_high_randomised_q05": qn(r["n_high"], r["d_high"], 0.05),
        "n_high_randomised_q50": qn(r["n_high"], r["d_high"], 0.50),
        "n_high_randomised_q75": qn(r["n_high"], r["d_high"], 0.75),
        "n_high_randomised_q90": qn(r["n_high"], r["d_high"], 0.90),
        "n_high_randomised_q95": qn(r["n_high"], r["d_high"], 0.95),
        "n_all_randomised_q05": qn(r["n_all"], r["d_all"], 0.05),
        "n_all_randomised_q50": qn(r["n_all"], r["d_all"], 0.50),
        "n_all_randomised_q75": qn(r["n_all"], r["d_all"], 0.75),
        "n_all_randomised_q95": qn(r["n_all"], r["d_all"], 0.95),
        "p_enrich_needs_more_than_300": float(np.mean(~(r["n_high"] <= 300) | (r["d_high"] <= 0))),
    }
    unc_rows.append(row)
    if n_cell == CELL_N:
        base = r
unc = pd.DataFrame(unc_rows)
unc.to_csv(TABLES / "01_anchor_uncertainty.csv", index=False, float_format="%.4f")
print("\n== uncertainty of the anchors (Beta posteriors, flat prior; seeds fixed)")
print(unc.round(3).T.to_string())

# draws for the figure (cell n = CELL_N)
np.savez_compressed(TABLES.parent / "01_posterior_draws_n48.npz",
                    psi=base["psi"][:20000], d_high=base["d_high"][:20000], d_all=base["d_all"][:20000],
                    n_high=base["n_high"][:20000], n_all=base["n_all"][:20000])

# ---------------------------------------------------------------- sensitivity to the prior and to integer counts (cell n = CELL_N)
prior_rows = []
for label, mode in (("uniform prior, non-integer counts (main)", "uniform"), ("Jeffreys prior (0.5), non-integer counts", "jeffreys"),
                    ("uniform prior, integer counts (13/3/7/6)", "integer")):
    c = {}
    for k, pk in ANCHOR.items():
        ev = pk * CELL_N if mode != "integer" else round(pk * CELL_N)
        add = 0.5 if mode == "jeffreys" else 1.0
        c[k] = rng.beta(ev + add, CELL_N - ev + add, size=DRAWS)
    r = required(c)
    prior_rows.append({"prior": label, "P_high_effect_le_0": float(np.mean(r["d_high"] <= 0)),
                       "P_allcomers_effect_le_0": float(np.mean(r["d_all"] <= 0)),
                       "enriched_n_q50": qn(r["n_high"], r["d_high"], 0.50), "enriched_n_q75": qn(r["n_high"], r["d_high"], 0.75),
                       "psi_q05": 100 * float(np.quantile(r["psi"], 0.05)), "psi_q95": 100 * float(np.quantile(r["psi"], 0.95))})
pd.DataFrame(prior_rows).to_csv(TABLES / "01_prior_sensitivity.csv", index=False, float_format="%.4f")
print("\n== prior / integer-count sensitivity at cell n = 48")
print(pd.DataFrame(prior_rows).round(3).to_string(index=False))

# ---------------------------------------------------------------- normal-approximation SE of the interaction contrast at n = CELL_N
se_psi = float(np.sqrt(sum(ANCHOR[k] * (1 - ANCHOR[k]) / CELL_N for k in ANCHOR)))
res["interaction_se_pp_at_cell_n"] = 100 * se_psi
res["interaction_wald95_pp"] = [100 * (res["interaction_pp"] / 100 - Z_A * se_psi), 100 * (res["interaction_pp"] / 100 + Z_A * se_psi)]
res["cell_n_assumed"] = CELL_N
res["seed"] = SEED
res["draws"] = DRAWS
(TABLES / "01_results.json").write_text(json.dumps(res, indent=2), encoding="utf-8")
print("\ninteraction SE (pp) at cell n=48:", round(100 * se_psi, 2), "Wald 95%:", [round(x, 1) for x in res["interaction_wald95_pp"]])

# ---------------------------------------------------------------- guard assertions
assert abs(d1["delta"] - 0.035) < 1e-12
assert abs(res["delta_high_pp"] - 14.0) < 1e-9 and abs(res["interaction_pp"] - 21.0) < 1e-9
assert d1["n_arm"] > d2["n_arm"] > 0
assert 0.5 < res["auc_atezolizumab_arm"] < 1 and abs(res["auc_docetaxel_arm"] - 0.5) < 0.02
print("assertions passed")
