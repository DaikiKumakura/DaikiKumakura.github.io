"""Step 2: what a purely prognostic score (same effect on risk in both arms) can save, as a function of its strength.

Model: S ~ N(0,1), logit P(PFS12 = 1 | S, arm a) = alpha_a + gamma * S (no treatment-by-score interaction on the logit scale).
alpha_a is solved so that the marginal PFS12 is 0.14 (control) and 0.24 (experimental), i.e. a 10-point marginal difference.
Estimand: marginal risk difference. Compared estimators (asymptotic variances by Gauss-Hermite quadrature):
  unadjusted difference of proportions, and the standardised (g-computation) estimator with a correct logistic model
  per arm (which is the efficient estimator in this model). Also the sample size for a test of the CONDITIONAL odds ratio
  in a logistic regression with the score, to show that this is a different estimand.
A Monte Carlo check (batched Newton fits) compares the formulas with simulated variances.
Run: python -X utf8 analysis/02_prognostic_adjustment.py
"""
import json
import sys

import numpy as np
import pandas as pd
from numpy.polynomial.hermite_e import hermegauss
from scipy.optimize import brentq
from scipy.special import expit

from common import TABLES, Z_SUM2, v

sys.stdout.reconfigure(encoding="utf-8")
SEED = 20261114
P0, P1 = 0.14, 0.24
NODES, WTS = hermegauss(200)
WTS = WTS / WTS.sum()  # weights of the standard normal


def expect(f):
    return float(np.sum(WTS * f(NODES)))


def alpha_for(p_marg: float, gamma: float) -> float:
    return brentq(lambda a: expect(lambda s: expit(a + gamma * s)) - p_marg, -30, 30)


def within_arm_auc(alpha: float, gamma: float) -> float:
    """P(S of an event patient > S of a non-event patient) for an arm with P(event|S) = expit(alpha + gamma S)."""
    s = np.linspace(-9, 9, 36001)
    phi = np.exp(-0.5 * s**2) / np.sqrt(2 * np.pi)
    p = expit(alpha + gamma * s)
    f1 = phi * p / np.trapezoid(phi * p, s)
    f0 = phi * (1 - p) / np.trapezoid(phi * (1 - p), s)
    F0 = np.concatenate([[0], np.cumsum(0.5 * (f0[1:] + f0[:-1]) * np.diff(s))])
    return float(np.trapezoid(f1 * F0, s))


def formulas(gamma: float) -> dict:
    a1, a0 = alpha_for(P1, gamma), alpha_for(P0, gamma)
    p1 = lambda s: expit(a1 + gamma * s)
    p0 = lambda s: expit(a0 + gamma * s)
    e1, e0 = expect(lambda s: v(p1(s))), expect(lambda s: v(p0(s)))
    delta = P1 - P0
    var_d = expect(lambda s: (p1(s) - p0(s) - delta) ** 2)
    v_un = v(P1) + v(P0)
    v_adj = e1 + e0 + var_d / 2.0
    tau = a1 - a0
    # Fisher information (per patient, 1:1) for (intercept, arm, score) in the pooled logistic model
    def info():
        I = np.zeros((3, 3))
        for arm, a in ((1, a1), (0, a0)):
            W = lambda s, a=a: v(expit(a + gamma * s))
            for i, s in enumerate(NODES):
                x = np.array([1.0, arm, s])
                I += 0.5 * WTS[i] * W(s) * np.outer(x, x)
        return I
    var_tau = np.linalg.inv(info())[1, 1]  # variance of tau_hat times N
    logor_m = np.log(P1 / (1 - P1)) - np.log(P0 / (1 - P0))
    n_cond = Z_SUM2 * var_tau / tau**2
    n_marg_or = 2 * Z_SUM2 * (1 / v(P1) + 1 / v(P0)) / logor_m**2
    return {
        "gamma": gamma,
        "auc_within_arm_ctrl": within_arm_auc(a0, gamma),
        "auc_within_arm_exp": within_arm_auc(a1, gamma),
        "var_explained_ctrl": expect(lambda s: (p0(s) - P0) ** 2) / v(P0),
        "v_unadj": v_un,
        "v_adj": v_adj,
        "n_ratio_rd_adj_over_unadj": v_adj / v_un,
        "n_arm_unadj_rd": Z_SUM2 * v_un / delta**2,
        "n_arm_adj_rd": Z_SUM2 * v_adj / delta**2,
        "cond_logor": tau,
        "marg_logor": logor_m,
        "n_total_cond_or_adjusted": n_cond,
        "n_total_marg_or_unadjusted": n_marg_or,
        "n_ratio_cond_over_marg": n_cond / n_marg_or,
    }


gammas = [0.0, 0.25, 0.5, 0.75, 1.0, 1.5, 2.0, 2.5, 3.0]
tab = pd.DataFrame([formulas(g) for g in gammas])
tab.to_csv(TABLES / "02_prognostic_sweep.csv", index=False, float_format="%.5f")
print("== analytic sweep (control PFS12 0.14, experimental 0.24)")
print(tab[["gamma", "auc_within_arm_ctrl", "var_explained_ctrl", "n_ratio_rd_adj_over_unadj", "n_ratio_cond_over_marg"]].round(4).to_string(index=False))


# ---------------------------------------------------------------- Monte Carlo check
def batch_logit(X, y, iters=12):
    """Logistic regression with intercept + one covariate, batched over axis 0. Returns (R, 2)."""
    R = X.shape[0]
    b = np.zeros((R, 2))
    for _ in range(iters):
        eta = b[:, [0]] + b[:, [1]] * X
        p = expit(eta)
        W = p * (1 - p)
        g0 = (y - p).sum(1)
        g1 = ((y - p) * X).sum(1)
        h00 = W.sum(1)
        h01 = (W * X).sum(1)
        h11 = (W * X * X).sum(1)
        det = h00 * h11 - h01**2
        b[:, 0] += (h11 * g0 - h01 * g1) / det
        b[:, 1] += (-h01 * g0 + h00 * g1) / det
    return b


rng = np.random.default_rng(SEED)
R, n = 20000, 300
mc_rows = []
for gamma in (0.5, 1.0, 2.0):
    a1, a0 = alpha_for(P1, gamma), alpha_for(P0, gamma)
    S1, S0 = rng.standard_normal((R, n)), rng.standard_normal((R, n))
    y1 = (rng.random((R, n)) < expit(a1 + gamma * S1)).astype(float)
    y0 = (rng.random((R, n)) < expit(a0 + gamma * S0)).astype(float)
    un = y1.mean(1) - y0.mean(1)
    b1, b0 = batch_logit(S1, y1), batch_logit(S0, y0)
    Sall = np.concatenate([S1, S0], axis=1)
    m1 = expit(b1[:, [0]] + b1[:, [1]] * Sall).mean(1)
    m0 = expit(b0[:, [0]] + b0[:, [1]] * Sall).mean(1)
    adj = m1 - m0
    f = formulas(gamma)
    mc_rows.append({
        "gamma": gamma,
        "mean_unadj": un.mean(), "mean_adj": adj.mean(), "true_delta": P1 - P0,
        "var_x_n_arm_unadj_mc": un.var(ddof=1) * n, "var_x_n_arm_unadj_formula": f["v_unadj"],
        "var_x_n_arm_adj_mc": adj.var(ddof=1) * n, "var_x_n_arm_adj_formula": f["v_adj"],
        "ratio_mc": adj.var(ddof=1) / un.var(ddof=1), "ratio_formula": f["n_ratio_rd_adj_over_unadj"],
    })
mc = pd.DataFrame(mc_rows)
mc.to_csv(TABLES / "02_monte_carlo_check.csv", index=False, float_format="%.5f")
print("\n== Monte Carlo check (R=20000 trials, n=300 per arm; seed 20261114)")
print(mc.round(4).to_string(index=False))

# guards: formula vs Monte Carlo within 4% on the variance ratio and variances; no bias
for r in mc_rows:
    assert abs(r["ratio_mc"] / r["ratio_formula"] - 1) < 0.04, r
    assert abs(r["var_x_n_arm_adj_mc"] / r["var_x_n_arm_adj_formula"] - 1) < 0.04, r
    assert abs(r["var_x_n_arm_unadj_mc"] / r["var_x_n_arm_unadj_formula"] - 1) < 0.04, r
    assert abs(r["mean_adj"] - r["true_delta"]) < 0.004 and abs(r["mean_unadj"] - r["true_delta"]) < 0.004, r
assert abs(tab.loc[0, "n_ratio_rd_adj_over_unadj"] - 1) < 1e-6 and (tab["n_ratio_rd_adj_over_unadj"].diff().dropna() <= 1e-9).all()
print("assertions passed")
(TABLES / "02_settings.json").write_text(json.dumps({"seed": SEED, "R": R, "n_arm": n, "p0": P0, "p1": P1, "nodes": 200}), encoding="utf-8")
