"""Step 3: simulated trials at the anchor cells, and what changes when the score or the trial conditions drift.

Part A  power and type I error of D1 (all-comers unadjusted), D2 (all-comers standardised over the binary score) and
        D4 (enriched, high score only), by cell counts (exact binomial sampling), at the analytic sample size.
Part B  analytic sensitivity of the enriched design: purity of the positive call (rho), shrinkage of the effect in the
        called-positive group, prevalence of the positive call, assay failure; compared with the all-comers design.
Part C  dropout before 12 months (non-informative) with a Kaplan-Meier estimate of PFS12 (exponential event times),
        D1 and D4, unadjusted: power loss at the dropout-free sample size and the sample size that restores 80% power.
Run: python -X utf8 analysis/03_design_simulation.py
"""
import json
import sys

import numpy as np
import pandas as pd

from common import ANCHOR, PREV, TABLES, Z_A, Z_SUM2, design_adjusted, design_enriched, design_unadjusted, interaction_total_n, v

sys.stdout.reconfigure(encoding="utf-8")
SEED = 20261114
rng = np.random.default_rng(SEED)
R_A = 40_000


# ------------------------------------------------------------------ Part A: count-based trials
def sim_counts(c: dict, n_total: int, design: str, reps: int, true_delta: float):
    """Returns power (|z| > z_alpha), coverage of the 95% CI for true_delta, and mean estimate."""
    half = n_total // 2
    if design == "enriched":
        x1 = rng.binomial(half, c["H1"], reps)
        x0 = rng.binomial(half, c["H0"], reps)
        p1, p0 = x1 / half, x0 / half
        est = p1 - p0
        se = np.sqrt(v(p1) / half + v(p0) / half)
    else:
        # strata counts per arm: binomial(half, prev); outcomes binomial within stratum
        nH1, nH0 = rng.binomial(half, PREV, reps), rng.binomial(half, PREV, reps)
        nL1, nL0 = half - nH1, half - nH0
        xH1, xH0 = rng.binomial(nH1, c["H1"]), rng.binomial(nH0, c["H0"])
        xL1, xL0 = rng.binomial(nL1, c["L1"]), rng.binomial(nL0, c["L0"])
        if design == "unadjusted":
            p1, p0 = (xH1 + xL1) / half, (xH0 + xL0) / half
            est = p1 - p0
            se = np.sqrt(v(p1) / half + v(p0) / half)
        else:  # standardised over the observed stratum shares (post-stratification)
            with np.errstate(divide="ignore", invalid="ignore"):
                pH1, pH0 = xH1 / nH1, xH0 / nH0
                pL1, pL0 = xL1 / nL1, xL0 / nL0
            wH = (nH1 + nH0) / (2 * half)
            wL = 1 - wH
            dH, dL = pH1 - pH0, pL1 - pL0
            est = wH * dH + wL * dL
            ev1 = wH * v(pH1) + wL * v(pL1)
            ev0 = wH * v(pH0) + wL * v(pL0)
            var_w = wH * (dH - est) ** 2 + wL * (dL - est) ** 2
            se = np.sqrt((ev1 + ev0 + var_w / 2.0) / half)
    ok = np.isfinite(est) & np.isfinite(se) & (se > 0)
    z = np.where(ok, est / np.where(ok, se, 1), 0.0)
    cover = np.where(ok, np.abs(est - true_delta) <= Z_A * np.where(ok, se, 1), False)
    return float(np.mean(np.abs(z) > Z_A)), float(np.mean(cover)), float(np.mean(est[ok])), float(1 - ok.mean())


rows = []
d1, d2, d4 = design_unadjusted(ANCHOR), design_adjusted(ANCHOR), design_enriched(ANCHOR)
true_all = d1["delta"]
for name, key, d, td in (("D1 all-comers unadjusted", "unadjusted", d1, true_all),
                         ("D2 all-comers adjusted", "adjusted", d2, true_all),
                         ("D4 enriched", "enriched", d4, ANCHOR["H1"] - ANCHOR["H0"])):
    n_tot = int(2 * np.ceil(d["n_arm"]))
    pw, cov, mean_est, bad = sim_counts(ANCHOR, n_tot, key, R_A, td)
    rows.append({"scenario": "anchors", "design": name, "n_randomised": n_tot, "analytic_n_arm": d["n_arm"],
                 "power_sim": pw, "ci_coverage_sim": cov, "mean_estimate": mean_est, "true_effect": td, "undefined_frac": bad})
# null: no treatment effect, score prognostic in both arms (high 0.20, low 0.10)
NULL = {"H1": 0.20, "L1": 0.10, "H0": 0.20, "L0": 0.10}
for n_tot in (100, 300, 1000):
    for name, key in (("D1 all-comers unadjusted", "unadjusted"), ("D2 all-comers adjusted", "adjusted"), ("D4 enriched", "enriched")):
        pw, cov, mean_est, bad = sim_counts(NULL, n_tot, key, R_A, 0.0)
        rows.append({"scenario": "null (no effect; score prognostic)", "design": name, "n_randomised": n_tot,
                     "analytic_n_arm": np.nan, "power_sim": pw, "ci_coverage_sim": cov, "mean_estimate": mean_est,
                     "true_effect": 0.0, "undefined_frac": bad})
# D3: interaction contrast psi = (H1 - H0) - (L1 - L0); each of the four cells gets N/4 patients
def sim_interaction(c: dict, n_total: int, reps: int, true_psi: float):
    m = n_total // 4
    ph = {k: rng.binomial(m, c[k], reps) / m for k in ("H1", "H0", "L1", "L0")}
    est = (ph["H1"] - ph["H0"]) - (ph["L1"] - ph["L0"])
    se = np.sqrt(sum(v(ph[k]) / m for k in ph))
    ok = se > 0
    z = np.where(ok, est / np.where(ok, se, 1), 0.0)
    cover = np.where(ok, np.abs(est - true_psi) <= Z_A * np.where(ok, se, 1), False)
    return float(np.mean(np.abs(z) > Z_A)), float(np.mean(cover)), float(np.mean(est[ok])), float(1 - ok.mean())


d3 = interaction_total_n(ANCHOR)
n3 = int(4 * np.ceil(d3["n_total"] / 4))
pw3, cov3, me3, bad3 = sim_interaction(ANCHOR, n3, R_A, d3["psi"])
rows.append({"scenario": "anchors", "design": "D3 interaction test", "n_randomised": n3, "analytic_n_arm": np.nan,
             "power_sim": pw3, "ci_coverage_sim": cov3, "mean_estimate": me3, "true_effect": d3["psi"], "undefined_frac": bad3})
for n_tot in (100, 300, 1000):
    pw0, cov0, me0, bad0 = sim_interaction(NULL, n_tot, R_A, 0.0)
    rows.append({"scenario": "null (no effect; score prognostic)", "design": "D3 interaction test", "n_randomised": n_tot,
                 "analytic_n_arm": np.nan, "power_sim": pw0, "ci_coverage_sim": cov0, "mean_estimate": me0,
                 "true_effect": 0.0, "undefined_frac": bad0})
A = pd.DataFrame(rows)
A.to_csv(TABLES / "03_partA_power_type1.csv", index=False, float_format="%.5f")
print("== Part A: simulated power at the analytic N, and type I error under the null")
print(A.round(4).to_string(index=False))

# ------------------------------------------------------------------ Part B: sensitivity of the enriched design
B_rows = []
ALL = design_unadjusted(ANCHOR)
all_n = 2 * ALL["n_arm"]
for rho in (1.0, 0.9, 0.8, 0.7, 0.6, 0.55, 0.5):
    c = dict(ANCHOR)
    c["H1"] = rho * ANCHOR["H1"] + (1 - rho) * ANCHOR["L1"]
    c["H0"] = rho * ANCHOR["H0"] + (1 - rho) * ANCHOR["L0"]
    e = design_enriched(c)
    B_rows.append({"axis": "purity of positive call rho", "value": rho, "delta_pp": 100 * e["delta"],
                   "randomised": 2 * e["n_arm"], "screened": e["screened"], "all_comers_randomised": all_n})
for s in (1.0, 0.75, 0.5, 0.35, 0.25, 0.15):
    c = dict(ANCHOR)
    c["H1"] = ANCHOR["H0"] + s * (ANCHOR["H1"] - ANCHOR["H0"])
    e = design_enriched(c)
    B_rows.append({"axis": "shrinkage of effect in high group (x of 14 pp)", "value": s, "delta_pp": 100 * e["delta"],
                   "randomised": 2 * e["n_arm"], "screened": e["screened"], "all_comers_randomised": all_n})
for prev in (0.2, 0.35, 0.5, 0.65, 0.8):
    e = design_enriched(ANCHOR, prev=prev)
    a = design_unadjusted(ANCHOR, prev=prev)  # the all-comers effect changes with the share of high patients
    B_rows.append({"axis": "prevalence of positive call (anchor cell risks kept)", "value": prev, "delta_pp": 100 * e["delta"],
                   "randomised": 2 * e["n_arm"], "screened": e["screened"], "all_comers_randomised": 2 * a["n_arm"]})
for miss in (0.0, 0.1, 0.2, 0.3, 0.4):
    e = design_enriched(ANCHOR, miss=miss)
    B_rows.append({"axis": "assay failure (no valid score)", "value": miss, "delta_pp": 100 * e["delta"],
                   "randomised": 2 * e["n_arm"], "screened": e["screened"], "all_comers_randomised": all_n})
B = pd.DataFrame(B_rows)
B.to_csv(TABLES / "03_partB_enrichment_sensitivity.csv", index=False, float_format="%.4f")
print("\n== Part B: sensitivity of the enriched design (randomised / screened vs all-comers randomised)")
print(B.round(2).to_string(index=False))


# ------------------------------------------------------------------ Part C: dropout with Kaplan-Meier PFS12
def km12(time: np.ndarray, event: np.ndarray):
    """Kaplan-Meier survival at t = 12 (all times are capped at 12) and Greenwood variance."""
    order = np.argsort(time)
    t, e = time[order], event[order]
    n = len(t)
    at_risk = n - np.arange(n)
    ev = e.astype(bool)
    d = np.ones(ev.sum())
    nr = at_risk[ev].astype(float)
    S = np.prod(1 - d / nr)
    var = S**2 * np.sum(d / (nr * (nr - d))) if np.all(nr > d) else np.nan
    return S, var


def sim_km(c: dict, n_total: int, design: str, drop: float, reps: int):
    """Returns (power, mean Greenwood variance of the difference) over valid trials."""
    half = n_total // 2
    mu = -np.log(1 - drop) / 12.0 if drop > 0 else 0.0
    pw = 0
    valid = 0
    vsum = 0.0
    for _ in range(reps):
        res = []
        for arm in ("1", "0"):
            if design == "enriched":
                p = np.full(half, c["H" + arm])
            else:
                high = rng.random(half) < PREV
                p = np.where(high, c["H" + arm], c["L" + arm])
            T = rng.exponential(1.0, half) / (-np.log(p) / 12.0)
            C = rng.exponential(1.0, half) / mu if mu > 0 else np.full(half, np.inf)
            tt = np.minimum(np.minimum(T, C), 12.0)
            ee = (T <= np.minimum(C, 12.0))
            res.append(km12(tt, ee))
        (S1, v1), (S0, v0) = res
        if np.isfinite(v1) and np.isfinite(v0) and v1 + v0 > 0:
            valid += 1
            vsum += v1 + v0
            pw += abs((S1 - S0) / np.sqrt(v1 + v0)) > Z_A
    return pw / max(valid, 1), vsum / max(valid, 1)


# note: for the all-comers design the exponential event hazard is a mixture over the score groups, so the marginal PFS12
# in each arm equals PREV*pH + (1-PREV)*pL exactly (the KM estimand is the marginal S(12)), as in Parts A and B.
# The sample-size inflation is the ratio of the mean Greenwood variance with dropout to that without dropout (a
# variance ratio is much less noisy than a search for the 80% crossing); it is then checked by one run at the inflated N.
C_rows = []
R_C = 6000
for name, key, d in (("D4 enriched", "enriched", d4), ("D1 all-comers unadjusted", "unadjusted", d1)):
    n0 = int(2 * np.ceil(d["n_arm"]))
    pw0, var0 = sim_km(ANCHOR, n0, key, 0.0, R_C)
    for drop in (0.0, 0.10, 0.20):
        pw, var = (pw0, var0) if drop == 0.0 else sim_km(ANCHOR, n0, key, drop, R_C)
        infl = var / var0
        n_inf = int(2 * np.ceil(infl * n0 / 2))
        pw_chk, _ = sim_km(ANCHOR, n_inf, key, drop, R_C) if drop > 0 else (pw0, var0)
        C_rows.append({"design": name, "dropout_by_12m": drop, "n_dropout_free": n0,
                       "power_at_dropout_free_n": pw, "variance_inflation": infl,
                       "n_inflated": n_inf, "power_at_inflated_n": pw_chk})
Cdf = pd.DataFrame(C_rows)
Cdf.to_csv(TABLES / "03_partC_dropout.csv", index=False, float_format="%.4f")
print("\n== Part C: dropout before 12 months, Kaplan-Meier PFS12 (R=6000 per point)")
print(Cdf.round(3).to_string(index=False))

# ------------------------------------------------------------------ break-even points (analytic)
from scipy.optimize import brentq


def enriched_with(rho=1.0, shrink=1.0):
    c = dict(ANCHOR)
    c["H1"] = rho * ANCHOR["H1"] + (1 - rho) * ANCHOR["L1"]
    c["H0"] = rho * ANCHOR["H0"] + (1 - rho) * ANCHOR["L0"]
    c["H1"] = c["H0"] + shrink * (c["H1"] - c["H0"])
    return design_enriched(c)


# Only the screened count is a non-trivial break-even: the randomised count of the enriched design equals the
# all-comers count exactly when the high group's effect equals the all-comers average (rho = 0.5, or shrink = 0.25).
be = {}
be["rho_break_even_screened"] = brentq(lambda x: enriched_with(rho=x)["screened"] - all_n, 0.5001, 1.0)
be["shrink_break_even_screened"] = brentq(lambda x: enriched_with(shrink=x)["screened"] - all_n, 0.1, 1.0)
be["all_comers_randomised"] = all_n
(TABLES / "03_break_even.json").write_text(json.dumps(be, indent=2), encoding="utf-8")
print("\n== break-even (enriched equals the all-comers randomised n of the anchors)")
for k, val in be.items():
    print(f"  {k}: {val:.4f}")

# ------------------------------------------------------------------ guards
Ad = A[A.scenario == "anchors"]
assert (Ad.power_sim.between(0.78, 0.83)).all(), Ad
assert (Ad.ci_coverage_sim.between(0.94, 0.96)).all(), Ad
nl = A[A.scenario != "anchors"]
assert (Cdf[Cdf.dropout_by_12m == 0].power_at_dropout_free_n.between(0.78, 0.82)).all(), Cdf
assert (Cdf[Cdf.dropout_by_12m > 0].power_at_inflated_n.between(0.77, 0.83)).all(), Cdf
assert nl[nl.n_randomised >= 300].power_sim.between(0.04, 0.06).all(), nl  # type I error near 5% once N >= 300
print("assertions passed")
(TABLES / "03_settings.json").write_text(json.dumps({"seed": SEED, "R_A": R_A, "R_C": R_C}), encoding="utf-8")
