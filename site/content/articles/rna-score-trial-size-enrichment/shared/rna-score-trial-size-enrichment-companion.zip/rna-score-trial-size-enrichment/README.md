# RNA-score trial size analysis (X26-20)

Working folder for the article `rna-score-trial-size-enrichment` (ja/en). Input: four published percentages and one count from a technical report (see `inputs/PROVENANCE.md`); no patient-level data, no model weights.

## Question and use
- QOI: if the POPLAR result quoted for an RNA foundation-model score holds (PFS12 by score half and arm), how many patients does a confirmatory trial need under four designs (all-comers unadjusted, all-comers score-adjusted, interaction test, enriched), and how uncertain is that number?
- COU: reading the claim "an AI score makes trials smaller" by design type and assumption. Not an evaluation of Ladon; not advice for a specific trial.

## Method summary
Binary PFS12 (complete 12-month follow-up assumed), marginal risk difference, two-sided alpha 0.05, power 0.80, 1:1. Formulas (1)-(3) of the article. Cell sizes (48 per cell) are an assumption; 24-96 tried. Beta posterior draws for sampling error. Purely prognostic scores swept by Gauss-Hermite integration. Monte Carlo (all four designs) and a statsmodels power check (D1 and D4 only, Equation (1)) check the formulas; D2 and D3 were checked by Monte Carlo only; dropout handled by Kaplan-Meier simulation.

## Order of work (honest record)
1. The formulas were derived first (before any simulation), from standard results; the scripts were then written by the same author and are not blinded or an independent implementation. 2. Two edits after first runs: the uncertainty quantiles were recomputed with a method that keeps infinite requirements (draws with a non-positive effect) instead of interpolating; the dropout analysis was changed from a power-crossing search (noisy) to a variance-ratio inflation checked by one run at the inflated size. After three reviews: a prior-sensitivity table (Jeffreys, integer counts) was added to script 01; wording of the checks, break-even values (0.574, 0.365) and the setting-specific AUC range were made precise. No formula or conclusion was changed because of a numerical result. 3. No time-stamped pre-registration.

## Run (clean directory, no inputs needed)
```
python -X utf8 analysis/01_anchor_designs.py
python -X utf8 analysis/02_prognostic_adjustment.py
python -X utf8 analysis/03_design_simulation.py
python -X utf8 analysis/04_figures_and_crosscheck.py
python -X utf8 analysis/05_manifest.py          # writes outputs/MANIFEST_SHA256.txt
python -X utf8 analysis/05_manifest.py --check  # compares a re-run with the stored hashes
```
Environment: Python 3.12.4, NumPy 2.2.6, SciPy 1.14.0, pandas 2.2.2, Matplotlib 3.9.1, statsmodels 0.14.2. Seed 20261114 (scripts 01-03). Runtime about one minute.

## Limits that matter
The four percentages were read from report text (figure not viewed); group sizes and intervals are not reported; time-to-event designs (hazard ratio, RMST) are not evaluated; the score is a binary high/low call; uncertainty covers only sampling error of the four proportions.
