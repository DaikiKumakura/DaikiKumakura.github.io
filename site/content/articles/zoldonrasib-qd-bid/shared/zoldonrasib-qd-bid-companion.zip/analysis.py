"""Zoldonrasib once daily vs twice daily: fit the published QD mean curves, then simulate paired virtual patients.

Model: oral two-compartment with lag time; shared disposition and absorption; per-dose relative
bioavailability (600 mg = 1). Concentrations in nM per mg of dose (no molecular weight is used), so CL/F and V/F
are on a relative scale. Steady state = day 15 after daily dosing (superposition).
"""
from pathlib import Path
import json

import numpy as np
import pandas as pd
from scipy.optimize import least_squares

ROOT = Path(__file__).resolve().parent
SEED = 20261022
N_BOOT = 1000
N_VIRTUAL = 4096
DOSES = [150, 300, 600, 900, 1200]
REF = 600
SS_DAY = 15
PAIRS = [(1200, 600), (900, 450), (600, 300)]       # (QD dose, BID dose)
GRID = np.linspace(0, 24, 2401)


def unit_conc(t, p, two_comp=True):
    """Concentration after a single unit dose given at time 0 (t may be negative)."""
    cl, v, q, vp, ka, tlag = p
    tt = np.clip(t - tlag, 0, None)
    if not two_comp:
        k = cl / v
        return np.where(t > tlag, ka / (v * (ka - k)) * (np.exp(-k * tt) - np.exp(-ka * tt)), 0.0)
    k10, k12, k21 = cl / v, q / v, q / vp
    s = k10 + k12 + k21
    alpha = (s + np.sqrt(s * s - 4 * k10 * k21)) / 2
    beta = (s - np.sqrt(s * s - 4 * k10 * k21)) / 2
    a = ka / v * (k21 - alpha) / ((ka - alpha) * (beta - alpha))
    b = ka / v * (k21 - beta) / ((ka - beta) * (alpha - beta))
    c = -(a + b)
    return np.where(t > tlag, a * np.exp(-alpha * tt) + b * np.exp(-beta * tt) + c * np.exp(-ka * tt), 0.0)


def ss_profile(t_in_tau, dose_mg, frel, p, tau=24.0, two_comp=True, days=SS_DAY):
    """Concentration at time t within a dosing interval at steady state (after `days` of dosing)."""
    n = int(round(days * 24 / tau))
    out = np.zeros_like(np.asarray(t_in_tau, dtype=float))
    for i in range(n):
        out = out + unit_conc(t_in_tau + i * tau, p, two_comp)
    return dose_mg * frel * out


def unpack(theta, doses):
    p = np.exp(theta[:6])
    frel = {REF: 1.0}
    frel.update({d: float(np.exp(x)) for d, x in zip([d for d in doses if d != REF], theta[6:])})
    return p, frel


def residuals(theta, data, doses, two_comp=True):
    p, frel = unpack(theta, doses)
    pred = np.concatenate([ss_profile(g.time_h.to_numpy(), d, frel[d], p, two_comp=two_comp)
                           for d, g in data.groupby("dose_mg")])
    return np.log(np.maximum(pred, 1e-12)) - np.log(data.sort_values(["dose_mg", "time_h"]).conc_nM.to_numpy())


def fit(data, two_comp=True, start=None, jitters=(0.0, 0.5, -0.5)):
    doses = sorted(data.dose_mg.unique())
    data = data.sort_values(["dose_mg", "time_h"])
    if start is None:
        start = np.r_[np.log([0.3, 1.0, 0.3, 2.0, 1.0, 0.25]), np.zeros(len(doses) - 1)]
    lo = np.r_[np.log([1e-3, 1e-3, 1e-4, 1e-3, 0.05, 0.01]), np.full(len(doses) - 1, -4)]
    hi = np.r_[np.log([1e2, 1e3, 1e2, 1e4, 20, 1.0]), np.full(len(doses) - 1, 4)]
    best = None
    for jitter in jitters:
        r = least_squares(residuals, np.clip(start + jitter * np.r_[np.ones(6), np.zeros(len(doses) - 1)], lo, hi),
                          bounds=(lo, hi), args=(data, doses, two_comp), method="trf", x_scale="jac", max_nfev=4000)
        if best is None or r.cost < best.cost:
            best = r
    return best, doses


def frel_at(dose, frel):
    """Log-dose interpolation of relative bioavailability for an unstudied per-dose amount."""
    if dose in frel:
        return frel[dose]
    ds = sorted(frel)
    lo = max(d for d in ds if d < dose)
    hi = min(d for d in ds if d > dose)
    w = (np.log(dose) - np.log(lo)) / (np.log(hi) - np.log(lo))
    return float(np.exp((1 - w) * np.log(frel[lo]) + w * np.log(frel[hi])))


def metrics(dose, tau, frel, p, cl_mult=1.0, ka_mult=1.0, two_comp=True):
    pp = p.copy()
    pp[0] *= cl_mult
    pp[4] *= ka_mult
    t = np.linspace(0, tau, int(tau * 100) + 1)
    c = ss_profile(t, dose, frel_at(dose, frel), pp, tau=tau, two_comp=two_comp)
    auc = np.trapz(c, t) * (24 / tau)
    return dict(cmax=float(c.max()), cmin=float(c[-1]), auc24=float(auc))


def trapz_obs(g):
    """Observed AUC0-24 from the digitised means; trough at time 0 is taken as the 24 h value (steady state)."""
    t = np.r_[0, g.time_h.to_numpy()]
    c = np.r_[g.conc_nM.to_numpy()[-1], g.conc_nM.to_numpy()]
    return float(np.trapz(c, t))


def compare(p, frel, rng, sd_cl, sd_ka=0.0, n=N_VIRTUAL):
    z = rng.standard_normal((n, 2))
    cl_m, ka_m = np.exp(sd_cl * z[:, 0]), np.exp(sd_ka * z[:, 1])
    rows = []
    for qd, bid in PAIRS:
        for i in range(n):
            a = metrics(qd, 24, frel, p, cl_m[i], ka_m[i])
            b = metrics(bid, 12, frel, p, cl_m[i], ka_m[i])
            rows.append(dict(pair=f"{qd} QD vs {bid} BID", id=i, **{f"qd_{k}": v for k, v in a.items()},
                             **{f"bid_{k}": v for k, v in b.items()}))
    return pd.DataFrame(rows)


def typical_ratios(p, frel, two_comp=True):
    out = {}
    for qd, bid in PAIRS:
        a, b = metrics(qd, 24, frel, p, two_comp=two_comp), metrics(bid, 12, frel, p, two_comp=two_comp)
        out[f"{qd} QD vs {bid} BID"] = {k: b[k] / a[k] for k in a}
    return out


def main():
    data = pd.read_csv(ROOT / "data/digitized-means.csv")
    box = pd.read_csv(ROOT / "data/digitized-auc-box.csv")
    assert len(data) == 45 and (data.conc_nM > 0).all()
    out = ROOT / "results"
    out.mkdir(exist_ok=True)

    # main fit and one-compartment comparison
    r2, doses = fit(data)
    r1, _ = fit(data, two_comp=False)
    n = len(data)
    # one-compartment leaves q and vp unused: 4 structural + 4 F_rel parameters
    k_par = {"two_comp": len(r2.x), "one_comp": len(r1.x) - 2}
    aic = {m: n * np.log(2 * r.cost / n) + 2 * k_par[m] for m, r in (("two_comp", r2), ("one_comp", r1))}
    p, frel = unpack(r2.x, doses)
    rmse = float(np.sqrt(2 * r2.cost / n))
    cl, v, q, vp, ka, tlag = p
    k10, k12, k21 = cl / v, q / v, q / vp
    s = k10 + k12 + k21
    alpha = (s + np.sqrt(s * s - 4 * k10 * k21)) / 2
    beta = (s - np.sqrt(s * s - 4 * k10 * k21)) / 2
    params = dict(cl_rel=cl, v_rel=v, q_rel=q, vp_rel=vp, ka=ka, tlag=tlag, half_life_alpha_h=np.log(2) / alpha,
                  half_life_beta_h=np.log(2) / beta, **{f"frel_{d}": frel[d] for d in doses}, rmse_log=rmse,
                  aic_two_comp=aic["two_comp"], aic_one_comp=aic["one_comp"])
    print("fit:", {k: round(float(x), 4) for k, x in params.items()})

    # observed vs model AUC and Cmax by dose; box medians
    chk = []
    for d, g in data.groupby("dose_mg"):
        m = metrics(d, 24, frel, p)
        row = dict(dose_mg=d, obs_auc_trapz=trapz_obs(g), model_auc24=m["auc24"], obs_cmax=g.conc_nM.max(),
                   model_cmax=m["cmax"], obs_c24=float(g[g.time_h == 24].conc_nM.iloc[0]), model_cmin=m["cmin"])
        bm = box[box.dose_mg == d]
        row["box_median_auc"] = float(bm["median"].iloc[0]) if len(bm) else np.nan
        chk.append(row)
    chk = pd.DataFrame(chk)
    chk["auc_per_mg_obs"] = chk.obs_auc_trapz / chk.dose_mg
    chk.round(3).to_csv(out / "dose-check.csv", index=False, lineterminator="\n")
    print(chk.round(1).to_string())

    # held-out 900 mg
    r_ho, d_ho = fit(data[data.dose_mg != 900])
    p_ho, frel_ho = unpack(r_ho.x, d_ho)
    frel_ho_900 = frel_at(900, frel_ho)
    g9 = data[data.dose_mg == 900]
    m9 = metrics(900, 24, {**frel_ho, 900: frel_ho_900}, p_ho)
    holdout = dict(frel_900_interpolated=frel_ho_900, frel_900_fitted=frel[900],
                   pred_auc=m9["auc24"], obs_auc=trapz_obs(g9), pred_cmax=m9["cmax"], obs_cmax=float(g9.conc_nM.max()),
                   pred_c24=m9["cmin"], obs_c24=float(g9[g9.time_h == 24].conc_nM.iloc[0]))
    holdout.update(auc_error=holdout["pred_auc"] / holdout["obs_auc"] - 1, cmax_error=holdout["pred_cmax"] / holdout["obs_cmax"] - 1,
                   c24_error=holdout["pred_c24"] / holdout["obs_c24"] - 1)
    print("holdout 900:", {k: round(v, 3) for k, v in holdout.items()})

    # typical-subject ratios, with residual bootstrap for parameter uncertainty
    base = typical_ratios(p, frel)
    rng = np.random.default_rng(SEED)
    fitted = np.exp(-residuals(r2.x, data, doses)) * data.sort_values(["dose_mg", "time_h"]).conc_nM.to_numpy()
    res = residuals(r2.x, data, doses)
    boot = []
    srt = data.sort_values(["dose_mg", "time_h"]).reset_index(drop=True)
    for b in range(N_BOOT):
        bd = srt.copy()
        bd["conc_nM"] = fitted * np.exp(rng.choice(res, len(res), replace=True))
        rb, _ = fit(bd, start=r2.x, jitters=(0.0,))
        pb, fb = unpack(rb.x, doses)
        for pair, v in typical_ratios(pb, fb).items():
            boot.append(dict(b=b, pair=pair, **v, frel_300=fb[300], frel_1200=fb[1200]))
    boot = pd.DataFrame(boot)
    boot.round(6).to_csv(out / "bootstrap-ratios.csv", index=False, lineterminator="\n")
    summ = []
    for pair, g in boot.groupby("pair", sort=False):
        for k in ("cmax", "cmin", "auc24"):
            summ.append(dict(pair=pair, metric=k, point=base[pair][k], lo=g[k].quantile(0.025), hi=g[k].quantile(0.975)))
    summ = pd.DataFrame(summ)
    summ.round(4).to_csv(out / "ratio-summary.csv", index=False, lineterminator="\n")
    print(summ.round(3).to_string())

    # virtual patients (CL/F variability from the AUC box plot), paired across regimens
    sd_cl = float(box.log_sd_from_iqr.mean())
    vp_main = compare(p, frel, np.random.default_rng(SEED + 1), sd_cl)
    vp_ka = compare(p, frel, np.random.default_rng(SEED + 2), sd_cl, sd_ka=0.5, n=1024)
    dist = []
    for name, vp_ in (("CL/F variability", vp_main), ("CL/F + ka variability (sensitivity)", vp_ka)):
        for pair, g in vp_.groupby("pair", sort=False):
            for k in ("cmax", "cmin", "auc24"):
                for arm in ("qd", "bid"):
                    x = g[f"{arm}_{k}"]
                    dist.append(dict(setting=name, pair=pair, metric=k, arm=arm, p05=x.quantile(0.05), p50=x.median(), p95=x.quantile(0.95)))
                rr = g[f"bid_{k}"] / g[f"qd_{k}"]
                dist.append(dict(setting=name, pair=pair, metric=k, arm="ratio", p05=rr.quantile(0.05), p50=rr.median(), p95=rr.quantile(0.95)))
    dist = pd.DataFrame(dist)
    dist.round(4).to_csv(out / "virtual-patients.csv", index=False, lineterminator="\n")

    # sensitivities on the typical-subject ratio
    sens = []
    r_no, d_no = fit(data[~data.occluded])
    p_no, f_no = unpack(r_no.x, d_no)
    lin = {d: 1.0 for d in DOSES}
    r_lin = least_squares(lambda th: residuals(np.r_[th, np.zeros(len(doses) - 1)], data, doses), r2.x[:6],
                          bounds=(np.log([1e-3, 1e-3, 1e-4, 1e-3, 0.05, 0.01]), np.log([1e2, 1e3, 1e2, 1e4, 20, 1.0])))
    p_lin = np.exp(r_lin.x)
    for name, (pp, ff, tc) in {"main": (p, frel, True), "occluded points removed": (p_no, f_no, True),
                               "linear (all F_rel = 1)": (p_lin, lin, True),
                               "one-compartment": (*unpack(r1.x, doses), False)}.items():
        for pair, v in typical_ratios(pp, ff, two_comp=tc).items():
            sens.append(dict(setting=name, pair=pair, **v))
    # planned sensitivity: unequal twice-daily spacing (doses at 0 h and 8 h of each day)
    for qd, bid in PAIRS:
        t = np.linspace(0, 24, 2401)
        f1 = frel_at(bid, frel)
        c = ss_profile(t, bid, f1, p, tau=24) + ss_profile((t - 8) % 24, bid, f1, p, tau=24)
        a = metrics(qd, 24, frel, p)
        sens.append(dict(setting="twice daily at 8/16 h spacing", pair=f"{qd} QD vs {bid} BID",
                         cmax=float(c.max()) / a["cmax"], cmin=float(c.min()) / a["cmin"],
                         auc24=float(np.trapz(c, t)) / a["auc24"]))
    sens = pd.DataFrame(sens)
    sens.round(4).to_csv(out / "sensitivity.csv", index=False, lineterminator="\n")
    print(sens.round(3).to_string())

    # profiles for figures
    prof = []
    for d in DOSES:
        prof.append(pd.DataFrame({"regimen": f"{d} mg QD", "time_h": GRID, "conc_nM": ss_profile(GRID, d, frel[d], p)}))
    for qd, bid in PAIRS:
        tb = GRID % 12
        prof.append(pd.DataFrame({"regimen": f"{bid} mg BID", "time_h": GRID,
                                  "conc_nM": ss_profile(tb, bid, frel_at(bid, frel), p, tau=12)}))
    pd.concat(prof).round(4).to_csv(out / "model-profiles.csv", index=False, lineterminator="\n")

    summary = dict(params=params, holdout=holdout, sd_cl=sd_cl, n_virtual=N_VIRTUAL, n_boot=N_BOOT,
                   boot_frel_300=[float(boot.frel_300.quantile(q)) for q in (0.025, 0.5, 0.975)],
                   boot_frel_1200=[float(boot.frel_1200.quantile(q)) for q in (0.025, 0.5, 0.975)])
    (out / "summary.json").write_text(json.dumps(summary, indent=2, default=float) + "\n", encoding="utf-8")


if __name__ == "__main__":
    main()
