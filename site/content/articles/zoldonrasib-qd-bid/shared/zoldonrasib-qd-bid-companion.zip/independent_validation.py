"""Independent matrix-exponential solution of the oral model, not analytic helper reuse."""
from pathlib import Path
import json
import numpy as np
import pandas as pd
from scipy.linalg import expm

R=Path(__file__).resolve().parent

def main():
    p=json.loads((R/'results/summary.json').read_text())['params']
    cl,v,q,vp,ka,lag=[p[k] for k in ['cl_rel','v_rel','q_rel','vp_rel','ka','tlag']]
    mat=np.array([[-ka,0,0],[ka,-(cl+q)/v,q/vp],[0,q/v,-q/vp]])
    def amplitude(d):
        ds=np.array([150,300,600,900,1200]);fs=np.array([p[f'frel_{x}'] for x in ds])
        return np.exp(np.interp(np.log(d),np.log(ds),np.log(fs)))
    def metrics(d,tau):
        dose=np.array([d*amplitude(d),0,0])
        after=np.linalg.solve(np.eye(3)-expm(mat*tau),dose)
        t=np.linspace(0,tau,int(tau*100)+1)
        c=np.array([(expm(mat*((x-lag)%tau))@after)[1]/v for x in t])
        return dict(cmax=c.max(),cmin=c[-1],auc24=np.trapz(c,t)*24/tau)
    ref=pd.read_csv(R/'results/ratio-summary.csv');rows=[]
    for qd,bid in [(1200,600),(900,450),(600,300)]:
        a,b=metrics(qd,24),metrics(bid,12);pair=f'{qd} QD vs {bid} BID'
        for key in a:
            actual=b[key]/a[key];expected=float(ref[(ref.pair==pair)&(ref.metric==key)].point.iloc[0])
            rows.append(dict(pair=pair,metric=key,matrix_ratio=actual,analytic_rounded=expected,relative_difference=abs(actual/expected-1)))
    worst=max(r['relative_difference'] for r in rows)
    assert worst<.0002,(worst,rows)
    out=dict(status='pass',method='Independent three-state matrix-exponential periodic solution, 0.01h metric grid; legacy cmin means predose',max_rel_diff=worst,comparisons=rows)
    (R/'results/validation.json').write_text(json.dumps(out,indent=2)+'\n')
    print('Independent 9 ratios pass, max relative difference',worst)

if __name__=='__main__':main()
