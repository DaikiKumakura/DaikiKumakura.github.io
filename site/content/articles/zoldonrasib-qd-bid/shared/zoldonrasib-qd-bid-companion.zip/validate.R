# Independent re-implementation (base R): integrate the two-compartment oral model as ODEs with a fixed-step
# RK4 solver (dose events as boluses into the depot after the lag), using the fitted parameters in
# results/summary.json, and compare steady-state Cmax, Cmin and AUC24 with results/ratio-summary.csv.
# Run from this folder: Rscript validate.R
s <- jsonlite::fromJSON("results/summary.json")$params
frel <- c("150" = s$frel_150, "300" = s$frel_300, "600" = s$frel_600, "900" = s$frel_900, "1200" = s$frel_1200)
frel_at <- function(d) {
  k <- as.character(d)
  if (k %in% names(frel)) return(unname(frel[k]))
  ds <- as.numeric(names(frel)); lo <- max(ds[ds < d]); hi <- min(ds[ds > d])
  w <- (log(d) - log(lo)) / (log(hi) - log(lo))
  exp((1 - w) * log(frel[as.character(lo)]) + w * log(frel[as.character(hi)]))[[1]]
}
deriv <- function(y) {
  c(-s$ka * y[1],
    s$ka * y[1] - (s$cl_rel + s$q_rel) / s$v_rel * y[2] + s$q_rel / s$vp_rel * y[3],
    s$q_rel / s$v_rel * y[2] - s$q_rel / s$vp_rel * y[3])
}
simulate <- function(dose, tau, days = 15, h = 0.005) {
  amt <- dose * frel_at(dose)
  n_dose <- round(days * 24 / tau)
  t_end <- n_dose * tau
  steps <- round(t_end / h)
  y <- c(0, 0, 0); out_t <- numeric(0); out_c <- numeric(0)
  dose_steps <- round((seq_len(n_dose) - 1) * tau / h + s$tlag / h)
  for (i in 0:steps) {
    if (i %in% dose_steps) y[1] <- y[1] + amt
    t <- i * h
    if (t >= t_end - tau - 1e-9) { out_t <- c(out_t, t - (t_end - tau)); out_c <- c(out_c, y[2] / s$v_rel) }
    k1 <- deriv(y); k2 <- deriv(y + h / 2 * k1); k3 <- deriv(y + h / 2 * k2); k4 <- deriv(y + h * k3)
    y <- y + h / 6 * (k1 + 2 * k2 + 2 * k3 + k4)
  }
  auc <- sum(diff(out_t) * (head(out_c, -1) + tail(out_c, -1)) / 2) * 24 / tau
  c(cmax = max(out_c), cmin = tail(out_c, 1), auc24 = auc)
}
ref <- read.csv("results/ratio-summary.csv")
pairs <- list(c(1200, 600), c(900, 450), c(600, 300))
rows <- list()
for (pr in pairs) {
  a <- simulate(pr[1], 24); b <- simulate(pr[2], 12)
  lab <- sprintf("%d QD vs %d BID", pr[1], pr[2])
  for (m in c("cmax", "cmin", "auc24")) {
    r_ode <- b[[m]] / a[[m]]
    r_py <- ref$point[ref$pair == lab & ref$metric == m]
    rows[[length(rows) + 1]] <- data.frame(pair = lab, metric = m, ode = r_ode, analytic = r_py)
  }
}
cmp <- do.call(rbind, rows)
cmp$rel_diff <- abs(cmp$ode / cmp$analytic - 1)
print(cmp)
ok <- all(cmp$rel_diff < 0.01)
jsonlite::write_json(list(status = if (ok) "pass" else "fail", method = "base R RK4 ODE integration, h = 0.005 h",
                          max_rel_diff = max(cmp$rel_diff), comparisons = cmp),
                     "results/validation.json", auto_unbox = TRUE, pretty = TRUE, digits = 8)
cat("validation:", if (ok) "pass" else "fail", "\n")
