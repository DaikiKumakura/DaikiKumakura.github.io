# Zoldonrasibの1日1回と1日2回：配布資料

記事「Zoldonrasibを1日2回に分けたら：公開PK曲線からの予測」の再実行用資料。

## 含むもの

- `analysis-plan.md`：データの監査、問い・使いみち・モデル・感度・判断の規則（当てはめ前に固定、追記あり）
- `digitize.py`：ポスターの図（8ページ）からの読み取りと、読み取りの確認図
- `data/`：読み取った平均濃度と箱ひげ図の四分位
- `input-provenance.json`：入力PDFの出典とSHA-256
- `analysis.py`, `test_analysis.py`, `figures.py`：当てはめ、仮想患者、検査、図
- `validate.R`：Rで微分方程式を数値的に解く独立の再計算
- `results/`、`figures/`

入力のPDF本体は同梱しない。出典のURLから取得し、`input-provenance.json` のSHA-256で照合して `inputs/` に置く。

## 実行

`python digitize.py && python test_analysis.py && python analysis.py && python figures.py && Rscript validate.R`

1日2回の値はすべてモデルによる予測である。臨床での効果・安全性の差や、推奨する用法は扱わない。
