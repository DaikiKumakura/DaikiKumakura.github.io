"""Digitise the C1D15 mean whole-blood PK curves and the AUC box plot from the AACR 2025 poster (page 8).

Automatic: per-colour pixel centroid in a narrow strip at each nominal time. Manual: points hidden by
overlapping markers, read from an 8x enlargement (pixel rows listed below). Writes inputs-derived CSVs and a
QC overlay image.
"""
from pathlib import Path
import hashlib
import json

import numpy as np
import pandas as pd
import pymupdf
from PIL import Image, ImageDraw
from scipy import ndimage as nd

ROOT = Path(__file__).resolve().parent
PDF = ROOT / "inputs/zoldonrasib-aacr.pdf"
PK_XREF, AUC_XREF = 135, 136
TIMES = [0.5, 1, 1.5, 2, 2.5, 4, 6, 8, 24]
COLOURS = {150: (0, 0, 255), 300: (160, 32, 240), 600: (0, 255, 0), 900: (255, 0, 0), 1200: (205, 170, 125)}
# axis calibration from tick-mark pixels: x ticks every hour, y ticks every decade
X0, PX = 16.5, (568 - 16.5) / 24
Y_ONE, PY = 354.5, (354.5 - 28) / 4          # row of 1 nM, pixels per decade
# manual reads (row in the original 630x450 image) for points hidden by other markers
MANUAL = {(150, 0.5): 197.5, (600, 0.5): 138.1, (600, 1): 101.25, (900, 0.5): 128.1, (900, 1): 88.1,
          (1200, 1): 89.4}
OCCLUDED = {(600, 0.5), (600, 1), (900, 0.5), (900, 1), (1200, 0.5), (1200, 1), (1200, 1.5), (900, 1.5)}
# AUC box plot: rows of the box edges (Q1, median, Q3) read from the outline pixels; 10,000 nM*h per 130 px, 0 at row 421
BOX_ROWS = {600: (371.5, 346.0, 327.5), 900: (339.5, 313.5, 283.5), 1200: (326.5, 280.0, 232.5)}


def image(xref):
    d = pymupdf.open(PDF)
    pix = pymupdf.Pixmap(d, xref)
    return np.asarray(Image.frombytes("RGB", (pix.width, pix.height), pix.samples)).astype(int)


def conc(row):
    return 10 ** ((Y_ONE - row) / PY)


def main():
    a = image(PK_XREF)
    h, w, _ = a.shape
    yy, xx = np.mgrid[:h, :w]
    legend = (xx > 385) & (yy < 185)
    rows = []
    for dose, col in COLOURS.items():
        mask = (np.abs(a - np.array(col)).sum(2) < 110) & ~legend
        for t in TIMES:
            x = X0 + t * PX
            if (dose, t) in MANUAL:
                r, src = MANUAL[(dose, t)], "manual"
            else:
                s = mask[:, int(x - 4):int(x + 5)].sum(1)
                lab, n = nd.label(s >= 4)
                if n == 0:
                    continue
                best = np.argmax(nd.sum(s, lab, range(1, n + 1))) + 1
                rr = np.flatnonzero(lab == best)
                r, src = float((rr * s[rr]).sum() / s[rr].sum()), "auto"
            rows.append(dict(dose_mg=dose, time_h=t, conc_nM=round(conc(r), 2), pixel_row=round(r, 2),
                             source=src, occluded=(dose, t) in OCCLUDED))
    df = pd.DataFrame(rows).sort_values(["dose_mg", "time_h"])
    assert len(df) == len(COLOURS) * len(TIMES), "missing points"
    (ROOT / "data").mkdir(exist_ok=True)
    df.to_csv(ROOT / "data/digitized-means.csv", index=False, lineterminator="\n")
    box = pd.DataFrame([dict(dose_mg=k, q1=(421 - v[0]) / 130 * 1e4, median=(421 - v[1]) / 130 * 1e4,
                             q3=(421 - v[2]) / 130 * 1e4) for k, v in BOX_ROWS.items()]).round(1)
    box["log_sd_from_iqr"] = (np.log(box.q3 / box.q1) / 1.349).round(4)
    box.to_csv(ROOT / "data/digitized-auc-box.csv", index=False, lineterminator="\n")
    # QC overlay
    im = Image.fromarray(a.astype("uint8")).resize((w * 2, h * 2), Image.NEAREST)
    dr = ImageDraw.Draw(im)
    for _, r in df.iterrows():
        x, y = 2 * (X0 + r.time_h * PX), 2 * r.pixel_row
        dr.ellipse([x - 5, y - 5, x + 5, y + 5], outline=(0, 0, 0), width=2)
    # kept private: it contains the poster's own figure
    (ROOT / "qc").mkdir(exist_ok=True)
    im.save(ROOT / "qc/00-digitization-qc.png")
    prov = {"source": "https://www.revmed.com/wp-content/uploads/2025/04/AACR-2025-Zoldon-Corporate-Rev.pdf",
            "file": "inputs/zoldonrasib-aacr.pdf", "bytes": PDF.stat().st_size,
            "sha256": hashlib.sha256(PDF.read_bytes()).hexdigest(), "page": 8, "image_xrefs": [PK_XREF, AUC_XREF]}
    (ROOT / "input-provenance.json").write_text(json.dumps(prov, indent=2) + "\n", encoding="utf-8")
    print(df.pivot(index="time_h", columns="dose_mg", values="conc_nM"))
    print(box)


if __name__ == "__main__":
    main()
