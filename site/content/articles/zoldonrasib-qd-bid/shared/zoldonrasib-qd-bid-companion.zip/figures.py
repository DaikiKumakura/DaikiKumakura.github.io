"""Figures from data/ and results/ (run digitize.py and analysis.py first)."""
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import pandas as pd

ROOT = Path(__file__).resolve().parent
data = pd.read_csv(ROOT / "data/digitized-means.csv")
prof = pd.read_csv(ROOT / "results/model-profiles.csv")
summ = pd.read_csv(ROOT / "results/ratio-summary.csv")
COL = {150: "#0072B2", 300: "#CC79A7", 600: "#009E73", 900: "#D55E00", 1200: "#E69F00"}

# Figure 1: digitised QD means and model fit
fig, ax = plt.subplots(figsize=(7, 4.2), constrained_layout=True)
for d, g in data.groupby("dose_mg"):
    m = prof[prof.regimen == f"{d} mg QD"]
    ax.plot(m.time_h, m.conc_nM, color=COL[d], linewidth=1.3)
    ax.scatter(g.time_h, g.conc_nM, color=COL[d], s=22, label=f"{d} mg QD", zorder=3,
               edgecolor=["k" if o else "none" for o in g.occluded])
ax.set_yscale("log")
ax.set_xlabel("Time after dose at steady state, cycle 1 day 15 (h)")
ax.set_ylabel("Whole-blood concentration (nM)")
ax.set_title("Points: mean values digitised from the AACR 2025 poster (black edge = read from overlapping markers);\n"
             "lines: two-compartment model fitted to all five doses", fontsize=8.5)
ax.legend(fontsize=7.5)
fig.savefig(ROOT / "figures/01-qd-fit.png", dpi=150)

# Figure 2: predicted QD vs BID profiles over 24 h
fig, axes = plt.subplots(1, 3, figsize=(10, 3.6), constrained_layout=True, sharey=True)
for ax, (qd, bid) in zip(axes, [(1200, 600), (900, 450), (600, 300)]):
    a = prof[prof.regimen == f"{qd} mg QD"]
    b = prof[prof.regimen == f"{bid} mg BID"]
    ax.plot(a.time_h, a.conc_nM, color="#0072B2", label=f"{qd} mg once daily")
    ax.plot(b.time_h, b.conc_nM, color="#D55E00", linestyle="--", label=f"{bid} mg twice daily (predicted)")
    ax.set_yscale("log")
    ax.set_xlabel("Time (h)")
    ax.set_title(f"{qd} mg/day", fontsize=9)
    ax.legend(fontsize=7, loc="lower center")
axes[0].set_ylabel("Whole-blood concentration (nM)")
fig.suptitle("Reference aggregate-fit profiles; twice-daily curves are model predictions, not observed", fontsize=9)
fig.savefig(ROOT / "figures/02-qd-vs-bid.png", dpi=150)

# Figure 3: ratios with bootstrap intervals
fig, ax = plt.subplots(figsize=(8, 3.8), constrained_layout=True)
lab = {"cmax": "Cmax", "cmin": "Ctrough (predose)", "auc24": "AUC24"}
mk = {"cmax": "o", "cmin": "s", "auc24": "D"}
pairs = list(dict.fromkeys(summ.pair))
for j, m in enumerate(lab):
    g = summ[summ.metric == m].set_index("pair").loc[pairs]
    y = [i + (j - 1) * 0.22 for i in range(len(pairs))]
    ax.errorbar(g.point, y, xerr=[g.point - g.lo, g.hi - g.point], fmt=mk[m], capsize=3, label=lab[m],
                color={"cmax": "#0072B2", "cmin": "#D55E00", "auc24": "#009E73"}[m])
ax.axvline(1, color="grey", linewidth=1)
ax.set_xscale("log")
ax.set_yticks(range(len(pairs)), [p.replace(" vs ", " vs\n") for p in pairs])
ticks = [0.25, 0.5, 0.8, 1, 1.25, 2, 4]
ax.set_xticks(ticks, [str(t) for t in ticks])
ax.minorticks_off()
ax.set_xlabel("Ratio: twice daily / once daily, same daily dose\n(reference curve; conditional 2.5-97.5% residual-resampling range)")
ax.legend(fontsize=7.5)
fig.savefig(ROOT / "figures/03-ratios.png", dpi=150)
print("figures written")
