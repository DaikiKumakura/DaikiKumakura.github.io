"""Checks of the PK model and fitting on synthetic data."""
import numpy as np
import pandas as pd

import analysis as A

P = np.array([0.1, 0.2, 0.03, 0.15, 0.8, 0.3])     # cl, v, q, vp, ka, tlag


def test_unit_dose_auc_equals_one_over_cl():
    t = np.linspace(0, 400, 400001)
    auc = np.trapz(A.unit_conc(t, P), t)
    assert abs(auc * P[0] - 1) < 1e-3


def test_steady_state_auc_over_tau_equals_single_dose_auc():
    # at steady state AUC over one interval equals the total AUC of one dose
    t = np.linspace(0, 24, 24001)
    c = A.ss_profile(t, 1.0, 1.0, P, tau=24, days=40)
    assert abs(np.trapz(c, t) * P[0] - 1) < 2e-3


def test_one_compartment_branch():
    p = np.array([0.2, 1.0, 0.0, 1.0, 1.5, 0.0])
    t = np.array([1.0, 5.0])
    k, ka = 0.2, 1.5
    exact = ka / (1.0 * (ka - k)) * (np.exp(-k * t) - np.exp(-ka * t))
    assert np.allclose(A.unit_conc(t, p, two_comp=False), exact)


def test_frel_interpolation_on_log_dose():
    f = {300: 1.0, 600: 2.0}
    assert abs(A.frel_at(np.sqrt(300 * 600), f) - np.sqrt(2.0)) < 1e-12
    assert A.frel_at(600, f) == 2.0


def test_fit_recovers_synthetic_parameters():
    times = [0.5, 1, 1.5, 2, 2.5, 4, 6, 8, 24]
    frel = {150: 0.5, 300: 1.0, 600: 1.0, 900: 1.1, 1200: 1.0}
    rows = [dict(dose_mg=d, time_h=t, conc_nM=float(A.ss_profile(np.array([t]), d, frel[d], P)[0]), occluded=False)
            for d in frel for t in times]
    r, doses = A.fit(pd.DataFrame(rows))
    p, f = A.unpack(r.x, doses)
    assert np.allclose(p, P, rtol=0.02)
    assert all(abs(f[d] - frel[d]) < 0.01 for d in frel)


def test_metrics_bid_halves_peak_for_fast_drug():
    # with a short half-life, splitting the dose lowers the peak and raises the trough
    f = {300: 1.0, 600: 1.0}
    a = A.metrics(600, 24, f, P)
    b = A.metrics(300, 12, f, P)
    assert b["cmax"] < a["cmax"] and b["cmin"] > a["cmin"]
    assert abs(b["auc24"] / a["auc24"] - 1) < 1e-3


def test_metrics_respects_one_compartment_flag():
    f = {600: 1.0}
    one = A.metrics(600, 24, f, P, two_comp=False)
    two = A.metrics(600, 24, f, P, two_comp=True)
    assert abs(one["cmin"] - two["cmin"]) > 1e-6


if __name__ == "__main__":
    for name, fn in list(globals().items()):
        if name.startswith("test_"):
            fn()
    print("all tests passed")
