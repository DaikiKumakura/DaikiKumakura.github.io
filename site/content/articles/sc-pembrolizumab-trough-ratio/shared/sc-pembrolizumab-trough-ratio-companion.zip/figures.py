"""Figure 1: cycle-3 Ctrough ratio (SC/IV) versus the absorption rate constant, with the reported ratio and its 94% CI."""
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

import analysis as an

ROOT = Path(__file__).resolve().parent
(ROOT / "figures").mkdir(exist_ok=True)
(ROOT / "results").mkdir(exist_ok=True)

k = np.log(2) / an.HALF_LIFE
kas = np.round(np.concatenate([np.arange(0.04, 0.2, 0.02), np.arange(0.2, 2.01, 0.1)]), 3)
rows = []
for ka in kas:
    t = np.array([an.TAU * 3])
    sc = an.one_comp_sc(ka, k, an.F_LABEL * an.DOSE_SC, t, 3)[0] / an.V_LABEL
    iv = sum(an.DOSE_IV * np.exp(-k * (an.TAU * 3 - i * an.TAU)) for i in range(3)) / an.V_LABEL
    rb = an.model_b_ratios(float(ka), an.F_LABEL)
    rows.append(dict(ka_per_day=ka, tmax_one_comp_days=an.tmax_one_comp(ka, k), c3_ratio_model_a=sc / iv, c3_ratio_model_b=rb["c3"]))
df = pd.DataFrame(rows)
df.round(4).to_csv(ROOT / "results" / "ka-scan-c3-ratio.csv", index=False, lineterminator="\n")

fig, ax = plt.subplots(figsize=(7.2, 4.2), dpi=150)
ax.axhspan(an.GMR_CTROUGH[1], an.GMR_CTROUGH[2], color="#bbbbbb", alpha=0.5, label="Reported ratio, 94% CI (1.52-1.84)")
ax.axhline(an.GMR_CTROUGH[0], color="#555555", lw=1)
ax.plot(df.ka_per_day, df.c3_ratio_model_a, color="#0072B2", lw=2, label="Model A: one compartment (label values)")
ax.plot(df.ka_per_day, df.c3_ratio_model_b, color="#D55E00", lw=2, ls="--", label="Model B: two compartments (Ahamadi 2017)")
ka4 = float(an.model_a()["ka"])
ax.axvline(ka4, color="#009E73", lw=1, ls=":")
ax.text(ka4 + 0.04, 1.12, "Tmax 4 days\n(Model A)", color="#009E73", fontsize=8, va="bottom")
ax.set_xscale("log")
ax.set_xlabel("Absorption rate constant ka (per day, log scale)")
ax.set_ylabel("Cycle-3 trough ratio, SC 790 mg / IV 400 mg (q6w)")
ax.set_title("Trough ratio predicted with bioavailability 0.60 (typical patient, no variability)", fontsize=9)
ax.legend(fontsize=8, loc="upper right")
ax.set_ylim(1.0, 2.1)
fig.tight_layout()
fig.savefig(ROOT / "figures" / "01-trough-ratio-vs-ka.png")
print(df.iloc[[0, 3, 5, 8, 12, 20]].round(3).to_string())
ka_hit = np.interp(an.GMR_CTROUGH[0], df.c3_ratio_model_b.values[::-1], df.ka_per_day.values[::-1])
print("ka at which model B reaches 1.67:", ka_hit)
