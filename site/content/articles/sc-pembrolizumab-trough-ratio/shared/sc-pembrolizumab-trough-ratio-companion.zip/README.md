# SC pembrolizumab trough ratio: companion code

Typical-patient calculation of the subcutaneous-to-intravenous trough ratio of pembrolizumab (790 mg vs 400 mg every 6 weeks).

- `analysis.py`: models A (one compartment) and B (two compartments with first-order absorption) and the result tables.
- `figures.py`: Figure 1 and the ka scan table.
- `test_analysis.py`: checks (run with `python -m pytest test_analysis.py`).
- `results/`: CSV outputs.

Inputs are published values (FDA label section 12.3, Felip et al. 2025, Ahamadi et al. 2017). No patient data are used. Requires Python 3 with numpy, scipy, pandas, matplotlib.
