import numpy as np
from scipy.integrate import solve_ivp

import analysis as an


def test_ka_reproduces_label_tmax():
    a = an.model_a()
    assert abs(an.tmax_one_comp(a["ka"], a["k"]) - an.TMAX_LABEL) < 1e-6


def test_steady_state_auc_ratio_is_dose_ratio_times_f():
    b = an.model_b_ratios(0.5, an.F_LABEL)
    assert abs(b["aucss"] - an.F_LABEL * an.DOSE_SC / an.DOSE_IV) < 1e-3
    assert abs(b["iv_auc_ss"] - an.DOSE_IV / an.AHAMADI["cl"]) < 1.0


def test_cycle1_auc_ratio_matches_ode():
    p, ka, f = an.AHAMADI, 0.4, an.F_LABEL

    def rhs_sc(t, y):
        c1, c2 = y[1] / p["v1"], y[2] / p["v2"]
        return [-ka * y[0], f * ka * y[0] - p["cl"] * c1 - p["q"] * (c1 - c2), p["q"] * (c1 - c2), c1]

    def rhs_iv(rate):
        def rhs(t, y):
            c1, c2 = y[0] / p["v1"], y[1] / p["v2"]
            return [rate - p["cl"] * c1 - p["q"] * (c1 - c2), p["q"] * (c1 - c2), c1]
        return rhs

    sc = solve_ivp(rhs_sc, (0, an.TAU), [an.DOSE_SC, 0, 0, 0], rtol=1e-10, atol=1e-12).y[3, -1]
    a = solve_ivp(rhs_iv(an.DOSE_IV / an.INFUSION), (0, an.INFUSION), [0, 0, 0], rtol=1e-10, atol=1e-12).y[:, -1]
    iv = solve_ivp(rhs_iv(0.0), (an.INFUSION, an.TAU), a, rtol=1e-10, atol=1e-12).y[2, -1]
    assert abs(sc / iv - an.model_b_ratios(ka, f)["auc1"]) < 1e-5
