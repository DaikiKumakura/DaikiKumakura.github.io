"""Can first-order absorption explain the trough ratio of subcutaneous vs intravenous pembrolizumab (MK-3475A-D77)?

Reported (Felip 2025; FDA label Keytruda Qlex section 12.3): SC 790 mg q6w vs IV 400 mg q6w, cycle-1 AUC0-6wk ratio 1.14,
cycle-3 Ctrough ratio 1.67; SC steady state AUC0-6wk 2798 ug*day/mL, Ctrough 39 ug/mL; bioavailability ~60%, peak by ~4 days,
V = 6 L, terminal half-life 22 days.
Model A: one-compartment with first-order absorption, parameters from the label only (ka solved from Tmax = 4 days).
Model B: two-compartment IV model of Ahamadi 2017 (typical values) plus a first-order depot, F from the label.
Closed-form or exact matrix-exponential solutions; no random effects.
"""
from pathlib import Path

import numpy as np
import pandas as pd
from scipy.linalg import expm
from scipy.optimize import brentq

ROOT = Path(__file__).resolve().parent
OUT = ROOT / "results"
OUT.mkdir(exist_ok=True)

TAU = 42.0
DOSE_IV, DOSE_SC = 400.0, 790.0
F_LABEL, TMAX_LABEL, HALF_LIFE, V_LABEL = 0.60, 4.0, 22.0, 6.0
GMR_AUC1 = (1.14, 1.06, 1.22)
GMR_CTROUGH = (1.67, 1.52, 1.84)
LABEL_SS = dict(auc_sc_q6w=2798.0, ctrough_sc_q6w=39.0)
INFUSION = 0.5 / 24
AHAMADI = dict(v1=3.48, v2=4.06, q=0.795, cl=0.22)
N_CYCLES = 14


def one_comp_sc(ka: float, k: float, dose: float, t: np.ndarray, n: int) -> np.ndarray:
    """Concentration (mg/L, V = 1 scaling applied later) after n repeated oral-type doses, superposition of single-dose profiles."""
    c = np.zeros_like(t)
    for i in range(n):
        tt = t - i * TAU
        m = tt > 0
        c[m] += dose * ka / (ka - k) * (np.exp(-k * tt[m]) - np.exp(-ka * tt[m]))
    return c


def tmax_one_comp(ka: float, k: float) -> float:
    return np.log(ka / k) / (ka - k)


def model_a() -> dict:
    k = np.log(2) / HALF_LIFE
    ka = brentq(lambda a: tmax_one_comp(a, k) - TMAX_LABEL, k * 1.01, 20.0)
    v = V_LABEL
    t = np.array([TAU * 3, TAU * N_CYCLES])
    sc = one_comp_sc(ka, k, F_LABEL * DOSE_SC, t, N_CYCLES) / v
    # IV: 30-minute infusion approximated as a bolus (effect on 6-week troughs is negligible)
    iv = np.array([sum(DOSE_IV * np.exp(-k * (tt - i * TAU)) for i in range(int(round(tt / TAU)))) for tt in t]) / v
    auc_sc_ss = F_LABEL * DOSE_SC / (k * v) * 1.0
    auc_iv_ss = DOSE_IV / (k * v)
    return dict(ka=ka, k=k, c3_ratio=sc[0] / iv[0], css_ratio=sc[1] / iv[1], aucss_ratio=auc_sc_ss / auc_iv_ss)


def model_b_ratios(ka: float, f: float) -> dict:
    p = AHAMADI
    a = np.array([[-ka, 0, 0, 0], [f * ka, -(p["cl"] + p["q"]) / p["v1"], p["q"] / p["v2"], 0],
                  [0, p["q"] / p["v1"], -p["q"] / p["v2"], 0], [0, 1 / p["v1"], 0, 0]])
    ai = a.copy(); ai[0, 0] = 0; ai[1, 0] = 0

    def prop(m, x, b, t):
        n = len(x); big = np.zeros((n + 1, n + 1)); big[:n, :n] = m; big[:n, n] = b
        return (expm(big * t) @ np.append(x, 1.0))[:n]

    xs, xi = np.zeros(4), np.zeros(4)
    res = []
    for _ in range(N_CYCLES):
        s0, i0 = xs[3], xi[3]
        xs = xs.copy(); xs[0] += DOSE_SC
        xs = prop(a, xs, np.zeros(4), TAU)
        xi = prop(ai, xi, np.array([0, DOSE_IV / INFUSION, 0, 0]), INFUSION)
        xi = prop(ai, xi, np.zeros(4), TAU - INFUSION)
        res.append((xs[1] / p["v1"], xi[1] / p["v1"], xs[3] - s0, xi[3] - i0))
    r = np.array(res)
    return dict(auc1=r[0, 2] / r[0, 3], c3=r[2, 0] / r[2, 1], css=r[-1, 0] / r[-1, 1], aucss=r[-1, 2] / r[-1, 3],
                sc_trough_ss=r[-1, 0], iv_trough_ss=r[-1, 1], sc_auc_ss=r[-1, 2], iv_auc_ss=r[-1, 3])


def tmax_model_b(ka: float, f: float = F_LABEL) -> float:
    """Time of the maximum central concentration after one SC dose in model B."""
    p = AHAMADI
    a = np.array([[-ka, 0, 0], [f * ka, -(p["cl"] + p["q"]) / p["v1"], p["q"] / p["v2"]], [0, p["q"] / p["v1"], -p["q"] / p["v2"]]])
    ts = np.linspace(0, TAU, 8401)
    cs = [(expm(a * t) @ np.array([DOSE_SC, 0, 0]))[1] for t in ts]
    return float(ts[int(np.argmax(cs))])


def c3_model_a(ka: float, k: float, f: float = F_LABEL) -> float:
    t = np.array([TAU * 3])
    sc = one_comp_sc(ka, k, f * DOSE_SC, t, 3)[0]
    iv = sum(DOSE_IV * np.exp(-k * (TAU * 3 - i * TAU)) for i in range(3))
    return sc / iv


def key_numbers() -> dict:
    k = np.log(2) / HALF_LIFE
    ka_a = brentq(lambda x: c3_model_a(x, k) - GMR_CTROUGH[0], 0.03, 2.0)
    ka_a_lo = brentq(lambda x: c3_model_a(x, k) - GMR_CTROUGH[1], 0.03, 2.0)
    ka_b = brentq(lambda x: model_b_ratios(x, F_LABEL)["c3"] - GMR_CTROUGH[0], 0.03, 2.0)
    ka_b_lo = brentq(lambda x: model_b_ratios(x, F_LABEL)["c3"] - GMR_CTROUGH[1], 0.03, 2.0)
    ka4_b = brentq(lambda x: tmax_model_b(x) - TMAX_LABEL, 0.1, 2.0)
    ka_lab = model_a()["ka"]
    return dict(ka_a_for_1p67=ka_a, tmax_a_at_that_ka=tmax_one_comp(ka_a, k), ka_a_for_1p52=ka_a_lo, tmax_a_for_1p52=tmax_one_comp(ka_a_lo, k),
                ka_b_for_1p67=ka_b, tmax_b_at_that_ka=tmax_model_b(ka_b), ka_b_for_1p52=ka_b_lo, tmax_b_for_1p52=tmax_model_b(ka_b_lo),
                tmax_b_at_ka_0p857=tmax_model_b(ka_lab), ka_b_for_4day_peak=ka4_b, c3_ratio_b_4day_peak=model_b_ratios(ka4_b, F_LABEL)["c3"],
                accumulation_model_a=1 / (1 - np.exp(-k * TAU)), accumulation_label=1.6,
                auc_label_cl195=F_LABEL * DOSE_SC / 0.195, auc_model_a=F_LABEL * DOSE_SC / (k * V_LABEL),
                c3_ratio_a_f070=c3_model_a(ka_lab, k, 0.70))


def main() -> None:
    a = model_a()
    print("Model A", a)
    # label-internal check: trough / average concentration at steady state (SC q6w)
    cavg = LABEL_SS["auc_sc_q6w"] / TAU
    label_ratio = LABEL_SS["ctrough_sc_q6w"] / cavg
    k, ka, v = a["k"], a["ka"], V_LABEL
    t = np.array([TAU * N_CYCLES])
    css_trough = one_comp_sc(ka, k, 1.0, t, N_CYCLES)[0]
    model_ratio = css_trough / (1.0 / (k * TAU))
    print("trough/avg label", label_ratio, "model A", model_ratio)
    rows = []
    for ka_b in (0.2, 0.3, 0.5, 1.0):
        rb = model_b_ratios(ka_b, F_LABEL)
        rows.append(dict(model="B", ka_per_day=ka_b, f=F_LABEL, **rb))
    pd.DataFrame(rows).round(4).to_csv(OUT / "model-b-scan.csv", index=False, lineterminator="\n")
    pd.set_option("display.width", 200)
    print(pd.DataFrame(rows).round(3).to_string())
    summary = dict(ka_a=a["ka"], c3_ratio_a=a["c3_ratio"], css_ratio_a=a["css_ratio"], aucss_ratio_a=a["aucss_ratio"],
                   label_trough_over_avg=label_ratio, model_a_trough_over_avg=model_ratio, reported_ctrough_ratio=GMR_CTROUGH[0])
    kn = key_numbers()
    pd.DataFrame([kn]).round(4).to_csv(OUT / "key-numbers.csv", index=False, lineterminator=chr(10))
    print(pd.DataFrame([kn]).round(3).T.to_string())
    pd.DataFrame([summary]).round(4).to_csv(OUT / "model-a-summary.csv", index=False, lineterminator="\n")


if __name__ == "__main__":
    main()
