# Predicting a soluble-mesothelin condition withheld from TCE fitting

New numerical reanalysis of Figure 4a, Snell et al., OncoImmunology (2023),
DOI:10.1080/2162402X.2023.2233401. The original source is CC BY-NC 4.0.
The source figure is retrieved through the original public archive; it is not
included in the public companion package. New plots are generated from the
experimental mean-marker readings with attribution, not from the source fit lines.

In an existing Python environment with the requirements.txt packages:

```sh
python analysis/download_sources.py
python analysis/run.py
python -m unittest discover -s tests
```

No installation is performed. Raw inputs are never overwritten. Marker x/y
coordinates and pixel-to-response calibration are inspectable in analysis/run.py.
The original figure is 800 by 533 pixels. Nominal concentrations are taken from
the original protocol: untreated plus ten fivefold dilutions, highest 50 nM.
The no-dose point is included in scoring but omitted from logarithmic plots.

Only H226 cells, E:T 30:1, 40 h LDH endpoint are analysed. C86 normal mesothelial
cell comparisons and antigen-density selection are not the subject of this work.
No experiments with other donors or targets are pooled. Source Figure 4a shows
means and SD from one representative experiment of at least two; its original
within-experiment replicate count is unspecified. This is not an individual-
donor dataset. Figure 4b summarizes EC50 across experiments and is not treated
as the same experimental curve or an independent held-out cohort.

The 0 and 50 ng/mL soluble-MSLN curves enter estimation. The complete 500 ng/mL
curve is withheld. A shared-baseline/amplitude/Hill model without soluble-antigen
effect is compared with EC50(S)=EC50(0)*(1+S/Kapp). Kapp is an empirical shift
scale, not an experimentally measured binding KD or clinical biomarker cutoff.
Separate condition-specific fits are descriptive diagnostics only.

One hundred fixed-seed marker-reading perturbations of +/-1.5 pixels are run
per molecule. They assess reading sensitivity with fixed axis calibration, not
biological uncertainty, replicate SD, parameter confidence or patient variability.
Neither the extrapolation nor the representative source figure is a prospective
blinded validation. No human dose, soluble-antigen threshold for patient selection
or regimen is inferred.

outputs/results.json and outputs/tables/results.json contain the same result
summary. Tables contain all source means, predictions, estimates and sensitivity
values. Public release files are explicitly listed in public-package-files.json.
