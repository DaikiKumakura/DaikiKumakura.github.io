"""Download an unchanged open figure used to read experimental mean markers."""
from pathlib import Path
from io import BytesIO
import hashlib
import urllib.request
import zipfile

ROOT=Path(__file__).resolve().parents[1]
URL="https://www.ebi.ac.uk/europepmc/webservices/rest/PMC10339761/supplementaryFiles"
MEMBER="KONI_A_2233401_F0004_OC.jpg"
SHA256="bd856cdf582f879b7cad43803a64e606bce19075a3993e49d46b639cff543cfd"


def main() -> None:
    path=ROOT/"data/raw"/MEMBER
    if not path.exists():
        path.parent.mkdir(parents=True,exist_ok=True)
        archive=zipfile.ZipFile(BytesIO(urllib.request.urlopen(URL,timeout=90).read()))
        payload=archive.read(next(n for n in archive.namelist() if n.endswith(MEMBER)))
        assert hashlib.sha256(payload).hexdigest()==SHA256
        with path.open("xb") as handle:handle.write(payload)
    assert hashlib.sha256(path.read_bytes()).hexdigest()==SHA256
    print("Verified the public source figure hash.")


if __name__=="__main__":main()
