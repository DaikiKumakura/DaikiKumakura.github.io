"""Estimate a soluble-antigen potency shift and predict a withheld assay condition."""
from pathlib import Path
import json,hashlib
import numpy as np
import pandas as pd
from scipy.optimize import least_squares
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

ROOT=Path(__file__).resolve().parents[1]
SEED=20261028
DOSES=np.r_[0.,50./5**np.arange(9,-1,-1)]
PIXELS={
 'NM28-2746':{
  0:{'x':[110,121,140,159,178,197,216,235,253,272,291],'y':[137,132,124.5,102,79,56,54,54,53,55,52],'zero':136.,'hundred':49.},
  50:{'x':[357,368,387,406,425,444,463,482,501,520,539],'y':[138,135,133,128,109,67,59,55,54,50,49],'zero':135.,'hundred':48.},
  500:{'x':[600,611,631,650,669,688,707,726,745,764,783],'y':[136,135,134,135,133,114,73,56,52,56,49],'zero':136.,'hundred':49.}},
 'NM28-1872':{
  0:{'x':[110,121,140,159,178,197,216,235,253,272,291],'y':[313,312,311,312,306,305,270,233,233,235,233],'zero':313.,'hundred':225.},
  50:{'x':[357,368,387,406,425,444,463,482,501,520,539],'y':[316,312,314,314,312,313,305,282,240,233,235],'zero':314.,'hundred':226.},
  500:{'x':[600,611,631,650,669,688,707,726,745,764,783],'y':[314,313,313,314,312,313,313,308,280,247,236],'zero':314.,'hundred':227.}}}

def response(c,s,p,model='shift'):
    b=p[0];e,k,h=np.exp(p[1:4])
    if model=='shift':k=k*(1+np.asarray(s)/np.exp(p[4]))
    c=np.asarray(c);out=np.zeros_like(c,dtype=float);positive=c>0
    out[positive]=1/(1+np.exp(np.clip(h*(np.log(np.broadcast_to(k,c.shape)[positive])-np.log(c[positive])),-700,700)))
    return b+e*out

def fit(c,s,y,model='shift'):
    lo=[-15.,np.log(1),np.log(1e-7),np.log(.1)];hi=[20.,np.log(150),np.log(1e3),np.log(6.)]
    starts=[[0.,np.log(95),np.log(.002),np.log(1.5)],[0.,np.log(95),np.log(.08),np.log(1.5)]]
    if model=='shift':lo+=[np.log(.001)];hi+=[np.log(1e8)];starts=[a+[np.log(10.)] for a in starts]
    r=min((least_squares(lambda p:response(c,s,p,model)-y,a,bounds=(lo,hi),max_nfev=700) for a in starts),key=lambda a:np.sum(a.fun**2))
    return r.x

def main():
    for d in ['data/processed','outputs/figures','outputs/tables']:(ROOT/d).mkdir(parents=True,exist_ok=True)
    records=[]
    for molecule,conditions in PIXELS.items():
        for soluble,p in conditions.items():
            for dose,px,py in zip(DOSES,p['x'],p['y']):records.append({'molecule':molecule,'cell_line':'H226','sMSLN_ng_ml':soluble,'TCE_nM':dose,'marker_x_px':px,'marker_y_px':py,'response_percent':100*(p['zero']-py)/(p['zero']-p['hundred']),'response_pp_per_pixel':100/(p['zero']-p['hundred']),'split':'held_out' if soluble==500 else 'training'})
    d=pd.DataFrame(records);d.to_csv(ROOT/'data/processed/observed-means.csv',index=False)
    assert len(d)==66 and not d.duplicated(['molecule','sMSLN_ng_ml','TCE_nM']).any() and d.cell_line.nunique()==1
    summaries=[];parameters=[];prediction=[];free=[];fitted={}
    for molecule in PIXELS:
        a=d.query('molecule==@molecule');c=a.TCE_nM.to_numpy();s=a.sMSLN_ng_ml.to_numpy();y=a.response_percent.to_numpy();train=s!=500
        for model in ['no_change','shift']:
            p=fit(c[train],s[train],y[train],model);pred=response(c,s,p,model);fitted[(molecule,model)]=p
            summaries.append({'molecule':molecule,'model':model,'n_training_means':22,'n_heldout_means':11,'training_RMSE_pp':float(np.sqrt(np.mean((pred[train]-y[train])**2))),'heldout_500_RMSE_pp':float(np.sqrt(np.mean((pred[~train]-y[~train])**2)))})
            parameters.append({'molecule':molecule,'model':model,'baseline_percent':p[0],'response_amplitude_percent':np.exp(p[1]),'EC50_0_nM':np.exp(p[2]),'Hill':np.exp(p[3]),'Kapp_ng_ml':np.exp(p[4]) if model=='shift' else None,'predicted_EC50_500_nM':np.exp(p[2])*(1+500/np.exp(p[4])) if model=='shift' else np.exp(p[2])})
            for record,estimate in zip(a.to_dict('records'),pred):prediction.append({**record,'model':model,'prediction_percent':estimate})
        for soluble in [0,50,500]:
            selected=s==soluble;p=fit(c[selected],np.zeros(11),y[selected],'no_change')
            free.append({'molecule':molecule,'sMSLN_ng_ml':soluble,'descriptive_EC50_nM':np.exp(p[2]),'baseline_percent':p[0],'amplitude_percent':np.exp(p[1]),'Hill':np.exp(p[3]),'role':'posthoc descriptive only; never enters heldout prediction'})
    pd.DataFrame(summaries).to_csv(ROOT/'outputs/tables/model-performance.csv',index=False)
    pd.DataFrame(parameters).to_csv(ROOT/'outputs/tables/model-parameters.csv',index=False)
    pd.DataFrame(prediction).to_csv(ROOT/'outputs/tables/predictions.csv',index=False)
    pd.DataFrame(free).to_csv(ROOT/'outputs/tables/descriptive-condition-fits.csv',index=False)
    rng=np.random.default_rng(SEED);sens=[]
    for molecule in PIXELS:
        a=d.query('molecule==@molecule');c=a.TCE_nM.to_numpy();s=a.sMSLN_ng_ml.to_numpy();y=a.response_percent.to_numpy();train=s!=500;scale=a.response_pp_per_pixel.to_numpy()
        for iteration in range(100):
            perturbed=y+rng.uniform(-1.5,1.5,len(a))*scale
            for model in ['no_change','shift']:
                p=fit(c[train],s[train],perturbed[train],model);prediction=response(c[~train],s[~train],p,model)
                sens.append({'molecule':molecule,'iteration':iteration,'model':model,'heldout_RMSE_pp':np.sqrt(np.mean((prediction-perturbed[~train])**2)),'Kapp_ng_ml':np.exp(p[4]) if model=='shift' else None})
    pd.DataFrame(sens).to_csv(ROOT/'outputs/tables/reading-sensitivity.csv',index=False)
    plt.rcParams.update({'font.size':10,'axes.spines.top':False,'axes.spines.right':False})
    fig,axs=plt.subplots(2,3,figsize=(12,6.5),layout='constrained');dense=np.geomspace(DOSES[1],50,250)
    for row,molecule in enumerate(PIXELS):
        for col,soluble in enumerate([0,50,500]):
            ax=axs[row,col];a=d.query('molecule==@molecule and sMSLN_ng_ml==@soluble');ax.scatter(a.TCE_nM.iloc[1:],a.response_percent.iloc[1:],color='#0072B2',s=22,label='Observed means')
            for model,color in [('no_change','#D55E00'),('shift','#009E73')]:ax.plot(dense,response(dense,np.full(250,soluble),fitted[(molecule,model)],model),color=color,label=model)
            ax.set(xscale='log',xlabel='TCE concentration (nM)',ylabel='LDH cytotoxicity (%)',title=f'{molecule}; sMSLN {soluble} ng/mL'+(' (held out)' if soluble==500 else ''),ylim=(-8,110));ax.legend(fontsize=7)
    fig.savefig(ROOT/'outputs/figures/soluble-antigen-forecast.png',dpi=180);fig.savefig(ROOT/'outputs/figures/soluble-antigen-forecast.svg');plt.close(fig)
    fig,axs=plt.subplots(1,2,figsize=(10,4),layout='constrained')
    for ax,molecule in zip(axs,PIXELS):
        p=fitted[(molecule,'shift')];ss=np.linspace(0,500,200);ax.plot(ss,np.exp(p[2])*(1+ss/np.exp(p[4]))*1000,color='#009E73',label='0/50 fit extrapolation')
        a=pd.DataFrame(free).query('molecule==@molecule');ax.scatter(a.sMSLN_ng_ml,a.descriptive_EC50_nM*1000,color='#0072B2',label='Descriptive curve fits');ax.set(xlabel='Soluble MSLN (ng/mL)',ylabel='EC50 (pM)',title=molecule);ax.legend(fontsize=8)
    fig.savefig(ROOT/'outputs/figures/potency-extrapolation.png',dpi=180);fig.savefig(ROOT/'outputs/figures/potency-extrapolation.svg');plt.close(fig)
    ranges=pd.DataFrame(sens).groupby(['molecule','model']).heldout_RMSE_pp.agg(['min','max']).reset_index();ranges.to_csv(ROOT/'outputs/tables/sensitivity-ranges.csv',index=False)
    potency_check=[]
    for molecule in PIXELS:
        p=next(p for p in parameters if p['molecule']==molecule and p['model']=='shift')
        observed=next(p['descriptive_EC50_nM'] for p in free if p['molecule']==molecule and p['sMSLN_ng_ml']==500)
        potency_check.append({'molecule':molecule,'predicted_EC50_500_nM':p['predicted_EC50_500_nM'],'descriptive_EC50_500_nM':observed,'prediction_over_descriptive_ratio':p['predicted_EC50_500_nM']/observed})
    result={'seed':SEED,'reading_sensitivity_draws_per_molecule':100,'observed_means':66,'training_means':44,'heldout_means':22,'source_grain':'mean markers from one representative experiment of at least two; original replicate count not given','performance':summaries,'parameters':parameters,'descriptive_fits':free,'potency_check':potency_check,'reading_sensitivity':ranges.to_dict('records'),'source_sha256':hashlib.sha256((ROOT/'data/raw/KONI_A_2233401_F0004_OC.jpg').read_bytes()).hexdigest()}
    for path in [ROOT/'outputs/tables/results.json',ROOT/'outputs/results.json']:
        path.write_text(json.dumps(result,indent=2),encoding='utf8')
    print(json.dumps(result,indent=2))

if __name__=='__main__':main()
