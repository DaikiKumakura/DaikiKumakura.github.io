from pathlib import Path
import importlib.util
import unittest
import numpy as np

ROOT=Path(__file__).resolve().parents[1]
spec=importlib.util.spec_from_file_location("msln_run",ROOT/"analysis/run.py")
run=importlib.util.module_from_spec(spec)
spec.loader.exec_module(run)


class AnalysisTests(unittest.TestCase):
    def test_protocol_doses_and_digitized_means(self):
        self.assertEqual(len(run.DOSES),11)
        self.assertEqual(run.DOSES[0],0)
        self.assertAlmostEqual(run.DOSES[-1],50)
        np.testing.assert_allclose(run.DOSES[2:]/run.DOSES[1:-1],5)
        self.assertEqual(sum(len(p['y']) for c in run.PIXELS.values() for p in c.values()),66)

    def test_untreated_equals_baseline(self):
        p=np.array([2,np.log(90),np.log(.02),np.log(1.5),np.log(10)])
        self.assertEqual(run.response(np.array([0.]),np.array([500.]),p)[0],2)

    def test_shifted_ec50_is_half_amplitude(self):
        p=np.array([2,np.log(90),np.log(.02),np.log(1.5),np.log(10)])
        s=np.array([0.,50.,500.]);ec50=.02*(1+s/10)
        np.testing.assert_allclose(run.response(ec50,s,p),47)

    def test_no_change_is_invariant_to_soluble_antigen(self):
        p=np.array([2,np.log(90),np.log(.02),np.log(1.5)])
        c=np.geomspace(.0001,50,11)
        np.testing.assert_allclose(run.response(c,np.zeros(11),p,'no_change'),run.response(c,np.ones(11)*500,p,'no_change'))

    def test_soluble_antigen_reduces_response_at_fixed_dose(self):
        p=np.array([0,np.log(90),np.log(.02),np.log(1.5),np.log(10)])
        values=run.response(np.ones(3)*.02,np.array([0.,50.,500.]),p)
        self.assertTrue(np.all(np.diff(values)<0))


if __name__=="__main__":unittest.main()
