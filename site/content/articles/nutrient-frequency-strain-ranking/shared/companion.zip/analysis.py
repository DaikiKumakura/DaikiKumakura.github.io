from math import cos, pi

def integrate(omega,tau):
    dt=2*pi/omega/4000
    memory=.5
    def mismatch_rate(t,m):
        return (.5+.25*cos(omega*t)-m)/tau
    accum=0
    periods=max(8,int(10*tau/(2*pi/omega))+2)
    for i in range(periods*4000):
        t=i*dt
        if i>=(periods-1)*4000:
            accum+=(memory-.5-.25*cos(omega*t))**2/4000
        a=mismatch_rate(t,memory)
        b=mismatch_rate(t+dt/2,memory+dt*a/2)
        c=mismatch_rate(t+dt/2,memory+dt*b/2)
        d=mismatch_rate(t+dt,memory+dt*c)
        memory+=dt*(a+2*b+2*c+d)/6
    return accum

for omega in (.5, 2., 8.):
    growth=[]
    for cost,tau in ((4,.25),(1,1)):
        squared=.25**2/2*(omega*tau)**2/(1+(omega*tau)**2)
        assert abs(squared-integrate(omega,tau))<1e-6
        growth.append(.5-cost*squared)
    print(omega, *(f"{x:.6f}" for x in growth))
