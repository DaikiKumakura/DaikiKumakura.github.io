"""Independent aggregate validation; participant rows are never printed."""
from pathlib import Path
import csv, json, math, statistics, hashlib
R=Path(__file__).resolve().parent
def read(name):
    with (R/'results'/name).open(newline='') as f:return list(csv.DictReader(f))
rows=read('heldout-private.csv'); grouped={}
for row in rows:grouped.setdefault(row['id'],[]).append(row)
assert len(grouped)==128 and all(len(v)==10 for v in grouped.values())
assert all(len({v['repeat_id'] for v in group})==10 for group in grouped.values())
people=[]
for group in grouped.values():
    people.append({k:statistics.mean(float(v[k]) for v in group) for k in ['time','state','lp0','lp1','p0','p1','G1','Gevent']})
assert sum(p['state'] for p in people)==101
def concordance(key):
    num=den=0
    for i,a in enumerate(people):
        for b in people[i+1:]:
            if a['time']==b['time']:
                if a['state']==b['state']:continue
                early,late=sorted([a,b],key=lambda p:-p['state'])
            else:early,late=sorted([a,b],key=lambda p:p['time'])
            if not early['state']:continue
            den+=1;num+=1 if early[key]>late[key] else .5 if early[key]==late[key] else 0
    return num/den
def brier(key):
    total=0
    for p in people:
        weight=1/p['G1'] if p['time']>1 else 1/p['Gevent'] if p['state'] else 0
        total+=weight*(int(p['time']>1)-p[key])**2
    return total/len(people)
primary=read('performance.csv')[1]; checked={}
for key,value in [('C0',concordance('lp0')),('C1',concordance('lp1')),('Brier0',brier('p0')),('Brier1',brier('p1'))]:
    assert abs(float(primary[key])-value)<1e-10,(key,value,primary[key]);checked[key]=value
assert all(0<=p[k]<=1 for p in people for k in ['p0','p1'])
assert all(p['time']>0 for p in people)
assert min(float(row['G1']) for row in rows)>.2
manifest=json.loads((R/'raw/source-manifest.json').read_text())
assert hashlib.sha256((R/'raw/frailtypack_3.8.1.tar.gz').read_bytes()).hexdigest()==manifest['sha256']
summary={'status':'passed','patients':128,'repeat_predictions':1280,'independently_recomputed':checked,'validation_scope':'Aggregate metrics and source identity; not clinical qualification'}
(R/'results/validation.json').write_text(json.dumps(summary,indent=2),encoding='utf-8')
print(json.dumps(summary,indent=2))
