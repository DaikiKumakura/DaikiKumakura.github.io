from pathlib import Path
import urllib.request,hashlib,json,tarfile
R=Path(__file__).resolve().parent;raw=R/'raw';url='https://cran.r-project.org/src/contrib/frailtypack_3.8.1.tar.gz';p=raw/'frailtypack_3.8.1.tar.gz';raw.mkdir(parents=True,exist_ok=True)
if not p.exists():p.write_bytes(urllib.request.urlopen(url,timeout=90).read())
assert hashlib.sha256(p.read_bytes()).hexdigest()=='b92677cee330815dfe3ad17606bc549b4fabf790840961d44fed292dabfada51','Pinned source bytes changed'
manifest={'url':url,'version':'3.8.1','sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'bytes':p.stat().st_size,'extracted':[]}
with tarfile.open(p)as t:
 for m in t.getmembers():
  if m.isfile()and (m.name.endswith('/DESCRIPTION')or any(m.name.endswith('/'+n)for n in ['colorectal.rda','colorectal.RData','colorectalLongi.rda','colorectalLongi.RData','colorectal.Rd','colorectalLongi.Rd'])):
   dest=raw/m.name.replace('/','__');data=t.extractfile(m).read();dest.write_bytes(data);manifest['extracted'].append({'file':dest.name,'sha256':hashlib.sha256(data).hexdigest()})
(raw/'source-manifest.json').write_text(json.dumps(manifest,indent=2));print(json.dumps(manifest,indent=2))
