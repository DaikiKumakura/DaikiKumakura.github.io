args<-commandArgs(FALSE); root<-dirname(normalizePath(sub('^--file=','',args[grep('^--file=',args)][1])))
library(survival)
set.seed(20261004)
l<-read.csv(file.path(root,'raw/colorectalLongi.csv')); s<-read.csv(file.path(root,'raw/colorectal.csv'))
end<-s[!duplicated(s$id,fromLast=TRUE),]; end<-s[order(s$id,s$time1),]; end<-end[!duplicated(end$id,fromLast=TRUE),]
make.data<-function(weeks=16,remove101=TRUE,floor=-10/3){
 L<-weeks/52.1775; ll<-l
 if(remove101)ll<-ll[ll$id!=101,] else ll<-ll[!(ll$id==101 & ll$year>1.14794520548),]
 b<-ll[ll$year==0,c('id','tumor.size')]; names(b)[2]<-'baseline'
 f<-ll[ll$year>0 & ll$year<=L,];f<-f[order(f$id,f$year),];f<-f[!duplicated(f$id,fromLast=TRUE),c('id','year','tumor.size')]
 names(f)[2:3]<-c('visit','early'); d<-merge(merge(end,b,by='id'),f,by='id');d<-d[d$time1>L,]
 d$floor<-d$early<=-3.33;d$early[d$floor]<-floor;d$change<-d$early-d$baseline;d$time<-d$time1-L
 d$arm<-as.numeric(d$treatment=='C');d$age<-factor(d$age,levels=c('<60 years','60-69 years','>69 years'));d$who<-as.numeric(d$who.PS!='0');d$resection<-as.numeric(d$prev.resection=='Yes');d
}
f0<-Surv(time,state)~arm+age+who+resection+baseline
f1<-update(f0,.~.+change+visit)
cind<-function(d,p){as.numeric(concordance(Surv(time,state)~p,data=d,reverse=TRUE)$concordance)}
g.at<-function(sf,t){idx<-findInterval(t,sf$time);c(1,sf$surv)[idx+1]}
brier<-function(d,p,g,h=1){G<-g.at(g,h); if(G<.2)return(NA_real_);w<-ifelse(d$time>h,1/G,ifelse(d$state==1,1/pmax(g.at(g,pmax(0,d$time-1e-9)),1e-8),0));y<-as.numeric(d$time>h);mean(w*(y-p)^2)}
fit.predict<-function(tr,te,formula){m<-coxph(formula,data=tr,x=TRUE);lp<-as.numeric(predict(m,newdata=te,type='lp',reference='zero'));bh<-basehaz(m,centered=FALSE);H<-if(any(bh$time<=1))tail(bh$hazard[bh$time<=1],1)else 0;list(lp=lp,surv=exp(-H*exp(lp)),model=m)}
cv<-function(d,repeats=10){
 set.seed(20261004)
 out<-list(); k<-1
 for(r in seq_len(repeats)){
 fold<-integer(nrow(d));for(e in 0:1){ii<-which(d$state==e);fold[ii]<-sample(rep(1:5,length.out=length(ii)))}
 for(j in 1:5){tr<-d[fold!=j,];te<-d[fold==j,];g<-survfit(Surv(time,1-state)~1,data=tr);a<-fit.predict(tr,te,f0);b<-fit.predict(tr,te,f1)
 out[[k]]<-data.frame(id=te$id,repeat_id=r,fold=j,time=te$time,state=te$state,lp0=a$lp,lp1=b$lp,p0=a$surv,p1=b$surv,G1=g.at(g,1),Gevent=g.at(g,pmax(0,te$time-1e-9)));k<-k+1
 }};do.call(rbind,out)
}
score<-function(o){a<-aggregate(cbind(lp0,lp1,p0,p1,G1,Gevent)~id+time+state,data=o,FUN=mean);w<-ifelse(a$time>1,1/a$G1,ifelse(a$state==1,1/pmax(a$Gevent,1e-8),0));y<-as.numeric(a$time>1); c(n=nrow(a),events=sum(a$state),C0=cind(a,a$lp0),C1=cind(a,a$lp1),Brier0=mean(w*(y-a$p0)^2),Brier1=mean(w*(y-a$p1)^2),min_training_G1=min(o$G1))}
d<-make.data();o<-cv(d);write.csv(o,file.path(root,'results/heldout-private.csv'),row.names=FALSE)
metrics<-data.frame(scenario=character()); rows<-list()
for(spec in list(c(12,1,-10/3),c(16,1,-10/3),c(24,1,-10/3),c(16,0,-10/3),c(16,1,-3.33))){dd<-make.data(spec[1],spec[2]==1,spec[3]);oo<-if(all(spec==c(16,1,-10/3)))o else cv(dd);rows[[length(rows)+1]]<-data.frame(scenario=paste(spec,collapse=':'),as.list(score(oo)))}
write.csv(do.call(rbind,rows),file.path(root,'results/performance.csv'),row.names=FALSE)
a<-aggregate(cbind(lp0,lp1,p0,p1,G1,Gevent)~id+time+state,data=o,FUN=mean)
boot<-replicate(1000,{bb<-a[sample(seq_len(nrow(a)),replace=TRUE),];w<-ifelse(bb$time>1,1/bb$G1,ifelse(bb$state==1,1/pmax(bb$Gevent,1e-8),0));y<-as.numeric(bb$time>1);c(delta_C=cind(bb,bb$lp1)-cind(bb,bb$lp0),delta_Brier=mean(w*((y-bb$p1)^2-(y-bb$p0)^2)))})
write.csv(data.frame(metric=rownames(boot),estimate=c(cind(a,a$lp1)-cind(a,a$lp0),score(o)['Brier1']-score(o)['Brier0']),lower=apply(boot,1,quantile,.025),upper=apply(boot,1,quantile,.975)),file.path(root,'results/paired-uncertainty.csv'),row.names=FALSE)
m0<-coxph(f0,data=d,x=TRUE);m1<-coxph(f1,data=d,x=TRUE)
capture.output({print(summary(m0));print(summary(m1));print(cox.zph(m0));print(cox.zph(m1));sessionInfo()},file=file.path(root,'results/model-diagnostics.txt'))
write.csv(data.frame(term=names(coef(m1)),logHR=coef(m1),se=sqrt(diag(vcov(m1)))),file.path(root,'results/coefficients.csv'),row.names=FALSE)
cal<-lapply(c('lp0','lp1'),function(v){ff<-as.formula(paste('Surv(time,state)~',v));m<-coxph(ff,data=a);data.frame(model=v,slope=coef(m)[1],lower=confint(m)[1],upper=confint(m)[2])});write.csv(do.call(rbind,cal),file.path(root,'results/calibration.csv'),row.names=FALSE)
png(file.path(root,'figures/heldout-performance.png'),width=1400,height=650,res=160);par(mfrow=c(1,2),mar=c(5,5,3,1));barplot(c(cind(a,a$lp0),cind(a,a$lp1)),names.arg=c('Clinical','Clinical + early change'),ylim=c(0,1),col=c('#9aaeb9','#246b80'),ylab='Held-out concordance',main='16-week landmark');barplot(c(score(o)['Brier0'],score(o)['Brier1']),names.arg=c('Clinical','Clinical + early change'),ylim=c(0,.3),col=c('#9aaeb9','#246b80'),ylab='1-year IPCW Brier (lower is better)',main='One-year probability scoring');dev.off()
png(file.path(root,'figures/heldout-calibration.png'),width=1000,height=750,res=160);plot(c(0,1),c(0,1),type='n',xlab='Mean held-out predicted 1-year survival',ylab='Kaplan–Meier 1-year survival',main='Conditional landmark cohort');abline(0,1,lty=2,col='grey');for(k in 0:1){p<-a[[paste0('p',k)]];group<-cut(p,quantile(p,seq(0,1,length.out=5)),include.lowest=TRUE);xx<-yy<-numeric();for(g in levels(group)){ii<-group==g;sf<-survfit(Surv(time,state)~1,data=a[ii,]);xx<-c(xx,mean(p[ii]));yy<-c(yy,summary(sf,times=1,extend=TRUE)$surv)};lines(xx,yy,type='b',pch=16,col=c('#9aaeb9','#246b80')[k+1])};legend('topleft',c('Clinical','Clinical + early change'),col=c('#9aaeb9','#246b80'),pch=16,bty='n');dev.off()
print(read.csv(file.path(root,'results/performance.csv')))
