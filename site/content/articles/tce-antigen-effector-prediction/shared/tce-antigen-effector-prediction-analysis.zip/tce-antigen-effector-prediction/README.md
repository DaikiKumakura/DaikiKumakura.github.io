# Antigen density and effector ratio in a 5T4 T-cell engager assay

Reanalysis of observed mean symbols from Yuan et al., The AAPS Journal (2026),
DOI https://doi.org/10.1208/s12248-026-01259-2 .

The source is licensed CC BY 4.0: https://creativecommons.org/licenses/by/4.0/ .
The numerical coordinates are a manual digitization/adaptation, not author-supplied
individual observations. Source fitted lines were not digitized as observations.
No BioRender model diagrams are reproduced.

Python dependencies follow the existing workspace Python analysis stack;
no new package installation or environment manager is needed in that workspace.
For another machine, use an isolated Python environment with requirements.txt.

Run from this directory:

```sh
python analysis/download_sources.py
python analysis/digitize.py
python analysis/run.py
python -m unittest discover -s tests
```

The download script preserves existing raw files and verifies the supplementary
PDF hash. Figure 6 is resized to width 1600 for recorded manual coordinates;
S10 coordinates refer to original embedded raster pixels. `verification/*readback.png`
allows inspection. Two possible low-dose blue markers obscured by other series
are excluded; see data/processed/exclusions.csv. The raw source PDFs remain
available at the official URLs; the full supplement is not bundled.

S10: 166 digitized observed symbols, 14 cell lines, E:T 4:1, 72 hours.
Figure 6: 43 digitized symbols, one cell line at four E:T ratios, 72 hours.
These are separate prediction tests; repeated 4:1 observations are never pooled.
Antigen measurements may enter a held-out cell-line prediction, but its killing
measurements and response-defined original cell-line clusters do not.

Results and all folds are under outputs/. The cell-line resampling range is a
descriptive stability check across this fixed panel, not a validated population
confidence interval. Pixel jitter is reading sensitivity, not biological uncertainty.
No claim is made about clinical dose selection, DLL3 validation, independent donor
validation, or superiority over the published QSP model.
