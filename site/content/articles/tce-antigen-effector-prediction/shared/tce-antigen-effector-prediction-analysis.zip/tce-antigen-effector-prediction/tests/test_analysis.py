from pathlib import Path
import sys,unittest,csv
import numpy as np
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'src'))
sys.path.insert(0,str(ROOT/'analysis'))
from models import predict,fit,cross_validate
from digitize import convert,PANELS

class AnalysisTests(unittest.TestCase):
    def test_axis_calibration(self):
        for cfg in PANELS.values():
            self.assertAlmostEqual(convert(cfg['xref'],cfg['yref'],cfg)[0],1e-4)
            self.assertAlmostEqual(convert(cfg['xref2'],cfg['yref2'],cfg)[0],.1)
            self.assertAlmostEqual(convert(cfg['xref2'],cfg['yref2'],cfg)[1],100)
    def test_held_out_response_cannot_change_own_prediction(self):
        c=np.tile(np.geomspace(.0001,10,9),4);g=np.repeat(['a','b','c','d'],9);x=np.repeat([.6,.9,1.2,1.6],9)
        y=predict(np.array([-2.,0.,2.,-.5]),c,x,'potency')
        first,_=cross_validate(c,x,y,g,'potency')
        altered=y.copy();altered[g=='c']+=20
        second,_=cross_validate(c,x,altered,g,'potency')
        np.testing.assert_allclose(first[g=='c'],second[g=='c'],rtol=0,atol=0)
    def test_equal_group_weight_duplicate_invariance(self):
        c=np.tile(np.geomspace(.001,10,8),2);g=np.repeat(['a','b'],8);x=np.ones(16);y=np.r_[np.linspace(0,90,8),np.linspace(0,45,8)]
        t=fit(c,x,y,g,'shared');idx=np.r_[np.arange(16),np.arange(8)]
        tt=fit(c[idx],x[idx],y[idx],g[idx],'shared')
        np.testing.assert_allclose(predict(t,c,x,'shared'),predict(tt,c,x,'shared'),atol=.001)
    def test_response_bounds_and_monotonicity(self):
        c=np.geomspace(1e-8,1e4,100)
        y=predict(np.array([-3.,.2,2.,-1.,.3]),c,np.ones(100),'both')
        self.assertTrue(np.all((y>=0)&(y<=100)));self.assertTrue(np.all(np.diff(y)>=0))
    def test_data_units_and_distinct_datasets(self):
        with (ROOT/'data/processed/s10-points.csv').open() as f:a=list(csv.DictReader(f))
        with (ROOT/'data/processed/et-points.csv').open() as f:b=list(csv.DictReader(f))
        self.assertEqual(len(a),166);self.assertEqual(len({r['cell_line'] for r in a}),14)
        self.assertEqual({r['et'] for r in a},{'4'});self.assertEqual({r['cell_line'] for r in b},{'MDA-MB-468'})
        self.assertEqual(len({r['point_id'] for r in a}),len(a))
    def test_no_outcome_defined_groups(self):
        text=(ROOT/'src/models.py').read_text()
        self.assertNotIn('Cell_Line_group',text)

if __name__=='__main__':unittest.main()
