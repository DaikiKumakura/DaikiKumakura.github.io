"""Run grouped prediction tests and digitization sensitivity; no replicate inference."""
from pathlib import Path
import sys,csv,json
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from scipy.stats import spearmanr
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'src'))
from models import fit,predict,cross_validate,ANTIGEN_REF
SEED=2026102606
N_SENSITIVITY=32
MODELS=['shared','potency','both']
COLORS=['#555555','#0072B2','#D55E00']
OUT=ROOT/'outputs'
for d in ['tables','figures']: (OUT/d).mkdir(parents=True,exist_ok=True)

def read(name):
    with (ROOT/'data/processed'/name).open(encoding='utf-8') as f: return list(csv.DictReader(f))
def write(name,rows):
    with (OUT/'tables'/name).open('w',newline='',encoding='utf-8') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
def array(rows,key): return np.array([float(r[key]) for r in rows])
def macro(records): return float(np.mean([r['rmse'] for r in records]))

def main():
    data=read('s10-points.csv');et=read('et-points.csv')
    c=array(data,'concentration_nm'); y=array(data,'killing_pct'); x=array(data,'antigen')/ANTIGEN_REF
    groups=np.array([r['cell_line'] for r in data])
    assert len(set(groups))==14 and len(set(array(data,'et')))==1
    records=[];predictions=[];summary=[];allpred={};allrec={}
    for model in MODELS:
        p,rec=cross_validate(c,x,y,groups,model);allpred[model]=p;allrec[model]=rec
        records.extend(rec)
        summary.append(dict(dataset='cell_line',model=model,groups=14,points=len(data),macro_rmse=macro(rec),macro_mae=float(np.mean([r['mae'] for r in rec]))))
        for row,yp in zip(data,p): predictions.append({**row,'model':model,'predicted_pct':yp})
    write('cell-line-predictions.csv',predictions)
    write('cell-line-errors.csv',[{k:v for k,v in r.items() if k!='parameters'} for r in records])
    # Each curve is weighted once in the paired descriptive contrast. Resampling
    # cell lines is not a clinical population CI or an independent external cohort.
    rng=np.random.default_rng(SEED)
    paired=[]
    for model in MODELS[1:]:
        difference=np.array([r['rmse'] for r in allrec[model]])-np.array([r['rmse'] for r in allrec['shared']])
        boot=np.mean(rng.choice(difference,(10000,len(difference))),axis=1)
        paired.append(dict(model=model,mean_rmse_difference=float(difference.mean()),
            bootstrap_lower=float(np.quantile(boot,.025)),bootstrap_upper=float(np.quantile(boot,.975)),
            better_lines=int(np.sum(difference<0)),lines=14))
    write('paired-errors.csv',paired)
    # Refit all grouped folds after bounded independent center perturbation.
    sensitivity={m:[] for m in MODELS}
    for _ in range(N_SENSITIVITY):
        dx=rng.uniform(-2,2,len(data));dy=rng.uniform(-2,2,len(data))
        cc=c*10**(3*dx/(array(data,'xref2')-array(data,'xref')))
        yy=y-100*dy/(array(data,'yref')-array(data,'yref2'))
        for model in MODELS:
            _,rec=cross_validate(cc,x,yy,groups,model);sensitivity[model].append(macro(rec))
    sens=[dict(model=m,draws=N_SENSITIVITY,pixel_bound=2,min_macro_rmse=min(v),max_macro_rmse=max(v)) for m,v in sensitivity.items()]
    write('digitization-sensitivity.csv',sens)
    # E:T is a separate, single-cell-line leave-one-ratio-out test. Do not pool
    # the 4:1 curve from S10 with the same observations in Figure 6.
    ec=array(et,'concentration_nm');ey=array(et,'killing_pct');ex=array(et,'et')/4
    eg=np.array([r['et'] for r in et]);er=[];ep={}
    for model in ['shared','potency']:
        yp,rec=cross_validate(ec,ex,ey,eg,model);ep[model]=yp;er.extend(rec)
        summary.append(dict(dataset='et_ratio',model=model,groups=4,points=len(et),macro_rmse=macro(rec),macro_mae=float(np.mean([r['mae'] for r in rec]))))
    write('et-errors.csv',[{k:v for k,v in r.items() if k!='parameters'} for r in er])
    write('model-comparison.csv',summary)
    # Descriptive curve fits use the whole cell line and are never hold-out
    # predictions. They show why antigen density alone can be insufficient.
    fitted=[]
    for g in np.unique(groups):
        mask=groups==g;t=fit(c[mask],x[mask],y[mask],groups[mask],'shared')
        fitted.append(dict(cell_line=g,antigen=float(array(data,'antigen')[mask][0]),ec50_nm=float(np.exp(t[0])),
            emax_pct=float(100/(1+np.exp(-t[2]))),hill=float(np.exp(t[1]))))
    write('descriptive-curve-fits.csv',fitted)
    rho=spearmanr([r['antigen'] for r in fitted],[r['emax_pct'] for r in fitted]).statistic
    results=dict(seed=SEED,cell_line_points=len(data),et_points=len(et),model_comparison=summary,paired_errors=paired,
        sensitivity=sens,descriptive_spearman_antigen_emax=float(rho),
        limitations=['Digitized published mean symbols, no biological replicate values',
        'Grouped internal validation, not independent external validation',
        'No refit of published QSP; no QSP superiority comparison',
        'E:T validation is one cell line only; no DLL3 or clinical-dose extrapolation'])
    (OUT/'results.json').write_text(json.dumps(results,indent=2)+'\n',encoding='utf-8')
    (OUT/'fold-parameters.json').write_text(json.dumps(records+er,indent=2)+'\n',encoding='utf-8')
    plt.rcParams.update({'font.size':10,'axes.spines.top':False,'axes.spines.right':False,'svg.fonttype':'none'})
    fig,axes=plt.subplots(2,2,figsize=(10,7.5),layout='constrained')
    for ax,g in zip(axes.flat,['FaDu','SW780','SCC-9','DU 145']):
        mask=groups==g;idx=np.argsort(c[mask]);ax.scatter(c[mask],y[mask],color='black',s=23,label='Observed mean (digitized)',zorder=4)
        grid=np.geomspace(c[mask].min(),c[mask].max(),160)
        for m,color in zip(MODELS,COLORS):
            theta=next(r['parameters'] for r in allrec[m] if r['held_out']==g)
            ax.plot(grid,predict(theta,grid,np.repeat(x[mask][0],len(grid)),m),color=color,label=m)
        ax.set(xscale='log',ylim=(-5,105),xlabel='Concentration (nM)',ylabel='Tumor killing (%)',title=f'{g} | held out; E:T 4:1')
    axes[0,0].legend(fontsize=8)
    save(fig,'01-held-out-curves')
    fig,axes=plt.subplots(1,2,figsize=(11,5.5),layout='constrained')
    names=np.unique(groups);pos=np.arange(len(names))
    for i,(m,color) in enumerate(zip(MODELS,COLORS)):
        axes[0].scatter([r['rmse'] for r in allrec[m]],pos+(i-1)*.2,color=color,label=m,s=25)
    axes[0].set(yticks=pos,yticklabels=names,xlabel='Held-out RMSE (percentage points)',title='14 cell-line folds')
    axes[0].legend(fontsize=8)
    axes[1].scatter([r['antigen'] for r in fitted],[r['emax_pct'] for r in fitted],color='#0072B2')
    for r in fitted:
        if r['cell_line'] in ['SCC-9','SW780','PC-3','SK-GT-4']:axes[1].annotate(r['cell_line'],(r['antigen'],r['emax_pct']),xytext=(4,-10),textcoords='offset points',fontsize=8)
    axes[1].set(xlabel='5T4 (molecules/cell)',ylabel='Descriptive fitted maximum killing (%)',ylim=(0,105),title='In-sample curve fits; not predictions')
    save(fig,'02-line-errors-antigen')
    fig,axes=plt.subplots(2,2,figsize=(10,7.5),layout='constrained')
    for ax,g in zip(axes.flat,['1','2','4','8']):
        mask=eg==g;idx=np.argsort(ec[mask]);ax.scatter(ec[mask],ey[mask],color='black',s=25,label='Observed mean (digitized)')
        grid=np.geomspace(ec[mask].min(),ec[mask].max(),160)
        for m,color in zip(['shared','potency'],COLORS):
            theta=next(r['parameters'] for r in er if r['held_out']==g and r['model']==m)
            ax.plot(grid,predict(theta,grid,np.repeat(ex[mask][0],len(grid)),m),label=m,color=color)
        ax.set(xscale='log',ylim=(-5,105),xlabel='Concentration (nM)',ylabel='Tumor killing (%)',title=f'MDA-MB-468 | held-out E:T {g}:1')
    axes[0,0].legend(fontsize=8)
    save(fig,'03-held-out-et')
    print(json.dumps(results,indent=2))

def save(fig,name):
    for ext in ['png','svg']:
        path=OUT/'figures'/f'{name}.{ext}'
        fig.savefig(path,dpi=180)
        if ext=='svg':
            path.write_text('\n'.join(s.rstrip() for s in path.read_text(encoding='utf-8').splitlines())+'\n',encoding='utf-8')
    plt.close(fig)
if __name__=='__main__': main()
