"""Convert manually identified observed-symbol centers, not fitted lines, to data."""
from pathlib import Path
import csv
import json
import hashlib
import pymupdf
from PIL import Image, ImageDraw

ROOT = Path(__file__).resolve().parents[1]
RAW = ROOT / 'data/raw'
OUT = ROOT / 'data/processed'
OUT.mkdir(parents=True, exist_ok=True)
CHECK = ROOT / 'verification'
CHECK.mkdir(exist_ok=True)
# Coordinates refer to embedded raster pixels. Axis calibration uses tick marks.
# x_ref=1e-4, x_ref2=1e-1; y_ref=0%, y_ref2=100%.
PANELS = {
    'low': dict(xref=240, xref2=448, yref=413, yref2=22, xrefpdf=120),
    'medium': dict(xref=238, xref2=447, yref=402, yref2=11, xrefpdf=121),
    'high': dict(xref=244, xref2=458, yref=423, yref2=22, xrefpdf=122),
}
# Identifiable observed-marker centers were entered, including low-dose scatter.
# Two possible blue centers in S10 high at x~341-348,y~390-399 are obscured by
# other series and excluded rather than guessed. See exclusions.csv.
# Overlapping symbols can obscure centers: the sensitivity is +/-2 px.
# The original figures do not expose biological replicate values.
POINTS = {
 'SiHa': ('low',9447,[(186,402),(235,400),(242,405),(290,386),(338,380),(381,394),(388,358),(435,364),(478,258),(484,172),(526,145),(533,94),(575,129),(582,68),(624,107),(630,65)]),
 'BxPC-3': ('low',12398,[(235,413),(242,372),(284,413),(291,411),(332,405),(339,398),(381,413),(429,413),(435,357),(478,413),(485,257),(526,329),(533,157),(575,184),(582,105),(624,100)]),
 'MDA-MB-231': ('low',13524,[(186,403),(235,378),(284,377),(332,377),(381,380),(429,339),(478,181),(526,64),(575,57),(624,40)]),
 'PANC-1': ('low',16500,[(186,402),(235,395),(242,399),(284,396),(291,386),(332,390),(339,354),(381,287),(388,228),(429,171),(436,54),(478,94),(485,29),(533,33),(575,66),(582,34),(624,92),(630,34)]),
 'FaDu': ('low',17925,[(235,388),(284,379),(332,352),(381,372),(429,302),(478,88),(526,48),(575,34),(624,33)]),
 'EPLC272H': ('medium',20106,[(185,402),(234,402),(283,402),(331,400),(380,398),(428,341),(477,126),(526,67),(574,53),(623,21)]),
 'SW780': ('medium',21775,[(234,326),(234,402),(283,402),(331,402),(380,402),(428,402),(477,374),(526,264),(574,166),(623,166)]),
 'Ca Ski': ('medium',22629,[(234,384),(241,372),(289,373),(338,372),(386,380),(428,331),(435,321),(477,225),(484,250),(526,158),(533,148),(574,149),(581,106),(623,141),(630,127)]),
 'RT-112': ('medium',23917,[(185,393),(234,399),(283,398),(331,396),(380,398),(428,365),(477,148),(526,53),(574,43),(623,43)]),
 'MDA-MB-468': ('high',31582,[(192,421),(242,410),(292,421),(390,364),(397,309),(440,246),(447,28),(490,107),(497,66),(547,54),(590,63),(640,22),(647,58)]),
 'PC-3': ('high',35800,[(242,422),(291,416),(341,390),(390,303),(440,86),(490,47),(540,43),(590,48),(640,42)]),
 'SCC-9': ('high',36102,[(192,401),(242,415),(291,409),(341,408),(390,410),(440,407),(490,364),(540,310),(590,290),(640,282)]),
 'SK-GT-4': ('high',55545,[(242,417),(291,421),(341,394),(390,342),(440,176),(490,46),(540,28),(590,25),(640,29)]),
 'DU 145': ('high',61686,[(142,380),(192,396),(242,390),(292,395),(341,248),(390,202),(440,134),(490,79),(540,69),(590,85),(640,53)]),
}
# Figure 6 coordinates use the original image rescaled to exactly 1600 pixels
# wide for manual reading. The scaling is recorded and reproduced below.
ET = {
 1: dict(xref=280,xref2=512,yref=661,yref2=110,points=[(276,661),(330,661),(384,661),(438,661),(491,439),(546,182),(599,134),(653,122)]),
 2: dict(xref=1102,xref2=1334,yref=663,yref2=121,points=[(1097,663),(1151,663),(1205,663),(1259,663),(1313,261),(1367,137),(1421,143),(1475,153)]),
 4: dict(xref=276,xref2=508,yref=1438,yref2=894,points=[(216,1434),(270,1418),(278,1438),(325,1414),(332,1438),(379,1401),(387,1393),(434,1358),(441,1239),(488,1197),(496,902),(543,1010),(550,953),(598,915),(605,937),(652,908),(659,948),(706,894),(713,943)]),
 8: dict(xref=1099,xref2=1334,yref=1444,yref2=897,points=[(1094,1444),(1149,1444),(1204,1407),(1258,1353),(1313,953),(1368,918),(1423,913),(1478,919)]),
}

def convert(x: float, y: float, cfg: dict) -> tuple[float,float]:
    logc = -4 + 3*(x-cfg['xref'])/(cfg['xref2']-cfg['xref'])
    killing = 100*(cfg['yref']-y)/(cfg['yref']-cfg['yref2'])
    return 10**logc, killing

def main() -> None:
    doc = pymupdf.open(RAW/'supplement.pdf')
    rows = []
    for panel,cfg in PANELS.items():
        im = doc.extract_image(cfg['xrefpdf'])
        target = CHECK/f's10-{panel}.png'
        target.write_bytes(im['image'])
        image = Image.open(target).convert('RGB'); draw = ImageDraw.Draw(image)
        for name,(group,antigen,points) in POINTS.items():
            if group != panel: continue
            for i,(x,y) in enumerate(points):
                c,k=convert(x,y,cfg)
                rows.append(dict(source='S10',panel=panel,cell_line=name,antigen=antigen,et=4,time_h=72,cd3_kd_nm=683,
                    point_id=f'{name}-{i+1}',x_px=x,y_px=y,concentration_nm=c,killing_pct=k,
                    xref=cfg['xref'],xref2=cfg['xref2'],yref=cfg['yref'],yref2=cfg['yref2']))
                draw.rectangle((x-6,y-6,x+6,y+6),outline='black',width=1)
        image.save(CHECK/f's10-{panel}-readback.png')
    write_csv(OUT/'s10-points.csv',rows)
    rows=[]
    image=Image.open(RAW/'figure6.png').convert('RGB')
    image=image.resize((1600,round(image.height*1600/image.width)))
    draw=ImageDraw.Draw(image)
    for ratio,cfg in ET.items():
        for i,(x,y) in enumerate(cfg['points']):
            c,k=convert(x,y,cfg)
            rows.append(dict(source='Figure6',panel=str(ratio),cell_line='MDA-MB-468',antigen=31582,et=ratio,time_h=72,cd3_kd_nm=683,
                point_id=f'ET{ratio}-{i+1}',x_px=x,y_px=y,concentration_nm=c,killing_pct=k,
                xref=cfg['xref'],xref2=cfg['xref2'],yref=cfg['yref'],yref2=cfg['yref2']))
            draw.rectangle((x-10,y-10,x+10,y+10),outline='black',width=2)
    image.save(CHECK/'figure6-readback.png')
    write_csv(OUT/'et-points.csv',rows)
    write_csv(OUT/'exclusions.csv',[dict(source='S10 high',cell_line='MDA-MB-468',
        candidate_markers='two possible low-concentration symbols',region_px='x341-348 y390-399',
        reason='Overlap with other series prevents reliable center identification; no inferred observations added')])
    audit=dict(s10_points=sum(len(v[2]) for v in POINTS.values()),cell_lines=len(POINTS),et_points=len(rows),
        biological_replicates_available=False,readout='published observed symbols, not QSP curves',
        sensitivity_px=2,source_pdf_sha256=hashlib.sha256((RAW/'supplement.pdf').read_bytes()).hexdigest())
    (OUT/'digitization.json').write_text(json.dumps(audit,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(audit))

def write_csv(path: Path, rows: list[dict]) -> None:
    with path.open('w',newline='',encoding='utf-8') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)

if __name__ == '__main__': main()
