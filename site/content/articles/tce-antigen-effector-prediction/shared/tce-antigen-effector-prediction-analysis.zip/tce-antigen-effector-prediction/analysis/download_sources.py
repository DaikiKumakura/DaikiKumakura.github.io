"""Fetch authorized open source material; never overwrite raw observations."""
from pathlib import Path
import urllib.request,hashlib
ROOT=Path(__file__).resolve().parents[1]
URLS={
 'supplement.pdf':'https://media.springernature.com/original/springer-static/esm/art%3A10.1208%2Fs12248-026-01259-2/MediaObjects/12248_2026_1259_MOESM1_ESM.pdf',
 'figure6.png':'https://media.springernature.com/full/springer-static/image/art%3A10.1208%2Fs12248-026-01259-2/MediaObjects/12248_2026_1259_Fig6_HTML.png',
}
def main():
    raw=ROOT/'data/raw';raw.mkdir(parents=True,exist_ok=True)
    for name,url in URLS.items():
        path=raw/name
        if not path.exists():
            data=urllib.request.urlopen(url,timeout=60).read()
            assert data.startswith(b'%PDF') if name.endswith('.pdf') else data.startswith(b'\x89PNG')
            path.write_bytes(data)
        if name=='supplement.pdf':
            assert hashlib.sha256(path.read_bytes()).hexdigest()=='298d27cea8703ccef86cbecccb43e85f02b76f6d7e03c0a16417bfc872239c70'
        print(name,hashlib.sha256(path.read_bytes()).hexdigest())
if __name__=='__main__':main()
