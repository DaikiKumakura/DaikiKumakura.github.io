"""Small empirical models fitted only to training cell lines or E:T ratios."""
import numpy as np
from scipy.optimize import least_squares
from scipy.special import expit

ANTIGEN_REF = 25000.

def predict(theta: np.ndarray, concentration: np.ndarray, covariate: np.ndarray, model: str) -> np.ndarray:
    logec, logh, logitmax = theta[:3]
    z = np.log(covariate)
    if model in {'potency','both'}: logec = logec + theta[3]*z
    if model == 'both': logitmax = logitmax + theta[4]*z
    maxeff = 100*expit(logitmax)
    return maxeff*expit(np.exp(logh)*(np.log(concentration)-logec))

def fit(c: np.ndarray, x: np.ndarray, y: np.ndarray, group: np.ndarray, model: str) -> np.ndarray:
    # Equal total squared-error weight per cell line (or per E:T ratio).
    counts = {g:np.sum(group==g) for g in np.unique(group)}
    weights = np.array([1/np.sqrt(counts[g]) for g in group])
    start = [np.log(.03),np.log(1.3),2.2]
    lo = [-18.,np.log(.2),-7.]
    hi = [8.,np.log(8.),10.]
    if model in {'potency','both'}:
        start += [0.];lo += [-5.];hi += [5.]
    if model=='both':
        start += [0.];lo += [-5.];hi += [5.]
    result = least_squares(lambda t: weights*(predict(t,c,x,model)-y), start,
                           bounds=(lo,hi),max_nfev=1500,ftol=1e-9,xtol=1e-9,gtol=1e-9)
    if not result.success: raise RuntimeError(result.message)
    return result.x

def cross_validate(c: np.ndarray,x: np.ndarray,y: np.ndarray,group: np.ndarray,model: str) -> tuple[np.ndarray,list[dict]]:
    out=np.full(len(y),np.nan);records=[]
    for held in np.unique(group):
        train=group!=held; test=~train
        assert set(group[train]).isdisjoint(set(group[test]))
        theta=fit(c[train],x[train],y[train],group[train],model)
        out[test]=predict(theta,c[test],x[test],model)
        records.append(dict(held_out=str(held),training_groups=len(np.unique(group[train])),
            model=model,rmse=float(np.sqrt(np.mean((out[test]-y[test])**2))),
            mae=float(np.mean(abs(out[test]-y[test]))),parameters=theta.tolist()))
    assert np.isfinite(out).all()
    return out,records
