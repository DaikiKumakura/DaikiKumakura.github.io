"""Fetch pinned public audit inputs; never download/run model checkpoints."""
from pathlib import Path
import hashlib,json,urllib.request
P=Path(__file__).resolve().parent
def main():
    manifest=json.loads((P/'input-provenance.json').read_text(encoding='utf-8'))
    root=P/'sources';root.mkdir(exist_ok=True)
    for r in manifest['records']:
        out=(root/r['file']).resolve()
        if not out.is_relative_to(root.resolve()):raise ValueError('path outside sources')
        out.parent.mkdir(parents=True,exist_ok=True)
        if not out.exists():
            with urllib.request.urlopen(r['url'],timeout=120) as f:out.write_bytes(f.read())
        if out.stat().st_size!=r['bytes'] or hashlib.sha256(out.read_bytes()).hexdigest()!=r['sha256']:raise ValueError('source hash mismatch: '+r['file'])
        print('verified',r['file'])
if __name__=='__main__':main()
