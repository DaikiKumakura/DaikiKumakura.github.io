"""Own figures; source-score audit and a synthetic ranking counterexample."""
from pathlib import Path
import csv
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from analysis import ap_sequence
P=Path(__file__).resolve().parent
F=P/'figures';F.mkdir(exist_ok=True)
rows=list(csv.DictReader((P/'results/audited-pairs.csv').open()))
fig,axs=plt.subplots(3,1,figsize=(7.2,10.6),sharex=True,sharey=True)
colors=dict(hepg2='#337e89',jurkat='#be7541',k562='#75659a',rpe1='#578446')
for ax,s,title in zip(axs,['unseen_ctx','unseen_pert','unseen_ctx_pert'],['Unseen context','Unseen perturbation','Both unseen']):
    for f,c in colors.items():
        a=[r for r in rows if r['setting']==s and r['fold']==f and int(r['de_genes'])>0]
        ax.scatter([float(r['prevalence']) for r in a],[float(r['reported_ap']) for r in a],s=5,alpha=.24,color=c,label=f)
    x=np.geomspace(1/6642,1,200);ax.plot(x,x,'--',c='#333333',lw=.9)
    ax.set_xscale('log');ax.set_yscale('log');ax.set_xlim(1e-4,1);ax.set_ylim(1e-4,1);ax.set_title(title);ax.set_xlabel('DE prevalence among 6,642 tested genes');ax.grid(alpha=.15)
for ax in axs: ax.set_ylabel('Released AP (AUPRC)')
axs[2].legend(markerscale=2,fontsize=8,loc='lower right')
fig.text(.5,.02,'One dot = one fold/context/perturbation score. Zero-DE rows omitted.\nRepeated pairs are not independent. Dashed: AP = prevalence.',ha='center',fontsize=8)
fig.tight_layout(rect=(0,.07,1,1));fig.savefig(F/'01-ap-and-prevalence.png',dpi=160);plt.close(fig)
fig,axs=plt.subplots(2,1,figsize=(8.6,4.2),sharex=True)
for ax,labels,name in zip(axs,[[0,0,1,0,0,0,0,1],[0,0,0,1,0,1,0,0]],['Ranking A','Ranking B']):
    x=np.arange(1,9);ax.bar(x,np.ones(8),color=['#337e89' if v else '#dddddd' for v in labels],width=.72)
    ax.axvspan(.5,3.5,color='#be7541',alpha=.12);ax.set_yticks([]);ax.set_ylim(0,1.6);ax.set_ylabel(name)
    ax.text(8.4,.9,f'AP = {ap_sequence(labels):.4f}\nPrecision@3 = {sum(labels[:3])}/3',ha='left',fontsize=10)
    ax.set_xlim(.4,11);ax.spines[['top','right','left']].set_visible(False)
axs[1].set_xticks(np.arange(1,9));axs[1].set_xlabel('Rank from highest to lowest predicted score')
fig.text(.5,.02,'Synthetic example, not PIE predictions. Both lists have 2 positives out of 8 genes. Teal = positive; shaded = top 3.',ha='center',fontsize=8)
fig.tight_layout(rect=(0,.08,1,1));fig.savefig(F/'02-same-ap-different-budget.png',dpi=160);plt.close(fig)
