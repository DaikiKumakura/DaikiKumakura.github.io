# PIE評価表とDEG母数の監査

対象はReplogle-Nadig必須遺伝子CRISPRiデータの4 fold・3評価設定。実装版21a526add9ff3a81b4f962d9b16bbae570052c63、公開モデル表版055c7a2cabdaff5659121c64fa2b609c231fc5be、加工済みデータ版20c9faef76fc96fdc809871340bd93499413dfe7、split版396ab9563175ee887750c9eed7ccaea6f5fdbf50。全取得URL、サイズ、SHA-256はinput-provenance.jsonを参照する。

## 同梱の集計を再実行

Python 3.12で検証した。analysis.pyとテストは標準ライブラリのみ。

```sh
python analysis.py
python -m unittest test_analysis.py
python plot.py
```

図にはnumpyとmatplotlibが必要。resultsの4 CSVとsummary.json、独自2図を生成する。audit-input.csvは公開スコアの事実値に独自抽出したDEG数を対応させた監査表であり、モデルの遺伝子別予測ではない。reported-aggregates.csvは公開集計値の照合用。元のモデルCSV、モデル本体、埋め込み、ラベル配列、第三者コードは配布していない。LICENSEは独自のコード・説明・図に適用し、第三者資産を再ライセンスしない。

## 公開元の配列と分割まで再照合

任意の追加工程。約473 MBを取得する。numpyが必要。fetch_data.pyはHTTP取得とハッシュ照合のみ行い、取得した第三者コードを実行しない。

```sh
python fetch_data.py
python rebuild_inputs.py
python analysis.py
```

再構築後のaudit-input.csvとreported-aggregates.csvのSHA-256はinput-provenance.jsonのinput_hashesと照合できる。検証時には2ファイルとも一致した。ラベルの形は5,459×6,642。全testedが真で、testedかつ真のLFCがNaNの要素は0。DEGはfdr<0.05、tested、真のLFC非NaNの積集合である。厳密な不等号を用いる。splitとCSVのcontext/perturbation集合、一意性、各n_rows=1を検査する。全公開集計のAPと再集計との差は2e-7未満を要求する。

## 集計単位と制限

10,335評価行は5,459の生物学的ペアを重複評価したもの。行単位の独立性やfoldの独立性は仮定しない。設定全体のAPは、ペア→背景→foldの均等平均。DEG数と陽性率の中央値は各fold/設定のペアを対象にする。AP/陽性率は非ゼロDEG行だけで計算し、中央値のAPを中央値の陽性率で割った値ではない。陽性ゼロでは比を欠測扱いにし、AP=0の公開方針を確認する。

APと陽性率が等しい線は記述的な目安。有限標本の無作為順位の期待APや有意差検定ではない。ランダムにk遺伝子を非復元で選ぶ期待陽性数k*piは正確だが、PIEのprecision@kを示さない。人工順位例は同じ陽性率とAPでもprecision@3が違うことのみを示す。実装のAPはstepwise average precisionで、台形積分PR-AUCと同一とは限らない。

対応比較は、未知摂動の共通部分に限り、既知背景のAPを摂動内で平均して除外背景との差を取る。既知背景の数が1〜3となり得るためpaired-contexts.csvにその数を残す。背景ごとの真の応答も異なり、未知背景の因果効果ではない。摂動の交差がないペアは比較から除外する。

公開sig_jaccardは確率0.5以上の集合の一致を測り、摂動対象遺伝子を両集合から除外する。一方APの母数には対象遺伝子も含まれる。両指標を同じ候補選択の精度として混同しない。真のLFC相関ではNaNが平均から外されるため、本監査のAPと分母が同じとは限らない。

チェックポイント推論、原生カウントのDE再計算、遺伝子順位、閾値校正、知識源別アブレーション、患者への転用を実行していない。原著PDFは取得できず、数値と定義は上記固定版の一次資料を根拠にした。知識源を使うモデルの説明は公開モデルカード・実装設定を参照する。

PIEのコードはCC BY-NC-SA 4.0、モデルと付随ファイルは別の非商用モデル利用条件。利用は公開元の条件を確認すること。取得スクリプトの存在はモデルの商用利用許諾を意味しない。

原著：Verma R, Adduri A, Bevilacqua B, Eraslan B, Burke DP, Goodarzi H, Roohani Y. (2026). PIE: Generalizing perturbation effects across unseen perturbations, contexts and datasets. bioRxiv version 1, posted 2026-10-05. https://doi.org/10.64898/2026.10.02.756297 。公開資産の著者への帰属であり、論文本文を読了したという主張ではない。
