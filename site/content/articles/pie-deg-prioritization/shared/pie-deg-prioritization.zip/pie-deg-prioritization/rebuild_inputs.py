"""Own extraction: independent joining of source metrics and processed labels."""
from pathlib import Path
import json,csv,hashlib
import numpy as np
P=Path(__file__).resolve().parent
S=P/'sources'
def main():
 meta=json.loads((S/'labels/meta.json').read_text())
 print('meta keys',list(meta))
 ctx={v:k for k,v in meta['context_to_id'].items()};pert={v:k for k,v in meta['pert_to_id'].items()}
 c=np.load(S/'labels/ctx_ids.npy');q=np.load(S/'labels/pert_ids.npy')
 t=np.load(S/'labels/tested.npy',mmap_mode='r');f=np.load(S/'labels/fdr.npy',mmap_mode='r');lf=np.load(S/'labels/lfc_true.npy',mmap_mode='r')
 assert t.shape==f.shape==lf.shape==(5459,6642)
 assert np.all(np.isfinite(f)) and not np.any(t & np.isnan(lf))
 label={}
 for i in range(len(c)):
  key=(ctx[int(c[i])],pert[int(q[i])]);assert key not in label
  label[key]=(int(t[i].sum()),int(((f[i]<.05)&t[i]&~np.isnan(lf[i])).sum()))
 rows=[];agg=[]
 for fold in ['hepg2','jurkat','k562','rpe1']:
  for setting in ['unseen_ctx','unseen_pert','unseen_ctx_pert']:
   split=json.loads((S/f'splits/{fold}/{setting}.json').read_text());expected={(k.split('.',1)[1],v) for k,vs in split.items() for v in vs}
   path=S/f'{fold}/eval/{setting}'
   records=list(csv.DictReader((path/'granular_best_auprc.csv').open()))
   actual={(r['context'],r['perturbation']) for r in records};assert expected==actual and len(actual)==len(records)
   for r in records:
    assert int(r['n_rows'])==1
    n,m=label[(r['context'],r['perturbation'])]
    rows.append(dict(fold=fold,setting=setting,context=r['context'],perturbation=r['perturbation'],tested_genes=n,de_genes=m,reported_ap=float(r['binary_auprc']),reported_jaccard=float(r['sig_jaccard'])))
   for r in csv.DictReader((path/'metrics_best_auprc.csv').open()):
    agg.append(dict(fold=fold,setting=setting,context=r['context'],n_rows=int(r['n_rows']),reported_ap=float(r['binary_auprc'])))
 for name,data in [('audit-input.csv',rows),('reported-aggregates.csv',agg)]:
  with (P/name).open('w',newline='',encoding='utf-8') as h:
   w=csv.DictWriter(h,fieldnames=list(data[0]));w.writeheader();w.writerows(data)
 print('audit rows',len(rows))
if __name__=='__main__':main()
