"""Own descriptive audit of published PIE scores; no model inference."""
from pathlib import Path
import csv
import json
import math
import statistics as st
from collections import defaultdict

HERE = Path(__file__).resolve().parent
SETTINGS = ('unseen_ctx', 'unseen_pert', 'unseen_ctx_pert')

def bucket(n):
    if n < 0: raise ValueError('negative count')
    return '0' if n == 0 else '1-20' if n <= 20 else '21-100' if n <= 100 else '101-500' if n <= 500 else '>500'

def prevalence(n, m):
    if n <= 0 or not 0 <= m <= n: raise ValueError('invalid counts')
    return m / n

def lift(ap, pi):
    if not 0 <= ap <= 1 or not 0 <= pi <= 1: raise ValueError('invalid score')
    return ap / pi if pi > 0 else None

def random_expected(n, m, k):
    if not 0 <= k <= n: raise ValueError('invalid budget')
    return k * prevalence(n, m)

def ap_sequence(labels):
    """Average precision for an explicitly ordered, untied example list."""
    if not labels or any(x not in (0, 1) for x in labels): raise ValueError('binary labels required')
    m=sum(labels)
    return sum(sum(labels[:i+1])/(i+1) for i,x in enumerate(labels) if x)/m if m else 0.0

def write_csv(path, rows):
    with path.open('w',newline='',encoding='utf-8') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)

def main():
    rows=list(csv.DictReader((HERE/'audit-input.csv').open(encoding='utf-8')))
    keys=set()
    for r in rows:
        key=tuple(r[k] for k in ('fold','setting','context','perturbation'))
        assert key not in keys;keys.add(key)
        r['tested_genes']=int(r['tested_genes']);r['de_genes']=int(r['de_genes'])
        r['reported_ap']=float(r['reported_ap']);r['reported_jaccard']=float(r['reported_jaccard'])
        pi=prevalence(r['tested_genes'],r['de_genes'])
        r.update(prevalence=pi,ap_over_prevalence=lift(r['reported_ap'],pi),de_bucket=bucket(r['de_genes']),random_expected_50=random_expected(r['tested_genes'],r['de_genes'],50))
        if not r['de_genes']: assert r['reported_ap']==0
    groups=defaultdict(list)
    for r in rows:groups[(r['fold'],r['setting'],r['context'])].append(r)
    agg=list(csv.DictReader((HERE/'reported-aggregates.csv').open(encoding='utf-8')))
    max_error=0
    for r in agg:
        vals=[st.mean(x['reported_ap'] for x in rs) for (f,s,c),rs in groups.items() if f==r['fold'] and s==r['setting'] and (r['context']=='all' or c==r['context'])]
        error=abs(st.mean(vals)-float(r['reported_ap']));max_error=max(max_error,error);assert error<2e-7
        assert int(r['n_rows'])==sum(len(rs) for (f,s,c),rs in groups.items() if f==r['fold'] and s==r['setting'] and (r['context']=='all' or c==r['context']))
    folds=[];strata=[]
    for setting in SETTINGS:
        for fold in ('hepg2','jurkat','k562','rpe1'):
            rs=[r for r in rows if r['fold']==fold and r['setting']==setting]
            aps=[st.mean(r['reported_ap'] for r in g) for (f,s,c),g in groups.items() if f==fold and s==setting]
            nz=[r for r in rs if r['de_genes']]
            folds.append(dict(fold=fold,setting=setting,n_pairs=len(rs),context_macro_ap=st.mean(aps),zero_de_pairs=len(rs)-len(nz),median_de=st.median(r['de_genes'] for r in rs),median_prevalence=st.median(r['prevalence'] for r in rs),nonzero_median_ap_over_prevalence=st.median(r['ap_over_prevalence'] for r in nz),nonzero_ap_below_prevalence=sum(r['reported_ap']<r['prevalence'] for r in nz),nonzero_pairs=len(nz)))
            for b in ('0','1-20','21-100','101-500','>500'):
                a=[r for r in rs if r['de_bucket']==b]
                if a:strata.append(dict(fold=fold,setting=setting,de_bucket=b,n=len(a),median_ap=st.median(r['reported_ap'] for r in a),median_prevalence=st.median(r['prevalence'] for r in a),median_lift=st.median(r['ap_over_prevalence'] for r in a) if b!='0' else '',median_random_expected_50=st.median(r['random_expected_50'] for r in a)))
    paired=[]
    for fold in ('hepg2','jurkat','k562','rpe1'):
        known=defaultdict(list)
        for r in rows:
            if r['fold']==fold and r['setting']=='unseen_pert':known[r['perturbation']].append(r)
        for r in rows:
            if r['fold']==fold and r['setting']=='unseen_ctx_pert' and r['perturbation'] in known:
                a=known[r['perturbation']]
                paired.append(dict(fold=fold,perturbation=r['perturbation'],n_known_contexts=len(a),known_context_mean_ap=st.mean(x['reported_ap'] for x in a),heldout_context_ap=r['reported_ap'],ap_difference=r['reported_ap']-st.mean(x['reported_ap'] for x in a),known_context_mean_prevalence=st.mean(x['prevalence'] for x in a),heldout_context_prevalence=r['prevalence']))
    summary=dict(total_evaluation_rows=len(rows),unique_biological_pairs=len({(r['context'],r['perturbation']) for r in rows}),max_context_macro_reaggregation_error=max_error,fold_summary=folds,setting_mean_ap={s:st.mean(r['context_macro_ap'] for r in folds if r['setting']==s) for s in SETTINGS},paired_summary={f:dict(n=sum(r['fold']==f for r in paired),median_ap_difference=st.median(r['ap_difference'] for r in paired if r['fold']==f),heldout_lower=sum(r['ap_difference']<0 for r in paired if r['fold']==f)) for f in ('hepg2','jurkat','k562','rpe1')},scope='Released-score reaggregation and processed-label audit. AP/prevalence is descriptive, not calibrated probability or a finite-sample random-ranking test. No precision@k or ablation reproduction.')
    out=HERE/'results';out.mkdir(exist_ok=True)
    for name,data in [('audited-pairs.csv',rows),('fold-summary.csv',folds),('de-strata.csv',strata),('paired-contexts.csv',paired)]:write_csv(out/name,data)
    (out/'summary.json').write_text(json.dumps(summary,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(summary,indent=2))

if __name__=='__main__':main()
