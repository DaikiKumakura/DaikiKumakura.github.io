import unittest
from analysis import prevalence,lift,bucket,random_expected,ap_sequence

class AuditTests(unittest.TestCase):
    def test_prevalence(self): self.assertEqual(prevalence(100,3),.03)
    def test_invalid_counts(self):
        for n,m in [(0,0),(10,11),(10,-1)]:
            with self.assertRaises(ValueError): prevalence(n,m)
    def test_zero_lift_undefined(self): self.assertIsNone(lift(0,0))
    def test_lift(self): self.assertEqual(lift(.2,.02),10)
    def test_bucket_boundaries(self): self.assertEqual([bucket(n) for n in [0,1,20,21,100,101,500,501]],['0','1-20','1-20','21-100','21-100','101-500','101-500','>500'])
    def test_random_full_budget(self): self.assertAlmostEqual(random_expected(100,7,100),7)
    def test_invalid_budget(self):
        with self.assertRaises(ValueError): random_expected(10,2,11)
    def test_same_ap_different_top_three(self):
        a=[0,0,1,0,0,0,0,1];b=[0,0,0,1,0,1,0,0]
        self.assertAlmostEqual(ap_sequence(a),7/24);self.assertAlmostEqual(ap_sequence(a),ap_sequence(b));self.assertNotEqual(sum(a[:3]),sum(b[:3]))
    def test_no_positive_ap(self): self.assertEqual(ap_sequence([0,0]),0)

if __name__=='__main__':unittest.main()
