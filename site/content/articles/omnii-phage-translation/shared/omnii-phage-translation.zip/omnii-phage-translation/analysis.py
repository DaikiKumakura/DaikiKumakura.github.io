"""Audit reported summary numbers and an uncalibrated exposure illustration.

No sequences, phage engineering, pathogen simulations or dosing recommendations.
"""
from pathlib import Path
import json
import numpy as np
import pandas as pd

HERE = Path(__file__).resolve().parent


def exposure(q, c, horizon):
    """Integral of q*exp(-c*t); all quantities are dimensionless."""
    if not 0 <= q <= 1 or c < 0 or horizon < 0:
        raise ValueError('Invalid dimensionless parameters')
    return q*horizon if c == 0 else q*(-np.expm1(-c*horizon))/c


def main():
    inp=json.loads((HERE/'inputs/reported_numbers.json').read_text())
    out=HERE/'results';out.mkdir(exist_ok=True)
    summary=dict(
        activity_above_wildtype_fraction=inp['above_wildtype']/inp['activity_measured'],
        rare_host_top100_fraction=inp['rare_host_top100_hits']/inp['top_k'],
        rare_host_descriptive_enrichment=(inp['rare_host_top100_hits']/inp['top_k'])/inp['rare_host_library_fraction'],
        recovery_percentage_point_difference=100*(inp['recovery_designed']-inp['recovery_random']),
        note='Summary arithmetic only. The rare-host baseline is rounded; variants are not independent clinical observations. No clinical success rate is inferred.')
    pd.DataFrame([dict(group='Evaluated library',percent=100*inp['rare_host_library_fraction']),
                  dict(group='Model top 100',percent=100*inp['rare_host_top100_hits']/inp['top_k'])]).to_csv(out/'reported_selection.csv',index=False)
    rows=[];curves=[]
    for q in [1.0,.2]:
        for c in [.25,2.0]:
            name=f'q={q:g}, c={c:g}'
            rows.append(dict(scenario=name,q=q,c=c,horizon=4,exposure=exposure(q,c,4)))
            for t in np.linspace(0,4,201):
                curves.append(dict(scenario=name,time=t,relative_activity=q*np.exp(-c*t)))
    pd.DataFrame(rows).to_csv(out/'illustrative_exposure.csv',index=False)
    pd.DataFrame(curves).to_csv(out/'illustrative_curves.csv',index=False)
    grid=[dict(q=q,c=c,exposure=exposure(q,c,4)) for q in np.linspace(.1,1,19) for c in np.linspace(.1,3,30)]
    pd.DataFrame(grid).to_csv(out/'exposure_grid.csv',index=False)
    summary['illustrative_exposure_max_min_ratio']=max(r['exposure'] for r in rows)/min(r['exposure'] for r in rows)
    (out/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
    print(json.dumps(summary,indent=2));print(pd.DataFrame(rows).to_string(index=False))


if __name__=='__main__':main()
