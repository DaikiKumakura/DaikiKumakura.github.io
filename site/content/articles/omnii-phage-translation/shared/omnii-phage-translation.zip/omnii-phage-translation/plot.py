"""Original figures from reported summaries and explicitly synthetic exposure."""
from pathlib import Path
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

HERE=Path(__file__).resolve().parent
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':10,'axes.spines.top':False,'axes.spines.right':False})


def main():
    out=HERE/'figures';out.mkdir(exist_ok=True)
    data=pd.read_csv(HERE/'results/reported_selection.csv')
    fig,ax=plt.subplots(figsize=(7.2,4),layout='constrained')
    bars=ax.bar(data.group,data.percent,color=['#9babb8','#355e8a'],width=.55)
    ax.bar_label(bars,labels=['4.5%','24 / 100'],padding=5)
    ax.set(ylabel='Above the reported activity threshold (%)',ylim=(0,30),title='Reported laboratory prioritization on a difficult host')
    ax.text(.5,.83,'5.33-fold descriptive enrichment',transform=ax.transAxes,ha='center')
    fig.savefig(out/'reported-prioritization.png',dpi=180);plt.close(fig)
    curves=pd.read_csv(HERE/'results/illustrative_curves.csv');table=pd.read_csv(HERE/'results/illustrative_exposure.csv')
    fig,axes=plt.subplots(1,2,figsize=(10,4.4),layout='constrained')
    colors=['#355e8a','#d88437','#4a8b79','#9a5a87']
    for (name,g),color in zip(curves.groupby('scenario',sort=False),colors):
        axes[0].plot(g.time,g.relative_activity,label=name,color=color)
    axes[0].set(xlabel='Dimensionless time',ylabel='Relative active exposure at site',title='A. Synthetic profiles, not patient data');axes[0].legend(frameon=False,fontsize=9)
    bars=axes[1].bar(np.arange(4),table.exposure,color=colors);axes[1].bar_label(bars,fmt='%.3f',padding=4)
    axes[1].set_xticks(np.arange(4),table.scenario,rotation=30,ha='right');axes[1].set(ylabel='Dimensionless exposure integral (0 to 4)',ylim=(0,3),title='B. Same initial input, different access / loss')
    fig.savefig(out/'illustrative-exposure.png',dpi=180);plt.close(fig)


if __name__=='__main__':main()
