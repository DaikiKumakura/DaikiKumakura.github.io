"""Save public source snapshots for evidence checking, not model execution."""
from pathlib import Path
import hashlib
import json
import requests
from bs4 import BeautifulSoup

HERE=Path(__file__).resolve().parent
URLS={
    'omnii.html':'https://www.radicalnumerics.ai/blog/omnii-phage',
    'who.html':'https://www.who.int/europe/news-room/fact-sheets/item/bacteriophages-and-their-use-in-combating-antimicrobial-resistance',
    'consensus.html':'https://www.nature.com/articles/s41591-026-04654-6',
    'engineered2019.html':'https://www.nature.com/articles/s41591-019-0437-z',
    'eliminate.json':'https://www.ebi.ac.uk/europepmc/webservices/rest/search?query=EXT_ID:39134085&format=json&resultType=core',
}


def main():
    out=HERE/'sources';out.mkdir(exist_ok=True);records=[]
    for name,url in URLS.items():
        r=requests.get(url,timeout=90);r.raise_for_status();(out/name).write_bytes(r.content)
        records.append(dict(file=name,url=url,sha256=hashlib.sha256(r.content).hexdigest()))
        if name.endswith('.html'):
            (out/name.replace('.html','.txt')).write_text(BeautifulSoup(r.text,'html.parser').get_text('\n',strip=True),encoding='utf-8')
    (out/'provenance.json').write_text(json.dumps(records,indent=2)+'\n')
    print('Saved',len(records),'public source snapshots')


if __name__=='__main__':main()
