import unittest
import json
from pathlib import Path
import numpy as np
from analysis import exposure

HERE=Path(__file__).resolve().parent


class ExposureTests(unittest.TestCase):
    def test_integral_matches_independent_quadrature(self):
        t=np.linspace(0,4,100001)
        for q,c in [(1,.25),(.2,.25),(1,2),(.2,2)]:
            numerical=np.trapz(q*np.exp(-c*t),t)
            self.assertAlmostEqual(exposure(q,c,4),numerical,places=8)

    def test_limits_and_direction(self):
        self.assertEqual(exposure(.2,0,4),.8)
        self.assertEqual(exposure(0,2,4),0)
        self.assertAlmostEqual(exposure(.2,1e-10,4),.8)
        self.assertGreater(exposure(1,.25,4),exposure(1,2,4))
        with self.assertRaises(ValueError):exposure(1,-1,4)

    def test_published_summary_arithmetic(self):
        x=json.loads((HERE/'inputs/reported_numbers.json').read_text())
        self.assertEqual(x['rare_host_top100_hits'],24)
        self.assertAlmostEqual((24/100)/x['rare_host_library_fraction'],16/3)
        self.assertTrue(0<x['above_wildtype']<x['activity_measured'])


if __name__=='__main__':unittest.main()
