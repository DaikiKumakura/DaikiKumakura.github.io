"""Validate the manually transcribed published summaries against source text."""
from pathlib import Path
import hashlib
import json

HERE=Path(__file__).resolve().parent


def main():
    text=(HERE/'sources/omnii.txt').read_text(encoding='utf-8')
    for token in ['69.9%','4.8%','6,694','2,161','4.5%','24%']:
        assert token in text,token
    numbers=dict(recovery_designed=.699,recovery_random=.048,activity_measured=6694,
                 above_wildtype=2161,rare_host_library_fraction=.045,rare_host_top100_hits=24,top_k=100,
                 source='https://www.radicalnumerics.ai/blog/omnii-phage',reported_date='2026-10-20',
                 definitions='Recovery is a proxy for viability. Enrichment/activity thresholds are laboratory readouts, not patient outcomes. Numbers are transcribed from the report and verified as text tokens, not extracted from raw experimental records.')
    out=HERE/'inputs';out.mkdir(exist_ok=True)
    (out/'reported_numbers.json').write_text(json.dumps(numbers,indent=2)+'\n')
    records=json.loads((HERE/'sources/provenance.json').read_text())
    for r in records:
        assert hashlib.sha256((HERE/'sources'/r['file']).read_bytes()).hexdigest()==r['sha256']
    (out/'provenance.json').write_text(json.dumps(dict(retrieved='2026-10-24',sources=records,
         note='Public web pages can change. SHA-256 identifies the snapshots checked for this article; source prose and original figures are not redistributed.'),indent=2)+'\n')


if __name__=='__main__':main()
