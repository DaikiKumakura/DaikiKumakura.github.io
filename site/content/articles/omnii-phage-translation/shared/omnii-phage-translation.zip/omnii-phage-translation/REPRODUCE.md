# AI-designed phages: evidence and exposure illustration

Python 3.12. Install requirements.txt, then run offline:

```
python analysis.py
python plot.py
python -m unittest test_analysis.py
```

The inputs are manually transcribed numerical summaries from the Radical Numerics report dated 20 Oct 2026. They are not raw experiments. The code checks arithmetic only; the top-100 proportion is not a clinical response probability, and the library baseline is rounded. Variants are not assumed independent. No confidence intervals or claims of a new benchmark replication are made.

The second calculation is a dimensionless bookkeeping illustration: a(t)=q exp(-c t), E=int_0^4 a(t)dt. q is the fraction initially available at an abstract site, c is a loss rate per dimensionless time. Input is normalized to one. The four parameter combinations are chosen for illustration; they are not fitted, literature-derived patient estimates or a virtual population. The model does not simulate phage replication, bacteria, resistance, clinical response or dosing. It does not identify a real patient's exposure or recommend treatment.

Independent numerical integration checks the analytic integral. Zero-loss and zero-access limits are tested. The exposure grid is a sensitivity calculation over arbitrary q/c values, not a treatment-optimization surface.

Optional source verification, with network:

```
python fetch_data.py
python extract.py
```

fetch_data.py stores public source pages for inspection; no downloaded code is executed. extract.py verifies stated number tokens and regenerates the manually transcribed input. This is not extraction of the original measurement records. The live pages can change; inputs/provenance.json records the SHA-256 of snapshots checked on 24 Oct 2026. Refreshing later can produce different hashes and should prompt source rechecking.

Sources: https://www.radicalnumerics.ai/blog/omnii-phage ; https://doi.org/10.1038/s41591-019-0437-z ; PMID 39134085 (ELIMINATE part 1); https://doi.org/10.1038/s41591-026-04654-6 ; WHO Europe phage fact sheet (17 Feb 2025). Clinical trial observations are contextual evidence, not model calibration data.

Only our new code, original plots, numerical summaries, original calculations and provenance are bundled. Source prose, original figures, sequences and external software are not redistributed. New code is MIT licensed (LICENSE).
