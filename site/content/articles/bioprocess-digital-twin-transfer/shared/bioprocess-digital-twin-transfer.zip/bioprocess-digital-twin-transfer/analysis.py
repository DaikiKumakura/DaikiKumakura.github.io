"""Synthetic oxygen-transfer calibration counterexample, not an Ark replication."""
from pathlib import Path
import json,csv,platform
import numpy as np
import scipy
from scipy.optimize import brentq
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
HERE=Path(__file__).resolve().parent
CSTAR=.2
C_CAL=.18
R_CAL=1.
KLA_CAL=50.
MODELS={'A':.02,'B':.22}

def qmax(k):return R_CAL*(k+C_CAL)/C_CAL
def uptake(c,k):return qmax(k)*c/(k+c)
def steady(kla,k):
    c=brentq(lambda c:kla*(CSTAR-c)-uptake(c,k),0.,CSTAR,xtol=1e-14)
    return c,uptake(c,k)

def main():
    out=HERE/'results';figs=HERE/'figures';out.mkdir(exist_ok=True);figs.mkdir(exist_ok=True)
    rows=[]
    for name,k in MODELS.items():
        for kla in [50.,8.]:
            c,r=steady(kla,k)
            rows.append({'model':name,'K_mmol_per_L':k,'qmax_mmol_per_L_h':qmax(k),
                         'kLa_per_h':kla,'oxygen_mmol_per_L':c,'uptake_mmol_per_L_h':r,
                         'fraction_of_calibration_uptake':r/R_CAL})
    with (out/'summary.csv').open('w',newline='',encoding='utf-8') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
    for k in MODELS.values():
        c,r=steady(KLA_CAL,k);assert abs(c-C_CAL)<1e-10 and abs(r-R_CAL)<1e-10
        for kla in np.linspace(.1,100,101):
            c,r=steady(kla,k);assert 0<c<CSTAR and 0<r<kla*CSTAR
            assert abs(kla*(CSTAR-c)-r)<1e-10
    fig,axs=plt.subplots(1,2,figsize=(10,4),layout='constrained')
    c=np.linspace(0,.2,201);klas=np.linspace(1,60,150)
    for name,k in MODELS.items():
        axs[0].plot(c,uptake(c,k),label=f'Model {name}')
        axs[1].plot(klas,[steady(kla,k)[1] for kla in klas],label=f'Model {name}')
    axs[0].scatter([C_CAL],[R_CAL],color='black',s=25,zorder=5,label='Calibration')
    axs[0].set(xlabel='Dissolved oxygen (mmol/L)',ylabel='Oxygen uptake (mmol/L/h)')
    axs[1].axhline(1.,color='.6',ls=':',label='Constant-rate extrapolation')
    axs[1].axvline(8.,color='.6',lw=.8)
    axs[1].set(xlabel='kLa (1/h)',ylabel='Steady oxygen uptake (mmol/L/h)')
    for ax in axs:ax.legend(frameon=False)
    fig.suptitle('Synthetic calibration; fixed biomass and gas saturation')
    fig.savefig(figs/'oxygen-transfer.png',dpi=180);plt.close(fig)
    (out/'checks.json').write_text(json.dumps({'synthetic':True,'calibration_and_mass_balance':'passed',
        'python':platform.python_version(),'numpy':np.__version__,'scipy':scipy.__version__,
        'matplotlib':matplotlib.__version__},indent=2)+'\n',encoding='utf-8')
    print(json.dumps(rows,indent=2))
if __name__=='__main__':main()
