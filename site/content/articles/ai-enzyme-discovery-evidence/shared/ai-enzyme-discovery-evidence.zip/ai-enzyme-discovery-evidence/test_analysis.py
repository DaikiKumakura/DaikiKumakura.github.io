"""Reference cases for motif matching, strand direction and zero-success bounds."""
import unittest
from analysis import motif_hits, reverse_complement, zero_success_upper, rounded_sum_compatible


class ReferenceTests(unittest.TestCase):
    def test_exact_and_coordinates(self):
        self.assertEqual(motif_hits('GGACGTAA','ACGT',0),[(2,0)])

    def test_one_mismatch(self):
        self.assertEqual(motif_hits('ACGA','ACGT',1),[(0,1)])
        self.assertEqual(motif_hits('ACAA','ACGT',1),[])

    def test_overlaps(self):
        self.assertEqual(motif_hits('AAAAA','AAA',0),[(0,0),(1,0),(2,0)])

    def test_reverse_complement(self):
        self.assertEqual(reverse_complement('AACG'),'CGTT')
        self.assertEqual(reverse_complement(reverse_complement('AACG')),'AACG')

    def test_unknown_bases_rejected(self):
        with self.assertRaises(ValueError):
            motif_hits('ACNT','ACGT',1)

    def test_short_sequence(self):
        self.assertEqual(motif_hits('AC','ACGT',0),[])

    def test_zero_success_bound(self):
        p = zero_success_upper(10)
        self.assertAlmostEqual((1-p)**10,.05)
        self.assertAlmostEqual(zero_success_upper(1),.95)

    def test_invalid_bound(self):
        with self.assertRaises(ValueError):zero_success_upper(0)

    def test_rounded_accounting(self):
        self.assertTrue(rounded_sum_compatible([11.3,14.9,189.5],215.6))
        self.assertFalse(rounded_sum_compatible([11.3,14.9,189.5],210.))


if __name__ == '__main__':
    unittest.main()
