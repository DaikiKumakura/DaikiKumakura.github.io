"""Original sequence-layout and conditional zero-recovery diagnostic figures."""
from pathlib import Path
import csv
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from analysis import zero_success_upper

HERE = Path(__file__).resolve().parent
OUT = HERE / 'figures'
OUT.mkdir(exist_ok=True)


def read(name):
    with (HERE / name).open(encoding='utf-8') as f:
        return list(csv.DictReader(f))


hits, loci = read('results/motif-hits.csv'), read('loci.csv')
fig, ax = plt.subplots(figsize=(8.5,4.5))
for y, locus in zip([1,0],loci):
    start = int(locus['cds_start_1based'])
    ax.hlines(y,-1500,0,color='#bbb',lw=2)
    selected = [r for r in hits if r['accession']==locus['accession'] and r['in_upstream_window']=='1']
    for r in selected:
        x = int(r['start_1based'])-start
        color = '#166277' if r['mismatches']=='0' else '#a45b32'
        ax.broken_barh([(x,14)],(y-.15,.3),facecolors=color)
    ax.axvline(0,color='#888',lw=1,alpha=.4)
    ax.annotate('',(100,y),(0,y),arrowprops={'arrowstyle':'->','color':'#333'})
ax.set_yticks([1,0],['MarsHill\n5 core matches','SA1\n5 core matches'])
ax.set(xlim=(-1550,150),ylim=(-.5,1.5),xlabel='Core start relative to corresponding CDS start (nt; plus strand)')
ax.spines[['top','right','left']].set_visible(False);ax.grid(axis='x',alpha=.15)
from matplotlib.patches import Patch
ax.legend(handles=[Patch(color='#166277',label='Exact 14-nt core'),Patch(color='#a45b32',label='One mismatch')],frameon=False,loc='upper left')
fig.text(.5,.02,'Known-locus audit. Bars mark 14-nt cores, not entire repeat units; arrows show CDS direction only.',ha='center',fontsize=9)
fig.tight_layout(rect=(0,.06,1,1));fig.savefig(OUT/'01-known-array-layout.png',dpi=180);plt.close(fig)

n, alpha = 10, .05
upper = zero_success_upper(n,alpha)
xs = [i*.6/300 for i in range(301)]
fig, ax = plt.subplots(figsize=(7.5,4.7))
ax.plot(xs,[(1-x)**n for x in xs],color='#166277',lw=2)
ax.axhline(alpha,color='#888',ls='--',lw=1)
ax.vlines(upper,0,alpha,color='#a45b32',ls='--')
ax.scatter([upper],[alpha],color='#a45b32',s=50)
ax.annotate(f'One-sided 95% upper bound: {100*upper:.1f}%',(upper,alpha),xytext=(.30,.29),arrowprops={'arrowstyle':'->','color':'#666'},fontsize=11)
ax.set(xlim=(0,.6),ylim=(0,1.03),xlabel='Assumed recorded-recovery probability per campaign, p',ylabel='P(zero recorded recoveries)\nin 10 campaigns')
ax.grid(alpha=.15)
fig.text(.5,.02,'Illustration assumes independent comparable campaigns and the same recording rule; not biological success.',ha='center',fontsize=9)
fig.tight_layout(rect=(0,.06,1,1));fig.savefig(OUT/'02-zero-recovery-bound.png',dpi=180);plt.close(fig)
