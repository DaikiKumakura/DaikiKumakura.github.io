"""Known-motif sequence audit and descriptive accounting of reported campaigns."""
from pathlib import Path
import csv
import json
import math
import statistics

HERE = Path(__file__).resolve().parent
MOTIF = 'ATATGAATACGTAT'


def motif_hits(sequence, motif=MOTIF, max_mismatches=1):
    sequence, motif = sequence.upper(), motif.upper()
    if not motif or set(sequence + motif) - set('ACGT') or not 0 <= max_mismatches < len(motif):
        raise ValueError('Canonical DNA and a valid mismatch threshold are required')
    return [(i, sum(a != b for a, b in zip(sequence[i:i+len(motif)], motif)))
            for i in range(len(sequence)-len(motif)+1)
            if sum(a != b for a, b in zip(sequence[i:i+len(motif)], motif)) <= max_mismatches]


def reverse_complement(sequence):
    sequence = sequence.upper()
    if set(sequence) - set('ACGT'):
        raise ValueError('Canonical DNA required')
    return sequence.translate(str.maketrans('ACGT','TGCA'))[::-1]


def zero_success_upper(n, alpha=.05):
    if not isinstance(n, int) or n <= 0 or not 0 < alpha < 1:
        raise ValueError('Positive integer trials and valid alpha required')
    return -math.expm1(math.log(alpha)/n)


def rounded_sum_compatible(components, total, half_unit=.05):
    if not components or half_unit <= 0:
        raise ValueError('Invalid rounding inputs')
    center = sum(components)
    return max(center-len(components)*half_unit,total-half_unit) < min(center+len(components)*half_unit,total+half_unit)


def read(name):
    with (HERE / name).open(encoding='utf-8', newline='') as f:
        return list(csv.DictReader(f))


def save(name, rows):
    with (HERE / 'results' / name).open('w', encoding='utf-8', newline='') as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0])); w.writeheader(); w.writerows(rows)


def read_fasta():
    sequences, key = {}, None
    for line in (HERE / 'genomes.fasta').read_text(encoding='utf-8').splitlines():
        if line.startswith('>'):
            key = line[1:].strip()
            if key in sequences:
                raise ValueError('Duplicate FASTA identifier')
            sequences[key] = ''
        elif line.strip():
            if key is None:
                raise ValueError('Missing FASTA header')
            sequences[key] += line.strip().upper()
    return sequences


def main():
    sequences, loci, cds = read_fasta(), read('loci.csv'), read('cds-intervals.csv')
    assert len(sequences) == len(loci) == 2
    hits, summaries = [], []
    for locus in loci:
        acc, sequence = locus['accession'], sequences[locus['accession']]
        assert len(sequence) == int(locus['genome_length']) and locus['strand'] == '+'
        rt = int(locus['cds_start_1based'])
        low = rt-int(locus['upstream_window_nt'])
        selected = []
        n_hits = 0
        for strand, string in [('+',sequence),('-',reverse_complement(sequence))]:
            for i, mismatches in motif_hits(string):
                start = i+1 if strand == '+' else len(sequence)-i-len(MOTIF)+1
                end = start+len(MOTIF)-1
                overlaps = [r['protein_id'] for r in cds if r['accession']==acc and int(r['start_1based'])<=end and int(r['end_1based'])>=start]
                inside = strand == '+' and low <= start and end < rt
                hits.append({'accession':acc,'phage':locus['phage'],'strand':strand,'start_1based':start,
                             'end_1based':end,'mismatches':mismatches,'in_upstream_window':int(inside),
                             'overlapping_cds':';'.join(overlaps)})
                n_hits += 1
                if inside:
                    assert not overlaps
                    selected.append(start)
        selected.sort()
        assert len(selected) == 5
        gaps = [b-a for a,b in zip(selected,selected[1:])]
        summaries.append({'accession':acc,'phage':locus['phage'],'genome_hits_both_strands':n_hits,
                          'upstream_hits':len(selected),'upstream_start_1based':low,'rt_start_1based':rt,
                          'start_to_start_gaps_nt':';'.join(map(str,gaps)),
                          'mean_gap_nt':statistics.mean(gaps),'min_gap_nt':min(gaps),'max_gap_nt':max(gaps)})
    counts = {r['quantity']:float(r['value']) for r in read('reported-counts.csv')}
    assert counts['total_sessions'] == sum(counts[k] for k in ['launch_sessions','worker_sessions','supervisor_sessions','curator_sessions','editor_sessions'])
    assert counts['total_tasks'] == counts['tasks_completed']+counts['tasks_rejected']+counts['tasks_stalled']
    assert counts['total_reports'] == counts['reports_for_partner_families']+counts['reports_for_rt_lineages']
    assert counts['total_promoted'] == counts['initially_promoted']+counts['followup_promoted']
    assert counts['total_promoted'] == counts['retained_as_new_associations']+counts['rejected_or_set_aside']
    assert counts['families_passing_filters'] == counts['known_controls']+counts['remaining_families']
    assert counts['fixed_input_total_attempts'] == counts['fixed_input_attempts_per_model_per_level']*counts['fixed_input_models']*counts['fixed_input_levels']
    tokens = [counts[k] for k in ['input_uncached_million_tokens','output_million_tokens','cache_write_million_tokens']]
    assert rounded_sum_compatible(tokens, counts['reported_total_million_tokens'])
    n = int(counts['replicate_campaigns'])
    assert counts['recorded_array_rediscoveries'] == 0
    result = {'known_motif':MOTIF,'max_mismatches':1,'upstream_window_nt':1500,
              'retained_report_association_fraction':counts['retained_as_new_associations']/counts['total_promoted'],
              'rounded_component_million_token_sum':sum(tokens),'reported_million_tokens':counts['reported_total_million_tokens'],
              'token_rounding_intervals_compatible':True,'zero_recorded_recoveries':0,'rerun_campaigns':n,
              'one_sided_95_upper_under_iid_recording_model':zero_success_upper(n),
              'context_recognition_lower_bound_minus_opus5_level4_pp':counts['strong_models_context_array_recognition_lower_bound']-counts['opus5_level4_array_recognition'],
              'scope':'Post hoc known-motif audit of two genomes and arithmetic of reported counts. The binomial bound assumes independent comparable campaigns and their original-identifier recording rule; it is not an exhaustive ART discovery probability or biological function estimate. Fixed-input recognition and campaign recovery differ.'}
    (HERE / 'results').mkdir(exist_ok=True)
    save('motif-hits.csv', hits); save('locus-summary.csv',summaries)
    (HERE / 'results/summary.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(result,indent=2))


if __name__ == '__main__':
    main()
