# Recalculate the ART evidence diagnostic

Python 3.11+ is sufficient for analysis and nine reference tests. Figures additionally require matplotlib.

```text
python analysis.py
python -m unittest test_analysis.py
python plot.py
```

This is an exploratory known-locus audit after reading the paper, not independent biological discovery. No LLM, genomic foundation model, agent campaign, structure prediction or wet-lab experiment was run.

`genomes.fasta` contains the sequence facts from two public GenBank records, MW248466.1 (MarsHill, 266,637 nt) and MW218148.1 (SA1, 260,727 nt). `loci.csv` records the plus-strand CDS coordinates used to anchor 1,500-nt upstream diagnostic windows. MarsHill QQM14740.1 is annotated RNA-directed DNA polymerase; the corresponding SA1 QPI16926.1 is annotated hypothetical protein. This diagnostic does not independently assign the function of that CDS. `cds-intervals.csv` retains all annotated CDS segments, including joined segments as separate intervals, to flag coding overlaps.

The paper Methods compares these loci using a known 14-nt core, ATATGAATACGTAT, allowing at most one mismatch. Our standard-library scan applies that fixed motif to both strands of each entire genome, then identifies same-strand matches in the upstream windows. It is not the authors' family-wide de novo array-delimitation algorithm. Unknown bases are rejected; these records contain canonical A/C/G/T only. Match coordinates are one-based inclusive. Overlaps are retained. Start-to-start gaps include the core, and are not spacer lengths. The bars in the original layout figure show 14-nt cores, not entire approximately 200-nt array units.

Both upstream windows contain five matching cores outside annotated CDS intervals. MarsHill has five whole-genome matches; SA1 has six, with the sixth inside QPI16945.1, outside the selected upstream window. This shows why a single motif match is insufficient to identify an array. The audit does not quantify genome-wide false positives, novelty, family generalization, RNA expression, enzyme activity or editing utility. The motif and loci were selected from the paper.

`reported-counts.csv` transcribes Figure 1, Results and Methods of the bioRxiv version 1 posted 2026-10-11. It distinguishes protein clusters, RT clusters, sampled loci, families, sessions, tasks, reports and campaign repeats. The 3 of 17 retained partner families were upheld as new associations in reports; this is not a validated wet-lab hit rate. 949 counts sessions rather than distinct autonomous agents. Cached token reads were excluded by the original accounting. Rounded component counts sum to 215.7 million while the reported total is 215.6 million; their rounding intervals overlap, so no numerical inconsistency is inferred.

The original-identifier transcript audit reported zero array rediscoveries in ten further campaigns. Methods explicitly says that ART loci outside the original identifier set would not be found by that audit. The formula `1 - alpha ** (1/n)` is the exact one-sided upper confidence bound for zero successes under independent comparable Bernoulli trials; here alpha=0.05, n=10. It is a conditional calculation illustrating uncertainty, not an independently validated estimate of the true discovery probability. Independence, comparability, completeness of recording and transfer to other systems are not verified. The original successful discovery was not pooled with the post-discovery repeats because it is the selected observation motivating them.

Fixed-input benchmarks had 100 attempts per model per level (seven models, five levels). The reported at-least-90% array-recognition rate in text context and 32% for Opus 5 at file/tool level 4 have different input conditions from full-campaign discovery. The higher value is a lower bound, not an exact count. Recognition uses the paper's model-judge rubric on known ART-positive inputs; specificity on non-ART loci is not estimated. The subtraction of 58 percentage points is therefore a lower-bound contrast in reported recognition settings, not a treatment effect or campaign improvement.

Sources and pinned hashes are in `input-provenance.json`. Primary paper: Yoon et al., https://doi.org/10.64898/2026.10.05.755809 (version 1, posted 2026-10-11, CC BY 4.0). Initial announcement: 2026-09-23. Source sequence records: https://www.ncbi.nlm.nih.gov/nuccore/MW248466.1 and https://www.ncbi.nlm.nih.gov/nuccore/MW218148.1 . Original scripts and documentation are MIT licensed; public sequence facts and transcribed numerical facts are attributed to their source records and paper. The archive grants no third-party software license and does not redistribute source PDFs, GenBank annotations in their original format, reports or figures.

出典の数値と解釈はbioRxiv version 1に固定した。provenance中の別ホストPDFは補助的な参照記録であり、分析の根拠として混在させていない。固定入力の原著評価ではMythos 5が採点者を務めた。
