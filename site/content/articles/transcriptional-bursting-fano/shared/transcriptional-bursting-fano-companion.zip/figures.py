"""Figure 1: stationary mRNA count distributions at equal mean. Figure 2: example single-cell time courses."""
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np

import analysis as an

ROOT = Path(__file__).resolve().parent
(ROOT / "figures").mkdir(exist_ok=True)
colors = ["#555555", "#0072B2", "#D55E00"]

fig, ax = plt.subplots(figsize=(7.2, 3.8), dpi=150)
for (name, b), c in zip(an.BURST_SIZES.items(), colors):
    kb = an.K1 / b
    pi = an.stationary_distribution(kb, b, an.K2)
    n = np.arange(0, 61)
    ax.step(n, pi[:61], where="mid", color=c, lw=2, label=f"{name}; variance / mean = {b:g}")
ax.set_xlabel("mRNA molecules per cell")
ax.set_ylabel("Fraction of cells")
ax.set_title("Same mean (10 per cell), different burst structure (steady state)", fontsize=9)
ax.legend(fontsize=8)
fig.tight_layout()
fig.savefig(ROOT / "figures" / "01-stationary-distributions.png")

fig, axes = plt.subplots(1, 2, figsize=(9.0, 3.4), dpi=150, sharey=True)
for ax, (name, b), c in zip(axes, [list(an.BURST_SIZES.items())[0], list(an.BURST_SIZES.items())[2]], [colors[0], colors[2]]):
    for s in range(3):
        t, n = an.trajectory(an.K1 / b, b, an.K2, 600.0, an.SEED + 10 * s + int(b))
        ax.step(t, n, where="post", color=c, lw=1.2, alpha=0.8)
    ax.set_title(name, fontsize=9)
    ax.set_xlabel("Time (min)")
axes[0].set_ylabel("mRNA molecules per cell")
fig.tight_layout()
fig.savefig(ROOT / "figures" / "02-example-time-courses.png")
