# Transcriptional bursting and the Fano factor: companion code

Batch-birth / linear-death model of mRNA counts with parameters from Golding et al. (Cell 2005). Stationary distributions from the truncated master equation, Gillespie simulation as a check, and a time-scaling identifiability check.

- `analysis.py`: model, stationary distributions, summary tables.
- `figures.py`: Figures 1 and 2.
- `test_analysis.py`: checks (`python -m pytest test_analysis.py`).
- `results/`: CSV outputs.

Inputs are published values. No new measurement data. Random seed 20261103. Requires Python 3 with numpy, scipy, pandas, matplotlib.
