"""Transcriptional bursting: why the mRNA count variance exceeds the mean, and what a snapshot of counts can identify.

Model (batch-birth / linear-death): bursts arrive as a Poisson process with rate kb; each burst adds B molecules,
B geometric on {1, 2, ...} with mean b; each molecule decays at rate d. Mean = kb*b/d; Fano factor (variance / mean) = b.
Parameter anchors are measurements reported by Golding et al. (Cell 2005;123:1025-1036): k1 = 0.14 /min (production),
k2 = 0.014 /min (loss), steady-state mean about 10 transcripts per cell, variance / mean = 4.1 +/- 0.5 at 37 C,
rate constant of P0(t) about 4.4-fold below k1, direct burst size 2.2 transcripts at 22 C.
The stationary distribution is obtained by solving the truncated master equation; a Gillespie simulation checks the moments.
"""
from pathlib import Path

import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parent
OUT = ROOT / "results"
OUT.mkdir(exist_ok=True)

K1, K2 = 0.14, 0.014              # per minute (Golding 2005): production rate k1 and loss rate k2
MEAN = K1 / K2                     # about 10 transcripts per cell
BURST_SIZES = {"Poisson (b = 1)": 1.0, "Direct burst size (b = 2.2)": 2.2, "Variance-implied (b = 4.1)": 4.1}
NMAX = 300
SEED = 20261103
N_CELLS, T_END = 2000, 3000.0


def burst_pmf(b: float, jmax: int) -> np.ndarray:
    """P(B = j), j = 1..jmax, geometric on {1, 2, ...} with mean b."""
    q = 1.0 - 1.0 / b
    j = np.arange(1, jmax + 1)
    pmf = (1.0 - q) * q ** (j - 1)
    return pmf


def stationary_distribution(kb: float, b: float, d: float, nmax: int = NMAX) -> np.ndarray:
    """Stationary distribution of the batch-birth / linear-death process (truncated at nmax; overflow mass is clamped to nmax)."""
    pmf = burst_pmf(b, nmax)
    q_mat = np.zeros((nmax + 1, nmax + 1))
    for n in range(nmax + 1):
        for j in range(1, nmax + 1):
            if pmf[j - 1] < 1e-14:
                break
            q_mat[n, min(n + j, nmax)] += kb * pmf[j - 1]
        if n > 0:
            q_mat[n, n - 1] += d * n
        q_mat[n, n] = -q_mat[n].sum()
    a = np.vstack([q_mat.T, np.ones(nmax + 1)])
    rhs = np.zeros(nmax + 2)
    rhs[-1] = 1.0
    pi = np.linalg.lstsq(a, rhs, rcond=None)[0]
    return np.clip(pi, 0.0, None) / np.clip(pi, 0.0, None).sum()


def moments(pi: np.ndarray) -> tuple[float, float]:
    n = np.arange(len(pi))
    mean = float((n * pi).sum())
    var = float(((n - mean) ** 2 * pi).sum())
    return mean, var


def gillespie_counts(kb: float, b: float, d: float, n_cells: int = N_CELLS, t_end: float = T_END, seed: int = SEED) -> np.ndarray:
    """Counts at t_end for independent cells, starting from zero (exact stochastic simulation)."""
    rng = np.random.default_rng(seed)
    out = np.zeros(n_cells, dtype=int)
    p_geo = 1.0 / b
    for c in range(n_cells):
        t, n = 0.0, 0
        while True:
            total = kb + d * n
            t += rng.exponential(1.0 / total)
            if t > t_end:
                break
            if rng.random() < kb / total:
                n += int(rng.geometric(p_geo))
            else:
                n -= 1
        out[c] = n
    return out


def trajectory(kb: float, b: float, d: float, t_end: float, seed: int) -> tuple[np.ndarray, np.ndarray]:
    rng = np.random.default_rng(seed)
    t, n = 0.0, 0
    ts, ns = [0.0], [0]
    p_geo = 1.0 / b
    while True:
        total = kb + d * n
        t += rng.exponential(1.0 / total)
        if t > t_end:
            break
        n += int(rng.geometric(p_geo)) if rng.random() < kb / total else -1
        ts.append(t)
        ns.append(n)
    ts.append(t_end)
    ns.append(n)
    return np.array(ts), np.array(ns)


def main() -> None:
    rows = []
    pis = {}
    for name, b in BURST_SIZES.items():
        kb = K1 / b                              # burst frequency that keeps the mean at k1 / k2
        pi = stationary_distribution(kb, b, K2)
        pis[name] = pi
        mean, var = moments(pi)
        sim = gillespie_counts(kb, b, K2)
        n = np.arange(len(pi))
        boot = np.random.default_rng(SEED + 1).choice(sim, size=(500, len(sim)), replace=True)
        fano_se = float(np.std(boot.var(axis=1, ddof=1) / boot.mean(axis=1)))
        rows.append(dict(model=name, b=b, burst_rate_per_min=kb, mean_theory=kb * b / K2, mean_master=mean, fano_master=var / mean, fano_theory=b,
                         mean_sim=float(sim.mean()), fano_sim=float(sim.var(ddof=1) / sim.mean()), fano_sim_bootstrap_se=fano_se, p_zero=float(pi[0]),
                         p_ge_20=float(pi[20:].sum()), p_first_burst_rate_per_min=kb))
    tab = pd.DataFrame(rows)
    tab.round(4).to_csv(OUT / "stationary-summary.csv", index=False, lineterminator=chr(10))
    pd.set_option("display.width", 220)
    print(tab.round(3).to_string())
    np.save(OUT / "stationary-pmf.npy", np.vstack([pis[k][:61] for k in BURST_SIZES]))

    # what the paper's three measurements imply for b (all at the same k1)
    k1_over_rate = (4.4, 1.4)
    imp = pd.DataFrame([
        dict(measurement="variance / mean at steady state (37 C)", value=4.1, spread=0.5, implied_b=4.1),
        dict(measurement="k1 / (decay rate of P0(t)) (37 C)", value=k1_over_rate[0], spread=k1_over_rate[1], implied_b=k1_over_rate[0]),
        dict(measurement="direct burst size from time series (22 C)", value=2.2, spread=float("nan"), implied_b=2.2),
    ])
    imp.to_csv(OUT / "paper-implied-burst-size.csv", index=False, lineterminator=chr(10))

    # identifiability: (kb, d) -> (c*kb, c*d) leaves the stationary distribution unchanged, but not the time course
    b = 4.1
    kb = K1 / b
    base = stationary_distribution(kb, b, K2)
    scaled = stationary_distribution(3 * kb, b, 3 * K2)
    print("max |difference| of stationary pmf after 3x time scaling:", float(np.abs(base - scaled).max()))
    p0_rate_base, p0_rate_scaled = kb, 3 * kb
    pd.DataFrame([dict(max_abs_pmf_difference=float(np.abs(base - scaled).max()), first_burst_rate_base=p0_rate_base, first_burst_rate_scaled=p0_rate_scaled)]).to_csv(
        OUT / "identifiability-time-scaling.csv", index=False, lineterminator=chr(10))


if __name__ == "__main__":
    main()
