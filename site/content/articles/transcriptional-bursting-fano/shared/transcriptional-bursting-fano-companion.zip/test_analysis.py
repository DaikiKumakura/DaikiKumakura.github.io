import numpy as np

import analysis as an


def test_burst_pmf_is_geometric_with_requested_mean():
    pmf = an.burst_pmf(2.2, 400)
    j = np.arange(1, 401)
    assert abs(pmf.sum() - 1) < 1e-9
    assert abs((j * pmf).sum() - 2.2) < 1e-6


def test_poisson_limit_gives_poisson_distribution():
    from scipy.stats import poisson
    pi = an.stationary_distribution(an.K1, 1.0, an.K2)
    ref = poisson.pmf(np.arange(len(pi)), an.MEAN)
    assert np.abs(pi - ref).max() < 1e-9


def test_mean_and_fano_match_theory():
    for b in (1.0, 2.2, 4.1):
        kb = an.K1 / b
        mean, var = an.moments(an.stationary_distribution(kb, b, an.K2))
        assert abs(mean - kb * b / an.K2) < 1e-6
        assert abs(var / mean - b) < 1e-6


def test_stationary_distribution_is_invariant_to_time_scaling():
    base = an.stationary_distribution(0.03, 3.0, 0.014)
    scaled = an.stationary_distribution(0.09, 3.0, 0.042)
    assert np.abs(base - scaled).max() < 1e-9


def test_gillespie_matches_master_equation_moments():
    b = 2.2
    kb = an.K1 / b
    sim = an.gillespie_counts(kb, b, an.K2, n_cells=1500, seed=1)
    assert abs(sim.mean() - an.MEAN) < 0.6
    assert abs(sim.var(ddof=1) / sim.mean() - b) < 0.4
