# Extrapolating a data-constrained scaling law: companion code

Rebuilds the scaling law of Baron et al. (arXiv:2610.37842, Eq. 3) from the constants printed in the preprint and evaluates it inside the fitted range (100M unique tokens, 1e19 to 1e20 FLOPs) and at 5T tokens and 1e29 FLOPs: optimal allocation of epochs, model size and ensemble members, flatness of the predicted loss, sensitivity to the printed exponents, and the hyperparameter power laws. The preprint's training code is not run.

- `analysis.py`: the law, the optimizer and all tables.
- `figures.py`: Figures 1 and 2.
- `test_analysis.py`: checks (`python -m pytest test_analysis.py`).
- `results/`: CSV outputs.

Requires Python 3 with numpy, scipy, pandas, matplotlib.
