import numpy as np

import analysis as an


def test_post_arithmetic_is_internally_consistent():
    a = an.blog_arithmetic()
    assert a["chinchilla_params_5T"] == 2.5e11
    assert abs(a["seven_thousand_x"] - 1.75e15) < 1
    assert abs(a["params_per_token_at_7000x"] - 350) < 1e-9
    assert abs(a["gap_ai_vs_human"] - 1e7) < 1


def test_single_member_term_vanishes():
    p = dict(an.PARAMS, F=0.0)
    assert an.loss(1e8, 4e8, 30, 1) == an.loss(1e8, 4e8, 30, 1, p)


def test_ensemble_gain_is_monotone_in_members():
    ls = [an.loss(1e8, 4e8, 30, m) for m in (1, 2, 4, 8, 64)]
    assert all(a > b for a, b in zip(ls, ls[1:]))


def test_prescription_respects_compute_constraint():
    r = an.prescribe(1e20, 1e8)
    assert abs(6 * r["N"] * 1e8 * r["R"] * r["M"] / 1e20 - 1) < 1e-6


def test_in_range_prescription_is_close_to_the_preprint():
    r = an.prescribe(1e20, 1e8, r_min=2.0, n_max=an.N_LARGEST_VALIDATED)
    assert 3.19 < r["loss"] < 3.22            # preprint: under 3.20 observed at 1e20
    assert r["M"] in (2, 3, 4)
    assert 4e8 <= r["N"] <= 1.0e9 and 16 <= r["R"] <= 128   # Figure 5 axis ranges


def test_loss_curve_is_flat_near_optimum():
    f = an.flatness_table()
    assert f.ratio_max_over_min.iloc[0] > 10
    assert (f.ratio_max_over_min.diff().dropna() >= 0).all()


def test_total_params_fixes_epochs():
    L, M, R = an.loss_at_total_params(1.75e15)
    assert abs(R - 1e29 / (6 * 5e12 * 1.75e15)) < 1e-12 and np.isfinite(L)


def test_boundary_optimum_is_found():
    r = an.prescribe(1e29, 5e12, r_min=1.0)
    assert abs(r["R"] - 1.0) < 1e-6 and r["M"] == 1       # single epoch, single model: law value 2.1955
    assert abs(r["loss"] - 2.1955) < 5e-4


def test_domain_constraint_changes_the_prescription():
    free = an.prescribe(1e20, 1e8)
    capped = an.prescribe(1e20, 1e8, r_min=2.0, n_max=an.N_LARGEST_VALIDATED)
    assert capped["N"] <= an.N_LARGEST_VALIDATED * (1 + 1e-9) and free["N"] > 10 * capped["N"]
    assert abs(free["loss"] - capped["loss"]) < 0.01
