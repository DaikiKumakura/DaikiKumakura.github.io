"""Evaluate the fitted data-constrained scaling law of Baron et al. (arXiv:2610.37842, v1) inside and far outside its fitted range.

Inputs are numbers printed in the preprint:
  Eq. 3  L(U,N,R,M) = E + A/N^a + B/(U R)^b + P (R-1)^d (N/U^g)^k - F N^-nu U^-eps R^-rho (1 - 1/M)^mu
  fitted constants (Section 5.2), hyperparameter power laws (Section 4.1), compute C = 6 U N R M,
  fit range U in 25M..400M tokens, N in 30M..398M non-embedding parameters, R in 2..256, M up to 8,
  M* rule of thumb: C2 = 1.4e4 U^1.9, C3 = 4.8e4 U^1.9, M* ~ 2 + C/C3.
and from the Q Labs web post: extrapolation to U = 5T tokens and C = 1e29 FLOPs ("~7,000x Chinchilla", "over 300 parameters per token").

Everything here is arithmetic on those published constants; there are no random numbers. Perturbations of the exponents are NOT confidence
intervals (the preprint prints no covariance); they only show how sensitive an extrapolated prescription is to the printed digits.
"""
from pathlib import Path

import numpy as np
import pandas as pd
from scipy.optimize import minimize_scalar

ROOT = Path(__file__).resolve().parent
OUT = ROOT / "results"
OUT.mkdir(exist_ok=True)

PARAMS = dict(E=2.18, A=165.0, alpha=0.298, B=1759.0, beta=0.408, P=117.0, delta=0.0791, kappa=0.162, gamma=3.04,
              F=192.0, mu=1.12, nu=0.224, eps=0.137, rho=0.263)
FIT_RANGE = dict(U=(25e6, 400e6), N=(30e6, 398e6), R=(2, 256), M=(1, 8))
CHINCHILLA_TOKENS_PER_PARAM = 20.0
HP = dict(eLR=(3.95e4, -1.014, 0.273, 0.120), wd=(1.08e2, -0.870, 0.398, 0.660))   # coefficient, exponents of U, N, R


def loss(U, N, R, M, p=PARAMS):
    """Eq. 3 of the preprint (N: non-embedding parameters per member, R: epochs, M: ensemble members)."""
    over = p["P"] * (R - 1.0) ** p["delta"] * (N / U ** p["gamma"]) ** p["kappa"]
    ens = p["F"] * N ** (-p["nu"]) * U ** (-p["eps"]) * R ** (-p["rho"]) * (1.0 - 1.0 / M) ** p["mu"]
    return p["E"] + p["A"] * N ** (-p["alpha"]) + p["B"] * (U * R) ** (-p["beta"]) + over - ens


def best_for_members(C, U, M, p=PARAMS, r_min=1.0, n_max=np.inf):
    """Best (R, N) for a fixed number of members M under C = 6 U N R M, R >= r_min continuous and N <= n_max. Returns (loss, R, N).

    A log-spaced grid (including both end points) is searched first and the best cell is refined, so that boundary optima (R = r_min) are found.
    """
    r_min = max(r_min, C / (6.0 * U * M * n_max))                    # N <= n_max forces enough epochs
    r_hi = max(C / (6.0 * U * M) / 1.0e3, r_min * (1 + 1e-6))      # keeps N >= 1000 parameters
    f = lambda lr: loss(U, C / (6.0 * U * np.exp(lr) * M), np.exp(lr), M, p)
    grid = np.linspace(np.log(r_min), np.log(r_hi), 4001)
    vals = np.array([f(g) for g in grid])
    i = int(np.argmin(vals))
    lo, hi = grid[max(i - 1, 0)], grid[min(i + 1, len(grid) - 1)]
    res = minimize_scalar(f, bounds=(lo, hi), method="bounded", options=dict(xatol=1e-12))
    lr, fv = (res.x, res.fun) if res.fun < vals[i] else (grid[i], vals[i])
    R = float(np.exp(lr))
    return float(fv), R, C / (6.0 * U * R * M)


def prescribe(C, U, p=PARAMS, m_max=64, r_min=1.0, n_max=np.inf):
    """Compute-optimal configuration among M = 1..m_max (integer), continuous R >= r_min and N <= n_max per member."""
    best = None
    for M in range(1, m_max + 1):
        L, R, N = best_for_members(C, U, M, p, r_min, n_max)
        if best is None or L < best["loss"]:
            best = dict(C=C, U=U, M=M, R=R, N=N, loss=L)
    best["total_params"] = best["N"] * best["M"]
    best["params_per_token"] = best["total_params"] / U
    best["x_chinchilla_params"] = best["total_params"] / (U / CHINCHILLA_TOKENS_PER_PARAM)
    return best


def m_star_rule(C, U):
    """Preprint rule of thumb: M*>=2 above C2, M*=3 above C3, M* ~ 2 + C/C3 beyond."""
    c2, c3 = 1.4e4 * U ** 1.9, 4.8e4 * U ** 1.9
    return c2, c3, (1 if C < c2 else 2 + C / c3)


def hyperparameters(U, N, R):
    c1, a1, b1, d1 = HP["eLR"]
    c2, a2, b2, d2 = HP["wd"]
    return c1 * U ** a1 * N ** b1 * R ** d1, c2 * U ** a2 * N ** b2 * R ** d2


def blog_arithmetic():
    """Internal consistency of the web post's own numbers."""
    u = 5e12
    chin_params = u / CHINCHILLA_TOKENS_PER_PARAM
    return dict(chinchilla_params_5T=chin_params, seven_thousand_x=7000 * chin_params,
                params_per_token_at_7000x=7000 * chin_params / u, chinchilla_params_per_token=1 / CHINCHILLA_TOKENS_PER_PARAM,
                ratio_300_ppt=300 / (1 / CHINCHILLA_TOKENS_PER_PARAM), humans_tokens_per_param=2e8 / 1e14,
                gap_ai_vs_human=CHINCHILLA_TOKENS_PER_PARAM / (2e8 / 1e14), chinchilla_30T_params=30e12 / CHINCHILLA_TOKENS_PER_PARAM,
                extrapolation_factor_U=u / FIT_RANGE["U"][1], compute_flops_ratio_to_1e20=1e29 / 1e20)


N_LARGEST_VALIDATED = 848e6        # largest model size shown in the preprint's Figure 9 (extrapolation points)


def in_range_table() -> pd.DataFrame:
    """U = 100M, C = 1e19..1e20: restricted to R >= 2 and N <= 848M (the preprint's tested ladder), and unrestricted (R >= 1, any N)."""
    rows = []
    for label, kw in (("R>=2, N<=848M", dict(r_min=2.0, n_max=N_LARGEST_VALIDATED)), ("R>=1, any N", dict())):
        for C in (1e19, 3e19, 1e20):
            r = prescribe(C, 100e6, **kw)
            c2, c3, m_rule = m_star_rule(C, 100e6)
            lr, wd = hyperparameters(100e6, r["N"], r["R"])
            rows.append(dict(domain=label, **r, M_rule=m_rule, eLR=lr, wd=wd))
    return pd.DataFrame(rows)


def extrapolation_table(U=5e12, budgets=(1e21, 1e23, 1e25, 1e27, 1e29), r_min=1.0) -> pd.DataFrame:
    rows = []
    for C in budgets:
        r = prescribe(C, U, r_min=r_min)
        c2, c3, m_rule = m_star_rule(C, U)
        lr, wd = hyperparameters(U, r["N"], r["R"])
        rows.append(dict(**r, r_min=r_min, M_rule=m_rule, eLR=lr, wd=wd, N_over_fit_max=r["N"] / FIT_RANGE["N"][1], U_over_fit_max=U / FIT_RANGE["U"][1]))
    return pd.DataFrame(rows)


def sensitivity_table(U=5e12, C=1e29, delta=0.05, r_min=2.0) -> pd.DataFrame:
    """Shift each printed exponent by +-delta (absolute) and recompute the 5T / 1e29 prescription. Not a confidence interval."""
    base = prescribe(C, U, r_min=r_min)
    rows = [dict(param="(printed)", shift=0.0, **{k: base[k] for k in ("M", "R", "N", "total_params", "params_per_token", "x_chinchilla_params", "loss")})]
    for name in ("alpha", "beta", "kappa", "gamma", "nu", "eps", "rho", "delta", "mu"):
        for s in (-delta, +delta):
            p = dict(PARAMS)
            p[name] = PARAMS[name] + s
            r = prescribe(C, U, p, r_min=r_min)
            rows.append(dict(param=name, shift=s, **{k: r[k] for k in ("M", "R", "N", "total_params", "params_per_token", "x_chinchilla_params", "loss")}))
    return pd.DataFrame(rows)


def flatness_table(U=5e12, C=1e29, r_min=2.0, tol=(0.001, 0.004, 0.01)) -> pd.DataFrame:
    # Note: M is searched up to 64, far above the M <= 8 that the preprint fitted; the ranges are therefore lower bounds on the flat region.
    """Loss at fixed C as a function of total parameters N*M (best R >= r_min for each M, N*M fixed by C / (6 U R))."""
    rows = []
    for M in range(1, 65):
        for R in np.geomspace(r_min, 2000, 400):
            N = C / (6.0 * U * R * M)
            rows.append(dict(M=M, R=R, N=N, total_params=N * M, loss=float(loss(U, N, R, M))))
    d = pd.DataFrame(rows)
    best = d.loss.min()
    out = []
    for t in tol:
        w = d[d.loss <= best + t]
        out.append(dict(tol_nats=t, best_loss=best, total_params_min=w.total_params.min(), total_params_max=w.total_params.max(),
                        ratio_max_over_min=w.total_params.max() / w.total_params.min(), M_min=int(w.M.min()), M_max=int(w.M.max())))
    return pd.DataFrame(out)


def loss_at_total_params(T, C=1e29, U=5e12, m_max=64):
    """Loss when the summed ensemble size N*M equals T; then R = C / (6 U T) is fixed. Best integer M in 1..m_max. NaN if R < 1."""
    R = C / (6.0 * U * T)
    if R < 1.0:
        return np.nan, np.nan, R
    best = min((float(loss(U, T / M, R, M)), M) for M in range(1, m_max + 1))
    return best[0], best[1], R


def loss_curve(C=1e29, U=5e12, n=60) -> pd.DataFrame:
    rows = []
    for T in sorted(set(np.geomspace(1e13, C / (6.0 * U), n)) | {C / (12.0 * U)}):
        L, M, R = loss_at_total_params(T, C, U)
        rows.append(dict(total_params=T, params_per_token=T / U, x_chinchilla_params=T / (U / CHINCHILLA_TOKENS_PER_PARAM), R=R, M_best=M, loss=L))
    return pd.DataFrame(rows)


PRINTED_LAST_DIGIT = dict(E=0.01, A=1.0, alpha=0.001, B=1.0, beta=0.001, P=1.0, delta=0.0001, kappa=0.001, gamma=0.01,
                          F=1.0, mu=0.01, nu=0.001, eps=0.001, rho=0.001)


def rounding_table(U=5e12, C=1e29, r_min=2.0) -> pd.DataFrame:
    """Shift each printed constant by +- half of its last printed digit (the rounding the printing allows) and re-optimize. One constant at a time."""
    base = prescribe(C, U, r_min=r_min)
    rows = [dict(param="(printed)", shift=0.0, M=base["M"], R=base["R"], total_params=base["total_params"], loss=base["loss"])]
    for name, unit in PRINTED_LAST_DIGIT.items():
        for sgn in (-1, 1):
            p = dict(PARAMS)
            p[name] = PARAMS[name] + sgn * 0.5 * unit
            r = prescribe(C, U, p, r_min=r_min)
            rows.append(dict(param=name, shift=sgn * 0.5 * unit, M=r["M"], R=r["R"], total_params=r["total_params"], loss=r["loss"]))
    return pd.DataFrame(rows)


def overfit_term_share(U, N, R):
    """Overfitting penalty relative to the other reducible terms at a configuration (diagnostic for the U^gamma scaling)."""
    p = PARAMS
    over = p["P"] * (R - 1.0) ** p["delta"] * (N / U ** p["gamma"]) ** p["kappa"]
    return over, p["A"] * N ** (-p["alpha"]), p["B"] * (U * R) ** (-p["beta"])


def main():
    pd.set_option("display.width", 250, "display.max_columns", 30, "display.float_format", lambda v: f"{v:.4g}")
    ba = blog_arithmetic()
    pd.Series(ba).to_csv(OUT / "post_arithmetic.csv", header=["value"])
    print("post arithmetic:", {k: float(f"{v:.4g}") for k, v in ba.items()})

    a = in_range_table()
    a.to_csv(OUT / "in_range_100M.csv", index=False)
    print("in range U=100M:\n", a)

    b = pd.concat([extrapolation_table(r_min=1.0), extrapolation_table(r_min=2.0)], ignore_index=True)
    b.to_csv(OUT / "extrapolation_5T.csv", index=False)
    print("extrapolation U=5T:\n", b)

    f = flatness_table()
    f.to_csv(OUT / "flatness_5T_1e29.csv", index=False)
    print("flatness:\n", f)

    lc = loss_curve()
    lc.to_csv(OUT / "loss_vs_total_params_5T_1e29.csv", index=False)
    bound = 1e29 / (6.0 * 5e12 * 2.0)                                   # total size when exactly R = 2 (333 parameters per token)
    pb = loss_at_total_params(bound)
    pd.DataFrame([dict(total_params=bound, params_per_token=bound / 5e12, x_chinchilla=bound / 2.5e11, loss=pb[0], M=pb[1], R=pb[2])]).to_csv(OUT / "r2_bound_point.csv", index=False)
    print("R=2 bound point (%.4g total parameters): loss %.4f, M %d, R %.3f" % (bound, *pb))

    rt = rounding_table()
    rt.to_csv(OUT / "rounding_5T_1e29.csv", index=False)
    print("rounding of printed digits: total params %.3g to %.3g, loss %.4f to %.4f, M %s, R %.2f to %.2f" % (rt.total_params.min(), rt.total_params.max(), rt.loss.min(), rt.loss.max(), sorted(set(rt.M)), rt.R.min(), rt.R.max()))

    s = sensitivity_table()
    s.to_csv(OUT / "sensitivity_5T_1e29.csv", index=False)
    print("sensitivity:\n", s)

    r = prescribe(1e29, 5e12, r_min=2.0)
    over, small, tokens = overfit_term_share(5e12, r["N"], r["R"])
    pd.DataFrame([dict(overfit=over, small_model=small, tokens_seen=tokens, N=r["N"], R=r["R"], M=r["M"])]).to_csv(OUT / "terms_5T_1e29.csv", index=False)
    print("terms at 5T/1e29: overfit %.3g, small-model %.3g, tokens-seen %.3g" % (over, small, tokens))


if __name__ == "__main__":
    main()
