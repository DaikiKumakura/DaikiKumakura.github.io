"""Figures for the data-constrained scaling extrapolation note (reads results/*.csv written by analysis.py)."""
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parent
RES, FIG = ROOT / "results", ROOT / "figures"
FIG.mkdir(exist_ok=True)
BLUE, ORANGE, GREY, GREEN = "#0072B2", "#D55E00", "#666666", "#009E73"
SEED_SD = 0.004          # run-to-run spread from seed alone, preprint Table 7 (nats)
POST_TOTAL = 1.6667e15   # total size when R = 2 exactly: 333 parameters per token = 6,667 x Chinchilla at 5T tokens


def fig1():
    d = pd.read_csv(RES / "loss_vs_total_params_5T_1e29.csv").dropna()
    ok, low = d[d.R >= 2], d[d.R <= 2]
    best = ok.loss.min()
    fig, ax = plt.subplots(figsize=(7.4, 4.4))
    ax.plot(ok.total_params, ok.loss, color=BLUE, lw=2, label="Predicted loss, epochs R >= 2 (best integer M for each total)")
    ax.plot(low.total_params, low.loss, color=GREY, lw=1.5, ls="--", label="Epochs R < 2 (outside the fitted epoch range)")
    ax.axhspan(best, best + SEED_SD, color=GREY, alpha=0.18, label="R >= 2 optimum + 0.004 nats (seed spread, preprint Table 7)")
    ax.axvline(POST_TOTAL, color=ORANGE, ls="--", lw=1.6, label="R = 2 bound: 333 params/token = 6,667 x Chinchilla (1.67e15)")
    ax.axvline(4.03e14, color=GREEN, ls=":", lw=1.8, label="Law optimum with R >= 2 (4.0e14)")
    ax.set_xscale("log")
    ax.set_ylim(2.192, best + 0.03)
    ax.set_xlabel("Total parameters in the ensemble, N x M (log scale)")
    ax.set_ylabel("Predicted validation loss (nats)")
    ax.set_title("5T unique tokens, 1e29 FLOPs: predicted loss across total ensemble size", fontsize=10)
    ax.legend(fontsize=7.3, loc="upper left")
    ax.grid(alpha=0.25)
    fig.tight_layout()
    fig.savefig(FIG / "01-flat-loss-vs-total-parameters.png", dpi=170)
    plt.close(fig)


def fig2():
    d = pd.read_csv(RES / "sensitivity_5T_1e29.csv")
    base = d.iloc[0]
    rows = d.iloc[1:].copy()
    rows["label"] = rows.param + rows["shift"].map(lambda s: f" {s:+.2f}")
    fig, ax = plt.subplots(figsize=(7.4, 6.0))
    y = np.arange(len(rows))
    ax.scatter(rows.total_params, y, color=BLUE, zorder=3)
    ax.axvline(base.total_params, color=GREEN, ls=":", lw=1.8, label="Printed constants, R >= 2 (4.0e14)")
    ax.axvline(POST_TOTAL, color=ORANGE, ls="--", lw=1.6, label="R = 2 exactly (1.67e15 = 333 per token = 6,667x Chinchilla)")
    ax.set_yticks(y)
    ax.set_yticklabels(rows.label, fontsize=8)
    ax.set_xscale("log")
    ax.set_xlabel("Prescribed total parameters N x M (log scale)")
    ax.set_title("One exponent shifted by +/-0.05, others fixed, nothing refitted (not a confidence interval)", fontsize=9.5)
    ax.legend(fontsize=8, loc="upper left", bbox_to_anchor=(0.0, 1.0))
    ax.grid(alpha=0.25)
    fig.tight_layout()
    fig.savefig(FIG / "02-exponent-sensitivity.png", dpi=170)
    plt.close(fig)


if __name__ == "__main__":
    fig1()
    fig2()
