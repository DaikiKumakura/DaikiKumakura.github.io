# M04: does a mixed-effects tumor-kinetic estimate add information beyond the observed one-point change?
# R 4.5.1, survival 3.8-3, nlme 3.1-168, jsonlite. Run: Rscript analyze.R  (writes results/*.csv, results/*.json)
args <- commandArgs(FALSE); root <- dirname(normalizePath(sub("^--file=", "", args[grep("^--file=", args)][1])))
suppressPackageStartupMessages({library(survival); library(nlme); library(jsonlite)})
SEED <- 20261004; WPY <- 52.1775; FLOOR <- -10/3; FLOOR_CUT <- -3.33
longi <- read.csv(file.path(root, "raw/colorectalLongi.csv")); ev <- read.csv(file.path(root, "raw/colorectal.csv"))
ev <- ev[order(ev$id, ev$time1), ]; end <- ev[!duplicated(ev$id, fromLast = TRUE), c("id", "time1", "state", "treatment", "age", "who.PS", "prev.resection")]

make_data <- function(weeks, remove101 = TRUE, drop_floor = FALSE) {
  L <- weeks / WPY; ll <- longi
  ll <- if (remove101) ll[ll$id != 101, ] else ll[!(ll$id == 101 & ll$year > end$time1[end$id == 101]), ]
  ll$floor <- ll$tumor.size <= FLOOR_CUT; ll$y <- ifelse(ll$floor, FLOOR, ll$tumor.size)
  pre <- ll[ll$year <= L, ]; if (drop_floor) pre <- pre[!(pre$floor & pre$year > 0), ]
  base <- pre[pre$year == 0, c("id", "y")]; names(base)[2] <- "baseline"
  fu <- pre[pre$year > 0, ]; fu <- fu[order(fu$id, fu$year), ]
  last <- fu[!duplicated(fu$id, fromLast = TRUE), c("id", "year", "y")]; names(last)[2:3] <- c("visit", "early")
  post <- ll[ll$year > L, ]; post <- post[order(post$id, post$year), ]; post <- post[!duplicated(post$id), c("id", "year", "y")]
  names(post)[2:3] <- c("t_next", "y_next")
  d <- merge(merge(end, base, by = "id"), last, by = "id"); d <- d[d$time1 > L, ]
  d <- merge(d, post, by = "id", all.x = TRUE)
  d$time <- d$time1 - L; d$change <- d$early - d$baseline
  d$arm <- as.numeric(d$treatment == "C"); d$age <- factor(d$age, levels = c("<60 years", "60-69 years", ">69 years"))
  d$who <- as.numeric(d$who.PS != "0"); d$resection <- as.numeric(d$prev.resection == "Yes")
  d <- d[order(d$id), ]
  long <- pre[pre$id %in% d$id, c("id", "year", "y")]; long <- long[order(long$id, long$year), ]
  list(d = d, long = long, L = L, weeks = weeks)
}

FIT_LOG <- new.env(); FIT_LOG$n <- 0; FIT_LOG$warn <- 0; FIT_LOG$fallback <- 0
fit_lme <- function(long, quad = FALSE, method = "REML") {
  f <- if (quad) y ~ year + I(year^2) else y ~ year
  ctl <- lmeControl(maxIter = 200, msMaxIter = 200, niterEM = 50, returnObject = TRUE)
  FIT_LOG$n <- FIT_LOG$n + 1; warned <- FALSE
  m <- tryCatch(withCallingHandlers(lme(f, random = ~ year | id, data = long, method = method, control = ctl),
                                    warning = function(w) { warned <<- TRUE; invokeRestart("muffleWarning") }),
                error = function(e) NULL)
  if (is.null(m)) { FIT_LOG$fallback <- FIT_LOG$fallback + 1
    m <- lme(f, random = ~ year | id, data = long, method = method, control = lmeControl(opt = "optim", returnObject = TRUE)) }
  if (warned) FIT_LOG$warn <- FIT_LOG$warn + 1
  m
}

# BLUP of individual effects for any patient given fixed population parameters (works for patients not in the fit)
blup <- function(m, long, ids, tpred) {
  beta <- fixef(m); D <- as.matrix(getVarCov(m)); s2 <- m$sigma^2; quad <- length(beta) == 3
  out <- matrix(NA_real_, length(ids), 3, dimnames = list(NULL, c("pred", "slope", "intercept")))
  for (k in seq_along(ids)) {
    g <- long[long$id == ids[k], ]; t <- g$year
    X <- if (quad) cbind(1, t, t^2) else cbind(1, t); Z <- cbind(1, t)
    V <- Z %*% D %*% t(Z) + diag(s2, length(t)); b <- D %*% t(Z) %*% solve(V, g$y - X %*% beta)
    tp <- tpred[k]; xp <- if (quad) c(1, tp, tp^2) else c(1, tp)
    sl <- beta[2] + b[2] + if (quad) 2 * beta[3] * tp else 0
    out[k, ] <- c(sum(xp * beta) + b[1] + b[2] * tp, sl, beta[1] + b[1])
  }
  out
}

add_kinetic <- function(d, long, m, L) {
  k <- blup(m, long, d$id, rep(L, nrow(d))); d$k_change <- k[, "pred"] - d$baseline; d$k_slope <- k[, "slope"]
  nxt <- ifelse(is.na(d$t_next), L, d$t_next); d$blup_next <- blup(m, long, d$id, nxt)[, "pred"]; d
}

FC <- Surv(time, state) ~ arm + age + who + resection + baseline
FP <- update(FC, . ~ . + change + visit)
FK <- update(FC, . ~ . + k_change + k_slope)
cox_lp <- function(tr, te, f) {
  m <- coxph(f, data = tr, x = TRUE, model = TRUE); lp <- as.numeric(predict(m, newdata = te, type = "lp", reference = "zero"))
  bh <- basehaz(m, centered = FALSE); H <- if (any(bh$time <= 1)) tail(bh$hazard[bh$time <= 1], 1) else 0
  list(lp = lp, s1 = exp(-H * exp(lp)))
}
g_at <- function(sf, t) { i <- findInterval(t, sf$time); c(1, sf$surv)[i + 1] }

cv <- function(x, repeats = 10, quad = FALSE) {
  d <- x$d; long <- x$long; set.seed(SEED); out <- list(); k <- 1
  for (r in seq_len(repeats)) {
    fold <- integer(nrow(d)); for (e in 0:1) { ii <- which(d$state == e); fold[ii] <- sample(rep(1:5, length.out = length(ii))) }
    for (j in 1:5) {
      tr <- d[fold != j, ]; te <- d[fold == j, ]
      m <- fit_lme(long[long$id %in% tr$id, ], quad)
      tr <- add_kinetic(tr, long, m, x$L); te <- add_kinetic(te, long, m, x$L)
      g <- survfit(Surv(time, 1 - state) ~ 1, data = tr)
      a <- cox_lp(tr, te, FC); b <- cox_lp(tr, te, FP); c <- cox_lp(tr, te, FK)
      lin <- te$baseline + (te$early - te$baseline) / te$visit * te$t_next
      out[[k]] <- data.frame(id = te$id, repeat_id = r, fold = j, time = te$time, state = te$state,
        lpC = a$lp, lpP = b$lp, lpK = c$lp, sC = a$s1, sP = b$s1, sK = c$s1, G1 = g_at(g, 1), Gev = g_at(g, pmax(0, te$time - 1e-9)),
        y_next = te$y_next, locf = te$early, linear = lin, blup = te$blup_next); k <- k + 1
    }
  }
  do.call(rbind, out)
}

cidx <- function(a, p) as.numeric(concordance(Surv(time, state) ~ p, data = a, reverse = TRUE)$concordance)
brier <- function(a, s) { w <- ifelse(a$time > 1, 1 / a$G1, ifelse(a$state == 1, 1 / pmax(a$Gev, 1e-8), 0)); mean(w * (as.numeric(a$time > 1) - s)^2) }
cal_slope <- function(a, p) { m <- coxph(Surv(time, state) ~ p, data = data.frame(a, p = p)); c(coef(m)[[1]], confint(m)) }
agg <- function(o) aggregate(cbind(lpC, lpP, lpK, sC, sP, sK, G1, Gev, y_next, locf, linear, blup) ~ id + time + state, data = o, FUN = mean, na.action = na.pass)

summarise <- function(o, label, boot_n = 1000) {
  a <- agg(o); t <- a[!is.na(a$y_next), ]
  est <- c(C_C = cidx(a, a$lpC), C_P = cidx(a, a$lpP), C_K = cidx(a, a$lpK),
           Brier_C = brier(a, a$sC), Brier_P = brier(a, a$sP), Brier_K = brier(a, a$sK),
           MAE_locf = mean(abs(t$y_next - t$locf)), MAE_linear = mean(abs(t$y_next - t$linear)), MAE_blup = mean(abs(t$y_next - t$blup)))
  set.seed(SEED)
  bs <- replicate(boot_n, { b <- a[sample(nrow(a), replace = TRUE), ]; bt <- b[!is.na(b$y_next), ]
    c(dC_KP = cidx(b, b$lpK) - cidx(b, b$lpP), dC_PC = cidx(b, b$lpP) - cidx(b, b$lpC), dBrier_KP = brier(b, b$sK) - brier(b, b$sP),
      dMAE_blup_locf = mean(abs(bt$y_next - bt$blup)) - mean(abs(bt$y_next - bt$locf)),
      dMAE_blup_linear = mean(abs(bt$y_next - bt$blup)) - mean(abs(bt$y_next - bt$linear))) })
  point <- c(dC_KP = est[["C_K"]] - est[["C_P"]], dC_PC = est[["C_P"]] - est[["C_C"]], dBrier_KP = est[["Brier_K"]] - est[["Brier_P"]],
             dMAE_blup_locf = est[["MAE_blup"]] - est[["MAE_locf"]], dMAE_blup_linear = est[["MAE_blup"]] - est[["MAE_linear"]])
  ci <- apply(bs, 1, quantile, c(.025, .975))
  cs <- rbind(C = cal_slope(a, a$lpC), P = cal_slope(a, a$lpP), K = cal_slope(a, a$lpK))
  list(label = label, n = nrow(a), events = sum(a$state), n_next = nrow(t), estimates = as.list(est),
       differences = data.frame(metric = names(point), estimate = point, lower = ci[1, ], upper = ci[2, ]),
       calibration = data.frame(model = rownames(cs), slope = cs[, 1], lower = cs[, 2], upper = cs[, 3]))
}

diagnostics <- function(x) {
  m <- fit_lme(x$long); d <- add_kinetic(x$d, x$long, m, x$L); D <- as.matrix(getVarCov(m))
  re <- ranef(m); shrink_slope <- 1 - var(re[, 2]) / D[2, 2]
  ml1 <- fit_lme(x$long, FALSE, "ML"); ml2 <- fit_lme(x$long, TRUE, "ML")
  lrt_stat <- 2 * (as.numeric(logLik(ml2)) - as.numeric(logLik(ml1))); lrt <- list(`p-value` = c(NA, pchisq(lrt_stat, df = 1, lower.tail = FALSE)))
  r <- residuals(m, type = "normalized"); f <- fitted(m)
  list(fixed = as.list(fixef(m)), sd_intercept = sqrt(D[1, 1]), sd_slope = sqrt(D[2, 2]), cor_re = D[1, 2] / sqrt(D[1, 1] * D[2, 2]),
       sigma = m$sigma, shrinkage_slope = shrink_slope,
       cor_kchange_change = cor(d$k_change, d$change), cor_kslope_change_per_time = cor(d$k_slope, d$change / d$visit),
       quad_lrt_p = lrt[["p-value"]][2], resid_vs_fitted_cor = cor(r, f), resid_vs_time_quad_cor = cor(r, (x$long$year - mean(x$long$year))^2))
}

res <- list(); diffs <- list(); cals <- list(); diag <- list(); escal <- list()
specs <- list(list(w = 16, lab = "16w"), list(w = 24, lab = "24w"), list(w = 32, lab = "32w"),
              list(w = 24, lab = "24w_dropfloor", drop = TRUE), list(w = 32, lab = "32w_dropfloor", drop = TRUE),
              list(w = 24, lab = "24w_keep101", keep = TRUE), list(w = 32, lab = "32w_keep101", keep = TRUE))
for (s in specs) {
  x <- make_data(s$w, remove101 = is.null(s$keep), drop_floor = !is.null(s$drop))
  FIT_LOG$n <- 0; FIT_LOG$warn <- 0; FIT_LOG$fallback <- 0; o <- cv(x)
  fitlog <- list(cv_fits = FIT_LOG$n, cv_fits_with_warning = FIT_LOG$warn, cv_fits_fallback_optim = FIT_LOG$fallback)
  if (s$lab %in% c("16w", "24w", "32w")) write.csv(o, file.path(root, sprintf("results/heldout-private-%s.csv", s$lab)), row.names = FALSE)
  sm <- summarise(o, s$lab); res[[s$lab]] <- c(sm[c("label", "n", "events", "n_next", "estimates")], list(fits = fitlog))
  diffs[[s$lab]] <- cbind(scenario = s$lab, sm$differences); cals[[s$lab]] <- cbind(scenario = s$lab, sm$calibration)
  if (s$lab %in% c("16w", "24w", "32w")) {
    diag[[s$lab]] <- diagnostics(x)
    qo <- cv(x, quad = TRUE); q <- agg(qo); q <- q[!is.na(q$y_next), ]
    if (s$lab != "16w") {  # escalation is evaluated per the fixed rule; report the quadratic model where it applies
      sq <- summarise(qo, paste0(s$lab, "_quadratic")); res[[sq$label]] <- sq[c("label", "n", "events", "n_next", "estimates")]
      diffs[[sq$label]] <- cbind(scenario = sq$label, sq$differences); cals[[sq$label]] <- cbind(scenario = sq$label, sq$calibration)
    }
    escal[[s$lab]] <- list(quad_lrt_p = diag[[s$lab]]$quad_lrt_p, MAE_linear_lme = sm$estimates$MAE_blup,
                           MAE_quadratic_lme = mean(abs(q$y_next - q$blup)))
    escal[[s$lab]]$relative_improvement <- 1 - escal[[s$lab]]$MAE_quadratic_lme / escal[[s$lab]]$MAE_linear_lme
    escal[[s$lab]]$escalate <- escal[[s$lab]]$quad_lrt_p < 0.05 && escal[[s$lab]]$relative_improvement >= 0.05
  }
  cat(s$lab, "done\n")
}
write.csv(do.call(rbind, diffs), file.path(root, "results/differences.csv"), row.names = FALSE)
write.csv(do.call(rbind, cals), file.path(root, "results/calibration.csv"), row.names = FALSE)
write_json(list(performance = res, diagnostics = diag, escalation = escal,
                session = list(R = R.version.string, survival = as.character(packageVersion("survival")), nlme = as.character(packageVersion("nlme")))),
           file.path(root, "results/summary.json"), auto_unbox = TRUE, digits = 8, pretty = TRUE)
print(do.call(rbind, diffs))
