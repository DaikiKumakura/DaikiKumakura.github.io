# Write the two serialized datasets to CSV without installing the package.
args <- commandArgs(FALSE); root <- dirname(normalizePath(sub("^--file=", "", args[grep("^--file=", args)][1])))
load(file.path(root, "raw/frailtypack__data__colorectal.rda"))
load(file.path(root, "raw/frailtypack__data__colorectalLongi.rda"))
write.csv(colorectal, file.path(root, "raw/colorectal.csv"), row.names = FALSE)
write.csv(colorectalLongi, file.path(root, "raw/colorectalLongi.csv"), row.names = FALSE)
cat(nrow(colorectal), nrow(colorectalLongi), "\n")
