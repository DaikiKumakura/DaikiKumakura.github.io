# Tumor kinetics versus a one-point change at the same landmark

Companion to the article "Does a tumor-kinetic model add anything to a single early tumor change?"

No participant-level data are included. `acquire.py` downloads CRAN frailtypack 3.8.1 and checks its SHA-256; `export.R` writes the `colorectal` and `colorectalLongi` datasets locally. Check the underlying data rights before redistributing them.

## Run

1. `python acquire.py` (Python 3.12, standard library)
2. `Rscript export.R` (R 4.5.1)
3. `python audit.py` → `results/audit.json`
4. `Rscript analyze.R` (survival 3.8-3, nlme 3.1-168, jsonlite) → `results/summary.json`, `differences.csv`, `calibration.csv`, and local per-patient held-out predictions
5. `python validate.py` → independent re-computation of the primary metrics (`results/validation.json`)
6. `python figures.py` (matplotlib) → `figures/*.png`

Seed 20261004. `analysis-plan.md` was fixed before any model was fitted; `data-audit.md` records the source checks. The analysis is a research demonstration, not a surrogate-endpoint qualification, treatment rule or prognosis tool.
