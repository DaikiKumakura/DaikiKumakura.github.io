"""Independent re-computation (Python standard library) of the primary metrics from held-out predictions.

Checks Harrell's C (reverse: higher risk -> shorter survival, ties handled as in survival::concordance) and
next-measurement MAE for 16/24/32 weeks against results/summary.json. Run after analyze.R.
"""
import csv, json
from collections import defaultdict
from pathlib import Path

R = Path(__file__).resolve().parent


def per_patient(path):
    rows = defaultdict(list)
    with open(path, newline="") as f:
        for r in csv.DictReader(f):
            rows[(r["id"], r["time"], r["state"])].append(r)
    out = []
    for (i, t, s), rs in rows.items():
        mean = lambda k: sum(float(r[k]) for r in rs) / len(rs)
        nxt = rs[0]["y_next"]
        out.append({"time": float(t), "state": int(s), "lpC": mean("lpC"), "lpP": mean("lpP"), "lpK": mean("lpK"),
                    "y_next": None if nxt in ("", "NA") else float(nxt),
                    "locf": mean("locf"), "linear": None if nxt in ("", "NA") else mean("linear"), "blup": mean("blup")})
    return out


def harrell(rows, key):
    conc = disc = tied = 0.0
    for a in rows:
        if a["state"] != 1:
            continue
        for b in rows:
            if b["time"] > a["time"] or (b["time"] == a["time"] and b["state"] == 0):
                if a[key] > b[key]: conc += 1
                elif a[key] < b[key]: disc += 1
                else: tied += 1
    return (conc + 0.5 * tied) / (conc + disc + tied)


def main():
    summary = json.loads((R / "results/summary.json").read_text())["performance"]
    report = {"status": "pass", "checks": []}
    for lab in ("16w", "24w", "32w"):
        rows = per_patient(R / f"results/heldout-private-{lab}.csv")
        est = summary[lab]["estimates"]
        nxt = [r for r in rows if r["y_next"] is not None]
        mine = {"C_C": harrell(rows, "lpC"), "C_P": harrell(rows, "lpP"), "C_K": harrell(rows, "lpK"),
                "MAE_locf": sum(abs(r["y_next"] - r["locf"]) for r in nxt) / len(nxt),
                "MAE_linear": sum(abs(r["y_next"] - r["linear"]) for r in nxt) / len(nxt),
                "MAE_blup": sum(abs(r["y_next"] - r["blup"]) for r in nxt) / len(nxt)}
        for k, v in mine.items():
            diff = abs(v - est[k])
            ok = diff < 1e-6
            report["checks"].append({"landmark": lab, "metric": k, "r": est[k], "python": v, "abs_diff": diff, "ok": ok})
            if not ok:
                report["status"] = "fail"
        assert len(rows) == summary[lab]["n"] and len(nxt) == summary[lab]["n_next"], lab
    (R / "results/validation.json").write_text(json.dumps(report, indent=2) + "\n")
    print(report["status"], max(c["abs_diff"] for c in report["checks"]), len(report["checks"]), "checks")
    assert report["status"] == "pass"


if __name__ == "__main__":
    main()
