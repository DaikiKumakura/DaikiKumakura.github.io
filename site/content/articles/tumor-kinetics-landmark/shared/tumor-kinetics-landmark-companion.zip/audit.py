"""M04-1 audit: data availability for kinetic modeling at each landmark. Writes results/audit.json (aggregate only)."""
import csv, json
from collections import defaultdict
from pathlib import Path

R = Path(__file__).resolve().parent
WEEKS_PER_YEAR = 52.1775
FLOOR = -3.33  # documented floor of the Box-Cox (lambda 0.3) transformed size; values <= this are floor-censored


def load():
    longi = defaultdict(list)
    with open(R / "raw/colorectalLongi.csv", newline="") as f:
        for r in csv.DictReader(f):
            longi[int(r["id"])].append((float(r["year"]), float(r["tumor.size"])))
    end = {}
    with open(R / "raw/colorectal.csv", newline="") as f:
        for r in csv.DictReader(f):
            i, t1 = int(r["id"]), float(r["time1"])
            if i not in end or t1 >= end[i]["time1"]:
                end[i] = {"time1": t1, "state": int(r["state"])}
    for v in longi.values():
        v.sort()
    return longi, end


def main():
    longi, end = load()
    post_terminal = sorted(i for i, v in longi.items() if any(t > end[i]["time1"] + 1e-9 for t, _ in v))
    floor_all = sum(1 for v in longi.values() for _, y in v if y <= FLOOR)
    gaps = [b[0] - a[0] for v in longi.values() for a, b in zip(v, v[1:])]
    gaps.sort()
    out = {"participants": len(longi), "measurements": sum(map(len, longi.values())),
           "deaths": sum(e["state"] for e in end.values()),
           "post_terminal_measurement_participants": len(post_terminal),
           "floor_censored_measurements": floor_all,
           "median_gap_weeks": round(gaps[len(gaps) // 2] * WEEKS_PER_YEAR, 1),
           "landmarks": []}
    for weeks in (12, 16, 24, 32):
        L = weeks / WEEKS_PER_YEAR
        rows = []
        for i, v in longi.items():
            if i in post_terminal or end[i]["time1"] <= L:
                continue
            if not any(t == 0 for t, _ in v):
                continue
            pre = [(t, y) for t, y in v if 0 < t <= L]
            if not pre:
                continue
            post = [(t, y) for t, y in v if t > L]
            rows.append({"n_pre": len(pre), "floor_pre": sum(y <= FLOOR for _, y in pre),
                         "event": end[i]["state"], "has_post": bool(post)})
        n = len(rows)
        out["landmarks"].append({
            "weeks": weeks, "eligible": n, "deaths_after": sum(r["event"] for r in rows),
            "followups_1": sum(r["n_pre"] == 1 for r in rows), "followups_2": sum(r["n_pre"] == 2 for r in rows),
            "followups_3plus": sum(r["n_pre"] >= 3 for r in rows),
            "floor_censored_pre": sum(r["floor_pre"] for r in rows),
            "with_post_landmark_measurement": sum(r["has_post"] for r in rows)})
    (R / "results/audit.json").write_text(json.dumps(out, indent=2) + "\n")
    print(json.dumps(out, indent=2))


if __name__ == "__main__":
    main()
