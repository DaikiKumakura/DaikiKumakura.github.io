"""Fetch frailtypack 3.8.1 from CRAN (pinned SHA-256) and extract only the two datasets and their help files."""
import hashlib, json, tarfile, urllib.request
from pathlib import Path

R = Path(__file__).resolve().parent
RAW = R / "raw"
URL = "https://cran.r-project.org/src/contrib/frailtypack_3.8.1.tar.gz"
SHA = "b92677cee330815dfe3ad17606bc549b4fabf790840961d44fed292dabfada51"
WANT = ("data/colorectal.rda", "data/colorectalLongi.rda", "man/colorectal.Rd", "man/colorectalLongi.Rd", "/DESCRIPTION")

RAW.mkdir(exist_ok=True)
tgz = RAW / "frailtypack_3.8.1.tar.gz"
if not tgz.exists():
    tgz.write_bytes(urllib.request.urlopen(URL, timeout=120).read())
assert hashlib.sha256(tgz.read_bytes()).hexdigest() == SHA, "pinned source changed"
out = {"url": URL, "version": "3.8.1", "sha256": SHA, "bytes": tgz.stat().st_size, "extracted": []}
with tarfile.open(tgz) as t:
    for m in t.getmembers():
        if m.isfile() and m.name.endswith(WANT) and m.name.count("/") <= 2:
            data = t.extractfile(m).read()
            dest = RAW / m.name.replace("/", "__")
            dest.write_bytes(data)
            out["extracted"].append({"file": dest.name, "sha256": hashlib.sha256(data).hexdigest()})
(RAW / "source-manifest.json").write_text(json.dumps(out, indent=2) + "\n")
print(json.dumps(out, indent=2))
