"""Figures from aggregate results only. Run after analyze.R: python figures.py"""
import csv, json
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

R = Path(__file__).resolve().parent
F = R / "figures"
INK, BLUE, ORANGE, GREEN, GREY = "#222222", "#1f5aa6", "#c2571a", "#2e7d4f", "#8a9099"
plt.rcParams.update({"font.size": 10, "axes.spines.top": False, "axes.spines.right": False})
audit = json.loads((R / "results/audit.json").read_text())
summ = json.loads((R / "results/summary.json").read_text())
diffs = {(r["scenario"], r["metric"]): (float(r["estimate"]), float(r["lower"]), float(r["upper"]))
         for r in csv.DictReader(open(R / "results/differences.csv"))}
LMS = ["16w", "24w", "32w"]


def fig1():
    rows = [l for l in audit["landmarks"] if l["weeks"] in (12, 16, 24, 32)]
    x = [f'{l["weeks"]} wk' for l in rows]
    a = [l["followups_1"] for l in rows]; b = [l["followups_2"] for l in rows]; c = [l["followups_3plus"] for l in rows]
    fig, ax = plt.subplots(figsize=(6.4, 4.0))
    ax.bar(x, a, color="#c9d3dc", label="1 follow-up measurement")
    ax.bar(x, b, bottom=a, color="#7f9fbf", label="2")
    ax.bar(x, c, bottom=[i + j for i, j in zip(a, b)], color=BLUE, label="3 or more")
    for i, l in enumerate(rows):
        ax.text(i, l["eligible"] + 2, f'n={l["eligible"]}', ha="center", fontsize=8.5, color=GREY)
    ax.set_ylabel("Patients in landmark cohort")
    ax.set_title("Follow-up measurements available before each landmark", loc="left", fontsize=10)
    ax.legend(frameon=False, fontsize=8.5, loc="upper center", bbox_to_anchor=(0.5, -0.12), ncol=3)
    ax.set_ylim(0, 150)
    fig.tight_layout(); fig.savefig(F / "fig1-availability.png", dpi=200)


def fig2():
    fig, ax = plt.subplots(figsize=(7.2, 3.8))
    items = [("dC_PC", "", "One-point change vs clinical (P − C)", GREY, -0.18),
             ("dC_KP", "", "Linear kinetic vs one-point (K − P)", BLUE, 0.0),
             ("dC_KP", "_quadratic", "Quadratic kinetic vs one-point", ORANGE, 0.18)]
    for metric, suffix, label, col, off in items:
        for i, lm in enumerate(LMS):
            key = (lm + suffix, metric)
            if key not in diffs:
                continue
            e, lo, hi = diffs[key]
            ax.plot([i + off, i + off], [lo, hi], color=col, lw=2)
            ax.plot(i + off, e, "o", color=col, ms=6, label=label if i == (0 if suffix == "" else 1) else None)
    ax.axhline(0, color=INK, lw=0.8)
    ax.set_xticks(range(3), ["16 weeks", "24 weeks", "32 weeks"])
    ax.set_ylabel("Difference in held-out C-index\n(95% paired bootstrap interval)")
    ax.set_title("Survival discrimination: added value of each tumor summary", loc="left", fontsize=10)
    ax.legend(frameon=False, fontsize=8.5, loc="upper right")
    fig.tight_layout(); fig.savefig(F / "fig2-survival-discrimination.png", dpi=200)


def fig3():
    fig, ax = plt.subplots(figsize=(7.2, 3.8))
    methods = [("MAE_locf", "Last value carried forward", GREEN), ("MAE_linear", "Straight line from baseline", GREY),
               ("MAE_blup", "Linear mixed model", BLUE), ("quad", "Quadratic mixed model", ORANGE)]
    w = 0.2
    for j, (k, label, col) in enumerate(methods):
        xs, ys = [], []
        for i, lm in enumerate(LMS):
            if k == "quad":
                q = summ["performance"].get(lm + "_quadratic")
                if not q:
                    continue
                v = q["estimates"]["MAE_blup"]
            else:
                v = summ["performance"][lm]["estimates"][k]
            xs.append(i + (j - 1.5) * w); ys.append(v)
        ax.bar(xs, ys, width=w, color=col, label=label)
    ax.set_xticks(range(3), ["16 weeks", "24 weeks", "32 weeks"])
    ax.set_ylabel("Mean absolute error, next measurement\n(transformed tumor scale)")
    ax.set_title("Predicting the first tumor measurement after the landmark", loc="left", fontsize=10)
    ax.legend(frameon=False, fontsize=8.5, loc="upper left", ncol=2)
    ax.set_ylim(0, 1.15)
    fig.tight_layout(); fig.savefig(F / "fig3-next-measurement.png", dpi=200)


if __name__ == "__main__":
    F.mkdir(exist_ok=True)
    fig1(); fig2(); fig3()
    print("figures written")
