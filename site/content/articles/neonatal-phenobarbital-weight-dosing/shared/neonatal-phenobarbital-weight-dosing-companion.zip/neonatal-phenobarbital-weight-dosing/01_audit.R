# Data audit of pheno_sd (nlmixr2data 2.0.10): structure, events, covariates, and a check of the unit of the dose column.
# Run: Rscript 01_audit.R   (from any directory other than the downloaded data)
src <- file.path(dirname(normalizePath(sub("^--file=", "", grep("^--file=", commandArgs(FALSE), value = TRUE)[1]), winslash = "/")), "common.R"); source(src)
d <- load_data(); h <- build_hist(d); dir.create(file.path(script_dir, "results"), showWarnings = FALSE)
obs <- d[d$EVID == 0, ]; dose <- d[d$EVID == 1, ]; subj <- h$subj
n_obs_per <- table(obs$ID); n_dose_per <- table(dose$ID)
first_dose <- do.call(rbind, lapply(split(dose, dose$ID), function(x) x[which.min(x$TIME), ]))
stopifnot(all(first_dose$TIME == 0), all(tapply(d$WT, d$ID, function(x) length(unique(x))) == 1), all(tapply(d$APGR, d$ID, function(x) length(unique(x))) == 1),
          !any(is.na(d[, c("ID", "TIME", "AMT", "WT", "APGR")])), all(obs$DV > 0), all(tapply(d$TIME, d$ID, function(x) !is.unsorted(x))), !any(duplicated(d[, c("ID", "TIME")])))
# Observations that fall at or before the first dose
stopifnot(all(sapply(split(d, d$ID), function(x) sum(x$EVID == 0 & x$TIME <= min(x$TIME[x$EVID == 1])) == 0)))
# Unit check: for the first observation after the loading dose and before the second dose, log(C / AMT) should have slope -1 on log(WT) if AMT is a total dose (mg),
# and slope 0 if AMT is a dose per kg.
early <- do.call(rbind, lapply(split(d, d$ID), function(x) {
  dd <- x[x$EVID == 1, ]; oo <- x[x$EVID == 0, ]; nd <- if (nrow(dd) > 1) dd$TIME[2] else Inf; o <- oo[oo$TIME < nd, ]
  if (nrow(o) == 0) return(NULL); data.frame(ID = x$ID[1], WT = x$WT[1], AMT = dd$AMT[1], t = o$TIME[1], C = o$DV[1]) }))
fit <- lm(log(C / AMT) ~ log(WT), early); ci <- confint(fit)["log(WT)", ]
audit <- data.frame(item = c("rows", "subjects", "dose rows", "observation rows", "subjects with at least one observation", "observations per subject, median", "observations per subject, min", "observations per subject, max",
  "dose rows per subject, median", "weight (kg), min", "weight (kg), median", "weight (kg), max", "Apgar 5 min, min", "Apgar 5 min, median", "Apgar 5 min, max", "subjects with Apgar below 5",
  "first dose (loading), median", "first dose, min", "first dose, max", "maintenance dose (all later doses), median", "concentration (mg/L), min", "concentration (mg/L), median", "concentration (mg/L), max",
  "time since first dose at observation (h), median", "time since first dose at observation (h), max", "unit check: subjects used", "unit check: slope of log(C/AMT) on log(WT)", "unit check: 95% CI lower", "unit check: 95% CI upper", "unit check: median C*WT/AMT (L/kg)^-1"),
  value = c(nrow(d), length(unique(d$ID)), nrow(dose), nrow(obs), length(n_obs_per), median(n_obs_per), min(n_obs_per), max(n_obs_per), median(n_dose_per), min(subj$WT), median(subj$WT), max(subj$WT),
  min(subj$APGR), median(subj$APGR), max(subj$APGR), sum(subj$APGR < 5), median(first_dose$AMT), min(first_dose$AMT), max(first_dose$AMT), median(dose$AMT[dose$TIME > 0]), min(obs$DV), median(obs$DV), max(obs$DV),
  median(obs$TIME), max(obs$TIME), nrow(early), coef(fit)[["log(WT)"]], ci[[1]], ci[[2]], median(early$C * early$WT / early$AMT)))
write.csv(audit, file.path(script_dir, "results/audit.csv"), row.names = FALSE)
# Dose per kilogram actually given (AMT is a total dose in mg): loading and maintenance doses, within-infant variation, and the relation of dose to weight
maint <- dose[dose$TIME > 0, ]; maint$mgkg <- maint$AMT / maint$WT; first_dose$mgkg <- first_dose$AMT / first_dose$WT
per_inf <- do.call(rbind, lapply(split(maint, maint$ID), function(x) data.frame(ID = x$ID[1], WT = x$WT[1], n_maint = nrow(x), med_mgkg = median(x$mgkg), cv_mgkg = if (nrow(x) > 1) sd(x$mgkg) / mean(x$mgkg) else NA,
  n_distinct = length(unique(round(x$AMT, 3))), med_interval_h = if (nrow(x) > 1) median(diff(x$TIME)) else NA)))
fm <- lm(log(AMT) ~ log(WT), first_dose); mm <- lm(log(AMT) ~ log(WT), maint)
q <- function(x) quantile(x, c(0.25, 0.5, 0.75), na.rm = TRUE)
dpk <- data.frame(item = c("loading dose, mg/kg: median", "loading dose, mg/kg: 25th percentile", "loading dose, mg/kg: 75th percentile", "loading dose, mg/kg: min", "loading dose, mg/kg: max",
  "maintenance dose per dose, mg/kg (all later doses): median", "maintenance dose per dose, mg/kg: 25th percentile", "maintenance dose per dose, mg/kg: 75th percentile", "maintenance dose per dose, mg/kg: min", "maintenance dose per dose, mg/kg: max",
  "infants with at least one later dose", "infants with at least two later doses", "infants whose later doses were not all identical (dose changed)", "within-infant coefficient of variation of the per-kg maintenance dose, median (infants with 2+ doses)",
  "median interval between later doses, h", "slope of log(loading AMT) on log(WT)", "slope 95% CI lower", "slope 95% CI upper", "slope of log(maintenance AMT) on log(WT) (all later doses)", "slope 95% CI lower", "slope 95% CI upper",
  "Spearman correlation of per-infant median per-kg maintenance dose with WT"),
  value = c(q(first_dose$mgkg)[2], q(first_dose$mgkg)[1], q(first_dose$mgkg)[3], min(first_dose$mgkg), max(first_dose$mgkg), q(maint$mgkg)[2], q(maint$mgkg)[1], q(maint$mgkg)[3], min(maint$mgkg), max(maint$mgkg),
  nrow(per_inf), sum(per_inf$n_maint >= 2), sum(per_inf$n_distinct > 1), median(per_inf$cv_mgkg, na.rm = TRUE), median(per_inf$med_interval_h, na.rm = TRUE), coef(fm)[[2]], confint(fm)[2, 1], confint(fm)[2, 2], coef(mm)[[2]], confint(mm)[2, 1], confint(mm)[2, 2],
  cor(per_inf$med_mgkg, per_inf$WT, method = "spearman")))
write.csv(dpk, file.path(script_dir, "results/audit-dose-per-kg.csv"), row.names = FALSE); print(dpk, row.names = FALSE)
print(audit, row.names = FALSE)
