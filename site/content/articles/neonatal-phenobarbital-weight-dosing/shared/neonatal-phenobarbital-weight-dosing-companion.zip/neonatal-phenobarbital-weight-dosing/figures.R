# Figures for the neonatal phenobarbital article (Okabe-Ito palette). Run: Rscript figures.R (after 01_audit.R to 04_rules.R; Figure 1A reads the data file, see README.md)
.f <- grep("^--file=", commandArgs(FALSE), value = TRUE); source(file.path(dirname(normalizePath(sub("^--file=", "", .f[1]), winslash = "/")), "common.R"))
suppressPackageStartupMessages(library(ggplot2)); dir.create(file.path(script_dir, "figures"), showWarnings = FALSE)
oi <- c(mgkg = "#009E73", band = "#0072B2", flat = "#D55E00")
rule_lab <- c(mgkg = "mg/kg", band = "Weight band", flat = "Flat (1.3 kg dose)")
# Figure 1: (A) unit check, (B) out-of-fold population predictions of the chosen model
d <- load_data()
early <- do.call(rbind, lapply(split(d, d$ID), function(x) {
  dd <- x[x$EVID == 1, ]; oo <- x[x$EVID == 0, ]; nd <- if (nrow(dd) > 1) dd$TIME[2] else Inf; o <- oo[oo$TIME < nd, ]
  if (nrow(o) == 0) return(NULL); data.frame(ID = x$ID[1], WT = x$WT[1], AMT = dd$AMT[1], C = o$DV[1]) }))
early$y <- early$C / early$AMT; fit <- lm(log(y) ~ log(WT), early); ref <- exp(mean(log(early$y))); wref <- exp(mean(log(early$WT)))
lines_df <- rbind(data.frame(WT = range(early$WT), y = exp(coef(fit)[1] + coef(fit)[2] * log(range(early$WT))), lab = "Fitted slope"),
                  data.frame(WT = range(early$WT), y = ref * (range(early$WT) / wref)^-1, lab = "Slope -1 (total dose)"),
                  data.frame(WT = range(early$WT), y = rep(ref, 2), lab = "Slope 0 (dose per kg)"))
pa <- ggplot(early, aes(WT, y)) + geom_point(size = 2, colour = "#000000") +
  geom_line(data = lines_df, aes(colour = lab, linetype = lab), linewidth = 0.9) +
  scale_colour_manual(values = c("Fitted slope" = "#000000", "Slope -1 (total dose)" = "#D55E00", "Slope 0 (dose per kg)" = "#0072B2"), name = NULL) +
  scale_linetype_manual(values = c("Fitted slope" = "solid", "Slope -1 (total dose)" = "dashed", "Slope 0 (dose per kg)" = "dotted"), name = NULL) +
  scale_x_log10(breaks = c(0.7, 1, 1.5, 2, 3)) + scale_y_log10() +
  labs(title = "A. First concentration after the loading dose", x = "Body weight (kg, log scale)", y = "Concentration / recorded dose (log scale)") +
  theme_bw(base_size = 11) + theme(legend.position = "bottom", legend.direction = "vertical", plot.title = element_text(size = 11))
cv <- read.csv(file.path(script_dir, "results/cv-predictions.csv")); best <- readLines(file.path(script_dir, "results/chosen-model.txt")); cv <- cv[cv$model == best, ]
cvm <- aggregate(cbind(obs, pred) ~ ID + obs, cv, function(x) mean(x))
pb <- ggplot(cv, aes(obs, pred)) + geom_abline(slope = 1, intercept = 0, colour = "grey50") +
  geom_abline(slope = 1.3, intercept = 0, colour = "grey50", linetype = "dashed") + geom_abline(slope = 0.7, intercept = 0, colour = "grey50", linetype = "dashed") +
  geom_point(alpha = 0.35, size = 1.6, colour = "#0072B2") + scale_x_log10() + scale_y_log10() +
  labs(title = "B. Out-of-fold predictions (population, chosen model)", x = "Observed concentration (mg/L, log scale)", y = "Predicted concentration (mg/L, log scale)") +
  theme_bw(base_size = 11) + theme(plot.title = element_text(size = 11))
g <- ggplotGrob(pa); g2 <- ggplotGrob(pb)
png(file.path(script_dir, "figures/figure-1-unit-and-fit.png"), width = 2000, height = 1000, res = 200); grid::grid.newpage()
grid::pushViewport(grid::viewport(layout = grid::grid.layout(1, 2))); grid::pushViewport(grid::viewport(layout.pos.col = 1)); grid::grid.draw(g); grid::popViewport()
grid::pushViewport(grid::viewport(layout.pos.col = 2)); grid::grid.draw(g2); grid::popViewport(2); dev.off()
# Figure 2: (A) target attainment with bootstrap range, (B) by weight band
s <- read.csv(file.path(script_dir, "results/rules-summary.csv")); s <- s[s$rule %in% names(oi), ]; s$rule <- factor(s$rule, names(oi), rule_lab); s$time <- factor(s$t_eval, c(24, 168), c("24 h after loading", "168 h after loading"))
p2a <- ggplot(s, aes(rule, within_median, colour = rule)) + geom_pointrange(aes(ymin = within_q05, ymax = within_q95), linewidth = 0.9, size = 0.8) + facet_wrap(~time) +
  scale_colour_manual(values = setNames(oi, rule_lab), guide = "none") + scale_y_continuous(limits = c(0, 1), breaks = seq(0, 1, 0.2)) +
  labs(title = "A. All infants", x = NULL, y = "Share of infants within 15-40 mg/L") + theme_bw(base_size = 11) + theme(axis.text.x = element_text(angle = 20, hjust = 1), plot.title = element_text(size = 11))
b <- read.csv(file.path(script_dir, "results/rules-by-band.csv")); b <- b[b$rule %in% names(oi), ]; b$rule <- factor(b$rule, names(oi), rule_lab); b$band <- factor(b$band, c("<1.0", "1.0-<1.5", "1.5-<2.5", ">=2.5")); b$time <- factor(b$t_eval, c(24, 168), c("24 h", "168 h"))
p2b <- ggplot(b, aes(band, within, colour = rule, shape = rule, group = rule)) + geom_line(linewidth = 0.7) + geom_point(size = 2.6) + facet_wrap(~time) +
  scale_colour_manual(values = setNames(oi, rule_lab), name = NULL) + scale_shape_manual(values = c(16, 17, 15), name = NULL) + scale_y_continuous(limits = c(0, 1), breaks = seq(0, 1, 0.2)) +
  labs(title = "B. By weight band (kg)", x = "Body weight band (kg)", y = "Share within 15-40 mg/L") + theme_bw(base_size = 11) + theme(legend.position = "bottom", plot.title = element_text(size = 11))
png(file.path(script_dir, "figures/figure-2-attainment.png"), width = 2000, height = 1100, res = 200); grid::grid.newpage()
grid::pushViewport(grid::viewport(layout = grid::grid.layout(1, 2, widths = grid::unit(c(0.42, 0.58), "npc"))))
grid::pushViewport(grid::viewport(layout.pos.col = 1)); grid::grid.draw(ggplotGrob(p2a)); grid::popViewport()
grid::pushViewport(grid::viewport(layout.pos.col = 2)); grid::grid.draw(ggplotGrob(p2b)); grid::popViewport(2); dev.off()
