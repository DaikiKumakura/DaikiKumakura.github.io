# Post hoc check: Apgar < 5 on the volume of distribution (the original paper's abstract reports an effect of this kind on V and none on CL). Not part of the pre-specified model set.
# Run: Rscript 02b_apgar_v.R      (writes results/apgar-v.csv)
.f <- grep("^--file=", commandArgs(FALSE), value = TRUE); source(file.path(dirname(normalizePath(sub("^--file=", "", .f[1]), winslash = "/")), "common.R"))
d <- load_data(); h <- build_hist(d); obs <- h$obs
r4 <- fit_model("M4", obs, h); r5 <- NULL
for (st in list(MODELS$M5$start, replace(MODELS$M5$start, "thV", 0.1))) { r5 <- tryCatch(fit_model("M5", obs, h, start = st), error = function(e) NULL); if (!is.null(r5)) break }
row <- function(m, r) if (is.null(r)) data.frame(model = m, converged = FALSE, npar = NA, aic = NA, bic = NA, lCL0 = NA, lV0 = NA, thV = NA, sd_cl = NA, sd_v = NA, sigma = NA) else { f <- r$fit; sds <- as.numeric(VarCorr(f)[, "StdDev"])
  data.frame(model = m, converged = TRUE, npar = attr(logLik(f), "df"), aic = AIC(f), bic = BIC(f), lCL0 = fixef(f)[["lCL0"]], lV0 = fixef(f)[["lV0"]], thV = if ("thV" %in% names(fixef(f))) fixef(f)[["thV"]] else NA,
    sd_cl = sds[1], sd_v = sds[2], sigma = f$sigma) }
out <- rbind(row("M4", r4), row("M5", r5))
write.csv(out, file.path(script_dir, "results/apgar-v.csv"), row.names = FALSE); print(out, row.names = FALSE)
