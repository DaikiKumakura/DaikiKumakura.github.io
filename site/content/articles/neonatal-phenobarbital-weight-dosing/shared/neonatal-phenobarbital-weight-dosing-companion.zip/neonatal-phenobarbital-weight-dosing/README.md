# Companion: weight-based, flat and weight-band phenobarbital dosing in neonates (model-based comparison)

Code and aggregate results for the article "Does a weight-based phenobarbital dose bring more neonates into the target range than a flat dose? A model-based comparison using the 1985 routine-care cohort of 59 preterm infants". **The data are not included.**

## Obtaining the data (not redistributed)

1. Download `nlmixr2data_2.0.10.tar.gz` from CRAN (https://cran.r-project.org/src/contrib/nlmixr2data_2.0.10.tar.gz). SHA-256 of the tarball used: `8555db27117eac430a97ea984c0d7eed2277aedaddc7e39eb3d943527ccb6650`.
2. Create the folder `_download/nlmixr2data/data/` next to the scripts and extract `nlmixr2data/data/pheno_sd.rda` from the tarball into it (SHA-256 of the file used: `483c61d0af46527499b971240d4da92748997aaea19585a0ea1e65831679a6a3`). The package is not installed; the file is only read with `load()`.
3. Treat the downloaded files as untrusted input: keep them in their own folder and do not run scripts from inside it.

The package is listed on CRAN under the GPL (version 3 or later). The rights to the original data (Grasela and Donn 1985; Pinheiro and Bates 2000) were not checked, so the data are not redistributed.

## Files

- `common.R`: shared definitions (data loading with checks, candidate models M0 to M7, nlme model function, target range).
- `rules_lib.R`: dose-rule simulation functions shared by `04_rules.R` and `05_extra.R`.
- `01_audit.R`: data audit, the unit check of the dose column and the dose per kilogram given (writes `results/audit.csv`, `results/audit-dose-per-kg.csv`).
- `02_fit.R`: pre-specified models M0 to M4 (nlme), selection by AIC, 5-fold x 5-repeat cross-validation over infants (writes `results/models.csv`, `results/model-params.csv`, `results/chosen-*.{csv,txt}`, `results/cv.csv`; the observation-level `results/cv-predictions.csv` is not distributed).
- `02b_apgar_v.R`: post hoc model with an Apgar score below 5 on V (writes `results/apgar-v.csv`).
- `03_bootstrap.R`: subject-level bootstrap of the chosen model (writes `results/bootstrap-params.csv` and `results/bootstrap-failures.csv`).
- `04_rules.R`: dose-rule simulation (mg/kg, flat, weight band) with between-infant variability and bootstrap parameter uncertainty, and sensitivity analyses (writes `results/rules-*.csv`).
- `05_extra.R`: post hoc checks: models with weight exponents away from proportionality (M6, M7) and the dose-rule comparison under them, a refit to the observations within 72 h of the first dose, and a predictive check (writes `results/alt-exponent-models.csv`, `results/rules-alt-exponents.csv`, `results/early-fit.csv`, `results/ppc.csv`).
- `figures.R`: Figures 1 and 2 (requires ggplot2 and the data file for Figure 1A).
- `results/`: aggregate results (the numbers in the tables and the text).

## Reproduce

```
Rscript 01_audit.R
Rscript 02_fit.R
Rscript 02b_apgar_v.R
Rscript 03_bootstrap.R 300
Rscript 04_rules.R
Rscript 05_extra.R
Rscript figures.R
```

Seed 20261125; each bootstrap fit and each cross-validation fit is deterministic given the seed, so the results do not depend on the number of worker processes (8 were used). Run the scripts from a directory other than the downloaded data. Software: R 4.5.3, nlme 3.1-168, ggplot2 4.0.4.
