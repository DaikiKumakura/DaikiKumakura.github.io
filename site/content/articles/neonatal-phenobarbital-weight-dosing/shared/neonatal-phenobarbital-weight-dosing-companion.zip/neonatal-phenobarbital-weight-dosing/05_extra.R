# Additional checks requested after review (all post hoc, none changes the pre-specified model choice):
# (1) models with weight exponents away from proportionality (M6: CL ~ WT^0.5, V ~ WT; M7: CL ~ WT, V ~ WT^0.8) fitted to all data, and the dose-rule comparison under them;
# (2) the chosen model refitted to the observations taken within 72 h of the first dose only (before most dose adjustments could matter);
# (3) a predictive check of the chosen model: share of observed concentrations inside the 90% predictive interval of a new infant with the same dose history, and the share of observed concentrations within 15-40 mg/L.
# Run: Rscript 05_extra.R      (seed 20261125)
.f <- grep("^--file=", commandArgs(FALSE), value = TRUE); source(file.path(dirname(normalizePath(sub("^--file=", "", .f[1]), winslash = "/")), "common.R"))
d <- load_data(); h <- build_hist(d); obs <- h$obs; subj <- h$subj; best <- readLines(file.path(script_dir, "results/chosen-model.txt")); source(file.path(script_dir, "rules_lib.R"))
point <- read.csv(file.path(script_dir, "results/chosen-params.csv")); pe <- setNames(point$estimate, point$parameter)
th_of <- function(row) { nm <- intersect(names(row), c("lCL0", "lV0", "aCL", "aV", "thA", "thV")); setNames(as.numeric(unlist(row[nm])), nm) }
sds_of <- function(f) as.numeric(VarCorr(f)[, "StdDev"])
# (1) alternative weight exponents
alt <- list(); rules_alt <- list()
for (m in c("M6", "M7")) {
  r <- fit_model(m, obs, h); if (is.null(r)) { alt[[m]] <- data.frame(model = m, converged = FALSE, npar = NA, aic = NA, lCL0 = NA, lV0 = NA, sd_cl = NA, sd_v = NA, sigma = NA, warned = NA); next }
  f <- r$fit; sd <- sds_of(f); th <- fixef(f)
  alt[[m]] <- data.frame(model = m, converged = TRUE, npar = attr(logLik(f), "df"), aic = AIC(f), lCL0 = th[["lCL0"]], lV0 = th[["lV0"]], sd_cl = sd[1], sd_v = sd[2], sigma = f$sigma, warned = r$warned)
  x <- simulate_draw(th, sd[1], sd[2], SEED, model = m); x$model <- m; rules_alt[[m]] <- x
}
write.csv(do.call(rbind, alt), file.path(script_dir, "results/alt-exponent-models.csv"), row.names = FALSE)
write.csv(do.call(rbind, rules_alt), file.path(script_dir, "results/rules-alt-exponents.csv"), row.names = FALSE)
# (2) early observations only
early_obs <- obs[obs$TIME <= 72, ]
re <- fit_model(best, early_obs, h)
early <- if (is.null(re)) data.frame(n_obs = nrow(early_obs), n_infants = length(unique(early_obs$ID)), converged = FALSE) else { f <- re$fit; sd <- sds_of(f); th <- fixef(f)
  data.frame(n_obs = nrow(early_obs), n_infants = length(unique(early_obs$ID)), converged = TRUE, warned = re$warned, lCL0 = th[["lCL0"]], lV0 = th[["lV0"]], cl_per_kg = exp(th[["lCL0"]]) / WT_REF, v_per_kg = exp(th[["lV0"]]) / WT_REF, sd_cl = sd[1], sd_v = sd[2], sigma = f$sigma) }
write.csv(early, file.path(script_dir, "results/early-fit.csv"), row.names = FALSE)
# (3) predictive check
set.seed(SEED); S <- 4000L; th <- c(lCL0 = pe[["lCL0"]], lV0 = pe[["lV0"]])
inside <- vapply(seq_len(nrow(obs)), function(i) {
  hd <- h$dose[[as.character(obs$ID[i])]]; cl <- typical_cl(best, th, obs$WT[i], obs$APGR[i]) * exp(rnorm(S, 0, pe[["sd_cl"]])); v <- typical_v(best, th, obs$WT[i], obs$APGR[i]) * exp(rnorm(S, 0, pe[["sd_v"]]))
  pred <- log(vapply(seq_len(S), function(k) conc_hist(obs$TIME[i], hd, cl[k], v[k]), numeric(1))) + rnorm(S, 0, pe[["sigma"]])
  qq <- quantile(pred, c(0.05, 0.95)); as.numeric(log(obs$DV[i]) >= qq[1] & log(obs$DV[i]) <= qq[2]) }, numeric(1))
ppc <- data.frame(item = c("observations", "share of observations inside the 90% predictive interval", "share inside, observations within 48 h of the first dose", "share inside, observations after 48 h",
  "share of observed concentrations within 15-40 mg/L", "share of observed concentrations below 15 mg/L", "share above 40 mg/L"),
  value = c(nrow(obs), mean(inside), mean(inside[obs$TIME <= 48]), mean(inside[obs$TIME > 48]), mean(obs$DV >= 15 & obs$DV <= 40), mean(obs$DV < 15), mean(obs$DV > 40)))
write.csv(ppc, file.path(script_dir, "results/ppc.csv"), row.names = FALSE)
options(width = 200); print(do.call(rbind, alt)); print(do.call(rbind, rules_alt)[, 1:8]); print(early); print(ppc)
