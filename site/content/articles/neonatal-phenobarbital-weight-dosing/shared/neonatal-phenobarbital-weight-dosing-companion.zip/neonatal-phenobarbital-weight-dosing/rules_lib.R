# Shared dose-rule simulation functions (sourced by 04_rules.R and 05_extra.R). Needs common.R; expects `subj` (infant-level weight and Apgar) and `best` in the calling environment.
N_SIM <- 4000L; LOAD <- 20; MAINT <- 4        # mg/kg loading dose; mg/kg per daily maintenance dose
T_EVAL <- c(24, 168)                           # h after the loading dose; trough just before the maintenance dose due at that time
BANDS <- c(0, 1.0, 1.5, 2.5, Inf)
BAND_LAB <- c("<1.0", "1.0-<1.5", "1.5-<2.5", ">=2.5")
band_of <- function(w) cut(w, BANDS, right = FALSE, labels = BAND_LAB)
band_rep_wt <- tapply(subj$WT, band_of(subj$WT), median)     # representative weight of each band: cohort median within the band
rules <- function(w) {
  wr <- as.numeric(band_rep_wt[as.character(band_of(w))]); wm <- median(subj$WT)
  wmean <- mean(subj$WT)
  list(mgkg = list(L = LOAD * w, M = MAINT * w), flat = list(L = rep(LOAD * wm, length(w)), M = rep(MAINT * wm, length(w))), band = list(L = LOAD * wr, M = MAINT * wr),
       flat_mean = list(L = rep(LOAD * wmean, length(w)), M = rep(MAINT * wmean, length(w))))   # flat_mean: flat dose set at the cohort mean weight (sensitivity)
}
conc_at <- function(Ld, Md, cl, v, t) {        # one compartment, IV bolus; loading dose at 0, maintenance doses at 24, 48, ... before t
  k <- cl / v; cc <- Ld / v * exp(-k * t)
  if (t > 24) for (tj in seq(24, t - 1, by = 24)) cc <- cc + Md / v * exp(-k * (t - tj))
  cc
}
simulate_draw <- function(th, sd_cl, sd_v, seed, wts = NULL, apgr = NULL, targets = list(TARGET), model = best) {
  set.seed(seed); idx <- sample(nrow(subj), N_SIM, replace = TRUE)
  w <- if (is.null(wts)) subj$WT[idx] else wts; a <- if (is.null(apgr)) subj$APGR[idx] else apgr
  cl <- typical_cl(model, th, w, a) * exp(rnorm(N_SIM, 0, sd_cl)); v <- typical_v(model, th, w, a) * exp(rnorm(N_SIM, 0, sd_v)); r <- rules(w)
  out <- list()
  for (rn in names(r)) for (t in T_EVAL) {
    cc <- conc_at(r[[rn]]$L, r[[rn]]$M, cl, v, t)
    for (tg in targets) out[[length(out) + 1]] <- data.frame(rule = rn, t_eval = t, target = paste(tg, collapse = "-"), within = mean(cc >= tg[1] & cc <= tg[2]), below = mean(cc < tg[1]), above = mean(cc > tg[2]),
      geo_mean = exp(mean(log(cc))), geo_cv = sqrt(exp(var(log(cc))) - 1))
  }
  do.call(rbind, out)
}
