# Dose-rule comparison by simulation from the fitted model: mg/kg rule, flat rule and weight-band rule, all with the loading and maintenance doses of the Australasian neonatal formulary
# (20 mg/kg IV loading dose, then 4 mg/kg once daily starting 24 h after the loading dose). Between-infant variability (random effects) and parameter uncertainty (bootstrap fits) are kept apart.
# Run: Rscript 04_rules.R      (seed 20261125; N_SIM virtual infants per fit, covariates drawn with replacement from the 59 infants)
.f <- grep("^--file=", commandArgs(FALSE), value = TRUE); source(file.path(dirname(normalizePath(sub("^--file=", "", .f[1]), winslash = "/")), "common.R"))
d <- load_data(); h <- build_hist(d); subj <- h$subj; best <- readLines(file.path(script_dir, "results/chosen-model.txt"))
boot <- read.csv(file.path(script_dir, "results/bootstrap-params.csv")); point <- read.csv(file.path(script_dir, "results/chosen-params.csv"))
source(file.path(script_dir, "rules_lib.R"))
th_of <- function(row) { nm <- intersect(names(row), c("lCL0", "lV0", "aCL", "aV", "thA")); setNames(as.numeric(unlist(row[nm])), nm) }
pe <- setNames(point$estimate, point$parameter); pe_th <- th_of(as.list(pe))
# (1) point estimate: between-infant variability only; the primary range and three alternative target ranges
iiv <- simulate_draw(pe_th, pe[["sd_cl"]], pe[["sd_v"]], SEED, targets = c(list(TARGET), TARGET_ALT))
write.csv(iiv, file.path(script_dir, "results/rules-point-estimate.csv"), row.names = FALSE)
# (2) bootstrap fits: between-infant variability within each fit, parameter uncertainty across fits (the same virtual infants and random draws are used for the three rules within a fit)
res <- do.call(rbind, lapply(seq_len(nrow(boot)), function(i) { x <- simulate_draw(th_of(as.list(boot[i, ])), boot$sd_cl[i], boot$sd_v[i], SEED + 1000L + i); x$b <- boot$b[i]; x }))
write.csv(res, file.path(script_dir, "results/rules-bootstrap.csv"), row.names = FALSE)
q3 <- function(x) c(median = median(x), q05 = unname(quantile(x, 0.05)), q95 = unname(quantile(x, 0.95)))
summ <- do.call(rbind, lapply(split(res, list(res$rule, res$t_eval)), function(x) {
  v <- unlist(lapply(c("within", "below", "above", "geo_cv"), function(m) setNames(q3(x[[m]]), paste0(m, "_", c("median", "q05", "q95")))))
  data.frame(rule = x$rule[1], t_eval = x$t_eval[1], n_fits = nrow(x), as.data.frame(t(v))) }))
rownames(summ) <- NULL; write.csv(summ, file.path(script_dir, "results/rules-summary.csv"), row.names = FALSE)
wide <- reshape(res[, c("b", "rule", "t_eval", "within")], idvar = c("b", "t_eval"), timevar = "rule", direction = "wide")
diffs <- do.call(rbind, lapply(split(wide, wide$t_eval), function(x) {
  dd <- list(mgkg_minus_flat = x$within.mgkg - x$within.flat, band_minus_mgkg = x$within.band - x$within.mgkg, band_minus_flat = x$within.band - x$within.flat)
  do.call(rbind, lapply(names(dd), function(n) data.frame(t_eval = x$t_eval[1], contrast = n, median = median(dd[[n]]), q05 = unname(quantile(dd[[n]], 0.05)), q95 = unname(quantile(dd[[n]], 0.95)), share_positive = mean(dd[[n]] > 0)))) }))
rownames(diffs) <- NULL; write.csv(diffs, file.path(script_dir, "results/rules-differences.csv"), row.names = FALSE)
# (3) by weight band, point estimate (infants of the band, resampled from the cohort; Apgar scores resampled from the whole cohort)
bw <- do.call(rbind, lapply(1:4, function(i) {
  pool <- subj$WT[subj$WT >= BANDS[i] & subj$WT < BANDS[i + 1]]; set.seed(SEED + 50L + i)
  x <- simulate_draw(pe_th, pe[["sd_cl"]], pe[["sd_v"]], SEED + 5L, wts = sample(pool, N_SIM, replace = TRUE), apgr = sample(subj$APGR, N_SIM, replace = TRUE)); x$band <- BAND_LAB[i]; x$n_infants <- length(pool); x }))
write.csv(bw, file.path(script_dir, "results/rules-by-band.csv"), row.names = FALSE)
# (4) model-structure sensitivity: the converged pre-specified models M1 to M4 and the post hoc model M5 (point estimates, between-infant variability only)
mods <- read.csv(file.path(script_dir, "results/models.csv")); mp <- read.csv(file.path(script_dir, "results/model-params.csv"))
ms <- do.call(rbind, lapply(c("M1", "M2", "M3", "M4"), function(m) { p <- mp[mp$model == m, ]; th <- setNames(p$estimate, p$parameter); r <- mods[mods$model == m, ]
  x <- simulate_draw(th, r$sd_cl, r$sd_v, SEED, model = m); x$model <- m; x }))
ap <- read.csv(file.path(script_dir, "results/apgar-v.csv")); ap <- ap[ap$model == "M5" & ap$converged, ]   # post hoc model with Apgar < 5 on V (02b_apgar_v.R)
if (nrow(ap)) { x <- simulate_draw(c(lCL0 = ap$lCL0, lV0 = ap$lV0, thV = ap$thV), ap$sd_cl, ap$sd_v, SEED, model = "M5"); x$model <- "M5"; ms <- rbind(ms, x) }
write.csv(ms, file.path(script_dir, "results/rules-by-model.csv"), row.names = FALSE)
# (5) sensitivity to the size of between-infant variability, which the data estimate only weakly (assumed larger values, not estimated from these data)
iv <- do.call(rbind, lapply(list(c(0.30, 0.20), c(0.40, 0.30), c(0.50, 0.40)), function(sd) { x <- simulate_draw(pe_th, sd[1], sd[2], SEED + 9L); x$sd_cl <- sd[1]; x$sd_v <- sd[2]; x }))
write.csv(iv, file.path(script_dir, "results/rules-iiv-sensitivity.csv"), row.names = FALSE)
options(width = 200); print(summ, row.names = FALSE); print(diffs, row.names = FALSE)
