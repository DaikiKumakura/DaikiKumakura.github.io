# Subject-level (nonparametric) bootstrap of the chosen model: resample the 59 infants with replacement (a repeated infant keeps its whole dose and observation history, under a new id),
# refit the chosen model, and keep the fixed effects and random-effect SDs. Fits that fail are counted and left out.
# Run: Rscript 03_bootstrap.R 300      (number of bootstrap fits; each fit uses its own seed derived from seed 20261125, so results do not depend on the number of workers; 8 worker processes)
.f <- grep("^--file=", commandArgs(FALSE), value = TRUE); source(file.path(dirname(normalizePath(sub("^--file=", "", .f[1]), winslash = "/")), "common.R"))
suppressPackageStartupMessages(library(parallel))
args <- commandArgs(trailingOnly = TRUE); B <- if (length(args) >= 1) as.integer(args[1]) else 300L
d <- load_data(); h <- build_hist(d); obs <- h$obs; best <- readLines(file.path(script_dir, "results/chosen-model.txt"))
par0 <- read.csv(file.path(script_dir, "results/chosen-params.csv")); free <- MODELS[[best]]$free
start <- setNames(par0$estimate[match(free, par0$parameter)], free)
boot_job <- function(b) {
  source(file.path(script_dir, "common.R"), local = TRUE)
  set.seed(SEED + b); ids <- sample(h$subj$ID, length(h$subj$ID), replace = TRUE); new_id <- seq_along(ids)
  o <- do.call(rbind, lapply(seq_along(ids), function(i) { x <- obs[obs$ID == ids[i], ]; x$ID <- new_id[i]; x }))
  hs <- list(dose = setNames(lapply(ids, function(i) h$dose[[as.character(i)]]), as.character(new_id)), obs = o, subj = NULL)
  r <- fit_model(best, o, hs, start = start)
  if (is.null(r)) return(list(fail = data.frame(b = b, message = get0("LAST_FIT_ERROR", envir = globalenv(), ifnotfound = "unknown"))))
  f <- r$fit; sds <- as.numeric(VarCorr(f)[, "StdDev"])
  list(ok = data.frame(b = b, t(fixef(f)), sd_cl = sds[1], sd_v = sds[2], sigma = f$sigma, warned = r$warned))
}
cl <- makeCluster(8L); clusterExport(cl, c("script_dir", "SEED", "h", "obs", "best", "start", "boot_job"))
res <- parLapplyLB(cl, seq_len(B), boot_job); stopCluster(cl)
ok <- Filter(function(x) !is.null(x$ok), res); out <- do.call(rbind, lapply(ok, `[[`, "ok"))
write.csv(out, file.path(script_dir, "results/bootstrap-params.csv"), row.names = FALSE)
fails <- Filter(function(x) !is.null(x$fail), res); fl <- if (length(fails)) do.call(rbind, lapply(fails, `[[`, "fail")) else data.frame(b = integer(), message = character())
fl$message <- trimws(gsub("[[:space:]]+", " ", fl$message)); write.csv(fl, file.path(script_dir, "results/bootstrap-failures.csv"), row.names = FALSE)
cat("bootstrap fits requested", B, "succeeded", length(ok), "with warning", sum(out$warned), "\n"); print(summary(out))
