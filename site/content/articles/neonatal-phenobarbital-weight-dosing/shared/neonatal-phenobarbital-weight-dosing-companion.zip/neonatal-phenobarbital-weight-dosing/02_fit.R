# Pre-specified covariate models for the one-compartment IV model (nlme), model comparison by AIC/BIC and by subject-wise cross-validation of population predictions.
# Plan fixed before looking at the model comparison: models M0 to M4 (common.R); choose the lowest AIC among models that converged, preferring a simpler model when it is within 2 AIC units;
# cross-validation (5 folds over subjects, 5 repeats) is a check and does not change the choice. Residual error: additive on the log concentration; random effects (diagonal) on CL and V.
# Run: Rscript 02_fit.R
.f <- grep("^--file=", commandArgs(FALSE), value = TRUE); source(file.path(dirname(normalizePath(sub("^--file=", "", .f[1]), winslash = "/")), "common.R"))
suppressPackageStartupMessages(library(parallel))
d <- load_data(); h <- build_hist(d); obs <- h$obs; dir.create(file.path(script_dir, "results"), showWarnings = FALSE)
NCORES <- 8L
extract <- function(r) {
  if (is.null(r)) return(NULL); f <- r$fit; sds <- as.numeric(VarCorr(f)[, "StdDev"])
  list(fixef = fixef(f), sd_cl = sds[1], sd_v = sds[2], sigma = f$sigma, logLik = as.numeric(logLik(f)), npar = attr(logLik(f), "df"), aic = AIC(f), bic = BIC(f), warned = r$warned)
}
fit_job <- function(job) {
  source(file.path(script_dir, "common.R"), local = TRUE)
  for (st in job$starts) { r <- tryCatch(fit_model(job$m, job$obs, job$hist, start = st), error = function(e) NULL); if (!is.null(r)) return(c(extract(r), list(start_used = which(sapply(job$starts, identical, st))[1]))) }
  NULL
}
starts_for <- function(m) { s <- MODELS[[m]]$start; if (m == "M3") list(s, replace(s, "thA", -0.3), replace(s, "thA", 0.3)) else if (m == "M0") list(s, replace(s, "lCL0", log(0.007))) else list(s) }
# 1. Full-data fits (all models in parallel)
cl <- makeCluster(NCORES); clusterExport(cl, c("script_dir", "starts_for", "extract", "fit_job", "MODELS"))
PREREG <- names(MODELS)[!sapply(MODELS, function(x) isTRUE(x$posthoc))]   # pre-specified models only
jobs <- lapply(PREREG, function(m) list(m = m, obs = obs, hist = h, starts = starts_for(m))); names(jobs) <- PREREG
fits <- parLapplyLB(cl, jobs, fit_job)
mod <- do.call(rbind, lapply(names(fits), function(m) { x <- fits[[m]]
  if (is.null(x)) data.frame(model = m, label = MODELS[[m]]$label, converged = FALSE, npar = NA, logLik = NA, aic = NA, bic = NA, sd_cl = NA, sd_v = NA, sigma = NA, start_used = NA, warned = NA)
  else data.frame(model = m, label = MODELS[[m]]$label, converged = TRUE, npar = x$npar, logLik = x$logLik, aic = x$aic, bic = x$bic, sd_cl = x$sd_cl, sd_v = x$sd_v, sigma = x$sigma, start_used = x$start_used, warned = x$warned) }))
mod$delta_aic <- mod$aic - min(mod$aic, na.rm = TRUE)
write.csv(mod, file.path(script_dir, "results/models.csv"), row.names = FALSE)
par <- do.call(rbind, lapply(names(fits), function(m) { x <- fits[[m]]; if (is.null(x)) NULL else data.frame(model = m, parameter = names(x$fixef), estimate = as.numeric(x$fixef)) }))
write.csv(par, file.path(script_dir, "results/model-params.csv"), row.names = FALSE)
# 2. Selection by the pre-specified rule
ok <- mod[mod$converged, ]; best <- ok$model[which.min(ok$aic)]
simpler <- ok[ok$npar < ok$npar[ok$model == best] & ok$aic - min(ok$aic) < 2, ]; if (nrow(simpler)) best <- simpler$model[which.min(simpler$npar)]
cat("chosen model:", best, "\n"); writeLines(best, file.path(script_dir, "results/chosen-model.txt"))
chosen <- fits[[best]]; write.csv(data.frame(model = best, parameter = c(names(chosen$fixef), "sd_cl", "sd_v", "sigma"), estimate = c(as.numeric(chosen$fixef), chosen$sd_cl, chosen$sd_v, chosen$sigma)), file.path(script_dir, "results/chosen-params.csv"), row.names = FALSE)
# 3. Subject-wise cross-validation of population predictions (fixed effects only), converged models
set.seed(SEED); ids <- h$subj$ID; cv_models <- ok$model[ok$model != "M0"]
folds <- lapply(1:5, function(rep) split(sample(ids), rep(1:5, length.out = length(ids))))
cv_job <- function(job) {
  source(file.path(script_dir, "common.R"), local = TRUE)
  tr <- job$obs[!job$obs$ID %in% job$test_ids, ]; te <- job$obs[job$obs$ID %in% job$test_ids, ]
  r <- tryCatch(fit_model(job$m, tr, job$hist, start = job$start), error = function(e) NULL); if (is.null(r)) return(NULL)
  th <- fixef(r$fit); sub <- h_subj[match(te$ID, h_subj$ID), ]
  pred <- vapply(seq_len(nrow(te)), function(i) conc_hist(te$TIME[i], job$hist$dose[[as.character(te$ID[i])]], typical_cl(job$m, th, te$WT[i], te$APGR[i]), typical_v(job$m, th, te$WT[i])), numeric(1))
  data.frame(model = job$m, rep = job$rep, fold = job$fold, ID = te$ID, obs = te$DV, pred = pred)
}
clusterExport(cl, c("h_subj", "cv_job"), envir = list2env(list(h_subj = h$subj, cv_job = cv_job)))
cvjobs <- unlist(lapply(cv_models, function(m) unlist(lapply(1:5, function(rep) lapply(1:5, function(k) list(m = m, rep = rep, fold = k, test_ids = folds[[rep]][[k]], obs = obs, hist = h, start = fits[[m]]$fixef[MODELS[[m]]$free]))), recursive = FALSE)), recursive = FALSE)
cvres <- parLapplyLB(cl, cvjobs, cv_job); stopCluster(cl)
cv <- do.call(rbind, cvres); write.csv(cv, file.path(script_dir, "results/cv-predictions.csv"), row.names = FALSE)
cvs <- do.call(rbind, lapply(split(cv, cv$model), function(x) { e <- log(x$pred) - log(x$obs); r <- by(e, x$rep, function(z) sqrt(mean(z^2)))
  data.frame(model = x$model[1], folds_fitted = length(unique(paste(x$rep, x$fold))), rmse_log = mean(r), rmse_log_min_rep = min(r), rmse_log_max_rep = max(r), mean_error_log = mean(e), share_within_30pct = mean(abs(x$pred / x$obs - 1) <= 0.3)) }))
rownames(cvs) <- NULL; write.csv(cvs, file.path(script_dir, "results/cv.csv"), row.names = FALSE)
options(width = 200); print(mod, row.names = FALSE); print(cvs, row.names = FALSE)
