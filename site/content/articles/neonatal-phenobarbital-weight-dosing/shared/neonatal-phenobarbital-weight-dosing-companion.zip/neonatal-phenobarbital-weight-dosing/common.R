# Shared definitions for the neonatal phenobarbital analysis. R 4.5.3; packages: nlme (recommended, shipped with R), parallel, ggplot2 (figures only).
# The data file is NOT part of this repository: see README.md for how to obtain nlmixr2data 2.0.10 from CRAN (the .rda is read with load(); nothing is installed).
.f <- grep("^--file=", commandArgs(FALSE), value = TRUE); if (length(.f)) script_dir <- dirname(normalizePath(sub("^--file=", "", .f[1]), winslash = "/")) else stopifnot(exists("script_dir"))
DATA_RDA <- file.path(script_dir, "_download/nlmixr2data/data/pheno_sd.rda")
SEED <- 20261125L
TARGET <- c(15, 40)                 # mg/L, serum phenobarbital target used by the Australasian neonatal formulary (assumed; sensitivity ranges below)
TARGET_ALT <- list(c(20, 40), c(10, 40), c(15, 30))
WT_REF <- 1.3                       # kg, cohort median weight (reference for the covariate models and for the flat rule)
load_data <- function() {
  e <- new.env(); load(DATA_RDA, envir = e); d <- e$pheno_sd
  stopifnot(nrow(d) == 744, length(unique(d$ID)) == 59, all(d$EVID %in% c(0, 1)), all(d$MDV == 1 - (d$EVID == 0)))
  d
}
# Dose history per subject: total dose (mg; see the unit check in 01_audit.R) and time (h since the first dose)
build_hist <- function(d) {
  dose <- d[d$EVID == 1, ]; obs <- d[d$EVID == 0, ]
  list(dose = split(dose[, c("TIME", "AMT")], dose$ID), obs = obs[, c("ID", "TIME", "DV", "WT", "APGR")],
       subj = aggregate(cbind(WT, APGR) ~ ID, d, function(x) x[1]))
}
# Concentration (mg/L) at times t for one subject: sum of IV bolus doses, one compartment
conc_hist <- function(t, hist_dose, cl, v) {
  k <- cl / v; out <- numeric(length(t))
  for (i in seq_len(nrow(hist_dose))) { dt <- t - hist_dose$TIME[i]; out <- out + ifelse(dt >= 0, hist_dose$AMT[i] / v * exp(-k * dt), 0) }
  out
}

# ---- Candidate models (pre-specified; see 02_fit.R). Parameters on the log scale: lCL0 (L/h at WT_REF), lV0 (L at WT_REF); aCL, aV weight exponents; thA effect of Apgar < 5 on log CL.
MODELS <- list(
  M0 = list(label = "No covariates", free = c("lCL0", "lV0"), start = c(lCL0 = log(0.01), lV0 = log(1.3))),
  M1 = list(label = "Fixed allometry (CL 0.75, V 1)", free = c("lCL0", "lV0"), start = c(lCL0 = log(0.01), lV0 = log(1.3))),
  M2 = list(label = "Estimated weight exponents", free = c("lCL0", "lV0", "aCL", "aV"), start = c(lCL0 = log(0.01), lV0 = log(1.3), aCL = 0.75, aV = 1)),
  M3 = list(label = "Fixed allometry + Apgar < 5 on CL", free = c("lCL0", "lV0", "thA"), start = c(lCL0 = log(0.01), lV0 = log(1.3), thA = 0)),
  M4 = list(label = "Proportional to weight (CL 1, V 1)", free = c("lCL0", "lV0"), start = c(lCL0 = log(0.01), lV0 = log(1.3))),
  # M5 is post hoc (added after the original paper's abstract reported an Apgar effect on V rather than CL); it is not part of the pre-specified set and is fitted only by 02b_apgar_v.R
  M5 = list(label = "Proportional to weight + Apgar < 5 on V (post hoc)", free = c("lCL0", "lV0", "thV"), start = c(lCL0 = log(0.01), lV0 = log(1.3), thV = 0), posthoc = TRUE),
  # M6 and M7 are post hoc models with weight exponents fixed away from proportionality (05_extra.R), used to test whether the dose-rule comparison depends on the proportional-to-weight assumption
  M6 = list(label = "CL ~ WT^0.5, V ~ WT (post hoc)", free = c("lCL0", "lV0"), start = c(lCL0 = log(0.01), lV0 = log(1.3)), posthoc = TRUE),
  M7 = list(label = "CL ~ WT, V ~ WT^0.8 (post hoc)", free = c("lCL0", "lV0"), start = c(lCL0 = log(0.01), lV0 = log(1.3)), posthoc = TRUE))
# Individual-typical CL (L/h) and V (L) from the fixed effects theta (named) and covariates
typical_cl <- function(m, th, WT, APGR) {
  a <- switch(m, M0 = 0, M1 = 0.75, M2 = th[["aCL"]], M3 = 0.75, M4 = 1, M5 = 1, M6 = 0.5, M7 = 1)
  exp(th[["lCL0"]] + a * log(WT / WT_REF) + if (m == "M3") th[["thA"]] * (APGR < 5) else 0)
}
typical_v <- function(m, th, WT, APGR = NULL) { a <- switch(m, M0 = 0, M1 = 1, M2 = th[["aV"]], M3 = 1, M4 = 1, M5 = 1, M6 = 1, M7 = 0.8); exp(th[["lV0"]] + a * log(WT / WT_REF) + if (m == "M5") th[["thV"]] * (APGR < 5) else 0) }
# Pairs of (observation, earlier dose) built once: the concentration of an observation is the sum over its earlier IV bolus doses
build_pairs <- function(obs, hist) {
  key <- paste(obs$ID, obs$TIME)
  rows <- lapply(seq_len(nrow(obs)), function(i) { dd <- hist$dose[[as.character(obs$ID[i])]]; k <- which(dd$TIME <= obs$TIME[i]); data.frame(AMT = dd$AMT[k], DT = obs$TIME[i] - dd$TIME[k]) })
  list(key = key, rows = rows)
}
# nlme model function for model m: returns log concentration; PAIRS is set by the caller with assign in globalenv
make_nlme_fun <- function(m) {
  function(id, t, WT, APGR, lCL0, lV0, aCL = 0, aV = 0, thA = 0, thV = 0) {
    ks <- paste(id, t); pr <- PAIRS$rows[match(ks, PAIRS$key)]; n <- lengths(lapply(pr, `[[`, "AMT")); owner <- rep(seq_along(ks), n)
    amt <- unlist(lapply(pr, `[[`, "AMT")); dt <- unlist(lapply(pr, `[[`, "DT"))
    th <- cbind(lCL0 = lCL0, lV0 = lV0, aCL = aCL, aV = aV, thA = thA, thV = thV)
    a_cl <- switch(m, M0 = 0, M1 = 0.75, M2 = th[, "aCL"], M3 = 0.75, M4 = 1, M5 = 1, M6 = 0.5, M7 = 1); a_v <- switch(m, M0 = 0, M1 = 1, M2 = th[, "aV"], M3 = 1, M4 = 1, M5 = 1, M6 = 1, M7 = 0.8)
    cl <- exp(th[, "lCL0"] + a_cl * log(WT / WT_REF) + if (m == "M3") th[, "thA"] * (APGR < 5) else 0); v <- exp(th[, "lV0"] + a_v * log(WT / WT_REF) + if (m == "M5") th[, "thV"] * (APGR < 5) else 0); k <- cl / v
    log(as.numeric(rowsum(amt / v[owner] * exp(-k[owner] * dt), owner)[as.character(seq_along(ks)), 1]))
  }
}
fit_model <- function(m, obs, hist, start = MODELS[[m]]$start, return_object = FALSE) {
  suppressPackageStartupMessages(library(nlme))
  assign("PAIRS", build_pairs(obs, hist), envir = globalenv()); assign("WT_REF", WT_REF, envir = globalenv()); assign("fun_nlme", make_nlme_fun(m), envir = globalenv())
  def <- MODELS[[m]]; fx <- as.formula(paste(paste(def$free, collapse = " + "), "~ 1"))
  dat <- data.frame(id = obs$ID, t = obs$TIME, WT = obs$WT, APGR = obs$APGR, y = log(obs$DV))
  # parameters not in the free set are passed as zero vectors through default arguments of fun_nlme
  fml <- as.formula(paste("y ~ fun_nlme(id, t, WT, APGR,", paste0(def$free, " = ", def$free, collapse = ", "), ")"))   # named arguments: free parameters must not be matched by position
  warned <- FALSE
  f <- try(withCallingHandlers(nlme(fml, data = dat, fixed = fx, random = pdDiag(lCL0 + lV0 ~ 1), groups = ~id, start = start,
    control = nlmeControl(maxIter = 200, msMaxIter = 200, returnObject = return_object)), warning = function(w) { warned <<- TRUE; invokeRestart("muffleWarning") }), silent = TRUE)
  if (inherits(f, "try-error")) { assign("LAST_FIT_ERROR", as.character(f), envir = globalenv()); return(NULL) }
  list(fit = f, warned = warned)
}
