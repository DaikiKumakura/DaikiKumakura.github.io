import unittest
import numpy as np
from information_demo import fisher, expected_mse

class DemoTests(unittest.TestCase):
    def test_zero_time_has_no_rate_information(self):
        self.assertEqual(fisher([0]*10)[1,1],0)
    def test_single_time_is_rank_one(self):
        self.assertEqual(np.linalg.matrix_rank(fisher([1]*10)),1)
    def test_two_times_identify_two_parameters_locally(self):
        self.assertEqual(np.linalg.matrix_rank(fisher([0]*5+[1]*5)),2)
    def test_replicates_scale_information_not_rank(self):
        np.testing.assert_allclose(fisher([1]*10),10*fisher([1]))
    def test_jacobian_matches_finite_difference(self):
        t=np.array([0.,1.,2.]); e=1e-6
        j=np.column_stack(((np.exp(e)*np.exp(-t)-np.exp(-e)*np.exp(-t))/(2*e),(np.exp(-np.exp(e)*t)-np.exp(-np.exp(-e)*t))/(2*e)))
        np.testing.assert_allclose(j.T@j/.01,fisher(t),rtol=1e-8,atol=1e-8)
    def test_metric_oracle_remains_better(self):
        for g in (100,1000,10000):
            baseline,oracle=expected_mse(g)
            self.assertGreater(baseline,oracle)
            self.assertAlmostEqual(baseline-oracle,10/g)

if __name__=='__main__': unittest.main()
