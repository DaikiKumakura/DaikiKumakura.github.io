"""Deterministic illustrative calculations; not a reanalysis of cell data."""
from pathlib import Path
import csv
import json
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

ROOT = Path(__file__).resolve().parent
BLUE, ORANGE = '#0072B2', '#D55E00'

def fisher(times, amplitude=1., rate=1., sigma=.1):
    t = np.asarray(times, dtype=float)
    mu = amplitude * np.exp(-rate * t)
    jac = np.column_stack((mu, -rate * t * mu))
    return jac.T @ jac / sigma**2  # parameters: log(A), log(k)

def expected_mse(genes, affected=10, shift=1., variance=1.):
    return variance + affected * shift**2 / genes, variance

def main():
    for folder in ('figures', 'results'):
        (ROOT / folder).mkdir(exist_ok=True)
    plt.rcParams.update({'font.size': 12, 'axes.spines.top': False, 'axes.spines.right': False})
    t = np.linspace(0, 3, 301)
    fig, ax = plt.subplots(2, 1, figsize=(7, 8), layout='constrained')
    ax[0].plot(t, 100 * t**2 * np.exp(-2*t), color=BLUE, lw=2.5)
    ax[0].set(xlabel='Time (normalized)', ylabel='Information per observation', title='A. Rate information when amplitude is known', ylim=(0, 15))
    for k, color, style in ((.5, BLUE, '-'), (1.5, ORANGE, '--')):
        a = np.exp(k - 1)
        ax[1].plot(t, a*np.exp(-k*t), color=color, ls=style, lw=2.5, label=f'A={a:.3f}, k={k:.1f}')
    ax[1].scatter([1], [np.exp(-1)], color='black', zorder=4, label='Repeated sampling time')
    ax[1].set(xlabel='Time (normalized)', ylabel='Mean response (normalized)', title='B. Different parameters, same mean at time 1', ylim=(0, 1.8))
    ax[1].legend(frameon=False)
    fig.savefig(ROOT/'figures/time-information.png', dpi=180)
    plt.close(fig)
    designs = {'all_at_0': [0]*10, 'all_at_1': [1]*10, 'five_at_0_five_at_1': [0]*5+[1]*5}
    rows = []
    for name, times in designs.items():
        f = fisher(times)
        rows.append({'design': name, 'n': len(times), 'joint_rank': int(np.linalg.matrix_rank(f)), 'conditional_rate_information': float(f[1,1]), 'profile_local_rate_information': float(f[1,1]-f[1,0]**2/f[0,0])})
    with (ROOT/'results/designs.csv').open('w', newline='', encoding='utf-8') as h:
        w=csv.DictWriter(h,fieldnames=list(rows[0])); w.writeheader(); w.writerows(rows)
    genes = np.array([100, 1000, 10000])
    metric = [{'genes': int(g), 'affected':10, 'baseline_expected_mse':expected_mse(g)[0], 'oracle_expected_mse':expected_mse(g)[1], 'gap':expected_mse(g)[0]-expected_mse(g)[1]} for g in genes]
    with (ROOT/'results/metrics.csv').open('w', newline='', encoding='utf-8') as h:
        w=csv.DictWriter(h,fieldnames=list(metric[0])); w.writeheader(); w.writerows(metric)
    fig, ax=plt.subplots(figsize=(7,4.5),layout='constrained')
    ax.plot(genes, [r['gap'] for r in metric], 'o-', color=BLUE, lw=2.5)
    ax.set(xscale='log', yscale='log', xlabel='Number of evaluated genes', ylabel='Expected MSE gap (normalized squared units)', title='Fixed signal diluted across more genes')
    ax.set_xticks(genes, labels=['100','1,000','10,000'])
    ax.grid(alpha=.2)
    fig.savefig(ROOT/'figures/metric-dilution.png', dpi=180); plt.close(fig)
    (ROOT/'results/summary.json').write_text(json.dumps({'designs':rows,'metrics':metric,'assumptions':{'amplitude':1,'rate':1,'sigma':.1,'affected_genes':10,'shift':1,'noise_variance':1}}, indent=2),encoding='utf-8')
    print(json.dumps(rows, indent=2))

if __name__ == '__main__':
    main()
