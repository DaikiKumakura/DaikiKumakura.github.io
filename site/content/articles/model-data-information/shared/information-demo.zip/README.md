# Information and measurement demos

Original analytical illustrations, not empirical cell-data reanalysis.
Executed with Python 3.12.4, NumPy 1.26.4 and Matplotlib 3.9.1.

Run `python information_demo.py`, then `python -m unittest test_demo.py -q`.
The script regenerates two figures and CSV/JSON outputs without external data or randomness.
Parameters: amplitude=1, rate=1, independent normal error SD=0.1.
The MSE illustration has 10 affected genes, unit shift, independent unit error variance.
Fisher matrices use log-amplitude and log-rate parameters; the separate plotted rate curve conditions on known amplitude.
This demonstration does not reproduce any published model or benchmark.
