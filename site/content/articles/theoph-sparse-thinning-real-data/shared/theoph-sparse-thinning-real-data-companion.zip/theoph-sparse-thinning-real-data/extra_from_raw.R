# Additional summaries from results/raw.csv: warnings, boundary estimates, degenerate fits and the flip-flop choice. Run: Rscript extra_from_raw.R (after simulate.R)
script_dir <- dirname(normalizePath(sub("^--file=", "", grep("^--file=", commandArgs(FALSE), value = TRUE)[1]), winslash = "/"))
raw <- read.csv(file.path(script_dir, "results/raw.csv")); ref <- read.csv(file.path(script_dir, "results/reference.csv"))[1, ]
sd_ref <- c(w_CL = ref$w_CL, w_V = ref$w_V, w_ka = ref$w_ka, sigma = ref$sigma)
rows <- list()
for (an in c("single_start", "best_of_two")) for (ns in c(2, 3, 4, 6)) {
  m <- raw[raw$analysis == an & raw$ns == ns & raw$returned == 1, ]
  flip <- m$ka < m$ke
  b <- sapply(names(sd_ref), function(p) m[[p]] < 0.01 * sd_ref[[p]]); colnames(b) <- names(sd_ref)
  any_b <- rowSums(b) > 0; sig_deg <- b[, "sigma"]
  clean <- m$warned == 0
  nondeg <- !sig_deg
  rows[[length(rows) + 1]] <- data.frame(analysis = an, samples_per_subject = ns, returned = nrow(m),
    share_warn_few = mean(m$warn_few == 1), share_conv_warning = mean(m$warned == 1),
    share_wV_below1pct = mean(b[, "w_V"]), share_wCL_below1pct = mean(b[, "w_CL"]), share_wka_below1pct = mean(b[, "w_ka"]), share_sigma_below1pct = mean(sig_deg), share_any_sd_below1pct = mean(any_b),
    share_boundary_among_clean = mean(any_b[clean]), share_boundary_among_warned = mean(any_b[!clean]), share_sigma_deg_among_warned = mean(sig_deg[!clean]), share_sigma_deg_among_clean = mean(sig_deg[clean]),
    share_flip = mean(flip), share_flip_excl_sigma_deg = mean(flip[nondeg]), n_excl_sigma_deg = sum(nondeg), share_flip_excl_any_boundary = mean(flip[!any_b]), n_excl_any_boundary = sum(!any_b),
    median_sigma_rel = median(m$sigma / sd_ref[["sigma"]] - 1), median_sigma_rel_excl_deg = median(m$sigma[nondeg & !flip] / sd_ref[["sigma"]] - 1))
}
out <- do.call(rbind, rows); write.csv(out, file.path(script_dir, "results/extra-from-raw.csv"), row.names = FALSE)
# why does the better-of-two fit choose the flip-flop mode so often with 6 samples? compare the single-start (default) fit with the chosen fit in the resamples where the chosen fit has ka < ke
s <- raw[raw$analysis == "single_start", ]; b <- raw[raw$analysis == "best_of_two", ]; m <- merge(s, b, by = c("ns", "rep"), suffixes = c(".s", ".b"))
m$flip_b <- !is.na(m$ka.b) & m$ka.b < m$ke.b
why <- do.call(rbind, lapply(c(2, 3, 4, 6), function(n) { x <- m[m$ns == n & m$flip_b, ]
  data.frame(samples_per_subject = n, n_flip_chosen = nrow(x), share_single_returned = mean(x$returned.s == 1), share_single_warned = mean(x$warned.s == 1, na.rm = TRUE),
    share_single_sigma_below1pct = mean(x$sigma.s < 0.01 * sd_ref[["sigma"]], na.rm = TRUE), share_chosen_sigma_below1pct = mean(x$sigma.b < 0.01 * sd_ref[["sigma"]], na.rm = TRUE),
    median_loglik_gain = median(x$loglik.b - x$loglik.s, na.rm = TRUE), median_loglik_single = median(x$loglik.s, na.rm = TRUE), median_loglik_chosen = median(x$loglik.b, na.rm = TRUE)) }))
write.csv(why, file.path(script_dir, "results/flip-choice-diagnostics.csv"), row.names = FALSE)
options(width = 250); print(round(t(out[, -(1:2)]), 3)); print(why)

# Warned versus clean fits: boundary estimates (single start, returned fits) with Fisher's exact test, and the residual SD with degenerate fits removed from the reference-mode population of Table 6.
bw <- do.call(rbind, lapply(c(2, 3, 4, 6), function(n) {
  m <- raw[raw$analysis == "single_start" & raw$ns == n & raw$returned == 1, ]; warned <- m$warned == 1
  anyb <- (m$w_CL < 0.01 * sd_ref[["w_CL"]]) | (m$w_V < 0.01 * sd_ref[["w_V"]]) | (m$w_ka < 0.01 * sd_ref[["w_ka"]]) | (m$sigma < 0.01 * sd_ref[["sigma"]]); vb <- m$w_V < 0.01 * sd_ref[["w_V"]]
  tab <- function(b) table(factor(warned, c(TRUE, FALSE)), factor(b, c(TRUE, FALSE)))
  refmode <- m$ka > m$ke; deg <- m$sigma < 0.01 * sd_ref[["sigma"]]
  data.frame(samples_per_subject = n, n_warned = sum(warned), n_clean = sum(!warned),
    any_sd_boundary_warned = mean(anyb[warned]), any_sd_boundary_clean = mean(anyb[!warned]), fisher_p_any_sd = fisher.test(tab(anyb))$p.value,
    wV_boundary_warned = mean(vb[warned]), wV_boundary_clean = mean(vb[!warned]), fisher_p_wV = fisher.test(tab(vb))$p.value,
    sigma_median_dev_reference_mode = median(m$sigma[refmode] / sd_ref[["sigma"]] - 1), sigma_median_dev_reference_mode_excl_degenerate = median(m$sigma[refmode & !deg] / sd_ref[["sigma"]] - 1),
    share_wV_below1pct_reference_mode = mean(vb[refmode]), share_wV_below1pct_all_returned = mean(vb))
}))
write.csv(bw, file.path(script_dir, "results/warned-vs-clean.csv"), row.names = FALSE); print(t(round(bw, 4)))
