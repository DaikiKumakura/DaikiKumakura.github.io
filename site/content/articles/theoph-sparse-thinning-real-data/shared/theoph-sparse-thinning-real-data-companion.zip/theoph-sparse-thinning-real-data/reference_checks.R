# Checks of the dense reference fit: approximate intervals for the parameters (nlme intervals) and a refit without the random effect on V. Run: Rscript reference_checks.R
script_dir <- dirname(normalizePath(sub("^--file=", "", grep("^--file=", commandArgs(FALSE), value = TRUE)[1]), winslash = "/"))
suppressPackageStartupMessages(library(nlme))
src <- readLines(file.path(script_dir, "simulate.R")); eval(parse(text = src[grep("^WIN_BREAKS", src):grep("^START <-", src)])); eval(parse(text = src[grep("^load_theoph", src):(grep("^fit_nlme", src) - 1)]))
d <- load_theoph()
model <- function(Dose, t, lCL, lV, lka) { cl <- exp(lCL); v <- exp(lV); ka <- exp(lka); ke <- cl / v; log(Dose * ka / (v * (ka - ke)) * (exp(-ke * t) - exp(-ka * t))) }
ctl <- nlmeControl(maxIter = 100, msMaxIter = 200, returnObject = TRUE)
full <- nlme(y ~ model(Dose, Time, lCL, lV, lka), data = d, fixed = lCL + lV + lka ~ 1, random = pdDiag(lCL + lV + lka ~ 1), groups = ~Subject, start = START$default, control = ctl)
iv <- try(intervals(full, which = "var-cov"), silent = TRUE)
out <- data.frame(item = character(), lower = numeric(), estimate = numeric(), upper = numeric())
if (!inherits(iv, "try-error")) {
  re <- iv$reStruct$Subject; ei <- iv$sigma
  out <- rbind(out, data.frame(item = paste0("sd_", gsub("sd[(]|[)]", "", rownames(re))), lower = re[, "lower"], estimate = re[, "est."], upper = re[, "upper"]), data.frame(item = "sigma", lower = ei[1], estimate = ei[2], upper = ei[3]))
} else cat("intervals failed:", conditionMessage(attr(iv, "condition")), "\n")
noV <- nlme(y ~ model(Dose, Time, lCL, lV, lka), data = d, fixed = lCL + lV + lka ~ 1, random = pdDiag(lCL + lka ~ 1), groups = ~Subject, start = START$default, control = ctl)
out <- rbind(out, data.frame(item = c("loglik_full", "loglik_no_random_effect_on_V", "loglik_difference"), lower = NA, estimate = c(as.numeric(logLik(full)), as.numeric(logLik(noV)), as.numeric(logLik(full)) - as.numeric(logLik(noV))), upper = NA))
write.csv(out, file.path(script_dir, "results/reference-checks.csv"), row.names = FALSE); print(out)
