# Non-overlapping comparison: for each resample, two disjoint random subsets of the same size are drawn from each subject's 10 post-dose samples, each is fitted by nlme
# (reference start), and the two fits are compared with each other and with the dense reference. Sizes 2, 3, 4 and 5 (two subsets of 5 exhaust the 10 samples; 6 is not possible).
# The subsets are random samples of the 10 post-dose times, not drawn by time window. Run: Rscript disjoint_halves.R 200 8   (seed 20261127)
script_dir <- dirname(normalizePath(sub("^--file=", "", grep("^--file=", commandArgs(FALSE), value = TRUE)[1]), winslash = "/"))
args <- commandArgs(trailingOnly = TRUE); NREP <- if (length(args) >= 1) as.integer(args[1]) else 200L; NCORES <- if (length(args) >= 2) as.integer(args[2]) else 8L
suppressPackageStartupMessages(library(nlme)); SEED <- 20261127L
src <- readLines(file.path(script_dir, "simulate.R")); eval(parse(text = src[grep("^WIN_BREAKS", src):grep("^START <-", src)])); eval(parse(text = src[grep("^load_theoph", src):(grep("^thin <- function", src) - 1)]))
one_pair <- function(task) {
  suppressPackageStartupMessages(library(nlme)); set.seed(SEED + task$rep * 1000L + task$ns)
  parts <- lapply(split(task$data, task$data$Subject), function(s) { idx <- sample.int(nrow(s), 2 * task$ns); list(a = s[sort(idx[1:task$ns]), ], b = s[sort(idx[(task$ns + 1):(2 * task$ns)]), ]) })
  da <- do.call(rbind, lapply(parts, `[[`, "a")); db <- do.call(rbind, lapply(parts, `[[`, "b"))
  rbind(a = fit_nlme(da, START$default), b = fit_nlme(db, START$default))
}
d <- load_theoph(); ref <- fit_nlme(d, START$default)
tasks <- do.call(c, lapply(2:5, function(n) lapply(seq_len(NREP), function(r) list(rep = r, ns = n, data = d))))
cl <- parallel::makeCluster(NCORES); parallel::clusterExport(cl, c("SEED", "WIN_BREAKS", "START", "load_theoph", "fit_nlme"))
res <- parallel::parLapplyLB(cl, tasks, one_pair); parallel::stopCluster(cl)
raw <- do.call(rbind, lapply(seq_along(res), function(i) data.frame(ns = tasks[[i]]$ns, rep = tasks[[i]]$rep, half = rownames(res[[i]]), res[[i]], row.names = NULL)))
write.csv(raw, file.path(script_dir, "results/disjoint-raw.csv"), row.names = FALSE)
rows <- list()
for (n in 2:5) {
  a <- raw[raw$ns == n & raw$half == "a", ]; b <- raw[raw$ns == n & raw$half == "b", ]
  ok <- a$returned == 1 & b$returned == 1 & a$ka > a$ke & b$ka > b$ke
  for (p in c("CL", "V", "ka", "w_CL", "w_V", "w_ka", "sigma")) {
    lr <- abs(log(a[ok, p] / b[ok, p])); both_dev <- c(a[ok, p], b[ok, p]) / ref[[p]] - 1
    rows[[length(rows) + 1]] <- data.frame(samples_per_subject = n, pairs = NREP, pairs_used = sum(ok), parameter = p, median_abs_log_ratio_between_halves = median(lr[is.finite(lr)]),
      share_halves_within_20pct = mean(lr[is.finite(lr)] <= log(1.2)), median_deviation_from_reference = median(both_dev), q05_deviation = quantile(both_dev, 0.05), q95_deviation = quantile(both_dev, 0.95),
      share_each_within_20pct_of_reference = mean(abs(both_dev) <= 0.2))
  }
}
out <- do.call(rbind, rows); write.csv(out, file.path(script_dir, "results/disjoint-summary.csv"), row.names = FALSE)
options(width = 230); print(out[out$parameter %in% c("CL", "V", "ka"), ], digits = 3, row.names = FALSE)
