# Companion: thinning the Theoph dataset and refitting with nlme

Code and results for the article "How far does a population PK fit of real theophylline data move when the samples are thinned? Resampling the Theoph dataset to 2 to 6 samples per subject". The data are the Theoph dataset distributed with R; no data are downloaded.

## Files

- `simulate.R`: fits a one-compartment oral model with random effects on CL, V and ka to the dense Theoph data (the reference), then thins each of the 12 subjects to 2, 3, 4 or 6 samples drawn from four time windows and refits it 500 times per scheme, from one start and with the better of two starts (`Rscript simulate.R 500 8`; seed 20261126; writes `results/reference.csv`, `results/raw.csv`, `results/summary.csv` and `results/session-info.txt`). Uses the nlme package and base R (parallel).
- `disjoint_halves.R`: draws two disjoint random subsets of each subject's 10 samples (sizes 2 to 5), fits both and compares them with each other and with the reference (`Rscript disjoint_halves.R 200 8`; seed 20261127; writes `results/disjoint-raw.csv` and `results/disjoint-summary.csv`).
- `reference_checks.R`: approximate intervals of the dense reference fit and a refit without the random effect on V (writes `results/reference-checks.csv`).
- `extra_from_raw.R`: summaries from `results/raw.csv` (warnings, boundary estimates, degenerate fits, the choice of the flip-flop mode; writes `results/extra-from-raw.csv`, `results/flip-choice-diagnostics.csv` and `results/warned-vs-clean.csv`, which compares warned and clean fits with Fisher's exact test).
- `figures.R`: draws Figures 1 and 2 from `results/summary.csv` (requires ggplot2).
- `results/reference.csv`: the two dense fits (Table 1).
- `results/raw.csv`: the result of every resample.
- `results/summary.csv`: aggregate results for every scheme and parameter, for returned fits and clean fits (Tables 2 to 4 and the text).
- `results/session-info.txt`: R 4.5.3 session information and the nlme version.

## Reproduce

```
Rscript simulate.R 500 8
Rscript figures.R
```

Each resample uses its own seed derived from the base seed, so the results do not depend on the number of worker processes. The output depends on the random-number stream of the R version used.
