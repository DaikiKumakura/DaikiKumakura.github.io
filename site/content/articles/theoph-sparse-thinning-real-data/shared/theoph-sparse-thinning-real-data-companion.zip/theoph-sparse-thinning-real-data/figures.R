# Figures for the Theoph thinning article (Okabe-Ito palette). Run: Rscript figures.R (after simulate.R)
script_dir <- dirname(normalizePath(sub("^--file=", "", grep("^--file=", commandArgs(FALSE), value = TRUE)[1]), winslash = "/"))
suppressPackageStartupMessages(library(ggplot2))
o <- read.csv(file.path(script_dir, "results/summary.csv")); o <- o[o$analysis == "single_start" & o$subset == "returned", ]
t <- o[o$parameter %in% c("CL", "V", "ka"), ]; t$parameter <- factor(t$parameter, c("CL", "V", "ka"), c("CL", "V", "ka"))
p1 <- ggplot(t, aes(samples_per_subject, 100 * rel_dev_median)) + geom_hline(yintercept = 0, colour = "grey50") +
  geom_ribbon(aes(ymin = 100 * rel_dev_q05, ymax = 100 * rel_dev_q95), fill = "#0072B2", alpha = 0.18) + geom_line(colour = "#0072B2", linewidth = 0.9) + geom_point(colour = "#0072B2", size = 2.4) +
  facet_wrap(~parameter) + scale_x_continuous(breaks = c(2, 3, 4, 6)) +
  labs(x = "Samples per subject after thinning", y = "Estimate relative to the dense reference (%)") + theme_bw(base_size = 12)
ggsave(file.path(script_dir, "figures/figure-2-typical-values.png"), p1, width = 9.5, height = 4.4, dpi = 160)
a <- read.csv(file.path(script_dir, "results/summary.csv")); a <- a[a$subset == "returned" & a$parameter == "CL", ]
a$analysis <- factor(a$analysis, c("single_start", "best_of_two"), c("One start (CL 0.04, V 0.5, ka 0.5)", "Better of two starts (one start reaches the flip-flop mode on the full data)"))
p2 <- ggplot(a, aes(factor(samples_per_subject), 100 * share_flip_flop, fill = analysis)) + geom_col(position = position_dodge(width = 0.7), width = 0.65) +
  scale_fill_manual(values = c("#E69F00", "#009E73"), name = "Fit used") +
  labs(x = "Samples per subject after thinning", y = "Share of returned fits with ka < ke (%)") + theme_bw(base_size = 12) + theme(legend.position = "bottom") + guides(fill = guide_legend(nrow = 2))
ggsave(file.path(script_dir, "figures/figure-1-flip-flop.png"), p2, width = 9.5, height = 4.8, dpi = 160)
