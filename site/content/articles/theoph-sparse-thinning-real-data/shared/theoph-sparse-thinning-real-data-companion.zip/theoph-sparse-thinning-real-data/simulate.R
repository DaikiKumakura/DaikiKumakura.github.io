# Thinning a real dataset: Theoph (12 subjects, oral theophylline, R datasets package). The full post-dose data (10 samples per subject) are fitted by nlme with a
# one-compartment oral model with random effects on CL, V and ka; this "dense reference" is not a true value. Each subject is then thinned to 2, 3, 4 or 6 samples
# drawn at random from four time windows, the model is refitted, and the estimates are compared with the dense reference. The same 12 subjects are used in every resample.
# Run: Rscript simulate.R 500 8      (resamples per cell; worker processes; seed 20261126; each resample uses set.seed(SEED + resample * 1000 + cell))
script_dir <- dirname(normalizePath(sub("^--file=", "", grep("^--file=", commandArgs(FALSE), value = TRUE)[1]), winslash = "/"))
args <- commandArgs(trailingOnly = TRUE)
SEED <- 20261126L; NREP <- if (length(args) >= 1) as.integer(args[1]) else 500L
NCORES <- if (length(args) >= 2) as.integer(args[2]) else 8L
suppressPackageStartupMessages(library(nlme))
NS_GRID <- c(2, 3, 4, 6)
WIN_BREAKS <- c(0, 1.2, 4, 8, Inf)     # hours; windows 1 (absorption), 2, 3, 4; chosen to match the nominal sampling times of Theoph
START <- list(default = c(lCL = log(0.04), lV = log(0.5), lka = log(0.5)), far = c(lCL = log(0.3), lV = log(0.2), lka = log(1)))

load_theoph <- function() {
  d <- as.data.frame(Theoph); d$Subject <- as.integer(as.character(d$Subject)); d <- d[d$Time > 0, ]   # the pre-dose sample at time 0 cannot be log-transformed
  d$y <- log(d$conc); d$win <- as.integer(cut(d$Time, WIN_BREAKS)); d[order(d$Subject, d$Time), ]
}
fit_nlme <- function(data, start) {
  model <- function(Dose, t, lCL, lV, lka) { cl <- exp(lCL); v <- exp(lV); ka <- exp(lka); ke <- cl / v; log(Dose * ka / (v * (ka - ke)) * (exp(-ke * t) - exp(-ka * t))) }
  assign("model", model, envir = globalenv())
  warn_conv <- FALSE; warn_few <- FALSE
  f <- try(withCallingHandlers(nlme(y ~ model(Dose, Time, lCL, lV, lka), data = data, fixed = lCL + lV + lka ~ 1, random = pdDiag(lCL + lV + lka ~ 1), groups = ~Subject,
    start = start, control = nlmeControl(maxIter = 100, msMaxIter = 200, returnObject = TRUE)),
    warning = function(w) { if (grepl("fewer observations than random effects", conditionMessage(w))) warn_few <<- TRUE else warn_conv <<- TRUE; invokeRestart("muffleWarning") }), silent = TRUE)
  out <- c(returned = 0, warned = NA, warn_few = NA, CL = NA, V = NA, ka = NA, ke = NA, w_CL = NA, w_V = NA, w_ka = NA, sigma = NA, loglik = NA)
  if (inherits(f, "try-error")) return(out)
  sds <- suppressWarnings(as.numeric(VarCorr(f)[, "StdDev"])); fx <- fixef(f)
  out[c("returned", "warned", "warn_few")] <- c(1, as.numeric(warn_conv), as.numeric(warn_few))
  out[c("CL", "V", "ka", "ke", "sigma", "loglik")] <- c(exp(fx[["lCL"]]), exp(fx[["lV"]]), exp(fx[["lka"]]), exp(fx[["lCL"]] - fx[["lV"]]), f$sigma, as.numeric(logLik(f)))
  out[c("w_CL", "w_V", "w_ka")] <- sds[1:3]
  out
}
thin <- function(d, ns) {
  do.call(rbind, lapply(split(d, d$Subject), function(s) {
    if (ns <= 4) { ws <- sort(sample(4, ns)); idx <- sapply(ws, function(w) { r <- which(s$win == w); r[sample.int(length(r), 1)] }) }
    else { idx <- sapply(1:4, function(w) { r <- which(s$win == w); r[sample.int(length(r), 1)] })
           for (w in 1:2) { r <- setdiff(which(s$win == w), idx); idx <- c(idx, r[sample.int(length(r), 1)]) } }
    s[sort(idx), ]
  }))
}
one_resample <- function(task) {
  suppressPackageStartupMessages(library(nlme)); set.seed(SEED + task$rep * 1000L + task$cell)
  d <- thin(task$data, task$ns)
  a <- fit_nlme(d, START$default); b <- fit_nlme(d, START$far)
  best <- if (is.na(a["loglik"]) && is.na(b["loglik"])) a else if (is.na(b["loglik"])) a else if (is.na(a["loglik"])) b else if (b["loglik"] > a["loglik"]) b else a
  rbind(single_start = a, best_of_two = best)
}

d <- load_theoph(); ref <- fit_nlme(d, START$default)
stopifnot(ref[["returned"]] == 1, ref[["warned"]] == 0)
ref_far <- fit_nlme(d, START$far)
write.csv(data.frame(fit = c("dense_reference", "dense_far_start"), rbind(ref, ref_far), check.names = FALSE), file.path(script_dir, "results/reference.csv"), row.names = FALSE)
cells <- data.frame(ns = NS_GRID, cell = seq_along(NS_GRID))
tasks <- do.call(c, lapply(seq_len(nrow(cells)), function(i) lapply(seq_len(NREP), function(r) list(rep = r, cell = cells$cell[i], ns = cells$ns[i], data = d))))
cl <- parallel::makeCluster(NCORES); parallel::clusterExport(cl, c("SEED", "NS_GRID", "WIN_BREAKS", "START", "load_theoph", "fit_nlme", "thin"))
res <- parallel::parLapplyLB(cl, tasks, one_resample); parallel::stopCluster(cl)
raw <- do.call(rbind, lapply(seq_along(res), function(i) data.frame(ns = tasks[[i]]$ns, rep = tasks[[i]]$rep, analysis = rownames(res[[i]]), res[[i]], row.names = NULL)))
dir.create(file.path(script_dir, "results"), showWarnings = FALSE); write.csv(raw, file.path(script_dir, "results/raw.csv"), row.names = FALSE)
refv <- c(CL = ref[["CL"]], V = ref[["V"]], ka = ref[["ka"]], w_CL = ref[["w_CL"]], w_V = ref[["w_V"]], w_ka = ref[["w_ka"]], sigma = ref[["sigma"]])
rows <- list()
for (an in c("single_start", "best_of_two")) for (ns in NS_GRID) {
  m <- raw[raw$analysis == an & raw$ns == ns, ]
  for (sub in c("returned", "clean")) {
    ok <- if (sub == "returned") m$returned == 1 else (m$returned == 1 & m$warned == 0)
    flip <- ok & m$ka < m$ke                    # fit in the flip-flop mode (ka smaller than ke)
    keep <- ok & !flip
    for (p in names(refv)) {
      r <- m[keep, p] / refv[[p]] - 1
      rows[[length(rows) + 1]] <- data.frame(analysis = an, samples_per_subject = ns, subset = sub, resamples = NREP, share_returned = mean(m$returned == 1), share_clean = mean(m$returned == 1 & m$warned == 0),
        share_flip_flop = mean(flip[ok]), n_used = sum(keep), parameter = p, reference = refv[[p]], rel_dev_median = median(r), rel_dev_q05 = quantile(r, 0.05), rel_dev_q95 = quantile(r, 0.95),
        share_at_zero_1pct = mean(m[keep, p] < 0.01 * refv[[p]]), share_within_20pct = mean(abs(r) <= 0.2))
    }
  }
}
out <- do.call(rbind, rows); rownames(out) <- NULL; write.csv(out, file.path(script_dir, "results/summary.csv"), row.names = FALSE)
writeLines(c(capture.output(sessionInfo()), paste("nlme", as.character(packageVersion("nlme")))), file.path(script_dir, "results/session-info.txt"))
options(width = 230); o <- out[out$analysis == "single_start" & out$subset == "returned" & out$parameter %in% c("CL", "V", "ka"), c("samples_per_subject", "parameter", "share_returned", "share_clean", "share_flip_flop", "rel_dev_median", "rel_dev_q05", "rel_dev_q95", "share_within_20pct")]
o[3:9] <- round(o[3:9], 3); print(o, row.names = FALSE)
