"""Published reference-covariate PopPK simulation; no clinical data fitting."""
from pathlib import Path
import json
import numpy as np
import pandas as pd
from scipy.linalg import expm
from scipy.stats import norm
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
ROOT=Path(__file__).resolve().parent
SEED=20261005; N=5000; T=1/24
OMEGA=np.array([[.437**2,.535*.437*.387],[.535*.437*.387,.387**2]])
plt.rcParams.update({'font.size':10,'axes.spines.top':False,'axes.spines.right':False,'figure.dpi':120})
def coefficients(cl,vc,q=1.11,vp=5.06):
 k10=cl/vc;k12=q/vc;k21=q/vp;s=k10+k12+k21
 alpha=(s+np.sqrt(s*s-4*k10*k21))/2;beta=(s-np.sqrt(s*s-4*k10*k21))/2
 return alpha,beta,(alpha-k21)/(alpha-beta)
def concentration(t,doses,cl,vc,q=1.11,vp=5.06):
 t=np.asarray(t);cl=np.atleast_1d(cl);vc=np.atleast_1d(vc);a,b,w=coefficients(cl,vc,q,vp)
 out=np.zeros((len(cl),t.size))
 for day,dose in doses:
  dt=np.maximum(t-day,0)[None,:];u=np.minimum(dt,T);v=np.maximum(dt-T,0)
  out+=dose/(T*vc[:,None])*((w/a)[:,None]*(-np.expm1(-a[:,None]*u))*np.exp(-a[:,None]*v)+((1-w)/b)[:,None]*(-np.expm1(-b[:,None]*u))*np.exp(-b[:,None]*v))
 return out*1000
def auc_until(end,doses,cl,vc,q=1.11,vp=5.06):
 cl=np.atleast_1d(cl);vc=np.atleast_1d(vc);a,b,w=coefficients(cl,vc,q,vp);out=cl*0
 for day,dose in doses:
  dt=max(end-day,0);u=min(dt,T);v=max(dt-T,0)
  def integral(lam):return u/lam+np.expm1(-lam*u)/lam**2+(-np.expm1(-lam*u))*(-np.expm1(-lam*v))/lam**2
  out+=dose/(T*vc)*(w*integral(a)+(1-w)*integral(b))
 return out*1000
def ss(dose,tau,cl,vc,q=1.11,vp=5.06):
 a,b,w=coefficients(np.asarray(cl),np.asarray(vc),q,vp)
 x=dose/(T*np.asarray(vc))*w*(-np.expm1(-a*T))/a/(-np.expm1(-a*tau))
 y=dose/(T*np.asarray(vc))*(1-w)*(-np.expm1(-b*T))/b/(-np.expm1(-b*tau))
 return np.array([dose/np.asarray(cl)/tau*1000,(x+y)*1000,(x*np.exp(-a*(tau-T))+y*np.exp(-b*(tau-T)))*1000])
def savefig(fig,name):fig.tight_layout();fig.savefig(ROOT/'figures'/name);plt.close(fig)
def run():
 for d in ['results','figures','data']:(ROOT/d).mkdir(exist_ok=True)
 rng=np.random.default_rng(SEED);eta=rng.multivariate_normal([0,0],OMEGA,N);cl=.649*np.exp(eta[:,0]);vc=3.44*np.exp(eta[:,1])
 base=[(0,1),(7,10),(14,10),(28,10),(42,10)]
 # Exact solution independently checked against matrix exponential.
 M=np.array([[-(.649+1.11)/3.44,1.11/5.06],[1.11/3.44,-1.11/5.06]])
 B=np.array([1/T,0]);end=np.linalg.solve(M,(expm(M*T)-np.eye(2)))@B
 tests={}
 for day in [T,.5,7,14]:
  expected=(expm(M*(day-T))@end)[0]/3.44*1000
  actual=concentration([day],[(0,1)],.649,3.44)[0,0]
  assert np.isclose(actual,expected,rtol=1e-11)
 tests['matrix_exponential_agreement']=True
 assert np.isclose(auc_until(1000,[(0,1)],.649,3.44)[0],1000/.649,rtol=1e-10)
 tests['single_dose_mass_balance']=True
 assert np.allclose(np.cov(eta.T),OMEGA,rtol=.07,atol=.004)
 tests['empirical_eta_covariance']=np.cov(eta.T).tolist()
 rows=[]
 label={'first_1mg':[106,314,49],'first_10mg':[1100,3190,517],'steady_10mg_Q2W':[1040,3640,472]}
 for name in label:
  if name.startswith('steady'):typ=ss(10,14,.649,3.44).reshape(3,1);pop=ss(10,14,cl,vc)
  else:
   start,stop=(0,7) if name=='first_1mg' else (7,14)
   def metrics(c,v):return np.vstack([(auc_until(stop,base,c,v)-auc_until(start,base,c,v))/(stop-start),concentration([start+T],base,c,v)[:,0],concentration([stop],[(d,x) for d,x in base if d<stop],c,v)[:,0]])
   typ=metrics(.649,3.44);pop=metrics(cl,vc)
  for j,endpoint in enumerate(['Cavg','Cmax','Ctrough']):rows.append(dict(window=name,endpoint=endpoint,label_mean=label[name][j],reference_typical=typ[j,0],virtual_mean=pop[j].mean(),virtual_median=np.median(pop[j]),virtual_p05=np.quantile(pop[j],.05),virtual_p95=np.quantile(pop[j],.95),typical_difference_pct=(typ[j,0]/label[name][j]-1)*100))
 pk=pd.DataFrame(rows);pk.to_csv(ROOT/'results/pk-check.csv',index=False)
 c1=auc_until(28,base,cl,vc)/28
 pd.DataFrame({'CL_L_day':cl,'Vc_L':vc,'Cavg_cycle1_ng_ml':c1}).to_csv(ROOT/'results/virtual-subjects.csv',index=False)
 time=np.unique(np.r_[np.linspace(0,56,1200),[d+T for d,_ in base]])
 profile=concentration(time,base,cl,vc);fig,ax=plt.subplots(figsize=(8,3.6));p=np.quantile(profile,[.05,.5,.95],axis=0)
 ax.fill_between(time,p[0],p[2],color='#d9e8ef',label='5–95% virtual subjects');ax.plot(time,p[1],color='#215e78',label='Virtual median');ax.plot(time,concentration(time,base,.649,3.44)[0],color='#ad5d32',ls='--',label='Reference typical');ax.set(xlabel='Time from first infusion (days)',ylabel='Concentration (ng/mL)');ax.legend(fontsize=8);savefig(fig,'01-pk.png')
 crs=[];z=norm.ppf(.975)
 for window,events,days in [('C1D1–7',54,7),('C1D8–14',39,7),('C1D15–28',10,14)]:
  n=133;p=events/n;center=(p+z*z/(2*n))/(1+z*z/n);half=z*np.sqrt(p*(1-p)/n+z*z/(4*n*n))/(1+z*z/n)
  crs.append(dict(window=window,events=events,denominator=n,window_days=days,proportion=p,wilson_lower=center-half,wilson_upper=center+half))
 crs=pd.DataFrame(crs);crs.to_csv(ROOT/'data/crs-counts.csv',index=False)
 fig,axes=plt.subplots(1,2,figsize=(8,3.5));x=np.arange(3)
 peaks=[np.median(concentration([d+T],base,cl,vc)) for d in [0,7,14]]
 axes[0].bar(x,peaks,color='#215e78');axes[0].set(ylabel='Virtual median Cmax (ng/mL)',xticks=x,xticklabels=['1 mg, D1','10 mg, D8','10 mg, D15'])
 axes[1].errorbar(x,crs.proportion*100,yerr=np.vstack([(crs.proportion-crs.wilson_lower)*100,(crs.wilson_upper-crs.proportion)*100]),fmt='o',color='#ad5d32',capsize=4)
 axes[1].set(ylabel='All-grade CRS in window (%)',xticks=x,xticklabels=['D1–7','D8–14','D15–28'],ylim=(0,60));savefig(fig,'02-crs.png')
 ref=ss(10,14,cl,vc);maint=[]
 for dose,tau in [(10,14),(10,21),(10,28),(15,21),(20,28)]:
  v=ss(dose,tau,cl,vc);typ=ss(dose,tau,.649,3.44)
  for j,key in enumerate(['Cavg','Cmax','Ctrough']):
   ratio=v[j]/ref[j];maint.append(dict(dose_mg=dose,interval_days=tau,endpoint=key,typical_ng_ml=typ[j],virtual_median_ng_ml=np.median(v[j]),ratio_median=np.median(ratio),ratio_p05=np.quantile(ratio,.05),ratio_p95=np.quantile(ratio,.95)))
 maint=pd.DataFrame(maint);maint.to_csv(ROOT/'results/maintenance.csv',index=False)
 fig,axes=plt.subplots(1,3,figsize=(9,3.5))
 for ax,key in zip(axes,['Cavg','Cmax','Ctrough']):
  v=maint[maint.endpoint==key];ax.errorbar(np.arange(5),v.ratio_median,yerr=np.vstack([v.ratio_median-v.ratio_p05,v.ratio_p95-v.ratio_median]),fmt='o',capsize=3,color='#215e78');ax.axhline(1,color='gray',ls=':');ax.set(title=key,xticks=np.arange(5),xticklabels=['10/14','10/21','10/28','15/21','20/28'],ylabel='Paired ratio to 10 mg / 14 d');ax.tick_params(axis='x',rotation=40)
 savefig(fig,'03-maintenance.png')
 e=np.geomspace(1,10000,400);fig,ax=plt.subplots(figsize=(8,3.5))
 for key,emax,ec50,lo,hi,color in [('ORR',.339,57.4,22.5,146,'#ad5d32'),('DCR',.650,49.4,20.9,117,'#215e78')]:
  ax.plot(e,emax*e/(ec50+e)*100,color=color,label=key+' published Emax')
  ax.fill_between(e,emax*e/(hi+e)*100,emax*e/(lo+e)*100,color=color,alpha=.12)
  ax.axvline(9*ec50,color=color,ls=':',alpha=.6)
 ax.set(xscale='log',xlabel='Cycle 1 Cavg (ng/mL)',ylabel='Model probability (%)',ylim=(0,75));ax.legend(fontsize=8);savefig(fig,'04-efficacy.png')
 sensitivity=[]
 from itertools import product
 for c,v,q,vp in product([.616,.682],[3.25,3.62],[.874,1.34],[4.4,5.71]):
  for dose,tau in [(10,21),(10,28),(15,21),(20,28)]:
   ratio=ss(dose,tau,c,v,q,vp)/ss(10,14,c,v,q,vp)
   sensitivity.append(dict(CL=c,Vc=v,Q=q,Vp=vp,dose_mg=dose,interval_days=tau,Cavg_ratio=ratio[0],Cmax_ratio=ratio[1],Ctrough_ratio=ratio[2]))
 pd.DataFrame(sensitivity).to_csv(ROOT/'results/fixed-effect-sensitivity.csv',index=False)
 tests.update(seed=SEED,n=N,clinical_parameter_fitting=False,reference_covariates='73 kg; White; binding ADA negative',residual_error_added=False,steady_state_average_identity=True)
 (ROOT/'results/validation.json').write_text(json.dumps(tests,indent=2),encoding='utf8')
 print(pk.round(2).to_string(index=False));print(maint.round(3).to_string(index=False));print(crs.round(4).to_string(index=False))
 return pk,maint,crs
if __name__=='__main__':run()
