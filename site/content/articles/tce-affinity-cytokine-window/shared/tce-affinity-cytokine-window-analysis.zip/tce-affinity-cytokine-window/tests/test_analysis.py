from pathlib import Path
import sys,unittest
import numpy as np
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'src'));sys.path.insert(0,str(ROOT/'analysis'))
from windows import feasible_intervals,width,interpolate,fit_hill,predict_hill
from run import normalized

class WindowTests(unittest.TestCase):
    def test_exact_loglinear_crossings(self):
        result=feasible_intervals(np.array([1.,100.]),np.array([0.,1.]),np.array([0.,1.]),.4,.7)
        np.testing.assert_allclose(result,[[10**.8,10**1.4]])
        self.assertAlmostEqual(width(result),.6)
    def test_disjoint_and_nonmonotonic(self):
        c=np.array([1.,10.,100.,1000.]);e=np.ones(4);t=np.array([0.,1.,1.,0.])
        result=feasible_intervals(c,e,t,.8,.25)
        self.assertEqual(len(result),2)
        self.assertAlmostEqual(width(result),.5)
    def test_no_window_not_zero_effect(self):
        self.assertEqual(feasible_intervals(np.array([1.,10.]),np.array([0.,.7]),np.zeros(2)),[])
    def test_no_extrapolation(self):
        with self.assertRaises(ValueError):interpolate([1,10],[0,1],[.1])
    def test_background_and_scale_invariance(self):
        curves={}
        for endpoint in ['kill','tnf']:
            for binder in ['high','low']:
                curves[('T','high',binder,endpoint)]=dict(c=np.array([1.,10.,100.]),y=np.array([100.,130.,160.]) if binder=='high' else np.array([300.,320.,340.]))
        first,_=normalized(curves,('T','high'),'low')
        changed={k:{**v,'y':v['y']*10+1234} for k,v in curves.items()}
        second,_=normalized(changed,('T','high'),'low')
        for ep in ['kill','tnf']:np.testing.assert_allclose(first[ep][1],second[ep][1])
        self.assertAlmostEqual(first['kill'][1][-1],2/3)
    def test_reference_is_not_each_molecules_own_maximum(self):
        curves={('T','high',b,e):dict(c=np.array([1.,10.,100.]),y=np.array([5.,5.+a/2,5.+a])) for b,a in [('high',100),('low',10)] for e in ['kill','tnf']}
        n,_=normalized(curves,('T','high'),'low')
        self.assertAlmostEqual(n['kill'][1][-1],.1)
    def test_hill_recovery_and_fixed_baseline(self):
        c=np.geomspace(.05,5000,16);theta=np.array([np.log(.9),np.log(30.)]);y=predict_hill(theta,c,c.min(),1.)
        recovered=fit_hill(c,y,1.)
        np.testing.assert_allclose(predict_hill(recovered,c,c.min(),1.),y,atol=1e-6)
        self.assertAlmostEqual(predict_hill(recovered,c.min(),c.min(),1.),0)
if __name__=='__main__':unittest.main()
