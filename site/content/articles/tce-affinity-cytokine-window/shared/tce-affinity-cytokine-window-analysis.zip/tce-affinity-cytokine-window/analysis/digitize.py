"""Digitize published observed square centers; never treat fitted lines as data."""
from pathlib import Path
import csv,json
from PIL import Image,ImageDraw
ROOT=Path(__file__).resolve().parents[1]
# Native 800px-wide source JPEG coordinates. yvalue endpoints are raw plotted AUCE.
# X coordinates identify nominal 1:10 serial concentrations specified in captions.
CONFIG={
 1:dict(target='FOLR1',ta='high',ta_kd_nm=57,cell='SK-OV-3',abc=90000,
   kill=dict(x=[158,203,248,293,338,384],c=[.05,.5,5,50,500,5000],y0=171.5,v0=1.5e6,y1=65.5,v1=2.5e6,
     points={'high':[168,141,102,76,68,60],'intermed':[184,172,135,92,73,73],'low':[181,183,175,155,133,124],'vlow':[181,181,181,172,164,154]}),
   tnf=dict(x=[545,590,636,681,726,772],c=[.05,.5,5,50,500,5000],y0=193,v0=0,y1=12,v1=6000,
     points={'high':[191,161,97,45,55,89],'intermed':[193,191,180,151,140,145],'low':[193,193,192,190,187,187],'vlow':[193,193,193,193,193,193]})),
 2:dict(target='FOLR1',ta='low',ta_kd_nm=1000,cell='SK-OV-3',abc=90000,
   kill=dict(x=[148,193,238,283,328,373],c=[.05,.5,5,50,500,5000],y0=170,v0=1e6,y1=65,v1=2e6,
     points={'high':[175,177,178,157,85,44],'intermed':[173,182,181,183,167,99],'low':[181,181,177,181,180,159],'vlow':[179,180,175,182,182,163]}),
   tnf=dict(x=[548,593,638,683,728,773],c=[.05,.5,5,50,500,5000],y0=190,v0=0,y1=12,v1=2000,
     points={'high':[190,189,189,182,122,58],'intermed':[190,190,190,190,187,171],'low':[190,190,190,190,190,189],'vlow':[190,190,190,190,190,190]})),
 5:dict(target='CEACAM5',ta='high',ta_kd_nm=.1,cell='LS-180',abc=76000,
   kill=dict(x=[139,184,229,274,319,364],c=[.05,.5,5,50,500,5000],y0=171,v0=2e6,y1=91,v1=4e6,
     points={'high':[190,175,149,54,42,67],'intermed':[185,185,156,109,None,52],'low':[186,185,175,145,80,79],'vlow':[185,185,183,139,131,137]}),
   tnf=dict(x=[551,605,658,712,766],c=[.5,5,50,500,5000],y0=202,v0=0,y1=12,v1=5000,
     points={'high':[202,200,146,37,36],'intermed':[202,202,197,162,138],'low':[202,202,202,193,184],'vlow':[202,202,202,202,201]})),
 6:dict(target='CEACAM5',ta='low',ta_kd_nm=5.5,cell='LS-180',abc=76000,
   kill=dict(x=[129,174,219,264,309,354],c=[.05,.5,5,50,500,5000],y0=161,v0=2e6,y1=86,v1=4e6,
     points={'high':[177,174,168,106,41,42],'intermed':[174,174,174,146,82,47],'low':[175,175,175,163,123,95],'vlow':[177,175,175,170,162,134]}),
   tnf=dict(x=[549,602,656,711,765],c=[.5,5,50,500,5000],y0=192,v0=0,y1=17,v1=6000,
     points={'high':[192,191,183,87,13],'intermed':[192,192,192,184,151],'low':[192,192,192,190,181],'vlow':[192,192,192,192,192]})),
}
KD={'high':1.56,'intermed':29.1,'low':41.,'vlow':82.4}
def main():
    out=ROOT/'data/processed';out.mkdir(parents=True,exist_ok=True)
    checks=ROOT/'verification';checks.mkdir(exist_ok=True)
    rows=[]
    for fig,cfg in CONFIG.items():
        image=Image.open(ROOT/f'data/raw/KMAB_A_2584374_F000{fig}_OC.jpg').convert('RGB');draw=ImageDraw.Draw(image)
        for endpoint in ['kill','tnf']:
            p=cfg[endpoint]
            for binder,ys in p['points'].items():
                assert len(ys)==len(p['c'])
                for i,(x,y,c) in enumerate(zip(p['x'],ys,p['c'])):
                    if y is None:continue
                    value=p['v0']+(p['v1']-p['v0'])*(y-p['y0'])/(p['y1']-p['y0'])
                    rows.append(dict(target=cfg['target'],ta=cfg['ta'],ta_kd_nm=cfg['ta_kd_nm'],cell=cfg['cell'],abc=cfg['abc'],
                        cd3=binder,cd3_kd_nm=KD[binder],endpoint=endpoint,concentration_pm=c,auce=value,
                        source=f'Figure{fig}',point_id=f'{fig}-{endpoint}-{binder}-{i+1}',x_px=x,y_px=y,
                        reading_quality='overlap_or_low_signal' if i<2 or abs(y-ys[0])<=4 else 'visible_symbol_center',
                        units='published AUCE axis units',value_per_y_pixel=(p['v1']-p['v0'])/(p['y1']-p['y0'])))
                    draw.rectangle((x-4,y-4,x+4,y+4),outline='red',width=1)
        image.crop((0,0,800,245)).resize((1600,490)).save(checks/f'figure{fig}-readback.png')
    with (out/'observed-points.csv').open('w',newline='',encoding='utf-8') as f:
        w=csv.DictWriter(f,fieldnames=rows[0]);w.writeheader();w.writerows(rows)
    with (out/'exclusions.csv').open('w',newline='',encoding='utf-8') as f:
        w=csv.DictWriter(f,fieldnames=['source','endpoint','cd3','concentration_pm','reason']);w.writeheader()
        w.writerow(dict(source='Figure5A',endpoint='kill',cd3='intermed',concentration_pm=500,reason='No individually identifiable blue observed square; fitted curve not used as observation'))
    (out/'digitization.json').write_text(json.dumps(dict(points=len(rows),curves=32,contexts=4,
        concentration_source='nominal serial dilution from captions and symbol x positions',
        reading_bound_native_pixels=2,biological_replicates_recovered=False),indent=2)+'\n')
    print('Observed symbols:',len(rows),'curves:',32)
if __name__=='__main__':main()
