"""Compare in-range efficacy/TNF screening criteria with explicit assumptions."""
from pathlib import Path
import sys,csv,json
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'src'))
from windows import interpolate,feasible_intervals,width,fit_hill,predict_hill
SEED=2026102607
READING_DRAWS=128
BINDERS=['high','intermed','low','vlow']
CONTEXTS=[('FOLR1','high'),('FOLR1','low'),('CEACAM5','high'),('CEACAM5','low')]
COLORS=['#222222','#56A5E8','#8822AA','#F64BA3']
OUT=ROOT/'outputs'
for d in ['figures','tables']: (OUT/d).mkdir(parents=True,exist_ok=True)

def save_csv(name,rows):
    with (OUT/'tables'/name).open('w',newline='',encoding='utf-8') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)

def load():
    with (ROOT/'data/processed/observed-points.csv').open(encoding='utf-8') as f:rows=list(csv.DictReader(f))
    curves={}
    for row in rows:
        k=(row['target'],row['ta'],row['cd3'],row['endpoint']);curves.setdefault(k,[]).append(row)
    return {k:dict(c=np.array([float(r['concentration_pm']) for r in v]),y=np.array([float(r['auce']) for r in v]),
        pixel=float(v[0]['value_per_y_pixel']),ta_kd_nm=float(v[0]['ta_kd_nm'])) for k,v in curves.items()}

def normalized(curves,context,binder,anchor='local',baseline='first'):
    target,ta=context;out={};meta=[]
    for endpoint in ['kill','tnf']:
        series=curves[(target,ta,binder,endpoint)]
        reference=curves[(target,ta if anchor=='local' else 'high','high',endpoint)]
        b=series['y'][0] if baseline=='first' else min(series['y'][:2])
        rb=reference['y'][0] if baseline=='first' else min(reference['y'][:2])
        scale=max(reference['y'])-rb
        assert scale>0
        out[endpoint]=(series['c'],(series['y']-b)/scale)
        meta.append(dict(target=target,ta=ta,cd3=binder,endpoint=endpoint,baseline=b,reference_increment=scale,anchor=anchor))
    return out,meta

def knots(norm):
    a,b=norm['kill'],norm['tnf'];lo=max(a[0].min(),b[0].min());hi=min(a[0].max(),b[0].max())
    c=np.unique(np.r_[a[0],b[0]]);c=c[(c>=lo)&(c<=hi)]
    return c,interpolate(*a,c),interpolate(*b,c)

def summarize(context,binder,c,e,t,method='interpolation',alpha=.8,beta=.25,observed=None):
    intervals=feasible_intervals(c,e,t,alpha,beta)
    return dict(target=context[0],ta=context[1],cd3=binder,method=method,alpha=alpha,beta=beta,
        intervals_pm=json.dumps(intervals),log10_width=float(width(intervals)),
        positive_width=bool(intervals),tested_doses_passing=int(np.sum((observed[0]>=alpha)&(observed[1]<=beta))) if observed is not None else '',
        min_pm=intervals[0][0] if intervals else '',max_pm=intervals[-1][1] if intervals else '')

def main():
    curves=load();assert len(curves)==32
    primary=[];normrows=[];references=[];sensitivity=[];parameters=[];normalized_curves={};equal_effect=[]
    for ctx in CONTEXTS:
        for binder in BINDERS:
            norm,meta=normalized(curves,ctx,binder);references.extend(meta);normalized_curves[(*ctx,binder)]=norm
            c,e,t=knots(norm)
            actual=np.intersect1d(norm['kill'][0],norm['tnf'][0])
            observed=(interpolate(*norm['kill'],actual),interpolate(*norm['tnf'],actual))
            primary.append(summarize(ctx,binder,c,e,t,observed=observed))
            for concentration,eff,tnf in zip(c,e,t):normrows.append(dict(target=ctx[0],ta=ctx[1],cd3=binder,concentration_pm=concentration,relative_tdcc=eff,relative_tnf=tnf))
            # Earliest in-range crossing of the relative efficacy criterion.
            achieved=feasible_intervals(c,e,np.zeros(len(c)),.8,1.)
            ce=achieved[0][0] if achieved else None
            equal_effect.append(dict(target=ctx[0],ta=ctx[1],cd3=binder,relative_tdcc_goal=.8,
                concentration_pm=ce if ce else '',relative_tnf_at_goal=float(interpolate(c,t,ce)) if ce else ''))
            for alpha in [.5,.7,.8,.9]:
                for beta in [.1,.25,.5]:sensitivity.append(summarize(ctx,binder,c,e,t,'threshold_grid',alpha,beta))
            for anchor,base,method in [('high_ta','first','common_high_ta_anchor'),('local','min2','lowest_two_minimum')]:
                n,_=normalized(curves,ctx,binder,anchor=anchor,baseline=base);cc,ee,tt=knots(n)
                sensitivity.append(summarize(ctx,binder,cc,ee,tt,method))
            for h in [.5,1.,2.]:
                vals={}
                grid=np.geomspace(c.min(),c.max(),1001)
                for endpoint in ['kill','tnf']:
                    cc,yy=norm[endpoint];theta=fit_hill(cc,yy,h)
                    vals[endpoint]=predict_hill(theta,grid,cc.min(),h)
                    parameters.append(dict(target=ctx[0],ta=ctx[1],cd3=binder,endpoint=endpoint,fixed_h=h,
                        fitted_increment=float(np.exp(theta[0])),ec50_pm=float(np.exp(theta[1])),
                        ec50_within_observed=bool(cc.min()<=np.exp(theta[1])<=cc.max()),
                        descriptive_rmse=float(np.sqrt(np.mean((predict_hill(theta,cc,cc.min(),h)-yy)**2)))))
                sensitivity.append(summarize(ctx,binder,grid,vals['kill'],vals['tnf'],f'Hill_h{h:g}'))
    save_csv('normalized-points.csv',normrows);save_csv('baseline-references.csv',references)
    save_csv('screening-windows.csv',primary);save_csv('sensitivity-windows.csv',sensitivity)
    save_csv('equal-effect.csv',equal_effect);save_csv('hill-sensitivity-parameters.csv',parameters)
    rng=np.random.default_rng(SEED);scenarios={(*ctx,b):[] for ctx in CONTEXTS for b in BINDERS}
    for _ in range(READING_DRAWS):
        modified={k:{**v,'y':v['y']+rng.uniform(-2,2,len(v['y']))*v['pixel']} for k,v in curves.items()}
        for ctx in CONTEXTS:
            for b in BINDERS:
                n,_=normalized(modified,ctx,b);c,e,t=knots(n)
                scenarios[(*ctx,b)].append(width(feasible_intervals(c,e,t)))
    reading=[dict(target=k[0],ta=k[1],cd3=k[2],scenarios=READING_DRAWS,pixel_bound=2,
        scenarios_positive_width=int(np.sum(np.array(v)>0)),min_log10_width=float(min(v)),max_log10_width=float(max(v))) for k,v in scenarios.items()]
    save_csv('reading-sensitivity.csv',reading)
    result=dict(seed=SEED,points=sum(len(v['c']) for v in curves.values()),curves=32,contexts=4,primary=primary,equal_effect=equal_effect,reading=reading,
        positive_windows=sum(r['positive_width'] for r in primary),
        out_of_range_ec50_sensitivity_fits=sum(not r['ec50_within_observed'] for r in parameters),
        interpretation='Relative baseline-adjusted AUCE screening, not percent cell death or CRS probability')
    (OUT/'results.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
    plt.rcParams.update({'font.size':10,'axes.spines.top':False,'axes.spines.right':False,'svg.fonttype':'none'})
    fig,axes=plt.subplots(2,2,figsize=(10,7.3),layout='constrained')
    for ax,ctx in zip(axes.flat,CONTEXTS):
        for b,color in zip(BINDERS,COLORS):
            n=normalized_curves[(*ctx,b)]
            c,e,t=knots(n);ax.plot(e,t,'-',color=color,label='CD3 '+b,lw=1.4)
            actual=np.intersect1d(n['kill'][0],n['tnf'][0])
            ax.scatter(interpolate(*n['kill'],actual),interpolate(*n['tnf'],actual),color=color,marker='s',s=20)
        ax.axvline(.8,color='gray',ls='--',lw=1);ax.axhline(.25,color='gray',ls='--',lw=1)
        ax.set(xlabel='Relative TDCC AUCE increment',ylabel='Relative TNF AUCE increment',xlim=(-.1,1.1),ylim=(-.08,1.1),
            title=f'{ctx[0]} | TA {ctx[1]}')
    axes[0,0].legend(fontsize=8)
    save(fig,'01-observed-tradeoffs')
    fig,axes=plt.subplots(1,2,figsize=(11,6),layout='constrained')
    for i,ctx in enumerate(CONTEXTS):
        for j,b in [(1,'intermed')]:
            row=next(r for r in primary if (r['target'],r['ta'],r['cd3'])==(*ctx,b))
            pos=i;intervals=json.loads(row['intervals_pm'])
            for lo,hi in intervals:axes[0].plot([lo,hi],[pos,pos],lw=5,color=COLORS[j],solid_capstyle='butt')
            if not intervals:axes[0].text(.8,pos,'none',fontsize=8,color='gray')
            n=normalized_curves[(*ctx,b)]
            c=np.intersect1d(n['kill'][0],n['tnf'][0]);e=interpolate(*n['kill'],c);t=interpolate(*n['tnf'],c);ok=(e>=.8)&(t<=.25)
            axes[0].scatter(c[ok],np.repeat(pos,np.sum(ok)),color='black',s=13,zorder=3)
    labels=[f'{ctx[0]} {ctx[1]} / {b}' for ctx in CONTEXTS for b in BINDERS]
    pos=list(range(4))
    axes[0].set(yticks=pos,yticklabels=[f'{ctx[0]} TA {ctx[1]}' for ctx in CONTEXTS],xscale='log',xlim=(.4,6500),xlabel='Concentration (pM)',title='CD3 intermed | TDCC >= 0.8 and TNF <= 0.25')
    axes[0].invert_yaxis()
    for i,(b,color) in enumerate(zip(BINDERS,COLORS)):
        for j,ctx in enumerate(CONTEXTS):
            r=next(r for r in equal_effect if (r['target'],r['ta'],r['cd3'])==(*ctx,b))
            if r['concentration_pm']!='':axes[1].scatter(r['concentration_pm'],r['relative_tnf_at_goal'],color=color,marker=['o','s','^','D'][j],s=55,label=f'{ctx[0]} {ctx[1]} / {b}')
    axes[1].axhline(.25,color='gray',ls='--');axes[1].set(xscale='log',xlabel='First concentration reaching TDCC 0.8 (pM)',ylabel='Relative TNF AUCE at that concentration',title='Same relative efficacy; local reference')
    axes[1].legend(fontsize=6.5,loc='best',ncol=2)
    save(fig,'02-screening-windows')
    methods=['interpolation','Hill_h0.5','Hill_h1','Hill_h2','common_high_ta_anchor','lowest_two_minimum']
    matrix=[]
    for ctx in CONTEXTS:
        for b in BINDERS:
            matrix.append([next(r['log10_width'] for r in primary+sensitivity if (r['target'],r['ta'],r['cd3'],r['method'])==(*ctx,b,m)) for m in methods])
    fig,ax=plt.subplots(figsize=(10,7),layout='constrained');im=ax.imshow(matrix,aspect='auto',cmap='cividis',vmin=0)
    for i,row in enumerate(matrix):
        for j,v in enumerate(row):ax.text(j,i,f'{v:.2f}',ha='center',va='center',fontsize=8,color='white' if v<max(map(max,matrix))*.55 else 'black')
    ax.set(yticks=range(16),yticklabels=labels,xticks=range(6),xticklabels=['Observed\ninterpolation','Hill h=0.5','Hill h=1','Hill h=2','Common high-TA\nreference','Minimum of\nlowest 2 doses'],title='Screening interval width | log10 concentration units')
    fig.colorbar(im,ax=ax,label='Sum of log10(upper/lower) over eligible intervals')
    save(fig,'03-assumption-sensitivity')
    print(json.dumps({k:v for k,v in result.items() if k not in ['primary','equal_effect','reading']},indent=2))

def save(fig,name):
    for ext in ['png','svg']:
        p=OUT/'figures'/f'{name}.{ext}';fig.savefig(p,dpi=180)
        if ext=='svg':p.write_text('\n'.join(s.rstrip() for s in p.read_text(encoding='utf-8').splitlines())+'\n',encoding='utf-8')
    plt.close(fig)
if __name__=='__main__':main()
