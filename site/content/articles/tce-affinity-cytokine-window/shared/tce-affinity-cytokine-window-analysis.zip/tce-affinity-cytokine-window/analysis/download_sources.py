"""Retrieve open primary figures; keep existing raw files unmodified."""
from pathlib import Path
from zipfile import ZipFile
import urllib.request,io,hashlib,json
ROOT=Path(__file__).resolve().parents[1]
URL='https://www.ebi.ac.uk/europepmc/webservices/rest/PMC12599352/supplementaryFiles'
NAMES=[f'KMAB_A_2584374_F000{i}_OC.jpg' for i in [1,2,5,6]]
def main():
    raw=ROOT/'data/raw';raw.mkdir(parents=True,exist_ok=True)
    missing=[n for n in NAMES if not (raw/n).exists()]
    if missing:
        data=urllib.request.urlopen(URL,timeout=90).read()
        with ZipFile(io.BytesIO(data)) as z:
            for name in missing:
                choices=[n for n in z.namelist() if Path(n).name==name]
                assert len(choices)==1
                (raw/name).write_bytes(z.read(choices[0]))
    source=json.loads((ROOT/'source-provenance.json').read_text(encoding='utf-8'))
    for name in NAMES:
        digest=hashlib.sha256((raw/name).read_bytes()).hexdigest()
        assert digest==source['image_sha256'][name],name
        print(name,digest)
if __name__=='__main__':main()
