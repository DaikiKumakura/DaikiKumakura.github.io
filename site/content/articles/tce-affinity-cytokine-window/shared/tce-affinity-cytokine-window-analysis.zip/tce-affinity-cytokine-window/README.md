# TCE affinity and cytokine screening

Companion analysis of Abdelmotaleb et al., mAbs (2025), DOI
https://doi.org/10.1080/19420862.2025.2584374 . Figures1/2/5/6A/B report
time-integrated AUCE for TDCC and TNFalpha, not percent cell death or CRS risk.
The numerical input is manual observed-marker digitization, not author-supplied
individual donor data. Fitted source lines are excluded.

Source material is CC BY-NC 4.0:
https://creativecommons.org/licenses/by-nc/4.0/ . Digitization and new quantitative
figures are adaptations. Preserve attribution and the noncommercial restriction.
The original article, supplements, and BioRender images are not redistributed here.
This companion is for noncommercial research and learning.

The existing workspace Python scientific environment is reused without installing
packages. On another machine use an isolated Python environment and requirements.txt.

```sh
python analysis/download_sources.py
python analysis/digitize.py
python analysis/run.py
python -m unittest discover -s tests
```

The first script retrieves official open figure assets only if absent. The second
records coordinate-to-axis conversion and reading overlays under verification/.
No original observations are overwritten. The analysis uses nominal concentrations
from the serial-dilution captions, not noisy inferred horizontal positions.

Primary calculations subtract each curve's lowest-dose readout, then use the
CD3high maximum increment as a common reference within each TA context and endpoint.
TDCC>=0.8/TNF<=0.25 is an illustrative screening criterion, not clinical validation.
The full threshold grid and reference/Hill/reading sensitivity are provided.
An inactive construct does not pass merely by having low TNF.

Donor identities and biological replicate data were not recovered. Near-background
markers can be occluded. Exclusions and readback decisions accompany the inputs.
Pixel perturbation is reading sensitivity, not biological confidence. Interpolated
concentration bounds are not measured cutoffs. No extrapolation outside observed
concentration support or prediction of clinical dosing is made.
