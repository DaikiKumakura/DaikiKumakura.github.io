"""In-range screening on baseline-adjusted published AUCE, not clinical risk."""
import numpy as np
from scipy.optimize import least_squares
from scipy.special import expit

def interpolate(c, y, query):
    if np.any(np.asarray(query)<min(c)) or np.any(np.asarray(query)>max(c)):
        raise ValueError('No extrapolation')
    return np.interp(np.log10(query),np.log10(c),y)

def feasible_intervals(c, efficacy, cytokine, alpha=.8, beta=.25):
    """Exact intersections of linear constraints on consecutive log10-dose knots."""
    x=np.log10(c); intervals=[]
    for i in range(len(x)-1):
        low,high=0.,1.
        for start,end,threshold,sign in [(efficacy[i],efficacy[i+1],alpha,1),(cytokine[i],cytokine[i+1],beta,-1)]:
            a=sign*(start-threshold);b=sign*(end-start)
            if abs(b)<1e-14:
                if a < 0: high=-1.
            elif b>0: low=max(low,-a/b)
            else: high=min(high,-a/b)
        if high>low+1e-12:
            seg=[x[i]+low*(x[i+1]-x[i]),x[i]+high*(x[i+1]-x[i])]
            if intervals and abs(intervals[-1][1]-seg[0])<1e-10:intervals[-1][1]=seg[1]
            else:intervals.append(seg)
    return [(10**a,10**b) for a,b in intervals]

def width(intervals):return sum(np.log10(b/a) for a,b in intervals)

def fit_hill(c,y,h):
    """Two-parameter increment with fixed slope; baseline is lowest-dose value."""
    c=np.asarray(c);y=np.asarray(y);logc=np.log(c);xmin=logc.min()
    def fun(t):
        a=np.exp(t[0]);ec=t[1]
        return a*(expit(h*(logc-ec))-expit(h*(xmin-ec)))
    fits=[]
    for initial in [np.log(np.median(c)),np.log(c.max())]:
        fit=least_squares(lambda t:fun(t)-y,[np.log(max(y.max(),.01)),initial],
            bounds=([-20.,-8.],[np.log(100.),20.]),max_nfev=2000)
        if fit.success:fits.append(fit)
    if not fits:raise RuntimeError('Hill fit failed')
    best=min(fits,key=lambda r:sum(r.fun**2))
    return best.x

def predict_hill(t,c,cmin,h):
    return np.exp(t[0])*(expit(h*(np.log(c)-t[1]))-expit(h*(np.log(cmin)-t[1])))
