"""Original figures of published score summaries and assay values."""
from pathlib import Path
import csv
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

HERE = Path(__file__).resolve().parent
OUT = HERE / 'figures'
OUT.mkdir(exist_ok=True)
with (HERE / 'results/complex1-summary.csv').open(encoding='utf-8') as f:
    assay = list(csv.DictReader(f))
fig, ax = plt.subplots(figsize=(8, 5))
for name, color in [('Compound 1', '#a45b32'), ('Compound 2', '#718c95'), ('Compound 3', '#166277')]:
    rows = [r for r in assay if r['compound'] == name]
    ax.errorbar([float(r['concentration_um']) for r in rows],
                [float(r['mean_activity_percent']) for r in rows],
                yerr=[float(r['sd_activity_percent']) for r in rows], color=color,
                marker='o', capsize=3, label=name)
ax.set(xscale='log', xlabel='Assay concentration (µM)', ylabel='NADH-linked activity (% control)', ylim=(0, 120))
ax.legend(frameon=False);ax.grid(alpha=.2)
fig.text(.5, .02, 'Published triplicate measurements: mean ± sample SD. No fitted IC50 or missing-dose interpolation.', ha='center', fontsize=9)
fig.tight_layout(rect=(0, .055, 1, 1));fig.savefig(OUT / '01-respiratory-assay.png', dpi=180);plt.close(fig)

with (HERE / 'lead-potency.csv').open(encoding='utf-8') as f:
    leads = list(csv.DictReader(f))
fig, ax = plt.subplots(figsize=(8, 4.8))
for r in leads:
    x = 1000 * float(r['ar_degradation_ec50_um']);y = 100 * float(r['score'])
    ax.scatter(x, y, color='#166277' if r['drug'] == 'Compound 3' else '#a45b32', s=65)
    offset, align = ((-7, 6), 'right') if r['drug'] == 'VHL degrader' else ((7, 6), 'left')
    ax.annotate(r['drug'], (x, y), xytext=offset, ha=align, textcoords='offset points', fontsize=10)
ax.set(xlabel='Reported AR degradation EC50 (nM; log axis)', ylabel='Published model score × 100',
       xscale='log', xlim=(4, 6000), ylim=(25, 105))
ax.grid(alpha=.2)
fig.text(.5, .02, 'Five selected published leads. Different assays; not a clinical therapeutic window.', ha='center', fontsize=9)
fig.tight_layout(rect=(0, .06, 1, 1));fig.savefig(OUT / '02-potency-score.png', dpi=180);plt.close(fig)
