"""Descriptive audit of published degrader scores and biochemical assay values."""
from pathlib import Path
import csv
import json
import math
import statistics

HERE = Path(__file__).resolve().parent


def label_below_10(text):
    text = text.strip()
    bound = text[0] if text[0] in '<>' else ''
    number = float(text[1:] if bound else text)
    if bound == '>' and number < 10 or bound == '<' and number > 10:
        return None
    return int(number <= 10 if bound == '<' else number < 10)


def average_precision(labels, scores):
    if len(labels) != len(scores) or not labels or sum(labels) == 0:
        raise ValueError('AP requires aligned observations and positive labels')
    groups = {}
    for label, score in zip(labels, scores):
        if label not in (0, 1) or not math.isfinite(score):
            raise ValueError('Invalid AP input')
        groups.setdefault(score, []).append(label)
    total = sum(labels)
    seen = positives = 0
    ap = 0.
    for score in sorted(groups, reverse=True):
        group = groups[score]
        new = sum(group)
        seen += len(group)
        positives += new
        ap += new / total * positives / seen
    return ap


def read(name):
    with (HERE / name).open(encoding='utf-8', newline='') as f:
        return list(csv.DictReader(f))


def save(path, rows):
    with path.open('w', encoding='utf-8', newline='') as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0]))
        w.writeheader()
        w.writerows(rows)


def main():
    rows = read('library.csv')
    assert len(rows) == 213 and len({r['row_id'] for r in rows}) == 213
    assert all(r['split'] in {'train', 'test'} and 0 <= float(r['score']) <= 1 for r in rows)
    train = [r for r in rows if r['split'] == 'train']
    test = [r for r in rows if r['split'] == 'test']
    assert len(train) == 170 and len(test) == 43
    train_ids = {r['base_id'] for r in train}
    test_ids = {r['base_id'] for r in test}
    shared = train_ids & test_ids
    train_series = {r['series'] for r in train}
    test_series = {r['series'] for r in test}
    labels = [label_below_10(r['gal_ic50_um_reported']) for r in test]
    if any(label is None for label in labels):
        raise ValueError('Holdout threshold class is ambiguous')
    ap = average_precision(labels, [float(r['score']) for r in test])
    group_scores = []
    for compound in ['Compound 1', 'Compound 2', 'Compound 3']:
        selected = [r for r in rows if r['drug'] == compound]
        group_scores.append({'compound': compound, 'rows': len(selected),
                             'mean_score': statistics.mean(float(r['score']) for r in selected),
                             'train_rows': sum(r['split'] == 'train' for r in selected),
                             'test_rows': sum(r['split'] == 'test' for r in selected)})
    assay = read('complex1.csv')
    assert len(assay) == 45
    keys = sorted({(r['compound'], float(r['concentration_um'])) for r in assay})
    summaries = []
    for compound, concentration in keys:
        selected = [r for r in assay if r['compound'] == compound and float(r['concentration_um']) == concentration]
        assert len(selected) == 3 and {int(r['replicate']) for r in selected} == {1, 2, 3}
        values = [float(r['activity_percent']) for r in selected]
        summaries.append({'compound': compound, 'concentration_um': concentration,
                          'n': 3, 'mean_activity_percent': statistics.mean(values),
                          'sd_activity_percent': statistics.stdev(values)})
    potency = read('lead-potency.csv')
    for r in potency:
        selected = [s for s in rows if s['base_id'] == r['base_id']]
        assert selected
        assert abs(statistics.mean(float(s['score']) for s in selected)-float(r['score'])) < .000001
    by_drug = {r['drug']: r for r in potency}
    ratio = float(by_drug['Compound 3']['ar_degradation_ec50_um']) / float(by_drug['Compound 1']['ar_degradation_ec50_um'])
    identified = [label_below_10(r['gal_ic50_um_reported']) for r in rows]
    ambiguous = [r for r, label in zip(rows, identified) if label is None]
    result = {'library_rows': 213, 'identified_positive_labels': sum(x for x in identified if x is not None),
              'ambiguous_censored_rows': [{k:r[k] for k in ['row_id','gal_ic50_um_reported','split']} for r in ambiguous],
              'train_rows': 170, 'test_rows': 43, 'test_positive': sum(labels),
              'test_prevalence': sum(labels)/len(labels), 'stored_ensemble_test_average_precision': ap,
              'train_base_ids': len(train_ids), 'test_base_ids': len(test_ids), 'shared_base_ids': sorted(shared),
              'test_rows_with_train_base_id': sum(r['base_id'] in shared for r in test),
              'train_series': len(train_series), 'test_series': len(test_series),
              'shared_series': sorted(train_series & test_series, key=int),
              'compound3_to_1_ar_degradation_ec50_ratio': ratio,
              'calibration_used_test_labels': True,
              'scope': 'Descriptive AP of stored ensemble scores on rows used for calibration; not independent validation or reproduction of separate raw-model AUPRCs. Known-series split audit and descriptive assays, not clinical safety.'}
    out = HERE / 'results'
    out.mkdir(exist_ok=True)
    save(out / 'compound-scores.csv', group_scores)
    save(out / 'complex1-summary.csv', summaries)
    (out / 'summary.json').write_text(json.dumps(result, indent=2)+'\n', encoding='utf-8')
    print(json.dumps(result, indent=2))


if __name__ == '__main__':
    main()
