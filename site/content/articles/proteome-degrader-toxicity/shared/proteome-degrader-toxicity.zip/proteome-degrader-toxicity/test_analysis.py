"""Analytic reference cases for censoring and tie-aware average precision."""
import unittest
from analysis import average_precision, label_below_10


class AuditTests(unittest.TestCase):
    def test_perfect_ranking(self):
        self.assertEqual(average_precision([1, 0, 1], [.9, .1, .8]), 1.)

    def test_tied_scores_do_not_depend_on_input_order(self):
        self.assertEqual(average_precision([1, 0], [.5, .5]), .5)
        self.assertEqual(average_precision([0, 1], [.5, .5]), .5)

    def test_low_rank_positive(self):
        self.assertAlmostEqual(average_precision([0, 1], [.9, .1]), .5)

    def test_uncertain_censoring(self):
        self.assertIsNone(label_below_10('>0.032'))
        self.assertIsNone(label_below_10('<20'))

    def test_resolved_censoring_and_boundary(self):
        self.assertEqual(label_below_10('>59'), 0)
        self.assertEqual(label_below_10('<10'), 1)
        self.assertEqual(label_below_10('10'), 0)
        self.assertEqual(label_below_10('0.5'), 1)

    def test_ap_requires_positives(self):
        with self.assertRaises(ValueError):
            average_precision([0, 0], [.1, .2])


if __name__ == '__main__':
    unittest.main()
