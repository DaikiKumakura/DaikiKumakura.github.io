# Recalculate the published degrader audit

Use Python 3.11 or newer:

```text
python analysis.py
python -m unittest test_analysis.py
python plot.py
```

Analysis and tests use only the standard library. Original figures require matplotlib. CSV inputs retain factual numerical values extracted from final Supplementary Dataset 5 and Source Data Figures 5 and 6 of Basu et al., DOI https://doi.org/10.1038/s41589-026-02347-2 . Public split metadata is from figshare version 1, DOI https://doi.org/10.6084/m9.figshare.28578113 . Source hashes, URLs and scope are in `input-provenance.json`; worksheet/cell locations are retained for the assay and lead inputs. Neither source workbooks nor official code/model files are redistributed.

`library.csv` contains 213 score rows joined one-to-one to public split metadata (170 train, 43 test). `base_id` removes the final suffix as the official score aggregation does. This grouping denotes a base identifier, not an independently validated identical molecular structure. Series are final score-table categories. The audit counts overlap of base identifiers and series, without claiming a completed group-holdout evaluation.

The AP calculation uses the 43 test rows, groups tied scores and sums precision weighted by recall increments. Labels require a reported galactose IC50 below 10 µM. Censoring bounds that do not determine that class return unknown. One training metadata value, >0.032, is ambiguous at this threshold; all 43 test labels are determined. It is retained and flagged, not treated as a measured value. We do not prove how that row was used by a specific final model. The paper Methods explicitly says the final models were calibrated using the test set. Therefore this AP reuses calibration labels and is descriptive, not an independent holdout performance estimate. AP here concerns saved calibrated ensemble scores, not the paper's separate narrow/wide model AUPRCs; no model was refitted or recalibrated.

`complex1.csv` contains 45 published replicate values for compounds 1-3, extracted from final Source Data Figure 6, sheet C. The NADH-linked respiratory-chain assay is reported as complex I activity; it does not directly measure binding to a named complex I subunit. The code computes means and sample SDs per concentration. Missing doses are absent, not imputed. No IC50 is fitted and no significance test is computed.

`lead-potency.csv` contains five selected source Figure 5C lead summaries. Source score means are reconciled to the library rows. The Compound 3/1 AR degradation EC50 ratio describes those reported summaries and is not an equivalence test or a therapeutic window; the score and degradation endpoint originate from different assays.

The older figshare TableS3 has different columns and scores from the final paper Dataset 5 and is not used. Results are exploratory arithmetic and a static split/code audit, not independent model validation, raw proteome reconstruction, prospective structure generalization or clinical safety prediction. The MIT license covers original scripts and documentation; source numerical inputs are attributed to their respective publications and no third-party license is granted by this archive.
