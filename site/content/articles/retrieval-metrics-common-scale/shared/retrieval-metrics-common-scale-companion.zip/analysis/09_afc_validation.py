"""Checks on the M-AFC model of retrieval metrics (script 07).

(a) Numerical check: Monte Carlo simulation of the forced-choice model against the quadrature used in 07.
(b) Held-out check of the heterogeneity claim: fit recall@k at k = 1, 10, 100 only, predict recall@5, 20, 50, MRR and AUROC.
    Three families: one d'; d' ~ Normal(mu, tau) across queries (2 parameters); two-component mixture (3 parameters).
Input : data/raw/zenodo-23740198/figure_data_fig2/figures/fig2/data/pbulk/fig2a_radar_ext.csv  (N = 1,157)
Output: outputs/tables/afc_mc_check.csv, afc_heldout.csv
Run   : python -X utf8 analysis/09_afc_validation.py     (seed 20261107)
Exploratory modelling; the fits use published summary curves, not per-query data.
"""
import sys
from pathlib import Path

import numpy as np
import pandas as pd
from scipy import optimize, stats

sys.stdout.reconfigure(encoding="utf-8")
SEED = 20261107
ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / "data/fig2a_radar_ext.csv"
OUT = ROOT / "outputs/tables"
N0 = 1157
Z = np.linspace(-8, 12, 4001)
DZ = Z[1] - Z[0]
FIT_K, TEST_K = [1, 10, 100], [5, 20, 50]
ALL_K = [1, 5, 10, 20, 50, 100]


def recall_at(k, N, d):
    d = np.atleast_1d(np.asarray(d, float))[:, None]
    q = stats.norm.sf(Z)[None, :]
    return (stats.norm.pdf(Z[None, :] - d) * stats.binom.cdf(k - 1, N - 1, q)).sum(axis=1) * DZ


def mrr_at(N, d):
    d = np.atleast_1d(np.asarray(d, float))[:, None]
    q = np.clip(stats.norm.sf(Z), 1e-300, 1)[None, :]
    return (stats.norm.pdf(Z[None, :] - d) * ((1 - (1 - q) ** N) / (N * q))).sum(axis=1) * DZ


def auc_at(d):
    return stats.norm.cdf(np.asarray(d, float) / np.sqrt(2))


# ---- (a) Monte Carlo check -------------------------------------------------------------------
rng = np.random.default_rng(SEED)
rows = []
for d in (1.0, 2.0, 3.0):
    n_q = 20000
    s = d + rng.standard_normal(n_q)
    # rank = 1 + number of N-1 distractors above s; sample count as Binomial(N-1, sf(s)) (exact for iid distractors)
    rank = 1 + rng.binomial(N0 - 1, stats.norm.sf(s))
    for k in (1, 10, 100):
        rows.append(dict(d=d, metric=f"recall@{k}", quadrature=float(recall_at(k, N0, d)[0]), monte_carlo=float((rank <= k).mean())))
    rows.append(dict(d=d, metric="MRR", quadrature=float(mrr_at(N0, d)[0]), monte_carlo=float((1 / rank).mean())))
    # explicit distractor draws for a smaller sample, to check the binomial shortcut itself
    n_small = 2000
    s2 = d + rng.standard_normal(n_small)
    dist = rng.standard_normal((n_small, N0 - 1))
    rank2 = 1 + (dist > s2[:, None]).sum(axis=1)
    rows.append(dict(d=d, metric="recall@10 (explicit draws, 2,000 queries)", quadrature=float(recall_at(10, N0, d)[0]), monte_carlo=float((rank2 <= 10).mean())))
    auc = float((s2[:, None] > dist[:, :1]).mean())
    rows.append(dict(d=d, metric="AUROC vs one distractor (explicit draws)", quadrature=float(auc_at(d)), monte_carlo=auc))
mc = pd.DataFrame(rows)
mc["abs_diff"] = (mc.quadrature - mc.monte_carlo).abs()
mc.to_csv(OUT / "afc_mc_check.csv", index=False)
print("== (a) quadrature vs Monte Carlo")
print(mc.round(4).to_string(index=False))

# ---- (b) held-out check ----------------------------------------------------------------------
gh_x, gh_w = np.polynomial.hermite_e.hermegauss(41)  # nodes for Normal(0,1) weights
gh_w = gh_w / gh_w.sum()


def curves(family, p, ks):
    """Return recall at ks, MRR, AUROC for a family with parameter vector p."""
    if family == "single":
        ds, ws = np.array([p[0]]), np.array([1.0])
    elif family == "normal":
        mu, tau = p[0], abs(p[1])
        ds, ws = mu + tau * gh_x, gh_w
    else:
        pi = 1 / (1 + np.exp(-p[2]))
        ds, ws = np.array([p[0], p[1]]), np.array([pi, 1 - pi])
    rec = [float((ws * recall_at(k, N0, ds)).sum()) for k in ks]
    return np.array(rec), float((ws * mrr_at(N0, ds)).sum()), float((ws * auc_at(ds)).sum())


def fit(family, obs, ks):
    f = lambda p: float(np.sum((curves(family, p, ks)[0] - obs) ** 2))
    starts = {"single": [[1.0], [3.0]], "normal": [[2.0, 1.0], [3.0, 2.0]], "mixture": [[4.0, 1.0, 0.0], [3.0, 0.5, -1.0], [3.5, 0.0, 1.0]]}[family]
    best = None
    for st in starts:
        r = optimize.minimize(f, st, method="Nelder-Mead", options=dict(xatol=1e-4, fatol=1e-12, maxiter=3000))
        if best is None or r.fun < best.fun:
            best = r
    return best.x


df = pd.read_csv(DATA)
res = []
for method in ("ExPert", "baseline_centroid_notarget", "xgboost_capped", "linreg"):
    for regime in ("id", "ood"):
        r = df[(df.method == method) & (df.regime == regime)].iloc[0]
        obs_all = np.array([r[f"R{k}"] for k in ALL_K])
        obs_fit = np.array([r[f"R{k}"] for k in FIT_K])
        for family in ("single", "normal", "mixture"):
            p = fit(family, obs_fit, FIT_K)
            rec, mrr, auc = curves(family, p, ALL_K)
            held = [ALL_K.index(k) for k in TEST_K]
            res.append(dict(method=method, regime=regime, family=family, n_params=len(p),
                            rmse_fit_k=float(np.sqrt(np.mean((rec[[ALL_K.index(k) for k in FIT_K]] - obs_fit) ** 2))),
                            rmse_heldout_k=float(np.sqrt(np.mean((rec[held] - obs_all[held]) ** 2))),
                            mrr_obs=float(r.MRR), mrr_pred=mrr, auroc_obs=float(r.AUROC), auroc_pred=auc,
                            params=";".join(f"{x:.3f}" for x in p)))
ho = pd.DataFrame(res)
ho.to_csv(OUT / "afc_heldout.csv", index=False)
print("\n== (b) fit on recall@1,10,100; predict recall@5,20,50, MRR, AUROC")
print(ho.drop(columns=["params"]).round(3).to_string(index=False))
ex = ho[(ho.method == "ExPert")]
print("\nExPert parameter values:\n", ex[["regime", "family", "params"]].to_string(index=False))
