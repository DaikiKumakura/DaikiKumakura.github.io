"""Ranking with and without abstention: comparing ExPert (always ranks) with RNA fingerprinting (may leave cells unassigned).

Input : data/raw/zenodo-23740198/figure_data_figS4/figures/figS4/data/{figS4a_abstention,figS4b_coverage,figS4c_called_vs_all}.csv
Output: outputs/tables/selective_matched_coverage.csv
Run   : python -X utf8 analysis/06_selective_prediction.py
Question: at the same coverage (share of cells given an answer), how do the methods compare, and what does 'all cells' vs 'called only' change?
"""
import sys
from pathlib import Path

import numpy as np
import pandas as pd

sys.stdout.reconfigure(encoding="utf-8")
ROOT = Path(__file__).resolve().parents[1]
D = ROOT / "data/raw/zenodo-23740198/figure_data_figS4/figures/figS4/data"
OUT = ROOT / "outputs/tables"
OUT.mkdir(parents=True, exist_ok=True)

ab = pd.read_csv(D / "figS4a_abstention.csv")
cov = pd.read_csv(D / "figS4b_coverage.csv")
cva = pd.read_csv(D / "figS4c_called_vs_all.csv")

print("== figS4a: abstention (fingerprinting) by regime; n-weighted share of cells left unassigned")
for reg, g in ab.groupby("regime"):
    w = g.n / g.n.sum()
    print(f"  {reg:4s} datasets={len(g):2d} cells={int(g.n.sum()):>9,d}  abstain (cells)={np.average(g.abstain_cells, weights=g.n):.3f}  abstain (effect-weighted)={np.average(g.abstain_eff, weights=g.n):.3f}")
print(ab.groupby("regime")[["abstain_cells", "abstain_eff"]].agg(["min", "median", "max"]).round(3).to_string())

print("\n== figS4b: columns, methods, regimes, coverage grid")
print(cov.method.unique(), cov.regime.unique(), sorted(cov.coverage.unique())[:5], "...", sorted(cov.coverage.unique())[-3:])
print(cov[cov.coverage.isin([1.0])].round(3).to_string(index=False))

print("\n== figS4c: all cells vs called cells")
print(cva.round(3).to_string(index=False))

# matched coverage: fingerprint call rate -> ExPert accuracy / recall10 at that coverage
rows = []
for reg in cov.regime.unique():
    call = 1 - np.average(ab[ab.regime == reg].abstain_cells, weights=ab[ab.regime == reg].n) if reg in ab.regime.values else np.nan
    sub = cov[(cov.regime == reg)]
    for m in sub.method.unique():
        s = sub[sub.method == m].sort_values("coverage")
        if len(s) == 0 or np.isnan(call):
            continue
        acc = np.interp(call, s.coverage, s.accuracy)
        rec = np.interp(call, s.coverage, s.recall10)
        rows.append(dict(regime=reg, method=m, matched_coverage=call, accuracy_at_cov=acc, recall10_at_cov=rec,
                         accuracy_at_1=float(s.accuracy.iloc[-1]), recall10_at_1=float(s.recall10.iloc[-1]), max_coverage=float(s.coverage.max())))
mc = pd.DataFrame(rows)
mc.to_csv(OUT / "selective_matched_coverage.csv", index=False)
print("\n== at the coverage the fingerprint method actually answered (n-weighted), accuracy / recall@10 of each method")
print(mc.round(3).to_string(index=False))
