"""One discriminability parameter for many retrieval metrics: an M-alternative forced-choice (signal detection) model.

Model : the true candidate scores S ~ N(d, 1); each of the other N-1 candidates scores N(0, 1).
        rank = 1 + number of distractors above S.   P(rank <= k) = E_S[ P(Binomial(N-1, 1-Phi(S)) <= k-1) ]
        MRR  = E_S[ (1 - (1-q)^N) / (N q) ], q = 1 - Phi(S);  AUROC (true vs one distractor) = Phi(d / sqrt 2).
        Heterogeneous version: a fraction pi of queries has d1, the rest d2 (two-component mixture).
Input : data/raw/zenodo-23740198/figure_data_fig2/figures/fig2/data/pbulk/fig2a_radar_ext.csv
        (ExPert and baselines, in-distribution and held-out contexts, N = 1,157 candidates, pseudobulk queries)
Output: outputs/tables/afc_fits.csv, afc_predictions_by_N.csv
Run   : python -X utf8 analysis/07_afc_model.py
Exploratory: a modelling lens, not a claim about the mechanism of any method.
"""
import sys
from pathlib import Path

import numpy as np
import pandas as pd
from scipy import optimize, stats

sys.stdout.reconfigure(encoding="utf-8")
ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / "data/fig2a_radar_ext.csv"
OUT = ROOT / "outputs/tables"
OUT.mkdir(parents=True, exist_ok=True)
N0 = 1157
KS = [1, 5, 10, 20, 50, 100]
Z = np.linspace(-8, 12, 4001)  # grid for the true candidate's standardised score offset


def recall_at(k, N, d):
    """P(rank <= k) for a single d (vectorised over d)."""
    d = np.atleast_1d(d)[:, None]
    s = Z[None, :]
    w = stats.norm.pdf(s - d)  # density of S = s when mean is d
    q = stats.norm.sf(s)  # prob. a distractor exceeds s
    pk = stats.binom.cdf(k - 1, N - 1, q)
    return (w * pk).sum(axis=1) * (Z[1] - Z[0])


def mrr(N, d):
    d = np.atleast_1d(d)[:, None]
    s = Z[None, :]
    w = stats.norm.pdf(s - d)
    q = np.clip(stats.norm.sf(s), 1e-300, 1)
    val = (1 - (1 - q) ** N) / (N * q)
    return (w * val).sum(axis=1) * (Z[1] - Z[0])


def curve(N, d):
    return np.array([float(recall_at(k, N, d)[0]) for k in KS]), float(mrr(N, d)[0]), float(stats.norm.cdf(d / np.sqrt(2)))


def fit_single(obs_r):
    f = lambda d: float(np.sum((np.array([recall_at(k, N0, d)[0] for k in KS]) - obs_r) ** 2))
    res = optimize.minimize_scalar(f, bounds=(0.0, 8.0), method="bounded")
    return res.x, res.fun


def fit_mixture(obs_r):
    def f(p):
        pi = 1 / (1 + np.exp(-p[2]))
        r = np.array([pi * recall_at(k, N0, p[0])[0] + (1 - pi) * recall_at(k, N0, p[1])[0] for k in KS])
        return float(np.sum((r - obs_r) ** 2))
    best = None
    for start in ([4.0, 1.0, 0.0], [5.0, 0.5, -1.0], [3.0, 0.0, 1.0]):
        res = optimize.minimize(f, start, method="Nelder-Mead", options=dict(xatol=1e-4, fatol=1e-10, maxiter=2000))
        if best is None or res.fun < best.fun:
            best = res
    d1, d2, lp = best.x
    return d1, d2, 1 / (1 + np.exp(-lp)), best.fun


df = pd.read_csv(DATA)
rows = []
print("== fit of the equal-variance Gaussian M-AFC model to ExPert's released recall@k curve (N = 1,157)")
for _, r in df.iterrows():
    if r.method not in ("ExPert", "baseline_centroid_notarget", "fingerprint_perdataset", "xgboost_capped", "linreg"):
        continue
    obs_r = np.array([r[f"R{k}"] for k in KS])
    d, sse = fit_single(obs_r)
    pred_r, pred_mrr, pred_auc = curve(N0, d)
    d1, d2, pi, sse2 = fit_mixture(obs_r)
    mix_r = np.array([pi * recall_at(k, N0, d1)[0] + (1 - pi) * recall_at(k, N0, d2)[0] for k in KS])
    mix_mrr = pi * float(mrr(N0, d1)[0]) + (1 - pi) * float(mrr(N0, d2)[0])
    mix_auc = pi * stats.norm.cdf(d1 / np.sqrt(2)) + (1 - pi) * stats.norm.cdf(d2 / np.sqrt(2))
    rows.append(dict(method=r.method, regime=r.regime, d_single=d, sse_single=sse, mrr_obs=r.MRR, mrr_single=pred_mrr, mrr_mix=mix_mrr,
                     auroc_obs=r.AUROC, auroc_single=pred_auc, auroc_mix=mix_auc,
                     d1=d1, d2=d2, pi_strong=pi, sse_mix=sse2, **{f"R{k}_obs": o for k, o in zip(KS, obs_r)},
                     **{f"R{k}_single": p for k, p in zip(KS, pred_r)}, **{f"R{k}_mix": p for k, p in zip(KS, mix_r)}))
fits = pd.DataFrame(rows)
fits.to_csv(OUT / "afc_fits.csv", index=False)
show = fits[["method", "regime", "d_single", "sse_single", "sse_mix", "d1", "d2", "pi_strong", "mrr_obs", "mrr_single", "mrr_mix", "auroc_obs", "auroc_single", "auroc_mix"]]
print(show.round(3).to_string(index=False))

ex = fits[fits.method == "ExPert"]
for _, r in ex.iterrows():
    print(f"\nExPert {r.regime}: observed recall@k {[round(r[f'R{k}_obs'], 3) for k in KS]}")
    print(f"   single d'={r.d_single:.2f}      predicted {[round(r[f'R{k}_single'], 3) for k in KS]}")
    print(f"   mixture d1={r.d1:.2f} d2={r.d2:.2f} (strong share {r.pi_strong:.2f}) predicted {[round(r[f'R{k}_mix'], 3) for k in KS]}")

# Dependence on the number of candidates, using the fitted models (illustration of how a headline moves with N)
print("\n== predicted top-10 recall at other candidate-set sizes (ExPert OOD, mixture fit vs single fit)")
pr = []
r = ex[ex.regime == "ood"].iloc[0]
for N in (200, 1157, 8347, 19895):
    s = float(recall_at(10, N, r.d_single)[0])
    m = r.pi_strong * float(recall_at(10, N, r.d1)[0]) + (1 - r.pi_strong) * float(recall_at(10, N, r.d2)[0])
    chance = 10 / N
    pr.append(dict(N=N, top10_single=s, top10_mixture=m, chance=chance, fold_single=s / chance, fold_mixture=m / chance))
pr = pd.DataFrame(pr)
pr.to_csv(OUT / "afc_predictions_by_N.csv", index=False)
print(pr.round(4).to_string(index=False))

# Conversion table between metric scales for a given d' and N
print("\n== metric scales for the same discriminability (N = 1,157): rank fraction, VCC-style PDisc norm, PerturBench-style rank, centroid accuracy (top-1)")
for d in (0.5, 1.0, 2.0, 3.0, 4.0):
    mean_rank_frac = 1 - float(stats.norm.cdf(d / np.sqrt(2)))  # expected fraction of distractors above the true candidate
    print(f"  d'={d:.1f}: PDisc={mean_rank_frac:.3f}  PDiscNorm(1-2*PDisc)={1 - 2 * mean_rank_frac:.3f}  PerturBench rank={mean_rank_frac:.3f}  top-1={float(recall_at(1, N0, d)[0]):.3f}  top-10={float(recall_at(10, N0, d)[0]):.3f}  fold(top-10)={float(recall_at(10, N0, d)[0]) / (10 / N0):.1f}")
