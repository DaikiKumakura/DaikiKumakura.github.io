"""How much discriminability is needed for a target top-k recall as the candidate pool grows? (M-AFC model, single d')

Output: outputs/tables/required_dprime.csv
Run   : python -X utf8 analysis/08_required_dprime.py
Also: d' gained by averaging more independent cells (d' scales with sqrt of the number of cells if noise is independent) - a hypothesis, not a measurement.
"""
import sys
from pathlib import Path

import numpy as np
import pandas as pd
from scipy import optimize, stats

sys.stdout.reconfigure(encoding="utf-8")
ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "outputs/tables"
Z = np.linspace(-8, 14, 6001)


def recall_at(k, N, d):
    w = stats.norm.pdf(Z - d)
    q = stats.norm.sf(Z)
    return float((w * stats.binom.cdf(k - 1, N - 1, q)).sum() * (Z[1] - Z[0]))


rows = []
for N in (100, 200, 1157, 8347, 19895, 100000):
    for k, target in ((10, 0.5), (10, 0.9), (1, 0.5), (50, 0.9)):
        d = optimize.brentq(lambda x: recall_at(k, N, x) - target, 0.0, 10.0)
        rows.append(dict(N=N, k=k, target_recall=target, required_dprime=d, rank_fraction_mean=1 - float(stats.norm.cdf(d / np.sqrt(2)))))
df = pd.DataFrame(rows)
df.to_csv(OUT / "required_dprime.csv", index=False)
print(df.pivot_table(index="N", columns=["k", "target_recall"], values="required_dprime").round(2).to_string())
base = df[(df.k == 10) & (df.target_recall == 0.5)].set_index("N").required_dprime
print("\nrequired d' for top-10 recall 50%: N=200 ->", round(base[200], 2), "; N=19,895 ->", round(base[19895], 2),
      "; ratio of N =", round(19895 / 200, 1), "-> increase in d' =", round(base[19895] - base[200], 2))
print("if d' scales with sqrt(cells averaged): factor of cells needed for +1 unit of d' starting at d'=2.25:", round((3.25 / 2.25) ** 2, 2))
print("sqrt(2 ln N) for N=200, 19,895:", round(np.sqrt(2 * np.log(200)), 2), round(np.sqrt(2 * np.log(19895)), 2))
