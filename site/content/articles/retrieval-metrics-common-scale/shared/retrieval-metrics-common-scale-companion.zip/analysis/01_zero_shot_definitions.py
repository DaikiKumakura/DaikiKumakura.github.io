"""Which 'fold over chance'? Re-reading the released zero-shot retrieval results of ExPert (12 fold models).

Input : data/raw/zenodo-23740198/figure_data_fig3/figures/fig3/data/folds/fig3a_fold{0..11}.json
        (Zenodo doi:10.5281/zenodo.23740198, CC BY 4.0). Nothing is re-fitted; only released summaries are re-aggregated.
Output: outputs/tables/zero_shot_definitions_by_fold.csv, zero_shot_by_screen.csv, zero_shot_summary.json
Run   : python -X utf8 analysis/01_zero_shot_definitions.py
"""
import json
import math
import sys
from pathlib import Path

import numpy as np
import pandas as pd

sys.stdout.reconfigure(encoding="utf-8")
ROOT = Path(__file__).resolve().parents[1]
FOLDS = ROOT / "data/raw/zenodo-23740198/figure_data_fig3/figures/fig3/data/folds"
OUT = ROOT / "outputs/tables"
OUT.mkdir(parents=True, exist_ok=True)
N_PANEL = 19895
CHANCE10 = 10 / N_PANEL
SEED = 20261107
N_BOOT = 5000

rows, screen_rows = [], []
for k in range(12):
    d = json.loads((FOLDS / f"fig3a_fold{k}.json").read_text(encoding="utf-8"))
    assert d["n_panel"] == N_PANEL and abs(d["chance10"] - CHANCE10) < 1e-12
    for name in ("pooled_all", "pooled_seen_dataset", "pooled_unseen_dataset"):
        r = d["real"].get(name)
        if r:
            rows.append(dict(fold=k, group=name, **{c: r[c] for c in ("n_query", "hits10", "top10", "zs_x", "w_zs_x", "wraw_zs_x")}))
    for key, r in d["real"].items():
        if key.startswith("ds:"):
            screen_rows.append(dict(fold=k, screen=key[3:], unseen=key[3:] in d["unseen"],
                                    **{c: r.get(c) for c in ("n_query", "hits10", "top10", "zs_x", "w_zs_x", "wraw_zs_x")}))
    sh = d["shuffled"]
    rows.append(dict(fold=k, group="shuffled_null_pooled_all_mean",
                     n_query=sh[0]["pooled_all"]["n_query"],
                     hits10=float(np.mean([s["pooled_all"]["hits10"] for s in sh])),
                     top10=float(np.mean([s["pooled_all"]["top10"] for s in sh])),
                     zs_x=float(np.mean([s["pooled_all"]["zs_x"] for s in sh])),
                     w_zs_x=float(np.mean([s["pooled_all"]["w_zs_x"] for s in sh])),
                     wraw_zs_x=float(np.mean([s["pooled_all"]["wraw_zs_x"] for s in sh]))))

by_fold = pd.DataFrame(rows)
by_fold.to_csv(OUT / "zero_shot_definitions_by_fold.csv", index=False)
screens = pd.DataFrame(screen_rows)
screens.to_csv(OUT / "zero_shot_by_screen.csv", index=False)

print("== 12 models: pooled zero-shot retrieval, three 'x chance' definitions (median over models)")
summ = {}
for g, sub in by_fold.groupby("group"):
    med = sub[["n_query", "hits10", "top10", "zs_x", "w_zs_x", "wraw_zs_x"]].median()
    summ[g] = med.to_dict()
    print(f"{g:34s} n_query(med)={med.n_query:7.0f} hits10(med)={med.hits10:6.1f} top10={med.top10:.4f} "
          f"unweighted x={med.zs_x:5.1f} effect-weighted x={med.w_zs_x:5.1f} wraw x={med.wraw_zs_x:5.1f}")
print("paper text: zero-shot 26.2-fold overall; 13.5-fold when the context was also held out; shuffled null at chance")

pa = by_fold[by_fold.group == "pooled_all"]
print("\nper-model weighted x (pooled_all):", np.round(pa.w_zs_x.values, 1))
print("per-model unweighted x (pooled_all):", np.round(pa.zs_x.values, 1))
print("ratio weighted/unweighted per model: median", round(float((pa.w_zs_x / pa.zs_x).median()), 2),
      "range", round(float((pa.w_zs_x / pa.zs_x).min()), 2), "-", round(float((pa.w_zs_x / pa.zs_x).max()), 2))

# Absolute recall with a Poisson/binomial interval on the pooled hits (one model, queries are unique perturbations)
print("\n== absolute top-10 recall (unweighted), pooled over the 9,874 zero-shot queries, per model")
rng = np.random.default_rng(SEED)
ci_rows = []
for _, r in pa.iterrows():
    n, h = int(r.n_query), int(r.hits10)
    p = h / n
    boot = rng.binomial(n, p, N_BOOT) / n
    lo, hi = np.percentile(boot, [2.5, 97.5])
    ci_rows.append(dict(fold=int(r.fold), n=n, hits=h, recall=p, lo=lo, hi=hi, x=p / CHANCE10, x_lo=lo / CHANCE10, x_hi=hi / CHANCE10))
ci = pd.DataFrame(ci_rows)
ci.to_csv(OUT / "zero_shot_unweighted_recall_ci.csv", index=False)
print(ci.round(4).to_string(index=False))

print("\n== per screen (all 12 models, hits and queries summed; unweighted)")
g = screens.dropna(subset=["n_query"]).groupby("screen").agg(n_query=("n_query", "sum"), hits10=("hits10", "sum"),
                                                              w_x_median=("w_zs_x", "median"), models=("fold", "nunique"))
g["recall"] = g.hits10 / g.n_query
g["x_unweighted"] = g.recall / CHANCE10
g["share_of_hits"] = g.hits10 / g.hits10.sum()
g["share_of_queries"] = g.n_query / g.n_query.sum()
g = g.sort_values("x_unweighted", ascending=False)
g.to_csv(OUT / "zero_shot_by_screen_summary.csv")
print(g.round(4).to_string())

(OUT / "zero_shot_summary.json").write_text(json.dumps(summ, indent=2), encoding="utf-8")

essential = ["ReplogleWeissman2022_K562_essential", "ReplogleWeissman2025_HepG2", "ReplogleWeissman2022_rpe1", "ReplogleWeissman2025_Jurkat"]
e = g.loc[essential]
print(f"\n== four essential-gene panels (K562 essential, HepG2, RPE1, Jurkat): {e.share_of_queries.sum():.4f} of queries, {e.share_of_hits.sum():.4f} of top-10 hits")
rest = g.drop(index=essential)
print(f"   all other screens: {rest.share_of_queries.sum():.4f} of queries, unweighted x chance = {(rest.hits10.sum() / rest.n_query.sum()) / CHANCE10:.1f}")
print(f"   excluding the four panels, unweighted pooled x chance (screen-model level) = {(rest.hits10.sum() / rest.n_query.sum()) / CHANCE10:.1f}; "
      f"with them = {(g.hits10.sum() / g.n_query.sum()) / CHANCE10:.1f}")
