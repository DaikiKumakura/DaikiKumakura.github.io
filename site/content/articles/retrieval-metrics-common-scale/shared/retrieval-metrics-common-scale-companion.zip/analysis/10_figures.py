"""Figures and the conversion table for the article. Requires outputs/tables from scripts 07-09.
Run: python -X utf8 analysis/10_figures.py
"""
import sys
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from scipy import stats

sys.stdout.reconfigure(encoding="utf-8")
ROOT = Path(__file__).resolve().parents[1]
FIG, TAB = ROOT / "outputs/figures", ROOT / "outputs/tables"
Z = np.linspace(-8, 14, 4401)
DZ = Z[1] - Z[0]
OI = dict(blue="#0072B2", orange="#E69F00", green="#009E73", verm="#D55E00", purple="#CC79A7", sky="#56B4E9", black="#000000")
plt.rcParams.update({"font.size": 10, "axes.spines.top": False, "axes.spines.right": False, "figure.dpi": 150})


def rec(k, N, d):
    d = np.atleast_1d(np.asarray(d, float))[:, None]
    return (stats.norm.pdf(Z[None] - d) * stats.binom.cdf(k - 1, N - 1, stats.norm.sf(Z)[None])).sum(1) * DZ


def mrr(N, d):
    d = np.atleast_1d(np.asarray(d, float))[:, None]
    q = np.clip(stats.norm.sf(Z), 1e-300, 1)[None]
    return (stats.norm.pdf(Z[None] - d) * ((1 - (1 - q) ** N) / (N * q))).sum(1) * DZ


# Figure 1: metrics against d' at N = 1,157
N0 = 1157
ds = np.linspace(0.05, 5, 60)
fig, ax = plt.subplots(figsize=(6.4, 4.0))
ax.plot(ds, 1 - 2 * (1 - stats.norm.cdf(ds / np.sqrt(2))), color=OI["black"], lw=2, label="PDiscNorm = 1 − 2·PDisc")
ax.plot(ds, rec(100, N0, ds), color=OI["sky"], ls="--", lw=2, label="top-100 recall")
ax.plot(ds, rec(10, N0, ds), color=OI["blue"], lw=2, label="top-10 recall")
ax.plot(ds, mrr(N0, ds), color=OI["green"], ls="-.", lw=2, label="MRR")
ax.plot(ds, rec(1, N0, ds), color=OI["verm"], ls=":", lw=2.5, label="top-1 recall")
ax.set_xlabel("Discriminability d′ (true candidate vs. each distractor)")
ax.set_ylabel("Metric value")
ax.set_title("One d′ determines each metric (N = 1,157 candidates, equal-variance Gaussian model)", fontsize=9)
ax.legend(frameon=False, fontsize=8, loc="lower right")
fig.tight_layout()
fig.savefig(FIG / "fig1_metrics_vs_dprime.png")
plt.close(fig)

# Figure 2: ExPert recall@k and fits (fit on k = 1, 10, 100)
ho = pd.read_csv(TAB / "afc_heldout.csv")
df = pd.read_csv(ROOT / "data/fig2a_radar_ext.csv")
KS = [1, 5, 10, 20, 50, 100]
gh_x, gh_w = np.polynomial.hermite_e.hermegauss(41)
gh_w = gh_w / gh_w.sum()


def fam_curve(family, p):
    if family == "single":
        d, w = np.array([p[0]]), np.array([1.0])
    elif family == "normal":
        d, w = p[0] + abs(p[1]) * gh_x, gh_w
    else:
        pi = 1 / (1 + np.exp(-p[2]))
        d, w = np.array([p[0], p[1]]), np.array([pi, 1 - pi])
    return np.array([(w * rec(k, N0, d)).sum() for k in KS])


fig, axes = plt.subplots(1, 2, figsize=(9.0, 3.8), sharey=True)
for ax, regime, title in zip(axes, ("id", "ood"), ("ExPert, seen contexts (ID)", "ExPert, held-out contexts (OOD)")):
    r = df[(df.method == "ExPert") & (df.regime == regime)].iloc[0]
    obs = np.array([r[f"R{k}"] for k in KS])
    for fam, col, ls in (("single", OI["verm"], "--"), ("normal", OI["green"], "-."), ("mixture", OI["blue"], "-")):
        p = [float(x) for x in ho[(ho.method == "ExPert") & (ho.regime == regime) & (ho.family == fam)].iloc[0].params.split(";")]
        label = {"single": "one d′ (1 parameter)", "normal": "d′ ~ Normal (2)", "mixture": "two-component mixture (3)"}[fam]
        ax.plot(KS, fam_curve(fam, p), color=col, ls=ls, lw=2, label=label)
    fitted = [KS.index(k) for k in (1, 10, 100)]
    held = [i for i in range(6) if i not in fitted]
    ax.scatter(np.array(KS)[fitted], obs[fitted], color="black", zorder=5, label="released value, used for fitting")
    ax.scatter(np.array(KS)[held], obs[held], facecolors="white", edgecolors="black", zorder=5, label="released value, held out")
    ax.set_xscale("log")
    ax.set_xlabel("k (top-k)")
    ax.set_title(title, fontsize=9)
axes[0].set_ylabel("Top-k recall (N = 1,157)")
axes[1].legend(frameon=False, fontsize=7.5, loc="lower right")
fig.tight_layout()
fig.savefig(FIG / "fig2_expert_fits.png")
plt.close(fig)

# Figure 3: required d' vs N
rq = pd.read_csv(TAB / "required_dprime.csv")
fig, ax = plt.subplots(figsize=(6.4, 4.0))
for (k, t), col, ls in (((10, 0.5), OI["blue"], "-"), ((10, 0.9), OI["verm"], "--"), ((1, 0.5), OI["green"], "-.")):
    s = rq[(rq.k == k) & (rq.target_recall == t)]
    ax.plot(s.N, s.required_dprime, color=col, ls=ls, marker="o", lw=2, label=f"top-{k} recall = {int(t * 100)}%")
ax.set_xscale("log")
ax.set_xlabel("Number of candidates N")
ax.set_ylabel("Required d′")
ax.set_title("Required discriminability grows slowly with the candidate pool", fontsize=9)
ax.legend(frameon=False, fontsize=8)
fig.tight_layout()
fig.savefig(FIG / "fig3_required_dprime.png")
plt.close(fig)

# Figure 4: fold over chance at fixed d' vs N
Ns = np.array([100, 200, 500, 1157, 3000, 8347, 19895, 60000])
rows = []
fig, ax = plt.subplots(figsize=(6.4, 4.0))
for d, col, ls in ((1.5, OI["verm"], "--"), (2.25, OI["blue"], "-"), (3.0, OI["green"], "-.")):
    fold = np.array([float(rec(10, int(n), d)[0]) / (10 / n) for n in Ns])
    ax.plot(Ns, fold, color=col, ls=ls, marker="o", lw=2, label=f"d′ = {d}")
    rows += [dict(dprime=d, N=int(n), top10=float(f * 10 / n), fold_over_chance=float(f)) for n, f in zip(Ns, fold)]
ax.set_xscale("log")
ax.set_yscale("log")
ax.set_xlabel("Number of candidates N")
ax.set_ylabel("Top-10 recall, fold over chance (10/N)")
ax.set_title("The same d′ gives very different folds at different N", fontsize=9)
ax.legend(frameon=False, fontsize=8)
fig.tight_layout()
fig.savefig(FIG / "fig4_fold_vs_N.png")
plt.close(fig)
pd.DataFrame(rows).to_csv(TAB / "fold_at_fixed_dprime.csv", index=False)
print(pd.DataFrame(rows).pivot(index="N", columns="dprime", values="fold_over_chance").round(1).to_string())
