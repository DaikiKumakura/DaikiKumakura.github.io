"""Effective d' behind some reported numbers (equal-variance M-AFC model, one d' per row; an 'effective' value because real populations are mixtures).

Input : outputs/tables/zero_shot_by_screen_summary.csv (from script 01; unweighted top-10 recall pooled over 12 fold models, N = 19,895)
Output: outputs/tables/effective_dprime_screens.csv ; prints d' for PDiscNorm = 0.86
Run   : python -X utf8 analysis/11_effective_dprime.py
"""
import sys
from pathlib import Path

import numpy as np
import pandas as pd
from scipy import optimize, stats

sys.stdout.reconfigure(encoding="utf-8")
ROOT = Path(__file__).resolve().parents[1]
Z = np.linspace(-8, 14, 6001)


def recall_at(k, N, d):
    return float((stats.norm.pdf(Z - d) * stats.binom.cdf(k - 1, N - 1, stats.norm.sf(Z))).sum() * (Z[1] - Z[0]))


def d_for_recall(k, N, target):
    return optimize.brentq(lambda x: recall_at(k, N, x) - target, -2.0, 10.0)


sc = pd.read_csv(ROOT / "outputs/tables/zero_shot_by_screen_summary.csv")
rows = []
for _, r in sc.iterrows():
    rows.append(dict(screen=r.screen, n_query=int(r.n_query), top10=r.recall, fold=r.x_unweighted, effective_dprime=d_for_recall(10, 19895, r.recall)))
out = pd.DataFrame(rows)
out.to_csv(ROOT / "outputs/tables/effective_dprime_screens.csv", index=False)
print(out.round(3).to_string(index=False))
d86 = optimize.brentq(lambda x: 2 * stats.norm.cdf(x / np.sqrt(2)) - 1 - 0.86, 0, 6)
print(f"\nPDiscNorm = 0.86 -> d' = {d86:.2f}; N = 1,157: top-1 {recall_at(1, 1157, d86):.3f}, top-10 {recall_at(10, 1157, d86):.3f}")
