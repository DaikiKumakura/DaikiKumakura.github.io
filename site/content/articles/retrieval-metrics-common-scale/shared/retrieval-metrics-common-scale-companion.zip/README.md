# Companion materials: putting retrieval metrics on one discriminability scale

Scripts, tables, figures and logs for the article "Putting perturbation-retrieval metrics on one discriminability scale".

- `analysis/07_afc_model.py`, `08_required_dprime.py`, `09_afc_validation.py`, `10_figures.py`, `11_effective_dprime.py`: run on the bundled `data/fig2a_radar_ext.csv` (Python 3.12, numpy, pandas, scipy, matplotlib). Order: 07, 08, 09, 10, 11. Seed 20261107.
- `analysis/01_zero_shot_definitions.py`, `06_selective_prediction.py`: need the ExPert figure data (Zenodo record, doi:10.5281/zenodo.23740198) unpacked to `data/raw/zenodo-23740198/` (figure_data_fig3.zip and figure_data_figS4.zip; the record lists md5 checksums). The data are not bundled; the output tables and logs are.
- `outputs/`: tables (`tables/`), figures (`figures/`) and run logs (`logs/`). Logs of scripts 01 and 06 are from the original run.
- `data/fig2a_radar_ext.csv`: from "ExPert - figure data" (Schwartz et al., Zenodo, doi:10.5281/zenodo.23740198, version v0.1.0), CC BY 4.0. Included unmodified.

All results are exploratory. The model is an equal-variance Gaussian M-alternative forced-choice model; it is a lens on published summary values, not a claim about any method's mechanism.
