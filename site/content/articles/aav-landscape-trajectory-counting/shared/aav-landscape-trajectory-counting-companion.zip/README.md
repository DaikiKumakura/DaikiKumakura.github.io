# Reading the counts of a fitness-landscape preprint: companion code

Arithmetic on numbers printed in the preprint of Sinai et al. (bioRxiv 10.64898/2026.10.18.759989): the number of orderings of 15 seeds and the share that the reported circuit counts represent, an independent-edge density scale, exact intervals for path discovery rates, single-hit arithmetic, and a back-calculation of prevalence and specificity from reported predictive values. No sequences, designs or procedures are involved, and the preprint's data (not yet deposited) are not used.

- `analysis.py`: all tables.
- `figures.py`: Figures 1 and 2.
- `test_analysis.py`: checks (`python -m pytest test_analysis.py`).
- `results/`: CSV outputs.

Requires Python 3 with numpy, scipy, pandas, matplotlib.
