"""Read the counts in 'A Vast Navigable Protein Sequence Subspace' (Sinai et al., bioRxiv 10.64898/2026.10.18.759989, posted 2026-10-22) by their counting unit and denominators.

Inputs are numbers printed in the preprint text (the data and analysis code are announced for deposit before peer review; they are not available here):
  15 seed neighborhoods; Hamiltonian circuits over the seed-level network: 5.4e9 (measured viability calls), >= 2e9 in any of 235 resamplings, "roughly 6% of all possible orderings";
  circuit lengths 212-667 single steps; 315 dense paths, 183 complete after quality control, 85 viable at every measured step; 4,993 dense and 22,500 sparse path samples;
  viable fraction 0.44 at one mutation and 0.016 at five (pooled), random local mutants 42.8% / 1.6%; per-mutation slope 0.9 (two mutations) to 0.52 (five); half-life ~5 mutations (95% CI 2.5-10.6);
  exclusion rule (universal lethals): sensitivity 0.985, NPV 0.995, PPV 0.489; 493,816 measured variants of which 51.3% viable; 1,202 viable of 6,184 random variants at >= 20 mutations;
  sequence-space size ~1e36 (substitutions only), ~1e33 after excluding the lethal set, ~1e27 after a stricter estimate.
Nothing sequence-specific, design-specific or procedural is used. The calculations are arithmetic and exact binomial intervals; there are no random numbers.
"""
from math import factorial
from pathlib import Path

import pandas as pd
from scipy.optimize import fsolve
from scipy.stats import beta

ROOT = Path(__file__).resolve().parent
OUT = ROOT / "results"
OUT.mkdir(exist_ok=True)
N_SEEDS = 15
CIRCUITS_MEASURED, CIRCUITS_MIN_RESAMPLED = 5.4e9, 2.0e9


def directed_orderings(n: int = N_SEEDS) -> int:
    """Directed Hamiltonian cycles of the complete graph on n nodes with a fixed start: (n-1)!"""
    return factorial(n - 1)


def implied_edge_density(count: float, n: int = N_SEEDS) -> float:
    """Edge probability p for which an independent-edge random graph has `count` directed Hamiltonian cycles in expectation: (n-1)! p^n = count.

    Real seed pairs are not independent; this is only a density scale, not an estimate of the actual edge set.
    """
    return (count / directed_orderings(n)) ** (1.0 / n)


def implied_edge_density_undirected(count: float, n: int = N_SEEDS) -> float:
    """Same inversion when circuits are counted without direction: (n-1)!/2 * p^n = count."""
    return (count / (directed_orderings(n) / 2)) ** (1.0 / n)


def clopper_pearson(k: int, n: int, level: float = 0.95) -> tuple[float, float]:
    a = (1 - level) / 2
    lo = 0.0 if k == 0 else float(beta.ppf(a, k, n - k + 1))
    hi = 1.0 if k == n else float(beta.ppf(1 - a, k + 1, n - k))
    return lo, hi


def circuit_table() -> pd.DataFrame:
    tot = directed_orderings()
    rows = []
    for label, c in (("measured calls", CIRCUITS_MEASURED), ("minimum over 235 resamplings", CIRCUITS_MIN_RESAMPLED)):
        rows.append(dict(count=label, circuits=c, orderings=tot, share_of_orderings=c / tot, implied_edge_density=implied_edge_density(c),
                         implied_connected_pairs_of_105=105 * implied_edge_density(c),
                         share_if_undirected=c / (tot / 2), implied_edge_density_undirected=implied_edge_density_undirected(c),
                         implied_connected_pairs_undirected=105 * implied_edge_density_undirected(c)))
    rows.append(dict(count="complete graph (all pairs connected)", circuits=float(tot), orderings=tot, share_of_orderings=1.0, implied_edge_density=1.0, implied_connected_pairs_of_105=105.0,
                     share_if_undirected=2.0, implied_edge_density_undirected=float("nan"), implied_connected_pairs_undirected=float("nan")))
    return pd.DataFrame(rows)


def circuit_steps() -> pd.DataFrame:
    return pd.DataFrame([dict(circuit_steps=s, steps_per_seed_hop=s / N_SEEDS) for s in (212, 667, 116, 192)])


def path_table() -> pd.DataFrame:
    rows = []
    for label, k, n in (("complete after QC / dense paths started", 183, 315), ("viable at every step / dense paths started", 85, 315),
                        ("viable at every step / complete paths", 85, 183), ("viable random variants at >= 20 mutations / sampled", 1202, 6184)):
        lo, hi = clopper_pearson(k, n)
        rows.append(dict(ratio=label, k=k, n=n, share=k / n, ci_low=lo, ci_high=hi))
    return pd.DataFrame(rows)


def single_hit_table() -> pd.DataFrame:
    rows = []
    for p1, label in ((0.44, "pooled viable fraction at 1 mutation (0.44)"), (0.428, "random local mutants at 1 edit (42.8%)"), (0.41, "common per-mutation viability anchor (0.41)")):
        for d in (2, 3, 4, 5):
            rows.append(dict(p1=label, d=d, single_hit_prediction=p1 ** d))
    df = pd.DataFrame(rows)
    df["observed_at_5"] = df.d.map(lambda d: 0.016 if d == 5 else float("nan"))
    return df


def rule_table() -> pd.DataFrame:
    """Prevalence and specificity implied by sensitivity 0.985, NPV 0.995 and PPV 0.489 (leave-one-seed-out exclusion rule)."""
    se, npv, ppv = 0.985, 0.995, 0.489

    def eq(v):
        pi, sp = v
        return [se * pi / (se * pi + (1 - sp) * (1 - pi)) - ppv, sp * (1 - pi) / (sp * (1 - pi) + (1 - se) * pi) - npv]

    pi, sp = fsolve(eq, [0.3, 0.9])
    return pd.DataFrame([dict(sensitivity=se, npv=npv, ppv=ppv, implied_prevalence=pi, implied_specificity=sp,
                              implied_false_positive_rate=1 - sp, prior_odds=pi / (1 - pi), posterior_odds=ppv / (1 - ppv))])


def space_table() -> pd.DataFrame:
    measured = 493816
    rows = [dict(space="substitutions only", size=1e36), dict(space="after excluding the lethal set", size=1e33), dict(space="stricter estimate", size=1e27)]
    for r in rows:
        r["measured_fraction"] = measured / r["size"]
    return pd.DataFrame(rows)


def main() -> None:
    pd.set_option("display.width", 250, "display.max_columns", 30, "display.float_format", lambda v: f"{v:.4g}")
    for name, df in (("circuits", circuit_table()), ("circuit_steps", circuit_steps()), ("paths", path_table()), ("single_hit", single_hit_table()),
                     ("exclusion_rule", rule_table()), ("space", space_table())):
        df.to_csv(OUT / f"{name}.csv", index=False)
        print(name); print(df); print()


if __name__ == "__main__":
    main()
