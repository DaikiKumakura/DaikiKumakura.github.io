import math

import analysis as an


def test_orderings_and_share_match_the_text():
    assert an.directed_orderings() == math.factorial(14) == 87178291200
    share = an.CIRCUITS_MEASURED / an.directed_orderings()
    assert abs(share - 0.06) < 0.003          # the text says "roughly 6% of all possible orderings"


def test_implied_density_roundtrip():
    p = an.implied_edge_density(5.4e9)
    assert abs(math.factorial(14) * p ** 15 - 5.4e9) / 5.4e9 < 1e-9
    assert an.implied_edge_density(float(an.directed_orderings())) == 1.0 or abs(an.implied_edge_density(float(an.directed_orderings())) - 1) < 1e-12


def test_clopper_pearson_contains_estimate():
    lo, hi = an.clopper_pearson(85, 183)
    assert lo < 85 / 183 < hi and 0.38 < lo < 0.40 and 0.53 < hi < 0.55


def test_single_hit_at_five_matches_pooled_rate():
    assert abs(0.44 ** 5 - 0.016) < 0.001


def test_rule_inversion_reproduces_inputs():
    r = an.rule_table().iloc[0]
    pi, sp, se = r.implied_prevalence, r.implied_specificity, 0.985
    assert abs(se * pi / (se * pi + (1 - sp) * (1 - pi)) - 0.489) < 1e-6
    assert abs(sp * (1 - pi) / (sp * (1 - pi) + (1 - se) * pi) - 0.995) < 1e-6


def test_undirected_convention_changes_density():
    assert an.implied_edge_density_undirected(5.4e9) > an.implied_edge_density(5.4e9)
    assert abs(5.4e9 / (math.factorial(14) / 2) - 0.1239) < 1e-3


def test_clopper_pearson_upper_bound_for_random_variants():
    lo, hi = an.clopper_pearson(1202, 6184)
    assert abs(hi - 0.20446) < 1e-4 and 0.184 < lo < 0.185
