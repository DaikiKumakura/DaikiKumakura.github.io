"""Figures for the landscape trajectory-counting note (reads results/*.csv)."""
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import pandas as pd

ROOT = Path(__file__).resolve().parent
RES, FIG = ROOT / "results", ROOT / "figures"
FIG.mkdir(exist_ok=True)
BLUE, ORANGE, GREY = "#0072B2", "#D55E00", "#666666"


def fig1():
    c = pd.read_csv(RES / "circuits.csv")
    labels = ["All orderings of 15 seeds\n(complete graph, 14!)", "Reported: measured\nviability calls", "Reported: minimum over\n235 resamplings"]
    vals = [c.circuits.iloc[2], c.circuits.iloc[0], c.circuits.iloc[1]]
    fig, ax = plt.subplots(figsize=(7.2, 4.2))
    ax.scatter(range(3), vals, s=110, color=[GREY, BLUE, BLUE], zorder=3)
    ax.set_yscale("log")
    for i, v in enumerate(vals):
        ax.text(i, v * 1.25, f"{v:.2e}", ha="center", fontsize=8)
    ax.set_xticks(range(3))
    ax.set_xticklabels(labels, fontsize=8)
    ax.set_ylim(5e8, 3e11)
    ax.set_xlim(-0.5, 2.5)
    ax.set_ylabel("Number of circuits through the 15 seeds (log scale)")
    ax.set_title("'Billions of circuits' on a 15-node graph: 6.2% and 2.3% of all orderings", fontsize=10)
    ax.grid(axis="y", alpha=0.25)
    fig.tight_layout()
    fig.savefig(FIG / "01-circuit-counts-vs-all-orderings.png", dpi=170)
    plt.close(fig)


def fig2():
    p = pd.read_csv(RES / "paths.csv")
    names = ["QC pass rate: complete after QC / dense paths started (183/315)", "Viable at every step / dense paths started (85/315)",
             "Viable at every step / complete paths (85/183)", "Viable random variants, 20+ mutations from WT (1202/6184)"]
    fig, ax = plt.subplots(figsize=(8.2, 3.8))
    y = range(len(p))
    ax.errorbar(100 * p.share, y, xerr=[100 * (p.share - p.ci_low), 100 * (p.ci_high - p.share)], fmt="o", color=BLUE, capsize=4)
    ax.set_yticks(list(y))
    ax.set_yticklabels(names, fontsize=8)
    ax.invert_yaxis()
    ax.set_xlabel("Percent (exact 95% interval)")
    ax.set_xlim(0, 80)
    ax.set_title("Proportions of paths and variants under different denominators", fontsize=10)
    ax.grid(axis="x", alpha=0.25)
    fig.tight_layout()
    fig.savefig(FIG / "02-path-denominators.png", dpi=170)
    plt.close(fig)


if __name__ == "__main__":
    fig1()
    fig2()
