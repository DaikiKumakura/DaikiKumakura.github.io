"""Illustrative TPD turnover simulation; not fitted to any compound or patient."""
from pathlib import Path
import json
import numpy as np
import pandas as pd
from scipy.integrate import solve_ivp
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
ROOT=Path(__file__).resolve().parent
plt.rcParams.update({'font.size':10,'axes.spines.top':False,'axes.spines.right':False,'figure.dpi':130})
COLORS=['#245c7a','#bd7042','#568567','#8b6799']
PARAM={'pk_half_life_h':6.,'ka_per_h':1.,'kmax_per_h':1.,'K50_relative':1.,'hill':1.2}
REG={'QD':(24,1.),'BID':(12,.5),'Q2D':(48,2.),'5 on / 2 off':(24,1.4)}
def simulate(target_half=48,tissue_half=2,regimen='QD',days=42,single=False,step=.25):
    tau,dose=REG[regimen];stop=24*days
    doses=[0.] if single else [float(t) for t in np.arange(0,stop,tau) if regimen!='5 on / 2 off' or int(t//24)%7<5]
    bounds=doses+[stop];state=np.array([0.,0.,0.,1.]);records=[]
    kd=np.log(2)/target_half; ke=np.log(2)/tissue_half; kel=np.log(2)/6
    def rhs(t,y):
        gut,cp,ct,x=y;drug=ct**1.2/(1+ct**1.2) if ct>0 else 0.
        return [-gut,gut-kel*cp,ke*(cp-ct),kd*(1-x)-drug*x]
    for a,b in zip(bounds[:-1],bounds[1:]):
        state[0]+=dose
        grid=np.linspace(a,b,int(round((b-a)/step))+1)
        sol=solve_ivp(rhs,(a,b),state,t_eval=grid,rtol=1e-9,atol=1e-11)
        if not sol.success:raise RuntimeError(sol.message)
        records.append(np.column_stack([sol.t[:-1],sol.y[:,:-1].T]));state=sol.y[:,-1]
    records.append(np.array([[stop,*state]])); arr=np.concatenate(records)
    return pd.DataFrame(arr,columns=['hour','gut','plasma','effect_site','target']).assign(degradation=lambda d:1-d.target)
def metrics(frame):
    d=frame[frame.hour>=28*24];t=d.hour.to_numpy();v=d.degradation.to_numpy()
    return dict(Dmax_pct=100*v.max(),Dmin_pct=100*v.min(),Dmean_pct=100*np.trapezoid(v,t)/(t[-1]-t[0]),time_above_80_pct=100*np.trapezoid((v>=.8).astype(float),t)/(t[-1]-t[0]))
def main():
    for name in ['data','results','figures']:(ROOT/name).mkdir(exist_ok=True)
    obs=pd.DataFrame([['ERD-1233',3,5365,312],['ERD-1233',24,16,157],['ARV-471',24,9,286]],columns=['compound','hour','plasma_ng_ml','tumor_ng_ml'])
    obs.to_csv(ROOT/'data/public-concentrations.csv',index=False)
    obs.assign(tumor_plasma_ratio=obs.tumor_ng_ml/obs.plasma_ng_ml).to_csv(ROOT/'results/ratios.csv',index=False)
    rows=[];frames={}
    for th in [6,48]:
      for eh in [2,24]:
       for reg in REG:
        f=simulate(th,eh,reg);frames[th,eh,reg]=f;rows.append(dict(target_half_h=th,effect_site_half_h=eh,regimen=reg,**metrics(f)))
    met=pd.DataFrame(rows);met.to_csv(ROOT/'results/regimen-metrics.csv',index=False)
    # Numerical refinement, no-drug equilibrium, and analytical washout checks.
    fine=metrics(simulate(step=.125));normal=metrics(frames[48,2,'QD']); delta=max(abs(fine[k]-normal[k]) for k in fine)
    assert delta<.2
    for f in frames.values():assert f.target.min()>-1e-8 and f.target.max()<=1+1e-8
    h=np.array([0.,6.,24.,48.,72.]);kd=np.log(2)/48
    a=solve_ivp(lambda t,x:kd*(1-x),(0,72),[.1],t_eval=h,rtol=1e-10,atol=1e-12).y[0]
    assert np.max(abs(a-(1-.9*np.exp(-kd*h))))<1e-8
    validation={'step_refinement_max_metric_pp':delta,'target_bounds_pass':True,'analytical_washout_pass':True,'model':'assumed parameters; no compound fit','window_h':[672,1008]}
    (ROOT/'results/validation.json').write_text(json.dumps(validation,indent=2))
    fig,ax=plt.subplots(figsize=(7,4));x=np.arange(3);w=.32
    ax.bar(x-w/2,obs.plasma_ng_ml,w,label='Plasma',color=COLORS[0]);ax.bar(x+w/2,obs.tumor_ng_ml,w,label='Tumor',color=COLORS[1]);ax.set_yscale('log');ax.set_ylim(1,10000);ax.set_xticks(x,['ERD-1233\n3 h','ERD-1233\n24 h','ARV-471\n24 h']);ax.set_ylabel('Reported total concentration (ng/mL)');ax.legend();ax.set_title('Public observations: plasma and tumor differ');fig.tight_layout();fig.savefig(ROOT/'figures/01-public-concentrations.png');plt.close(fig)
    fig,axes=plt.subplots(2,2,figsize=(8,6),sharex=True,sharey=True)
    for ax,(th,eh) in zip(axes.ravel(),[(6,2),(6,24),(48,2),(48,24)]):
        f=simulate(th,eh,days=7,single=True);ax.plot(f.hour,100*f.degradation,color=COLORS[0]);ax.set_title(f'Target half-life {th} h; effect-site {eh} h');ax.set_ylim(0,100);ax.set_xlabel('Time after one relative dose (h)');ax.set_ylabel('Degradation (%)');ax.grid(alpha=.15)
    fig.suptitle('Illustrative scenarios: persistence has two sources',fontsize=12);fig.tight_layout();fig.savefig(ROOT/'figures/02-single-dose.png');plt.close(fig)
    fig,axes=plt.subplots(2,1,figsize=(8,6),sharex=True,sharey=True)
    for ax,th in zip(axes,[6,48]):
      for reg,color in zip(REG,COLORS):
        f=frames[th,2,reg];f=f[f.hour>=35*24];ax.plot((f.hour-35*24)/24,100*f.degradation,label=reg,color=color)
      ax.set_ylim(0,100);ax.set_title(f'Target half-life {th} h; effect-site half-life 2 h');ax.set_ylabel('Degradation (%)');ax.grid(alpha=.15)
    axes[0].legend(ncol=4,fontsize=9);axes[-1].set_xlabel('Day within final week');fig.suptitle('Equal long-run dose rate; not clinical dose equivalence',fontsize=12);fig.tight_layout();fig.savefig(ROOT/'figures/03-schedules.png');plt.close(fig)
    fig,axes=plt.subplots(1,2,figsize=(10,4),sharey=True)
    for ax,key,title in zip(axes,['Dmin_pct','Dmean_pct'],['Minimum degradation','Mean degradation']):
      matrix=np.array([[met[(met.target_half_h==th)&(met.effect_site_half_h==eh)&(met.regimen==reg)][key].iloc[0] for reg in REG] for th,eh in [(6,2),(6,24),(48,2),(48,24)]])
      ax.imshow(matrix,vmin=0,vmax=100,cmap='Blues',aspect='auto');ax.set_xticks(range(4),REG,rotation=25,ha='right');ax.set_yticks(range(4),['Target 6 h / site 2 h','Target 6 h / site 24 h','Target 48 h / site 2 h','Target 48 h / site 24 h']);ax.set_title(title+' (%)')
      for i in range(4):
       for j in range(4):ax.text(j,i,f'{matrix[i,j]:.1f}',ha='center',va='center',color='white' if matrix[i,j]>60 else '#222')
    fig.suptitle('Illustrative PD metrics over days 28-42',fontsize=12);fig.tight_layout();fig.savefig(ROOT/'figures/04-metrics.png');plt.close(fig)
    print(met.to_string(index=False));print(validation)
if __name__=='__main__':main()
