from pathlib import Path
import csv,json,gzip,math,statistics,hashlib
R=Path(__file__).resolve().parent
def read(name):
 with (R/'results'/name).open(newline='') as f:return list(csv.DictReader(f))
scores=read('paired-scores-private.csv');pred=read('heldout-private.csv');assert len(scores)==43 and len(pred)==42
assert len({p['patient'] for p in pred})==42 and sum(int(p['y']) for p in pred)==9
summary=json.loads((R/'results/model-summary.json').read_text());audit=json.loads((R/'results/audit.json').read_text())
for column,key in [('p_baseline','FPKM_baseline'),('p_change','FPKM_baseline_change')]:
 pos=[float(p[column]) for p in pred if p['y']=='1'];neg=[float(p[column]) for p in pred if p['y']=='0'];auc=sum(1 if a>b else .5 if a==b else 0 for a in pos for b in neg)/(len(pos)*len(neg));bs=statistics.mean((int(p['y'])-float(p[column]))**2 for p in pred)
 assert abs(auc-summary[key]['AUC'])<1e-12 and abs(bs-summary[key]['Brier'])<1e-12
metadata=read('sample-metadata-private.csv');lookup={p['sample']:p for p in metadata};values={}
with gzip.open(R/'raw/GSE91061_BMS038109Sample.hg19KnownGene.fpkm.csv.gz','rt',newline='') as f:
 reader=csv.reader(f);header=next(reader)
 for row in reader:
  if row[0] in ['3001','5551','3458','6772','3620','4283','3627','3122']:values[row[0]]=[float(v) for v in row[1:]]
assert len(values)==8
for i,sample in enumerate(header[1:]):
 expected=(math.log2(values['3001'][i]+1)+math.log2(values['5551'][i]+1))/2;assert abs(expected-float(lookup[sample]['Cytolytic']))<1e-10
 expected_ifn=sum(math.log2(values[g][i]+1) for g in ['3458','6772','3620','4283','3627','3122'])/6;assert abs(expected_ifn-float(lookup[sample]['IFN-related']))<1e-10
paired_summary=read('paired-change-summary.csv')[0];median=statistics.median(float(p['Cytolytic_change']) for p in scores);assert abs(median-float(paired_summary['median_change']))<1e-12
assert audit['duplicate_patient_visit_rows']==2 and audit['paired_patients']==43 and not audit['exact_biopsy_days_available']
for source in json.loads((R/'raw/source-manifest.json').read_text()):assert hashlib.sha256((R/'raw'/source['file']).read_bytes()).hexdigest()==source['sha256']
identities=json.loads((R/'results/gene-identities.json').read_text())['verified'];assert identities['3620']=='IDO1' and audit['score_gene_ids']['IDO1']==3620
result={'status':'passed','independent_checks':['all sample primary and secondary scores','NCBI gene identities','paired median','pairwise AUC','Brier','source SHA-256','cohort counts'],'scope':'Selected paired-cohort association; not prospective or survival validation'}
(R/'results/validation.json').write_text(json.dumps(result,indent=2));print(json.dumps(result,indent=2))
