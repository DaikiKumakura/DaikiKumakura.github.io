# Data audit

Official GSE91061: 109 samples, 65 participants, 51 Pre and 58 On; exactly 43 pairs and 22 unpaired participants. One unpaired participant has two On samples, recorded as two duplicate participant–visit rows. No sample was selected by response. Titles agree with visit characteristics, response agrees within participant, and 109 expression columns match metadata exactly. Both 22,187-gene matrices have unique matching IDs. FPKM is finite/nonnegative; raw counts are nonnegative integers. All eight fixed Entrez IDs are present.

Paired response: 9 PRCR, 15 SD, 18 PD, 1 UNK. Response-associated analysis: 42 participants, 9 events. PRCR means CR/PR, not durable clinical benefit. Unknown response is not relabeled.

Collection schedule from source study: Pre 1–7 days before treatment; On cycle 1 day 29, days 23–29. Exact participant collection and response/event dates are unavailable in these files. No qualified survival or day-29 prospective prediction. Only association conditional on observed pairs. No untreated longitudinal comparator; changes need not represent a causal pharmacological effect.

Participant source data, metadata, scores, fold assignments and held-out predictions remain local. Public release includes aggregate outputs and retrieval code only. SHA-256 checks are applied to official source files. Source paper: Riaz et al., DOI 10.1016/j.cell.2017.09.028.

Prepublication correction: initial secondary panel used INPP1 ID 3628 in place of IDO1. Independent NCBI gene verification corrected IDO1 to 3620 before release. Primary GZMA/PRF1 results were unaffected; all secondary results were recomputed. This correction followed the fixed biological panel rather than response-driven reselection.
