from pathlib import Path
import urllib.request,json,hashlib
R=Path(__file__).resolve().parent;raw=R/'raw';raw.mkdir(parents=True,exist_ok=True)
base='https://ftp.ncbi.nlm.nih.gov/geo/series/GSE91nnn/GSE91061/'
urls=[base+'soft/GSE91061_family.soft.gz']+[base+'suppl/GSE91061_BMS038109Sample.hg19KnownGene.'+kind+'.csv.gz' for kind in ['fpkm','raw']]
old=raw/'source-manifest.json';pinned={v['file']:v['sha256'] for v in json.loads(old.read_text())} if old.exists() else {};manifest=[]
for url in urls:
 p=raw/url.rsplit('/',1)[1]
 if not p.exists():p.write_bytes(urllib.request.urlopen(url,timeout=90).read())
 sha=hashlib.sha256(p.read_bytes()).hexdigest()
 if p.name in pinned:assert sha==pinned[p.name],'Source bytes changed; inspect before repinning'
 manifest.append({'url':url,'file':p.name,'sha256':sha,'bytes':p.stat().st_size})
old.write_text(json.dumps(manifest,indent=2));print('Three official GEO files acquired and hashed')
