from pathlib import Path
import gzip,re,json,hashlib
import numpy as np,pandas as pd
from scipy.optimize import minimize
from scipy.special import expit
from scipy.stats import rankdata,spearmanr
import matplotlib;matplotlib.use('Agg')
import matplotlib.pyplot as plt
R=Path(__file__).resolve().parent
for name in ['results','figures']:(R/name).mkdir(exist_ok=True)
manifest=json.loads((R/'raw/source-manifest.json').read_text())
for f in manifest:assert hashlib.sha256((R/'raw'/f['file']).read_bytes()).hexdigest()==f['sha256']
soft=gzip.open(R/'raw/GSE91061_family.soft.gz','rt').read();records=[]
for block in soft.split('^SAMPLE = ')[1:]:
 title=re.search(r'^!Sample_title = (.+)$',block,re.M).group(1).strip();m=re.fullmatch(r'Pt(\d+)_(Pre|On)_(.+)',title);assert m
 visit=re.search(r'^!Sample_characteristics_ch1 = visit \(pre or on treatment\): (.+)$',block,re.M).group(1).strip();assert visit==m[2]
 response=re.search(r'^!Sample_characteristics_ch1 = response: (.+)$',block,re.M).group(1).strip()
 records.append({'patient':int(m[1]),'sample':title,'visit':visit,'response':response})
meta=pd.DataFrame(records);assert len(meta)==109 and meta.patient.nunique()==65;assert meta.groupby('patient').response.nunique().eq(1).all();assert meta['sample'].is_unique
fp=pd.read_csv(R/'raw/GSE91061_BMS038109Sample.hg19KnownGene.fpkm.csv.gz',index_col=0);counts=pd.read_csv(R/'raw/GSE91061_BMS038109Sample.hg19KnownGene.raw.csv.gz',index_col=0)
assert fp.index.is_unique and counts.index.is_unique;assert set(fp.columns)==set(meta['sample']);assert fp.index.equals(counts.index) and fp.columns.equals(counts.columns);assert np.isfinite(fp.values).all() and (fp.values>=0).all();assert (counts.values>=0).all() and np.equal(counts.values,np.floor(counts.values)).all()
genes={'GZMA':3001,'PRF1':5551,'IFNG':3458,'STAT1':6772,'IDO1':3620,'CXCL9':4283,'CXCL10':3627,'HLA-DRA':3122};assert set(genes.values())<=set(fp.index)
sets={'Cytolytic':['GZMA','PRF1'],'IFN-related':['IFNG','STAT1','IDO1','CXCL9','CXCL10','HLA-DRA']}
for name,names in sets.items():meta[name]=np.log2(fp.loc[[genes[g] for g in names]]+1).mean().reindex(meta['sample']).to_numpy()
cpm=counts.div(counts.sum(),axis=1)*1e6;meta['CPM-Cytolytic']=np.log2(cpm.loc[[3001,5551]]+1).mean().reindex(meta['sample']).to_numpy()
pairs=[]
for patient,group in meta.groupby('patient'):
 if len(group)!=2 or set(group.visit)!={'Pre','On'}:continue
 pre=group[group.visit=='Pre'].iloc[0];on=group[group.visit=='On'].iloc[0];row={'patient':patient,'response':pre.response}
 for name in ['Cytolytic','IFN-related','CPM-Cytolytic']:row[name+'_Pre']=pre[name];row[name+'_On']=on[name];row[name+'_change']=on[name]-pre[name]
 pairs.append(row)
d=pd.DataFrame(pairs);assert len(d)==43;d.to_csv(R/'results/paired-scores-private.csv',index=False);meta.to_csv(R/'results/sample-metadata-private.csv',index=False)
audit={'samples':109,'patients':65,'pre_samples':int((meta.visit=='Pre').sum()),'on_samples':int((meta.visit=='On').sum()),'paired_patients':43,'unpaired_patients':22,'duplicate_patient_visit_rows':int(meta.duplicated(['patient','visit'],keep=False).sum()),'response_counts_paired':d.response.value_counts().to_dict(),'gene_count':len(fp),'exact_biopsy_days_available':False,'survival_endpoint_qualified':False,'eligible_response_known':int((d.response!='UNK').sum()),'score_gene_ids':genes}
(R/'results/audit.json').write_text(json.dumps(audit,indent=2))
rng=np.random.default_rng(20261004);summaries=[]
for name in ['Cytolytic','IFN-related','CPM-Cytolytic']:
 v=d[name+'_change'].to_numpy();boot=np.median(v[rng.integers(len(v),size=(2000,len(v)))],axis=1);summaries.append({'score':name,'n':len(v),'median_change':float(np.median(v)),'lower':float(np.quantile(boot,.025)),'upper':float(np.quantile(boot,.975)),'positive_changes':int((v>0).sum())})
pd.DataFrame(summaries).to_csv(R/'results/paired-change-summary.csv',index=False)
known=d[d.response!='UNK'].copy();y=(known.response=='PRCR').astype(int).to_numpy();assert len(y)==42 and y.sum()==9
def auc(y,p):return float((rankdata(p)[y==1].sum()-y.sum()*(y.sum()+1)/2)/(y.sum()*(len(y)-y.sum())))
def metrics(y,p):
 p=np.clip(p,1e-8,1-1e-8);return {'AUC':auc(y,p),'Brier':float(np.mean((y-p)**2)),'logloss':float(-np.mean(y*np.log(p)+(1-y)*np.log(1-p)))}
def fit(x,y,penalty=1):
 def objective(b):
  eta=b[0]+x@b[1:];p=expit(eta);val=np.logaddexp(0,eta).sum()-(y*eta).sum()+penalty/2*(b[1:]@b[1:]);grad=np.r_[(p-y).sum(),x.T@(p-y)+penalty*b[1:]];return val,grad
 result=minimize(objective,np.zeros(x.shape[1]+1),jac=True,method='BFGS',options={'gtol':1e-7});assert np.isfinite(result.x).all() and np.linalg.norm(result.jac)<1e-5,(result.message,result.jac);return result.x
def cv(prefix):
 x=known[[prefix+'_Pre',prefix+'_change']].to_numpy();generator=np.random.default_rng(20261004);pred=np.empty((20,len(y),2));folds=[]
 for repeat in range(20):
  fold=np.zeros(len(y),int)
  for label in [0,1]:
   idx=np.flatnonzero(y==label);generator.shuffle(idx);fold[idx]=np.arange(len(idx))%3
  for f in range(3):
   test=fold==f;train=~test;mu=x[train].mean(axis=0);sd=x[train].std(axis=0);assert (sd>0).all();tr=(x[train]-mu)/sd;te=(x[test]-mu)/sd
   for model,ncols in enumerate([1,2]):b=fit(tr[:,:ncols],y[train]);pred[repeat,test,model]=expit(b[0]+te[:,:ncols]@b[1:])
  folds.append(fold)
 return pred.mean(axis=0),np.array(folds)
pred,folds=cv('Cytolytic');pd.DataFrame(folds,columns=known.patient).to_csv(R/'results/fold-assignment-private.csv',index=False);cpred,cfolds=cv('CPM-Cytolytic');assert np.array_equal(folds,cfolds)
private=pd.DataFrame({'patient':known.patient,'y':y,'p_baseline':pred[:,0],'p_change':pred[:,1]});private.to_csv(R/'results/heldout-private.csv',index=False)
summary={'FPKM_baseline':metrics(y,pred[:,0]),'FPKM_baseline_change':metrics(y,pred[:,1]),'CPM_baseline':metrics(y,cpred[:,0]),'CPM_baseline_change':metrics(y,cpred[:,1]),'bootstrap_conditioning':'Stratified participant resampling of averaged held-out predictions, without refitting','folds':3,'repeats':20,'penalty':1}
diffs={key:[] for key in ['AUC','Brier','logloss']};generator=np.random.default_rng(20261005)
for _ in range(2000):
 ix=np.r_[generator.choice(np.flatnonzero(y==0),(y==0).sum()),generator.choice(np.flatnonzero(y==1),y.sum())];a=metrics(y[ix],pred[ix,0]);b=metrics(y[ix],pred[ix,1])
 for key in diffs:diffs[key].append(b[key]-a[key])
summary['paired_differences']={key:{'estimate':summary['FPKM_baseline_change'][key]-summary['FPKM_baseline'][key],'lower':float(np.quantile(values,.025)),'upper':float(np.quantile(values,.975))} for key,values in diffs.items()}
summary['CPM_delta_rank_correlation']=float(spearmanr(d['Cytolytic_change'],d['CPM-Cytolytic_change']).statistic)
logits=np.log(pred[:,1]/(1-pred[:,1]));cal=fit(logits[:,None],y,penalty=0);summary['heldout_calibration_intercept']=float(cal[0]);summary['heldout_calibration_slope']=float(cal[1]);(R/'results/model-summary.json').write_text(json.dumps(summary,indent=2))
selection=[]
for label,part in [('Paired baseline',meta[(meta.visit=='Pre')&meta.patient.isin(d.patient)]),('Unpaired baseline',meta[(meta.visit=='Pre')&~meta.patient.isin(d.patient)])]:
 k=part[part.response!='UNK'];selection.append({'group':label,'n':len(part),'known_response_n':len(k),'PRCR':int((k.response=='PRCR').sum()),'median_baseline_Cytolytic':float(part.Cytolytic.median())})
pd.DataFrame(selection).to_csv(R/'results/selection-summary.csv',index=False)
plt.rcParams.update({'font.size':11,'axes.spines.top':False,'axes.spines.right':False});fig,ax=plt.subplots(1,2,figsize=(10,4))
for a,name in zip(ax,['Cytolytic','IFN-related']):
 for _,row in d.iterrows():a.plot([0,1],[row[name+'_Pre'],row[name+'_On']],color='#246b80',alpha=.22,lw=.8)
 a.plot([0,1],[d[name+'_Pre'].median(),d[name+'_On'].median()],color='#9c553d',lw=3,marker='o',label='Visit median');a.legend(fontsize=9,frameon=False);a.set(xticks=[0,1],xticklabels=['Pre','On'],ylabel='Mean log2(FPKM + 1)',title=name+' — 43 patient pairs')
fig.tight_layout();fig.savefig(R/'figures/paired-expression.png',dpi=170);plt.close(fig)
fig,ax=plt.subplots(figsize=(7,4));groups=[known.loc[known.response!='PRCR','Cytolytic_change'],known.loc[known.response=='PRCR','Cytolytic_change']];ax.boxplot(groups,tick_labels=['SD/PD (n=33)','PRCR (n=9)'],showfliers=True);ax.axhline(0,color='grey',ls='--');ax.set(ylabel='On − Pre cytolytic score',title='Selected paired cohort: descriptive response association');fig.tight_layout();fig.savefig(R/'figures/change-by-response.png',dpi=170);plt.close(fig)
fig,ax=plt.subplots(1,2,figsize=(9,3.8));a=summary['FPKM_baseline'];b=summary['FPKM_baseline_change'];ax[0].bar(['Baseline','Baseline + change'],[a['AUC'],b['AUC']],color=['#9aaeb9','#246b80']);ax[0].set(ylim=(0,1),ylabel='Held-out AUC',title='Conditional association');ax[1].bar(['Baseline','Baseline + change'],[a['Brier'],b['Brier']],color=['#9aaeb9','#246b80']);ax[1].set(ylim=(0,.3),ylabel='Held-out Brier (lower is better)',title='42 paired, response-known participants');fig.tight_layout();fig.savefig(R/'figures/association-validation.png',dpi=170);plt.close(fig)
print(json.dumps(audit,indent=2));print(pd.DataFrame(summaries).to_string(index=False));print(json.dumps(summary,indent=2));print(pd.DataFrame(selection).to_string(index=False))
