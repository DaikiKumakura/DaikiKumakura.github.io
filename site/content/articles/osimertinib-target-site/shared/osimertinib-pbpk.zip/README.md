# Osimertinib target-site PBPK audit
Source: van der Gaag et al.2025, DOI10.1002/psp4.70006, Table1, AppendicesS2-S5.
Source code: https://github.com/ibartelink/Target-Site-PBPK-in-oncology
Fixed commit00c6410c000bcb3b32b7fa54f2cb3a2aed87dcbd, Apache2.0.
See LICENSE and NOTICE. Original articles, figures and patient records are excluded.
Independent adapted Python implementation and numerical comparisons, not a new fit.

Install requirements.txt in your chosen environment.
Run: python analysis/run_analysis.py
Tests: python -m unittest discover -s analysis -p "test_*.py" -q
Only standard Python plus numpy/pandas/scipy/matplotlib; no credentials or downloads.
Raw source hashes document the inputs consulted in the original executed run.
The raw files are deliberately excluded; rerunning without them produces an empty
source-hashes.json, which is not new source verification.

Units: min, nmol, liter, nM. Scalar parameters are numeric facts from public code.
13tissues+10binding states+gut lumen+venous/arterial blood=26states.
Two cumulative states track eliminated and nonabsorbed amounts.
Plasma conversion divides venous blood concentration by blood/plasma ratio.
Kp is not Kpuu. Non-EGFR-bound amount is not pharmacological unbound concentration.
Reversible binding states are not irreversible inhibition or efficacy.
WT and L858R/T790M binding rates are averaged as in the original code.
Active metabolites AZ5104/AZ7550 and target turnover are not modeled.
Daily dosing starts onday0, unlike the original clinical-comparison event schedule.
Common endpoint windowday27-28;28/56day and BDF/Radau checks are recorded.
The fraction absorption mode is an unfitted structural alternative, not a validated fix.
Tumor Kp/flow/EGFR0.5/2 scenarios are not confidence intervals or patient distributions.
Do not use this lung-tumor model to predict CNS/CSF or select treatment doses.
No efficacy or toxicity optimization, independent clinical validation or PET refitting.
