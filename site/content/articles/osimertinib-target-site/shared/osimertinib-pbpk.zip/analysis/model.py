"""Independent equation implementation; see NOTICE for source-model attribution."""
from pathlib import Path
import json
import numpy as np
from scipy.integrate import solve_ivp
P=json.loads((Path(__file__).with_name('parameters.json')).read_text())
TISSUES=['Lung','Tumor','Adipose','Heart','Brain','Muscle','Pancreas','Skin','Spleen','Gut','Liver','Kidney','Rest']
VKEY=['Vlu','Vtumor','Vad','Vhe','Vbr','Vmu','Vpa','Vsk','Vsp','Vgu','Vli','Vki','Vre']
IKEY=['Vlu_int','Vtu_int','Vad_int','Vhe_int',None,'Vmu_int','Vpa_int','Vsk_int',None,'Vgu_int','Vli_int','Vki_int',None]
BOUND=[i for i,t in enumerate(TISSUES) if IKEY[i]]
N=13;LUMEN=23;VEN=24;ART=25;ELIM=26;LOSS=27

def partitions(p=P):
    """Rodgers/lysosomal terms, preserving the published code convention for LogP."""
    den=1+10**(p['pKa']-p['pHp']);di=1+10**(p['pKa']-p['pHiw'])
    kbc=(p['H']-1+p['bp'])/(p['Fu']*p['H'])
    kabc=(kbc-p['FiwBloodcells']*(1+10**(p['pKa']-p['pHbc']))/den-(p['LogP']*p['FnlBloodcells']+(.3*p['LogP']+.7)*p['FnpBloodcells'])/den)*den/(p['APBloodcells']*10**(p['pKa']-p['pHbc']))
    def lys(t,ph,frac):
        return ((p['Fiw'+t]+kabc*p['AP'+t])*10**(p['pKa']-ph)+p['Fiw'+t]+p['LogP']*p['Fnl'+t]+(.3*p['LogP']+.7)*p['Fnp'+t])*frac/den
    kp={}
    for t in TISSUES[:-1]:
        iw=di*p['Fiw'+t]/den;ew=p['Few'+t]
        lp=p['LogP_V'] if t=='Adipose' else p['LogP']
        lipid=(lp*p['Fnl'+t]+(.3*lp+.7)*p['Fnp'+t])/den
        ap=kabc*p['AP'+t]*10**(p['pKa']-p['pHiw'])/den
        if t=='Lung':ly=sum(lys(t,p['pHlys'+x],p['F'+x]*p['Fcell'+x]) for x in ['alv','typ','res'])
        elif t=='Liver':ly=sum(lys(t,p['pHlys'+x],p['F'+x]*p['Fcell'+x]) for x in ['hep','kup','fat','end'])
        elif t=='Kidney':ly=lys(t,p['pHlyskid'],p['Fkid']*p['Fcellkid'])
        elif t=='Tumor':ly=lys(t,p['pHlysres'],p['FlysTumor'])
        else:ly=lys(t,p['pHlys'],p['Flys'+t])
        kp[t]=p['Fu']*(iw+ew+lipid+ap+ly)
    kp['Rest']=float(np.mean(list(kp.values())))
    return kp

def system(kp_factor=1.,flow_factor=1.,egfr_factor=1.,binding=True,absorption='source'):
    p=P;kp=partitions();kp['Tumor']*=kp_factor
    vol=np.array([p[k] for k in VKEY]);q=np.array([p['Q'+t] for t in TISSUES]);q[1]*=flow_factor
    # Redistribute pulmonary flow so the total cardiac output stays unchanged.
    q[0]=p['QLung']+p['QTumor']-q[1]
    assert q[0]>0
    cap=np.array([p['EGFR'+TISSUES[i]]*vol[i]*(egfr_factor if i==1 else 1) for i in BOUND])
    kon=np.array([p['kontumor'] if i==1 else p['konwt'] for i in BOUND]) if binding else np.zeros(len(BOUND))
    koff=np.array([p['kofftumor'] if i==1 else p['koffwt'] for i in BOUND])
    vi=np.array([p[IKEY[i]] for i in BOUND])
    k=np.array([kp[t] for t in TISSUES]);assert np.all(k>0)
    def rhs(t,y):
        dy=np.zeros(28);a=y[:N];b=y[N:N+10];out=q*a/vol*p['bp']/k
        ca=y[ART]/p['Var'];cv=y[VEN]/p['Vve']
        dy[:N]=q*ca-out
        dy[0]=q[0]*cv-out[0];dy[1]=q[1]*cv-out[1]
        dy[10]=out[9]+out[8]+p['QHa']*ca-out[10]
        dy[VEN]=out[[2,3,4,5,6,7,10,11,12]].sum()-(q[0]+q[1])*cv
        dy[ART]=out[0]+out[1]-(q[[2,3,4,5,6,7,9,11,12]].sum()+p['QSpleen']+p['QHa'])*ca
        uptake=kon*a[BOUND]*np.maximum(cap-b,0)/vi-koff*b
        dy[BOUND]-=uptake;dy[N:N+10]=uptake
        ka=p['ka']*p['F'] if absorption=='source' else p['ka']
        absorbed=ka*y[LUMEN];delivered=absorbed if absorption=='source' else absorbed*p['F']
        dy[LUMEN]=-absorbed;dy[9]+=delivered;dy[LOSS]=absorbed-delivered
        eliminated=p['CL_int_lit']*a[10]/vol[10]*p['Fu']*p['bp']/k[10]+p['CL_R']*p['Fu']*a[11]/vol[11]*p['bp']/k[11]
        dy[10]-=p['CL_int_lit']*a[10]/vol[10]*p['Fu']*p['bp']/k[10]
        dy[11]-=p['CL_R']*p['Fu']*a[11]/vol[11]*p['bp']/k[11];dy[ELIM]=eliminated
        return dy
    zero=np.zeros(28)
    linear=np.column_stack([rhs(0,np.eye(28)[i])-rhs(0,zero) for i in range(28)])
    def jac(t,y):
        j=linear.copy()
        for k,i in enumerate(BOUND):
            da=kon[k]*(max(cap[k]-y[N+k],0)-cap[k])/vi[k]
            db=-kon[k]*y[i]/vi[k] if y[N+k]<cap[k] else 0.
            j[i,i]-=da;j[N+k,i]+=da
            j[i,N+k]-=db;j[N+k,N+k]+=db
        return j
    rhs.jac=jac
    return rhs,cap,kp

def simulate(dose=80,days=28,rtol=2e-7,method='BDF',**kwargs):
    rhs,cap,kp=system(**kwargs);y=np.zeros(28);ts=[];ys=[]
    for day in range(days):
        y[LUMEN]+=dose/P['MW']*1e6
        grid=np.linspace(day*1440,(day+1)*1440,97)
        sol=solve_ivp(rhs,(grid[0],grid[-1]),y,t_eval=grid,rtol=rtol,atol=1e-7,method=method,jac=rhs.jac)
        if not sol.success:raise RuntimeError(sol.message)
        ts.extend(grid[1:]);ys.extend(sol.y[:,1:].T);y=sol.y[:,-1]
    t=np.array(ts);a=np.array(ys);last=t>=(days-1)*1440
    plasma=a[:,VEN]/P['Vve']/P['bp'];tumor=a[:,1]/P['Vtumor'];bound=a[:,14]/P['Vtumor']
    occupancy=a[:,14]/cap[1]
    def mean(v):return np.trapz(v[last],t[last])/(t[last][-1]-t[last][0])
    result=dict(dose_mg=dose,days=days,plasma_mean_nM=mean(plasma),tumor_nonEGFR_mean_nM=mean(tumor),tumor_total_mean_nM=mean(tumor+bound),bound_fraction_mean=mean(occupancy),bound_fraction_trough=float(occupancy[-1]),tumor_kp=kp['Tumor'],mass_relative_error=abs(a[-1].sum()-dose/P['MW']*1e6*days)/(dose/P['MW']*1e6*days),nonabsorbed_fraction=a[-1,LOSS]/(dose/P['MW']*1e6*days))
    curves=dict(day=t/1440,plasma=plasma,tumor=tumor,total=tumor+bound,bound_fraction=occupancy)
    return result,curves
