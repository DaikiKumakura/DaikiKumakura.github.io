"""Executed fixed-parameter comparisons; no new fitting or patient distributions."""
from pathlib import Path
import json,platform,hashlib
import numpy as np,pandas as pd,scipy,matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from model import simulate,P,partitions,system
ROOT=Path(__file__).resolve().parents[1]
def main():
    for sub in ['outputs/figures','outputs/tables']:(ROOT/sub).mkdir(parents=True,exist_ok=True)
    rows=[];curves={}
    for absorption in ['source','fraction']:
        for dose in [80,160]:
            m,c=simulate(dose,absorption=absorption);rows.append(dict(absorption=absorption,**m));curves[absorption,dose]=c
    pd.DataFrame(rows).to_csv(ROOT/'outputs/tables/exposure.csv',index=False)
    sensitivity=[]
    for key in ['kp_factor','flow_factor','egfr_factor']:
        for factor in [.5,2.]:
            for dose in [80,160]:
                m,_=simulate(dose,**{key:factor});sensitivity.append(dict(changed=key,factor=factor,**m))
    pd.DataFrame(sensitivity).to_csv(ROOT/'outputs/tables/sensitivity.csv',index=False)
    pd.DataFrame([dict(tissue=k,kp=v) for k,v in partitions().items()]).to_csv(ROOT/'outputs/tables/partition.csv',index=False)
    base=rows[0];tight,_=simulate(80,rtol=1e-9,method='Radau');long,_=simulate(80,days=56)
    keys=['plasma_mean_nM','tumor_total_mean_nM','bound_fraction_mean']
    # Independent instantaneous mass balance at a non-equilibrium nonnegative state.
    rhs,_,_=system();y=np.arange(28,dtype=float)+1;y[26:]=0
    qa=dict(max_solver_relative_difference=max(abs(tight[k]/base[k]-1) for k in keys),day28_vs56_max_relative_difference=max(abs(long[k]/base[k]-1) for k in keys),max_mass_relative_error=max(x['mass_relative_error'] for x in rows+sensitivity),instantaneous_mass_sum=float(rhs(1,y).sum()),parameter_fitting=False,virtual_population=False)
    (ROOT/'outputs/verification.json').write_text(json.dumps(qa,indent=2)+'\n')
    env=dict(python=platform.python_version(),numpy=np.__version__,pandas=pd.__version__,scipy=scipy.__version__,matplotlib=matplotlib.__version__)
    (ROOT/'outputs/environment.json').write_text(json.dumps(env,indent=2)+'\n')
    (ROOT/'outputs/source-hashes.json').write_text(json.dumps({f.name:hashlib.sha256(f.read_bytes()).hexdigest() for f in (ROOT/'data/raw').glob('*') if f.is_file()},indent=2)+'\n')
    plt.rcParams.update({'font.size':10,'axes.spines.top':False,'axes.spines.right':False})
    fig,ax=plt.subplots(1,3,figsize=(12,3.8))
    for dose,color in [(80,'#0072B2'),(160,'#D55E00')]:
        c=curves['source',dose]
        for a,key in zip(ax,['plasma','total','bound_fraction']):
            a.plot(c['day'],c[key]*(100 if key=='bound_fraction' else 1),color=color,label=f'{dose} mg QD')
    for a,title,unit in zip(ax,['Venous plasma','Lung tumor: model total','Reversible binding-state fraction'],['nM','nM','%']):a.set(title=title,xlabel='Day',ylabel=unit);a.grid(alpha=.15)
    ax[2].set_ylim(0,100);ax[0].legend();fig.tight_layout();fig.savefig(ROOT/'outputs/figures/01-exposure.png',dpi=180);plt.close(fig)
    fig,ax=plt.subplots(1,2,figsize=(9,3.8))
    names=['Plasma mean','Tumor total mean','Bound fraction mean'];keys=['plasma_mean_nM','tumor_total_mean_nM','bound_fraction_mean']
    for mode,color,offset in [('source','#0072B2',-.17),('fraction','#D55E00',.17)]:
        x=[next(r for r in rows if r['absorption']==mode and r['dose_mg']==d) for d in [80,160]]
        ax[0].bar(np.arange(3)+offset,[x[1][k]/x[0][k] for k in keys],width=.34,color=color,label=mode)
        ax[1].bar(np.arange(2)+offset,[v['bound_fraction_mean']*100 for v in x],width=.34,color=color,label=mode)
    ax[0].set(xticks=np.arange(3),xticklabels=names,ylabel='160 / 80 mg ratio',ylim=(0,2.3));ax[0].tick_params(axis='x',labelrotation=15)
    ax[1].set(xticks=np.arange(2),xticklabels=['80 mg','160 mg'],ylabel='Mean binding-state fraction (%)',ylim=(0,100));ax[1].legend(title='Absorption convention',loc='lower left',bbox_to_anchor=(0,1.02),ncol=2,fontsize=8)
    fig.tight_layout();fig.savefig(ROOT/'outputs/figures/02-absorption.png',dpi=180);plt.close(fig)
    fig,ax=plt.subplots(1,2,figsize=(10,4))
    for i,(key,label) in enumerate([('kp_factor','Tumor Kp'),('flow_factor','Tumor flow'),('egfr_factor','Tumor EGFR')]):
        subset=[v for v in sensitivity if v['changed']==key and v['dose_mg']==80]
        for v in subset:
            marker='o' if v['factor']==.5 else '^'
            ax[0].scatter(v['plasma_mean_nM']/base['plasma_mean_nM'],v['tumor_total_mean_nM']/base['tumor_total_mean_nM'],marker=marker,s=65,label=f'{label} x{v["factor"]:g}')
            ax[1].scatter(i+(-.12 if v['factor']==.5 else .12),v['bound_fraction_mean']*100,marker=marker,s=65)
    ax[0].axhline(1,color='gray',ls=':');ax[0].axvline(1,color='gray',ls=':');ax[0].set(xlabel='Plasma mean / reference',ylabel='Tumor total mean / reference',xlim=(.95,1.05));ax[0].ticklabel_format(axis='x',style='plain',useOffset=False);ax[0].legend(fontsize=8)
    ax[1].axhline(base['bound_fraction_mean']*100,color='gray',ls=':',label='Reference 80 mg');ax[1].set(xticks=range(3),xticklabels=['Kp','Flow','EGFR'],ylabel='Binding-state fraction (%)',ylim=(0,100));ax[1].legend()
    fig.tight_layout();fig.savefig(ROOT/'outputs/figures/03-sensitivity.png',dpi=180);plt.close(fig)
    print(json.dumps(qa));print(pd.DataFrame(rows).to_string(index=False))
if __name__=='__main__':main()
