import unittest
import numpy as np
from model import simulate,system,P,partitions
class ModelChecks(unittest.TestCase):
    def test_instantaneous_mass(self):
        for mode in ['source','fraction']:
            f,_,_=system(absorption=mode);y=np.arange(28,dtype=float)+1
            self.assertLess(abs(f(0,y).sum()),1e-8)
    def test_jacobian(self):
        f,cap,_=system();y=np.arange(28,dtype=float)+1;y[13:23]=cap*.3
        numeric=np.column_stack([(f(0,y+np.eye(28)[i]*1e-4)-f(0,y-np.eye(28)[i]*1e-4))/2e-4 for i in range(28)])
        np.testing.assert_allclose(f.jac(0,y),numeric,rtol=1e-5,atol=1e-6)
    def test_boundaries(self):
        f,cap,_=system();y=np.ones(28);y[13:23]=cap
        self.assertTrue(np.all(f(0,y)[13:23]<0))
        y[13:23]=0;self.assertTrue(np.all(f(0,y)[13:23]>=0))
    def test_dose_proportional_without_binding(self):
        a,_=simulate(80,days=2,binding=False);b,_=simulate(160,days=2,binding=False)
        self.assertAlmostEqual(b['plasma_mean_nM']/a['plasma_mean_nM'],2,places=5)
        self.assertAlmostEqual(b['tumor_total_mean_nM']/a['tumor_total_mean_nM'],2,places=5)
    def test_fraction_loss(self):
        a,_=simulate(days=2,absorption='fraction');self.assertAlmostEqual(a['nonabsorbed_fraction'],.3,places=3)
        self.assertLess(a['mass_relative_error'],1e-7)
    def test_source_mass(self):
        a,_=simulate(days=2);self.assertEqual(a['nonabsorbed_fraction'],0);self.assertLess(a['mass_relative_error'],1e-7)
    def test_source_parameters(self):
        self.assertAlmostEqual(P['kontumor'],.18);self.assertAlmostEqual(P['kofftumor'],86.1)
        self.assertAlmostEqual(P['Vtumor'],.046);self.assertGreater(partitions()['Tumor'],0)
if __name__=='__main__':unittest.main()
