"""Public Dato-DXd/DXd structural equations, independent hour/ug implementation."""
from dataclasses import dataclass
import numpy as np
from scipy.integrate import solve_ivp
from scipy.optimize import minimize_scalar

def continuous_maximum(solution,times,values,extract):
    """Bracket the sampled maximum, then optimize the dense ODE solution locally."""
    k=int(np.argmax(values));lo=times[max(0,k-1)];hi=times[min(len(times)-1,k+1)]
    best=float(values[k])
    if hi>lo:
        result=minimize_scalar(lambda t:-extract(solution(t)),bounds=(lo,hi),method='bounded',options={'xatol':1e-8})
        best=max(best,float(-result.fun))
    return best

@dataclass
class Parameters:
    cl:float=.386/24
    vc:float=3.06
    q:float=.422/24
    vp:float=2.88
    vmax:float=8410/24
    km:float=4490.
    clp:float=2.66
    vp_pl:float=25.1
    factor:float=.696
    beta:float=.259
    alpha:float=.25

def parameters(weight=66.,albumin=38.,age=62.,tumor=66.,female=False):
    p=Parameters()
    p.cl*=(weight/66)**.75*(albumin/38)**(-.788)*(age/62)**(-.306)*(1-.263 if female else 1)
    p.vc*=(weight/66)**.415*(1-.160 if female else 1)
    p.vp*=(weight/66)**.311
    p.vmax*=(tumor/66)**.125
    p.clp*=(weight/66)**.298*(albumin/38)**.343
    p.vp_pl*=(weight/66)**.530*(1-.185 if female else 1)
    return p

def simulate(dose_mgkg=6.,interval_days=21.,p=None,weight=66.,clock='dose',
             end_days=84.,rtol=1e-8,max_step=2.,linear=False,constant_formation=False,
             time_scale=1.):
    """time_scale=24 expresses the exact same system using day as solver time unit."""
    p=parameters(weight=weight) if p is None else p
    if clock=='cohort':
        if linear or constant_formation or time_scale!=1.:
            raise ValueError('Cohort extension supports only the base hour-scale model')
        return simulate_cohort(dose_mgkg,interval_days,p,weight,end_days,rtol,max_step)
    end=end_days*24/time_scale;interval=interval_days*24/time_scale
    starts=np.arange(0,end-1e-8,interval)
    infusions=[(float(t),float(t+(1.5 if j==0 else .5)/time_scale),dose_mgkg*weight*1000) for j,t in enumerate(starts)]
    changes=list(np.arange(0,end+1e-6,504/time_scale))
    bounds=sorted(set([0.,end,42*24/time_scale,21*24/time_scale,63*24/time_scale]+changes+
                      [x for a,b,_ in infusions for x in [a,b]]))
    bounds=[x for x in bounds if 0<=x<=end]
    y=np.zeros(9);points={};curves=[];delivered=0.;peaks=np.zeros(2)
    for left,right in zip(bounds[:-1],bounds[1:]):
        points[round(left*time_scale,7)]=y.copy()
        idx=max(0,int(np.searchsorted(starts,left+1e-9,side='right')-1))
        if clock=='dose':reset=starts[idx];first=idx==0
        elif clock=='calendar':reset=np.floor((left+1e-9)/(504/time_scale))*504/time_scale;first=left<504/time_scale-1e-9
        else:raise ValueError(clock)
        input_rate=sum(d/(b-a) for a,b,d in infusions if a<=left<b)
        delivered+=input_rate*(right-left)
        def rhs(t,state):
            c=state[0]/p.vc;periph=state[1]/p.vp;cp=state[2]/p.vp_pl
            nonlin=0. if linear else p.vmax*c/(p.km+c)
            elimination=p.cl*c+nonlin
            f=(1. if first else p.factor)*(p.alpha+(1-p.alpha)*np.exp(-p.beta*(t-reset)*time_scale))
            if constant_formation:f=1.
            formation=elimination*4*f*493.5/150000
            transfer=p.q*(c-periph);pelim=p.clp*cp
            return np.array([input_rate+(-elimination-transfer)*time_scale,
                transfer*time_scale,(formation-pelim)*time_scale,c*time_scale,cp*time_scale,
                elimination*time_scale,formation*time_scale,pelim*time_scale,nonlin*time_scale])
        sol=solve_ivp(rhs,(left,right),y,method='DOP853',rtol=rtol,atol=rtol*.01,
                      dense_output=True,max_step=max_step/time_scale)
        assert sol.success
        ts=np.linspace(left,right,max(3,int((right-left)*time_scale)+1))
        values=sol.sol(ts)
        curves.append(np.column_stack([ts*time_scale,values[0]/p.vc,values[2]/p.vp_pl]))
        mask=ts*time_scale>=1008-1e-8
        if np.any(mask):
            for k,index,volume in [(0,0,p.vc),(1,2,p.vp_pl)]:
                peak=continuous_maximum(sol.sol,ts[mask],values[index,mask]/volume,
                                        lambda state,index=index,volume=volume:state[index]/volume)
                peaks[k]=max(peaks[k],peak)
        y=sol.y[:,-1]
    points[round(end*time_scale,7)]=y.copy()
    c=np.vstack(curves)
    adc_error=abs(y[0]+y[1]+y[5]-delivered)/delivered
    payload_error=abs(y[2]+y[7]-y[6])/max(y[6],1e-20)
    assert min(y[:3])>=-1e-8 and adc_error<1e-7 and payload_error<1e-7
    late=c[:,0]>=1008-1e-7
    cycle3_end=points.get(1512.,y);cycle3_start=points.get(1008.,y)
    m=dict(dose_total_mg=delivered/1000,adc_auc0_84=y[3]/24000,
           payload_auc0_84=y[4],adc_cavg42_84=(y[3]-points[1008.][3])/1008/1000,
           payload_cavg42_84=(y[4]-points[1008.][4])/1008,
           adc_cmax42_84=peaks[0]/1000,payload_cmax42_84=peaks[1],
           adc_predose84=y[0]/p.vc/1000,payload_predose84=y[2]/p.vp_pl,
           adc_auc_cycle3=(cycle3_end[3]-cycle3_start[3])/24000,
           payload_auc_cycle3=cycle3_end[4]-cycle3_start[4],
           adc_balance_error=adc_error,payload_balance_error=payload_error)
    m.update(adc_residual_mg=(y[0]+y[1])/1000,adc_nonlinear_eliminated_mg=y[8]/1000,
             adc_linear_eliminated_mg=(y[5]-y[8])/1000)
    return m,c

def simulate_cohort(dose_mgkg,interval_days,p,weight,end_days,rtol,max_step):
    """Unfitted dose-cohort age extension: old ADC does not regain the new-dose factor."""
    end=end_days*24;starts=np.arange(0,end-1e-8,interval_days*24);n=len(starts);j=2*n
    infusions=[(float(t),float(t+(1.5 if i==0 else .5)),dose_mgkg*weight*1000) for i,t in enumerate(starts)]
    bounds=sorted(set([0.,end,1008.,504.,1512.]+[x for a,b,_ in infusions for x in [a,b]]))
    bounds=[x for x in bounds if 0<=x<=end]
    state=np.zeros(2*n+7);points={};curves=[];delivered=0.;peaks=np.zeros(2)
    for left,right in zip(bounds[:-1],bounds[1:]):
        points[round(left,7)]=state.copy()
        rates=np.array([d/(b-a) if a<=left<b else 0. for a,b,d in infusions])
        delivered+=rates.sum()*(right-left)
        first=left<starts[1]-1e-9 if n>1 else True
        def rhs(t,y):
            c=y[:n]/p.vc;periph=y[n:2*n]/p.vp;total=c.sum();cp=y[j]/p.vp_pl
            nonlin=p.vmax*c/(p.km+total);out=p.cl*c+nonlin;transfer=p.q*(c-periph)
            age=np.maximum(t-starts,0.)
            release=(1. if first else p.factor)*(p.alpha+(1-p.alpha)*np.exp(-p.beta*age))
            formation=float(np.sum(out*release))*4*493.5/150000
            deriv=np.empty_like(y);deriv[:n]=rates-out-transfer;deriv[n:2*n]=transfer
            deriv[j]=formation-p.clp*cp;deriv[j+1]=total;deriv[j+2]=cp
            deriv[j+3]=out.sum();deriv[j+4]=formation;deriv[j+5]=p.clp*cp;deriv[j+6]=nonlin.sum()
            return deriv
        sol=solve_ivp(rhs,(left,right),state,method='DOP853',rtol=rtol,atol=rtol*.01,dense_output=True,max_step=max_step)
        assert sol.success
        ts=np.linspace(left,right,max(3,int(right-left)+1));ys=sol.sol(ts)
        curves.append(np.column_stack([ts,ys[:n].sum(axis=0)/p.vc,ys[j]/p.vp_pl]))
        mask=ts>=1008-1e-8
        if np.any(mask):
            peaks[0]=max(peaks[0],continuous_maximum(sol.sol,ts[mask],ys[:n,mask].sum(axis=0)/p.vc,lambda state:state[:n].sum()/p.vc))
            peaks[1]=max(peaks[1],continuous_maximum(sol.sol,ts[mask],ys[j,mask]/p.vp_pl,lambda state:state[j]/p.vp_pl))
        state=sol.y[:,-1]
    points[round(end,7)]=state.copy();c=np.vstack(curves);late=c[:,0]>=1008-1e-7
    residual=float(state[:2*n].sum());adc_error=abs(residual+state[j+3]-delivered)/delivered
    payload_error=abs(state[j]+state[j+5]-state[j+4])/state[j+4]
    assert adc_error<1e-7 and payload_error<1e-7
    m=dict(dose_total_mg=delivered/1000,adc_auc0_84=state[j+1]/24000,payload_auc0_84=state[j+2],
           adc_cavg42_84=(state[j+1]-points[1008.][j+1])/1008/1000,
           payload_cavg42_84=(state[j+2]-points[1008.][j+2])/1008,
           adc_cmax42_84=peaks[0]/1000,payload_cmax42_84=peaks[1],
           adc_predose84=state[:n].sum()/p.vc/1000,payload_predose84=state[j]/p.vp_pl,
           adc_auc_cycle3=(points[1512.][j+1]-points[1008.][j+1])/24000,
           payload_auc_cycle3=points[1512.][j+2]-points[1008.][j+2],
           adc_balance_error=adc_error,payload_balance_error=payload_error,
           adc_residual_mg=residual/1000,adc_nonlinear_eliminated_mg=state[j+6]/1000,
           adc_linear_eliminated_mg=(state[j+3]-state[j+6])/1000)
    return m,c
