"""Small conditional schedule analysis and source-model consistency checks."""
from pathlib import Path
from dataclasses import replace
import json,platform,hashlib
import numpy as np
import pandas as pd
import scipy,matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from model import simulate,parameters

ROOT=Path(__file__).resolve().parents[1]
SCHEDULES=[(6,21,'6 mg/kg q21d'),(4,14,'4 mg/kg q14d'),(2,7,'2 mg/kg q7d')]
COLORS=['#0072B2','#D55E00','#009E73']
KEYS=['adc_auc0_84','payload_auc0_84','adc_cavg42_84','payload_cavg42_84',
      'adc_cmax42_84','payload_cmax42_84','adc_predose84','payload_predose84']

def main():
    for d in ['outputs/figures','outputs/tables']:(ROOT/d).mkdir(parents=True,exist_ok=True)
    plt.rcParams.update({'font.size':10,'axes.spines.top':False,'axes.spines.right':False})
    rows=[];profiles={};reference,_=simulate()
    for clock in ['dose','cohort']:
        for dose,interval,name in SCHEDULES:
            m,c=simulate(dose,interval,clock=clock)
            assert abs(m['dose_total_mg']-1584)<1e-6
            rows.append(dict(clock=clock,schedule=name,**m))
            profiles[(clock,name)]=c
    table=pd.DataFrame(rows);table.to_csv(ROOT/'outputs/tables/exposure.csv',index=False)
    ratios=[]
    for r in rows:
        matched_reference=next(x for x in rows if x['clock']==r['clock'] and x['schedule']=='6 mg/kg q21d')
        ratios.append(dict(clock=r['clock'],schedule=r['schedule'],**{k:r[k]/matched_reference[k] for k in KEYS}))
    pd.DataFrame(ratios).to_csv(ROOT/'outputs/tables/ratios.csv',index=False)
    # Fig4 values: source medians of sampled parameter vectors, not a new clinical benchmark.
    source_cases=[('albumin19',dict(albumin=19),66.,.651,1.28),
                  ('albumin50',dict(albumin=50),66.,1.19,.900),
                  ('weight37',dict(weight=37),37.,.622,.669),
                  ('weight156',dict(weight=156),156.,1.61,1.83)]
    checks=[]
    for name,cov,wt,adc,dx in source_cases:
        m,_=simulate(p=parameters(**cov),weight=wt)
        ra=m['adc_auc_cycle3']/reference['adc_auc_cycle3'];rp=m['payload_auc_cycle3']/reference['payload_auc_cycle3']
        checks.append(dict(case=name,source_adc_ratio=adc,computed_adc_ratio=ra,source_payload_ratio=dx,computed_payload_ratio=rp,
            adc_relative_difference=ra/adc-1,payload_relative_difference=rp/dx-1))
    pd.DataFrame(checks).to_csv(ROOT/'outputs/tables/source-consistency.csv',index=False)
    # Equal-dose AUC difference decomposed exactly into finite-horizon residual and nonlinear removal.
    p=parameters();decomp=[]
    for r in rows:
        if r['clock']!='dose':continue
        nl=-(r['adc_nonlinear_eliminated_mg']-reference['adc_nonlinear_eliminated_mg'])*1000/p.cl/24000
        tail=-(r['adc_residual_mg']-reference['adc_residual_mg'])*1000/p.cl/24000
        delta=r['adc_auc0_84']-reference['adc_auc0_84']
        assert abs(delta-nl-tail)<1e-5
        decomp.append(dict(schedule=r['schedule'],auc_difference=delta,nonlinear_component=nl,remaining_drug_component=tail,
                           nonlinear_eliminated_mg=r['adc_nonlinear_eliminated_mg'],remaining_adc_mg=r['adc_residual_mg']))
    pd.DataFrame(decomp).to_csv(ROOT/'outputs/tables/auc-decomposition.csv',index=False)
    # Published marginal90% bootstrap bounds; no joint parameter uncertainty claim.
    bounds={'cl':(.353/24,.410/24),'vc':(3.01,3.11),'q':(.388/24,.461/24),'vp':(2.78,3.00),
            'vmax':(6840/24,10400/24),'km':(3260,6190),'clp':(2.58,2.73),'vp_pl':(24.,26.2),
            'factor':(.685,.707),'beta':(.245,.276)}
    sensitivity=[]
    for key,(lo,hi) in bounds.items():
        for value in [lo,hi]:
            q=replace(p,**{key:value});ref,_=simulate(p=q)
            for dose,interval,name in SCHEDULES[1:]:
                m,_=simulate(dose,interval,p=q)
                sensitivity.append(dict(parameter=key,value=value,schedule=name,**{k:m[k]/ref[k] for k in KEYS}))
    pd.DataFrame(sensitivity).to_csv(ROOT/'outputs/tables/parameter-sensitivity.csv',index=False)
    grid=[]
    for weight in [45.,66.,85.]:
        for albumin in [28.,38.,45.]:
            q=parameters(weight=weight,albumin=albumin)
            ref,_=simulate(p=q,weight=weight)
            for clock in ['dose','cohort']:
                ref,_=simulate(p=q,weight=weight,clock=clock)
                for dose,interval,name in SCHEDULES[1:]:
                    m,_=simulate(dose,interval,p=q,weight=weight,clock=clock)
                    grid.append(dict(weight_kg=weight,albumin_gL=albumin,clock=clock,schedule=name,
                                     **{k:m[k]/ref[k] for k in KEYS}))
    pd.DataFrame(grid).to_csv(ROOT/'outputs/tables/conditional-grid.csv',index=False)
    fig,axs=plt.subplots(2,1,figsize=(10,7),sharex=True)
    for (dose,interval,name),color in zip(SCHEDULES,COLORS):
        c=profiles[('dose',name)]
        axs[0].plot(c[:,0]/24,c[:,1]/1000,label=name,color=color)
        axs[1].plot(c[:,0]/24,c[:,2],color=color)
    axs[0].set(ylabel='ADC (µg/mL)',title='66 kg reference, equal total dose over 84 days; dose-reset clock');axs[0].legend(ncol=3,fontsize=8)
    axs[1].set(xlabel='Time since first infusion (day)',ylabel='Unconjugated DXd (ng/mL)')
    for ax in axs:ax.set_ylim(bottom=0)
    fig.tight_layout();fig.savefig(ROOT/'outputs/figures/01-profiles.png',dpi=180);plt.close(fig)
    fig,axs=plt.subplots(1,3,figsize=(12,4))
    rtable=pd.DataFrame(ratios)
    for ax,key,title in zip(axs,['adc_cavg42_84','payload_cavg42_84','payload_cmax42_84'],['ADC mean, days42–84','DXd mean, days42–84','DXd peak, days42–84']):
        for clock,marker,linestyle in [('dose','o','-'),('cohort','s','--')]:
            g=rtable[rtable.clock==clock]
            ax.plot(range(3),g[key],marker=marker,ls=linestyle,label='Patient-level reset' if clock=='dose' else 'Preserve cohort age')
        ax.axhline(1,color='grey',ls=':');ax.set(xticks=range(3),xticklabels=['6 q21d','4 q14d','2 q7d'],title=title,ylabel='Ratio to 6 mg/kg q21d')
    axs[1].legend(fontsize=8);fig.suptitle('Each rule normalized to its own q21d reference; cohort extension is unfitted');fig.tight_layout();fig.savefig(ROOT/'outputs/figures/02-clock-ratios.png',dpi=180);plt.close(fig)
    fig,ax=plt.subplots(figsize=(9,4.5));x=np.arange(3);dc=pd.DataFrame(decomp)
    ax.bar(x-.16,dc.nonlinear_component,width=.3,label='Nonlinear removal contribution',color='#D55E00')
    ax.bar(x+.16,dc.remaining_drug_component,width=.3,label='Drug remaining at day84 contribution',color='#0072B2')
    ax.plot(x,dc.auc_difference,'ko',label='Total finite-horizon AUC difference');ax.axhline(0,color='grey')
    ax.set(xticks=x,xticklabels=[n for _,_,n in SCHEDULES],ylabel='ADC AUC0–84 difference (µg·day/mL)',title='Same administered dose does not mean the same eliminated dose by day84')
    ax.legend(fontsize=8);fig.tight_layout();fig.savefig(ROOT/'outputs/figures/03-auc-accounting.png',dpi=180);plt.close(fig)
    tight,_=simulate(rtol=1e-10,max_step=.5);day,_=simulate(time_scale=24.)
    qa=dict(max_solver_relative_difference=max(abs(tight[k]/reference[k]-1) for k in KEYS),
            max_hour_day_relative_difference=max(abs(day[k]/reference[k]-1) for k in KEYS),
            max_adc_mass_error=max(r['adc_balance_error'] for r in rows),
            max_payload_mass_error=max(r['payload_balance_error'] for r in rows),
            source_adc_max_relative_difference=max(abs(r['adc_relative_difference']) for r in checks),
            source_payload_max_relative_difference=max(abs(r['payload_relative_difference']) for r in checks),
            virtual_population=False,parameter_fitting=False)
    assert qa['max_solver_relative_difference']<1e-5 and qa['max_hour_day_relative_difference']<1e-5
    (ROOT/'outputs/verification.json').write_text(json.dumps(qa,indent=2)+'\n')
    (ROOT/'outputs/environment.json').write_text(json.dumps(dict(python=platform.python_version(),numpy=np.__version__,pandas=pd.__version__,scipy=scipy.__version__,matplotlib=matplotlib.__version__),indent=2)+'\n')
    sources={f.name:hashlib.sha256(f.read_bytes()).hexdigest() for f in (ROOT/'data/raw').glob('*') if f.suffix in ['.xml','.pdf','.docx']}
    (ROOT/'outputs/source-hashes.json').write_text(json.dumps(sources,indent=2)+'\n')
    print(pd.DataFrame(ratios).to_string(index=False));print(json.dumps(qa,indent=2))

if __name__=='__main__':main()
