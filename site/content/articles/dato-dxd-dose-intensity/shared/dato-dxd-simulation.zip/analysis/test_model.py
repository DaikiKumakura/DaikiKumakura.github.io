"""Checks of numerical implementation, not clinical regimen validation."""
import unittest
import numpy as np
from model import simulate,parameters

class ModelTests(unittest.TestCase):
    def test_equal_nominal_input(self):
        values=[simulate(d,t)[0]['dose_total_mg'] for d,t in [(6,21),(4,14),(2,7)]]
        np.testing.assert_allclose(values,1584,rtol=1e-12)
    def test_mass_balance(self):
        for clock in ['dose','cohort']:
            m,_=simulate(2,7,clock=clock)
            self.assertLess(m['adc_balance_error'],1e-7)
            self.assertLess(m['payload_balance_error'],1e-7)
    def test_hour_day_equivalence(self):
        h,_=simulate();d,_=simulate(time_scale=24.)
        for key in ['adc_auc0_84','payload_auc0_84','adc_predose84','payload_predose84']:
            self.assertLess(abs(h[key]/d[key]-1),1e-6)
    def test_linear_auc_with_tail(self):
        p=parameters();expected=1584*1000/p.cl/24000
        for dose,interval in [(6,21),(4,14),(2,7)]:
            m,_=simulate(dose,interval,linear=True)
            corrected=m['adc_auc0_84']+m['adc_residual_mg']*1000/p.cl/24000
            self.assertAlmostEqual(corrected/expected,1,places=7)
    def test_cohort_does_not_change_adc(self):
        for dose,interval in [(6,21),(2,7)]:
            source,_=simulate(dose,interval);cohort,_=simulate(dose,interval,clock='cohort')
            for key in ['adc_auc0_84','adc_cavg42_84','adc_predose84']:
                self.assertLess(abs(source[key]/cohort[key]-1),1e-6)
    def test_step_refinement(self):
        a,_=simulate(4,14);b,_=simulate(4,14,rtol=1e-10,max_step=.5)
        for key in ['adc_auc0_84','payload_auc0_84','payload_cmax42_84']:
            self.assertLess(abs(a[key]/b[key]-1),1e-5)

if __name__=='__main__':unittest.main()
