# Dato-DXd equal-input conditional simulation
Source: Hong et al. DOI 10.1002/psp4.70118, Tables 1-2, equations and supplementary code.
Independent implementation; original papers and NONMEM source are not redistributed.
Python requirements are pinned to the executed environment.
Run: python analysis/run_analysis.py
Then: python -m unittest discover -s analysis -p "test_*.py" -q
No downloads or credentials required. Raw sources are optional for source-hashes.json.
Units: hour, microgram, liter. DXd CL is 2.66 L/h, not L/day.
ADC CL, Q and Vmax are divided by24. Unconjugated is not protein-unbound.
Compare24 mg/kg over84 days; exclude dosing at day84; late window42-84days.
Reference66kg, eta0. No population sampling, parameter estimation or patient data.
Original development intervals were Q3W; Q2W and QW are interval extrapolations.
The cohort-age extension is unfitted and unvalidated; it is not a true DAR model
or a biological confidence bound. Each clock is normalized to its own reference.
OAT marginal90%CI sensitivity is not a joint confidence/prediction interval.
Source Figure4 checks are implementation consistency, not external validation.
No efficacy, toxicity or treatment recommendation follows from these simulations.
Figures, aggregate results and independent code are original.
