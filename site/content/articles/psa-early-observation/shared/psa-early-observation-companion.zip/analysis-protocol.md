# M03 implemented protocol v1.0

2026-10-04. The code specifications were fixed before inspecting held-out performance. This is a retrospective analysis, not a registered prospective protocol. Earlier planning and PDS reconnaissance are private historical records; this document is suitable for a reproducibility companion.

## Source and audit

Use the official, registration-free Monolix PSA_survival_dataset.csv, SHA256 3906a6ced50c310393a48696f2322370fd02db0d243eee5467a04965e6ae758a. This is the original Desmée et al. training subset of 400 patients from the VENICE comparator, not all 598 participants and not the separate 196-person original validation dataset. Here it is divided again into 240 training, 80 calibration and 80 test participants, seed 20261004. No external validation is claimed.

YTYPE=1 is log(PSA+1), days relative to treatment initiation; CENS=1 means below 0.1 ng/mL and its supplied transformed threshold equals log(1.1). YTYPE=2 contains a time-zero record and a final survival/censoring record per participant. Treatment end is TIMEENDtr. Two same-day repeated PSA groups with different values are averaged on the supplied scale. Do not call them identical duplicates. Negative-time observations are audited but not modeled here. Their natural history is not the on-treatment response model.

## QOI / COU

QOI: does separating decline and regrowth improve a 12-week-ahead prediction window, compared with simple extrapolation, and when is growth identifiable? COU: retrospective assessment of measurement and modeling design, not individual treatment changes, drug comparisons, a qualified OS surrogate, or cancer-cell counts.

## Structural candidates

Constant last observation; linear transformed PSA with hierarchical intercept/slope; single exponential decay; and B[A exp(-d t)+(1-A) exp(g t)] followed by log1p. The two-component raw-scale response divided by B is exactly 1 at treatment initiation. B is latent rather than setting every observation equal to a noisy first-observation ratio. Parameters are log B, log d, log g, logit A with independent Gaussian random effects. Rates are day^-1. These are PSA shape parameters, not direct cellular resistant/sensitive fractions.

Population fitting maximizes a first-order Gaussian marginal likelihood: f(z_i,t) approximately f(mu,t)+J(mu,t)(z_i-mu), covariance J diag(omega^2) J^T+sigma^2 I. The linear candidate has an exact Gaussian marginal likelihood. The nonlinear candidates have a Taylor approximation. This is not SAEM, not full exact marginal NLME, and not a reproduction of the original ODE/survival model. Broad parameter bounds, random-effect scales, three fixed starting configurations and all optimizer outcomes are in model.py/population-fits.json. Report boundary optima and differences between starts rather than treating them as definitive estimates.

Population marginal fitting uses uncensored observations only. Individual nonlinear MAP predictions use uncensored Gaussian residuals and log Gaussian CDF terms for BLQ. This hybrid is computationally transparent but can bias population estimation under censoring; the omission sensitivity does not qualify a fully censored population likelihood. Predictive validation and recalibration are therefore essential. Local covariance uses an uncensored Gauss-Newton information matrix plus prior precision, not an exact posterior; it is only an identification diagnostic.

## Landmarks and selection

Landmarks at 42/84/126/168 days. Eligible participants are still on treatment and under survival follow-up at the landmark, have at least two on-treatment PSA records in [0,L] spanning 14 days. Population fitting uses only training participants and observations available by L. Calibrating/test participants use their own prior history only; no future test value affects hyperparameters or individual estimation.

Targets are uncensored observed PSA in (L,L+84] while still on treatment. This is a varying set of patients across landmarks and an observed-target estimand, not all randomized patients or a death-adjusted outcome. Report eligibility, target availability, future BLQ, treatment ends and deaths. Missing and post-treatment outcomes are not imputed. On-treatment targets have measurements in a window rather than a common exact future visit. Additional 42-day horizon and post-treatment-target analyses are sensitivity comparisons, with their denominators stated.

## Intervals, uncertainty, diagnostics

For each fixed candidate and landmark, calibration score is the participant's maximum absolute prediction error over the next 84-day observed target window. Radius is the ceil((m+1)*0.9)-th ordered calibration score. A finite radius requires enough calibration participants. Test coverage is simultaneous coverage of all observed targets per patient, separately from row coverage. This split-conformal interval is calibrated in supplied log1p units; it does not establish coverage after nonrandom dropout or for missing BLQ values. It is not a latent-mechanism credible interval and not an exact-time survival prediction. If showing a concentration interval, use expm1 and truncate lower bound at 0.

Primary MAE is patient-weighted: average within-patient absolute log1p error, then average over patients. RMSE is sqrt(mean of per-patient mean square error). Paired MAE differences use identical patients/targets for two-component and references, with 4,000 patient resampling percentile intervals. These quantify finite test-cohort sampling variation conditional on fitted models, not full refitting uncertainty or multiplicity-adjusted inferential tests. Avoid selecting a universal best landmark using these different risk sets.

Data-only information rank/condition, local posterior-to-prior SD ratios, MAP failures/boundaries and start dependence are reported for eligible test patients, including those without future targets. No individually definitive g/d values are published.

Sensitivity: individual prior SD scaled 0.5/2; individual BLQ observations omitted; 42-day horizon; inclusion of observed post-treatment targets. These do not identify MNAR dropout or treatment-switch effects. No OS model is fitted, since the primary question is forecast accuracy.

## Completion and release

All aggregate data, source hashes, code, test results, original figures and executed notebook must agree. No raw CSV, participant split, individual parameter estimates or source-paper images enter public companion archives. The public download is accessible without a PDS agreement; no claim of an unrestricted redistribution license is made. Cite its source and redistribute original code and aggregate analysis only. Public candidate stays outside the live site until a publication date is specified.
