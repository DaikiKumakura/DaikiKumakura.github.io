"""Original aggregate figures; no participant trajectories or identifiers."""
from pathlib import Path
import csv,json
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
ROOT=Path(__file__).resolve().parent
BLUE='#245b76';GRAY='#6c7278';LIGHT='#bdc4c9';ORANGE='#ab6540'
def rows(name):return list(csv.DictReader((ROOT/'results'/name).open()))
def finish(fig,name):
    (ROOT/'figures').mkdir(exist_ok=True);fig.tight_layout()
    for ext in ['png','svg']:fig.savefig(ROOT/'figures'/f'{name}.{ext}',dpi=180,bbox_inches='tight',metadata={'Creator':'Original aggregate analysis','Date':None} if ext=='svg' else {'Software':'Original aggregate analysis'})
    plt.close(fig)
def run():
    plt.rcParams.update({'font.family':'DejaVu Sans','font.size':10,'axes.spines.top':False,'axes.spines.right':False,'axes.grid':False,'figure.facecolor':'white','svg.hashsalt':'M03'})
    p=rows('prediction-performance.csv');a=[x for x in rows('availability.csv') if x['split']=='test'];i=rows('identifiability.csv');q=[x for x in rows('paired-comparison.csv') if x['reference']=='last']
    weeks=np.array([6,12,18,24])
    fig,ax=plt.subplots(figsize=(7.4,3.6))
    ax.plot(weeks,[80]*4,'--',color=LIGHT,label='Assigned test participants (80)')
    for col,key,lab in [(GRAY,'landmark_eligible','Eligible at landmark'),(BLUE,'has_future_on_treatment','Observed on-treatment targets')]:
        y=[int(x[key]) for x in a];ax.plot(weeks,y,'o-',color=col,label=lab)
        for x,v in zip(weeks,y):ax.text(x,v+(2.2 if col==GRAY else -4.5),str(v),ha='center',color=col)
    ax.set(xlabel='Observation landmark (weeks)',ylabel='Test participants',xticks=weeks,ylim=(0,88),title='The population changes as observation time increases');ax.legend(loc='lower left',frameon=False)
    finish(fig,'target-availability')
    fig,axs=plt.subplots(1,2,figsize=(9.4,4))
    for kind,col,mark,label in [('last',GRAY,'s','Last observation'),('linear',LIGHT,'^','Linear hierarchy'),('decay',ORANGE,'D','Single decay'),('two',BLUE,'o','Decline + regrowth')]:
        rr=[x for x in p if x['model']==kind];axs[0].plot(weeks,[float(x['mae']) for x in rr],marker=mark,color=col,label=label)
    axs[0].set(xlabel='Landmark (weeks)',ylabel='Patient-weighted MAE [log(PSA+1)]',xticks=weeks,ylim=(0,.7),title='12-week observed-target prediction');axs[0].legend(frameon=False,fontsize=8)
    y=np.array([float(x['mae_difference_two_minus_reference']) for x in q]);lo=np.array([float(x['ci_low']) for x in q]);hi=np.array([float(x['ci_high']) for x in q])
    axs[1].axhline(0,color=GRAY,lw=1);axs[1].errorbar(weeks,y,yerr=[y-lo,hi-y],fmt='o',capsize=4,color=BLUE)
    axs[1].set(xlabel='Landmark (weeks)',ylabel='MAE difference [two-component − last]',xticks=weeks,title='Paired participant bootstrap, 95% interval');axs[1].text(.04,.96,'Below zero favors the two-component model',transform=axs[1].transAxes,va='top',fontsize=8)
    finish(fig,'prediction-comparison')
    fig,axs=plt.subplots(1,2,figsize=(9.2,3.7))
    for kind,col,mark,label in [('last',GRAY,'s','Last observation'),('two',BLUE,'o','Decline + regrowth')]:
        rr=[x for x in p if x['model']==kind]
        axs[0].plot(weeks,[100*float(x['patient_simultaneous_coverage']) for x in rr],marker=mark,color=col,label=label)
        axs[1].plot(weeks,[float(x['interval_width']) for x in rr],marker=mark,color=col,label=label)
    axs[0].axhline(90,color=LIGHT,ls='--');axs[0].set(xlabel='Landmark (weeks)',ylabel='Patient simultaneous coverage (%)',ylim=(75,101),xticks=weeks,title='Held-out coverage of observed targets');axs[0].legend(frameon=False,fontsize=8)
    axs[1].set(xlabel='Landmark (weeks)',ylabel='Full interval width [log(PSA+1)]',ylim=(0,4.5),xticks=weeks,title='Split-conformal interval width')
    finish(fig,'interval-calibration')
    fig,axs=plt.subplots(1,2,figsize=(9.2,3.7))
    axs[0].plot(weeks,[float(x['median_d_sd_ratio']) for x in i],'s-',color=GRAY,label='log decline rate')
    y=np.array([float(x['median_g_sd_ratio']) for x in i]);axs[0].plot(weeks,y,'o-',color=BLUE,label='log regrowth rate')
    axs[0].fill_between(weeks,[float(x['g_sd_ratio_q25']) for x in i],[float(x['g_sd_ratio_q75']) for x in i],color=BLUE,alpha=.15)
    axs[0].set(xlabel='Landmark (weeks)',ylabel='Local conditional SD / prior SD',xticks=weeks,ylim=(0,1.08),title='A fitted curve need not identify regrowth');axs[0].legend(frameon=False,fontsize=8)
    axs[0].text(.03,.06,'Regrowth ratios remain approximately 1.\nLocal Gaussian diagnostic, not a qualified posterior.',transform=axs[0].transAxes,fontsize=8)
    vals=[100*int(x['condition_gt_1e6'])/int(x['n_patients']) for x in i];axs[1].bar(weeks,vals,width=3,color=BLUE)
    axs[1].set(xlabel='Landmark (weeks)',ylabel='Eligible test patients (%)',xticks=weeks,ylim=(0,108),title='Data-only condition number > 10⁶')
    for x,y in zip(weeks,vals):axs[1].text(x,y+1,f'{y:.0f}%',ha='center',fontsize=9)
    finish(fig,'regrowth-identification')
    s=rows('sensitivity.csv');fig,axs=plt.subplots(1,2,figsize=(9.2,3.7))
    for sc,col,mark,label in [('prior_half',LIGHT,'^','Prior SD ×0.5'),('horizon_84_days',BLUE,'o','Primary'),('prior_double',ORANGE,'s','Prior SD ×2')]:
        rr=[x for x in s if x['model']=='two' and x['scenario']==sc];axs[0].plot(weeks,[float(x['mae']) for x in rr],marker=mark,color=col,label=label)
    axs[0].set(xlabel='Landmark (weeks)',ylabel='Patient-weighted MAE [log(PSA+1)]',xticks=weeks,ylim=(0,.8),title='Regrowth predictions depend on shrinkage');axs[0].legend(frameon=False,fontsize=8)
    for w,col in [(6,LIGHT),(12,GRAY),(18,ORANGE),(24,BLUE)]:
        rr=[x for x in rows('residual-bins.csv') if int(x['week'])==w];axs[1].plot([float(x['mean_prediction']) for x in rr],[float(x['mean_residual']) for x in rr],'o-',color=col,label=f'{w} weeks')
    axs[1].axhline(0,color=LIGHT);axs[1].set(xlabel='Mean predicted log(PSA+1), equal-count bins',ylabel='Mean observed − predicted',title='Aggregate held-out residual diagnostic');axs[1].legend(frameon=False,fontsize=8)
    finish(fig,'prediction-sensitivity')
    print('Five original aggregate figures rendered.')
if __name__=='__main__':run()
