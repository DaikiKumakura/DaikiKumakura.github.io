"""Independent reconstruction of every primary held-out prediction metric."""
import csv,json,unittest,io,contextlib
from pathlib import Path
import numpy as np
from data import audit,eligible,history,future,ROOT
from model import curve,fit_individual
from analysis import quantile
def validate():
    import test_analysis
    suite=unittest.defaultTestLoader.loadTestsFromModule(test_analysis)
    result=unittest.TextTestRunner(stream=io.StringIO()).run(suite)
    assert result.wasSuccessful() and result.testsRun==14
    patients,split,source=audit()
    fits=json.loads((ROOT/'results/population-fits.json').read_text())
    individual=json.loads((ROOT/'private/individual-fits.json').read_text())
    stored={(x['week'],x['kind'],x['id']):x for x in individual}
    with (ROOT/'results/prediction-performance.csv').open() as f:table=list(csv.DictReader(f))
    max_difference=0.;history_blq=0
    for row in table:
        week=int(row['week']);L=week*7;kind=row['model'];group=[p for p in patients if split[p['id']]=='test' and eligible(p,L)]
        errors=[];row_errors=[];covered=[]
        for p in group:
            t,y,c=history(p,L)
            tt,yy=future(p,L)
            if not len(tt):continue
            if kind=='two':history_blq+=int(np.sum(c))
            pred=np.full(len(tt),y[-1]) if kind=='last' else curve(stored[(week,kind,p['id'])]['z'],tt,kind)
            e=yy-pred;errors.append(e);row_errors.extend(e);covered.append(np.all(np.abs(e)<=float(row['interval_radius'])))
        measures={'mae':np.mean([np.mean(np.abs(x)) for x in errors]),'rmse':np.sqrt(np.mean([np.mean(x*x) for x in errors])),'bias':np.mean([np.mean(x) for x in errors]),'patient_simultaneous_coverage':np.mean(covered),'measurement_coverage':np.mean(np.abs(row_errors)<=float(row['interval_radius']))}
        assert len(errors)==int(row['n_patients']) and len(row_errors)==int(row['n_measurements'])
        for k,v in measures.items():
            difference=abs(v-float(row[k]));max_difference=max(max_difference,difference);assert difference<1e-12,(week,kind,k)
        scores=[]
        for p in patients:
            if split[p['id']]!='calibration' or not eligible(p,L):continue
            tt,yy=future(p,L)
            if not len(tt):continue
            t,y,c=history(p,L)
            if kind=='last':pred=np.full(len(tt),y[-1])
            else:
                fit=fits[f'{week}_{kind}'];z,_,_=fit_individual(t,y,c,fit);pred=curve(z,tt,kind)
            scores.append(float(np.max(np.abs(yy-pred))))
        assert len(scores)==int(row['calibration_patients'])
        assert abs(quantile(scores)-float(row['interval_radius']))<1e-10
    assert history_blq==0,'Revise the manuscript BLQ sensitivity explanation'
    assert all(all(x['success'] for x in f['starts']) for f in fits.values())
    assert all(abs(fits[f'{w}_two']['mu'][2]+10)<1e-8 for w in [6,12,18,24])
    article=(ROOT/'article.md').read_text(encoding='utf-8')
    assert '{{' not in article and len(__import__('re').findall(r'!\[[^\]]+\]\(figures/',article))==5
    assert 'SAEM' in article and 'not external validation' in article.lower()
    report={'status':'pass','tests':result.testsRun,'primary_rows_reconstructed':len(table),'max_primary_metric_difference':float(max_difference),'calibration_radii_recomputed':True,'source_hash':'verified','source_scale':'log1p threshold plus original equation','patient_split':'disjoint','future_leakage_checks':'pass','test_history_blq':history_blq,'population_starts_successful':36,'growth_bound_active_all_landmarks':True,'numerical_convergence_is_not_identification':True,'figures':5,'article_private_content':'excluded'}
    (ROOT/'results/validation.json').write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps(report,indent=2));return report
if __name__=='__main__':validate()
