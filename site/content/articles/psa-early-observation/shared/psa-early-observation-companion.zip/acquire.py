"""Acquire only the publicly offered official CSV, pinned by its original SHA."""
from pathlib import Path
import hashlib,json,urllib.request
ROOT=Path(__file__).resolve().parent
def acquire():
    manifest=json.loads((ROOT/'sources/monolix-manifest.json').read_text())
    target=ROOT/'sources/PSA_survival_dataset.csv'
    if not target.exists():
        target.parent.mkdir(exist_ok=True)
        payload=urllib.request.urlopen(manifest['url'],timeout=60).read()
        if hashlib.sha256(payload).hexdigest()!=manifest['sha256']:
            raise ValueError('Upstream bytes changed; audit the replacement before using it.')
        target.write_bytes(payload)
    assert hashlib.sha256(target.read_bytes()).hexdigest()==manifest['sha256']
    return target
if __name__=='__main__':acquire();print('Pinned official public CSV verified.')
