"""Data audit. Participant-level output remains local in private/."""
from pathlib import Path
import csv,json,hashlib,collections
import numpy as np
from acquire import acquire,ROOT
LOQ=np.log1p(.1)
def load():
    with acquire().open(encoding='utf-8-sig') as f:rows=list(csv.DictReader(f))
    groups=collections.defaultdict(list)
    for r in rows:
        groups[r['ID']].append({k:float(v) for k,v in r.items() if k!='ID'})
    patients=[];duplicate_groups=[]
    for ident,rr in sorted(groups.items()):
        ends={r['TIMEENDtr'] for r in rr};assert len(ends)==1
        ev=[r for r in rr if r['YTYPE']==2];assert len(ev)==2
        assert sum(r['TIME']==0 and r['Y']==0 for r in ev)==1
        final=max(ev,key=lambda r:r['TIME']);assert final['Y'] in (0,1)
        values=collections.defaultdict(list)
        for r in rr:
            if r['YTYPE']==1:
                assert r['CENS'] in (0,1)
                assert r['Y']>=0
                if r['CENS']:assert abs(r['Y']-LOQ)<1e-8
                values[r['TIME']].append(r)
        records=[]
        for t,v in sorted(values.items()):
            assert len({x['CENS'] for x in v})==1
            if len(v)>1:duplicate_groups.append({'time':t,'rows':len(v),'range_y':max(x['Y'] for x in v)-min(x['Y'] for x in v)})
            # Repeated same-day observations are collapsed on the supplied log1p scale.
            records.append((t,np.mean([x['Y'] for x in v]),v[0]['CENS']))
        a=np.array(records)
        patients.append({'id':ident,'t':a[:,0],'y':a[:,1],'c':a[:,2].astype(bool),'end':next(iter(ends)),'last':final['TIME'],'dead':int(final['Y'])})
    return patients,rows,duplicate_groups
def audit():
    p,rows,dup=load()
    rng=np.random.default_rng(20261004);order=rng.permutation(len(p))
    # 240 train / 80 calibration / 80 test. Hashes, not participant IDs, enter public outputs.
    split={p[i]['id']:('train' if j<240 else 'calibration' if j<320 else 'test') for j,i in enumerate(order)}
    report={'patients':len(p),'raw_rows':len(rows),'raw_psa':sum(r['YTYPE']=='1' for r in rows),'clean_psa':sum(len(x['t']) for x in p),'duplicate_groups':dup,'raw_blq':sum(r['YTYPE']=='1' and r['CENS']=='1' for r in rows),'deaths':sum(x['dead'] for x in p),'observation_scale':'natural log(PSA+1); BLQ log(1.1)','time_unit':'days from treatment initiation','treatment_groups':1,'study':'VENICE comparator; original paper training subset, not original 196-person validation sample','split_counts':dict(collections.Counter(split.values())),'raw_pre_zero':sum(r['YTYPE']=='1' and float(r['TIME'])<0 for r in rows),'exact_treatment_zero':sum(r['YTYPE']=='1' and float(r['TIME'])==0 for r in rows),'post_treatment_clean':sum(np.sum(x['t']>x['end']) for x in p).item(),'raw_redistributed':False}
    (ROOT/'private').mkdir(exist_ok=True)
    (ROOT/'private/split.json').write_text(json.dumps(split,indent=2))
    (ROOT/'results').mkdir(exist_ok=True)
    (ROOT/'results/data-audit.json').write_text(json.dumps(report,indent=2)+'\n')
    return p,split,report
def history(p,L,include_post=False):
    mask=(p['t']>=0)&(p['t']<=L)
    if not include_post:mask&=p['t']<=p['end']
    return p['t'][mask],p['y'][mask],p['c'][mask]
def eligible(p,L):
    t,_,_=history(p,L)
    return p['end']>=L and p['last']>=L and len(t)>=2 and np.ptp(t)>=14
def future(p,L,post=False):
    m=(p['t']>L)&(p['t']<=L+84)&(~p['c'])
    if not post:m&=p['t']<=p['end']
    return p['t'][m],p['y'][m]
if __name__=='__main__':print(json.dumps(audit()[2],indent=2))
