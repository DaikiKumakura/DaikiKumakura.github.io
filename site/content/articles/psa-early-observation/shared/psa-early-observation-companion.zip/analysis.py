"""Landmark prediction comparison. No participant-level data in results/."""
from pathlib import Path
import csv,json,time
import numpy as np
from data import audit,history,eligible,future,ROOT
from model import fit_population,fit_individual,curve
LANDMARKS=[42,84,126,168]
def writecsv(name,rows):
    if not rows:return
    with (ROOT/'results'/name).open('w',newline='',encoding='utf-8') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
def quantile(scores,alpha=.1):
    n=len(scores);k=int(np.ceil((n+1)*(1-alpha)))
    return float(np.sort(scores)[k-1]) if k<=n else float('inf')
def metrics(items):
    if not items:return {}
    a=np.array([np.mean(np.abs(x['err'])) for x in items]);s=np.array([np.mean(x['err']**2) for x in items]);b=np.array([np.mean(x['err']) for x in items])
    rng=np.random.default_rng(381);boots=a[rng.integers(0,len(a),(4000,len(a)))].mean(axis=1)
    return {'n_patients':len(items),'n_measurements':sum(len(x['err']) for x in items),'mae':float(a.mean()),'mae_low':float(np.quantile(boots,.025)),'mae_high':float(np.quantile(boots,.975)),'rmse':float(np.sqrt(s.mean())),'bias':float(b.mean())}
def run():
    began=time.perf_counter();patients,split,source=audit();fits={};out=[];flows=[];ident=[];paired=[];sensitivity=[];bins=[];private=[]
    for L in LANDMARKS:
        current=[p for p in patients if eligible(p,L)]
        groups={k:[p for p in current if split[p['id']]==k] for k in ['train','calibration','test']}
        for name,group in groups.items():
            flows.append({'week':L//7,'split':name,'total_split':sum(v==name for v in split.values()),'landmark_eligible':len(group),'has_future_on_treatment':sum(len(future(p,L)[0])>0 for p in group),'has_future_any_treatment':sum(len(future(p,L,True)[0])>0 for p in group),'died_within_horizon':sum(p['dead'] and L<p['last']<=L+84 for p in group),'ended_treatment_within_horizon':sum(L<=p['end']<L+84 for p in group),'future_blq_rows':sum(np.sum((p['t']>L)&(p['t']<=L+84)&(p['t']<=p['end'])&p['c']) for p in group).item()})
        cache={};predictions={};fitrows=[]
        for kind in ['linear','decay','two']:
            rec=[]
            for p in groups['train']:
                t,y,c=history(p,L)
                if np.sum(~c)>=2:rec.append((t[~c],y[~c]))
            fit=fit_population(rec,kind,starts=3);fits[f'{L//7}_{kind}']=fit
            print(f'week {L//7}: {kind} n={len(rec)} nll={fit["nll"]:.3f}, boundary={fit["boundary_indices"]}',flush=True)
            for p in groups['calibration']+groups['test']:
                t,y,c=history(p,L);z,cov,diag=fit_individual(t,y,c,fit)
                cache[(kind,p['id'])]=(z,cov,diag)
                if split[p['id']]=='test':
                    private.append({'week':L//7,'kind':kind,'id':p['id'],'z':z.tolist(),'cov':cov.tolist(),**diag})
            if kind=='two':
                d=[cache[(kind,p['id'])] for p in groups['test']]
                ratios=np.array([np.sqrt(x[1].diagonal())/np.array(fit['omega']) for x in d])
                ident.append({'week':L//7,'n_patients':len(d),'rank_lt_four':sum(x[2]['data_rank']<4 for x in d),'condition_gt_1e6':sum(x[2]['data_condition']>1e6 for x in d),'map_success':sum(x[2]['success'] for x in d),'any_boundary':sum(x[2]['boundaries']>0 for x in d),'multistart_disagreement':sum(x[2]['all_starts_objective_range']>.1 for x in d),'median_d_sd_ratio':float(np.median(ratios[:,1])),'median_g_sd_ratio':float(np.median(ratios[:,2])),'g_sd_ratio_q25':float(np.quantile(ratios[:,2],.25)),'g_sd_ratio_q75':float(np.quantile(ratios[:,2],.75))})
        for kind in ['last','linear','decay','two']:
            calib=[];items=[]
            for p in groups['calibration']+groups['test']:
                tt,yy=future(p,L)
                if len(tt)==0:continue
                h,y,c=history(p,L)
                pred=np.full(len(tt),y[-1]) if kind=='last' else curve(cache[(kind,p['id'])][0],tt,kind)
                item={'id':p['id'],'err':yy-pred,'pred':pred,'obs':yy,'time':tt}
                if split[p['id']]=='calibration':calib.append(float(np.max(np.abs(item['err']))))
                else:items.append(item)
            radius=quantile(calib);m=metrics(items)
            assert np.isfinite(radius),'Insufficient calibration subjects for finite 90% conformal interval'
            m.update(week=L//7,model=kind,calibration_patients=len(calib),interval_radius=radius,interval_width=2*radius,patient_simultaneous_coverage=float(np.mean([np.all(np.abs(x['err'])<=radius) for x in items])),measurement_coverage=float(np.mean(np.concatenate([np.abs(x['err'])<=radius for x in items]))))
            out.append(m);predictions[kind]=items
            for h in [42,84]:
                sub=[dict(x,err=x['err'][x['time']<=L+h]) for x in items if np.any(x['time']<=L+h)]
                hh=metrics(sub);sensitivity.append({'week':L//7,'model':kind,'scenario':f'horizon_{h}_days',**hh})
            if kind=='two':
                allp=np.concatenate([x['pred'] for x in items]);allr=np.concatenate([x['err'] for x in items])
                for a in np.array_split(np.argsort(allp),6):bins.append({'week':L//7,'n_rows':len(a),'mean_prediction':float(allp[a].mean()),'mean_residual':float(allr[a].mean()),'residual_sd':float(allr[a].std())})
        for baseline in ['last','linear','decay']:
            x={q['id']:np.mean(np.abs(q['err'])) for q in predictions[baseline]};y={q['id']:np.mean(np.abs(q['err'])) for q in predictions['two']};assert x.keys()==y.keys()
            delta=np.array([y[k]-x[k] for k in x]);rng=np.random.default_rng(722)
            boot=delta[rng.integers(0,len(delta),(4000,len(delta)))].mean(axis=1)
            paired.append({'week':L//7,'reference':baseline,'patients':len(delta),'mae_difference_two_minus_reference':float(delta.mean()),'ci_low':float(np.quantile(boot,.025)),'ci_high':float(np.quantile(boot,.975)),'bootstrap':'patient-paired percentile, 4000 samples'})
        fit=fits[f'{L//7}_two']
        for scenario,scale,omit,post in [('prior_half',.5,False,False),('prior_double',2.,False,False),('omit_blq',1.,True,False),('include_post_treatment_targets',1.,False,True)]:
            items=[]
            for p in groups['test']:
                tt,yy=future(p,L,post)
                if not len(tt):continue
                t,y,c=history(p,L)
                if omit:t,y,c=t[~c],y[~c],c[~c]
                z,_,_=fit_individual(t,y,c,fit,scale)
                items.append({'err':yy-curve(z,tt,'two')})
            sensitivity.append({'week':L//7,'model':'two','scenario':scenario,**metrics(items)})
    # Sparse sensitivity rows have the same union schema.
    keys=list(dict.fromkeys(k for row in sensitivity for k in row))
    sensitivity=[{k:row.get(k,'') for k in keys} for row in sensitivity]
    writecsv('prediction-performance.csv',out);writecsv('availability.csv',flows);writecsv('identifiability.csv',ident);writecsv('paired-comparison.csv',paired);writecsv('sensitivity.csv',sensitivity);writecsv('residual-bins.csv',bins)
    (ROOT/'private/individual-fits.json').write_text(json.dumps(private))
    (ROOT/'results/population-fits.json').write_text(json.dumps(fits,indent=2)+'\n')
    report={'status':'computed','method':'First-order marginal Gaussian hierarchy + nonlinear empirical-Bayes MAP; NOT SAEM or exact marginal NLME','landmarks_weeks':[6,12,18,24],'horizon_days':84,'split_seed':20261004,'nominal_conformal_patient_coverage':.9,'calibration_score':'maximum absolute log1p error across uncensored on-treatment targets in next 84 days','conditional_population':'alive/observed and on treatment at landmark; >=2 early measurements spanning >=14 days; has observed future on-treatment targets','population_censor_handling':'uncensored observations only; individual MAP uses Gaussian CDF for BLQ','source_audit':source,'runtime_seconds':round(time.perf_counter()-began,2)}
    (ROOT/'results/analysis-summary.json').write_text(json.dumps(report,indent=2)+'\n')
    print('Analysis complete; aggregate results saved. No participant rows released.',flush=True)
    return report
if __name__=='__main__':run()
