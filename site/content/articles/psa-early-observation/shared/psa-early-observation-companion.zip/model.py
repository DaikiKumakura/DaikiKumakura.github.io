"""Approximate hierarchical nonlinear regression, explicit first-order marginal fit.

Not SAEM, not the source-paper ODE, and not exact nonlinear marginal maximum likelihood.
Population likelihood uses uncensored on-treatment observations. Individual MAP uses
censored Gaussian contributions. Recalibrated intervals are assessed on held-out subjects.
"""
import numpy as np
from scipy.special import expit,log_ndtr
from scipy.optimize import minimize
from data import LOQ

def curve(z,t,kind='two'):
    t=np.asarray(t)
    if kind=='linear':return z[0]+z[1]*t/84
    b,d=z[0],np.exp(z[1])
    if kind=='decay':
        q=b-d*t
        f=np.logaddexp(0,q)
        w=expit(q)
        J=np.stack([w,-w*d*t],axis=-1)
    else:
        g=np.exp(z[2]);a=expit(z[3])
        q1=np.log(a)-d*t;q2=np.log1p(-a)+g*t
        q=b+np.logaddexp(q1,q2);f=np.logaddexp(0,q)
        r=expit(q1-q2);w=expit(q)
        J=np.stack([w,-w*r*d*t,w*(1-r)*g*t,w*(r-a)],axis=-1)
    return f
def jac(z,t,kind):
    t=np.asarray(t)
    if kind=='linear':return np.stack([np.ones_like(t),t/84],axis=-1)
    d=np.exp(z[1]);q=z[0]-d*t
    if kind=='decay':return np.stack([expit(q),-expit(q)*d*t],axis=-1)
    g=np.exp(z[2]);a=expit(z[3]);q1=np.log(a)-d*t;q2=np.log1p(-a)+g*t
    q=z[0]+np.logaddexp(q1,q2);r=expit(q1-q2);w=expit(q)
    return np.stack([w,-w*r*d*t,w*(1-r)*g*t,w*(r-a)],axis=-1)
def spec(kind):
    if kind=='linear':return np.array([3.,-.5]),[(-2,10),(-4,4)]
    if kind=='decay':return np.array([3.,-4.5]),[(-2,10),(-9,-1)]
    return np.array([3.,-4.5,-5.5,2.]),[(-2,10),(-9,-1),(-10,-2),(-3,8)]
def fo_nll(par,records,kind):
    k=(len(par)-1)//2;mu=par[:k];omega=np.exp(par[k:2*k]);sigma=np.exp(par[-1]);v=sigma*sigma
    total=0.
    for t,y in records:
        f=curve(mu,t,kind);J=jac(mu,t,kind)*omega
        M=np.eye(k)+J.T@J/v
        _,ld=np.linalg.slogdet(M);r=y-f;u=J.T@r/v
        total+=.5*(len(t)*np.log(2*np.pi*v)+ld+r@r/v-u@np.linalg.solve(M,u))
    return float(total)
def fit_population(records,kind,starts=3):
    mu,b=spec(kind);k=len(mu)
    base=np.r_[mu,np.log(np.full(k,.6)),np.log(.35)]
    bounds=b+[(-3,1)]*k+[(-3,.7)]
    runs=[]
    for i in range(starts):
        x=base.copy()
        if i:x[:k]+=np.random.default_rng(220+i).normal(0,.35,k)
        result=minimize(fo_nll,x,args=(records,kind),method='L-BFGS-B',bounds=bounds,options={'maxiter':500,'ftol':1e-9,'gtol':1e-5})
        runs.append(result)
    best=min(runs,key=lambda x:x.fun)
    return {'kind':kind,'mu':best.x[:k].tolist(),'omega':np.exp(best.x[k:2*k]).tolist(),'sigma':float(np.exp(best.x[-1])),'nll':float(best.fun),'starts':[{'success':bool(x.success),'nll':float(x.fun),'iterations':int(x.nit),'message':str(x.message)} for x in runs],'boundary_indices':[i for i,(lo,hi) in enumerate(bounds) if min(abs(best.x[i]-lo),abs(best.x[i]-hi))<.001],'n_patients':len(records),'n_observations':sum(len(x[0]) for x in records),'estimator':'first-order Gaussian marginal likelihood approximation'}
def map_nll(z,t,y,c,fit,prior_scale=1.):
    f=curve(z,t,fit['kind']);sigma=fit['sigma'];mu=np.array(fit['mu']);omega=np.array(fit['omega'])*prior_scale
    value=.5*np.sum(((z-mu)/omega)**2)+.5*np.sum(((y[~c]-f[~c])/sigma)**2)
    if np.any(c):value-=np.sum(log_ndtr((LOQ-f[c])/sigma))
    return float(value)
def fit_individual(t,y,c,fit,prior_scale=1.,starts=2):
    _,bounds=spec(fit['kind']);mu=np.array(fit['mu']);runs=[]
    for i in range(starts):
        z=mu.copy()
        if i:
            z[0]=float(np.clip(y[0],-1,9))
            if fit['kind']=='two':z[3]=4.
        out=minimize(map_nll,z,args=(t,y,c,fit,prior_scale),method='L-BFGS-B',bounds=bounds,options={'maxiter':250,'ftol':1e-10})
        runs.append(out)
    out=min(runs,key=lambda q:q.fun)
    J=jac(out.x,t[~c],fit['kind'])/fit['sigma'];P=np.diag(1/(np.array(fit['omega'])*prior_scale)**2)
    H=J.T@J+P;cov=np.linalg.inv(H)
    # Uncensored data-only rank and condition: do not let the prior manufacture identification.
    eig=np.linalg.eigvalsh(J.T@J);cond=float(eig[-1]/max(eig[0],1e-12))
    return out.x,cov,{'success':bool(out.success),'data_condition':cond,'data_min_eigen':float(eig[0]),'data_rank':int(np.linalg.matrix_rank(J)),'all_starts_objective_range':float(max(q.fun for q in runs)-min(q.fun for q in runs)),'boundaries':int(sum(min(abs(out.x[i]-lo),abs(out.x[i]-hi))<.001 for i,(lo,hi) in enumerate(bounds)))}
