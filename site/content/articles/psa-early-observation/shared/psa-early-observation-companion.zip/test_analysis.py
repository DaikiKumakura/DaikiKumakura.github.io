import unittest,json,csv
import numpy as np
from scipy.optimize._numdiff import approx_derivative
from scipy.stats import norm
from data import audit,load,history,eligible,future,LOQ,ROOT
from model import curve,jac,fo_nll,map_nll,fit_individual
from analysis import quantile

class Checks(unittest.TestCase):
    @classmethod
    def setUpClass(cls):cls.p,cls.split,cls.report=audit()
    def test_pinned_source_and_counts(self):
        self.assertEqual(self.report['patients'],400);self.assertEqual(self.report['raw_psa'],6627)
        self.assertEqual(self.report['raw_blq'],165);self.assertEqual(self.report['deaths'],286)
    def test_split_no_patient_overlap(self):
        parts=[{k for k,v in self.split.items() if v==name} for name in ['train','calibration','test']]
        self.assertEqual(list(map(len,parts)),[240,80,80])
        self.assertEqual(len(set.union(*parts)),400);self.assertFalse(parts[0]&parts[2])
    def test_log1p_limit(self):self.assertAlmostEqual(np.expm1(LOQ),.1,places=14)
    def test_normalization(self):
        z=np.array([np.log(50),-4,-5,2]);self.assertAlmostEqual(np.expm1(curve(z,np.array([0.]))[0]),50,places=10)
    def test_analytic_jacobians(self):
        for kind,z in [('two',[3,-4.5,-5.5,2]),('decay',[3,-4.5]),('linear',[3,-.5])]:
            t=np.array([0,21,84,168]);numeric=approx_derivative(lambda q:curve(q,t,kind),np.array(z,dtype=float))
            np.testing.assert_allclose(jac(z,t,kind),numeric,rtol=1e-5,atol=1e-7)
    def test_first_order_likelihood_independent_dense_formula(self):
        t=np.array([0.,21.,42.]);y=np.array([3.,2.9,2.6]);mu=np.array([3.,-4.,-5.,2.]);sd=np.array([.3,.5,.4,.6]);s=.4
        par=np.r_[mu,np.log(sd),np.log(s)]
        J=jac(mu,t,'two');V=J@np.diag(sd**2)@J.T+s*s*np.eye(3);r=y-curve(mu,t)
        expected=.5*(3*np.log(2*np.pi)+np.linalg.slogdet(V)[1]+r@np.linalg.solve(V,r))
        self.assertAlmostEqual(fo_nll(par,[(t,y)],'two'),expected,places=10)
    def test_censored_contribution_is_cdf(self):
        fit={'kind':'linear','mu':[0.,0.],'omega':[1.,1.],'sigma':.5};z=np.zeros(2)
        value=map_nll(z,np.array([0.]),np.array([LOQ]),np.array([True]),fit)
        self.assertAlmostEqual(value,-norm.logcdf(LOQ/.5),places=12)
    def test_history_excludes_future_and_post_treatment(self):
        for p in self.p:
            t,_,_=history(p,84)
            self.assertTrue(np.all((t>=0)&(t<=84)&(t<=p['end'])))
    def test_targets_are_strictly_future(self):
        for p in self.p:
            t,_=future(p,84)
            self.assertTrue(np.all((t>84)&(t<=168)&(t<=p['end'])))
    def test_future_perturbation_cannot_change_history(self):
        p=self.p[0];q=dict(p,y=p['y'].copy());q['y'][p['t']>84]+=100
        for x,y in zip(history(p,84),history(q,84)):np.testing.assert_array_equal(x,y)
    def test_conformal_finite_sample_rank(self):
        self.assertEqual(quantile(list(range(19))),17.)
        self.assertTrue(np.isinf(quantile([1,2,3])))
    def test_clean_day_keys_unique(self):
        for p in self.p:self.assertEqual(len(p['t']),len(set(p['t'])))
    def test_saved_denominators_and_pairing(self):
        path=ROOT/'results/prediction-performance.csv'
        if not path.exists():self.skipTest('Run analysis.py first')
        with path.open() as f:rows=list(csv.DictReader(f))
        for week in [6,12,18,24]:
            group=[r for r in rows if int(r['week'])==week];self.assertEqual(len(group),4)
            self.assertEqual(len({r['n_patients'] for r in group}),1)
            self.assertEqual(len({r['n_measurements'] for r in group}),1)
            self.assertTrue(all(0<=float(r['patient_simultaneous_coverage'])<=1 for r in group))
    def test_early_linear_marginal_model_exact(self):
        # Linear predictor has no Taylor remainder, making its FO marginal likelihood exact.
        z=np.array([2.,-.2]);eta=np.array([.3,.1]);t=np.array([0.,42.,84.])
        np.testing.assert_allclose(curve(z+eta,t,'linear'),curve(z,t,'linear')+jac(z,t,'linear')@eta)
if __name__=='__main__':unittest.main()
