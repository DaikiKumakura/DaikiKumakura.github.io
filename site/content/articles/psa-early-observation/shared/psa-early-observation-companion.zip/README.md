# Early PSA prediction: decline and regrowth

Original retrospective analysis of an official public-download clinical dataset. No PDS registration or commercial modeling software is needed. This is not an exact nonlinear marginal NLME or a SAEM reproduction; read analysis-protocol.md and article.md before interpreting parameters.

## Reproduce

Python 3.12. Install requirements.txt in an isolated environment. Run:

```text
python acquire.py
python analysis.py
python prepare_article.py
python figures.py
python validate.py
```

The official source CSV is acquired locally and pinned by SHA256. A future upstream change requires a new audit. Source docs, raw CSV, participant splits and individual fits are not redistributed. The run creates these locally in sources/ and private/. Do not publish those directories.

analysis.ipynb is an executed companion; its analysis cell reruns estimation. Runtime depends on hardware and optimizer libraries. Outputs include patient-weighted errors, paired patient bootstrap intervals, held-out split-conformal calibration, numerical diagnostics and fixed sensitivities.

Public aggregate CSV/JSON files and original PNG/SVG figures are in results/ and figures/. The data is one treatment-group subset, internally split; no independent cohort validation, treatment comparison or OS surrogate qualification is claimed. Population fitting omits BLQ observations; individual MAP includes BLQ CDF terms. Fully censored population estimation is not completed or implied.

Source: https://monolixsuite.slp-software.com/monolix/2024R1/psa-and-survival-data-set
Original publication: https://doi.org/10.1111/biom.12537

No participant data redistribution license is asserted. Independently retrieve the officially offered file and follow its source conditions. Public companion content does not relicense original data or publisher materials.
