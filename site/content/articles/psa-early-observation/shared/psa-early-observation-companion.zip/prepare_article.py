"""Generate the manuscript tables from the saved aggregate results."""
from pathlib import Path
import csv,json
ROOT=Path(__file__).resolve().parent
TITLE='Does separating PSA decline and regrowth improve early prediction?'
def rows(n):
    with (ROOT/'results'/n).open() as f:return list(csv.DictReader(f))
def table(headers,data):return '\n'.join(['| '+' | '.join(headers)+' |','| '+' | '.join(['---']*len(headers))+' |']+['| '+' | '.join(map(str,row))+' |' for row in data])
def prepare():
    p=rows('prediction-performance.csv');pair=rows('paired-comparison.csv');a=rows('availability.csv');i=rows('identifiability.csv');s=rows('sensitivity.csv')
    selected=lambda week,model:next(x for x in p if int(x['week'])==week and x['model']==model)
    performance=table(['Landmark','Test patients / targets','Last value MAE','Linear MAE','Decay MAE','Two-component MAE'],[[f'{w} weeks',f'{selected(w,"two")["n_patients"]} / {selected(w,"two")["n_measurements"]}']+[f'{float(selected(w,k)["mae"]):.3f}' for k in ['last','linear','decay','two']] for w in [6,12,18,24]])
    differences=table(['Landmark','Two-component − last MAE','Paired bootstrap 95% interval'],[[f'{x["week"]} weeks',f'{float(x["mae_difference_two_minus_reference"]):+.3f}',f'[{float(x["ci_low"]):+.3f}, {float(x["ci_high"]):+.3f}]'] for x in pair if x['reference']=='last'])
    calibration=table(['Landmark','Calibration patients','Two-component patient coverage','Full width','Last-value patient coverage'],[[f'{w} weeks',selected(w,'two')['calibration_patients'],f'{100*float(selected(w,"two")["patient_simultaneous_coverage"]):.1f}%',f'{float(selected(w,"two")["interval_width"]):.3f}',f'{100*float(selected(w,"last")["patient_simultaneous_coverage"]):.1f}%'] for w in [6,12,18,24]])
    identification=table(['Landmark','Eligible test patients','Data rank <4','Data condition >10⁶','Median g SD ratio'],[[f'{x["week"]} weeks',x['n_patients'],x['rank_lt_four'],x['condition_gt_1e6'],f'{float(x["median_g_sd_ratio"]):.6f}'] for x in i])
    sensitivity=table(['Landmark','Prior SD ×0.5','Primary','Prior SD ×2','Including post-treatment targets'],[[f'{w} weeks']+[f'{float(next(x for x in s if int(x["week"])==w and x["model"]=="two" and x["scenario"]==sc)["mae"]):.3f}' for sc in ['prior_half','horizon_84_days','prior_double','include_post_treatment_targets']] for w in [6,12,18,24]])
    mapping={'{{PERFORMANCE}}':performance,'{{DIFFERENCES}}':differences,'{{CALIBRATION}}':calibration,'{{IDENTIFICATION}}':identification,'{{SENSITIVITY}}':sensitivity}
    text=(ROOT/'article-template.md').read_text(encoding='utf-8')
    for token,value in mapping.items():text=text.replace(token,value)
    assert '{{' not in text
    (ROOT/'article.md').write_text(text,encoding='utf-8');print('Manuscript generated from aggregate tables.')
if __name__=='__main__':prepare()
