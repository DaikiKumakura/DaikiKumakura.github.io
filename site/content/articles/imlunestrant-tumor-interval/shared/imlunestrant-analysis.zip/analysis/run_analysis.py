"""Aggregate fitting, public PK reconstruction, conditional interval comparison."""
from pathlib import Path
import json,hashlib,platform
import numpy as np
import pandas as pd
import scipy
from scipy.optimize import least_squares
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from model import periodic_profile, metrics, disposition_half

ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'outputs'
INPUT=json.loads((ROOT/'analysis/inputs.json').read_text())
for d in ['tables','figures']:(OUT/d).mkdir(parents=True,exist_ok=True)
COLORS=['#0072B2','#009E73','#D55E00']
plt.rcParams.update({'font.size':11,'axes.spines.top':False,'axes.spines.right':False})


def main():
    pp=INPUT['parameters'];p=dict(cl=pp['cl'],q=pp['q'],vc=pp['vc_base']*(1+pp['mbc_effect']),vp=pp['vp'],mtt=pp['mtt'])
    obs=pd.DataFrame(INPUT['observed_repeat']);x=np.log(obs.dose.to_numpy()/400)
    fits={}
    for endpoint in ['auc','cmax']:
        se=np.sqrt(np.log1p(obs[f'{endpoint}_cv'].to_numpy()**2)/obs[f'{endpoint}_n'].to_numpy())
        y=np.log(obs[endpoint].to_numpy())
        fit=least_squares(lambda b:(b[0]+b[1]*x-y)/se,[np.log(obs.loc[1,endpoint]),1.])
        fits[endpoint]=dict(at400=float(np.exp(fit.x[0])),dose_exponent=float(fit.x[1]),working_objective=float(np.sum(fit.fun**2)))
    fits.update(parameters=p,terminal_half_hours=disposition_half(p))
    (OUT/'fit.json').write_text(json.dumps(fits,indent=2)+'\n')
    check=[]
    for r in INPUT['observed_repeat']:
        peak,trough,auc48,predose=metrics(p,r['dose'],24)
        for endpoint,pred in [('auc',auc48/2),('cmax',peak[0])]:check.append(dict(dose=r['dose'],endpoint=endpoint,observed=r[endpoint],predicted=pred,ratio=pred/r[endpoint]))
    pd.DataFrame(check).to_csv(OUT/'tables/model-check.csv',index=False)
    rows=[];halves=INPUT['effect_half_hours']
    for stages in INPUT['transit_stage_sensitivity']:
        for r in INPUT['regimens']:
            peak,minimum,auc48,predose=metrics(p,r['dose'],r['tau'],stages=stages,halves=tuple(halves))
            for j,name in enumerate(['plasma']+[f'effect_h{h:g}' for h in halves]):
                rows.append(dict(stages=stages,regimen=r['label'],compartment=name,cmax=peak[j],minimum=minimum[j],plasma_predose=predose,plasma_auc48=auc48))
    pd.DataFrame(rows).to_csv(OUT/'tables/typical.csv',index=False)
    cv=INPUT['iiv_cv'];sigma=np.array([np.sqrt(np.log1p(cv[k]**2)) for k in ['cl','vc','mtt']])
    covariance=np.diag(sigma**2);covariance[0,1]=covariance[1,0]=INPUT['eta_correlation_cl_vc']*sigma[0]*sigma[1]
    rng=np.random.default_rng(INPUT['seed']);etas=rng.multivariate_normal(np.zeros(3),covariance,size=INPUT['virtual_n'])
    arrays={r['label']:[] for r in INPUT['regimens']}
    for eta in etas:
        individual=dict(p,cl=p['cl']*np.exp(eta[0]),vc=p['vc']*np.exp(eta[1]),mtt=p['mtt']*np.exp(eta[2]))
        for r in INPUT['regimens']:
            peak,minimum,auc48,predose=metrics(individual,r['dose'],r['tau'],halves=tuple(halves))
            arrays[r['label']].append(np.r_[peak[0],predose,auc48,minimum[1:]])
    endpoints=['plasma_cmax','plasma_predose','plasma_auc48']+[f'effect_h{h:g}_minimum' for h in halves]
    base=np.array(arrays['400 mg Q24h']);virtual=[];paired=[]
    for label,values in arrays.items():
        arr=np.array(values);assert np.all(arr>0)
        assert np.max(abs(arr[:,2]/base[:,2]-1))<1e-12
        for j,name in enumerate(endpoints):
            quant=np.quantile(arr[:,j],[.05,.5,.95]);rat=np.quantile(arr[:,j]/base[:,j],[.05,.5,.95])
            virtual.append(dict(regimen=label,endpoint=name,p05=quant[0],median=quant[1],p95=quant[2]))
            paired.append(dict(regimen=label,endpoint=name,p05=rat[0],median=rat[1],p95=rat[2]))
    pd.DataFrame(virtual).to_csv(OUT/'tables/virtual.csv',index=False)
    pd.DataFrame(paired).to_csv(OUT/'tables/paired.csv',index=False)
    required_half=np.log(2)*48*np.sqrt(1/.25**2-1)/(2*np.pi)
    (OUT/'verification.json').write_text(json.dumps(dict(virtual_n=INPUT['virtual_n'],seed=INPUT['seed'],equal_auc=True,half_for_quarter_48h_harmonic=required_half),indent=2)+'\n')
    make_figures(obs,fits,check,p,paired,halves)
    env=dict(python=platform.python_version(),numpy=np.__version__,pandas=pd.__version__,scipy=scipy.__version__,matplotlib=matplotlib.__version__)
    (OUT/'environment.json').write_text(json.dumps(env,indent=2)+'\n')
    hashes={f.name:hashlib.sha256(f.read_bytes()).hexdigest() for f in (ROOT/'data/raw').glob('*') if f.is_file()}
    if hashes:(OUT/'source-hashes.json').write_text(json.dumps(hashes,indent=2)+'\n')
    print(json.dumps({'fit':fits,'typical':[r for r in rows if r['stages']==3],'paired':paired,'required_half':required_half},indent=2))


def make_figures(obs,fits,check,p,paired,halves):
    fig,axes=plt.subplots(1,2,figsize=(11,4.2),dpi=140);grid=np.geomspace(200,800,100)
    for ax,key,label in zip(axes,['auc','cmax'],['AUC0-24 (ng h/mL)','Cmax (ng/mL)']):
        ax.scatter(obs.dose,obs[key],c=COLORS[0],label='Observed geometric means')
        ax.plot(grid,fits[key]['at400']*(grid/400)**fits[key]['dose_exponent'],color=COLORS[0],label='Aggregate power fit')
        sub=pd.DataFrame(check);sub=sub[sub.endpoint==key]
        ax.plot(sub.dose,sub.predicted,'s--',color=COLORS[2],label='Public PK reconstruction')
        ax.set(xlabel='Daily dose (mg)',ylabel=label,ylim=(0,None));ax.legend(fontsize=8)
    fig.suptitle('Separate aggregate fit and public-model check (four cohorts)',fontsize=12)
    fig.tight_layout();fig.savefig(OUT/'figures/01-exposure-check.png');plt.close(fig)
    fig,axes=plt.subplots(1,2,figsize=(11.5,4.3),dpi=140)
    for color,r in zip(COLORS,INPUT['regimens']):
        t,c=periodic_profile(p,r['dose'],r['tau'],halves=tuple(halves));factor=int(48/r['tau'])
        time=np.concatenate([t[:-1]+r['tau']*j for j in range(factor)]+[np.array([48.])])
        cp=np.r_[np.tile(c[:-1,0],factor),c[-1,0]];ce=np.r_[np.tile(c[:-1,-1],factor),c[-1,-1]]
        axes[0].plot(time,cp,color=color,label=r['label']);axes[1].plot(time,ce,color=color,label=r['label'])
    for ax in axes:ax.set(xlabel='Time in common48h window (h)',ylabel='Concentration (ng/mL)',ylim=(0,None));ax.legend(fontsize=9)
    axes[0].set_title('Reconstructed plasma PK');axes[1].set_title('Hypothetical filter, half-time48h\nPlasma-equivalent units; NOT measured tumor PK',fontsize=10)
    fig.tight_layout();fig.savefig(OUT/'figures/02-plasma-filter.png');plt.close(fig)
    fig,ax=plt.subplots(figsize=(8.5,4.3),dpi=140);pair=pd.DataFrame(paired)
    for j,label in enumerate(['200 mg Q12h','800 mg Q48h']):
        values=pair[(pair.regimen==label)&pair.endpoint.str.startswith('effect')];xx=np.arange(3)+(j-.5)*.12
        ax.errorbar(xx,values['median'],yerr=[values['median']-values.p05,values.p95-values['median']],fmt='o-',capsize=4,label=label,color=COLORS[2*j])
    ax.axhline(1,ls='--',color='#888');ax.set_xticks(range(3),['2h','12h','48h'])
    ax.set(xlabel='Assumed effect-filter equilibration half-time',ylabel='Minimum / same-person400mg Q24h minimum',ylim=(0,1.8))
    ax.set_title('Conditional virtual patients (n=1024);5-95% ranges\nNo estimated human tumor half-time or clinical response threshold',fontsize=10);ax.legend()
    fig.tight_layout();fig.savefig(OUT/'figures/03-minimum-sensitivity.png');plt.close(fig)


if __name__=='__main__':main()
