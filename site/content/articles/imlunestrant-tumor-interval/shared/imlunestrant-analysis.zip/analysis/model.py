"""Public apparent two-compartment PK plus hypothetical effect filters."""
import numpy as np
from scipy.linalg import expm, solve


def system(p: dict, stages: int=3, halves: tuple=(2.,12.,48.)) -> np.ndarray:
    """Exactly stages serial input states, total mean stages/ktr=MTT.

    This specifies our reconstruction convention, not original NONMEM code.
    Apparent amounts mg; last states plasma-equivalent ng/mL.
    No tumor partition or receptor response parameter is estimated.
    """
    n=stages+2+len(halves);a=np.zeros((n,n));ktr=stages/p['mtt']
    for j in range(stages):
        a[j,j]=-ktr
        if j>0:a[j,j-1]=ktr
    c,v=stages,stages+1
    a[c,stages-1]=ktr;a[c,c]=-(p['cl']+p['q'])/p['vc'];a[c,v]=p['q']/p['vp']
    a[v,c]=p['q']/p['vc'];a[v,v]=-p['q']/p['vp']
    for j,h in enumerate(halves):
        k=np.log(2)/h;a[stages+2+j,c]=k*1000/p['vc'];a[stages+2+j,stages+2+j]=-k
    return a


def periodic_profile(p: dict, dose: float, tau: float, dt: float=.25, stages: int=3, halves: tuple=(2.,12.,48.)) -> tuple:
    a=system(p,stages,halves);b=np.zeros(len(a));b[0]=dose
    state=solve(np.eye(len(a))-expm(a*tau),b)
    count=int(round(tau/dt));assert abs(count*dt-tau)<1e-8
    step=expm(a*dt);path=np.empty((count+1,len(a)));path[0]=state
    for i in range(count):path[i+1]=step@path[i]
    concentrations=np.column_stack([path[:,stages]*1000/p['vc'],path[:,stages+2:]])
    return np.arange(count+1)*dt,concentrations


def metrics(p: dict, dose: float, tau: float, **kwargs) -> tuple:
    t,c=periodic_profile(p,dose,tau,**kwargs)
    return np.max(c,axis=0),np.min(c,axis=0),48/tau*dose*1000/p['cl'],c[-1,0]


def disposition_half(p: dict) -> float:
    a=system(p,halves=())[-2:,-2:]
    return np.log(2)/(-np.max(np.linalg.eigvals(a)).real)
