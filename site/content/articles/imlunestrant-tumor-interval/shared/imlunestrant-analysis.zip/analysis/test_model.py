import unittest
import numpy as np
from scipy.integrate import solve_ivp
from scipy.linalg import expm,solve
from model import system,periodic_profile,metrics,disposition_half

P=dict(cl=166.,q=256.,vc=8120*(1-.469),vp=2280.,mtt=1.84)


class ModelChecks(unittest.TestCase):
    def test_ode_periodic(self):
        a=system(P);b=np.zeros(len(a));b[0]=400
        x=solve(np.eye(len(a))-expm(a*24),b)
        sol=solve_ivp(lambda t,y:a@y,(0,24),x,t_eval=[0,4,12,24],rtol=1e-10,atol=1e-10)
        t,c=periodic_profile(P,400,24)
        np.testing.assert_allclose(c[[0,16,48,96],0],sol.y[3]*1000/P['vc'],rtol=1e-8)

    def test_periodic_balance(self):
        a=system(P);b=np.zeros(len(a));b[0]=400
        x=solve(np.eye(len(a))-expm(a*24),b)
        np.testing.assert_allclose(expm(a*24)@x+b,x,rtol=1e-10,atol=1e-8)

    def test_auc(self):
        for d,tau in [(200,12),(400,24),(800,48)]:
            t,c=periodic_profile(P,d,tau,dt=.0625)
            numeric=np.trapz(c[:,0],t)*48/tau
            self.assertAlmostEqual(numeric/(800*1000/P['cl']),1,places=5)

    def test_filter_mean_equals_plasma(self):
        t,c=periodic_profile(P,800,48,dt=.0625)
        areas=np.trapz(c,t,axis=0)
        np.testing.assert_allclose(areas,areas[0],rtol=1e-5)

    def test_terminal_half(self):
        self.assertAlmostEqual(disposition_half(P),30,delta=.05)
        self.assertNotAlmostEqual(disposition_half(dict(P,vc=8120)),30,delta=1.)

    def test_input_mean(self):
        for n in [1,3,4]:
            a=system(P,stages=n,halves=())[:n,:n];b=np.zeros(n);b[0]=1
            total=-solve(a,b);residence=np.sum(total)
            self.assertAlmostEqual(residence,P['mtt'],places=12)

    def test_dose_scaling(self):
        _,a=periodic_profile(P,400,24);_,b=periodic_profile(P,800,24)
        np.testing.assert_allclose(b,a*2,rtol=1e-12)

    def test_grid_convergence(self):
        for p in [P,dict(P,cl=332,vc=2000,mtt=.6)]:
            coarse=metrics(p,800,48);fine=metrics(p,800,48,dt=.0625)
            np.testing.assert_allclose(coarse[0],fine[0],rtol=.005)
            np.testing.assert_allclose(coarse[1],fine[1],rtol=.005)

    def test_positive_and_filter_attenuation(self):
        _,c=periodic_profile(P,800,48)
        self.assertTrue(np.all(c>0))
        self.assertLess(np.ptp(c[:,-1]),np.ptp(c[:,0]))


if __name__=='__main__':unittest.main()
