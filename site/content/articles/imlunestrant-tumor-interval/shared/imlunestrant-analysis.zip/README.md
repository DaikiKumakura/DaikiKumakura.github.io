# Imlunestrant plasma PK and hypothetical delayed concentration

Public research only, not treatment or clinical-trial dose advice.
Use an existing Python environment with requirements.txt packages.
Run: python analysis/run_analysis.py
Tests: python -m unittest discover -s analysis -p "test_*.py" -q
No downloads or account required. Numeric inputs and source locations: inputs.json.

Separate descriptive power fitting uses observed day15 group geometric AUC/Cmax
from EMA Table8 (200,400,600,800mg). Log-CV/n working weights. No patient-level
NLME estimate or clinical confidence interval; power fit does not alter public PK.

Public FDA Table19.2 coefficients reconstruct apparent2comp plasma PK. CL166,
Q256,Vp2280,Vc8120*(1-.469)=4311.72L for mBC, reference68.2kg. Do not multiply
absolute F10% again. Three serial input states with total mean MTT1.84h,ktr=3/MTT,
explicit Erlang convention; original NONMEM code was not replayed. State-count1/4
alternatives retainMTT. This is not a fully qualified original absorption model.
Group checks reuse trials contributing to original model, NOT external validation.
Typical predictions differ from observed geometric groups and label population means.

200Q12h,400Q24h,800Q48h assume same formulation/fasted input, time-independent
coefficients, linear PK and full adherence. Compare periodic steady state/common48h.
Equal AUC follows algebra, not demonstrated clinical equivalence.

1024 identical patient eta draws across schedules, seed20261020. Public CV(CL,Vc,MTT)
50.5%,69.1%,47.7% converted by log(1+CV^2). EtaCL-Vc correlation.618 retained,
MTT independent. Weight fixed68.2kg/mBC. IOVF35.4%,residual24.1%, covariate
distribution and fixed-effect parameter uncertainty omitted. Percentiles are
conditional patient ranges, not CIs or clinical prediction intervals.

Effect filter dX/dt=ke*(Cp-X) has assumed equilibration half-times2,12,48h.
X is plasma-equivalent ng/mL, NOT total/free tumor concentration, ER degradation,
Ki67 or efficacy. No human tumor kinetic coefficient, EC50 or recovery fit exists.
Reported human tumor/plasma enrichment is not used as equilibriumKp. No point-rank
pairing or animal-to-human kinetic transplantation. Filter minimum differs from
plasma predose. Ratio.947 does NOT mean94.7% clinical efficacy preservation.
First-harmonic attenuation threshold is mathematical, not a clinical threshold.

Code generates tables/figures. Source-hashes.json records original consulted files;
rerunning without raw papers retains it, not fresh source validation. Raw papers,
source graphics, individual records and private working documents not redistributed.
Original code MIT; numeric source facts remain attributed. Article contains the
primary-source clinical/tumor evidence audit and its limitations.
