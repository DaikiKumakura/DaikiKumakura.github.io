# Inavolisib renal-dose exposure analysis

Public research; not treatment or clinical-trial dosing advice.
Run in an existing Python environment with requirements.txt packages:
  python analysis/run_analysis.py
  python -m unittest discover -s analysis -p "test_*.py" -q
No downloads or account required. Numeric input facts: analysis/inputs.json.

Sources: FDA NDA219249 Table48 printed199 / EMA Itovebi Table6 p33;
Sutaria et al., Poster108, 2025 CPDD Abstract Booklet, DOI10.1002/cpdd.1588;
US Itovebi prescribing information revised04/2026. Consult article for links.
Same-drug apparent oral three-compartment first-order linear model. Reference
weight65kg, non-Asian, phase3 formulation. Do NOT multiply dose by0.76:
clearance and volumes are apparent oral parameters. Units mg/L/h; ng/mL output.
CL8.83, Vc155, Vp68.1, Vp2 31.4, Q7.50, Q2 .142, ka.917.
Omega order CL,Vc,ka,Vp; published logvariances .0822,.0671,.632,1.85,
CL-Vc covariance .0608; other covariances zero. 4096 paired draws, seed20261021.
No residual error, covariate frequencies or renal-specific variance fitted.

Dedicated renal study single6mg: moderate7,severe8,normal11 with matched
subsets; controls not assumed disjoint. AUCinf GMR1.73(90%CI1.49–2.02),
2.23(1.59–3.12). Relative apparent clearance is the reciprocal of GMR, with
unchanged absorption/distribution. This is aggregate calibration, NOT new NLME
estimation or PBPK. Renal GMR is transported to cancer PK and steady state;
this assumption is not validated. CI inversion is not a new IIV estimate.
Source Omega is copied unchanged to renal groups as a conditional assumption.
Reference is a normalized cancer-model reference, not the actual healthy group.
The source continuous predictor uses MDRD eGFR; dedicated trial used2021CKD-EPI.
Group mean eGFR unavailable. Do not use hypothetical values as trial means.
The old model range41.8–218 does not support severe renal extrapolation.
Normalized-category model REPLACES rather than compounds continuous renal factor.

Reference9QD, moderate6QD, severe3QD use current source-labeled start doses.
Single-dose observed Cmax ratios are not used to fit CL; conditional typical
peak comparison is not independent patient-level validation. Different population
summaries are not identical estimands. No F/absorption effects identified.
Simulated5th–95th percentiles are not CIs. AUC paired ratios cancel shared eta
by construction; precision of a fixed ratio is not clinical certainty.
Hypothetical3mgQ12h vs6mgQ24h has equal dose intensity under linear kinetics.
No lower hyperglycemia, preserved response/survival or clinical equivalence claim.
No complete public exposure-risk equation was obtained; no logistic risk fitted
from plotted curves. Grade2+ phase1 associations differ from phase3 results.
No glucose dynamics, tumor exposure, adherence, dialysis or changing renal function.
3mg is below the labeled6–12mg dose-proportionality range; linearity is assumed.

Original scripts regenerate9CSV tables,3figures andresults.json. Source-hashes
record the consulted private raw files, not a fresh source verification; raw
papers/source graphics/individual records/private plans or reviews not included.
Original code MIT. Source numeric facts remain attributed; no source artwork reused.
