"""Regenerate aggregate calculations and original article figures."""
from pathlib import Path
import hashlib
import json
import platform
import time
import numpy as np
import pandas as pd
import scipy
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from model import parameters, metrics, profile, single_peak

ROOT = Path(__file__).resolve().parents[1]
CFG = json.loads((ROOT / "analysis/inputs.json").read_text(encoding="utf-8"))
BLUE, ORANGE, GREY = "#2463A6", "#C36B24", "#4B5563"
plt.rcParams.update({"font.family": "DejaVu Sans", "font.size": 11,
                     "axes.spines.top": False, "axes.spines.right": False,
                     "axes.grid": True, "grid.alpha": .16, "figure.dpi": 150})


def summary(a: np.ndarray) -> dict:
    q = np.percentile(a, [5, 50, 95])
    return dict(p05=float(q[0]), median=float(q[1]), p95=float(q[2]))


def main() -> None:
    start = time.perf_counter()
    out = ROOT / "outputs"
    for d in [out / "tables", out / "figures"]:
        d.mkdir(parents=True, exist_ok=True)
    rng = np.random.default_rng(CFG["seed"])
    eta = rng.multivariate_normal(np.zeros(4), np.array(CFG["omega"]), size=CFG["n"])
    rows, typical, calibration = [], [], []
    predictions = {}
    for category, source in CFG["renal"].items():
        p = parameters(CFG["pk"], eta, source["auc_gmr"])
        dose = source["dose_mg_qd"]
        m = metrics(p, dose, 24)
        predictions[category] = m
        for endpoint in ["auc24", "cmax", "cmin"]:
            rows.append(dict(category=category, dose_mg=dose, tau_h=24,
                             endpoint=endpoint, n=CFG["n"], **summary(m[endpoint])))
        p0 = parameters(CFG["pk"], gmr=source["auc_gmr"])
        tm = metrics(p0, dose, 24, dt=.01)
        typical.append(dict(category=category, dose_mg=dose,
                            **{k: float(v[0]) for k, v in tm.items()}))
        if category != "reference":
            ci = source["auc_ci90"]
            calibration.append(dict(category=category, auc_gmr=source["auc_gmr"],
                auc_lo90=ci[0], auc_hi90=ci[1], relative_cl=1/source["auc_gmr"],
                relative_cl_lo90=1/ci[1], relative_cl_hi90=1/ci[0],
                adjusted_auc_ratio=source["auc_gmr"]*dose/9,
                adjusted_auc_lo90=ci[0]*dose/9, adjusted_auc_hi90=ci[1]*dose/9,
                auc_matched_dose_mg=9/source["auc_gmr"],
                auc_matched_dose_lo90=9/ci[1], auc_matched_dose_hi90=9/ci[0],
                observed_single_cmax_gmr=source["cmax_gmr"],
                observed_single_cmax_lo90=source["cmax_ci90"][0],
                observed_single_cmax_hi90=source["cmax_ci90"][1],
                cl_only_single_cmax_ratio=single_peak(p0,6)/single_peak(parameters(CFG["pk"]),6)))
    pd.DataFrame(rows).to_csv(out / "tables/conditional-exposure.csv",index=False)
    pd.DataFrame(typical).to_csv(out / "tables/typical.csv",index=False)
    cal = pd.DataFrame(calibration)
    cal.to_csv(out / "tables/renal-calibration.csv", index=False)

    # Paired: all patients share the same eta across category and dosing scenarios.
    paired = []
    for category in ["moderate", "severe"]:
        for endpoint in ["auc24", "cmax", "cmin"]:
            ratio = predictions[category][endpoint]/predictions["reference"][endpoint]
            paired.append(dict(comparison=category+"_adjusted_vs_reference9QD",
                               endpoint=endpoint, **summary(ratio)))
    modp = parameters(CFG["pk"], eta, CFG["renal"]["moderate"]["auc_gmr"])
    bid = metrics(modp, 3, 12)
    for endpoint in ["auc24", "cmax", "cmin"]:
        r = bid[endpoint]/predictions["moderate"][endpoint]
        paired.append(dict(comparison="moderate3BID_vs6QD", endpoint=endpoint, **summary(r)))
    pd.DataFrame(paired).to_csv(out/"tables/paired-ratios.csv",index=False)

    # The continuous model uses MDRD eGFR. No comparison with category group means.
    grid = []
    for g in [20, 30, 45, 60, 86, 100, 120]:
        for b in [CFG["egfr_exponent_ci95"][0],CFG["egfr_exponent"],CFG["egfr_exponent_ci95"][1]]:
            grid.append(dict(hypothetical_mdrd_egfr=g, exponent=b,
                auc_ratio_at_same_dose=(g/86)**(-b), outside_observed_range=g<41.8))
    pd.DataFrame(grid).to_csv(out/"tables/old-model-sensitivity.csv",index=False)
    sens=[]
    for category in ["moderate","severe"]:
        src=CFG["renal"][category]
        for gmr in [src["auc_ci90"][0],src["auc_gmr"],src["auc_ci90"][1]]:
            p=parameters(CFG["pk"],eta,gmr)
            qd=metrics(p,src["dose_mg_qd"],24)
            ratio=metrics(p,src["dose_mg_qd"]/2,12)["cmax"]/qd["cmax"]
            sens.append(dict(category=category,gmr=gmr,
                adjusted_auc_ratio=src["dose_mg_qd"]*gmr/9,
                bid_vs_qd_cmax_median=float(np.median(ratio))))
    pd.DataFrame(sens).to_csv(out/"tables/renal-uncertainty.csv",index=False)
    coeff=[]
    for cl in [CFG['cl_ci95'][0],CFG['pk']['cl'],CFG['cl_ci95'][1]]:
        base=dict(CFG['pk'],cl=cl)
        qd=metrics(parameters(base,gmr=1.73),6,24,.01)
        bid0=metrics(parameters(base,gmr=1.73),3,12,.01)
        coeff.append(dict(reference_cl=cl,moderate_auc24=float(qd['auc24'][0]),
                          moderate_cmax=float(qd['cmax'][0]),
                          bid_qd_cmax_ratio=float(bid0['cmax'][0]/qd['cmax'][0])))
    pd.DataFrame(coeff).to_csv(out/'tables/cl-sensitivity.csv',index=False)
    support=[]
    for key in ["auc24","cmax","cmin"]:
        a=predictions["reference"][key]
        support.append(dict(endpoint=key,n=len(a),minimum=float(a.min()),maximum=float(a.max()),**summary(a)))
    pd.DataFrame(support).to_csv(out/"tables/simulated-support.csv",index=False)

    # Figure 1: original plot of numeric facts, no copied source graphic.
    fig, ax = plt.subplots(figsize=(8.8,4.4))
    for i,row in cal.iterrows():
        y=1-i
        for dx,col,lo,hi,color,marker,label in [(.14,"auc_gmr","auc_lo90","auc_hi90",BLUE,"o","Observed AUCinf"),(-.14,"observed_single_cmax_gmr","observed_single_cmax_lo90","observed_single_cmax_hi90",ORANGE,"s","Observed Cmax")]:
            v=row[col];ax.errorbar(v,y+dx,xerr=[[v-row[lo]],[row[hi]-v]],fmt=marker,color=color,capsize=4,label=label if i==0 else None)
        ax.plot(row.cl_only_single_cmax_ratio,y-.14,marker="x",color=GREY,ms=9,label="CL-only Cmax calculation" if i==0 else None)
    ax.axvline(1,color=GREY,ls=":");ax.set_yticks([1,0],["Moderate (n=7)","Severe (n=8)"])
    ax.set(xlabel="Single-dose geometric mean ratio vs matched normal controls",xlim=(0,3.5),ylim=(-.5,1.6),title="Renal study ratios and CL-only reconstruction")
    ax.legend(loc="upper right",fontsize=9);fig.text(.12,.01,"Single 6 mg; bars: reported 90% CIs. X: conditional model, not a fitted peak.",fontsize=9)
    fig.tight_layout(rect=(0,.06,1,1));fig.savefig(out/"figures/01-renal-ratios.png");plt.close(fig)

    # Figure 2: paired ratio percentiles, not a clinical equivalence interval.
    paired_df=pd.DataFrame(paired)
    fig,axs=plt.subplots(1,3,figsize=(11,4),sharey=True)
    labels=["Moderate, 6 mg QD","Severe, 3 mg QD"]
    for ax,key,title in zip(axs,["auc24","cmax","cmin"],["AUC over 24 h","Peak concentration","Trough concentration"]):
        for i,cat in enumerate(["moderate","severe"]):
            row=paired_df[(paired_df.comparison==cat+"_adjusted_vs_reference9QD")&(paired_df.endpoint==key)].iloc[0]
            ax.errorbar(row["median"],1-i,xerr=[[row["median"]-row.p05],[row.p95-row["median"]]],fmt="o" if i==0 else "s",color=BLUE if i==0 else ORANGE,capsize=4)
        ax.axvline(1,color=GREY,ls=":");ax.set(xlabel="Paired ratio vs reference 9 mg QD",title=title,xlim=(0,1.9));ax.set_yticks([1,0],labels)
    fig.suptitle("Conditional renal dosing at steady state (4,096 paired draws)",fontsize=13)
    fig.text(.1,.01,"Bars: 5th–95th percentiles across simulated ratios; no residual error or coefficient uncertainty.",fontsize=9)
    fig.tight_layout(rect=(0,.06,1,.95));fig.savefig(out/"figures/02-adjusted-exposure.png");plt.close(fig)

    # Figure 3: same intensity; hypothesis, not a new recommended regimen.
    p0=parameters(CFG["pk"],gmr=1.73);t=np.linspace(0,24,481)
    cq=profile(p0,6,t,24)[0];cb=profile(p0,3,np.mod(t,12),12)[0]
    pd.DataFrame(dict(time_h=t,moderate6QD=cq,moderate3BID=cb)).to_csv(out/"tables/steady-profiles.csv",index=False)
    fig,axs=plt.subplots(1,2,figsize=(10,4.3),gridspec_kw={"width_ratios":[1.5,1]})
    axs[0].plot(t,cq,color=BLUE,label="6 mg every 24 h")
    axs[0].plot(t,cb,color=ORANGE,ls="--",label="3 mg every 12 h (hypothetical)")
    axs[0].set(xlabel="Time in steady-state day (h)",ylabel="Plasma concentration (ng/mL)",ylim=(0,None),title="Moderate-RI CL-only model: typical profile");axs[0].legend(fontsize=9)
    for i,key in enumerate(["auc24","cmax","cmin"]):
        r=paired_df[(paired_df.comparison=="moderate3BID_vs6QD")&(paired_df.endpoint==key)].iloc[0]
        axs[1].errorbar(r["median"],2-i,xerr=[[r["median"]-r.p05],[r.p95-r["median"]]],fmt="o",color=BLUE,capsize=4)
    axs[1].axvline(1,color=GREY,ls=":");axs[1].set(xlabel="Paired ratio, 3 mg BID / 6 mg QD",yticks=[2,1,0],yticklabels=["AUC24","Cmax","Cmin"],xlim=(.5,1.6),title="4,096 conditional draws")
    fig.text(.07,.01,"Equal daily dose (6 mg/day); concentration comparison only. Bars: 5th–95th percentiles, not confidence intervals.",fontsize=9)
    fig.tight_layout(rect=(0,.06,1,1));fig.savefig(out/"figures/03-equal-intensity.png");plt.close(fig)

    results=dict(n=CFG["n"],seed=CFG["seed"],calibration=calibration,typical=typical,
                 paired=paired,conditional=rows,
                 reference_comparison={"source_auc":1010,"source_cmax":69,
                    "typical_auc_relative_difference":typical[0]["auc24"]/1010-1,
                    "typical_cmax_relative_difference":typical[0]["cmax"]/69-1})
    (out/"results.json").write_text(json.dumps(results,indent=2)+"\n",encoding="utf-8")
    env={"python":platform.python_version(),"numpy":np.__version__,"pandas":pd.__version__,"scipy":scipy.__version__,"matplotlib":matplotlib.__version__}
    (out/"environment.json").write_text(json.dumps(env,indent=2)+"\n",encoding="utf-8")
    raw=ROOT/"data/raw"
    if raw.exists():
        hashes={f.name:hashlib.sha256(f.read_bytes()).hexdigest() for f in raw.iterdir() if f.is_file()}
        (out/"source-hashes.json").write_text(json.dumps(hashes,indent=2)+"\n",encoding="utf-8")
    print(json.dumps({"n":CFG["n"],"runtime_s":round(time.perf_counter()-start,2),"tables":len(list((out/"tables").glob('*.csv'))),"typical":typical,"paired":paired},indent=2))


if __name__ == "__main__":
    main()
