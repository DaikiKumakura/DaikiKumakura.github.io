"""Independent numerical qualification of exposure calculations."""
import json
from pathlib import Path
import unittest
import numpy as np
from scipy.integrate import solve_ivp, quad
from scipy.linalg import expm
from model import parameters, matrix, metrics, profile, single_peak

CFG=json.loads((Path(__file__).parent/'inputs.json').read_text())


class PKTests(unittest.TestCase):
    def setUp(self):
        self.p=parameters(CFG['pk'])

    def test_omega_valid(self):
        self.assertGreater(np.linalg.eigvalsh(CFG['omega']).min(),0)

    def test_single_independent_ode(self):
        p={k:v[0] for k,v in self.p.items()}
        def rhs(t,a):
            g,c,p1,p2=a;f1=p['q']*(c/p['vc']-p1/p['vp']);f2=p['q2']*(c/p['vc']-p2/p['vp2'])
            return [-p['ka']*g,p['ka']*g-p['cl']*c/p['vc']-f1-f2,f1,f2]
        t=np.linspace(0,120,241)
        sol=solve_ivp(rhs,(0,120),[9,0,0,0],t_eval=t,rtol=1e-10,atol=1e-11)
        np.testing.assert_allclose(profile(self.p,9,t)[0],sol.y[1]/p['vc']*1000,rtol=1e-7,atol=1e-7)

    def test_single_total_auc(self):
        val=quad(lambda t:profile(self.p,9,np.array([t]))[0,0],0,np.inf,epsabs=1e-6)[0]
        self.assertAlmostEqual(val,9000/8.83,places=5)

    def test_steady_matrix_solution(self):
        k=matrix(self.p)[0];a=np.linalg.solve(np.eye(4)-expm(k*24),np.array([9,0,0,0]))
        for t in [0,1,3,12,24]:
            c=(expm(k*t)@a)[1]/155*1000
            self.assertAlmostEqual(c,profile(self.p,9,np.array([t]),24)[0,0],places=7)

    def test_steady_integral(self):
        for gmr in [1,1.73,2.23]:
            p=parameters(CFG['pk'],gmr=gmr)
            for dose,tau in [(9,24),(3,12)]:
                a=quad(lambda t:profile(p,dose,np.array([t]),tau)[0,0],0,tau,epsabs=1e-7)[0]
                self.assertAlmostEqual(a,dose*1000/(8.83/gmr),places=5)

    def test_dose_linearity(self):
        t=np.linspace(0,24,100)
        np.testing.assert_allclose(profile(self.p,6,t,24)/profile(self.p,9,t,24),2/3)

    def test_gmr_auc_and_reciprocal_ci(self):
        for cat in ['moderate','severe']:
            r=CFG['renal'][cat];p=parameters(CFG['pk'],gmr=r['auc_gmr'])
            self.assertAlmostEqual(metrics(p,9,24)['auc24'][0]/metrics(self.p,9,24)['auc24'][0],r['auc_gmr'])
            self.assertLess(1/r['auc_ci90'][1],1/r['auc_gmr'])
            self.assertGreater(1/r['auc_ci90'][0],1/r['auc_gmr'])

    def test_equal_intensity(self):
        p=parameters(CFG['pk'],gmr=1.73);a=metrics(p,6,24);b=metrics(p,3,12)
        np.testing.assert_allclose(a['auc24'],b['auc24'])
        self.assertLess(b['cmax'][0],a['cmax'][0]);self.assertGreater(b['cmin'][0],a['cmin'][0])

    def test_grid_peak_accuracy(self):
        rng=np.random.default_rng(18);eta=rng.multivariate_normal(np.zeros(4),CFG['omega'],64)
        p=parameters(CFG['pk'],eta,gmr=1.73)
        a=metrics(p,6,24,.1)['cmax'];b=metrics(p,6,24,.005)['cmax']
        self.assertLess(np.max(np.abs(a/b-1)),.001)


if __name__=='__main__':unittest.main()
