"""Apparent oral three-compartment model; units mg, L, h."""
import numpy as np
from scipy.optimize import minimize_scalar


def parameters(base: dict, eta: np.ndarray | None = None, gmr: float = 1.0) -> dict:
    eta = np.zeros((1, 4)) if eta is None else np.atleast_2d(eta)
    p = {k: np.full(len(eta), v, dtype=float) for k, v in base.items()}
    for j, key in enumerate(["cl", "vc", "ka", "vp"]):
        p[key] *= np.exp(eta[:, j])
    p["cl"] /= gmr
    return p


def matrix(p: dict) -> np.ndarray:
    n = len(p["cl"])
    k = np.zeros((n, 4, 4))
    k[:, 0, 0] = -p["ka"]
    k[:, 1, 0] = p["ka"]
    k[:, 1, 1] = -(p["cl"] + p["q"] + p["q2"]) / p["vc"]
    k[:, 1, 2] = p["q"] / p["vp"]
    k[:, 1, 3] = p["q2"] / p["vp2"]
    k[:, 2, 1] = p["q"] / p["vc"]
    k[:, 2, 2] = -p["q"] / p["vp"]
    k[:, 3, 1] = p["q2"] / p["vc"]
    k[:, 3, 3] = -p["q2"] / p["vp2"]
    return k


def components(p: dict, dose: float, tau: float | None = None) -> tuple:
    vals, vecs = np.linalg.eig(matrix(p))
    assert np.max(np.abs(vals.imag)) < 1e-10
    vals = vals.real
    coef = vecs[:, 1, :] * np.linalg.inv(vecs)[:, :, 0]
    coef = coef.real * (dose * 1000 / p["vc"])[:, None]
    if tau is not None:
        coef /= -np.expm1(vals * tau)
    return vals, coef


def profile(p: dict, dose: float, times: np.ndarray, tau: float | None = None) -> np.ndarray:
    """Concentration ng/mL after single dose or within a steady-state interval."""
    vals, coef = components(p, dose, tau)
    t = np.atleast_1d(times)
    out = np.einsum("nj,ntj->nt", coef, np.exp(vals[:, None, :] * t[None, :, None]))
    assert out.min() > -1e-8
    return np.maximum(out, 0)


def metrics(p: dict, dose: float, tau: float, dt: float = 0.1) -> dict:
    t = np.linspace(0, tau, int(tau / dt) + 1)
    c = profile(p, dose, t, tau)
    return {"auc24": dose * 1000 / p["cl"] * 24 / tau,
            "cmax": c.max(axis=1), "cmin": c.min(axis=1),
            "tmax": t[np.argmax(c, axis=1)]}


def single_peak(p: dict, dose: float) -> float:
    assert len(p["cl"]) == 1
    result = minimize_scalar(lambda t: -profile(p, dose, np.array([t]))[0, 0],
                             bounds=(0, 48), method="bounded")
    return float(-result.fun)
