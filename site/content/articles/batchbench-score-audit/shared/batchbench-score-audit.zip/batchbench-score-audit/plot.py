"""Figures from published means and descriptive mixture scenarios."""
from pathlib import Path
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

HERE=Path(__file__).resolve().parent
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':10,'axes.spines.top':False,'axes.spines.right':False})


def main():
    out=HERE/'figures';out.mkdir(exist_ok=True)
    s=pd.read_csv(HERE/'results/reweighted_scores.csv')
    fig,axes=plt.subplots(1,2,figsize=(11,4.5),layout='constrained')
    x=np.arange(len(s));width=.25
    for offset,key,color,label in [(-1,'poscon','#355e8a','POSCON'),(0,'target','#d88437','TARGET'),(1,'rest','#4a8b79','REST')]:
        axes[0].bar(x+offset*width,s[key]*100,width,color=color,label=label)
    axes[0].set_xticks(x,s.method.str.replace(' (no adaptation)','',regex=False),rotation=45,ha='right');axes[0].set_ylabel('Published subgroup accuracy (%)');axes[0].legend(frameon=False)
    axes[0].set_title('A. Classification accuracy by image group')
    gain=pd.read_csv(HERE/'results/gain_contributions.csv');gain=gain[gain.method.eq('AdaBN')].iloc[0]
    axes[1].bar(['POSCON','TARGET','REST'],[gain[g]*100 for g in ['poscon','target','rest']],color=['#355e8a','#d88437','#4a8b79'])
    axes[1].set_ylabel('Contribution to overall gain (percentage points)');axes[1].set_title('B. AdaBN minus no adaptation')
    axes[1].text(.5,.89,'94.5% of reconstructed gain: POSCON',transform=axes[1].transAxes,ha='center',fontsize=10,bbox=dict(facecolor='white',edgecolor='none',alpha=.9))
    fig.savefig(out/'subgroups-and-gain.png',dpi=180);plt.close(fig)
    fig,axes=plt.subplots(1,2,figsize=(11,4.6),layout='constrained')
    grid=pd.read_csv(HERE/'results/mixture_grid.csv')
    for name,color in [('AdaBN','#355e8a'),('deepCORAL','#d88437'),('ARM-BN','#4a8b79')]:
        q=grid[grid.method.eq(name)];axes[0].plot(q.poscon_share*100,q.accuracy*100,label=name,color=color)
    axes[0].axvline(36.166847,color='#666',ls='--',lw=1,label='Private test mix')
    axes[0].set(xlabel='Positive-control image share (%)',ylabel='Reweighted accuracy (%)',xlim=(0,55),ylim=(0,40),title='A. Fixed subgroup accuracies, changed weights');axes[0].legend(frameon=False)
    q=pd.read_csv(HERE/'inputs/source_groups.csv').pivot(index='Metadata_Source',columns='group',values='images').fillna(0)
    q=q.div(q.sum(axis=1),axis=0)*100;bottom=np.zeros(len(q))
    for g,c in [('poscon','#355e8a'),('target','#d88437'),('rest','#4a8b79')]:
        axes[1].bar(q.index.str.replace('source_',''),q[g],bottom=bottom,label=g.upper(),color=c);bottom+=q[g].to_numpy()
    axes[1].set(xlabel='Public source ID (2 = validation)',ylabel='Share of images (%)',title='B. Public metadata: source composition');axes[1].legend(frameon=False,loc='upper right',fontsize=8,ncol=3,bbox_to_anchor=(1,1.13))
    fig.savefig(out/'mixture-and-sources.png',dpi=180);plt.close(fig)


if __name__=='__main__':main()
