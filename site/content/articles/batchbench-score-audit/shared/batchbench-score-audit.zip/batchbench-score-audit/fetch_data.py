"""Fetch pinned public tables/metadata only; no images or private test data."""
from pathlib import Path
import hashlib
import json
import requests

HERE = Path(__file__).resolve().parent
DATA_REV = 'a5c2888d320f57e14d1c7d4dd4374397935ab9a4'
SPACE_REV = '6d9f7134993355ac2affd2fa6bd2e32e04f879b9'
BASE = f'https://huggingface.co/datasets/ai-lab-jku/jumpcp-challenge-datasets/resolve/{DATA_REV}/'
URLS = {
    'paper.html': 'https://arxiv.org/html/2610.30104v1',
    'train_domain_data.csv': BASE+'2k/200x200/train_domain_data.csv',
    'metadata.npz': BASE+'2k/500x500/train_data_metadata.npz',
    'labels.npy': BASE+'2k/500x500/train_data_labels.npy',
    'data_loading.py': 'https://raw.githubusercontent.com/ml-jku/batchbench-baselines/df18b76bbf6233a0a8bdb423801c5353e613078f/data_loading.py',
    'public_results.json': f'https://huggingface.co/spaces/ai-lab-jku/jumpcp-challenge/resolve/{SPACE_REV}/data/public_results.json',
}


def main():
    folder = HERE/'sources'
    folder.mkdir(exist_ok=True)
    records = []
    for name, url in URLS.items():
        response = requests.get(url, timeout=90)
        response.raise_for_status()
        (folder/name).write_bytes(response.content)
        records.append(dict(file=name,url=url,sha256=hashlib.sha256(response.content).hexdigest()))
    (folder/'fetch_provenance.json').write_text(json.dumps(records,indent=2)+'\n')
    print('Fetched',len(records),'files; no model code executed.')


if __name__ == '__main__':
    main()
