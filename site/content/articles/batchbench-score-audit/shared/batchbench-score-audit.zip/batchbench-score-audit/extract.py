"""Extract published scores and audit public metadata; no image/model execution."""
from pathlib import Path
import hashlib
import json
import re
import numpy as np
import pandas as pd
from bs4 import BeautifulSoup

HERE = Path(__file__).resolve().parent


def main():
    src, out = HERE/'sources', HERE/'inputs'
    out.mkdir(exist_ok=True)
    soup = BeautifulSoup((src/'paper.html').read_text(encoding='utf-8'), 'html.parser')
    table = soup.find_all('table')[1]
    rows = []
    for tr in table.find_all('tr')[1:]:
        cells = tr.find_all(['th','td'], recursive=False)
        if not cells:
            continue
        row = {'method': cells[0].get_text(' ', strip=True)}
        for key, cell in zip(['overall', 'poscon', 'target', 'rest'], cells[1:]):
            # MathML annotation is a single canonical TeX representation.
            text = cell.find('annotation').get_text() if cell.find('annotation') else cell.get_text(' ', strip=True)
            nums = re.findall(r'\d+\.\d+', text)
            row[key], row[key+'_sd'] = map(float, nums[:2])
        rows.append(row)
    pd.DataFrame(rows).to_csv(out/'published_scores.csv', index=False)
    count_rows = []
    for i, tr in enumerate(soup.find_all('table')[0].find_all('tr')[1:]):
        cells = tr.find_all(['th','td'], recursive=False)
        if i in [0,3]:
            cells = cells[1:]  # rowspan split label, present only in first row
        count_rows.append(['public' if i < 3 else 'test', cells[0].get_text(strip=True).lower(),
                           int(cells[2].get_text(strip=True).replace(',', ''))])
    counts = pd.DataFrame(count_rows,columns=['split','group','images'])
    assert counts.images.tolist() == [48574,23455,23186,16691,25352,4107]
    counts.to_csv(out/'published_counts.csv', index=False)
    df = pd.read_csv(src/'train_domain_data.csv')
    meta = np.load(src/'metadata.npz', allow_pickle=False)
    labels = np.load(src/'labels.npy', allow_pickle=False)
    assert np.array_equal(labels, df.label.to_numpy())
    for key, col in [('image_id','filename'),('source_id','Metadata_Source'),
                     ('batch_id','Metadata_Batch'),('plate_id','Metadata_Plate')]:
        assert np.array_equal(meta[key], df[col].astype(str))
    assert np.array_equal(np.char.lower(meta['group']), df.group.to_numpy(dtype=str))
    assert not df.filename.duplicated().any()
    assert set(df.Metadata_Source) == {'source_1','source_2','source_3','source_5','source_7','source_8','source_10','source_11','source_15'}
    df.groupby(['Metadata_Source','group']).agg(images=('label','size'), classes=('label','nunique')).reset_index().to_csv(out/'source_groups.csv', index=False)
    df.groupby('label').group.agg(lambda x: '+'.join(sorted(set(x)))).value_counts().rename_axis('membership').reset_index(name='classes').sort_values('membership').to_csv(out/'group_membership.csv',index=False)
    source_n = df.groupby('label').Metadata_Source.nunique()
    source_n.value_counts().sort_index().rename_axis('sources_per_class').reset_index(name='classes').to_csv(out/'class_coverage.csv',index=False)
    val = df.Metadata_Source.eq('source_2')
    train_classes, val_classes = set(df.loc[~val,'label']), set(df.loc[val,'label'])
    summary = dict(public_images=len(df), public_classes=df.label.nunique(),
                   train_images=int((~val).sum()), validation_images=int(val.sum()),
                   train_classes=len(train_classes), validation_classes=len(val_classes),
                   validation_classes_absent_from_training=len(val_classes-train_classes),
                   filename_duplicates=0, csv_npz_npy_alignment=True,
                   private_test_downloaded=False, images_downloaded=False)
    (out/'metadata_audit.json').write_text(json.dumps(summary,indent=2)+'\n')
    records = json.loads((src/'fetch_provenance.json').read_text())
    for record in records:
        assert hashlib.sha256((src/record['file']).read_bytes()).hexdigest() == record['sha256']
    (out/'provenance.json').write_text(json.dumps(dict(retrieved='2026-10-24', paper='https://arxiv.org/html/2610.30104v1',
        dataset='https://huggingface.co/datasets/ai-lab-jku/jumpcp-challenge-datasets',
        note='Counts and published tables only; raw public metadata are fetched separately and not redistributed.',sha256=records),indent=2)+'\n')
    print(json.dumps(summary,indent=2))


if __name__ == '__main__':
    main()

