# BatchBench score and metadata audit

Python 3.12. Install requirements.txt, then run offline:

```
python analysis.py
python plot.py
python -m unittest test_analysis.py
```

Inputs contain the v1 paper's rounded Table 2 means/SDs, Table 1 image counts, and our aggregates of public metadata. Results are descriptive reweighting of published subgroup means. They do not contain per-image predictions, a trained classifier, or new private-test evaluations. No confidence intervals or significance tests are inferred from three-seed marginal SDs.

To independently refresh the metadata audit (network needed):

```
python fetch_data.py
python extract.py
python analysis.py
```

The downloader pins Hugging Face dataset and Space commits and the baseline repository revision. It downloads only public metadata, labels, paper HTML, and reference source text. Downloaded Python source is not executed. No images or held-out sources are downloaded. CSV from the 200-pixel public release is row-aligned to the 500-pixel metadata/labels before aggregation. Case in group names is normalized only for validation.

Training is all public sources except source_2, which is validation. Public source IDs include source_15; identifiers need not be consecutive. The public release contains 95,215 rows and 2,000 unique labels. TARGET and REST are disjoint image groups but overlap in 227 compound labels. Summing group-specific compound counts is therefore incorrect.

Accuracy scenarios hold subgroup conditional accuracies fixed while varying image mixture weights. In real test-time adaptation, changing the mixture can change the model's conditional accuracies; scenarios are not predictions of that process. The non-POSCON scenario keeps the original test TARGET:REST image ratio. Equal-group weights do not produce per-compound macro accuracy. The 8.6% crossover is approximate and based on rounded reported means.

Published source: Topf S, Sanchez-Fernandez A, Klambauer G. BatchBench, arXiv:2610.30104v1, https://arxiv.org/html/2610.30104v1 (21 Oct 2026, preprint), Tables 1 and 2. Paper license CC BY 4.0, https://creativecommons.org/licenses/by/4.0/ . The tables are transcribed and transformed with attribution; no paper figure is redistributed. Raw Hugging Face metadata and external code are not bundled. Our aggregate counts and original code are provided for this audit; original code is MIT licensed (LICENSE).

The Space's pinned public_results.json contains example-style entries that do not match the paper baselines. It is not used as measured benchmark evidence. Only the paper's fixed v1 scores are analyzed. Source file SHA-256 values and retrieval date are in inputs/provenance.json.
