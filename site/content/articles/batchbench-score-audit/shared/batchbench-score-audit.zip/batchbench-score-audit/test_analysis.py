import unittest
from pathlib import Path
import numpy as np
import pandas as pd
from analysis import weighted_accuracy

HERE=Path(__file__).resolve().parent


class AuditTests(unittest.TestCase):
    def test_weighted_accuracy_known_example(self):
        self.assertAlmostEqual(weighted_accuracy([1,0,0],[.25,.5,.25]),.25)
        with self.assertRaises(ValueError):weighted_accuracy([1,0,0],[1,1,1])

    def test_public_image_counts_and_overlapping_classes(self):
        groups=pd.read_csv(HERE/'inputs/source_groups.csv')
        self.assertEqual(groups.images.sum(),95215)
        self.assertEqual(groups[groups.group.eq('poscon')].images.sum(),48574)
        memberships=pd.read_csv(HERE/'inputs/group_membership.csv').set_index('membership').classes
        self.assertEqual(memberships.sum(),2000)
        self.assertEqual(memberships['rest+target'],227)

    def test_reported_overall_consistent_with_subgroups(self):
        s=pd.read_csv(HERE/'inputs/published_scores.csv')
        weights=np.array([16691,25352,4107])/46150
        # Each subgroup and overall value was independently rounded to .001.
        np.testing.assert_allclose(s[['poscon','target','rest']].to_numpy()@weights,s.overall,atol=.001,rtol=0)
        self.assertEqual(len(s),7)


if __name__=='__main__':unittest.main()
