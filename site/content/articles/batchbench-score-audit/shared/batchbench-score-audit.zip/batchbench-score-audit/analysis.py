"""Reweight rounded published subgroup accuracies; not a model replication."""
from pathlib import Path
import json
import numpy as np
import pandas as pd

HERE = Path(__file__).resolve().parent
GROUPS = ['poscon','target','rest']


def weighted_accuracy(scores, weights):
    scores, weights = np.asarray(scores, dtype=float), np.asarray(weights, dtype=float)
    if scores.shape[-1] != 3 or weights.shape != (3,) or np.any(weights < 0) or not np.isclose(weights.sum(), 1):
        raise ValueError('Three nonnegative weights summing to one are required')
    return scores @ weights


def main():
    inp, out = HERE/'inputs', HERE/'results'
    out.mkdir(exist_ok=True)
    scores = pd.read_csv(inp/'published_scores.csv')
    counts = pd.read_csv(inp/'published_counts.csv')
    weights = {s: counts[counts.split.eq(s)].set_index('group').loc[GROUPS,'images'].to_numpy(dtype=float) for s in ['public','test']}
    weights = {k: v/v.sum() for k,v in weights.items()}
    matrix = scores[GROUPS].to_numpy()
    scores['test_reweighted'] = weighted_accuracy(matrix, weights['test'])
    scores['public_mix_scenario'] = weighted_accuracy(matrix, weights['public'])
    scores['equal_group_scenario'] = weighted_accuracy(matrix, np.ones(3)/3)
    nonpos = weights['test'].copy();nonpos[0] = 0;nonpos /= nonpos.sum()
    scores['nonposcon_scenario'] = weighted_accuracy(matrix, nonpos)
    scores['rounding_discrepancy'] = scores.test_reweighted-scores.overall
    scores.to_csv(out/'reweighted_scores.csv',index=False)
    contributions = []
    base = scores.iloc[0]
    for _, row in scores.iterrows():
        d = (row[GROUPS].to_numpy(dtype=float)-base[GROUPS].to_numpy(dtype=float))*weights['test']
        contributions.append(dict(method=row.method, **dict(zip(GROUPS,d)),total=float(d.sum())))
    pd.DataFrame(contributions).to_csv(out/'gain_contributions.csv',index=False)
    # Hold the target:rest ratio fixed while varying the positive-control image share.
    grid = []
    for share in np.linspace(0,1,101):
        w = nonpos*(1-share);w[0] = share
        for name, acc in zip(scores.method,weighted_accuracy(matrix,w)):
            grid.append(dict(poscon_share=share,method=name,accuracy=acc))
    pd.DataFrame(grid).to_csv(out/'mixture_grid.csv',index=False)
    a = scores.set_index('method')
    differences = a.loc['AdaBN',GROUPS].to_numpy(dtype=float)-a.loc['deepCORAL',GROUPS].to_numpy(dtype=float)
    dn = float(differences @ nonpos)
    crossover = -dn/(differences[0]-dn)
    adagain = next(r for r in contributions if r['method']=='AdaBN')
    summary = dict(weights={k:dict(zip(GROUPS,v)) for k,v in weights.items()},
                   max_rounding_discrepancy=float(scores.rounding_discrepancy.abs().max()),
                   adabn_gain_contribution_poscon_fraction=adagain['poscon']/adagain['total'],
                   adabn_vs_deepcoral_poscon_share_crossover=crossover,
                   caution='Rounded three-seed subgroup means, fixed conditional accuracies; descriptive scenarios, not new model evaluations or inference under an actual changed distribution.')
    (out/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
    print(scores[['method','overall','test_reweighted','nonposcon_scenario']].to_string(index=False))
    print(json.dumps(summary,indent=2))


if __name__ == '__main__':
    main()
