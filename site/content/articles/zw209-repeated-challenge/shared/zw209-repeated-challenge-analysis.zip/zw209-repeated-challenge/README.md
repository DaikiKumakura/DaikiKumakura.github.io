# Repeated stimulation and initial TCE activity

This independent reanalysis tests a fixed geometric retention forecast from the first two plotted cytotoxicity values to a held-out third stimulation. Source: Lau et al., AACR Annual Meeting 2025, Abstract 7318, Figure 2B. The poster URL and hash are recorded in source-provenance.json.

## Reproduction

Python 3.12 and dependencies in requirements.txt:

```sh
python analysis/download_sources.py
python analysis/run.py
python -m unittest discover -s tests -v
```

No new experimental data are created. Eleven displayed markers are vector-graphic summaries with unknown donor and replicate counts, not eleven independent experimental units. The common held-out evaluation comprises one third-stimulation summary per molecule. Subsequent controls are not imputed. Coordinate perturbations describe graphical sensitivity only, not biological confidence intervals.

`data/processed/vector-observations.csv` records marker coordinates. `outputs/tables` contains calibration, predictions and sensitivity calculations. `outputs/figures` contains newly generated figures. The original poster PDF and rendered source images are excluded from the public archive. The comparator marked AMG 757 in figures denotes the source's dagger-marked analogue, not verified clinical material.

The context is fixed-assay extrapolation, not human dosing, clinical efficacy, safety or mechanistic identification.
