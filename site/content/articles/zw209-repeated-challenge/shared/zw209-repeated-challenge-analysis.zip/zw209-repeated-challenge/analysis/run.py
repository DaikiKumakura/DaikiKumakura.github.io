"""Read source vector markers and predict the next restimulation without using it."""
from pathlib import Path
import hashlib,json,csv
import numpy as np
import pymupdf
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
ROOT=Path(__file__).resolve().parents[1]
SEED=20261028
Y0,Y100=716.49658203125,590.1304931640625
COLORS={'ZW209':np.array([.0852979347,.4904554784,.7409781218]),'ZW209 CD28null':np.array([.5630121231,.7623102069,0.]),'AMG 757 analogue':np.array([.6663309932,.3630884290,.6642709970])}
def extract():
 page=pymupdf.open(ROOT/'data/raw/poster.pdf')[0]; rows=[]
 for molecule,color in COLORS.items():
  markers=[]
  for obj in page.get_drawings():
   r=obj['rect'];fill=obj.get('fill')
   if fill is not None and np.linalg.norm(np.asarray(fill)-color)<1e-5 and 760<r.x0<950 and 580<r.y0<725 and 1<r.width<10 and 1<r.height<10:
    markers.append(((r.x0+r.x1)/2,(r.y0+r.y1)/2))
  markers.sort();assert len(markers)==(5 if molecule=='ZW209' else 3)
  for n,((x,y),day) in enumerate(zip(markers,[4,7,11,14,18]),1):rows.append(dict(molecule=molecule,round=n,day=day,x_pdf_pt=x,y_pdf_pt=y,cytotoxicity_percent=100*(Y0-y)/(Y0-Y100),role='training' if n<=2 else 'heldout'))
 assert len(rows)==11
 return rows

def forecast(a1,a2,n,method):
 assert min(a1,a2)>0
 return float(a2 if method=='carry latest' else a1*(a2/a1)**(n-1))
def write(path,rows):
 with path.open('w',newline='',encoding='utf8') as f:
  w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
def save(fig,name):
 fig.tight_layout();fig.savefig(ROOT/f'outputs/figures/{name}.png',dpi=170);fig.savefig(ROOT/f'outputs/figures/{name}.svg');plt.close(fig)
def main():
 for d in ['data/processed','outputs/tables','outputs/figures']:(ROOT/d).mkdir(parents=True,exist_ok=True)
 rows=extract();write(ROOT/'data/processed/vector-observations.csv',rows);pred=[];params=[]
 for molecule in COLORS:
  r=[v for v in rows if v['molecule']==molecule];a1,a2=[v['cytotoxicity_percent'] for v in r[:2]]
  params.append(dict(molecule=molecule,initial_percent=a1,round_retention=a2/a1,training_points=2))
  for v in r[2:]:
   for method in ['geometric retention','carry latest']:
    p=forecast(a1,a2,v['round'],method);pred.append(dict(molecule=molecule,round=v['round'],day=v['day'],method=method,prediction=p,observation=v['cytotoxicity_percent'],error_pp=p-v['cytotoxicity_percent']))
 write(ROOT/'outputs/tables/predictions.csv',pred);write(ROOT/'outputs/tables/parameters.csv',params);write(ROOT/'outputs/tables/observations.csv',rows)
 common=[v for v in pred if v['round']==3];scores=[]
 for method in ['geometric retention','carry latest']:
  r=[v for v in common if v['method']==method];scores.append(dict(method=method,n_molecule_summaries=3,rmse_pp=float(np.sqrt(np.mean([v['error_pp']**2 for v in r]))),mae_pp=float(np.mean([abs(v['error_pp']) for v in r]))))
 write(ROOT/'outputs/tables/common-round-scores.csv',scores)
 # Display-coordinate perturbation, not sampling/biological uncertainty.
 rng=np.random.default_rng(SEED);sens=[]
 for molecule in COLORS:
  r=[v for v in rows if v['molecule']==molecule][:3];ys=np.array([v['y_pdf_pt'] for v in r]);errors=[]
  for _ in range(2000):
   a=100*(Y0-(ys+rng.uniform(-.5,.5,3)))/(Y0-Y100);errors.append(forecast(a[0],a[1],3,'geometric retention')-a[2])
  sens.append(dict(molecule=molecule,min_error_pp=float(min(errors)),max_error_pp=float(max(errors)),coordinate_perturbation_pdf_pt=.5,scenarios=2000))
 write(ROOT/'outputs/tables/coordinate-sensitivity.csv',sens)
 plt.rcParams.update({'font.size':10,'svg.fonttype':'none','axes.spines.top':False,'axes.spines.right':False})
 fig,axes=plt.subplots(1,3,figsize=(11,3.6),sharey=True)
 for ax,(molecule,color) in zip(axes,COLORS.items()):
  r=[v for v in rows if v['molecule']==molecule];ax.plot([v['round'] for v in r],[v['cytotoxicity_percent'] for v in r],'-',color=color,label='Source observations')
  ax.scatter([1,2],[v['cytotoxicity_percent'] for v in r[:2]],color=color,label='Calibration')
  ax.scatter([v['round'] for v in r[2:]],[v['cytotoxicity_percent'] for v in r[2:]],facecolors='white',edgecolors=color,label='Held out')
  for method,ls in [('geometric retention','--'),('carry latest',':')]:
   q=[v for v in pred if v['molecule']==molecule and v['method']==method];ax.plot([v['round'] for v in q],[v['prediction'] for v in q],ls,color='black',marker='x' if method=='geometric retention' else '+',markersize=7,label=method)
  ax.set(title=molecule,xlabel='Stimulation round',ylim=(-3,105),xticks=[1,2,3,4,5]);ax.axvline(2.5,color='gray',lw=.6)
 axes[0].set_ylabel('Tumor-cell cytotoxicity (%)');axes[0].legend(fontsize=7,loc='lower left');save(fig,'repeat-forecast')
 fig,ax=plt.subplots(figsize=(7,3.5));x=np.arange(3)
 for j,method in enumerate(['geometric retention','carry latest']):
  q=[next(v for v in common if v['molecule']==m and v['method']==method) for m in COLORS];ax.bar(x+(j-.5)*.34,[v['error_pp'] for v in q],.32,label=method,color=['#0072B2','#D55E00'][j])
 ax.set(xticks=x,xticklabels=list(COLORS),ylabel='Predicted minus observed (pp)',title='Third stimulation excluded from calibration');ax.axhline(0,color='gray');ax.legend();save(fig,'third-round-error')
 result=dict(id='NEXT-01',observed_markers=11,independent_donors_reported=False,training_per_molecule=2,common_heldout_round=3,parameters=params,common_round_predictions=common,scores=scores,coordinate_sensitivity=sens,source_sha256=hashlib.sha256((ROOT/'data/raw/poster.pdf').read_bytes()).hexdigest())
 (ROOT/'outputs/results.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf8');print(json.dumps(result,indent=2))
if __name__=='__main__':main()
