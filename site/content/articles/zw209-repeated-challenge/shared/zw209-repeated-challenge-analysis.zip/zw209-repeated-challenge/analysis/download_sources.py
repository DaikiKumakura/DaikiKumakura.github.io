"""Fetch the unchanged public source poster; do not overwrite raw data."""
from pathlib import Path
import urllib.request,hashlib
ROOT=Path(__file__).resolve().parents[1]
URL='https://www.zymeworks.com/wp-content/uploads/2025/04/ZYME-AACR-2025-ZW209_final.pdf'
EXPECTED='349043fe163d27f8acbf01c8ae67b1b3c43ed9780d78d18ceebbb8002ecdb645'
def main():
 path=ROOT/'data/raw/poster.pdf'
 if not path.exists():
  data=urllib.request.urlopen(URL,timeout=90).read()
  assert hashlib.sha256(data).hexdigest()==EXPECTED
  path.parent.mkdir(parents=True,exist_ok=True);path.write_bytes(data)
 assert hashlib.sha256(path.read_bytes()).hexdigest()==EXPECTED
 print('Source PDF verified')
if __name__=='__main__':main()
