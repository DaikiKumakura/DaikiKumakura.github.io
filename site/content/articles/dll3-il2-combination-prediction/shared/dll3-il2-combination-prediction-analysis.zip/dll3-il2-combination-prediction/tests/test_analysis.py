import importlib.util
from pathlib import Path
import unittest
import numpy as np

P=Path(__file__).resolve().parents[1]
spec=importlib.util.spec_from_file_location('analysis',P/'analysis/run.py')
m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)


class AnalysisTest(unittest.TestCase):
    def test_growth_recovers_known_rate(self):
        t=np.array([0,2,5]);v=100*np.exp(.2*t)
        g,b=m.fit_growth(t,v,0,5)
        self.assertAlmostEqual(g,.2);self.assertAlmostEqual(b,100)

    def test_control_is_counted_once(self):
        g_control=.3;g_tce=.2;g_il2=.1
        self.assertAlmostEqual(g_tce+g_il2-g_control,0)

    def test_fitting_excludes_late_observations(self):
        t=np.array([0,2,5,9]);v=np.array([100,150,200,100000])
        a=m.fit_growth(t,v,0,5)[0]
        v[-1]=1
        self.assertAlmostEqual(a,m.fit_growth(t,v,0,5)[0])

    def test_all_arms_have_treatment_baseline(self):
        for p in m.PANELS.values():
            for pts in p['data'].values():
                self.assertIn(p['t0'],[q[0] for q in pts])
                self.assertTrue(np.all(m.volume([q[1] for q in pts],p)>0))


if __name__=='__main__':unittest.main()
