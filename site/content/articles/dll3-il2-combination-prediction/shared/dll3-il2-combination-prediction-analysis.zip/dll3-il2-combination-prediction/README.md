# Can monotherapy tumor growth predict the effect of a DLL3 T-cell engager combined with IL-2?

Reanalysis of published aggregate means, DOI:10.64898/2025.12.04.692214.
The source is licensed under CC BY 4.0; full source URL and SHA-256 are in source-provenance.json.
Original source figures and articles are not included in the companion.
Digitization is approximate and is not original individual-level data.

Use the scientific Python versions in requirements.txt in an existing environment. From this directory:

```sh
python analysis/download_sources.py
python analysis/run.py
python -m unittest discover -s tests
```

The outputs are regenerated from manually recorded observed-symbol pixel centers and explicit axis calibration. Connecting/fitted lines are not extra observations. Reading scenarios are not biological confidence intervals. Full methods and limits are in the Japanese and English manuscripts.

Figure 3H (B16/TRP2) and 3I (KP1/DLL3) use IL2REH, not wild-type IL2. Combination outcomes are excluded from rate estimation; only its treatment-start volume scales predictions. Reported mouse counts are source cohort sizes, not numbers of independent digitized observations. The independent-effect benchmark does not prove pharmacological synergy or identify its mechanism.
