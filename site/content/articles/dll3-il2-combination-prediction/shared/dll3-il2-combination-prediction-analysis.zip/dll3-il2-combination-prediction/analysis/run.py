"""Aggregate-mean tumor growth benchmark; combination means never enter fitting."""
from pathlib import Path
import csv
import json
import hashlib
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

ROOT=Path(__file__).resolve().parents[1]
SEED=20261028
# Manual centers of observed mean symbols in the public Figure 3 JPEG.
# Figure 3H uses IL2REH, not wild-type IL2. The source figure's fitted/connecting
# lines and error bars are not treated as additional independent observations.
PANELS={
 'B16 / TRP2':{'panel':'H','t0':6,'end_fit':19,'zero_y':663.5,'tick_y':553.5,'tick_value':1000,'n':{'HBS':5,'TCE':11,'IL2REH':5,'Combination':11},
  'data':{'HBS':[(6,661),(8,659),(11,654),(13,644),(16,619),(19,563)],
          'TCE':[(6,661),(8,660),(11,659),(13,658),(16,648),(19,633),(21,620),(24,594)],
          'IL2REH':[(6,661),(8,660),(11,657),(13,644),(16,634),(19,611)],
          'Combination':[(6,661),(8,661),(11,661),(13,662),(16,662),(19,661),(21,661),(24,660),(27,658)]}},
 'KP1 / DLL3':{'panel':'I','t0':14,'end_fit':22,'zero_y':668.3,'tick_y':542,'tick_value':2000,'n':{'HBS':10,'TCE':10,'IL2REH':10,'Combination':10},
  'data':{'HBS':[(11,663.5),(14,648),(18,605),(22,535),(24,526)],
          'TCE':[(11,663.5),(14,651),(18,626),(22,594),(24,569)],
          'IL2REH':[(11,663.5),(14,648),(18,618),(22,582),(24,543)],
          'Combination':[(11,663.5),(14,651),(18,650),(22,644),(24,643)]}}
}


def volume(y: np.ndarray, p: dict) -> np.ndarray:
    return (p['zero_y']-np.asarray(y))*p['tick_value']/(p['zero_y']-p['tick_y'])


def fit_growth(t: np.ndarray, v: np.ndarray, t0: float, end: float) -> tuple[float,float]:
    """Baseline-constrained exponential growth on the source mean trajectory."""
    mask=(t>=t0)&(t<=end);t=t[mask];v=v[mask]
    assert len(t)>=3 and np.all(v>0) and t[0]==t0
    dt=t-t0; baseline=v[0]
    g=float(dt @ np.log(v/baseline)/(dt@dt))
    return g,float(baseline)


def csv_write(path: Path, rows: list[dict]) -> None:
    with path.open('w',newline='',encoding='utf8') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)


def main() -> None:
    out=ROOT/'outputs';(out/'figures').mkdir(parents=True,exist_ok=True);(out/'tables').mkdir(exist_ok=True)
    (ROOT/'data/processed').mkdir(parents=True,exist_ok=True)
    raw=[];param=[];preds=[];metrics=[];sens=[]
    rng=np.random.default_rng(SEED)
    colors={'HBS':'#777777','TCE':'#E69F00','IL2REH':'#0072B2','Combination':'#CC79A7'}
    plt.rcParams.update({'font.size':10,'svg.fonttype':'none'})
    fig,axes=plt.subplots(1,2,figsize=(10,4))
    for ax,(name,p) in zip(axes,PANELS.items()):
        arm_data={}
        for arm,points in p['data'].items():
            t=np.array([x[0] for x in points]);ypx=np.array([x[1] for x in points]);v=volume(ypx,p)
            assert np.all(v>0)
            arm_data[arm]=(t,v)
            for day,y,z in zip(t,ypx,v):raw.append(dict(model=name,panel=p['panel'],arm=arm,day=int(day),y_px=y,volume_mm3=z,
                 role='heldout_combination' if arm=='Combination' else ('fit' if p['t0']<=day<=p['end_fit'] else 'not_fit'),reported_n=p['n'][arm]))
            ax.plot(t,v,'o-',markersize=4,color=colors[arm],label=arm)
        fitted={}
        for arm in ['HBS','TCE','IL2REH']:
            g,b=fit_growth(*arm_data[arm],p['t0'],p['end_fit']);fitted[arm]=g
            param.append(dict(model=name,arm=arm,net_log_growth_per_day=g,baseline_mm3=b,treatment_start_day=p['t0'],fit_end_day=p['end_fit']))
        g_combo=fitted['TCE']+fitted['IL2REH']-fitted['HBS']
        tc,vc=arm_data['Combination'];take=(tc>p['t0'])&(tc<=p['end_fit']);t=tc[take];v=vc[take]
        baseline=vc[np.where(tc==p['t0'])[0][0]]
        prediction=baseline*np.exp(g_combo*(t-p['t0']))
        for d,obs,pr in zip(t,v,prediction):preds.append(dict(model=name,day=int(d),observed_mm3=obs,predicted_mm3=pr,prediction_over_observed=pr/obs))
        # Pointwise independence benchmark uses only observed monotherapy/control means.
        # It checks dependence on the exponential time-shape assumption.
        pointwise=[]
        for day in t:
            folds={}
            for arm in ['HBS','TCE','IL2REH']:
                ta,va=arm_data[arm];i=np.where(ta==p['t0'])[0][0]
                folds[arm]=np.interp(day,ta,va)/va[i]
            pointwise.append(baseline*folds['TCE']*folds['IL2REH']/folds['HBS'])
        metrics.append(dict(model=name,fit_end_day=p['end_fit'],comparison_days=','.join(map(str,t)),g_combination=g_combo,
              observed_last=float(v[-1]),predicted_last=float(prediction[-1]),ratio_last=float(prediction[-1]/v[-1]),
              pointwise_predicted_last=float(pointwise[-1]),pointwise_ratio_last=float(pointwise[-1]/v[-1]),
              log_rmse=float(np.sqrt(np.mean(np.log(prediction/v)**2)))))
        grid=np.linspace(p['t0'],p['end_fit'],100)
        ax.plot(grid,baseline*np.exp(g_combo*(grid-p['t0'])),'k--',label='Unfitted combination prediction')
        ax.scatter(t,pointwise,marker='x',s=50,color='black',label='Pointwise independence')
        ax.axvline(p['end_fit'],color='gray',ls=':',alpha=.7)
        ax.set(title=f"{name} (Figure 3{p['panel']})",xlabel='Day after implantation',ylabel='Tumor volume (mm³)',yscale='log')
        ax.legend(frameon=False,fontsize=7);ax.grid(alpha=.2)
        # Coherent arm-wise vertical reading offsets. This is not a mouse bootstrap.
        scenario=[]
        for _ in range(2000):
            new={}
            for arm in ['HBS','TCE','IL2REH','Combination']:
                pts=p['data'][arm];tt=np.array([q[0] for q in pts]);yy=np.array([q[1] for q in pts]);vv=volume(yy+rng.uniform(-1,1),p)
                new[arm]=(tt,vv)
            gs={a:fit_growth(*new[a],p['t0'],p['end_fit'])[0] for a in ['HBS','TCE','IL2REH']}
            tt,vv=new['Combination'];b=vv[np.where(tt==p['t0'])[0][0]];actual=vv[np.where(tt==p['end_fit'])[0][0]]
            pr=b*np.exp((gs['TCE']+gs['IL2REH']-gs['HBS'])*(p['end_fit']-p['t0']))
            scenario.append(pr/actual)
        sens.append(dict(model=name,min_ratio=float(min(scenario)),max_ratio=float(max(scenario)),pixel_halfwidth=1))
    fig.suptitle('Mean-trajectory benchmark; combination outcomes excluded from estimation')
    fig.tight_layout();fig.savefig(out/'figures/combination-prediction.svg');fig.savefig(out/'figures/combination-prediction.png',dpi=170);plt.close(fig)
    fig,ax=plt.subplots(figsize=(6.5,3.8))
    for i,r in enumerate(metrics):
        ax.bar(i-.15,r['ratio_last'],.28,color='#0072B2',label='Exponential fit' if i==0 else '')
        ax.bar(i+.15,r['pointwise_ratio_last'],.28,color='#009E73',label='Pointwise means' if i==0 else '')
    ax.axhline(1,color='black',ls='--');ax.set(xticks=[0,1],xticklabels=list(PANELS),ylabel='Predicted / observed combination volume')
    ax.legend(frameon=False);fig.tight_layout();fig.savefig(out/'figures/prediction-discrepancy.svg');fig.savefig(out/'figures/prediction-discrepancy.png',dpi=170);plt.close(fig)
    csv_write(ROOT/'data/processed/markers.csv',raw);csv_write(out/'tables/net-growth.csv',param)
    csv_write(out/'tables/heldout-combination.csv',preds);csv_write(out/'tables/comparison.csv',metrics);csv_write(out/'tables/reading-sensitivity.csv',sens)
    r={'article_id':'STCE-14','n_digitized_means':len(raw),'comparison':metrics,'reading_sensitivity':sens,
       'source_sha256':hashlib.sha256((ROOT/'data/raw/source-figure.jpg').read_bytes()).hexdigest()}
    (out/'results.json').write_text(json.dumps(r,indent=2),encoding='utf8');print(json.dumps(r,indent=2))


if __name__=='__main__':main()
