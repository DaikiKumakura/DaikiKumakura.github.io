from math import cosh,sinh,sqrt,log

def mul(x,y):
    return tuple(tuple(sum(x[i][k]*y[k][j] for k in range(2)) for j in range(2)) for i in range(2))
def prop(diagonal,delta):
    a,b=diagonal
    mean=(a+b)/2
    gap=sqrt(((a-b)/2)**2+.1**2)
    from math import exp
    level=exp(mean*delta)
    high=cosh(delta*gap)
    low=sinh(delta*gap)/gap
    return ((level*(high+low*(a-mean)),level*low*.1),
            (level*low*.1,level*(high+low*(b-mean))))
def radius(m):
    a,b=m[0]
    c,d=m[1]
    return (a+d+sqrt((a-d)**2+4*b*c))/2
for delta in (.25,1,3):
    a,b=prop((.9,-.1),delta),prop((-.1,.9),delta)
    ab,ba=mul(a,b),mul(b,a)
    grouped=mul(mul(b,b),mul(a,a))
    alternating=mul(ba,ba)
    assert abs(radius(ab)-radius(ba))<1e-12
    rates=[log(radius(m))/(4*delta) for m in (grouped,alternating)]
    assert rates[0]>rates[1]
    print(delta,*(f"{r:.6f}" for r in rates))
