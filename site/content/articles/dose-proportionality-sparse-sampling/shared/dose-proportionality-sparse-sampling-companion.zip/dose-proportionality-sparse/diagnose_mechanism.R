# Mechanism of the AUC bias under saturation: splits the estimated AUC into the observed part (0 to last sample) and the extrapolated tail,
# compares the estimated terminal rate constant with the true local rate at the last sample, and separates the number of samples,
# the number of terminal points and the observation window. Reuses the definitions of simulate.R.
# Run: Rscript diagnose_mechanism.R   (seed 20261121; 5000 subjects per dose, wide dose range; writes results/diagnostic-mechanism.csv)
script_dir <- dirname(normalizePath(sub("^--file=", "", grep("^--file=", commandArgs(FALSE), value = TRUE)[1]), winslash = "/"))
src <- readLines(file.path(script_dir, "simulate.R")); eval(parse(text = src[seq_len(grep("^set.seed", src)[1] - 1)]))
DESIGNS <- list(sparse_4samples_2terminal = list(t = T_SPARSE, m = 2), sparse_4samples_3terminal = list(t = T_SPARSE, m = 3),
                dense_9samples_to24h = list(t = T_DENSE[1:9], m = 3), dense_11samples_to48h = list(t = T_DENSE, m = 3))
set.seed(20261121L); rows <- list(); N <- 5000
for (sn in c("linear", "moderate", "strong")) {
  km <- if (SAT[[sn]] == 0) 1e6 else (max(DOSE_SETS$wide) / V_POP) / SAT[[sn]]
  for (d in DOSE_SETS$wide) {
    s <- subjects(N, d, km); at <- auc_true(s$c0, s$km, s$vmax)
    for (dn in names(DESIGNS)) {
      tt <- DESIGNS[[dn]]$t; m <- DESIGNS[[dn]]$m; k <- length(tt); tl <- tt[k]
      ctrue <- sapply(tt, function(t) conc_mm(t, s$c0, s$km, s$vmax))
      cm <- ctrue * exp(matrix(rnorm(N * k, 0, SIGMA), N)); e <- nca_auc(cm, tt, m)
      c0 <- ifelse(cm[, 2] < cm[, 1], cm[, 1] * (cm[, 1] / cm[, 2])^(tt[1] / (tt[2] - tt[1])), cm[, 1])
      a <- seg(c0, cm[, 1], tt[1]); for (j in 2:k) a <- a + seg(cm[, j - 1], cm[, j], tt[j] - tt[j - 1])
      tail_true <- auc_true(ctrue[, k], s$km, s$vmax); auc0t_true <- at - tail_true
      tail_est <- e$auc - a
      idx <- (k - m + 1):k; x <- tt[idx] - mean(tt[idx]); ly <- log(cm[, idx, drop = FALSE])
      lam <- -as.vector((ly - rowMeans(ly)) %*% x) / sum(x^2); lam_true <- s$vmax / (s$km + ctrue[, k])
      rows[[length(rows) + 1]] <- data.frame(saturation = sn, dose = d, design = dn,
        auc_ratio = median(e$auc / at), auc0last_ratio = median(a / auc0t_true), tail_ratio = median(tail_est / tail_true),
        lambda_over_local_rate = median(lam / lam_true), clast_over_km = median(ctrue[, k] / s$km),
        extrap_share = median(tail_est / e$auc), share_extrap_gt_20pct = mean(tail_est / e$auc > 0.2))
    }
  }
}
out <- do.call(rbind, rows); write.csv(out, file.path(script_dir, "results/diagnostic-mechanism.csv"), row.names = FALSE)
options(width = 220); o <- out; o[4:10] <- round(o[4:10], 3); print(o[o$saturation != "moderate" | o$dose == 80, ], row.names = FALSE)
