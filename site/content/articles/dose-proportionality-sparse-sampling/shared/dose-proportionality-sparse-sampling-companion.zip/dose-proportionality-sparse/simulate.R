# Dose-proportionality assessment with the power model when elimination saturates (Michaelis-Menten), IV bolus, parallel dose groups.
# Compares the AUC from sparse sampling (4 samples) and dense sampling (11 samples) against the true AUC. R 4.5.3, base R only.
# Run: Rscript simulate.R 2000        (trials per cell; seed 20261119)
script_dir <- dirname(normalizePath(sub("^--file=", "", grep("^--file=", commandArgs(FALSE), value = TRUE)[1]), winslash = "/"))
args <- commandArgs(trailingOnly = TRUE)
SEED <- 20261119L; NREP <- if (length(args) >= 1) as.integer(args[1]) else 2000L
V_POP <- 50          # L, volume of distribution (typical)
CL_LIN <- 5          # L/h, linear (low-concentration) clearance Vmax/Km (typical)
OMEGA_CL <- 0.30     # SD of log linear clearance between subjects
OMEGA_V <- 0.20      # SD of log volume between subjects
SIGMA <- 0.10        # SD of log assay error (proportional)
T_SPARSE <- c(0.5, 2, 8, 24)
T_DENSE <- c(0.25, 0.5, 1, 2, 4, 6, 8, 12, 24, 36, 48)
M_TERM <- c(sparse = 2, dense = 3)     # points used for the terminal slope
DOSE_SETS <- list(wide = c(10, 20, 40, 80), narrow = c(20, 40))   # mg
N_GRID <- c(6, 12, 24, 48)             # subjects per dose group
SAT <- c(linear = 0, mild = 0.25, moderate = 1, strong = 4)       # C0 of the highest dose (80 mg) divided by Km, at typical volume; 0 = linear
EXCL <- 0.05                           # 90% CI

# Concentration of an IV bolus with Michaelis-Menten elimination (closed form via the Lambert W function, solved in the log domain).
conc_mm <- function(t, c0, km, vmax) {
  lx <- log(c0 / km) + (c0 - vmax * t) / km
  u <- ifelse(lx > 1, log(pmax(lx, 1e-9)), lx)
  for (k in 1:60) u <- u - (exp(u) + u - lx) / (exp(u) + 1)
  km * exp(u)
}
auc_true <- function(c0, km, vmax) c0 * (c0 / 2 + km) / vmax        # AUC from 0 to infinity

subjects <- function(n, dose, km) {
  cl <- CL_LIN * exp(rnorm(n, 0, OMEGA_CL)); v <- V_POP * exp(rnorm(n, 0, OMEGA_V))
  list(dose = dose, c0 = dose / v, km = km, vmax = cl * km / v)     # vmax in concentration per hour
}
# Linear-up/log-down trapezoid segment
seg <- function(a, b, dt) ifelse(b < a & b > 0 & a > 0, (a - b) * dt / log(a / b), (a + b) * dt / 2)
nca_auc <- function(cm, tt, m) {
  # cm: subjects x times. Back-extrapolated C0 from the first two samples, AUC0-last, extrapolation by the terminal slope.
  k <- length(tt)
  c0 <- ifelse(cm[, 2] < cm[, 1], cm[, 1] * (cm[, 1] / cm[, 2])^(tt[1] / (tt[2] - tt[1])), cm[, 1])
  a <- seg(c0, cm[, 1], tt[1])
  for (j in 2:k) a <- a + seg(cm[, j - 1], cm[, j], tt[j] - tt[j - 1])
  idx <- (k - m + 1):k; x <- tt[idx] - mean(tt[idx])
  ly <- log(cm[, idx, drop = FALSE]); slope <- as.vector((ly - rowMeans(ly)) %*% x) / sum(x^2)
  lam <- -slope; ok <- is.finite(lam) & lam > 0
  list(auc = ifelse(ok, a + cm[, k] / lam, a), fail = !ok)
}
beta_ci <- function(auc, ld) {
  f <- lm(log(auc) ~ ld); s <- summary(f)$coefficients[2, ]; tq <- qt(1 - EXCL, f$df.residual)
  c(est = s[1], lo = s[1] - tq * s[2], hi = s[1] + tq * s[2])
}

set.seed(SEED); rows <- list()
for (sn in names(SAT)) {
  km <- if (SAT[[sn]] == 0) 1e6 else (max(DOSE_SETS$wide) / V_POP) / SAT[[sn]]
  for (rn in names(DOSE_SETS)) {
    ds <- DOSE_SETS[[rn]]; r <- max(ds) / min(ds)
    thl <- 1 + log(0.8) / log(r); thu <- 1 + log(1.25) / log(r)
    # population slope of the log geometric mean AUC (true AUC, large simulated population)
    gm <- sapply(ds, function(d) { s <- subjects(2e5, d, km); mean(log(auc_true(s$c0, s$km, s$vmax))) })
    beta_pop <- unname(coef(lm(gm ~ log(ds)))[2])
    for (n in N_GRID) {
      res <- array(NA_real_, c(NREP, 3, 4), dimnames = list(NULL, c("oracle", "sparse", "dense"), c("est", "lo", "hi", "fail")))
      for (i in seq_len(NREP)) {
        dose <- rep(ds, each = n); s <- subjects(length(dose), dose, km); ld <- log(dose)
        at <- auc_true(s$c0, s$km, s$vmax); res[i, "oracle", 1:3] <- beta_ci(at, ld); res[i, "oracle", 4] <- 0
        for (dn in c("sparse", "dense")) {
          tt <- if (dn == "sparse") T_SPARSE else T_DENSE
          cm <- sapply(tt, function(t) conc_mm(t, s$c0, s$km, s$vmax)) * exp(matrix(rnorm(length(dose) * length(tt), 0, SIGMA), length(dose)))
          e <- nca_auc(cm, tt, M_TERM[[dn]]); res[i, dn, 1:3] <- beta_ci(e$auc, ld); res[i, dn, 4] <- mean(e$fail)
        }
      }
      for (dn in c("oracle", "sparse", "dense")) {
        x <- res[, dn, ]
        rows[[length(rows) + 1]] <- data.frame(saturation = sn, sat_c0_over_km = SAT[[sn]], dose_range = rn, doses = paste(ds, collapse = "/"),
          n_per_dose = n, auc = dn, trials = NREP, beta_pop = beta_pop, theta_low = thl, theta_high = thu,
          beta_mean = mean(x[, "est"]), beta_sd = sd(x[, "est"]), ci_width_mean = mean(x[, "hi"] - x[, "lo"]),
          p_declare_prop = mean(x[, "lo"] >= thl & x[, "hi"] <= thu), p_ci_excl1 = mean(x[, "lo"] > 1 | x[, "hi"] < 1),
          p_ci_upper_below_1 = mean(x[, "hi"] < 1), lambda_fail_share = mean(x[, "fail"]))
      }
    }
    cat(sn, rn, "beta_pop =", round(beta_pop, 3), " window", round(thl, 3), "-", round(thu, 3), "\n")
  }
}
out <- do.call(rbind, rows); dir.create(file.path(script_dir, "results"), showWarnings = FALSE)
write.csv(out, file.path(script_dir, "results/summary.csv"), row.names = FALSE)
writeLines(capture.output(sessionInfo()), file.path(script_dir, "results/session-info.txt"))
options(width = 220); o <- out[out$n_per_dose == 12, c(1, 3, 6, 8, 11, 12, 14, 15, 17)]; o[4:9] <- round(o[4:9], 3); print(o, row.names = FALSE)
