# Figures for the dose-proportionality article (Okabe-Ito palette). Run: Rscript figures.R (after simulate.R and diagnose_bias.R)
script_dir <- dirname(normalizePath(sub("^--file=", "", grep("^--file=", commandArgs(FALSE), value = TRUE)[1]), winslash = "/"))
suppressPackageStartupMessages(library(ggplot2))
oi <- c(linear = "#000000", mild = "#009E73", moderate = "#E69F00", strong = "#D55E00")
s <- read.csv(file.path(script_dir, "results/summary.csv")); s <- s[s$auc == "sparse", ]
s$saturation <- factor(s$saturation, names(oi)); s$dose_range <- factor(s$dose_range, c("wide", "narrow"), c("10-80 mg (ratio 8)", "20-40 mg (ratio 2)"))
l <- rbind(data.frame(s[, c("saturation", "dose_range", "n_per_dose")], panel = "A. Proportionality declared (90% CI inside the window)", value = s$p_declare_prop),
           data.frame(s[, c("saturation", "dose_range", "n_per_dose")], panel = "B. 90% CI excludes 1", value = s$p_ci_excl1))
p1 <- ggplot(l, aes(n_per_dose, value, colour = saturation, linetype = dose_range)) +
  geom_line(linewidth = 0.9) + geom_point(size = 2) + facet_wrap(~panel) +
  scale_colour_manual(values = oi, name = "True saturation\n(C0 of 80 mg / Km)", labels = c("none", "0.25", "1", "4")) +
  scale_linetype_manual(values = c("solid", "dashed"), name = "Dose range") +
  scale_x_continuous(breaks = c(6, 12, 24, 48), trans = "log2") + scale_y_continuous(limits = c(0, 1), breaks = seq(0, 1, 0.2)) +
  labs(x = "Subjects per dose group (log scale)", y = "Probability over 2,000 simulated studies") + theme_bw(base_size = 12) + theme(legend.position = "bottom", legend.box = "vertical")
ggsave(file.path(script_dir, "figures/figure-1-power-model.png"), p1, width = 9.5, height = 5.6, dpi = 160)
b <- read.csv(file.path(script_dir, "results/diagnostic-mechanism.csv")); b <- b[b$saturation %in% c("linear", "moderate", "strong"), ]
b$saturation <- factor(b$saturation, c("linear", "moderate", "strong"), c("No saturation", "C0 of 80 mg / Km = 1", "C0 of 80 mg / Km = 4"))
b$design <- factor(b$design, c("sparse_4samples_2terminal", "sparse_4samples_3terminal", "dense_9samples_to24h", "dense_11samples_to48h"),
                   c("4 samples to 24 h, 2 terminal points", "4 samples to 24 h, 3 terminal points", "9 samples to 24 h, 3 terminal points", "11 samples to 48 h, 3 terminal points"))
p2 <- ggplot(b, aes(factor(dose), auc_ratio, colour = design, shape = design, group = design)) +
  geom_hline(yintercept = 1, colour = "grey50") + geom_line(linewidth = 0.5) + geom_point(size = 2.6) + facet_wrap(~saturation) +
  scale_colour_manual(values = c("#D55E00", "#CC79A7", "#009E73", "#0072B2"), name = "Sampling design") + scale_shape_manual(values = c(16, 17, 15, 18), name = "Sampling design") +
  labs(x = "Dose (mg)", y = "Estimated AUC / true AUC (median)") + theme_bw(base_size = 12) + theme(legend.position = "bottom") + guides(colour = guide_legend(nrow = 2), shape = guide_legend(nrow = 2))
ggsave(file.path(script_dir, "figures/figure-2-auc-bias.png"), p2, width = 9.5, height = 5, dpi = 160)
