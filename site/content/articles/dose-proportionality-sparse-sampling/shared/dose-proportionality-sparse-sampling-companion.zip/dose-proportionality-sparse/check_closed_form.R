# Numerical check of the closed-form Michaelis-Menten concentration and AUC used in simulate.R against a fourth-order Runge-Kutta solution.
script_dir <- dirname(normalizePath(sub("^--file=", "", grep("^--file=", commandArgs(FALSE), value = TRUE)[1]), winslash = "/"))
src <- readLines(file.path(script_dir, "simulate.R")); eval(parse(text = src[seq_len(grep("^set.seed", src)[1] - 1)]))
rk4 <- function(c0, km, vmax, tmax, h = 1e-3) { f <- function(c) -vmax * c / (km + c); n <- round(tmax / h); c <- c0; auc <- 0
  for (i in seq_len(n)) { k1 <- f(c); k2 <- f(c + h / 2 * k1); k3 <- f(c + h / 2 * k2); k4 <- f(c + h * k3); cn <- c + h / 6 * (k1 + 2 * k2 + 2 * k3 + k4); auc <- auc + h * (c + cn) / 2; c <- cn }
  c(conc = c, auc = auc) }
worst <- 0
for (case in list(c(1.6, 0.4, 0.8), c(1.6, 1.6, 0.8), c(0.2, 0.4, 2), c(1.6, 6.4, 0.4))) {
  r <- rk4(case[1], case[2], case[3], 24); cc <- conc_mm(24, case[1], case[2], case[3])
  at <- auc_true(case[1], case[2], case[3]); ar <- r["auc"] + cc * 0  # AUC 0-24 by RK4; closed form 0-24 = AUC_inf - AUC from 24 to inf
  tail_auc <- auc_true(cc, case[2], case[3]); closed <- at - tail_auc
  rel <- max(abs(cc - r["conc"]) / r["conc"], abs(closed - r["auc"]) / r["auc"]); worst <- max(worst, rel)
  cat(sprintf("c0=%.2f km=%.2f vmax=%.2f  conc(24h) closed=%.6f rk4=%.6f | AUC0-24 closed=%.6f rk4=%.6f | max rel diff=%.2e\n", case[1], case[2], case[3], cc, r["conc"], closed, r["auc"], rel))
}
stopifnot(worst < 1e-5); cat("max relative difference", format(worst, digits = 3), "\n")
