# Companion: power-model assessment of dose proportionality when elimination saturates

Simulation code and aggregate results for the article "How often does a power-model dose-proportionality study detect saturable elimination? Simulated studies with sparse and dense sampling". No subject-level data are used.

## Files

- `simulate.R`: simulates parallel-group single-dose intravenous studies with Michaelis-Menten elimination (no, mild, moderate or strong saturation; 10-80 mg and 20-40 mg; 6 to 48 subjects per dose), estimates AUC by noncompartmental analysis from 4 or 11 samples and from the true AUC, and fits the power model (`Rscript simulate.R 2000`; seed 20261119; writes `results/summary.csv` and `results/session-info.txt`). Base R only.
- `diagnose_mechanism.R`: splits the estimated AUC into the observed part and the extrapolated tail, compares the estimated terminal rate constant with the true local rate, and separates the number of samples, the number of terminal points and the observation window (`Rscript diagnose_mechanism.R`; seed 20261121; writes `results/diagnostic-mechanism.csv`).
- `check_closed_form.R`: checks the closed-form concentration and AUC against a Runge-Kutta solution.
- `figures.R`: draws Figures 1 and 2 (requires ggplot2).
- `results/summary.csv`: aggregate results for every setting (Tables 1 to 3 and the text).
- `results/diagnostic-mechanism.csv`: the diagnostic results (Table 4 and Figure 2).
- `results/session-info.txt`: R 4.5.3 session information.

## Reproduce

```
Rscript simulate.R 2000
Rscript diagnose_mechanism.R
Rscript check_closed_form.R
Rscript figures.R
```

The scripts find their own folder, so they can be run from any directory. The output depends on the random-number stream of the R version used.
