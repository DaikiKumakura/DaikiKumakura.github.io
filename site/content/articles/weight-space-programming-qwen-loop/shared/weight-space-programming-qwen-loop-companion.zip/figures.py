"""Figures for the Weight-Space Programming MATH-500 note (reads results/*.csv)."""
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import pandas as pd

ROOT = Path(__file__).resolve().parent
RES, FIG = ROOT / "results", ROOT / "figures"
FIG.mkdir(exist_ok=True)
BLUE, ORANGE, GREY = "#0072B2", "#D55E00", "#666666"
LABELS = {"unedited": "Unedited", "p10c": "Run p10c\n(10 passes)", "p25c": "Run p25c\n(25 passes)", "p50c": "Run p50c\n(50 passes)"}


def fig1():
    a = pd.read_csv(RES / "math500_accuracy.csv")
    fig, ax = plt.subplots(figsize=(7.2, 4.4))
    x = range(len(a))
    ax.bar(x, 100 * a.accuracy, color=BLUE, width=0.55, label="MATH-500 accuracy (95% bootstrap interval over 500 problems)")
    ax.errorbar(x, 100 * a.accuracy, yerr=[100 * (a.accuracy - a.ci_low), 100 * (a.ci_high - a.accuracy)], fmt="none", ecolor="black", capsize=4)
    ax.plot(x, 100 * a.cut_share, "o--", color=ORANGE, label="Share of samples cut at the 32,768-token limit")
    for i, (acc, hi, cut) in enumerate(zip(a.accuracy, a.ci_high, a.cut_share)):
        ax.text(i, 100 * hi + 2.5, f"{100 * acc:.1f}", ha="center", fontsize=8)
        ax.text(i + 0.07, 100 * cut + 2.5, f"{100 * cut:.1f}", color=ORANGE, fontsize=8)
    ax.set_xticks(list(x))
    ax.set_xticklabels([LABELS[r] for r in a.run], fontsize=8)
    ax.set_ylim(0, 110)
    ax.set_ylabel("Percent")
    ax.set_title("Qwen3.5-0.8B, MATH-500: three different edits, one run each", fontsize=10)
    ax.legend(fontsize=7.5, loc="upper right")
    ax.grid(axis="y", alpha=0.25)
    fig.tight_layout()
    fig.savefig(FIG / "01-math500-runs.png", dpi=170)
    plt.close(fig)


def fig2():
    b = pd.read_csv(RES / "benchmarks_p50c_vs_unedited.csv")
    fig, ax = plt.subplots(figsize=(6.4, 4.6))
    ax.scatter(b.delta_finished, b.delta_acc, color=BLUE, zorder=3)
    for _, r in b.iterrows():
        ax.annotate(r.benchmark, (r.delta_finished, r.delta_acc), textcoords="offset points", xytext=(5, 3), fontsize=8)
    ax.set_xlabel("Drop in share of samples cut off at the token limit, p50c vs unedited (points)")
    ax.set_ylabel("Gain in accuracy, run p50c vs unedited (points)")
    ax.set_title("Ten benchmarks: accuracy gain and drop in cut-off share move together (exploratory)", fontsize=9.5)
    ax.grid(alpha=0.25)
    fig.tight_layout()
    fig.savefig(FIG / "02-gain-vs-truncation-drop.png", dpi=170)
    plt.close(fig)


if __name__ == "__main__":
    fig1()
    fig2()
