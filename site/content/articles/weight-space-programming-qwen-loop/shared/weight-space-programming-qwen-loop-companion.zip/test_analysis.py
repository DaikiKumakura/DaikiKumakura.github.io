import numpy as np

import analysis as an


def test_inputs_match_published_headline_numbers():
    d = an.load_counts()
    assert round(100 * an.accuracy(d, "unedited"), 1) == 7.9
    assert round(100 * an.accuracy(d, "p50c"), 1) == 48.1
    assert round(100 * an.accuracy(d, "p25c"), 1) == 14.1


def test_cut_share_and_lower_bound():
    t = an.accuracy_table(an.load_counts()).set_index("run")
    assert abs(t.loc["unedited", "cut_share"] - 0.93) < 1e-9
    assert t.loc["unedited", "min_correct_among_cut"] == 18          # 158 correct but only 140 finished samples
    assert t.loc["p50c", "min_correct_among_cut"] == 0


def test_bootstrap_ci_contains_point_estimate_and_is_reproducible():
    d = an.load_counts()
    a, b = an.accuracy_table(d), an.accuracy_table(d)
    assert (a.ci_low <= a.accuracy).all() and (a.accuracy <= a.ci_high).all()
    assert np.allclose(a.ci_low, b.ci_low)


def test_paired_counts_add_up():
    p = an.paired_table(an.load_counts())
    assert ((p.problems_better + p.problems_worse + p.problems_equal) == 500).all()
    assert p.set_index(["a", "b"]).loc[("p50c", "unedited"), "problems_worse"] == 0


def test_weights_and_ratios():
    w = an.weights_arithmetic()
    assert w["edited_weights"] == 131072 and abs(w["share_of_0p8B_percent"] - 0.016384) < 1e-9
