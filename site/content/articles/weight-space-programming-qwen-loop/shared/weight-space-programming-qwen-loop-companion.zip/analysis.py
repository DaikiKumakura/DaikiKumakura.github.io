"""Re-read the MATH-500 result of the Weight-Space Programming post (Takehi et al., 2026-11-02, Experiment 8) from its released logs.

Inputs (inputs/, derived from the CC BY 4.0 logs at github.com/RikiyaT/lm_understand-logs, exp8_math/eval/<run>/):
  math500_per_problem_correct_counts.csv  correct samples (0-4) per MATH-500 problem for four evaluated checkpoints
  math500_sample_totals.csv               samples, correct samples and samples cut at the 32,768-token limit per checkpoint
  benchmark_summary.csv                   accuracy and cut share per benchmark per checkpoint (from merged.json)
Runs: unedited = Qwen3.5-0.8B; p10c / p25c / p50c = the three edits (10, 25, 50 forward passes) reported in the post. Each run is a different edit.
All intervals are percentile bootstrap over the 500 problems (problems are the independent unit; the 4 samples per problem are averaged), seed fixed.
Nothing is trained or run here; the calculation is arithmetic and resampling on the released numbers.
"""
from pathlib import Path

import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parent
IN, OUT = ROOT / "inputs", ROOT / "results"
OUT.mkdir(exist_ok=True)
SEED, B = 20261104, 10000
RUNS = ["unedited", "p10c", "p25c", "p50c"]
SAMPLES = 4

# Attempts with Qwen3.5-0.8B listed in the logs' results table (eval/RESULTS_excerpt.md): (label, passes budget, MATH-500 %, GSM8K %, edit submitted)
ATTEMPTS = [
    ("v2, 0 passes", 0, 7.9, 13.8, False),
    ("v3, 5 passes", 5, 7.9, 13.8, False),
    ("v3, 10 passes (p10c)", 10, 12.3, 25.7, True),
    ("v3, 25 passes (p25c)", 25, 14.1, 25.1, True),
    ("v3, 50 passes (p50c)", 50, 48.1, 67.1, True),
    ("v4, 10 passes", 10, 7.9, 13.8, False),
    ("v4, 25 passes", 25, 14.1, 25.1, True),   # edit submission inferred: identical scores to p25c; the excerpt leaves the note blank
]


def load_counts() -> pd.DataFrame:
    d = pd.read_csv(IN / "math500_per_problem_correct_counts.csv")
    assert len(d) == 500 and d.id.is_unique
    assert d[RUNS].min().min() >= 0 and d[RUNS].max().max() <= SAMPLES
    return d


def accuracy(d: pd.DataFrame, run: str) -> float:
    return float(d[run].sum() / (SAMPLES * len(d)))


def boot_means(x: np.ndarray, rng: np.random.Generator, b: int = B) -> np.ndarray:
    idx = rng.integers(0, len(x), size=(b, len(x)))
    return x[idx].mean(axis=1)


def percentile_ci(v: np.ndarray, level: float = 0.95) -> tuple[float, float]:
    lo, hi = np.percentile(v, [(1 - level) / 2 * 100, (1 + level) / 2 * 100])
    return float(lo), float(hi)


def accuracy_table(d: pd.DataFrame) -> pd.DataFrame:
    tot = pd.read_csv(IN / "math500_sample_totals.csv").set_index("run")
    rng = np.random.default_rng(SEED)
    rows = []
    for r in RUNS:
        p = d[r].to_numpy() / SAMPLES
        lo, hi = percentile_ci(boot_means(p, rng))
        correct, cut, n = int(tot.loc[r, "correct"]), int(tot.loc[r, "cut_at_max_tokens"]), int(tot.loc[r, "samples"])
        assert correct == int(d[r].sum())
        finished = n - cut
        rows.append(dict(run=r, accuracy=correct / n, ci_low=lo, ci_high=hi, cut_share=cut / n, finished_samples=finished,
                         correct_samples=correct, min_correct_among_cut=max(0, correct - finished),
                         share_of_correct_that_were_cut_min=max(0, correct - finished) / correct,
                         problems_with_any_correct=int((d[r] > 0).sum()), problems_all_four_correct=int((d[r] == SAMPLES).sum())))
    return pd.DataFrame(rows)


def paired_table(d: pd.DataFrame) -> pd.DataFrame:
    rng = np.random.default_rng(SEED + 1)
    pairs = [("p10c", "unedited"), ("p25c", "unedited"), ("p50c", "unedited"), ("p25c", "p10c"), ("p50c", "p25c")]
    rows = []
    for a, b in pairs:
        diff = (d[a] - d[b]).to_numpy() / SAMPLES
        lo, hi = percentile_ci(boot_means(diff, rng))
        rows.append(dict(a=a, b=b, diff_points=100 * diff.mean(), ci_low_points=100 * lo, ci_high_points=100 * hi,
                         problems_better=int((diff > 0).sum()), problems_worse=int((diff < 0).sum()), problems_equal=int((diff == 0).sum())))
    return pd.DataFrame(rows)


def first_sample_proxy() -> pd.DataFrame:
    """Subset check of the truncation lower bound: among the first-sample texts in the logs (200 per run), how many lack the closing think tag (a proxy for being cut off) and how many of those were graded correct.

    The counts in inputs/first_sample_proxy.csv were extracted from math500_first_samples.jsonl.gz of the logs together with the per-problem correctness of the first sample.
    """
    d = pd.read_csv(IN / "first_sample_proxy.csv")
    d["share_without_think_close"] = d.without_think_close / d.first_samples
    d["share_of_correct_in_cut_proxy"] = d.correct_without_think_close / d.correct_first_samples
    return d


def benchmark_table() -> pd.DataFrame:
    s = pd.read_csv(IN / "benchmark_summary.csv")
    w = s.pivot(index="benchmark", columns="run", values=["acc_percent", "cut_share_percent"])
    out = pd.DataFrame({"benchmark": w.index})
    for r in ("unedited", "p50c"):
        out[f"acc_{r}"] = w[("acc_percent", r)].to_numpy()
        out[f"cut_{r}"] = w[("cut_share_percent", r)].to_numpy()
    out["delta_acc"] = out.acc_p50c - out.acc_unedited
    out["delta_finished"] = out.cut_unedited - out.cut_p50c      # drop in cut share = rise in finished share (points)
    return out


def weights_arithmetic() -> dict:
    n_edit = 2 * 64 * 1024          # logs README: 64 output columns in each of two MLP output matrices (layers 15 and 19), 1,024 rows each
    return dict(edited_weights=n_edit, share_of_0p8B=n_edit / 0.8e9, share_of_0p8B_percent=100 * n_edit / 0.8e9,
                head_off_p25c_if_hidden_1024=256 * 1024, ratio_p25c_to_p50c=256 * 1024 / n_edit)


def attempt_table() -> pd.DataFrame:
    a = pd.DataFrame(ATTEMPTS, columns=["attempt", "passes", "math500", "gsm8k", "edit_submitted"])
    a["gain_over_unedited_points"] = a.math500 - 7.9
    return a


def main() -> None:
    pd.set_option("display.width", 250, "display.max_columns", 30, "display.float_format", lambda v: f"{v:.4g}")
    d = load_counts()
    acc = accuracy_table(d); acc.to_csv(OUT / "math500_accuracy.csv", index=False); print(acc)
    pr = paired_table(d); pr.to_csv(OUT / "math500_paired.csv", index=False); print(pr)
    fp = first_sample_proxy(); fp.to_csv(OUT / "first_sample_proxy.csv", index=False); print(fp)
    bm = benchmark_table(); bm.to_csv(OUT / "benchmarks_p50c_vs_unedited.csv", index=False); print(bm)
    print("Pearson r (delta_acc, delta_finished):", float(np.corrcoef(bm.delta_acc, bm.delta_finished)[0, 1]),
          " Spearman:", float(bm[["delta_acc", "delta_finished"]].corr(method="spearman").iloc[0, 1]))
    wa = weights_arithmetic(); pd.Series(wa).to_csv(OUT / "weights_arithmetic.csv", header=["value"]); print(wa)
    at = attempt_table(); at.to_csv(OUT / "attempt_ledger.csv", index=False); print(at)
    finished_ratio = (1 - 0.3305) / (1 - 0.93)           # share of MATH-500 samples that finished: p50c vs unedited
    ratios = dict(math500=48.1 / 7.9, gsm8k=67.1 / 13.8, ifeval=62.3 / 21.0, finished_share_math500=finished_ratio)
    pd.Series(ratios).to_csv(OUT / "ratios.csv", header=["value"]); print(ratios)


if __name__ == "__main__":
    main()
