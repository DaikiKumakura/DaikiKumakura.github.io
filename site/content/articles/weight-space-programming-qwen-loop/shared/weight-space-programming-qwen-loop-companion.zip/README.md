# Reading the MATH-500 result of a weight-editing experiment: companion code

Bootstrap intervals, paired differences, truncation lower bound and cross-benchmark comparison computed from numbers in the public logs of the Weight-Space Programming post (Experiment 8, Qwen3.5-0.8B; logs under CC BY 4.0 at github.com/RikiyaT/lm_understand-logs). No model is run.

- `analysis.py`: all tables.
- `figures.py`: Figures 1 and 2.
- `test_analysis.py`: checks (`python -m pytest test_analysis.py`).
- `inputs/`: per-problem correct counts, sample totals and benchmark summary extracted from the logs.
- `results/`: CSV outputs.

Requires Python 3 with numpy, pandas, matplotlib.

The numbers in `inputs/` are extracted from the logs by Rikiya Takehi (github.com/RikiyaT/lm_understand-logs), licensed CC BY 4.0 (https://creativecommons.org/licenses/by/4.0/); this folder extracts and recomputes from them.
