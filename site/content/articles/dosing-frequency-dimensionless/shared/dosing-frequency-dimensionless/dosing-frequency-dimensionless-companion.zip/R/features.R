#' Extract dynamic features from a profile
#'
#' Computes defined features over a time window of a sampled profile. Integrals
#' use the trapezoidal rule on the supplied sampling grid (a coarse grid gives
#' a coarse integral); features that are not defined are `NA` with the reason
#' in the `note` attribute.
#'
#' Definitions (window `[t0, t1]`, concentration in mg/L):
#' * `auc`: trapezoidal area under the concentration curve (mg h/L).
#' * `cmax`, `tmax`: maximum on the grid in the window and its time.
#' * `cmin`: minimum on the grid in the window.
#' * `cavg`: `auc / (t1 - t0)`.
#' * `mean_effect`, `peak_effect`, `min_effect`: for PD profiles, time average
#'   (trapezoid), maximum and minimum of `effect`.
#' * `time_above`: fraction of the window with `effect >= threshold` (linear
#'   interpolation between grid points), if `threshold` is given.
#'
#' @param profile A data frame from [simulate_profile()].
#' @param window Numeric length 2 `c(t0, t1)`; defaults to the full range.
#' @param threshold Optional effect threshold (same units as `effect`).
#' @return A one-row data frame of features.
#' @examples
#' m <- pkpd_model("one_compartment", "direct_emax")
#' r <- regimen(amount = 24, interval = 24, n = 14)
#' p <- simulate_profile(m, c(CL = 2, V = 20, EC50 = 0.5, hill = 1), r, times = seq(0, 336, by = 0.5))
#' extract_features(p, window = c(312, 336), threshold = 0.5)
#' @export
extract_features <- function(profile, window = NULL, threshold = NULL) {
  if (!all(c("time", "concentration") %in% names(profile))) stop("`profile` needs `time` and `concentration`.", call. = FALSE)
  if (is.null(window)) window <- range(profile$time)
  if (length(window) != 2L || window[2] <= window[1]) stop("`window` must be c(t0, t1) with t1 > t0.", call. = FALSE)
  d <- profile[order(profile$time), ]
  keep <- d$time >= window[1] - 1e-12 & d$time <= window[2] + 1e-12
  d <- d[keep, ]
  if (nrow(d) < 2L) stop("Fewer than two sampling times in the window.", call. = FALSE)
  trapz <- function(x, y) sum(diff(x) * (head(y, -1) + tail(y, -1)) / 2)
  w <- diff(range(d$time))
  auc <- trapz(d$time, d$concentration)
  out <- data.frame(window_start = window[1], window_end = window[2], n_points = nrow(d),
                    auc = auc, cmax = max(d$concentration), tmax = d$time[which.max(d$concentration)],
                    cmin = min(d$concentration), cavg = auc / w)
  if ("effect" %in% names(d)) {
    out$mean_effect <- trapz(d$time, d$effect) / w
    out$peak_effect <- max(d$effect)
    out$min_effect <- min(d$effect)
    if (!is.null(threshold)) out$time_above <- fraction_above(d$time, d$effect, threshold)
  } else if (!is.null(threshold)) {
    stop("`threshold` needs an `effect` column.", call. = FALSE)
  }
  out
}

# Fraction of [min(t), max(t)] with y >= threshold, interpolating linearly.
fraction_above <- function(t, y, threshold) {
  tot <- 0
  for (i in seq_len(length(t) - 1L)) {
    t0 <- t[i]; t1 <- t[i + 1L]; y0 <- y[i]; y1 <- y[i + 1L]
    if (y0 >= threshold && y1 >= threshold) tot <- tot + (t1 - t0)
    else if (y0 < threshold && y1 < threshold) next
    else {
      tc <- t0 + (threshold - y0) / (y1 - y0) * (t1 - t0)
      tot <- tot + if (y0 >= threshold) tc - t0 else t1 - tc
    }
  }
  tot / (max(t) - min(t))
}
