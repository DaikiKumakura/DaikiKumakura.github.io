#' Simulate virtual drugs under a set of regimens
#'
#' Solves every accepted virtual drug under every regimen of a [regimen_set()]
#' with the ODE engine and returns one row of features per (drug, regimen).
#' Drugs are processed in chunks of `chunk_size`; when `dir` is given, each
#' chunk is written atomically and an interrupted run resumes from the chunks
#' already present. Results do not depend on `chunk_size`. Full time series
#' are not stored; they can be recomputed from the parameters with
#' [simulate_profile()].
#'
#' Features are defined over `window` (default: the last 7 days of the
#' horizon) of the sampling grid by the trapezoidal rule; see
#' [extract_features()]. A failed solution (non-finite values, negative
#' amounts, occupancy outside 0 to 1) is recorded with `status = "failed"`
#' and a reason and is never clipped.
#'
#' @param drugs A [sample_space()] result.
#' @param regimens A [regimen_set()] or a single [regimen()].
#' @param times Sampling times (h). Default: hourly over the horizon implied by
#'   the regimens plus 7 days.
#' @param window `c(t0, t1)` window (h) for the features; default last 168 h.
#' @param threshold Effect threshold for `time_above` (default 0.5 of the
#'   maximal effect for models with a PD structure whose effect is bounded by 1;
#'   otherwise no threshold feature).
#' @param chunk_size Number of drugs per chunk.
#' @param dir Optional output directory for chunk files and `manifest.rds`.
#' @param dry_run If `TRUE`, return an estimate of size and time and do nothing.
#' @return A data frame of class `pkpd_results` (or, for `dry_run`, a list).
#' @examples
#' \dontrun{
#' m <- pkpd_model("one_compartment", "direct_emax")
#' sp <- parameter_space(m, list(CL = c(0.1, 10), V = c(5, 100), EC50 = c(0.01, 10)),
#'                       fixed = c(hill = 1))
#' drugs <- sample_space(sp, n = 64, seed = 1)
#' regs <- regimen_set(daily = regimen(amount = 24, interval = 24, n = 14),
#'                     twice = regimen(amount = 12, interval = 12, n = 28))
#' res <- simulate_space(drugs, regs, chunk_size = 32)
#' }
#' @export
simulate_space <- function(drugs, regimens, times = NULL, window = NULL, threshold = NULL,
                           chunk_size = 1024L, dir = NULL, dry_run = FALSE) {
  if (!inherits(drugs, "pkpd_drugs")) stop("`drugs` must come from sample_space().", call. = FALSE)
  if (inherits(regimens, "pkpd_regimen")) regimens <- regimen_set(regimens)
  if (!inherits(regimens, "pkpd_regimen_set")) stop("`regimens` must be a regimen_set().", call. = FALSE)
  space <- attr(drugs, "space"); model <- space$model
  last <- max(vapply(regimens$regimens, function(r) max(r$events$time + ifelse(is.na(r$events$duration), 0, r$events$duration)), numeric(1)))
  horizon <- ceiling(last + 168)
  if (is.null(times)) times <- seq(0, horizon, by = 1)
  if (is.null(window)) window <- c(max(0, max(times) - 168), max(times))
  chunk_size <- as.integer(chunk_size)
  ok <- which(drugs$status == "ok")
  pnames <- model$parameters$name
  nreg <- length(regimens$regimens)
  est <- list(n_drugs = nrow(drugs), n_accepted = length(ok), n_regimens = nreg, n_time = length(times),
              est_rows = length(ok) * nreg, est_feature_bytes = length(ok) * nreg * 20 * 8,
              est_chunk_memory_mb = chunk_size * length(times) * 8 * 8 / 1024^2)
  if (dry_run) {
    probe <- ok[seq_len(min(32L, length(ok)))]
    t0 <- proc.time()[["elapsed"]]
    for (r in regimens$regimens) solve_ode(model, drugs[probe, pnames, drop = FALSE], r, times)
    est$seconds_per_drug_regimen <- (proc.time()[["elapsed"]] - t0) / (length(probe) * nreg)
    est$est_seconds <- est$seconds_per_drug_regimen * length(ok) * nreg
    return(structure(est, class = "pkpd_dry_run"))
  }
  chunks <- split(ok, ceiling(seq_along(ok) / chunk_size))
  if (!is.null(dir)) dir.create(dir, recursive = TRUE, showWarnings = FALSE)
  t_start <- proc.time()[["elapsed"]]
  out <- vector("list", length(chunks)); skipped <- 0L
  for (k in seq_along(chunks)) {
    f <- if (is.null(dir)) NULL else file.path(dir, sprintf("chunk_%06d.rds", k))
    if (!is.null(f) && file.exists(f)) { out[[k]] <- readRDS(f); skipped <- skipped + 1L; next }
    res <- simulate_chunk(model, drugs[chunks[[k]], , drop = FALSE], regimens, times, window, threshold)
    if (!is.null(f)) { tmp <- paste0(f, ".tmp"); saveRDS(res, tmp); file.rename(tmp, f) }
    out[[k]] <- res
  }
  res <- do.call(rbind, out)
  rejected <- drugs[drugs$status != "ok", , drop = FALSE]
  man <- list(package = "pkpdspace", version = as.character(utils::packageVersion("pkpdspace")), created = format(Sys.time(), tz = "UTC", usetz = TRUE),
              structure_id = model$structure_id, n_drugs = nrow(drugs), n_rejected_by_constraint = nrow(rejected),
              n_rows = nrow(res), n_failed = sum(res$status != "ok"), n_regimens = nreg, regimens = names(regimens$regimens),
              n_time = length(times), horizon_h = max(times), window = window, chunk_size = chunk_size, chunks = length(chunks),
              chunks_resumed = skipped, seed = unique(drugs$seed), design_method = unique(drugs$design_method),
              runtime_seconds = proc.time()[["elapsed"]] - t_start, R = R.version.string, platform = R.version$platform)
  if (!is.null(dir)) { tmp <- file.path(dir, "manifest.rds.tmp"); saveRDS(man, tmp); file.rename(tmp, file.path(dir, "manifest.rds")) }
  attr(res, "manifest") <- man
  class(res) <- c("pkpd_results", "data.frame")
  res
}

#' @export
print.pkpd_dry_run <- function(x, ...) {
  cat("<dry run> ", x$n_accepted, " accepted drug(s) x ", x$n_regimens, " regimen(s), ", x$n_time, " time points\n", sep = "")
  cat(sprintf("  estimated feature table: %.1f MB; chunk working memory about %.0f MB\n", x$est_feature_bytes / 1024^2, x$est_chunk_memory_mb))
  cat(sprintf("  measured %.4f s per drug and regimen -> estimated %.1f s in total (serial)\n", x$seconds_per_drug_regimen, x$est_seconds))
  invisible(x)
}

simulate_chunk <- function(model, d, regimens, times, window, threshold) {
  pnames <- model$parameters$name
  rows <- list()
  for (rid in names(regimens$regimens)) {
    r <- regimens$regimens[[rid]]
    s <- try(solve_ode(model, d[, pnames, drop = FALSE], r, times), silent = TRUE)
    if (inherits(s, "try-error")) {
      # isolate failures: solve one by one and record the reason
      parts <- lapply(seq_len(nrow(d)), function(i) {
        si <- try(solve_ode(model, d[i, pnames, drop = FALSE], r, times), silent = TRUE)
        if (inherits(si, "try-error")) return(failed_features(d$virtual_id[i], rid, conditionMessage(attr(si, "condition"))))
        chk <- try(check_solution(si, model), silent = TRUE)
        if (inherits(chk, "try-error")) return(failed_features(d$virtual_id[i], rid, conditionMessage(attr(chk, "condition"))))
        cbind(virtual_id = d$virtual_id[i], regimen_id = rid, features_from_solution(model, si, r, window, threshold), status = "ok", reason = NA_character_, stringsAsFactors = FALSE)
      })
      rows[[length(rows) + 1L]] <- do.call(rbind, parts)
    } else {
      bad <- solution_failures(s, model)
      f <- features_from_solution(model, s, r, window, threshold)
      f <- cbind(virtual_id = d$virtual_id, regimen_id = rid, f, status = ifelse(is.na(bad), "ok", "failed"), reason = bad, stringsAsFactors = FALSE)
      f[!is.na(bad), setdiff(names(f), c("virtual_id", "regimen_id", "status", "reason"))] <- NA_real_
      rows[[length(rows) + 1L]] <- f
    }
  }
  do.call(rbind, rows)
}

failed_features <- function(id, rid, reason) {
  data.frame(virtual_id = id, regimen_id = rid, auc = NA_real_, cmax = NA_real_, cmin = NA_real_, cavg = NA_real_,
             peak_trough = NA_real_, accumulation = NA_real_, mean_effect = NA_real_, peak_effect = NA_real_, min_effect = NA_real_,
             time_above = NA_real_, tox_max = NA_real_, tox_auc = NA_real_, total_dose = NA_real_, n_doses = NA_real_, status = "failed", reason = reason,
             stringsAsFactors = FALSE)
}

# Per-column failure reason (NA when fine).
solution_failures <- function(s, model, tol = 1e-8) {
  ns <- ncol(s$A)
  reason <- rep(NA_character_, ns)
  for (nm in setdiff(names(s), "time")) {
    bad <- colSums(!is.finite(s[[nm]])) > 0
    reason[bad & is.na(reason)] <- paste("non-finite", nm)
  }
  scale <- pmax(1, apply(abs(s$A), 2, max))
  neg <- colSums(s$A < -tol * rep(scale, each = nrow(s$A))) > 0
  reason[neg & is.na(reason)] <- "negative amount"
  if ("O" %in% names(s)) { o <- colSums(s$O < -tol | s$O > 1 + tol) > 0; reason[o & is.na(reason)] <- "occupancy outside [0, 1]" }
  reason
}

# Vectorised features from a solution list (matrices ntime x nset).
features_from_solution <- function(model, s, regimen, window, threshold) {
  t <- s$time; ns <- ncol(s$A)
  idx <- which(t >= window[1] - 1e-9 & t <= window[2] + 1e-9)
  tw <- t[idx]; w <- numeric(length(tw))
  dt <- diff(tw); w[-1] <- w[-1] + dt / 2; w[-length(tw)] <- w[-length(tw)] + dt / 2
  Cn <- model$pk_spec$conc[1]
  C <- s[[Cn]][idx, , drop = FALSE]
  W <- diff(range(tw))
  auc <- colSums(w * C)
  cmax <- apply(C, 2, max); cmin <- apply(C, 2, min)
  first_end <- if (regimen$n > 1L) regimen$interval else 24
  fi <- which(t <= first_end + 1e-9)
  cmax_first <- apply(s[[Cn]][fi, , drop = FALSE], 2, max)
  out <- data.frame(auc = auc, cmax = cmax, cmin = cmin, cavg = auc / W,
                    peak_trough = ifelse(cmin > 0, cmax / cmin, NA_real_), accumulation = ifelse(cmax_first > 0, cmax / cmax_first, NA_real_))
  if (!is.null(model$pd_spec)) {
    E <- s[[model$pd_spec$effect]][idx, , drop = FALSE]
    out$mean_effect <- colSums(w * E) / W; out$peak_effect <- apply(E, 2, max); out$min_effect <- apply(E, 2, min)
    thr <- if (is.null(threshold)) 0.5 else threshold
    out$time_above <- time_above_matrix(tw, E, thr)
  } else { out$mean_effect <- NA_real_; out$peak_effect <- NA_real_; out$min_effect <- NA_real_; out$time_above <- NA_real_ }
  if (!is.null(model$tox_spec)) {
    H <- s[[model$tox_spec$effect]][idx, , drop = FALSE]
    out$tox_max <- apply(H, 2, max); out$tox_auc <- colSums(w * H) / W
  } else { out$tox_max <- NA_real_; out$tox_auc <- NA_real_ }
  out$total_dose <- sum(regimen$events$amount); out$n_doses <- nrow(regimen$events)
  out
}

# Fraction of the window with y >= threshold (linear interpolation), per column.
time_above_matrix <- function(t, Y, thr) {
  tot <- numeric(ncol(Y))
  for (i in seq_len(length(t) - 1L)) {
    y0 <- Y[i, ]; y1 <- Y[i + 1L, ]; d <- t[i + 1L] - t[i]
    a0 <- y0 >= thr; a1 <- y1 >= thr
    full <- a0 & a1
    part <- xor(a0, a1)
    frac <- ifelse(part, ifelse(a0, (y0 - thr) / (y0 - y1), (y1 - thr) / (y1 - y0)), 0)
    tot <- tot + d * (full + part * frac)
  }
  tot / (max(t) - min(t))
}
