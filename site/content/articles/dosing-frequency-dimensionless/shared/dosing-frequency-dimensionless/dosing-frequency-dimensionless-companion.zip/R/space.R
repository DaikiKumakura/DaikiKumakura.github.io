#' Define a parameter space
#'
#' Describes the region from which virtual drugs are sampled: a range per
#' model parameter, a transform (`"log"`, `"logit"` or `"identity"`) and
#' optional constraints. The space carries no drug, target or modality
#' information. Sampling distributions are exploration designs, not
#' distributions of real drugs.
#'
#' @param model A [pkpd_model()].
#' @param ranges Named list of `c(lower, upper)` for every model parameter
#'   that is varied. Parameters that are not listed take their `fixed` value or
#'   the registry default (`Emax`, `Hmax`, `F`, `mwr`).
#' @param transforms Named character vector of transforms; defaults come from
#'   the registry (`"log"` for positive scales, `"logit"` for fractions).
#' @param fixed Named numeric vector of parameters held constant.
#' @param constraints Optional function taking a data frame of sampled
#'   parameters and returning a logical vector (`TRUE` = keep).
#' @return A `pkpd_space` object.
#' @examples
#' m <- pkpd_model("one_compartment", "direct_emax")
#' parameter_space(m, ranges = list(CL = c(0.1, 10), V = c(5, 100),
#'                                     EC50 = c(0.01, 10), hill = c(1, 3)),
#'                 transforms = c(CL = "log", V = "log", EC50 = "log", hill = "identity"))
#' @export
parameter_space <- function(model, ranges, transforms = NULL, fixed = NULL, constraints = NULL) {
  if (!inherits(model, "pkpd_model")) stop("`model` must be a pkpd_model.", call. = FALSE)
  sch <- model$parameters
  if (!is.list(ranges) || is.null(names(ranges))) stop("`ranges` must be a named list.", call. = FALSE)
  unk <- setdiff(names(ranges), sch$name)
  if (length(unk)) stop(sprintf("Unknown parameter(s) in `ranges`: %s.", paste(unk, collapse = ", ")), call. = FALSE)
  tr <- stats::setNames(sch$transform[match(names(ranges), sch$name)], names(ranges))
  if (!is.null(transforms)) tr[names(transforms)] <- transforms
  for (nm in names(ranges)) {
    r <- ranges[[nm]]
    if (!is.numeric(r) || length(r) != 2L || any(!is.finite(r)) || r[1] >= r[2]) stop(sprintf("Range of `%s` must be c(lower, upper) with lower < upper.", nm), call. = FALSE)
    if (!tr[[nm]] %in% c("log", "logit", "identity")) stop(sprintf("Unknown transform `%s`.", tr[[nm]]), call. = FALSE)
    if (tr[[nm]] == "log" && r[1] <= 0) stop(sprintf("Log-transformed `%s` needs a positive lower bound.", nm), call. = FALSE)
    if (tr[[nm]] == "logit" && (r[1] < 0 || r[2] > 1)) stop(sprintf("Logit-transformed `%s` must lie in [0, 1].", nm), call. = FALSE)
  }
  need <- setdiff(sch$name[is.na(sch$default)], names(ranges))
  fixed <- c(fixed, if (length(need) && is.null(fixed)) NULL)
  miss <- setdiff(need, names(fixed))
  if (length(miss)) stop(sprintf("Parameter(s) neither in `ranges` nor `fixed`: %s.", paste(miss, collapse = ", ")), call. = FALSE)
  structure(list(model = model, ranges = ranges, transforms = tr, fixed = fixed, constraints = constraints,
                 dimension = length(ranges)), class = "pkpd_space")
}

#' @export
print.pkpd_space <- function(x, ...) {
  cat("<pkpd_space>", x$model$structure_id, "-", x$dimension, "varied parameter(s)\n")
  for (nm in names(x$ranges)) cat(sprintf("  %-9s [%g, %g] %s\n", nm, x$ranges[[nm]][1], x$ranges[[nm]][2], x$transforms[[nm]]))
  if (length(x$fixed)) cat("  fixed:", paste0(names(x$fixed), " = ", x$fixed, collapse = ", "), "\n")
  invisible(x)
}

# Unit-cube design points. Sobol with a random shift when randtoolbox is available,
# otherwise independent pseudo-random numbers; the method actually used is
# returned. Points depend only on (n, d, seed, method), not on chunking.
unit_design <- function(n, d, seed, method) {
  if (method == "sobol" && requireNamespace("randtoolbox", quietly = TRUE)) {
    # randtoolbox::sobol() has no scrambling in this version, so the points are
    # randomized with a Cranley-Patterson random shift drawn from the seed.
    set.seed(seed)
    shift <- stats::runif(d)
    u0 <- matrix(randtoolbox::sobol(n, dim = d), nrow = n)
    list(u = (u0 + matrix(shift, n, d, byrow = TRUE)) %% 1, method = "sobol_random_shift")
  } else {
    if (method == "sobol") warning("randtoolbox is not installed; falling back to pseudo-random sampling.", call. = FALSE)
    set.seed(seed)
    list(u = matrix(stats::runif(n * d), nrow = n), method = "pseudo_random")
  }
}

#' Sample virtual drugs
#'
#' Draws virtual parameter sets from a [parameter_space()] with a space-filling
#' (randomly shifted Sobol) or pseudo-random design. Points are identified by their
#' design index, so the same `seed` and `n` give the same points whatever the
#' chunk size or the number of workers used later. Points rejected by the
#' constraint function are kept in the design with `status = "rejected"` (and
#' counted) so that identifiers stay stable.
#'
#' A low-discrepancy design is not an independent random sample.
#'
#' @param space A [parameter_space()].
#' @param n Number of design points.
#' @param method `"sobol"` (default) or `"random"`.
#' @param seed Integer seed.
#' @return A data frame with `virtual_id`, `structure_id`, `design_index`,
#'   `design_method`, `seed`, `status`, then one column per model parameter,
#'   with class `pkpd_drugs`.
#' @examples
#' m <- pkpd_model("one_compartment", "direct_emax")
#' sp <- parameter_space(m, list(CL = c(0.1, 10), V = c(5, 100), EC50 = c(0.01, 10),
#'                                hill = c(1, 3)),
#'                       transforms = c(hill = "identity"))
#' head(sample_space(sp, n = 16, seed = 1, method = "random"))
#' @export
sample_space <- function(space, n, method = c("sobol", "random"), seed = 1L) {
  method <- match.arg(method)
  if (!inherits(space, "pkpd_space")) stop("`space` must be a pkpd_space.", call. = FALSE)
  if (!is.numeric(n) || length(n) != 1L || n < 1 || n != round(n)) stop("`n` must be a positive integer.", call. = FALSE)
  d <- space$dimension
  ud <- unit_design(n, d, seed, method)
  sch <- space$model$parameters
  th <- as.data.frame(matrix(NA_real_, n, nrow(sch), dimnames = list(NULL, sch$name)))
  for (j in seq_len(d)) {
    nm <- names(space$ranges)[j]; r <- space$ranges[[nm]]; tr <- space$transforms[[nm]]; u <- ud$u[, j]
    th[[nm]] <- switch(tr,
      log = exp(log(r[1]) + u * (log(r[2]) - log(r[1]))),
      logit = { lo <- stats::qlogis(pmax(r[1], 1e-6)); hi <- stats::qlogis(pmin(r[2], 1 - 1e-6)); stats::plogis(lo + u * (hi - lo)) },
      identity = r[1] + u * (r[2] - r[1]))
  }
  for (i in seq_len(nrow(sch))) {
    nm <- sch$name[i]
    if (nm %in% names(space$ranges)) next
    th[[nm]] <- if (nm %in% names(space$fixed)) space$fixed[[nm]] else sch$default[i]
  }
  keep <- rep(TRUE, n)
  if (!is.null(space$constraints)) keep <- as.logical(space$constraints(th))
  out <- data.frame(virtual_id = sprintf("%s-%s-%08d", space$model$structure_id, format(seed), seq_len(n)),
                    structure_id = space$model$structure_id, design_index = seq_len(n), design_method = ud$method,
                    seed = seed, status = ifelse(keep, "ok", "rejected"), th, stringsAsFactors = FALSE)
  attr(out, "space") <- space
  class(out) <- c("pkpd_drugs", "data.frame")
  out
}
