# Model registry --------------------------------------------------------------
#
# Every supported structure is registered with its equations, parameters,
# units, routes and solver. Combinations that are not registered are rejected.
# Units: time in h, volume in L, amount in mg, concentration in mg/L.
# Structures are identified by mechanism, never by drug, target or modality.

par_row <- function(name, unit, lower, upper, lower_inclusive, transform, default = NA_real_, description = "") {
  data.frame(name = name, unit = unit, lower = lower, upper = upper, lower_inclusive = lower_inclusive,
             transform = transform, default = default, description = description, stringsAsFactors = FALSE)
}
par_table <- function(...) do.call(rbind, list(...))

registry_components <- function() {
  list(
    pk = list(
      one_compartment = list(
        id = "K01", name = "One-compartment linear",
        equations = c("dA/dt = input - CL * C", "C = A / V"),
        parameters = par_table(par_row("CL", "L/h", 0, Inf, FALSE, "log", description = "Total clearance"),
                               par_row("V", "L", 0, Inf, FALSE, "log", description = "Volume of distribution")),
        routes = c("iv_bolus", "iv_infusion"), dose_cmt = c(iv_bolus = "A", iv_infusion = "A", oral = "Ag"),
        states = "A", solver = "analytic or ode",
        ode = c("C <- A / V", "d/dt(A) <- - CL * C"), drivers = c(parent = "C"), conc = "C"),
      first_order_input = list(
        id = "K02", name = "One-compartment, first-order extravascular input",
        equations = c("dAg/dt = -ka * Ag", "dA/dt = F * ka * Ag - CL * C + iv_input", "C = A / V"),
        parameters = par_table(par_row("CL", "L/h", 0, Inf, FALSE, "log", description = "Total clearance"),
                               par_row("V", "L", 0, Inf, FALSE, "log", description = "Volume of distribution"),
                               par_row("ka", "1/h", 0, Inf, FALSE, "log", description = "First-order absorption rate constant"),
                               par_row("F", "1", 0, 1, TRUE, "logit", default = 1, description = "Bioavailable fraction (not applicable to iv input)")),
        routes = c("iv_bolus", "iv_infusion", "oral"), dose_cmt = c(iv_bolus = "A", iv_infusion = "A", oral = "Ag"),
        states = c("Ag", "A"), solver = "ode",
        ode = c("C <- A / V", "d/dt(Ag) <- - ka * Ag", "d/dt(A) <- Fbio * ka * Ag - CL * C"), drivers = c(parent = "C"), conc = "C"),
      two_compartment = list(
        id = "K03", name = "Two-compartment linear",
        equations = c("dAc/dt = input - CL * Cc - Q * (Cc - Cp)", "dAp/dt = Q * (Cc - Cp)", "Cc = Ac / Vc, Cp = Ap / Vp"),
        parameters = par_table(par_row("CL", "L/h", 0, Inf, FALSE, "log", description = "Total clearance from the central compartment"),
                               par_row("V", "L", 0, Inf, FALSE, "log", description = "Central volume Vc"),
                               par_row("Q", "L/h", 0, Inf, FALSE, "log", description = "Inter-compartmental clearance"),
                               par_row("Vp", "L", 0, Inf, FALSE, "log", description = "Peripheral volume")),
        routes = c("iv_bolus", "iv_infusion"), dose_cmt = c(iv_bolus = "A", iv_infusion = "A"),
        states = c("A", "Ap"), solver = "ode",
        ode = c("C <- A / V", "Cp <- Ap / Vp", "d/dt(A) <- - CL * C - Q * (C - Cp)", "d/dt(Ap) <- Q * (C - Cp)"),
        drivers = c(parent = "C"), conc = "C"),
      saturable_elimination = list(
        id = "K04", name = "One-compartment with parallel linear and saturable elimination",
        equations = c("dA/dt = input - CL * C - Vmax * C / (Km + C)", "C = A / V"),
        parameters = par_table(par_row("CL", "L/h", 0, Inf, FALSE, "log", description = "Linear clearance"),
                               par_row("V", "L", 0, Inf, FALSE, "log", description = "Volume of distribution"),
                               par_row("Vmax", "mg/h", 0, Inf, FALSE, "log", description = "Maximal saturable elimination rate (amount/time)"),
                               par_row("Km", "mg/L", 0, Inf, FALSE, "log", description = "Michaelis constant (concentration)")),
        routes = c("iv_bolus", "iv_infusion"), dose_cmt = c(iv_bolus = "A", iv_infusion = "A"),
        states = "A", solver = "ode",
        ode = c("C <- A / V", "d/dt(A) <- - CL * C - Vmax * C / (Km + C)"), drivers = c(parent = "C"), conc = "C"),
      active_species = list(
        id = "K05", name = "Parent with formation of an active species (mass-consistent)",
        equations = c("dA/dt = input - CL * C", "dM/dt = mwr * fm * CL * C - CLm * Cm", "C = A / V, Cm = M / Vm"),
        parameters = par_table(par_row("CL", "L/h", 0, Inf, FALSE, "log", description = "Total parent clearance"),
                               par_row("V", "L", 0, Inf, FALSE, "log", description = "Parent volume"),
                               par_row("fm", "1", 0, 1, TRUE, "logit", description = "Fraction of parent clearance that forms the active species"),
                               par_row("CLm", "L/h", 0, Inf, FALSE, "log", description = "Active species clearance"),
                               par_row("Vm", "L", 0, Inf, FALSE, "log", description = "Active species volume"),
                               par_row("mwr", "1", 0, Inf, FALSE, "identity", default = 1, description = "Mass of active species formed per mass of parent converted (molecular-weight ratio times stoichiometry)")),
        routes = c("iv_bolus", "iv_infusion"), dose_cmt = c(iv_bolus = "A", iv_infusion = "A"),
        states = c("A", "M"), solver = "ode",
        ode = c("C <- A / V", "Cm <- M / Vm", "d/dt(A) <- - CL * C", "d/dt(M) <- mwr * fm * CL * C - CLm * Cm"),
        drivers = c(parent = "C", active = "Cm"), conc = c("C", "Cm"), default_driver = "active")
    ),
    pd = list(
      direct_emax = list(
        id = "P01", name = "Direct Emax / Hill",
        equations = c("S = Cd^h / (EC50^h + Cd^h)", "E = Emax * S"),
        parameters = par_table(par_row("EC50", "mg/L", 0, Inf, FALSE, "log", description = "Driver concentration at half-maximal effect"),
                               par_row("hill", "1", 0, Inf, FALSE, "log", description = "Hill coefficient"),
                               par_row("Emax", "1", 0, Inf, TRUE, "identity", default = 1, description = "Maximal effect (proxy units)")),
        ode = c("S <- 1 / (1 + (EC50 / (Cd + 1e-300))^hill)", "E <- Emax * S"), states = character(), effect = "E", stimulus = "S"),
      effect_compartment = list(
        id = "P02", name = "Effect compartment",
        equations = c("dCe/dt = ke0 * (Cd - Ce)", "S = Ce^h / (EC50^h + Ce^h)", "E = Emax * S"),
        parameters = par_table(par_row("ke0", "1/h", 0, Inf, FALSE, "log", description = "Effect-site equilibration rate constant"),
                               par_row("EC50", "mg/L", 0, Inf, FALSE, "log", description = "Effect-site concentration at half-maximal effect"),
                               par_row("hill", "1", 0, Inf, FALSE, "log", description = "Hill coefficient"),
                               par_row("Emax", "1", 0, Inf, TRUE, "identity", default = 1, description = "Maximal effect (proxy units)")),
        ode = c("d/dt(Ce) <- ke0 * (Cd - Ce)", "S <- 1 / (1 + (EC50 / (max(Ce, 0) + 1e-300))^hill)", "E <- Emax * S"),
        states = "Ce", effect = "E", stimulus = "S"),
      indirect_response = list(
        id = "P03", name = "Normalized indirect response (inhibition of production)",
        equations = c("dR/dt = kout * (1 - Imax * S(Cd) - R), R(0) = 1", "S = Cd^h / (EC50^h + Cd^h)", "effect = 1 - R"),
        parameters = par_table(par_row("kout", "1/h", 0, Inf, FALSE, "log", description = "First-order loss rate constant of the response variable"),
                               par_row("Imax", "1", 0, 1, TRUE, "logit", description = "Maximal inhibition of production"),
                               par_row("EC50", "mg/L", 0, Inf, FALSE, "log", description = "Driver concentration at half-maximal inhibition"),
                               par_row("hill", "1", 0, Inf, FALSE, "log", description = "Hill coefficient")),
        ode = c("S <- 1 / (1 + (EC50 / (Cd + 1e-300))^hill)", "R(0) <- 1", "d/dt(R) <- kout * (1 - Imax * S - R)", "E <- 1 - R"),
        states = "R", effect = "E", stimulus = "S"),
      binding = list(
        id = "P04", name = "Reversible binding (occupancy proxy, driver concentration unchanged by binding)",
        equations = c("dO/dt = kon * Cd * (1 - O) - koff * O, O(0) = 0", "E = Emax * O"),
        parameters = par_table(par_row("kon", "L/(mg h)", 0, Inf, FALSE, "log", description = "Association rate constant"),
                               par_row("koff", "1/h", 0, Inf, FALSE, "log", description = "Dissociation rate constant"),
                               par_row("Emax", "1", 0, Inf, TRUE, "identity", default = 1, description = "Maximal effect (proxy units)")),
        ode = c("d/dt(O) <- kon * Cd * (1 - O) - koff * O", "E <- Emax * O"), states = "O", effect = "E", stimulus = "O")
    ),
    tox = list(
      toxicity_proxy = list(
        id = "P05", name = "Reversible toxicity proxy (not an adverse-event probability)",
        equations = c("dH/dt = krec * (Hmax * S_tox(Cd) - H), H(0) = 0", "S_tox = Cd^h_tox / (EC50_tox^h_tox + Cd^h_tox)"),
        parameters = par_table(par_row("krec", "1/h", 0, Inf, FALSE, "log", description = "Recovery rate constant of the toxicity proxy"),
                               par_row("Hmax", "1", 0, Inf, FALSE, "identity", default = 1, description = "Maximal proxy value"),
                               par_row("EC50_tox", "mg/L", 0, Inf, FALSE, "log", description = "Driver concentration at half-maximal proxy"),
                               par_row("hill_tox", "1", 0, Inf, FALSE, "log", description = "Hill coefficient of the proxy")),
        ode = c("S_tox <- 1 / (1 + (EC50_tox / (Cd + 1e-300))^hill_tox)", "d/dt(H) <- krec * (Hmax * S_tox - H)"),
        states = "H", effect = "H", stimulus = "S_tox")
    )
  )
}

# Supported (pk, pd, tox) combinations. Anything else is rejected.
supported_combinations <- function() {
  rows <- list()
  add <- function(pk, pd, tox) rows[[length(rows) + 1L]] <<- data.frame(pk = pk, pd = pd, tox = tox, stringsAsFactors = FALSE)
  for (pd in c(NA, "direct_emax", "effect_compartment", "indirect_response", "binding")) for (tox in c(NA, "toxicity_proxy"))
    add("one_compartment", pd, tox)
  for (pd in c("direct_emax", "indirect_response")) for (tox in c(NA, "toxicity_proxy")) add("first_order_input", pd, tox)
  add("first_order_input", NA, NA)
  add("two_compartment", "direct_emax", NA); add("two_compartment", NA, NA)
  add("saturable_elimination", "direct_emax", NA); add("saturable_elimination", NA, NA)
  add("active_species", "direct_emax", NA); add("active_species", NA, NA)
  do.call(rbind, rows)
}

#' List implemented model structures
#'
#' Only structures that are implemented and verified are listed; any other
#' combination is rejected by [pkpd_model()].
#'
#' @return A data frame with one row per PK, PD or toxicity-proxy component:
#'   key, kind, id, name, parameters with units, routes, solver and equations.
#' @examples
#' available_models()
#' @export
available_models <- function() {
  comp <- registry_components()
  rows <- list()
  for (kind in names(comp)) for (nm in names(comp[[kind]])) {
    m <- comp[[kind]][[nm]]
    rows[[length(rows) + 1L]] <- data.frame(
      key = nm, kind = kind, id = m$id, name = m$name,
      parameters = paste0(m$parameters$name, " [", m$parameters$unit, "]", collapse = ", "),
      routes = if (is.null(m$routes)) NA_character_ else paste(m$routes, collapse = ", "),
      solver = if (is.null(m$solver)) NA_character_ else m$solver,
      equations = paste(m$equations, collapse = "; "), stringsAsFactors = FALSE)
  }
  do.call(rbind, rows)
}

#' List supported structure combinations
#'
#' @return A data frame of the (PK, PD, toxicity proxy) combinations that
#'   [pkpd_model()] accepts. `NA` means the component is absent.
#' @examples
#' supported_models()
#' @export
supported_models <- function() {
  sc <- supported_combinations()
  sc$structure_id <- vapply(seq_len(nrow(sc)), function(i) {
    comp <- registry_components()
    paste(c(comp$pk[[sc$pk[i]]]$id, if (!is.na(sc$pd[i])) comp$pd[[sc$pd[i]]]$id, if (!is.na(sc$tox[i])) comp$tox[[sc$tox[i]]]$id), collapse = "x")
  }, character(1))
  sc
}

#' Define a PK/PD model structure
#'
#' Resolves a structure from the registry. Model structures are identified by
#' mechanism, not by drug, target or modality.
#'
#' @param pk Pharmacokinetic structure key; see [available_models()].
#' @param pd Pharmacodynamic structure key, or `NULL` for PK only.
#' @param toxicity Toxicity-proxy structure key (`"toxicity_proxy"`), or `NULL`.
#'   It runs in parallel with the efficacy structure on the same driver.
#' @param driver Concentration that drives the PD and toxicity structures:
#'   `"parent"` or, for the active-species structure, `"active"` (default).
#' @return An object of class `pkpd_model` with the resolved specification,
#'   the combined parameter schema and units.
#' @examples
#' pkpd_model(pk = "one_compartment", pd = "direct_emax")
#' pkpd_model(pk = "first_order_input", pd = "indirect_response", toxicity = "toxicity_proxy")
#' @export
pkpd_model <- function(pk, pd = NULL, toxicity = NULL, driver = NULL) {
  comp <- registry_components()
  if (!is.character(pk) || length(pk) != 1L || !pk %in% names(comp$pk))
    stop(sprintf("Unsupported PK structure `%s`. See available_models().", paste(pk, collapse = ",")), call. = FALSE)
  if (!is.null(pd) && (!is.character(pd) || length(pd) != 1L || !pd %in% names(comp$pd)))
    stop(sprintf("Unsupported PD structure `%s`. See available_models().", paste(pd, collapse = ",")), call. = FALSE)
  if (!is.null(toxicity) && (!is.character(toxicity) || length(toxicity) != 1L || !toxicity %in% names(comp$tox)))
    stop(sprintf("Unsupported toxicity structure `%s`. See available_models().", paste(toxicity, collapse = ",")), call. = FALSE)
  sc <- supported_combinations()
  pdv <- if (is.null(pd)) NA_character_ else pd
  tv <- if (is.null(toxicity)) NA_character_ else toxicity
  ok <- any(sc$pk == pk & (sc$pd == pdv | (is.na(sc$pd) & is.na(pdv))) & (sc$tox == tv | (is.na(sc$tox) & is.na(tv))))
  if (!isTRUE(ok)) stop(sprintf("The combination PK `%s`, PD `%s`, toxicity `%s` is not implemented.", pk,
                                if (is.null(pd)) "none" else pd, if (is.null(toxicity)) "none" else toxicity), call. = FALSE)
  pkm <- comp$pk[[pk]]
  pdm <- if (is.null(pd)) NULL else comp$pd[[pd]]
  tm <- if (is.null(toxicity)) NULL else comp$tox[[toxicity]]
  if (is.null(driver)) driver <- if (!is.null(pkm$default_driver)) pkm$default_driver else "parent"
  if (!driver %in% names(pkm$drivers)) stop(sprintf("`driver` must be one of: %s.", paste(names(pkm$drivers), collapse = ", ")), call. = FALSE)
  par <- rbind(cbind(component = "pk", pkm$parameters), if (!is.null(pdm)) cbind(component = "pd", pdm$parameters),
               if (!is.null(tm)) cbind(component = "tox", tm$parameters))
  rownames(par) <- NULL
  structure(list(pk = pk, pd = pd, toxicity = toxicity, pk_spec = pkm, pd_spec = pdm, tox_spec = tm,
                 parameters = par, routes = pkm$routes, driver = driver,
                 structure_id = paste(c(pkm$id, if (!is.null(pdm)) pdm$id, if (!is.null(tm)) tm$id), collapse = "x")),
            class = "pkpd_model")
}

#' @export
print.pkpd_model <- function(x, ...) {
  cat("<pkpd_model>", x$structure_id, "\n")
  cat("  PK:", x$pk_spec$name, "\n")
  if (!is.null(x$pd_spec)) cat("  PD:", x$pd_spec$name, "(driver:", x$driver, ")\n")
  if (!is.null(x$tox_spec)) cat("  toxicity proxy:", x$tox_spec$name, "\n")
  cat("  parameters:", paste0(x$parameters$name, " [", x$parameters$unit, "]", collapse = ", "), "\n")
  cat("  routes:", paste(x$routes, collapse = ", "), "\n")
  invisible(x)
}

# Validate a named parameter vector against the model schema; fills defaults
# (Emax, Hmax, F, mwr) when they are not supplied.
check_parameters <- function(model, parameters) {
  if (!is.numeric(parameters) || is.null(names(parameters)))
    stop("`parameters` must be a named numeric vector.", call. = FALSE)
  sch <- model$parameters
  for (i in which(!is.na(sch$default))) {
    if (!sch$name[i] %in% names(parameters)) parameters <- c(parameters, stats::setNames(sch$default[i], sch$name[i]))
  }
  miss <- setdiff(sch$name, names(parameters))
  if (length(miss)) stop(sprintf("Missing parameter(s): %s.", paste(miss, collapse = ", ")), call. = FALSE)
  extra <- setdiff(names(parameters), sch$name)
  if (length(extra)) stop(sprintf("Unknown parameter(s): %s.", paste(extra, collapse = ", ")), call. = FALSE)
  p <- parameters[sch$name]
  if (any(!is.finite(p))) stop("Parameters must be finite.", call. = FALSE)
  for (i in seq_len(nrow(sch))) {
    lo <- sch$lower[i]; hi <- sch$upper[i]; inc <- sch$lower_inclusive[i]
    bad <- if (inc) p[i] < lo else p[i] <= lo
    if (bad || p[i] > hi) stop(sprintf("`%s` is outside its valid range (%s%g, %g].", sch$name[i], if (inc) "[" else "(", lo, hi), call. = FALSE)
  }
  p
}
