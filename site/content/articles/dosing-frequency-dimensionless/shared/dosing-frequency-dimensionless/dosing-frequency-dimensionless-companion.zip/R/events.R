#' Define a dosing regimen
#'
#' Builds a validated dose event table. Times are in hours and amounts in
#' mg (the package works in h, L, mg and mg/L unless stated otherwise).
#' Doses are given at `start`, `start + interval`, ..., `n` times.
#'
#' @param amount Dose amount per administration (mg, positive).
#' @param interval Time between administrations (h, positive). Ignored when
#'   `n = 1`.
#' @param n Number of administrations (positive integer).
#' @param route One of `"iv_bolus"`, `"iv_infusion"` or `"oral"`.
#' @param duration Infusion duration (h, positive); required for
#'   `"iv_infusion"`, not allowed otherwise.
#' @param start Time of the first administration (h, non-negative).
#' @param amounts Optional numeric vector of length `n` that overrides
#'   `amount` per administration (loading or step-up dosing).
#' @param id Optional regimen label.
#' @return An object of class `pkpd_regimen`: a list with the event table
#'   `events` (columns `event_id`, `time`, `amount`, `route`, `duration`) and
#'   the arguments used.
#' @examples
#' # 24 mg every 24 h for 14 days, all values synthetic
#' regimen(amount = 24, interval = 24, n = 14, route = "iv_bolus")
#' # 2-h infusions with a loading dose
#' regimen(amounts = c(200, 100, 100), interval = 12, n = 3,
#'         route = "iv_infusion", duration = 2)
#' @export
regimen <- function(amount = NULL, interval = NULL, n = 1L, route = "iv_bolus",
                    duration = NULL, start = 0, amounts = NULL, id = NULL) {
  route <- match.arg(route, c("iv_bolus", "iv_infusion", "oral"))
  n <- as.integer(n)
  if (length(n) != 1L || is.na(n) || n < 1L) stop("`n` must be a positive integer.", call. = FALSE)
  if (is.null(amounts)) {
    if (is.null(amount)) stop("Supply `amount` or `amounts`.", call. = FALSE)
    amounts <- rep(amount, length.out = n)
  } else {
    if (!is.null(amount)) stop("Supply either `amount` or `amounts`, not both.", call. = FALSE)
    if (length(amounts) != n) stop("`amounts` must have length `n`.", call. = FALSE)
  }
  check_positive(amounts, "amount")
  if (n > 1L) {
    if (is.null(interval)) stop("`interval` is required when `n` > 1.", call. = FALSE)
    check_positive(interval, "interval", length1 = TRUE)
  } else if (is.null(interval)) {
    interval <- NA_real_
  }
  if (!is.numeric(start) || length(start) != 1L || !is.finite(start) || start < 0)
    stop("`start` must be a single non-negative number.", call. = FALSE)
  if (route == "iv_infusion") {
    if (is.null(duration)) stop("`duration` is required for route \"iv_infusion\".", call. = FALSE)
    check_positive(duration, "duration", length1 = TRUE)
  } else if (!is.null(duration)) {
    stop("`duration` is only allowed for route \"iv_infusion\".", call. = FALSE)
  } else {
    duration <- NA_real_
  }
  times <- if (n == 1L) start else start + (seq_len(n) - 1L) * interval
  if (route == "iv_infusion" && n > 1L && duration > interval + 1e-12)
    stop("Overlapping infusions: `duration` must not exceed `interval`.", call. = FALSE)
  events <- data.frame(event_id = seq_len(n), time = times, amount = as.numeric(amounts),
                       route = route, duration = as.numeric(duration), stringsAsFactors = FALSE)
  structure(list(events = events, amount = amount, interval = interval, n = n,
                 route = route, duration = duration, start = start,
                 id = if (is.null(id)) NA_character_ else as.character(id)),
            class = "pkpd_regimen")
}

#' @export
print.pkpd_regimen <- function(x, ...) {
  e <- x$events
  cat("<pkpd_regimen>", if (!is.na(x$id)) x$id else "", "\n", sep = " ")
  cat(sprintf("  route: %s; %d administration(s); total dose %.4g mg\n", x$route, nrow(e), sum(e$amount)))
  cat(sprintf("  first at %.4g h, last at %.4g h\n", min(e$time), max(e$time)))
  invisible(x)
}

#' Collect regimens for comparison
#'
#' @param ... `pkpd_regimen` objects (named arguments become the regimen ids).
#' @return An object of class `pkpd_regimen_set`.
#' @examples
#' a <- regimen(amount = 24, interval = 24, n = 14)
#' b <- regimen(amount = 12, interval = 12, n = 28)
#' regimen_set(daily = a, twice_daily = b)
#' @export
regimen_set <- function(...) {
  rs <- list(...)
  if (length(rs) == 0L) stop("Supply at least one regimen.", call. = FALSE)
  if (!all(vapply(rs, inherits, logical(1), "pkpd_regimen")))
    stop("All arguments must be `pkpd_regimen` objects.", call. = FALSE)
  nm <- names(rs)
  if (is.null(nm)) nm <- rep("", length(rs))
  for (i in seq_along(rs)) {
    if (!nzchar(nm[i])) nm[i] <- if (!is.na(rs[[i]]$id)) rs[[i]]$id else paste0("regimen_", i)
  }
  if (anyDuplicated(nm)) stop("Regimen ids must be unique.", call. = FALSE)
  names(rs) <- nm
  structure(list(regimens = rs), class = "pkpd_regimen_set")
}

#' @export
print.pkpd_regimen_set <- function(x, ...) {
  cat("<pkpd_regimen_set>", length(x$regimens), "regimen(s)\n")
  for (nm in names(x$regimens)) {
    e <- x$regimens[[nm]]$events
    cat(sprintf("  %-16s %-12s n = %d, total %.4g mg\n", nm, x$regimens[[nm]]$route, nrow(e), sum(e$amount)))
  }
  invisible(x)
}

# internal helpers -------------------------------------------------------------

check_positive <- function(x, what, length1 = FALSE) {
  if (!is.numeric(x) || any(!is.finite(x)) || any(x <= 0))
    stop(sprintf("`%s` must be positive and finite.", what), call. = FALSE)
  if (length1 && length(x) != 1L) stop(sprintf("`%s` must be a single number.", what), call. = FALSE)
  invisible(TRUE)
}
