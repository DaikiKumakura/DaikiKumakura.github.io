# Time-course mode ---------------------------------------------------------------

# One-compartment concentration after a single oral dose (or IV bolus when route = "iv");
# returns a length(t) x nrow(lib) matrix.
conc_single <- function(t, dose, lib, route) {
  ke <- lib$CL / lib$V
  if (route == "iv") return(exp(-outer(t, ke)) * rep(dose / lib$V, each = length(t)))
  ka <- lib$ka; ka <- ifelse(abs(ka - ke) < 1e-9 * ka, ka * (1 + 1e-6), ka)
  k <- dose * lib$F * ka / (lib$V * (ka - ke))
  (exp(-outer(t, ke)) - exp(-outer(t, ka))) * rep(k, each = length(t))
}

#' Map one subject's concentration-time data onto the virtual library
#'
#' Weights label-free virtual candidates by the log-normal likelihood of a
#' subject's observations (single dose, one-compartment candidates, error
#' `sigma` on the log scale). Observations after `condition_until` can be held
#' out; the returned `predict` function gives the weighted posterior predictive
#' (5%, 50%, 95%) at new times.
#'
#' @param subject One element of `import_timecourse()$subjects` (single dose only).
#' @param library A [pk_library()].
#' @param route `"oral"` or `"iv"`.
#' @param sigma Log-scale residual SD.
#' @param condition_until Time up to which observations are used; `Inf` uses all.
#' @return A list with `status`, `ess`, `weights` and `predict`.
#' @examples
#' lib <- pk_library(2000, seed = 1)
#' d <- data.frame(ID = 1, TIME = c(0, 0.5, 1, 2, 4, 8, 12), AMT = c(100, 0, 0, 0, 0, 0, 0),
#'                 DV = c(0, 1.2, 2.0, 2.4, 1.9, 1.0, 0.5), EVID = c(1, 0, 0, 0, 0, 0, 0))
#' tc <- import_timecourse(d, "ID", "TIME", "DV", "AMT", evid = "EVID")
#' map_subject(tc$subjects[[1]], lib)$ess
#' @export
map_subject <- function(subject, library, route = c("oral", "iv"), sigma = 0.3, condition_until = Inf) {
  route <- match.arg(route)
  ev <- subject$regimen$events
  if (nrow(ev) != 1L) return(list(status = "multiple_doses_not_supported"))
  dose <- ev$amount; t0 <- ev$time
  use <- subject$times <= condition_until
  if (sum(use) < 3L) return(list(status = "insufficient_evidence"))
  C <- conc_single(subject$times[use] - t0, dose, library, route)
  ll <- -0.5 * colSums(((log(pmax(C, 1e-300)) - log(subject$conc[use])) / sigma)^2)
  ll[!is.finite(ll)] <- -Inf
  w <- exp(ll - max(ll)); w <- w / sum(w)
  wq <- function(x, p) { o <- order(x); cw <- cumsum(w[o]); vapply(p, function(pp) x[o][which(cw >= pp)[1]], numeric(1)) }
  pred <- function(times) {
    Cm <- conc_single(times - t0, dose, library, route)
    vapply(seq_along(times), function(i) wq(Cm[i, ], c(0.05, 0.5, 0.95)), numeric(3))
  }
  list(status = "ok", ess = 1 / sum(w^2), weights = w, predict = pred)
}

#' Evaluate time-course mapping with a held-out tail and a baseline
#'
#' For every single-dose subject with at least six observations, the first
#' `condition_frac` of the observations (in time order) condition the mapping and
#' the rest are predicted. The baseline is the geometric mean of the
#' dose-normalized concentrations of the *other* subjects at the nearest
#' observation time (a population profile that does not use the subject's own
#' data). Reported per subject: log-RMSE of the posterior median, log-RMSE of the
#' baseline, and the share of held-out points inside the 90% predictive interval.
#'
#' @param tc Output of [import_timecourse()].
#' @param library A [pk_library()].
#' @param route `"oral"` or `"iv"`.
#' @param condition_frac Fraction of observations used for conditioning.
#' @param sigma Residual SD on the log scale.
#' @return Data frame with one row per evaluated subject.
#' @examples
#' \dontrun{evaluate_timecourse(tc, pk_library(20000))}
#' @export
evaluate_timecourse <- function(tc, library, route = "oral", condition_frac = 0.6, sigma = 0.3) {
  subs <- Filter(function(s) nrow(s$regimen$events) == 1L && length(s$conc) >= 6L, tc$subjects)
  rel <- function(s) s$times - s$regimen$events$time
  base_curve <- function(excl, t) {
    others <- Filter(function(s) !identical(s$id, excl), subs)
    vapply(t, function(tt) {
      v <- vapply(others, function(s) { r <- rel(s); j <- which.min(abs(r - tt)); if (abs(r[j] - tt) < 0.25 * max(tt, 1)) s$conc[j] / s$regimen$events$amount else NA_real_ }, numeric(1))
      v <- v[is.finite(v) & v > 0]; if (length(v)) exp(mean(log(v))) else NA_real_
    }, numeric(1))
  }
  out <- lapply(subs, function(s) {
    o <- order(s$times); s$times <- s$times[o]; s$conc <- s$conc[o]
    n <- length(s$conc); nc <- max(3L, floor(n * condition_frac)); tcut <- s$times[nc]
    m <- map_subject(s, library, route, sigma, condition_until = tcut)
    if (m$status != "ok") return(NULL)
    h <- s$times > tcut; if (!any(h)) return(NULL)
    p <- m$predict(s$times[h]); y <- log(s$conc[h])
    bc <- base_curve(s$id, rel(s)[h]) * s$regimen$events$amount
    ok <- is.finite(bc) & bc > 0
    data.frame(id = s$id, n_obs = n, n_heldout = sum(h), ess = m$ess,
               log_rmse_map = sqrt(mean((log(p[2, ]) - y)^2)), log_rmse_baseline = if (any(ok)) sqrt(mean((log(bc[ok]) - y[ok])^2)) else NA_real_,
               coverage90 = mean(y >= log(p[1, ]) & y <= log(p[3, ])), stringsAsFactors = FALSE)
  })
  do.call(rbind, out)
}
