# Steady-state coordinates in (alpha, beta): cmax = beta / (1 - exp(-alpha)),
# cmin = cmax * exp(-alpha). Vectorised.
ss_coordinates <- function(alpha, beta, e_threshold = 0.5) {
  cmax <- beta / (-expm1(-alpha))
  cmin <- cmax * exp(-alpha)
  odds <- e_threshold / (1 - e_threshold)
  data.frame(cmax = cmax, cmin = cmin,
             mean_effect = (log1p(cmax) - log1p(cmin)) / alpha,
             time_above_threshold = pmin(pmax(log(cmax / odds) / alpha, 0), 1))
}

#' Phase diagram for a change of dosing frequency at equal dose rate
#'
#' For the one-compartment model with a direct Emax response (Hill coefficient 1),
#' compares a regimen with interval `tau` and dose `D` with a regimen that gives
#' the same dose rate in `split` times more frequent administrations
#' (interval `tau / split`, dose `D / split`). Both are evaluated at steady state
#' in closed form on a grid of `alpha = CL * tau / V` and
#' `beta = D / (V * EC50)` (both on a log scale).
#'
#' Because the mean exposure is the same, the direct Emax relation with
#' `hill = 1` is concave in concentration and the more frequent regimen cannot
#' have a lower mean effect (Jensen). The time above an effect threshold can
#' differ in either direction. This function reports both.
#'
#' All coordinates are dimensionless and the grid is a mathematical
#' construction, not a distribution of real drugs.
#'
#' @param alpha_range,beta_range Ranges of `alpha` and `beta` (positive).
#' @param n Number of grid points per axis.
#' @param split Integer >= 2: how many times more frequent the split regimen is.
#' @param e_threshold Effect threshold in (0, 1) as a fraction of `Emax`.
#' @return A data frame of class `pkpd_phase` with the grid and, for the
#'   reference and the split regimen, `mean_effect` and `time_above_threshold`,
#'   plus `d_mean_effect` and `d_time_above_threshold` (split minus reference).
#' @examples
#' ph <- phase_diagram(n = 40)
#' range(ph$d_mean_effect)
#' @export
phase_diagram <- function(alpha_range = c(1e-2, 1e2), beta_range = c(1e-2, 1e2), n = 60L,
                          split = 2L, e_threshold = 0.5) {
  check_positive(alpha_range, "alpha_range"); check_positive(beta_range, "beta_range")
  if (length(alpha_range) != 2L || length(beta_range) != 2L) stop("Ranges must have length 2.", call. = FALSE)
  if (split < 2L || split != round(split)) stop("`split` must be an integer >= 2.", call. = FALSE)
  if (!(e_threshold > 0 && e_threshold < 1)) stop("`e_threshold` must be in (0, 1).", call. = FALSE)
  a <- exp(seq(log(alpha_range[1]), log(alpha_range[2]), length.out = n))
  b <- exp(seq(log(beta_range[1]), log(beta_range[2]), length.out = n))
  g <- expand.grid(alpha = a, beta = b)
  ref <- ss_coordinates(g$alpha, g$beta, e_threshold)
  spl <- ss_coordinates(g$alpha / split, g$beta / split, e_threshold)
  out <- data.frame(g, mean_effect_ref = ref$mean_effect, mean_effect_split = spl$mean_effect,
                    tta_ref = ref$time_above_threshold, tta_split = spl$time_above_threshold)
  out$d_mean_effect <- out$mean_effect_split - out$mean_effect_ref
  out$d_time_above_threshold <- out$tta_split - out$tta_ref
  attr(out, "split") <- split
  attr(out, "e_threshold") <- e_threshold
  class(out) <- c("pkpd_phase", "data.frame")
  out
}

#' Plot a phase diagram
#'
#' Draws the difference in mean steady-state effect or in the fraction of the
#' interval above the effect threshold (split regimen minus reference) on the
#' `alpha`-`beta` plane. Requires the ggplot2 package.
#'
#' @param x A [phase_diagram()] result.
#' @param metric `"d_mean_effect"` or `"d_time_above_threshold"`.
#' @param ... Unused.
#' @return A ggplot object.
#' @export
plot.pkpd_phase <- function(x, metric = c("d_mean_effect", "d_time_above_threshold"), ...) {
  metric <- match.arg(metric)
  if (!requireNamespace("ggplot2", quietly = TRUE)) stop("Package 'ggplot2' is required for plotting.", call. = FALSE)
  lab <- if (metric == "d_mean_effect") "Change in mean effect" else "Change in fraction of interval above threshold"
  df <- as.data.frame(x)
  df$value <- df[[metric]]
  lim <- max(abs(df$value), na.rm = TRUE)
  ggplot2::ggplot(df, ggplot2::aes(x = alpha, y = beta, fill = value)) +
    ggplot2::geom_raster(interpolate = FALSE) +
    ggplot2::scale_x_log10() + ggplot2::scale_y_log10() +
    ggplot2::scale_fill_gradient2(low = "#0072B2", mid = "white", high = "#D55E00", midpoint = 0, limits = c(-lim, lim), name = lab) +
    ggplot2::labs(x = "alpha = CL * tau / V (reference interval)", y = "beta = D / (V * EC50)",
                  caption = sprintf("Closed form, split x%d at equal dose rate. Synthetic dimensionless grid.", attr(x, "split"))) +
    ggplot2::theme_minimal()
}
