#' pkpdspace: Simulation and Exploration of PK/PD Spaces
#'
#' Virtual pharmacokinetic and pharmacodynamic profiles are generated without
#' drug, target or modality labels, compared across dosing regimens in
#' dimensionless coordinates, and empirical evidence can be mapped onto the
#' simulated space. The package is for methodological research and exploratory
#' comparison of dosing strategies. It is not a clinical dosing or regulatory
#' decision tool.
#'
#' Units: time in h, volume in L, amount in mg, concentration in mg/L.
#'
#' @keywords internal
#' @importFrom utils head tail
"_PACKAGE"

utils::globalVariables(c("alpha", "beta", "value"))
