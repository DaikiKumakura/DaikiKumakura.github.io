# Empirical distribution of real-drug dynamics (task T2) -----------------------
#
# Fits a multivariate log-normal to dose-normalized apparent clearance (dose/AUC)
# and terminal half-life of real drugs, with two estimators compared in
# `evaluate_empirical_prior()`: the sample mean/covariance and a shrinkage
# (Ledoit-Wolf-type, towards a scaled identity) covariance. Few drugs, missing
# values, assay and population differences limit what this can claim; the theoretical
# design distribution is kept separate.

#' Per-drug table of log apparent clearance and log half-life
#'
#' Collapses eligible rows (oral or intravenous, single dose, absolute dose, AUC
#' to infinity) to one geometric-mean value per drug.
#'
#' @param evidence A `pkpd_evidence` object.
#' @param route `"Oral"` or `"Intravenous"`.
#' @return Data frame with `drug_id`, `log_cl_f` (log of dose/AUC, L/h; apparent after oral dosing), `log_thalf` (log h) and `n_rows`.
#' @examples
#' \dontrun{drug_pk_table(import_frdb("path/to/frdb"), "Oral")}
#' @export
drug_pk_table <- function(evidence, route = c("Oral", "Intravenous")) {
  route <- match.arg(route)
  s <- evidence$summaries
  s <- s[s$route == route & s$schedule == "SINGLE" & s$dose_basis == "absolute" & s$dose_mg > 0 & s$auc_type %in% "\u221e", ]
  s <- s[is.finite(s$auc_mg_h_per_l) & s$auc_mg_h_per_l > 0 & is.finite(s$thalf_h) & s$thalf_h > 0, ]
  if (!nrow(s)) return(data.frame(drug_id = character(), log_cl_f = numeric(), log_thalf = numeric(), n_rows = integer()))
  s$lcl <- log(s$dose_mg / s$auc_mg_h_per_l); s$lt <- log(s$thalf_h)
  a <- stats::aggregate(cbind(log_cl_f = lcl, log_thalf = lt) ~ drug_id, data = s, FUN = mean)
  a$n_rows <- as.integer(table(s$drug_id)[a$drug_id])
  a
}

#' Fit a bivariate log-normal prior over drugs
#'
#' @param x Data frame from [drug_pk_table()] (or any numeric columns).
#' @param cols Columns to model.
#' @param shrink `0` for the sample covariance, `"lw"` for a Ledoit-Wolf-type
#'   shrinkage towards `mean(diag) * I`, or a number in `[0, 1]`.
#' @return A `pkpd_prior` with `mean`, `cov`, `shrink`, `n`.
#' @examples
#' set.seed(1); d <- data.frame(a = rnorm(30), b = rnorm(30))
#' fit_empirical_prior(d, c("a", "b"))
#' @export
fit_empirical_prior <- function(x, cols = c("log_cl_f", "log_thalf"), shrink = "lw") {
  M <- as.matrix(x[, cols]); n <- nrow(M)
  if (n < 5L) stop("At least 5 drugs are needed.", call. = FALSE)
  mu <- colMeans(M); S <- stats::cov(M)
  if (identical(shrink, "lw")) {
    Xc <- sweep(M, 2, mu); target <- mean(diag(S)) * diag(ncol(M))
    b2 <- sum(vapply(seq_len(n), function(i) sum((tcrossprod(Xc[i, ]) - S)^2), numeric(1))) / n^2
    d2 <- sum((S - target)^2); shrink <- if (d2 > 0) min(1, b2 / d2) else 1
  }
  structure(list(mean = mu, cov = (1 - shrink) * S + shrink * mean(diag(S)) * diag(ncol(M)), shrink = shrink, n = n, cols = cols), class = "pkpd_prior")
}

#' Held-out log predictive density of empirical-prior estimators
#'
#' Repeated K-fold at the drug level: the prior is fitted on the training drugs
#' only and scored by the mean log density of the held-out drugs. Compared with
#' independent univariate normals (no correlation), the sample covariance and
#' the shrinkage covariance.
#'
#' @param x Data frame from [drug_pk_table()].
#' @param cols Columns to model.
#' @param k Folds.
#' @param reps Repeats.
#' @param seed Seed.
#' @return Data frame with the mean held-out log density per estimator and its standard error over folds.
#' @examples
#' set.seed(1); d <- data.frame(a = rnorm(60)); d$b <- d$a + rnorm(60)
#' evaluate_empirical_prior(d, c("a", "b"), reps = 2)
#' @export
evaluate_empirical_prior <- function(x, cols = c("log_cl_f", "log_thalf"), k = 5L, reps = 5L, seed = 1L) {
  ld <- function(Y, mu, S) { Si <- solve(S); d <- ncol(Y); apply(Y, 1, function(r) -0.5 * (d * log(2 * pi) + as.numeric(determinant(S)$modulus) + sum((r - mu) %*% Si * (r - mu)))) }
  set.seed(seed); n <- nrow(x); res <- list()
  for (r in seq_len(reps)) {
    f <- sample(rep(seq_len(k), length.out = n))
    for (i in seq_len(k)) {
      tr <- x[f != i, ]; te <- as.matrix(x[f == i, cols])
      mu <- colMeans(as.matrix(tr[, cols])); S <- stats::cov(as.matrix(tr[, cols]))
      p <- fit_empirical_prior(tr, cols, "lw")
      res[[length(res) + 1L]] <- rbind(
        data.frame(estimator = "independent_normals", lpd = mean(ld(te, mu, diag(diag(S))))),
        data.frame(estimator = "sample_covariance", lpd = mean(ld(te, mu, S))),
        data.frame(estimator = "shrinkage_covariance", lpd = mean(ld(te, p$mean, p$cov))))
    }
  }
  a <- do.call(rbind, res)
  out <- do.call(rbind, lapply(split(a, a$estimator), function(d) data.frame(estimator = d$estimator[1], mean_lpd = mean(d$lpd), se = stats::sd(d$lpd) / sqrt(nrow(d)), folds = nrow(d))))
  rownames(out) <- NULL; out
}
