# Real-drug mapping -------------------------------------------------------------
#
# Summary mode: a label-free library of virtual one-compartment PK parameter sets
# (CL, V, ka, F; log-uniform, no drug information) is weighted by how well its
# single-dose summaries (AUC/dose, Cmax/dose, terminal half-life) match the
# measured summaries of one real drug. The real drug never enters the library;
# it only receives weights afterwards ("simulate first, annotate later").
#
# Identifiability notes (not assumptions that remove them):
#  * after oral dosing, CL and F enter only as CL/F, V and F only as V/F;
#    the posterior for F is then essentially the prior and `not_identifiable` is set.
#  * the terminal half-life after oral dosing is ln2/min(ka, ke): flip-flop is
#    reported as the posterior mass with ka < ke.

#' Virtual one-compartment PK library
#'
#' Draws label-free virtual PK parameter sets (log-uniform `CL`, `V`, `ka`,
#' logit-uniform `F`) with a randomly shifted Sobol (or pseudo-random) design.
#' Used by [map_drug()].
#'
#' @param n Number of candidates.
#' @param ranges Named list of `c(lower, upper)` for `CL` (L/h), `V` (L), `ka` (1/h), `F` (fraction).
#' @param seed Integer seed.
#' @return A data frame with columns `CL`, `V`, `ka`, `F`.
#' @examples
#' head(pk_library(8, seed = 1))
#' @export
pk_library <- function(n = 20000L, ranges = list(CL = c(1e-2, 1e3), V = c(1e-1, 1e4), ka = c(1e-2, 1e2), F = c(0.05, 1)), seed = 1L) {
  u <- unit_design(n, 4L, seed, "sobol")$u
  lg <- function(r, x) exp(log(r[1]) + x * (log(r[2]) - log(r[1])))
  F <- { lo <- stats::qlogis(ranges$F[1]); hi <- stats::qlogis(min(ranges$F[2], 1 - 1e-6)); stats::plogis(lo + u[, 4] * (hi - lo)) }
  data.frame(CL = lg(ranges$CL, u[, 1]), V = lg(ranges$V, u[, 2]), ka = lg(ranges$ka, u[, 3]), F = F)
}

# Single-dose summaries per unit dose (mg/L per mg, mg h/L per mg, h) for a one-compartment model.
pk_summaries <- function(lib, route) {
  ke <- lib$CL / lib$V
  if (route == "iv") return(data.frame(auc_per_dose = 1 / lib$CL, cmax_per_dose = NA_real_, thalf = log(2) / ke))
  ka <- lib$ka; same <- abs(ka - ke) < 1e-9 * ka
  ka2 <- ifelse(same, ka * (1 + 1e-6), ka)
  tmax <- log(ka2 / ke) / (ka2 - ke)
  cmax <- lib$F / lib$V * ka2 / (ka2 - ke) * (exp(-ke * tmax) - exp(-ka2 * tmax))
  data.frame(auc_per_dose = lib$F / lib$CL, cmax_per_dose = cmax, thalf = log(2) / pmin(ka2, ke))
}

# Per-drug summary evidence: geometric mean of dose-normalized quantities over eligible rows.
drug_summary_evidence <- function(rows, route) {
  ok <- rows$dose_basis == "absolute" & rows$schedule == "SINGLE" & rows$dose_mg > 0
  r <- rows[ok & rows$route == route, , drop = FALSE]
  q <- function(v, normalize) { v <- if (normalize) v / r$dose_mg else v; v <- v[is.finite(v) & v > 0]; list(n = length(v), gm = if (length(v)) exp(mean(log(v))) else NA_real_, sd = if (length(v) > 1L) stats::sd(log(v)) else NA_real_) }
  auc_ok <- r$auc_type %in% "\u221e"
  list(rows = nrow(r), route = route,
       auc = { x <- r[auc_ok, ]; z <- x$auc_mg_h_per_l / x$dose_mg; z <- z[is.finite(z) & z > 0]; list(n = length(z), gm = if (length(z)) exp(mean(log(z))) else NA_real_, sd = if (length(z) > 1L) stats::sd(log(z)) else NA_real_) },
       cmax = if (route == "Oral") q(r$cmax_mg_per_l, TRUE) else list(n = 0L, gm = NA_real_, sd = NA_real_),
       thalf = q(r$thalf_h, FALSE))
}

#' Map one real drug onto the virtual PK library (summary mode)
#'
#' Weights virtual candidates by agreement of their single-dose summaries with
#' the measured summaries of one drug. Observation error on the log scale is
#' `sqrt(floor^2 + between-row sd^2)`. The result reports posterior quantiles,
#' the effective sample size, the best-matching discrepancy (support
#' diagnostic), flip-flop mass and abstention flags.
#'
#' Only eligible rows are used: single dose, absolute dose in mg, route
#' `Oral` or `Intravenous`, AUC type infinity. Doses in mg/kg or mg/m2 are not
#' converted. The drug is dropped (status `insufficient_evidence`) when fewer
#' than two summary quantities are available; `out_of_support` is set when
#' the best candidate is further than `support_z` standard errors from the data
#' (the library cannot represent it); `not_identifiable` when the 90% interval
#' of CL (after oral dosing the apparent CL/F, since F is not identifiable from
#' oral data alone) spans more than a factor of `ident_ratio`.
#'
#' @param evidence A `pkpd_evidence` object ([import_frdb()]).
#' @param drug_id Drug identifier in `evidence$summaries$drug_id`.
#' @param route `"Oral"` or `"Intravenous"`.
#' @param library Output of [pk_library()].
#' @param floor Observation-error floor on the log scale.
#' @param support_z Support threshold (in observation SD units, for the root of the summed squared standardized residuals).
#' @param ident_ratio Identifiability threshold for the 5%-95% CL ratio.
#' @param min_ess Minimum effective sample size; below it the status is `low_effective_sample_size`.
#' @param hold_out Optional quantity (`"auc"`, `"cmax"` or `"thalf"`) excluded from the weights; the posterior predictive of it is returned for evaluation.
#' @return A list of class `pkpd_mapping`.
#' @examples
#' \dontrun{
#' ev <- import_frdb("path/to/frdb")
#' map_drug(ev, "frdb-1", "Oral", pk_library(20000))
#' }
#' @export
map_drug <- function(evidence, drug_id, route = c("Oral", "Intravenous"), library = pk_library(), floor = 0.25, support_z = 3, ident_ratio = 10, min_ess = 30, hold_out = NULL) {
  route <- match.arg(route)
  rows <- evidence$summaries[evidence$summaries$drug_id == drug_id, , drop = FALSE]
  if (!nrow(rows)) stop(sprintf("Unknown drug_id `%s`.", drug_id), call. = FALSE)
  ev <- drug_summary_evidence(rows, route)
  obs <- list(auc = c(ev$auc$gm, ev$auc$sd, ev$auc$n, "auc_per_dose"), cmax = c(ev$cmax$gm, ev$cmax$sd, ev$cmax$n, "cmax_per_dose"), thalf = c(ev$thalf$gm, ev$thalf$sd, ev$thalf$n, "thalf"))
  used <- names(obs)[vapply(obs, function(o) is.finite(as.numeric(o[1])), logical(1))]
  if (!is.null(hold_out)) used <- setdiff(used, hold_out)
  base <- list(drug_id = drug_id, route = route, n_rows = ev$rows, quantities_used = used, evidence = ev)
  if (length(used) < 2L) return(structure(c(base, list(status = "insufficient_evidence")), class = "pkpd_mapping"))
  pr <- attr(library, "summaries")[[route]]
  if (is.null(pr)) pr <- pk_summaries(library, if (route == "Oral") "oral" else "iv")
  z2 <- 0; nq <- 0
  for (q in used) {
    o <- obs[[q]]; sdq <- sqrt(floor^2 + (if (is.finite(as.numeric(o[2]))) as.numeric(o[2])^2 else 0))
    r <- (log(pr[[o[4]]]) - log(as.numeric(o[1]))) / sdq
    z2 <- z2 + r^2; nq <- nq + 1L
  }
  ll <- -0.5 * z2; ll[!is.finite(ll)] <- -Inf
  w <- exp(ll - max(ll)); w <- w / sum(w)
  ess <- 1 / sum(w^2)
  wq <- function(x, p) { o <- order(x); cw <- cumsum(w[o]); vapply(p, function(pp) x[o][which(cw >= pp)[1]], numeric(1)) }
  # After oral dosing only the apparent quantities CL/F and V/F are identifiable.
  lib2 <- library
  if (route == "Oral") { lib2$CL <- library$CL / library$F; lib2$V <- library$V / library$F }
  par_q <- lapply(c(CL = "CL", V = "V", ka = "ka", F = "F"), function(nm) wq(lib2[[nm]], c(0.05, 0.5, 0.95)))
  if (route == "Intravenous") par_q <- par_q[c("CL", "V")]
  names(par_q)[names(par_q) == "CL"] <- if (route == "Oral") "CL_F" else "CL"
  names(par_q)[names(par_q) == "V"] <- if (route == "Oral") "V_F" else "V"
  ke <- library$CL / library$V
  flip <- if (route == "Oral") sum(w[library$ka < ke]) else NA_real_
  best <- sqrt(min(z2))
  pred <- lapply(c(auc = "auc_per_dose", cmax = "cmax_per_dose", thalf = "thalf"), function(nm) if (all(is.na(pr[[nm]]))) rep(NA_real_, 3) else wq(pr[[nm]], c(0.05, 0.5, 0.95)))
  cl <- if (route == "Oral") par_q$CL_F else par_q$CL
  cl_ratio <- cl[3] / cl[1]
  status <- if (best > support_z) "out_of_support" else if (ess < min_ess) "low_effective_sample_size" else if (cl_ratio > ident_ratio) "not_identifiable" else "ok"
  structure(c(base, list(status = status, ess = ess, best_standardized_residual = best, flip_flop_mass = flip,
                          parameters = par_q, predicted = pred, cl_ratio_90 = cl_ratio, n_library = nrow(library))), class = "pkpd_mapping")
}

#' @export
print.pkpd_mapping <- function(x, ...) {
  cat("<pkpd_mapping>", x$drug_id, x$route, "-", x$status, "\n")
  if (!is.null(x$ess)) cat(sprintf("  ESS %.0f of %d; best residual %.2f; CL 5-50-95%%: %s; flip-flop mass %s\n", x$ess, x$n_library,
                                    x$best_standardized_residual, paste(signif(if (x$route == "Oral") x$parameters$CL_F else x$parameters$CL, 3), collapse = " / "), format(x$flip_flop_mass, digits = 2)))
  invisible(x)
}

#' Map many drugs and tabulate the result
#'
#' Calls [map_drug()] for every drug with at least two eligible summary
#' quantities for the given route and returns one row per drug, including the
#' abstentions.
#'
#' @param evidence A `pkpd_evidence` object.
#' @param route `"Oral"` or `"Intravenous"`.
#' @param drug_ids Optional vector of drug ids; default all eligible.
#' @param library Library from [pk_library()].
#' @param ... Passed to [map_drug()].
#' @return A data frame with one row per drug. After oral dosing `CL_*` and `V_p50` are apparent (CL/F, V/F).
#' @examples
#' \dontrun{map_drugs(import_frdb("path/to/frdb"), "Oral")}
#' @export
map_drugs <- function(evidence, route = c("Oral", "Intravenous"), drug_ids = NULL, library = pk_library(), ...) {
  route <- match.arg(route)
  s <- evidence$summaries
  attr(library, "summaries") <- stats::setNames(list(pk_summaries(library, if (route == "Oral") "oral" else "iv")), route)
  ids <- if (is.null(drug_ids)) unique(s$drug_id) else drug_ids
  pp <- function(m, i, what = "CL") {
    if (is.null(m$parameters)) return(NA_real_)
    nm <- if (route == "Oral") paste0(what, "_F") else what
    m$parameters[[nm]][i]
  }
  out <- lapply(ids, function(id) {
    m <- map_drug(evidence, id, route, library, ...)
    data.frame(drug_id = id, drug_name = s$drug_name[match(id, s$drug_id)], route = route, status = m$status, n_rows = m$n_rows,
               quantities = paste(m$quantities_used, collapse = "+"), ess = if (is.null(m$ess)) NA_real_ else m$ess,
               best_residual = if (is.null(m$best_standardized_residual)) NA_real_ else m$best_standardized_residual,
               CL_p05 = pp(m, 1), CL_p50 = pp(m, 2), CL_p95 = pp(m, 3), V_p50 = pp(m, 2, "V"), flip_flop_mass = if (is.null(m$flip_flop_mass)) NA_real_ else m$flip_flop_mass,
               stringsAsFactors = FALSE)
  })
  do.call(rbind, out)
}

#' Annotate mapped virtual drugs with labels afterwards
#'
#' Attaches names and identifiers from the evidence table to a mapping result.
#' Labels are added only after mapping and are never used as model input.
#'
#' @param mapping Output of [map_drugs()].
#' @param evidence A `pkpd_evidence` object.
#' @return `mapping` with `unii` and `source_uris` (first three) columns added.
#' @examples
#' \dontrun{annotate_drugs(map_drugs(ev, "Oral"), ev)}
#' @export
annotate_drugs <- function(mapping, evidence) {
  s <- evidence$summaries
  mapping$unii <- s$unii[match(mapping$drug_id, s$drug_id)]
  mapping$source_uris <- vapply(mapping$drug_id, function(id) paste(utils::head(unique(s$source_uri[s$drug_id == id & !is.na(s$source_uri)]), 3), collapse = " | "), character(1))
  mapping
}
