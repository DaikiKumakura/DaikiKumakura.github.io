#' Compare regimens across virtual drugs
#'
#' Summarizes, for every virtual drug, how regimens differ on a feature
#' (pairwise differences against a reference regimen) and which regimens are
#' not dominated on a set of objectives (Pareto set). The output is a
#' scenario comparison for hypothesis prioritization, not a dosing
#' recommendation; no utility function is applied.
#'
#' With `criterion = "equal_total_dose"` the regimens must deliver the same
#' total dose over their course (for courses of equal length this is equal
#' dose rate); otherwise the function stops. Drugs for which a regimen failed
#' or an objective is missing are reported as not comparable and are never
#' filled with zeros.
#'
#' @param x A [simulate_space()] result.
#' @param reference Regimen id used as the reference (default: first).
#' @param criterion `"equal_total_dose"` (checked) or `"none"`.
#' @param metrics Feature names for the pairwise differences.
#' @param objectives Named character vector, feature -> `"max"` or `"min"`,
#'   for the Pareto set; default `mean_effect = "max"` and, if present,
#'   `tox_max = "min"`.
#' @param tol Differences with an absolute value at most `tol` count as ties.
#' @return A list of class `pkpd_comparison` with `pairwise` (per drug, regimen
#'   and metric: difference to the reference), `summary` (shares of drugs where the
#'   regimen is higher/lower/tied, medians and quantiles), `pareto` (per drug and
#'   regimen) and `comparable` (counts).
#' @examples
#' \dontrun{
#' compare_regimens(res, metrics = c("mean_effect", "time_above"))
#' }
#' @export
compare_regimens <- function(x, reference = NULL, criterion = c("equal_total_dose", "none"),
                             metrics = c("mean_effect", "time_above", "cavg", "cmax"), objectives = NULL, tol = 1e-9) {
  criterion <- match.arg(criterion)
  if (!inherits(x, "pkpd_results")) stop("`x` must be a simulate_space() result.", call. = FALSE)
  d <- as.data.frame(x)
  regs <- unique(d$regimen_id)
  if (length(regs) < 2L) stop("At least two regimens are needed.", call. = FALSE)
  if (is.null(reference)) reference <- regs[1]
  if (!reference %in% regs) stop("Unknown reference regimen.", call. = FALSE)
  if (criterion == "equal_total_dose") {
    td <- tapply(d$total_dose, d$regimen_id, function(v) unique(v[!is.na(v)]))
    td <- unlist(td)
    if (max(td) - min(td) > 1e-9 * max(td)) stop("Regimens do not have equal total dose; use criterion = \"none\" to compare them anyway.", call. = FALSE)
  }
  metrics <- intersect(metrics, names(d))
  ref <- d[d$regimen_id == reference, ]
  rows <- list()
  for (r in setdiff(regs, reference)) {
    cur <- d[d$regimen_id == r, ]
    m <- merge(ref[, c("virtual_id", "status", metrics)], cur[, c("virtual_id", "status", metrics)], by = "virtual_id", suffixes = c(".ref", ".cur"))
    for (mt in metrics) {
      a <- m[[paste0(mt, ".ref")]]; b <- m[[paste0(mt, ".cur")]]
      okc <- m$status.ref == "ok" & m$status.cur == "ok" & is.finite(a) & is.finite(b)
      rows[[length(rows) + 1L]] <- data.frame(virtual_id = m$virtual_id, regimen_id = r, reference = reference, metric = mt,
                                              reference_value = a, value = b, difference = ifelse(okc, b - a, NA_real_), comparable = okc, stringsAsFactors = FALSE)
    }
  }
  pw <- do.call(rbind, rows)
  sm <- do.call(rbind, lapply(split(pw, list(pw$regimen_id, pw$metric), drop = TRUE), function(g) {
    v <- g$difference[g$comparable]
    data.frame(regimen_id = g$regimen_id[1], metric = g$metric[1], n_comparable = length(v), n_not_comparable = sum(!g$comparable),
               share_higher = mean(v > tol), share_lower = mean(v < -tol), share_tied = mean(abs(v) <= tol),
               median_difference = stats::median(v), q05 = unname(stats::quantile(v, 0.05)), q95 = unname(stats::quantile(v, 0.95)), stringsAsFactors = FALSE)
  }))
  rownames(sm) <- NULL
  if (is.null(objectives)) objectives <- c(mean_effect = "max", if (!all(is.na(d$tox_max))) c(tox_max = "min"))
  objectives <- objectives[names(objectives) %in% names(d)]
  par <- pareto_flags(d, objectives, tol)
  structure(list(pairwise = pw, summary = sm, pareto = par, objectives = objectives, reference = reference, criterion = criterion,
                 comparable = table(pw$metric, pw$comparable)), class = "pkpd_comparison")
}

#' @export
print.pkpd_comparison <- function(x, ...) {
  cat("<pkpd_comparison> reference:", x$reference, "| criterion:", x$criterion, "\n")
  print(x$summary, digits = 3, row.names = FALSE)
  cat("Pareto objectives:", paste0(names(x$objectives), " (", x$objectives, ")", collapse = ", "), "\n")
  invisible(x)
}

# Non-dominated regimens per drug (NA objectives -> not comparable, flag NA).
pareto_flags <- function(d, objectives, tol) {
  ids <- unique(d$virtual_id)
  out <- vector("list", length(ids))
  sp <- split(d, d$virtual_id)
  for (i in seq_along(sp)) {
    g <- sp[[i]]
    M <- as.matrix(g[, names(objectives), drop = FALSE])
    for (j in seq_along(objectives)) if (objectives[j] == "min") M[, j] <- -M[, j]
    comparable <- g$status == "ok" & stats::complete.cases(M)
    nd <- rep(NA, nrow(g))
    idx <- which(comparable)
    for (a in idx) {
      dominated <- FALSE
      for (b in idx) if (a != b && all(M[b, ] >= M[a, ] - tol) && any(M[b, ] > M[a, ] + tol)) { dominated <- TRUE; break }
      nd[a] <- !dominated
    }
    out[[i]] <- data.frame(virtual_id = g$virtual_id, regimen_id = g$regimen_id, non_dominated = nd, stringsAsFactors = FALSE)
  }
  do.call(rbind, out)
}
