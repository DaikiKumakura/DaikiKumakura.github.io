# Learned approximation of simulated features (task T1) ------------------------
#
# A surrogate maps the parameters of one structure to one feature of one
# standardized regimen. It is optional: the closed-form or ODE simulation remains
# the reference, and `predict()` returns NA with `in_domain = FALSE` outside the
# training box so that callers fall back to simulation.

design_matrix <- function(theta, cols, positive) {
  m <- as.matrix(theta[, cols, drop = FALSE])
  for (j in seq_along(cols)) if (positive[j]) m[, j] <- log(m[, j])
  m
}

#' Fit a surrogate for one simulated feature
#'
#' @param theta Data frame of model parameters (one row per virtual drug).
#' @param y Numeric response, same length (the feature on the scale to be learned, e.g. `log(cmax)`).
#' @param method `"linear"` (interpretable baseline: linear in log-parameters, with
#'   squares and pairwise products) or `"boost"` (gradient-boosted trees, needs xgboost).
#' @param seed Seed.
#' @param nrounds,max_depth,eta Boosting settings (`"boost"` only); fixed before evaluation, not tuned on test data.
#' @param fallback Text recorded in the object: what to do outside the domain.
#' @return A `pkpd_surrogate`: the fitted model, the training domain (min/max per
#'   parameter), training size, seed, a hash of the training data, package version and fallback.
#' @examples
#' set.seed(1); th <- data.frame(CL = exp(runif(300)), V = exp(runif(300)))
#' s <- fit_surrogate(th, log(th$CL) - log(th$V), "linear")
#' head(predict(s, th)$fit)
#' @export
fit_surrogate <- function(theta, y, method = c("linear", "boost"), seed = 1L, nrounds = 300L, max_depth = 4L, eta = 0.1,
                          fallback = "simulate_profile()/simulate_space()") {
  method <- match.arg(method)
  theta <- as.data.frame(theta)
  cols <- names(theta)[vapply(theta, function(v) length(unique(v)) > 1L, logical(1))]
  positive <- vapply(cols, function(cn) all(theta[[cn]] > 0) && max(theta[[cn]]) / min(theta[[cn]]) > 5, logical(1))
  X <- design_matrix(theta, cols, positive)
  ok <- is.finite(y) & apply(X, 1, function(r) all(is.finite(r)))
  X <- X[ok, , drop = FALSE]; y <- y[ok]
  mu <- colMeans(X); sdv <- apply(X, 2, stats::sd); Z <- scale(X, mu, sdv)
  set.seed(seed)
  fit <- if (method == "linear") {
    D <- as.data.frame(Z); form <- stats::as.formula(paste("y ~ (.)^2 +", paste0("I(", names(D), "^2)", collapse = " + ")))
    D$y <- y; stats::lm(form, data = D)
  } else {
    if (!requireNamespace("xgboost", quietly = TRUE)) stop("Package 'xgboost' is required for method = \"boost\".", call. = FALSE)
    xgboost::xgb.train(params = list(objective = "reg:squarederror", max_depth = max_depth, eta = eta, nthread = 1, seed = seed),
                       data = xgboost::xgb.DMatrix(Z, label = y), nrounds = nrounds, verbose = 0)
  }
  structure(list(method = method, fit = fit, cols = cols, positive = unname(positive), mu = mu, sd = sdv, domain = rbind(min = apply(X, 2, min), max = apply(X, 2, max)),
                 n_train = length(y), seed = seed, train_hash = unname(tools::md5sum(write_hash_file(cbind(X, y)))), package_version = as.character(utils::packageVersion("pkpdspace")),
                 fallback = fallback), class = "pkpd_surrogate")
}

write_hash_file <- function(m) { f <- tempfile(); on.exit(NULL); saveRDS(round(m, 10), f, version = 2, compress = FALSE); f }

#' Predict with a surrogate
#'
#' @param object A [fit_surrogate()] result.
#' @param newdata Data frame of parameters.
#' @param ... Unused.
#' @return A list: `fit` (NA outside the training box) and `in_domain` (logical).
#' @export
predict.pkpd_surrogate <- function(object, newdata, ...) {
  X <- design_matrix(as.data.frame(newdata), object$cols, object$positive)
  inside <- unname(apply(X, 1, function(r) all(is.finite(r))) & colSums(t(X) >= object$domain["min", ] - 1e-9 & t(X) <= object$domain["max", ] + 1e-9) == ncol(X))
  Z <- scale(X, object$mu, object$sd)
  p <- if (object$method == "linear") as.numeric(stats::predict(object$fit, newdata = as.data.frame(Z))) else as.numeric(stats::predict(object$fit, xgboost::xgb.DMatrix(Z)))
  p[!inside] <- NA_real_
  list(fit = p, in_domain = inside)
}

#' @export
print.pkpd_surrogate <- function(x, ...) {
  cat("<pkpd_surrogate>", x$method, "- trained on", x$n_train, "points, seed", x$seed, "\nparameters:", paste(x$cols, collapse = ", "), "\nfallback:", x$fallback, "\n")
  invisible(x)
}
