# ODE engine (rxode2) ---------------------------------------------------------
#
# One rxode2 model is compiled per structure and cached. Many parameter sets are
# solved in one call (one row per parameter set). The closed-form engine in
# simulate.R is used as the reference for K01 x P01.

.pkpd_cache <- new.env(parent = emptyenv())

rx_name <- function(x) ifelse(x == "F", "Fbio", x)

rx_model_text <- function(model) {
  driver <- model$pk_spec$drivers[[model$driver]]
  c(model$pk_spec$ode, paste0("Cd <- max(", driver, ", 0)"),
    if (!is.null(model$pd_spec)) model$pd_spec$ode,
    if (!is.null(model$tox_spec)) model$tox_spec$ode)
}

rx_compiled <- function(model) {
  if (!requireNamespace("rxode2", quietly = TRUE))
    stop("The ODE engine needs the 'rxode2' package.", call. = FALSE)
  key <- paste(model$structure_id, model$driver, sep = "|")
  if (is.null(.pkpd_cache[[key]])) {
    suppressMessages(.pkpd_cache[[key]] <- rxode2::rxode2(paste(rx_model_text(model), collapse = "\n")))
  }
  .pkpd_cache[[key]]
}

# Event table for rxode2 from a regimen and sampling times.
rx_events <- function(model, regimen, times) {
  ev <- rxode2::et(times)
  e <- regimen$events
  for (i in seq_len(nrow(e))) {
    cmt <- model$pk_spec$dose_cmt[[e$route[i]]]
    ev <- if (e$route[i] == "iv_infusion") rxode2::add.dosing(ev, dose = e$amount[i], start.time = e$time[i], dur = e$duration[i], cmt = cmt)
          else rxode2::add.dosing(ev, dose = e$amount[i], start.time = e$time[i], cmt = cmt)
  }
  ev
}

# Solve many parameter sets (rows of a data frame) for one regimen.
# Returns a list of matrices (ntime x nset) for the requested outputs.
solve_ode <- function(model, params, regimen, times, outputs = NULL, atol = 1e-10, rtol = 1e-8) {
  if (!all(regimen$events$route %in% model$routes))
    stop(sprintf("Route(s) %s are not supported by this model.", paste(setdiff(unique(regimen$events$route), model$routes), collapse = ", ")), call. = FALSE)
  m <- rx_compiled(model)
  p <- as.data.frame(params)
  names(p) <- rx_name(names(p))
  ev <- rx_events(model, regimen, times)
  s <- suppressMessages(rxode2::rxSolve(m, p, ev, atol = atol, rtol = rtol, returnType = "data.frame"))
  nt <- length(unique(times)); ns <- nrow(p)
  if (!"sim.id" %in% names(s)) s$sim.id <- 1L
  s <- s[order(s$sim.id, s$time), ]
  if (nrow(s) != nt * ns) stop("Unexpected solver output size.", call. = FALSE)
  if (is.null(outputs)) outputs <- setdiff(names(s), c("sim.id", "time"))
  res <- lapply(outputs, function(v) matrix(s[[v]], nrow = nt, ncol = ns))
  names(res) <- outputs
  res$time <- sort(unique(times))
  res
}
