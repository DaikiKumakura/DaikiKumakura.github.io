#' Simulate one scenario
#'
#' Computes the amount in the central compartment, the concentration and, if
#' the model has a PD or toxicity-proxy structure, the stimulus, effect and
#' proxy for one parameter set and one regimen.
#'
#' Two engines are available. `"analytic"` solves linear one-compartment
#' kinetics with a direct Emax response in closed form by superposition of the
#' dose events. `"ode"` solves any registered structure with `rxode2` (LSODA).
#' `"auto"` (default) uses the closed form where it exists. The two are
#' cross-checked in the test suite.
#'
#' Dose events are applied at their time and included in the profile at that
#' time (a bolus at `t0` contributes to the value reported at `t0`, so the
#' profile at a dosing time is the post-dose value). An infusion starting at
#' `t0` contributes from `t0` on. Initial states are zero except for the
#' normalized response `R(0) = 1` of the indirect-response structure.
#'
#' @param model A [pkpd_model()].
#' @param parameters Named numeric vector (units: see [available_models()]).
#'   Optional parameters (`Emax`, `Hmax`, `F`, `mwr`) default to 1.
#' @param regimen A [regimen()].
#' @param times Observation times (h, non-negative, finite).
#' @param engine `"auto"`, `"analytic"` or `"ode"`.
#' @return A data frame with `time`, `amount` (mg, central or parent),
#'   `concentration` (mg/L) and, where the structure has them, `active_concentration`,
#'   `stimulus`, `effect` and `toxicity`. The attribute `status` is `"ok"`; a failed
#'   or non-physical solution is an error, not a clipped result.
#' @examples
#' m <- pkpd_model("one_compartment", "direct_emax")
#' r <- regimen(amount = 24, interval = 24, n = 3)
#' simulate_profile(m, c(CL = 2, V = 20, EC50 = 0.5, hill = 1), r, times = 0:72)[1:5, ]
#' @export
simulate_profile <- function(model, parameters, regimen, times, engine = c("auto", "analytic", "ode")) {
  engine <- match.arg(engine)
  if (!inherits(model, "pkpd_model")) stop("`model` must be a pkpd_model.", call. = FALSE)
  if (!inherits(regimen, "pkpd_regimen")) stop("`regimen` must be a pkpd_regimen.", call. = FALSE)
  if (!is.numeric(times) || any(!is.finite(times)) || any(times < 0))
    stop("`times` must be finite and non-negative.", call. = FALSE)
  p <- check_parameters(model, parameters)
  if (!all(regimen$events$route %in% model$routes))
    stop(sprintf("Route(s) %s are not supported by this model.",
                 paste(setdiff(unique(regimen$events$route), model$routes), collapse = ", ")), call. = FALSE)
  has_closed_form <- model$pk == "one_compartment" && is.null(model$tox_spec) && (is.null(model$pd) || model$pd == "direct_emax")
  if (engine == "analytic" && !has_closed_form) stop("No closed form is registered for this structure; use engine = \"ode\".", call. = FALSE)
  if (engine == "auto") engine <- if (has_closed_form) "analytic" else "ode"
  if (engine == "analytic") {
    A <- k01_amount(times, regimen$events, CL = p[["CL"]], V = p[["V"]])
    C <- A / p[["V"]]
    out <- data.frame(time = times, amount = A, concentration = C)
    if (!is.null(model$pd_spec)) {
      S <- hill_stimulus(C, p[["EC50"]], p[["hill"]])
      out$stimulus <- S
      out$effect <- p[["Emax"]] * S
    }
  } else {
    ord <- order(times)
    s <- solve_ode(model, as.data.frame(as.list(p)), regimen, times[ord])
    chk <- check_solution(s, model)
    inv <- order(ord)
    out <- data.frame(time = times, amount = s$A[inv, 1], concentration = s[[model$pk_spec$conc[1]]][inv, 1])
    if (length(model$pk_spec$conc) > 1L) out$active_concentration <- s[[model$pk_spec$conc[2]]][inv, 1]
    if (!is.null(model$pd_spec)) {
      out$stimulus <- s[[model$pd_spec$stimulus]][inv, 1]
      out$effect <- s[[model$pd_spec$effect]][inv, 1]
    }
    if (!is.null(model$tox_spec)) out$toxicity <- s[[model$tox_spec$effect]][inv, 1]
  }
  attr(out, "status") <- "ok"
  out
}

# Fail (do not clip) when a solution is non-finite or states leave their bounds.
check_solution <- function(s, model, tol = 1e-8) {
  for (nm in setdiff(names(s), "time")) {
    m <- s[[nm]]
    if (any(!is.finite(m))) stop(sprintf("Solver returned non-finite values in `%s`.", nm), call. = FALSE)
  }
  scale <- max(1, max(abs(s$A)))
  if (any(s$A < -tol * scale)) stop("Negative amount in the central compartment beyond tolerance.", call. = FALSE)
  if ("O" %in% names(s) && (any(s$O < -tol) || any(s$O > 1 + tol))) stop("Occupancy left [0, 1].", call. = FALSE)
  invisible(TRUE)
}

# Closed-form central amount (mg) for dose events on a one-compartment linear
# system with first-order elimination k = CL/V.
k01_amount <- function(times, events, CL, V) {
  k <- CL / V
  A <- numeric(length(times))
  for (i in seq_len(nrow(events))) {
    t0 <- events$time[i]; D <- events$amount[i]
    dt <- times - t0
    if (events$route[i] == "iv_bolus") {
      A <- A + ifelse(dt >= 0, D * exp(-k * pmax(dt, 0)), 0)
    } else if (events$route[i] == "iv_infusion") {
      dur <- events$duration[i]; R <- D / dur
      during <- dt >= 0 & dt <= dur
      after <- dt > dur
      # amount accumulated during the infusion: (R / k) * (1 - exp(-k t)) = (R / k) * -expm1(-k t)
      Aduring <- (R / k) * (-expm1(-k * pmax(pmin(dt, dur), 0)))
      A <- A + ifelse(during, Aduring, 0) + ifelse(after, (R / k) * (-expm1(-k * dur)) * exp(-k * (dt - dur)), 0)
    } else stop("Unsupported route.", call. = FALSE)
  }
  A
}

# Numerically stable Hill stimulus S = C^h / (EC50^h + C^h); S(0) = 0.
hill_stimulus <- function(C, EC50, h) {
  stats::plogis(h * (log(C) - log(EC50)))
}
