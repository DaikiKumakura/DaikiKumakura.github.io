# Evidence layer ---------------------------------------------------------------
#
# Every observation carries an evidence type, units, a source locator and the
# original value and unit before conversion. Real data and synthetic fixtures
# are kept apart by `evidence_type`.

evidence_types <- c("measured_individual", "measured_aggregate", "published_estimate", "digitized",
                    "reimplemented", "inferred", "synthetic", "missing")

#' Evidence types
#'
#' @return Character vector of the evidence types used by the package:
#'   `measured_individual`, `measured_aggregate`, `published_estimate`,
#'   `digitized`, `reimplemented`, `inferred`, `synthetic`, `missing`.
#' @examples
#' evidence_type_levels()
#' @export
evidence_type_levels <- function() evidence_types

sha256_file <- function(path) unname(tools::sha256sum(path))  # R >= 4.5.0

# Unit conversion to mg/L (concentration) and mg h/L (AUC) with a small explicit grammar:
#   "<amount> [x <time>] [/ <volume>]"   or a molar concentration "<M-unit> [x <time>]".
# `mw` (g/mol) is needed for molar units. Units that do not parse give NA (never guessed).
mass_mg <- c(pg = 1e-9, ng = 1e-6, "\u03bcg" = 1e-3, ug = 1e-3, mg = 1, g = 1e3)
mol_mol <- c(pmol = 1e-12, nmol = 1e-9, "\u03bcmol" = 1e-6, umol = 1e-6, mmol = 1e-3, mol = 1)
molar_l <- c(pM = 1e-12, nM = 1e-9, "\u03bcM" = 1e-6, uM = 1e-6, mM = 1e-3, M = 1)
vol_l <- c(L = 1, dL = 0.1, mL = 1e-3, "\u03bcL" = 1e-6)
time_h <- c(h = 1, min = 1 / 60, day = 24, s = 1 / 3600)
convert_one <- function(unit, mw, with_time) {
  if (is.na(unit)) return(NA_real_)
  parts <- strsplit(unit, "/", fixed = TRUE)[[1]]
  num <- trimws(strsplit(parts[1], " \u00d7 ", fixed = TRUE)[[1]])
  den <- if (length(parts) > 1L) trimws(parts[2]) else NA_character_
  tf <- 1
  if (with_time) { if (length(num) != 2L || !num[2] %in% names(time_h)) return(NA_real_); tf <- time_h[[num[2]]] }
  else if (length(num) != 1L) return(NA_real_)
  a <- num[1]
  if (!is.na(den) && den %in% names(vol_l)) {
    if (a %in% names(mass_mg)) return(mass_mg[[a]] / vol_l[[den]] * tf)
    if (a %in% names(mol_mol) && is.finite(mw)) return(mol_mol[[a]] * mw * 1000 / vol_l[[den]] * tf)
    return(NA_real_)
  }
  if (is.na(den) && a %in% names(molar_l) && is.finite(mw)) return(molar_l[[a]] * mw * 1000 * tf)
  NA_real_
}
convert_units <- function(value, unit, mw, with_time) {
  f <- vapply(seq_along(value), function(i) convert_one(unit[i], mw[i], with_time), numeric(1))
  value * f
}
to_mg_per_l <- function(value, unit, mw) convert_units(value, unit, mw, FALSE)
to_mg_h_per_l <- function(value, unit, mw) convert_units(value, unit, mw, TRUE)
to_hours <- function(value, unit) {
  out <- rep(NA_real_, length(value)); k <- unit %in% names(time_h) & !is.na(unit); out[k] <- value[k] * time_h[unit[k]]; out
}

#' Import the NCATS Fast Response Database (FRDB) pharmacokinetic table
#'
#' Reads `frdb-pk.tsv` and `frdb-drugs.tsv` from a directory that the user has
#' downloaded (the package does not download or redistribute the data). Values are
#' normalized to h, mg, mg/L and mg h/L; original values and units are kept.
#' Doses in mg/kg or mg/m2 are not converted (no body weight is assumed).
#' Entries from experiments are `measured_aggregate`; entries from labels,
#' reviews and other sources are `published_estimate`. Summary statistics of the
#' study (mean, median, ...) are not specified in the file; this is recorded as
#' `summary_type = "not_stated"`.
#'
#' @param dir Directory containing the FRDB tab-separated files.
#' @return A list of class `pkpd_evidence` with `summaries`, `drugs`, `manifest`.
#' @examples
#' \dontrun{ev <- import_frdb("path/to/frdb")}
#' @export
import_frdb <- function(dir) {
  fp <- file.path(dir, "frdb-pk.tsv"); fd <- file.path(dir, "frdb-drugs.tsv")
  if (!file.exists(fp) || !file.exists(fd)) stop("`dir` must contain frdb-pk.tsv and frdb-drugs.tsv.", call. = FALSE)
  rd <- function(f) utils::read.delim(f, stringsAsFactors = FALSE, quote = "", comment.char = "", na.strings = c("", "NA"), check.names = FALSE, fileEncoding = "UTF-8")
  pk <- rd(fp); dr <- rd(fd)
  req <- c("compound_id", "pk_species", "pk_routes", "pk_dose_value", "pk_dose_units", "pk_experiment_type", "pk_cmax_value",
           "pk_cmax_units", "pk_auc_value", "pk_auc_units", "pk_auc_type", "pk_thalf_value", "pk_thalf_units", "pk_source_uri", "pk_source_type")
  miss <- setdiff(req, names(pk)); if (length(miss)) stop(sprintf("FRDB columns missing: %s.", paste(miss, collapse = ", ")), call. = FALSE)
  mw <- suppressWarnings(as.numeric(pk$pk_analyte_mw))
  dose_mg <- ifelse(pk$pk_dose_units == "mg", pk$pk_dose_value, ifelse(pk$pk_dose_units == "g", pk$pk_dose_value * 1000,
                    ifelse(pk$pk_dose_units == "\u03bcg", pk$pk_dose_value / 1000, NA_real_)))
  s <- data.frame(
    evidence_id = sprintf("frdb-pk-%d", pk$id), source = "NCATS FRDB v1.5 2024-12-30", drug_id = paste0("frdb-", pk$compound_id),
    drug_name = dr$compound_name[match(pk$compound_id, dr$compound_id)], unii = pk$pk_analyte_unii,
    evidence_type = ifelse(pk$pk_source_type == "EXPERIMENT", "measured_aggregate", "published_estimate"),
    species = pk$pk_species, population_age = pk$pk_age_group, population_health = pk$pk_health_status, sex = pk$pk_sex,
    n_subjects = pk$pk_population_size, route = pk$pk_routes, schedule = pk$pk_experiment_type, food_status = pk$pk_food_status,
    dose_mg = dose_mg, dose_value_original = pk$pk_dose_value, dose_unit_original = pk$pk_dose_units, dose_type = pk$pk_dose_type,
    dose_basis = ifelse(pk$pk_dose_units %in% c("mg", "g", "\u03bcg"), "absolute", ifelse(pk$pk_dose_units %in% c("mg/kg", "mg/kg bw"), "per_kg", ifelse(pk$pk_dose_units == "mg/m\u00b2", "per_m2", "other"))),
    analyte_matrix = pk$pk_analyte_tissue, analyte_mw = mw,
    cmax_mg_per_l = to_mg_per_l(pk$pk_cmax_value, pk$pk_cmax_units, mw), cmax_value_original = pk$pk_cmax_value, cmax_unit_original = pk$pk_cmax_units,
    auc_mg_h_per_l = to_mg_h_per_l(pk$pk_auc_value, pk$pk_auc_units, mw), auc_value_original = pk$pk_auc_value, auc_unit_original = pk$pk_auc_units,
    auc_type = pk$pk_auc_type, auc_hours = pk$pk_auc_hours,
    thalf_h = to_hours(pk$pk_thalf_value, pk$pk_thalf_units), thalf_value_original = pk$pk_thalf_value, thalf_unit_original = pk$pk_thalf_units,
    fraction_unbound = pk$pk_funbound_value, summary_type = "not_stated", source_type = pk$pk_source_type, source_uri = pk$pk_source_uri,
    stringsAsFactors = FALSE)
  s$missing_reason_cmax <- ifelse(is.na(pk$pk_cmax_value), "not_reported", ifelse(is.na(s$cmax_mg_per_l), "unit_not_convertible", NA_character_))
  s$missing_reason_auc <- ifelse(is.na(pk$pk_auc_value), "not_reported", ifelse(is.na(s$auc_mg_h_per_l), "unit_not_convertible", NA_character_))
  s$missing_reason_thalf <- ifelse(is.na(pk$pk_thalf_value), "not_reported", ifelse(is.na(s$thalf_h), "unit_not_convertible", NA_character_))
  man <- data.frame(file = c("frdb-pk.tsv", "frdb-drugs.tsv"), sha256 = c(sha256_file(fp), sha256_file(fd)), rows = c(nrow(pk), nrow(dr)), stringsAsFactors = FALSE)
  structure(list(summaries = s, drugs = dr, manifest = man), class = "pkpd_evidence")
}

#' Audit an evidence table
#'
#' Counts rows, drugs, coverage of Cmax, AUC and half-life by route and
#' schedule, unit conversion failures, duplicates and implausible values.
#'
#' @param x A `pkpd_evidence` object from [import_frdb()].
#' @return A list of data frames: `overview`, `coverage`, `unit_failures`,
#'   `duplicates`, `flags`.
#' @examples
#' \dontrun{audit_evidence(import_frdb("path/to/frdb"))}
#' @export
audit_evidence <- function(x) {
  s <- x$summaries
  has <- function(v) !is.na(v)
  ov <- data.frame(rows = nrow(s), drugs = length(unique(s$drug_id)), species = paste(unique(s$species), collapse = ","),
                   rows_cmax = sum(has(s$cmax_mg_per_l)), rows_auc = sum(has(s$auc_mg_h_per_l)), rows_thalf = sum(has(s$thalf_h)),
                   rows_all_three = sum(has(s$cmax_mg_per_l) & has(s$auc_mg_h_per_l) & has(s$thalf_h)),
                   rows_dose_mg = sum(has(s$dose_mg)), rows_per_kg_or_m2 = sum(s$dose_basis %in% c("per_kg", "per_m2")),
                   measured_aggregate = sum(s$evidence_type == "measured_aggregate"), published_estimate = sum(s$evidence_type == "published_estimate"))
  cov <- stats::aggregate(cbind(rows = 1, with_cmax = has(cmax_mg_per_l), with_auc = has(auc_mg_h_per_l), with_thalf = has(thalf_h), drugs = 0) ~ route + schedule, data = transform(s, drugs = 0), FUN = sum)
  cov$drugs <- vapply(seq_len(nrow(cov)), function(i) length(unique(s$drug_id[s$route == cov$route[i] & s$schedule == cov$schedule[i]])), integer(1))
  one <- function(q, reason, unit) {
    u <- unit[!is.na(reason) & reason == "unit_not_convertible"]
    if (length(u)) data.frame(quantity = q, unit = as.character(u), stringsAsFactors = FALSE) else NULL
  }
  uf <- rbind(one("cmax", s$missing_reason_cmax, s$cmax_unit_original), one("auc", s$missing_reason_auc, s$auc_unit_original),
              one("thalf", s$missing_reason_thalf, s$thalf_unit_original))
  uf <- if (!is.null(uf)) { t <- as.data.frame(table(uf$quantity, uf$unit), stringsAsFactors = FALSE); t <- t[t$Freq > 0, ]; names(t) <- c("quantity", "unit", "rows"); t[order(-t$rows), ] }
        else data.frame(quantity = character(), unit = character(), rows = integer())
  key <- paste(s$drug_id, s$route, s$schedule, s$dose_value_original, s$dose_unit_original, s$cmax_value_original, s$auc_value_original, s$thalf_value_original)
  dup <- data.frame(duplicated_rows = sum(duplicated(key) & !is.na(s$cmax_value_original)), distinct_keys = length(unique(key)))
  fl <- data.frame(flag = c("nonpositive_cmax", "nonpositive_auc", "nonpositive_thalf", "thalf_gt_1000h", "dose_mg_nonpositive"),
                   rows = c(sum(s$cmax_mg_per_l <= 0, na.rm = TRUE), sum(s$auc_mg_h_per_l <= 0, na.rm = TRUE), sum(s$thalf_h <= 0, na.rm = TRUE),
                            sum(s$thalf_h > 1000, na.rm = TRUE), sum(s$dose_mg <= 0, na.rm = TRUE)), stringsAsFactors = FALSE)
  list(overview = ov, coverage = cov, unit_failures = uf, duplicates = dup, flags = fl)
}

#' Import a curated table of published values
#'
#' Reads a CSV with the required columns `drug_id`, `parameter`, `value`,
#' `unit`, `species`, `population`, `route`, `evidence_type`, `source_uri` and
#' `locator`, and validates it: allowed evidence types, finite positive values,
#' non-empty source and locator for non-synthetic rows, no duplicate keys.
#'
#' @param path CSV file.
#' @return A data frame of class `pkpd_curated`.
#' @examples
#' f <- system.file("extdata", "curated_fixture.csv", package = "pkpdspace")
#' import_curated(f)
#' @export
import_curated <- function(path) {
  d <- utils::read.csv(path, stringsAsFactors = FALSE, na.strings = c("", "NA"))
  req <- c("drug_id", "parameter", "value", "unit", "species", "population", "route", "evidence_type", "source_uri", "locator")
  miss <- setdiff(req, names(d)); if (length(miss)) stop(sprintf("Missing column(s): %s.", paste(miss, collapse = ", ")), call. = FALSE)
  bad <- setdiff(unique(d$evidence_type), evidence_types); if (length(bad)) stop(sprintf("Unknown evidence type(s): %s.", paste(bad, collapse = ", ")), call. = FALSE)
  if (any(!is.finite(d$value) | d$value <= 0)) stop("`value` must be finite and positive.", call. = FALSE)
  real <- d$evidence_type != "synthetic"
  if (any(is.na(d$source_uri[real]) | is.na(d$locator[real]))) stop("Non-synthetic rows need `source_uri` and `locator`.", call. = FALSE)
  if (anyDuplicated(d[, c("drug_id", "parameter", "route", "population", "source_uri", "locator")])) stop("Duplicate keys.", call. = FALSE)
  structure(d, class = c("pkpd_curated", "data.frame"))
}

#' Import an ADME assay table
#'
#' Reads a CSV of measured assay values with the columns `compound_id`,
#' `endpoint`, `value`, `unit`, `species`, `system` and `source_uri`, validates
#' it and returns a long table with an `evidence_type` of `measured_individual`.
#' Assay results are never converted into PK parameters.
#'
#' @param path CSV file (or a data frame).
#' @param endpoint Name of the endpoint when the file has a single value column
#'   (e.g. `"LogD7.4"`) and no `endpoint` column.
#' @param value_col,id_col Column names to use for the value and the compound id
#'   when the file has no `value` / `compound_id` columns.
#' @param unit,species,system,source_uri Constants used when the columns are absent.
#' @return A data frame of class `pkpd_adme`.
#' @examples
#' f <- system.file("extdata", "adme_fixture.csv", package = "pkpdspace")
#' import_adme_assay(f)
#' @export
import_adme_assay <- function(path, endpoint = NULL, value_col = NULL, id_col = NULL, unit = NA_character_, species = NA_character_,
                              system = NA_character_, source_uri = NA_character_) {
  d <- if (is.data.frame(path)) path else utils::read.csv(path, stringsAsFactors = FALSE, na.strings = c("", "NA"))
  if (!is.null(value_col)) d$value <- d[[value_col]]
  if (!is.null(id_col)) d$compound_id <- d[[id_col]]
  if (!"endpoint" %in% names(d)) { if (is.null(endpoint)) stop("Supply `endpoint`.", call. = FALSE); d$endpoint <- endpoint }
  for (nm in c("unit", "species", "system", "source_uri")) if (!nm %in% names(d)) d[[nm]] <- get(nm)
  req <- c("compound_id", "endpoint", "value", "unit", "species", "system", "source_uri")
  miss <- setdiff(req, names(d)); if (length(miss)) stop(sprintf("Missing column(s): %s.", paste(miss, collapse = ", ")), call. = FALSE)
  if (any(!is.finite(d$value))) stop("`value` must be finite.", call. = FALSE)
  out <- data.frame(d[, req], evidence_type = if ("evidence_type" %in% names(d)) d$evidence_type else "measured_individual", stringsAsFactors = FALSE)
  bad <- setdiff(unique(out$evidence_type), evidence_types); if (length(bad)) stop(sprintf("Unknown evidence type(s): %s.", paste(bad, collapse = ", ")), call. = FALSE)
  structure(out, class = c("pkpd_adme", "data.frame"))
}

# Standardize a NONMEM-style time-course data frame into regimens and observations.
#' Import time-course concentration data
#'
#' Converts a NONMEM-style data frame (event rows with `AMT` > 0 and
#' observation rows) into one regimen and one observation table per subject.
#' Each dose is an intravenous bolus, an intravenous infusion (when `rate` or
#' `dur` is given) or oral input, according to `route`. Observations are
#' concentrations in mg/L; rows with zero concentration before the first dose
#' are dropped and the number of dropped rows is reported. The evidence type is
#' `measured_individual` and is set by the caller after checking the origin of
#' the data.
#'
#' @param data Data frame.
#' @param id,time,dv,amt Column names (character).
#' @param evid Optional column marking dose rows (`!= 0`); if `NULL`, rows with
#'   `amt > 0` are doses.
#' @param rate Optional infusion-rate column (mg/h); rows with positive rate are infusions of duration `amt / rate`.
#' @param route Route of dose rows without a rate: `"oral"` or `"iv_bolus"`.
#' @param dvid Optional column and value `c(column, value)` selecting the concentration rows.
#' @return A list of class `pkpd_timecourse` with `subjects` (a list with `id`, `regimen`, `times`, `conc`) and `dropped`.
#' @examples
#' d <- data.frame(ID = 1, TIME = c(0, 0, 1, 4), AMT = c(100, 0, 0, 0),
#'                 DV = c(0, 0, 3, 1.5), EVID = c(1, 0, 0, 0))
#' import_timecourse(d, "ID", "TIME", "DV", "AMT", evid = "EVID", route = "oral")
#' @export
import_timecourse <- function(data, id, time, dv, amt, evid = NULL, rate = NULL, route = c("oral", "iv_bolus"), dvid = NULL) {
  route <- match.arg(route)
  d <- as.data.frame(data)
  if (!is.null(dvid)) d <- d[d[[dvid[1]]] == dvid[2] | (if (!is.null(evid)) d[[evid]] != 0 else d[[amt]] > 0), ]
  isdose <- if (!is.null(evid)) d[[evid]] != 0 & d[[amt]] > 0 else d[[amt]] > 0
  subs <- list(); dropped <- 0L
  for (i in unique(d[[id]])) {
    g <- d[d[[id]] == i, ]; gd <- g[isdose[d[[id]] == i], ]; go <- g[!isdose[d[[id]] == i], ]
    if (!nrow(gd)) next
    first <- min(gd[[time]])
    keep <- !(go[[dv]] <= 0 & go[[time]] <= first)
    dropped <- dropped + sum(!keep); go <- go[keep & go[[dv]] > 0, ]
    r <- NULL
    for (j in seq_len(nrow(gd))) {
      inf <- !is.null(rate) && is.finite(gd[[rate]][j]) && gd[[rate]][j] > 0
      rj <- if (inf) regimen(amount = gd[[amt]][j], route = "iv_infusion", duration = gd[[amt]][j] / gd[[rate]][j], start = gd[[time]][j])
            else regimen(amount = gd[[amt]][j], route = route, start = gd[[time]][j])
      r <- if (is.null(r)) rj else { r$events <- rbind(r$events, rj$events); r }
    }
    r$events <- r$events[order(r$events$time), ]; r$events$event_id <- seq_len(nrow(r$events))
    r$n <- nrow(r$events); r$route <- if (all(r$events$route == r$events$route[1])) r$events$route[1] else "mixed"
    subs[[as.character(i)]] <- list(id = i, regimen = r, times = go[[time]], conc = go[[dv]])
  }
  structure(list(subjects = subs, dropped = dropped), class = "pkpd_timecourse")
}
