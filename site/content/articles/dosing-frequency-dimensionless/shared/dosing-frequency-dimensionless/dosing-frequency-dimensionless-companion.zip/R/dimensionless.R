#' Dimensionless coordinates
#'
#' Computes intrinsic coordinates (time scales relative to a fixed reference
#' time) and, for a repeated intravenous bolus regimen, regimen coordinates and
#' closed-form steady-state quantities for the one-compartment model with a
#' direct Emax (Hill coefficient 1) response.
#'
#' The reference time `reference_time` is a fixed mathematical reference, not
#' a dosing interval or a property of the drug.
#'
#' With `k = CL / V`, `alpha = k * tau` and `beta = D / (V * EC50)`:
#' \deqn{C_{max,ss} = (D/V) / (1 - e^{-\alpha}), \quad C_{min,ss} = C_{max,ss} e^{-\alpha},
#'   \quad C_{avg,ss} = D / (CL \tau).}
#' The mean steady-state normalized effect (`Emax = 1`, `hill = 1`) is
#' `(log1p(cmax) - log1p(cmin)) / alpha` with `cmax = Cmax_ss / EC50`, and the
#' fraction of the interval with effect at least `e_threshold` is
#' `clamp(log(cmax / (e / (1 - e))) / alpha, 0, 1)`.
#'
#' @param model A [pkpd_model()].
#' @param parameters Named numeric vector; see [simulate_profile()].
#' @param regimen Optional [regimen()]. Steady-state coordinates require a
#'   repeated intravenous bolus with a constant amount.
#' @param reference_time Reference time (h) for the intrinsic coordinates.
#' @param e_threshold Effect threshold in (0, 1) for the time-above-threshold
#'   coordinate, as a fraction of `Emax`.
#' @return A list of class `pkpd_dimensionless` with `intrinsic` and, if a
#'   regimen is supplied, `regimen` coordinates.
#' @examples
#' m <- pkpd_model("one_compartment", "direct_emax")
#' dimensionless(m, c(CL = 2, V = 20, EC50 = 0.5, hill = 1),
#'               regimen(amount = 24, interval = 24, n = 14))
#' @export
dimensionless <- function(model, parameters, regimen = NULL, reference_time = 24, e_threshold = 0.5) {
  if (!inherits(model, "pkpd_model")) stop("`model` must be a pkpd_model.", call. = FALSE)
  check_positive(reference_time, "reference_time", length1 = TRUE)
  p <- check_parameters(model, parameters)
  k <- p[["CL"]] / p[["V"]]
  out <- list(intrinsic = c(k = k, half_life = log(2) / k, k_T0 = k * reference_time),
              reference_time = reference_time)
  if (!is.null(regimen)) {
    if (!inherits(regimen, "pkpd_regimen")) stop("`regimen` must be a pkpd_regimen.", call. = FALSE)
    if (is.null(model$pd_spec)) stop("Regimen coordinates need a PD structure (EC50 reference).", call. = FALSE)
    if (regimen$route != "iv_bolus" || regimen$n < 2L || length(unique(regimen$events$amount)) != 1L)
      stop("Steady-state coordinates require a repeated intravenous bolus with a constant amount.", call. = FALSE)
    if (p[["hill"]] != 1) stop("Closed-form effect coordinates are available only for hill = 1.", call. = FALSE)
    out$regimen <- steady_state_bolus(CL = p[["CL"]], V = p[["V"]], EC50 = p[["EC50"]],
                                      D = regimen$events$amount[1], tau = regimen$interval, e_threshold = e_threshold)
  }
  class(out) <- "pkpd_dimensionless"
  out
}

#' @export
print.pkpd_dimensionless <- function(x, ...) {
  cat("<pkpd_dimensionless>\n  intrinsic:", paste0(names(x$intrinsic), " = ", signif(x$intrinsic, 4), collapse = "; "), "\n")
  if (!is.null(x$regimen)) cat("  regimen:", paste0(names(x$regimen), " = ", signif(x$regimen, 4), collapse = "; "), "\n")
  invisible(x)
}

# Closed-form steady state of a repeated IV bolus on a 1-compartment system with
# direct Emax (hill = 1, Emax = 1). Vectorised over its arguments.
steady_state_bolus <- function(CL, V, EC50, D, tau, e_threshold = 0.5) {
  k <- CL / V
  alpha <- k * tau
  beta <- D / (V * EC50)
  cmax_abs <- (D / V) / (-expm1(-alpha))
  cmin_abs <- cmax_abs * exp(-alpha)
  cmax <- cmax_abs / EC50
  cmin <- cmin_abs / EC50
  odds <- e_threshold / (1 - e_threshold)
  tta <- pmin(pmax(log(cmax / odds) / alpha, 0), 1)
  mean_effect <- (log1p(cmax) - log1p(cmin)) / alpha
  c(alpha = alpha, beta = beta, Cmax_ss = cmax_abs, Cmin_ss = cmin_abs, Cavg_ss = D / (CL * tau),
    cmax = cmax, cmin = cmin, mean_effect = mean_effect, time_above_threshold = tta)
}
