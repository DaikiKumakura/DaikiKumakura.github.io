# Companion archive: When does dosing frequency matter?

Contents: R package source used for the study (pkpdspace 0.0.5, GPL-3, development version), workflow scripts, configuration files and the result tables (results/freq-*.csv).
No data from third parties are included. The Fast Response Database files (reference 1 of the article) are not redistributed; without them the real-drug overlay is reported as NOT EVALUATED.

Requirements: R 4.5.x, packages rxode2, randtoolbox, ggplot2, pkgload (and xgboost is not needed here).

Run order (from this directory):
  Rscript workflows/03_generate_space.R --config workflows/config/frequency.R --out workflows/out/frequency
  Rscript workflows/10_frequency_study.R
Optional real-drug overlay: place the FRDB files (frdb-pk.tsv, frdb-drugs.tsv) in workflows/data-cache/ncats/extracted/frdb/ (obtain them from the source in the article; check its terms).
Seed 20261201. Outputs: validation/results/freq-*.csv and outputs/figures/freq-fig*.png. Your numbers should match results/ to printed precision.
