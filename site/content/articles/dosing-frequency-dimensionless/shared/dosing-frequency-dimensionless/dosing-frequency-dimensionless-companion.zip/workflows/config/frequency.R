# Dosing-frequency study (Stage E): four PD mechanisms with one-compartment IV PK, 8,192 virtual drugs each.
config <- modifyList(local({ source("workflows/config/pilot.R", local = TRUE); config }), list(
  name = "frequency", n_per_structure = 8192L, structures = c("K01xP01", "K01xP02", "K01xP03", "K01xP04"), seed = 20261201L))
