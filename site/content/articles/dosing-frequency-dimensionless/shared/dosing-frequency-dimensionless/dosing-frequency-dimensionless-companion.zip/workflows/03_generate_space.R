#!/usr/bin/env Rscript
# Generate and simulate a virtual PK/PD space for every supported structure.
#
# Usage: Rscript workflows/03_generate_space.R --config workflows/config/pilot.R --out workflows/out/pilot [--seed 20261126] [--dry-run]
#
# Labels-free: structures are identified by mechanism; no drug, target or modality
# information enters the design. The design ranges are stress-test ranges in
# dimensionless form (see design/decisions.md), not distributions of real drugs.
# Inputs : config file (a list `config`), seed.   Outputs: <out>/<structure>/chunk_*.rds, manifest.rds,
#          <out>/features.rds (all structures), <out>/run-manifest.rds, <out>/session-info.txt.
# Re-running with the same --out resumes unfinished chunks and never duplicates finished ones.

args <- commandArgs(trailingOnly = TRUE)
opt <- list(config = "workflows/config/smoke.R", out = "workflows/out/run", seed = NA, dry = FALSE)
i <- 1L
while (i <= length(args)) {
  a <- args[i]
  if (a == "--config") { opt$config <- args[i + 1L]; i <- i + 2L }
  else if (a == "--out") { opt$out <- args[i + 1L]; i <- i + 2L }
  else if (a == "--seed") { opt$seed <- as.integer(args[i + 1L]); i <- i + 2L }
  else if (a == "--dry-run") { opt$dry <- TRUE; i <- i + 1L }
  else if (a == "--help") { cat("Rscript workflows/03_generate_space.R --config FILE --out DIR [--seed N] [--dry-run]\n"); quit(status = 0) }
  else stop("Unknown argument: ", a)
}
suppressMessages(if (file.exists("DESCRIPTION")) pkgload::load_all(".", quiet = TRUE) else library(pkpdspace))
source(opt$config, local = TRUE)               # defines `config`
if (is.na(opt$seed)) opt$seed <- config$seed
dir.create(opt$out, recursive = TRUE, showWarnings = FALSE)

# Dimensionless candidate ranges (reference time T0, reference volume and dose). Parameters in
# model units are derived once from these, not sampled twice.
T0 <- config$reference_time; Vref <- config$reference_volume; Dref <- config$reference_dose
Cref <- Dref / Vref
rng <- config$ranges
dimless_ranges <- function(model) {
  nm <- model$parameters$name
  r <- list()
  add <- function(name, lo, hi) if (name %in% nm) r[[name]] <<- c(lo, hi)
  k_lo <- rng$k_T0[1] / T0; k_hi <- rng$k_T0[2] / T0
  add("CL", Vref * k_lo, Vref * k_hi)
  add("ka", rng$ka_T0[1] / T0, rng$ka_T0[2] / T0)
  add("ke0", rng$ke0_T0[1] / T0, rng$ke0_T0[2] / T0)
  add("kout", rng$kout_T0[1] / T0, rng$kout_T0[2] / T0)
  add("krec", rng$krec_T0[1] / T0, rng$krec_T0[2] / T0)
  add("koff", rng$koff_T0[1] / T0, rng$koff_T0[2] / T0)
  add("kon", rng$kon_Cref_T0[1] / (T0 * Cref), rng$kon_Cref_T0[2] / (T0 * Cref))
  add("EC50", rng$EC50_Cref[1] * Cref, rng$EC50_Cref[2] * Cref)
  add("EC50_tox", rng$EC50_Cref[1] * Cref, rng$EC50_Cref[2] * Cref)
  add("Km", rng$EC50_Cref[1] * Cref, rng$EC50_Cref[2] * Cref)
  add("hill", rng$hill[1], rng$hill[2]); add("hill_tox", rng$hill[1], rng$hill[2])
  add("F", rng$fraction[1], rng$fraction[2]); add("fm", rng$fraction[1], rng$fraction[2])
  add("Imax", rng$fraction[1], rng$fraction[2])
  add("Vp", Vref * rng$volume_ratio[1], Vref * rng$volume_ratio[2])
  add("Q", Vref * rng$Q_ratio[1] / T0, Vref * rng$Q_ratio[2] / T0)
  add("Vmax", Cref * Vref * rng$k_T0[1] / T0, Cref * Vref * rng$k_T0[2] / T0)
  add("CLm", Vref * k_lo, Vref * k_hi); add("Vm", Vref * rng$volume_ratio[1], Vref * rng$volume_ratio[2])
  r
}
fixed_for <- function(model) {
  nm <- model$parameters$name
  f <- c(V = Vref, Emax = 1, Hmax = 1, mwr = 1)
  f[names(f) %in% nm]
}

panel <- local({
  r <- list()
  tot <- config$dose_rate * config$course_h
  mk <- function(tau, route, dur = NULL) {
    n <- as.integer(round(config$course_h / tau))
    if (route == "iv_infusion") regimen(amount = tot / n, interval = tau, n = n, route = route, duration = dur) else regimen(amount = tot / n, interval = tau, n = n, route = route)
  }
  list(iv = regimen_set(qd = mk(24, "iv_bolus"), bid = mk(12, "iv_bolus"), q48h = mk(48, "iv_bolus"), qw = mk(168, "iv_bolus"), qd_infusion2h = mk(24, "iv_infusion", 2)),
       oral = regimen_set(qd = mk(24, "oral"), bid = mk(12, "oral"), q48h = mk(48, "oral"), qw = mk(168, "oral")))
})

structs <- supported_models()
invisible(gc(reset = TRUE))
all_res <- list(); log <- list(); t0 <- proc.time()[["elapsed"]]
for (s in seq_len(nrow(structs))) {
  pk <- structs$pk[s]; pd <- if (is.na(structs$pd[s])) NULL else structs$pd[s]; tx <- if (is.na(structs$tox[s])) NULL else structs$tox[s]
  model <- pkpd_model(pk, pd, tx)
  if (is.null(pd) && is.null(tx)) next                  # PK-only structures are covered by the PD-bearing ones
  if (!is.null(config$structures) && !model$structure_id %in% config$structures) next
  rg <- dimless_ranges(model); fx <- fixed_for(model)
  rg <- rg[setdiff(names(rg), names(fx))]
  sp <- parameter_space(model, ranges = rg, fixed = fx)
  n <- config$n_per_structure
  seed_s <- opt$seed + s
  drugs <- sample_space(sp, n = n, method = "sobol", seed = seed_s)
  regs <- if (pk == "first_order_input") panel$oral else panel$iv
  sdir <- file.path(opt$out, model$structure_id)
  if (!opt$dry) { dir.create(sdir, recursive = TRUE, showWarnings = FALSE); saveRDS(as.data.frame(drugs), file.path(sdir, "drugs.rds")) }  # parameters, for learning
  times <- seq(0, config$course_h + 168, by = config$time_step)
  win <- c(config$course_h - 168, config$course_h)   # the last 7 days of dosing (not the washout after it)
  if (opt$dry) { print(simulate_space(drugs, regs, times = times, window = win, chunk_size = config$chunk_size, dry_run = TRUE)); next }
  tt <- system.time(res <- simulate_space(drugs, regs, times = times, window = win, chunk_size = config$chunk_size, dir = sdir))[["elapsed"]]
  man <- attr(res, "manifest")
  res$structure_id <- model$structure_id
  all_res[[length(all_res) + 1L]] <- res
  log[[length(log) + 1L]] <- data.frame(structure_id = model$structure_id, n_drugs = man$n_drugs, n_rows = man$n_rows, n_failed = man$n_failed,
                                        failure_rate = man$n_failed / man$n_rows, seconds = tt, chunks_resumed = man$chunks_resumed, stringsAsFactors = FALSE)
  message(sprintf("%-10s drugs %6d rows %7d failed %5d (%.2f%%)  %.1f s", model$structure_id, man$n_drugs, man$n_rows, man$n_failed, 100 * man$n_failed / man$n_rows, tt))
}
if (!opt$dry) {
  feat <- do.call(rbind, lapply(all_res, as.data.frame))
  saveRDS(feat, file.path(opt$out, "features.rds"))
  lg <- do.call(rbind, log)
  rm_ <- list(created = format(Sys.time(), tz = "UTC", usetz = TRUE), seed = opt$seed, config = config, config_md5 = unname(tools::md5sum(opt$config)),
              runtime_seconds = proc.time()[["elapsed"]] - t0, peak_memory_mb_r = sum(gc()[, 6]), structures = lg, n_rows = nrow(feat), n_failed = sum(feat$status != "ok"),
              output_bytes = sum(file.size(list.files(opt$out, recursive = TRUE, full.names = TRUE))), R = R.version.string,
              package_version = as.character(utils::packageVersion("pkpdspace")),
              git_sha = tryCatch(system("git rev-parse HEAD", intern = TRUE, ignore.stderr = TRUE), error = function(e) NA_character_, warning = function(w) NA_character_))
  saveRDS(rm_, file.path(opt$out, "run-manifest.rds"))
  writeLines(capture.output(sessionInfo()), file.path(opt$out, "session-info.txt"))
  utils::write.csv(lg, file.path(opt$out, "run-log.csv"), row.names = FALSE)
  print(lg)
}
