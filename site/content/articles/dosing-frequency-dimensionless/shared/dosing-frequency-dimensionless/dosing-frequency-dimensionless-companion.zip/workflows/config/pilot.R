# Pilot configuration: 2^10 drugs per PD or toxicity-bearing structure.
config <- list(
  name = "pilot", seed = 20261126L, n_per_structure = 1024L, chunk_size = 512L,
  reference_time = 24, reference_volume = 10, reference_dose = 10,
  dose_rate = 1, course_h = 336, time_step = 1,
  ranges = list(k_T0 = c(1e-2, 1e2), ka_T0 = c(1e-1, 1e2), ke0_T0 = c(1e-1, 1e2), kout_T0 = c(1e-2, 1e2), krec_T0 = c(1e-2, 1e2),
                koff_T0 = c(1e-2, 1e2), kon_Cref_T0 = c(1e-2, 1e2), EC50_Cref = c(1e-2, 1e2), hill = c(0.5, 4), fraction = c(0.05, 0.95),
                volume_ratio = c(0.1, 10), Q_ratio = c(1e-2, 1e2))
)
