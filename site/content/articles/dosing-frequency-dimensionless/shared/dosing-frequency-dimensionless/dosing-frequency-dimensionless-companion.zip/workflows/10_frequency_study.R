#!/usr/bin/env Rscript
# Stage E research case study: when does dosing frequency matter?
# QOI: at equal total dose, how do twice-daily (bid) and once-daily (qd) dosing differ in the PD proxy, as a function of
#      dimensionless coordinates alpha = k * 24 h (elimination relative to the dosing interval) and beta = D_qd / (V * C_ref)?, C_ref = EC50 (Kd = koff/kon for persistent binding)
# COU: hypothesis formation about dosing frequency in early development. Not a dosing recommendation.
# Inputs : workflows/out/frequency/<structure>/{drugs.rds, chunk_*.rds}  (workflows/03_generate_space.R, config/frequency.R)
# Outputs: validation/results/freq-*.csv, outputs/figures/freq-*.png
# Thresholds are fixed here before looking at results: "frequency matters" for time above threshold = |difference| >= 0.10 (absolute
# fraction of the window); for mean effect = relative difference >= 5%. Sensitivity: 0.05/0.20 and 2%/10%.
suppressMessages(if (file.exists("DESCRIPTION")) pkgload::load_all(".", quiet = TRUE) else library(pkpdspace))
out <- "validation/results"; fig <- "outputs/figures"; dir.create(out, FALSE, TRUE); dir.create(fig, FALSE, TRUE)
T0 <- 24; Vref <- 10; D_day <- 24                     # config/frequency.R: dose rate 1 mg/h, V fixed at 10 L, regimens qd (24 mg) and bid (12 mg)
okabe <- c(vermillion = "#D55E00", blue = "#0072B2", green = "#009E73", orange = "#E69F00", sky = "#56B4E9", purple = "#CC79A7")
rd <- function(d) { f <- list.files(d, pattern = "^chunk_.*\\.rds$", full.names = TRUE); do.call(rbind, lapply(f, function(x) as.data.frame(readRDS(x)))) }
thr_ta <- c(0.05, 0.10, 0.20); thr_me <- c(0.02, 0.05, 0.10)
res <- list(); grid <- list(); chk <- list()
for (st in c("K01xP01", "K01xP02", "K01xP03", "K01xP04")) {
  d <- file.path("workflows/out/frequency", st)
  th <- readRDS(file.path(d, "drugs.rds")); th <- th[th$status == "ok", ]; f <- rd(d); f <- f[f$status == "ok" & f$regimen_id %in% c("qd", "bid"), ]
  q <- f[f$regimen_id == "qd", ]; b <- f[f$regimen_id == "bid", ]; m <- merge(q, b, by = "virtual_id", suffixes = c("_qd", "_bid"))
  m <- merge(m, th[, c("virtual_id", intersect(c("CL", "V", "EC50", "hill", "Km", "kon", "koff", "kout", "ke0"), names(th)))], by = "virtual_id")
  stopifnot(nrow(m) > 0, all(abs(m$total_dose_qd - m$total_dose_bid) < 1e-8))               # equal total dose
  m$ref_conc <- if ("EC50" %in% names(m)) m$EC50 else m$koff / m$kon      # persistent binding: Kd = koff / kon
  m$alpha <- (m$CL / m$V) * T0; m$beta <- D_day / (m$V * m$ref_conc)
  m$d_ta <- m$time_above_bid - m$time_above_qd; m$rel_me <- (m$mean_effect_bid - m$mean_effect_qd) / pmax(m$mean_effect_qd, 1e-6)
  for (a in thr_ta) for (b2 in thr_me) res[[length(res) + 1L]] <- data.frame(structure = st, n = nrow(m), thr_time_above = a, thr_mean_effect = b2,
    share_time_above = mean(abs(m$d_ta) >= a), share_mean_effect = mean(abs(m$rel_me) >= b2), share_either = mean(abs(m$d_ta) >= a | abs(m$rel_me) >= b2))
  # fixed-grid summary over (log10 alpha, log10 beta): 12 x 12 bins
  m$ia <- cut(log10(m$alpha), seq(-2, 2, length.out = 13), include.lowest = TRUE); m$ib <- cut(log10(m$beta), seq(-2.5, 2.5, length.out = 13), include.lowest = TRUE)
  g <- aggregate(cbind(abs_d_ta = abs(d_ta), abs_rel_me = abs(rel_me), n = 1) ~ ia + ib, data = m, FUN = function(x) c(med = stats::median(x), n = length(x)))
  g <- data.frame(structure = st, ia = g$ia, ib = g$ib, med_abs_d_time_above = g$abs_d_ta[, "med"], med_abs_rel_mean_effect = g$abs_rel_me[, "med"], n = g$abs_d_ta[, "n"])
  grid[[st]] <- g
  m$alpha_bin <- cut(m$alpha, c(0, 0.1, 0.3, 1, 3, 10, Inf)); m$structure <- st
  chk[[st]] <- aggregate(cbind(abs_d_ta = abs(d_ta), abs_rel_me = abs(rel_me)) ~ alpha_bin, data = m, FUN = stats::median)
  chk[[st]]$structure <- st
  if (st == "K01xP01") {
    h1 <- m[abs(m$hill - 1) < 1e-9 | m$hill < 1.05, ]
    cat("K01xP01 hill ~ 1 (n =", nrow(h1), "): median |relative mean-effect difference| =", signif(stats::median(abs(h1$rel_me)), 3), "\n")
    hh <- cut(m$hill, c(0.5, 0.8, 1.2, 2, 4)); print(tapply(abs(m$rel_me), hh, stats::median))
    utils::write.csv(data.frame(hill_bin = levels(hh), median_abs_rel_mean_effect = as.numeric(tapply(abs(m$rel_me), hh, stats::median)), n = as.integer(table(hh))),
                     file.path(out, "freq-jensen-hill.csv"), row.names = FALSE)
  }
  saveRDS(m[, c("virtual_id", "alpha", "beta", "d_ta", "rel_me")], file.path(out, sprintf("freq-points-%s.rds", st)))
}
r <- do.call(rbind, res); utils::write.csv(r, file.path(out, "freq-shares.csv"), row.names = FALSE); print(r[r$thr_time_above == 0.10 & r$thr_mean_effect == 0.05, ])
cg <- do.call(rbind, grid); cg$ia <- as.character(cg$ia); cg$ib <- as.character(cg$ib); utils::write.csv(cg, file.path(out, "freq-grid.csv"), row.names = FALSE)
ca <- do.call(rbind, chk); utils::write.csv(ca, file.path(out, "freq-by-alpha.csv"), row.names = FALSE); print(ca)

# Figure 1: median |time-above difference| on the (alpha, beta) grid, per structure
if (requireNamespace("ggplot2", quietly = TRUE)) {
  mid <- function(s) { v <- as.numeric(strsplit(gsub("[\\[\\]\\(\\)]", "", s, perl = TRUE), ",")[[1]]); mean(v) }
  cg$x <- vapply(cg$ia, mid, numeric(1)); cg$y <- vapply(cg$ib, mid, numeric(1))
  lab <- c(K01xP01 = "Direct Emax", K01xP02 = "Effect compartment", K01xP03 = "Indirect response", K01xP04 = "Persistent binding")
  cg$mech <- factor(lab[cg$structure], lab)
  p <- ggplot2::ggplot(cg, ggplot2::aes(x, y, fill = med_abs_d_time_above)) + ggplot2::geom_tile() + ggplot2::facet_wrap(~mech) +
    ggplot2::scale_fill_gradient(low = "white", high = okabe[["vermillion"]], limits = c(0, 1), name = "median |bid - qd|\ntime above threshold") +
    ggplot2::labs(x = expression(log[10](alpha == k %.% 24 ~ h)), y = expression(log[10](beta == D[qd] / (V %.% C[ref]))),
                  caption = sprintf("Virtual drugs (design distribution, not real drugs); equal total dose;
n = %d to %d per mechanism; white = zero difference or no drug in the cell.", min(r$n), max(r$n))) +
    ggplot2::theme_bw(base_size = 11) + ggplot2::theme(plot.caption = ggplot2::element_text(hjust = 0))
  ggplot2::ggsave(file.path(fig, "freq-fig1-time-above.png"), p, width = 8, height = 6, dpi = 150)
  p2 <- ggplot2::ggplot(cg, ggplot2::aes(x, y, fill = med_abs_rel_mean_effect)) + ggplot2::geom_tile() + ggplot2::facet_wrap(~mech) +
    ggplot2::scale_fill_gradient(low = "white", high = okabe[["blue"]], limits = c(0, 1), oob = scales::squish, name = "median |relative\nmean-effect difference|") +
    ggplot2::labs(x = expression(log[10](alpha)), y = expression(log[10](beta))) + ggplot2::theme_bw(base_size = 11)
  ggplot2::ggsave(file.path(fig, "freq-fig2-mean-effect.png"), p2, width = 8, height = 6, dpi = 150)
}

# Real-drug PK coordinates only (no PD coordinate is available): alpha_qd = ln2 / t_half * 24 h, FRDB intravenous and oral single-dose half-lives
fr <- "workflows/data-cache/ncats/extracted/frdb"
if (dir.exists(fr)) {
  ev <- import_frdb(fr); s <- ev$summaries; s <- s[is.finite(s$thalf_h) & s$thalf_h > 0 & s$route %in% c("Oral", "Intravenous") & s$schedule == "SINGLE", ]
  a <- stats::aggregate(thalf_h ~ drug_id, data = s, FUN = function(x) exp(mean(log(x)))); a$alpha_qd <- log(2) / a$thalf_h * 24
  q <- stats::quantile(a$alpha_qd, c(0.05, 0.25, 0.5, 0.75, 0.95)); print(q)
  bins <- cut(a$alpha_qd, c(0, 0.1, 0.3, 1, 3, 10, Inf)); tb <- data.frame(alpha_bin = levels(bins), drugs = as.integer(table(bins)), share = as.numeric(table(bins)) / nrow(a))
  utils::write.csv(tb, file.path(out, "freq-real-alpha.csv"), row.names = FALSE); print(tb)
} else cat("NOT EVALUATED: FRDB not available.\n")
