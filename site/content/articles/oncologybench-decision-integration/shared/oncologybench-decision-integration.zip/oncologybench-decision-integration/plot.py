from pathlib import Path
import csv
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np

HERE=Path(__file__).resolve().parent
def main():
    (HERE/'figures').mkdir(exist_ok=True)
    plt.rcParams.update({'font.size':11,'axes.spines.top':False,'axes.spines.right':False})
    rows=list(csv.DictReader((HERE/'results/scope-checks.csv').open()))
    fields=['system','intervention','comparator','endpoint','record_state']
    labels=['Same spatial scope','Vehicle is not monotherapy','Mouse spatial is not human outcome','Unrecorded variant is not A','Monotherapy is not combination','Missing is not absent','Keep missing as missing']
    codes={'not_requested':0,'compatible':1,'unresolved':2,'mismatch':3};colors=['#f0f0f0','#398969','#d4a64f','#b55c59']
    from matplotlib.colors import ListedColormap
    fig,ax=plt.subplots(figsize=(11,5.7));values=np.array([[codes[r[f]] for f in fields] for r in rows]);ax.imshow(values,cmap=ListedColormap(colors),vmin=0,vmax=3,aspect='auto')
    ax.set_yticks(range(7),labels);ax.set_xticks(range(5),['System','Intervention','Comparator','Endpoint','Record state']);ax.xaxis.tick_top()
    short=['—','match','unknown','different']
    for i in range(7):
        for j in range(5):ax.text(j,i,short[values[i,j]],ha='center',va='center',color='white' if values[i,j] in (1,3) else '#333333',fontsize=10)
    fig.text(.5,.05,'Seven original controlled metadata fixtures; not AI outputs or clinical cases.\nMatching scope alone does not establish efficacy or justify a programme decision.',ha='center',fontsize=9)
    fig.subplots_adjust(left=.35,right=.98,top=.89,bottom=.2);fig.savefig(HERE/'figures/01-evidence-scope.png',dpi=150,metadata={'Software':'Matplotlib'});plt.close(fig)
    rows=list(csv.DictReader((HERE/'results/utility-curves.csv').open()));q=[float(r['q']) for r in rows]
    fig,ax=plt.subplots(figsize=(10,5.3))
    for k,color,label in [('stop','#777777','Stop'),('continue_utility','#387c88','Continue now'),('test_utility','#b47843','Test, then choose')]:ax.plot(q,[float(r[k]) for r in rows],color=color,label=label,lw=2)
    ax.axvline(9/84,color='#aaaaaa',ls=':',lw=1);ax.axvline(31/56,color='#aaaaaa',ls=':',lw=1)
    ax.set_xlabel('Hypothetical probability q of eventual project success');ax.set_ylabel('Expected utility (arbitrary units)');ax.legend(frameon=False);ax.grid(axis='y',alpha=.2)
    fig.text(.5,.035,'Success +100, failure -40; test sensitivity 0.8, specificity 0.9, cost 5.\nActions after either result adapt to q. No patient recommendation or empirical test performance.',ha='center',fontsize=9)
    fig.subplots_adjust(left=.12,right=.97,top=.94,bottom=.24);fig.savefig(HERE/'figures/02-decision-and-information.png',dpi=150,metadata={'Software':'Matplotlib'});plt.close(fig)

if __name__=='__main__':main()
