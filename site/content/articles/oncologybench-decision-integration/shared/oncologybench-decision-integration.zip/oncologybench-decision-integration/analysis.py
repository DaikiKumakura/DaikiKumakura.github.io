"""Original metadata checks and hypothetical project decision arithmetic."""
from pathlib import Path
from collections import Counter
import csv,json

HERE=Path(__file__).resolve().parent
FIELDS=('system','intervention','comparator','endpoint','record_state')

def scope_check(evidence,claim):
    if not claim or any(k not in FIELDS for k in claim):raise ValueError('Explicit supported metadata fields required')
    checks={}
    for field,want in claim.items():
        got=evidence.get(field)
        checks[field]='compatible' if got==want else ('unresolved' if got is None else 'mismatch')
    status='mismatch' if 'mismatch' in checks.values() else ('unresolved' if 'unresolved' in checks.values() else 'compatible')
    return status,checks

def grader_structure(doc):
    counts=Counter();positive=negative=0
    def walk(node):
        nonlocal positive,negative
        counts[node['type']]+=1
        if node['type']=='rubric':
            criteria=node['config']['criteria']
            positive+=sum(c['score_delta']>0 for c in criteria);negative+=sum(c['score_delta']<0 for c in criteria)
        for child in node.get('config',{}).get('children',[]):walk(child)
    for root in doc['graders']:walk(root)
    containers=sum(counts.get(k,0) for k in ('all_of','average_of'))
    return dict(examinations=doc['task'].count('## Examination'),nodes=sum(counts.values()),containers=containers,leaves=sum(counts.values())-containers,numeric_tolerance_nodes=counts['numeric_tolerance'],numeric_range_nodes=counts['numeric_range'],predicate_nodes=counts['predicate_leaf'],rubric_nodes=counts['rubric'],positive_criteria=positive,negative_criteria=negative)

def utilities(q,cost=5.,sensitivity=.8,specificity=.9,gain=100.,loss=40.):
    if not 0<=q<=1 or not 0<=sensitivity<=1 or not 0<=specificity<=1 or min(cost,gain,loss)<0:raise ValueError('Invalid hypothetical inputs')
    direct=q*gain-(1-q)*loss
    # Joint expected utilities avoid dividing by a zero-probability test outcome.
    pos=q*sensitivity*gain-(1-q)*(1-specificity)*loss
    neg=q*(1-sensitivity)*gain-(1-q)*specificity*loss
    tested=max(pos,0)+max(neg,0)-cost
    vals={'stop':0.,'continue':direct,'test':tested}
    best=max(vals.values());optimal='|'.join(k for k,v in vals.items() if abs(v-best)<1e-10)
    return dict(stop=0.,continue_utility=direct,test_utility=tested,positive_followup='continue' if pos>0 else 'stop',negative_followup='continue' if neg>0 else 'stop',best_actions=optimal,gross_information_value=tested+cost-max(direct,0))

def dump(name,rows):
    with (HERE/'results'/name).open('w',newline='',encoding='utf-8') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)

def main():
    (HERE/'results').mkdir(exist_ok=True)
    fixtures=json.loads((HERE/'fixtures.json').read_text());scope=[]
    for f in fixtures:
        status,checks=scope_check(f['evidence'],f['claim']);scope.append(dict(id=f['id'],status=status,**{k:checks.get(k,'not_requested') for k in FIELDS}))
    structures=json.loads((HERE/'source-structure.json').read_text())['examples']
    dump('source-structure.csv',structures);dump('scope-checks.csv',scope)
    rows=[dict(q=i/100,**utilities(i/100)) for i in range(101)];dump('utility-curves.csv',rows)
    sens=[dict(q=i/100,cost=cost,sensitivity=se,specificity=sp,**utilities(i/100,cost,se,sp)) for cost in (0.,5.,20.) for se,sp in ((.6,.6),(.8,.9),(.95,.95)) for i in range(101)];dump('sensitivity.csv',sens)
    summary=dict(public_examples=2,benchmark_reproduced=False,llm_runs=0,fixtures=len(fixtures),fixture_status_counts=dict(Counter(r['status'] for r in scope)),q_grid_points=101,sensitivity_rows=len(sens),parameters=dict(gain=100,loss=40,cost=5,sensitivity=.8,specificity=.9),direct_break_even=40/140,test_vs_stop_threshold=9/84,test_vs_continue_threshold=31/56,note='Thresholds for this hypothetical base scenario only; q and utilities are not empirical clinical values',base_at_q_point2=utilities(.2),base_at_q_point4=utilities(.4),base_at_q_point8=utilities(.8))
    (HERE/'results/summary.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary,indent=2))

if __name__=='__main__':main()
