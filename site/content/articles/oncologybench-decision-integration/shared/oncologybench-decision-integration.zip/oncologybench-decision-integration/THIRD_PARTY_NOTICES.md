# Source attribution

OncologyBench, latchbio/oncologybench, Apache License 2.0, commit c576d11144db9a5b2f8461d469e24ac05af2386a. The package contains factual counts of its two public example grading structures and source hashes, with source links. Original tasks, answer keys, graders, figures and source code are not redistributed. All executable scripts and the seven metadata fixtures in this package are original.

Original repository and license: https://github.com/latchbio/oncologybench/tree/c576d11144db9a5b2f8461d469e24ac05af2386a ; https://github.com/latchbio/oncologybench/blob/c576d11144db9a5b2f8461d469e24ac05af2386a/LICENSE . The optional audit fetch requires internet access and downloads the original files separately.
