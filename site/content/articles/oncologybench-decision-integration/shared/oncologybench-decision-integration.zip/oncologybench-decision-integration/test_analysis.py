import unittest
from analysis import utilities,scope_check,grader_structure

class AuditTests(unittest.TestCase):
    def test_missing_is_not_absent(self):self.assertEqual(scope_check({'record_state':None},{'record_state':'absent'})[0],'unresolved')
    def test_keep_unknown(self):self.assertEqual(scope_check({'record_state':None},{'record_state':None})[0],'compatible')
    def test_comparator_mismatch(self):self.assertEqual(scope_check({'comparator':'vehicle'},{'comparator':'M'})[0],'mismatch')
    def test_wrong_endpoint(self):self.assertEqual(scope_check({'endpoint':'spatial'},{'endpoint':'outcome'})[0],'mismatch')
    def test_missing_not_wildcard(self):self.assertEqual(scope_check({}, {'intervention':'A'})[0],'unresolved')
    def test_recursive_alternative_count(self):
        d={'task':'## Examination 1','graders':[{'type':'average_of','config':{'children':[{'type':'numeric_tolerance','config':{}},{'type':'predicate_leaf','config':{}}]}}]};r=grader_structure(d);self.assertEqual((r['containers'],r['leaves']),(1,2))
    def test_hand_q_point2(self):
        r=utilities(.2);self.assertAlmostEqual(r['continue_utility'],-12);self.assertAlmostEqual(r['test_utility'],7.8);self.assertEqual(r['best_actions'],'test')
    def test_hand_q_point4(self):
        r=utilities(.4);self.assertAlmostEqual(r['continue_utility'],16);self.assertAlmostEqual(r['test_utility'],24.6)
    def test_high_prior_uses_negative_result(self):
        r=utilities(.8);self.assertEqual(r['negative_followup'],'continue');self.assertAlmostEqual(r['test_utility'],67);self.assertAlmostEqual(r['continue_utility'],72)
    def test_no_information_test(self):
        for q in (0,.2,.4,.8,1):self.assertAlmostEqual(utilities(q,0,.5,.5)['gross_information_value'],0)
    def test_information_nonnegative_before_cost(self):
        for i in range(101):self.assertGreaterEqual(utilities(i/100)['gross_information_value'],-1e-10)
    def test_perfect_test(self):self.assertAlmostEqual(utilities(.2,0,1,1)['test_utility'],20)
    def test_reject_invalid(self):
        with self.assertRaises(ValueError):utilities(1.1)
        with self.assertRaises(ValueError):scope_check({}, {})

if __name__=='__main__':unittest.main()
