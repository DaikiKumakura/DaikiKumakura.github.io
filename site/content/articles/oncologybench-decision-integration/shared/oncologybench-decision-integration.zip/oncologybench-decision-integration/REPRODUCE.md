# Scope checks and hypothetical project decisions

Original controlled metadata fixtures and risk-neutral project-level arithmetic. No LLM runs, clinical raw data, treatment recommendations, or reproduction of the 25 benchmark evaluations.

Python 3.12, NumPy 1.26.4, Matplotlib 3.9.1:

```sh
python analysis.py
python -m unittest test_analysis.py
python plot.py
```

Offline execution uses fixtures.json and source-structure.json. Five result files and two figures are generated. Seven fixtures are hand authored; counts are not accuracy estimates. Exact metadata equality is not evidence of efficacy, causal validity or a programme Go decision. None means unrecorded, including when a claim explicitly preserves that state.

The source aggregate describes two public example JSONs, not the full benchmark. Grader leaves are not independent required tests: container and alternative semantics matter. To verify the aggregate against source files, explicitly run `python audit_sources.py --fetch`. This fetches pinned public JSONs into sources/ and regenerates source-structure.json; it never executes their graders. Source SHA-256 values are recorded in the aggregate. Raw tasks and answer keys are not bundled.

Decision model: q is a hypothetical probability of eventual project success. Continue earns +100 on success and -40 on failure; stop earns 0. A binary experiment costs 5, sensitivity .8, specificity .9, conditional on eventual project state. Post-result actions are chosen separately. Expected utility is max(84q-4,0)+max(56q-36,0)-5 for testing, 140q-40 for direct continuation. There is no estimation or empirical calibration. Assumptions include known probabilities and utility, risk neutrality, two states, three actions, no delay or competing budget needs.

Grid q=0,.01,...,1. Sensitivity: cost=0,5,20 crossed with sensitivity/specificity=(.6,.6),(.8,.9),(.95,.95), yielding 909 rows. Different plotting versions may change image bytes. No network or GPU is required for ordinary reproduction.

Sources: https://blog.latch.bio/p/oncologybench-benchmarking-ai-decisions ; https://latch.bio/oncologybench ; https://github.com/latchbio/oncologybench/tree/c576d11144db9a5b2f8461d469e24ac05af2386a . Retrieved 2026-10-14. Authors' performance figures are not recalculated here.
