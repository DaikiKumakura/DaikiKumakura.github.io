"""Read-only structural audit of frozen public examples. Never runs graders."""
from pathlib import Path
import argparse,hashlib,json,urllib.request
from analysis import grader_structure

HERE=Path(__file__).resolve().parent
SHA='c576d11144db9a5b2f8461d469e24ac05af2386a'
NAMES=('coad_postop_board_dpyd','tgfb_pdl1_programme_review')

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--fetch',action='store_true');ap.add_argument('--source-dir',type=Path,default=HERE/'sources');args=ap.parse_args();args.source_dir.mkdir(exist_ok=True,parents=True)
    rows=[];records=[]
    for name in NAMES:
        path=args.source_dir/f'{name}.json';u=f'https://raw.githubusercontent.com/latchbio/oncologybench/{SHA}/evals/{name}.json'
        if args.fetch:
            with urllib.request.urlopen(u,timeout=30) as r:path.write_bytes(r.read())
        blob=path.read_bytes();doc=json.loads(blob)
        rows.append(dict(example=name,**grader_structure(doc)));records.append(dict(example=name,url=u,sha256=hashlib.sha256(blob).hexdigest()))
    out=dict(commit=SHA,examples=rows,source_records=records,scope='Only the two public examples, not full benchmark',raw_tasks_redistributed=False)
    (HERE/'source-structure.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(rows,indent=2))

if __name__=='__main__':main()
