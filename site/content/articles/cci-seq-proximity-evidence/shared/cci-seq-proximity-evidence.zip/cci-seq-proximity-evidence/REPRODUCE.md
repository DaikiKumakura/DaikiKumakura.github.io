# CCI-seqの共存数とFrequencyの監査

原著：Tang L, Tian K, Fu X et al. Resolving cell–cell interaction networks and their molecular logic in complex tissues. Nature Methods 23, 2042–2053 (2026). https://doi.org/10.1038/s41592-026-03237-0 . 公開固定記録：https://doi.org/10.5281/zenodo.19544434 。コードrevision327725c97d82e8918d880e439d57e4133cfa93d4。

対象はマウス腎臓の加工済み注釈とCell-ID、原著の異型ペアFrequency表。ヒトCRCのraw reads、発現由来ligand–receptor推論、画像の再解析、因果的な通信検証は範囲外。引用と元ライセンス通知はTHIRD_PARTY_NOTICES.mdに収録。

## 同梱データから再計算

Python3.12・numpy1.26.4、図にmatplotlibで検証。

```sh
python analysis.py
python -m unittest test_analysis.py
python plot.py
```

cell-metadata.csvにはQC=1の11519細胞の元行番号、exp1〜3、置換したclump ID、17細胞型を収録。RNA発現、元のDNA/細胞barcodeは同梱していない。結果7ファイルと独自2図を再生成する。11テストが、異型ペアの重み、欠けた細胞型、singleton、有限標本の期待値の全列挙、非ゼロかつ同順位を含むMonte Carlo P値などを検査する。

## 元の公開メタデータから再抽出

```sh
python fetch_data.py
python prepare_data.py
```

fetch_data.pyはHTTP Rangeを使って、約396MBと175MBのZIP全量の代わりに必要な7メンバーを取得する。ZIPのCRC32と展開後SHA-256を照合する。全アーカイブの公開MD5を独立検証したという意味ではない。HTTP Range非対応なら処理を停止する。取得した第三者ノートの実行は行わない。source_membersに固定URL、member名、サイズ、CRC32、SHA-256を記録した。

prepare_data.pyは元20824行からqc=1を選択。CellIDが非欠損、exp=batch、同一IDが実験を跨がないことを検査し、各実験内のIDを辞書順で連番へ置換する。source_rowは0始まりの元データ行番号。母数の詳細はdata-summary.jsonを参照する。cell-metadata.csv/data-summary.jsonのSHA-256はinput-provenance.jsonのinput_hashesと比較でき、検証時は一致した。

published-frequency.csvは原著の異型ペア表を並べ替えた参照数値。原著interaction/intensity.txtとSourceData Fig.2/2e.txtのバイト一致を確認。17型の136異型ペアのうち、Tを含む16ペアは分母が0で元表も欠測。残り120ペアを比較し、最大絶対差は約7.1e-15（許容1e-10）。欠測を0の相互作用としない。

## 母数と帰無の定義

原著ノートはsingletonsを除いたmulti-cell clumpにあるcell数をFrequencyの母数にしている。そのため主解析は5731細胞・1927clumpで、11519細胞全体を分母に使わない。17型のうちTの7細胞はすべてsingletonで、主解析でのTのFrequencyは定義できない。

異型A,Bについて、各clumpのnA*nB/choose(size,2)を足したweighted sum W、共存clump数（少なくとも1Aと1B）、raw cell-pair数（nA*nBの和）を別々に算出。Frequency=100*W/sqrt(NA*NB)。方向性、全ペアの直接接触、通信の確率を示す値ではない。同型ペアは今回の対象外。

固定cell数N、A/B数NA/NBをclump位置へ一様に再割付する場合、各multi-cell clumpの重みの期待は2*NA*NB/[N*(N−1)]。したがって期待weighted sumはmulti-cell clump数を掛けた値。全実験を混ぜるglobal nullと、実験内でのみ混ぜるblocked nullを区別し、blocked期待は各実験の厳密期待を合計する。分子と期待の両方に同じ正規化を使えば、W/expected WはFrequencyの観測/期待比と一致する。

Monte Carloはseed1729・1999回、各反復内のみcell labelsを置換。P=(1+#W_perm>=W_obs)/(1999+1)。最小値0.0005で、0にはならない。原著の1000回・厳密不等号・全実験プールのP値とは定義が異なる。MC平均とそのSEはnull-expectation-checks.csvに保存し、厳密期待と照合できる。MC誤差は生物学的な推定不確実性ではない。

## 探索性・感度・制限

PST–BとCD-PC–CD-ICを原著の例から選んだ、事後的なケース監査。新規相互作用の発見やconfirmatory検定ではない。136ペア全体を探索して多重性を調整した検定とも言わない。3実験は生物学的反復、1999は乱数置換の回数で別の単位。独立clumpという仮定で臨床的なCIを作っていない。

size2、size2〜5、size2〜20、singleton込みの感度解析では、そのsubset内のcell数・型数・clump数で期待を再計算する。比較対象母集団が変わるため、同じeffect sizeの単純なrobustness試験ではない。回収した細胞数は元の物理的なclumpサイズと一致するとは限らず、2cell clumpでも直接接触が証明されるわけではない。leave-one-replicate-outでも母数・期待を再計算する。

ラベル置換はcell型比率と回収clumpサイズだけを保存し、腎臓の領域、解剖学的配置、細胞型別の解離・回収・QCバイアスを保存しない。上振れした値はこの帰無に対する共存濃縮であり、物理接触や因果通信の証明ではない。PST–Bは主解析B=8細胞、共存6clump。exp1には主解析でのBがなく、そのFrequency/比/P値は欠測として残す。
