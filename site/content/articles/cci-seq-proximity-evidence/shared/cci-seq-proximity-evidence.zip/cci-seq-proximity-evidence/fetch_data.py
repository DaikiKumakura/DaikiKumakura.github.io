"""Fetch selected members of immutable public ZIPs; no third-party code execution."""
from pathlib import Path
import urllib.request,zipfile,hashlib,json
P=Path(__file__).resolve().parent

class RangeFile:
    def __init__(self,url,size):self.url=url;self.size=size;self.pos=0
    def seek(self,offset,whence=0):
        self.pos=offset if whence==0 else self.pos+offset if whence==1 else self.size+offset
        if not 0<=self.pos<=self.size:raise ValueError('invalid ZIP seek')
        return self.pos
    def tell(self):return self.pos
    def seekable(self):return True
    def read(self,n=-1):
        n=self.size-self.pos if n<0 else min(n,self.size-self.pos)
        if n<=0:return b''
        req=urllib.request.Request(self.url,headers={'Range':f'bytes={self.pos}-{self.pos+n-1}'})
        with urllib.request.urlopen(req,timeout=90) as f:
            if f.status!=206:raise ValueError('server did not honor byte range')
            b=f.read()
        if len(b)!=n:raise ValueError('wrong range length')
        self.pos+=n;return b

def main():
    root=P/'sources';root.mkdir(exist_ok=True)
    d=json.loads((P/'input-provenance.json').read_text(encoding='utf-8'))
    for r in d['source_members']:
        out=(root/r['file']).resolve()
        if not out.is_relative_to(root.resolve()):raise ValueError('unsafe output path')
        if not out.exists():
            with zipfile.ZipFile(RangeFile(r['url'],r['archive_bytes'])) as z:
                i=z.getinfo(r['member'])
                if i.CRC!=r['crc32'] or i.file_size!=r['bytes']:raise ValueError('member metadata changed')
                out.write_bytes(z.read(r['member']))
        if out.stat().st_size!=r['bytes'] or hashlib.sha256(out.read_bytes()).hexdigest()!=r['sha256']:raise ValueError('input hash mismatch')
        print('verified',r['file'])
if __name__=='__main__':main()
