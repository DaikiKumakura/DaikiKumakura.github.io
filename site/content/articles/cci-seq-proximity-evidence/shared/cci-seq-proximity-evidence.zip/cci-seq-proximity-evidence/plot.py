"""Original plots; counts and subset-specific random-label enrichment."""
from pathlib import Path
import json
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
P=Path(__file__).resolve().parent;F=P/'figures';F.mkdir(exist_ok=True)
s=json.loads((P/'results/summary.json').read_text())
fig,axs=plt.subplots(2,1,figsize=(7.4,7.2))
for ax,pair,title in zip(axs,['PST--B','CD-PC--CD-IC'],['PST - B cells','CD-PC - CD-IC']):
    r=[r for r in s['pair_results'] if r['pair']==pair and r['scope']!='pooled'];x=np.arange(3)
    a=ax.bar(x-.18,[r['co_clumps'] for r in r],width=.35,color='#337e89',label='Co-occurring clumps')
    b=ax.bar(x+.18,[r['raw_cell_pairs'] for r in r],width=.35,color='#b87742',label='Cell pairs within those clumps')
    ax.bar_label(a,padding=3,fontsize=10);ax.bar_label(b,padding=3,fontsize=10)
    ax.set_xticks(x,[f'{v["scope"]}\nA={v["n_a"]}, B={v["n_b"]}' for v in r]);ax.set_title(title);ax.set_ylabel('Count');ax.grid(axis='y',alpha=.15);ax.set_axisbelow(True)
    ax.set_ylim(0,max(v['raw_cell_pairs'] for v in r)*1.25+1);ax.spines[['top','right']].set_visible(False)
axs[0].legend(fontsize=9,loc='upper left')
fig.text(.5,.02,'A/B counts refer to cells recovered in multi-cell clumps, not all QC-passed cells.\nThree biological replicates. Cell-pair counts do not establish direct physical contacts.',ha='center',fontsize=8)
fig.tight_layout(rect=(0,.07,1,1));fig.savefig(F/'01-clumps-and-cell-pairs.png',dpi=160);plt.close(fig)
fig,ax=plt.subplots(figsize=(7.4,4.7))
keys=['size2','size2to5','size2to20','singleton_inclusive']
for pair,color,off in [('PST--B','#337e89',-.03),('CD-PC--CD-IC','#b87742',.03)]:
    r=[next(r for r in s['size_sensitivity'] if r['pair']==pair and r['subset']==k) for k in keys]
    ax.plot(np.arange(4)+off,[r['enrichment_blocked'] for r in r],'-o',c=color,label=pair)
ax.axhline(1,c='gray',ls='--',lw=1);ax.set_xticks(range(4),['2 cells','2-5 cells','2-20 cells','Including\nsingletons']);ax.set_ylabel('Observed / expected weighted co-occurrence\n(replicate-stratified random-label null)');ax.set_ylim(0,4.5);ax.legend();ax.grid(axis='y',alpha=.15);ax.spines[['top','right']].set_visible(False)
fig.text(.5,.02,'Each subset redefines the cell pool, clump counts and null expectation.\nRatios are descriptive, not probabilities of contact or communication; no confidence intervals.',ha='center',fontsize=8)
fig.tight_layout(rect=(0,.1,1,1));fig.savefig(F/'02-subset-and-denominator-sensitivity.png',dpi=160);plt.close(fig)
