"""Own co-clump arithmetic and replicate-stratified random-label null."""
from pathlib import Path
from collections import Counter,defaultdict
import csv,json,math,itertools
import numpy as np
P=Path(__file__).resolve().parent
PAIRS=(('PST','B'),('CD-PC','CD-IC'))

def pair_weight(na,nb,size):
    if size<2 or na<0 or nb<0 or na+nb>size:raise ValueError('invalid heterotypic clump')
    return na*nb/(size*(size-1)/2)

def expected_weight_sum(n,na,nb,g):
    if n<2 or min(na,nb,g)<0 or na+nb>n:raise ValueError('invalid null counts')
    return g*2*na*nb/(n*(n-1))

def frequency(w,na,nb):
    return 100*w/math.sqrt(na*nb) if na>0 and nb>0 else None

def monte_carlo_p(observed,permuted):
    a=np.asarray(permuted,dtype=float)
    if len(a)==0 or not np.isfinite(a).all():raise ValueError('invalid permutations')
    return (1+int(np.sum(a>=observed)))/(len(a)+1)

def encode(rows):
    ids=sorted({r['clump'] for r in rows});lookup={x:i for i,x in enumerate(ids)}
    group=np.array([lookup[r['clump']] for r in rows]);labels=np.array([r['celltype'] for r in rows])
    size=np.bincount(group,minlength=len(ids));den=size*(size-1)/2
    return ids,group,labels,size,den

def pair_stat(rows,a,b):
    ids,g,l,size,den=encode(rows)
    ca=np.bincount(g,weights=(l==a),minlength=len(ids));cb=np.bincount(g,weights=(l==b),minlength=len(ids))
    take=size>=2;weights=np.zeros(len(ids));weights[take]=ca[take]*cb[take]/den[take]
    na=int((l==a).sum());nb=int((l==b).sum());w=float(weights.sum())
    return dict(cells=len(rows),clumps=len(ids),multiplet_clumps=int(take.sum()),n_a=na,n_b=nb,co_clumps=int(((ca>0)&(cb>0)).sum()),raw_cell_pairs=int((ca*cb).sum()),weighted_sum=w,frequency=frequency(w,na,nb),expected_global=expected_weight_sum(len(rows),na,nb,int(take.sum())) if len(rows)>=2 else 0)

def select(rows,lo=2,hi=20):
    sizes=Counter(r['clump'] for r in rows)
    return [r for r in rows if lo<=sizes[r['clump']]<=hi]

def summarize(rows,a,b):
    d=pair_stat(rows,a,b);by=defaultdict(list)
    for r in rows:by[r['replicate']].append(r)
    blocked=sum(pair_stat(rs,a,b)['expected_global'] for rs in by.values())
    d.update(expected_blocked=blocked,enrichment_global=d['weighted_sum']/d['expected_global'] if d['expected_global']>0 else None,enrichment_blocked=d['weighted_sum']/blocked if blocked>0 else None)
    return d

def write(path,rows):
    with path.open('w',newline='',encoding='utf-8') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)

def main():
    allrows=list(csv.DictReader((P/'cell-metadata.csv').open(encoding='utf-8')))
    assert len(allrows)==11519 and len({r['source_row'] for r in allrows})==len(allrows)
    rows=select(allrows);assert len(rows)==5731
    reps=sorted({r['replicate'] for r in rows})
    results=[];sens=[];loo=[];network=[]
    for a,b in PAIRS:
        for scope in reps+['pooled']:
            sub=[r for r in rows if scope=='pooled' or r['replicate']==scope]
            results.append(dict(pair=f'{a}--{b}',scope=scope,**summarize(sub,a,b)))
        for name,lo,hi in [('size2',2,2),('size2to5',2,5),('size2to20',2,20),('singleton_inclusive',1,20)]:
            sens.append(dict(pair=f'{a}--{b}',subset=name,**summarize(select(allrows,lo,hi),a,b)))
        for rep in reps:loo.append(dict(pair=f'{a}--{b}',excluded_replicate=rep,**summarize([r for r in rows if r['replicate']!=rep],a,b)))
    types=sorted({r['celltype'] for r in allrows})
    for a,b in itertools.combinations(types,2):network.append(dict(type_a=a,type_b=b,**summarize(rows,a,b)))
    published=list(csv.DictReader((P/'published-frequency.csv').open(encoding='utf-8')))
    assert len(published)==len(network)==136
    truth={(r['type_a'],r['type_b']):float(r['frequency']) if r['frequency'] else None for r in published}
    assert all((r['frequency'] is None)==(truth[(r['type_a'],r['type_b'])] is None) for r in network)
    error=max(abs(r['frequency']-truth[(r['type_a'],r['type_b'])]) for r in network if r['frequency'] is not None)
    assert error<1e-10
    rng=np.random.default_rng(1729);nperm=1999
    blocks={rep:encode([r for r in rows if r['replicate']==rep]) for rep in reps}
    samples={rep:np.zeros((nperm,2)) for rep in reps}
    for k in range(nperm):
        for rep,(_,group,labels,size,den) in blocks.items():
            shuffled=rng.permutation(labels)
            for j,(a,b) in enumerate(PAIRS):
                ca=np.bincount(group,weights=(shuffled==a),minlength=len(size));cb=np.bincount(group,weights=(shuffled==b),minlength=len(size))
                samples[rep][k,j]=np.sum(ca*cb/den)
    samples['pooled']=sum(samples.values())
    permutation=[];null_checks=[]
    for r in results:
        j=[f'{a}--{b}' for a,b in PAIRS].index(r['pair']);x=samples[r['scope']][:,j]
        if r['expected_blocked']>0:
            p=monte_carlo_p(r['weighted_sum'],x);mc_mean=float(x.mean());mc_se=float(x.std(ddof=1)/np.sqrt(nperm));r.update(upper_mc_p=p,mc_mean=mc_mean,mc_mean_se=mc_se)
            null_checks.append(dict(pair=r['pair'],scope=r['scope'],analytic=r['expected_blocked'],mc_mean=mc_mean,mc_mean_se=mc_se))
        else:r.update(upper_mc_p=None,mc_mean=0.0,mc_mean_se=0.0)
        for k,v in enumerate(x):permutation.append(dict(pair=r['pair'],scope=r['scope'],permutation=k,weighted_sum=float(v)))
    out=P/'results';out.mkdir(exist_ok=True)
    for name,data in [('pair-summary.csv',results),('size-sensitivity.csv',sens),('leave-one-replicate-out.csv',loo),('network-descriptive.csv',network),('permutation-samples.csv',permutation),('null-expectation-checks.csv',null_checks)]:write(out/name,data)
    summary=dict(qualified_cells=len(allrows),multiplet_cells=len(rows),multiplet_clumps=len({r['clump'] for r in rows}),biological_replicates=len(reps),max_published_frequency_error=error,defined_published_pairs=sum(r['frequency'] is not None for r in network),undefined_pairs=sum(r['frequency'] is None for r in network),n_permutations=nperm,seed=1729,pair_results=results,size_sensitivity=sens,leave_one_replicate_out=loo,scope='Exploratory, paper-selected cases on published QC metadata. Co-clump proximity is not all-pairs direct contact or causal communication. Random-label null preserves recovered clump sizes and marginal counts, not spatial anatomy or recovery biases. Primary denominator excludes singleton cells as in source notebook.')
    (out/'summary.json').write_text(json.dumps(summary,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({k:summary[k] for k in ('qualified_cells','multiplet_cells','multiplet_clumps','max_published_frequency_error','pair_results','size_sensitivity','leave_one_replicate_out')},indent=2))
if __name__=='__main__':main()
