import unittest,itertools
import numpy as np
from analysis import pair_weight,expected_weight_sum,frequency,monte_carlo_p,pair_stat,select

class CoClumpTests(unittest.TestCase):
    def test_two_cells(self):self.assertEqual(pair_weight(1,1,2),1)
    def test_three_cells(self):self.assertAlmostEqual(pair_weight(1,1,3),1/3)
    def test_large_clump_is_not_one_contact(self):self.assertAlmostEqual(pair_weight(2,1,4),1/3)
    def test_invalid_counts(self):
        with self.assertRaises(ValueError):pair_weight(2,2,3)
    def test_absent_type_frequency(self):self.assertIsNone(frequency(0,3,0))
    def test_frequency_scale(self):self.assertEqual(frequency(2,2,2),100)
    def test_exact_null_enumeration(self):
        # Two 2-cell clumps; fixed A,A,B,B labels, six distinct assignments.
        values=[]
        for idx in itertools.combinations(range(4),2):
            labels=np.zeros(4,int);labels[list(idx)]=1
            values.append(sum(pair_weight(int(labels[i:i+2].sum()),2-int(labels[i:i+2].sum()),2) for i in (0,2)))
        self.assertAlmostEqual(np.mean(values),expected_weight_sum(4,2,2,2))
    def test_p_never_zero(self):self.assertEqual(monte_carlo_p(2,[0,1,1]),.25)
    def test_p_includes_ties(self):self.assertEqual(monte_carlo_p(1,[0,1,2]),.75)
    def test_clump_count_vs_cell_pairs(self):
        r=[dict(clump='x',celltype=t,replicate='r') for t in ['A','A','B']]
        d=pair_stat(r,'A','B');self.assertEqual(d['co_clumps'],1);self.assertEqual(d['raw_cell_pairs'],2)
    def test_singleton_selection(self):
        r=[dict(clump=c,celltype='A',replicate='r') for c in ['x','x','y']];self.assertEqual(len(select(r)),2)

if __name__=='__main__':unittest.main()
