# Data source and attribution

Tang L, Tian K, Fu X et al. (2026). Resolving cell–cell interaction networks and their molecular logic in complex tissues. Nature Methods 23, 2042–2053. https://doi.org/10.1038/s41592-026-03237-0 . Public archive https://doi.org/10.5281/zenodo.19544434 .

The cell metadata was reduced from Fig.2/result.txt; clump identifiers were replaced by deterministic labels. The frequency reference table was reorganized from Fig.2/interaction/intensity.txt, identical to Fig.2/2e.txt in SourceData. The archive records an MIT license. Third-party notice follows; our LICENSE does not relicense third-party materials.

MIT License

Copyright (c) 2026 Zhang Lab @Tsinghua University, School of Life Sciences

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
