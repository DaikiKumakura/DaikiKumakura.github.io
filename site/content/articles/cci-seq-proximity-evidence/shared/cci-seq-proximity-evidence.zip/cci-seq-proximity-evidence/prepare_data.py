"""Own reduction of public mouse kidney cell metadata; no expression matrix."""
from pathlib import Path
import csv,json
from collections import Counter,defaultdict
P=Path(__file__).resolve().parent

def main():
    raw=list(csv.DictReader((P/'sources/Fig.2__result.txt').open(encoding='utf-8'),delimiter='\t'))
    assert len(raw)==20824
    good=[(i,r) for i,r in enumerate(raw) if r['qc']=='1']
    assert len(good)==11519
    assert all(r['CellID'] and r['celltype'] and r['exp']==r['batch'] for i,r in good)
    identities={r['CellID'] for i,r in good};keys={(r['exp'],r['CellID']) for i,r in good}
    assert len(identities)==len(keys)  # Source already suffixes IDs with experiment.
    maps={rep:{cid:f'{rep}:c{j:06d}' for j,cid in enumerate(sorted({r['CellID'] for i,r in good if r['exp']==rep}),1)} for rep in ('exp1','exp2','exp3')}
    rows=[dict(source_row=i,replicate=r['exp'],clump=maps[r['exp']][r['CellID']],celltype=r['celltype']) for i,r in good]
    sizes=Counter(r['clump'] for r in rows)
    assert max(sizes.values())<=20
    with (P/'cell-metadata.csv').open('w',newline='',encoding='utf-8') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
    summary=dict(source_rows=len(raw),qualified_cells=len(rows),excluded_qc_rows=len(raw)-len(rows),cell_types=len({r['celltype'] for r in rows}),clumps=len(sizes),singleton_clumps=sum(v==1 for v in sizes.values()),multiplet_clumps=sum(v>=2 for v in sizes.values()),multiplet_cells=sum(v for v in sizes.values() if v>=2),max_recovered_clump_size=max(sizes.values()),replicate_cells=dict(Counter(r['replicate'] for r in rows)),type_cells=dict(Counter(r['celltype'] for r in rows)),clump_size_counts=dict(sorted(Counter(sizes.values()).items())),scope='Published QC=1 cells; reduced metadata. Original barcodes replaced by deterministic clump labels. Recovered clump size is not original physical clump size.')
    (P/'data-summary.json').write_text(json.dumps(summary,indent=2)+'\n',encoding='utf-8');print(json.dumps(summary,indent=2))
if __name__=='__main__':main()
