# Initial-record mercaptopurine ANC forecasting

Public source: Jost et al. 2020, Front Physiol11:217,
DOI https://doi.org/10.3389/fphys.2020.00217 (CC BY).
00_acquire.py retrieves the public observed-event CSV with SHA256 verification,
no account or credentials. Original patient rows, IPRED, original EBEs and papers
are not redistributed. Source data are not the CRP-filtered4747 observations in
the paper: the CSV contains5897 and has no CRP/exclusion flag.

Uses existing Python numeric runtime; exact versions in outputs/environment.json.
Install requirements.txt in your chosen environment.
Run from this directory, in order:
python analysis/00_acquire.py
python analysis/01_prepare.py
python analysis/02_fit.py
python analysis/03_report.py
python analysis/05_verify.py
python -m unittest discover -s analysis -p "test_*.py" -q

Population fitting uses four CPU threads and two starts; no GPU or large virtual cohort.
Training60/calibration20/test36 patients, seed20261018;59 actually fitted,
17 calibration and31 test eligible for day84-to112 comparisons.
Use original treatment day; observations<=84 only for individual MAP.
PK constants fixed to Table2 day-unit convention; Table2/Eq2 coefficient disagreement
is unresolved, and E is a latent input scale, not a verified measured concentration.
Random effect is baseline only. Slope SD1e-9 is a numerical representation of fixed0.
Gamma reaches upper bound1.2; starts differ. No globally identified physiological model claimed.
Calibration bands are empirical record-wise absolute-log-error quantiles, not
fully Bayesian or guaranteed patient-level conformal intervals.
Constant-dose scenario disagrees with future recorded doses in24/31 test patients;
its errors are not counterfactual validation. Future-record-dose scenario is retrospective.
No dose-policy simulation: predeclared predictive gate failed.
Outputs/tables contain aggregate results only; data/processed contains individual
intermediates after local rerun and is intentionally excluded from this download.

Slight platform-dependent differences in local optima are possible. Saved outputs
report the executed run; do not silently replace them by an unreported new fit.
Figures and source code in this bundle are original.
