"""Structural, numerical and information-boundary tests."""
import unittest
import numpy as np
import pandas as pd
from model import prepare_patient,predict,individual_map

def synthetic():
    rows=[]
    for day in range(113):
        rows.append(dict(ID=1,TIME=day+.79,DV=0.,AMT=50.,EVID=1,BSA=1.))
    for day in [0,14,28,42,56,70,83,90,100,110]:
        rows.append(dict(ID=1,TIME=day+.42,DV=2.,AMT=0.,EVID=0,BSA=1.))
    return pd.DataFrame(rows)

class ModelTests(unittest.TestCase):
    def test_zero_input_homeostasis(self):
        p=prepare_patient(synthetic().query('EVID==0'),112)
        out=predict(p.grid,p.exposure,np.array([2.,.2,.15,.5]))
        np.testing.assert_allclose(out,2,rtol=1e-10)
    def test_step_refinement(self):
        a=prepare_patient(synthetic(),112,step=.25)
        b=prepare_patient(synthetic(),112,step=.125)
        th=np.array([2.,.2,.15,.5])
        ya=predict(a.grid,a.exposure,th)[a.obs_index]
        yb=predict(b.grid,b.exposure,th)[b.obs_index]
        self.assertLess(float(np.max(abs(ya-yb))),.002)
    def test_prefix_pk_not_changed_by_future(self):
        a=prepare_patient(synthetic(),112)
        altered=synthetic();altered.loc[(altered.EVID==1)&(altered.TIME>84),'AMT']=100
        b=prepare_patient(altered,112)
        th=np.array([2.,.2,.15,.5]);mask=a.grid<=84
        np.testing.assert_allclose(predict(a.grid,a.exposure,th)[mask],predict(b.grid,b.exposure,th)[mask],rtol=1e-10)
    def test_map_future_anc_is_not_input(self):
        a=prepare_patient(synthetic(),112)
        altered=synthetic();altered.loc[(altered.EVID==0)&(altered.TIME>84),'DV']=100
        b=prepare_patient(altered,112)
        par=np.array([2.,.2,.15,.5,.3,.5,.5])
        _,ra=individual_map(a,par);_,rb=individual_map(b,par)
        np.testing.assert_allclose(ra.x,rb.x,atol=1e-9)
    def test_held_input_ignores_future_dose(self):
        a=prepare_patient(synthetic(),112,held_after=84)
        altered=synthetic();altered.loc[(altered.EVID==1)&(altered.TIME>84),'AMT']=100
        b=prepare_patient(altered,112,held_after=84)
        np.testing.assert_allclose(a.exposure,b.exposure)

if __name__=='__main__':unittest.main()
