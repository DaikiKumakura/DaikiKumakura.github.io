"""Download the CC BY public observed-event supplement without account or credentials."""
from pathlib import Path
import hashlib
import io
import json
from urllib.request import urlopen
import zipfile

ROOT=Path(__file__).resolve().parents[1]
URL='https://www.ebi.ac.uk/europepmc/webservices/rest/PMC7093595/supplementaryFiles'
EXPECTED='d8d500b5bc0dd7e6b32a20e175a8c0f00ccfb58b45f561f6a497ed5a2a56cc4f'

def main():
    target=ROOT/'data/raw/Data_Sheet_2.CSV'
    if not target.exists():
        target.parent.mkdir(parents=True,exist_ok=True)
        with urlopen(URL,timeout=120) as response:
            z=zipfile.ZipFile(io.BytesIO(response.read()))
        data=z.read('Data_Sheet_2.CSV')
        assert hashlib.sha256(data).hexdigest()==EXPECTED
        target.write_bytes(data)
    assert hashlib.sha256(target.read_bytes()).hexdigest()==EXPECTED
    print(json.dumps(dict(source='Jost et al. 2020, DOI 10.3389/fphys.2020.00217',license='CC BY',sha256=EXPECTED)))

if __name__=='__main__':main()
