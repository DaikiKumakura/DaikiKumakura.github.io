"""Train on separate patients, calibrate, then freeze held-out comparisons."""
from pathlib import Path
import json,time,platform
import numpy as np
import pandas as pd
import scipy,matplotlib,numba
from scipy.optimize import minimize
from model import prepare_patient,objective,predict,individual_map

ROOT=Path(__file__).resolve().parents[1]
BOUNDS=np.log([(0.3,8),(.001,2),(.04,.5),(.05,1.2),(.03,1.2),(1e-9,1e-9),(.1,1.5)])

def main():
    tic=time.perf_counter()
    d=pd.read_csv(ROOT/'data/processed/events.csv');splits=json.loads((ROOT/'data/processed/split.json').read_text())
    groups={int(i):f for i,f in d.groupby('ID')}
    train=[]
    for pid,e in groups.items():
        if splits[str(pid)]=='train':
            p=prepare_patient(e)
            if len(p.obs)>=4:train.append(p)
    print('Training patients',len(train),flush=True)
    fits=[]
    for n,init in enumerate([[1.72,.01,.25,.34,.28,1e-9,.49],[2,.1,.2,.3,.3,1e-9,.6]]):
        calls=[0]
        def fun(x):
            val=objective(x,train,17);calls[0]+=1
            if calls[0]%80==0:print('start',n,'eval',calls[0],'nll',round(val,2),flush=True)
            return val
        result=minimize(fun,np.log(init),method='L-BFGS-B',bounds=BOUNDS.tolist(),options={'maxiter':80,'ftol':1e-6,'maxls':25})
        fits.append(result);print('Fit',n,result.success,result.fun,np.exp(result.x),flush=True)
    fit=min(fits,key=lambda r:r.fun)
    par=np.exp(fit.x)
    check_nll=objective(fit.x,train,25)
    info=dict(parameters=par.tolist(),names=['baseline','slope','ktr','gamma','omega_baseline','omega_slope','sigma_log'],
              training_patients=len(train),nll=float(fit.fun),check_nll=float(check_nll),fit_quadrature_order=17,check_quadrature_order=25,random_effects='baseline only; slope variability removed after training-only boundary diagnostic',
              success=bool(fit.success),message=str(fit.message),
              starts=[dict(nll=float(r.fun),success=bool(r.success)) for r in fits],
              elapsed_seconds=time.perf_counter()-tic)
    (ROOT/'outputs/fit.json').write_text(json.dumps(info,indent=2)+'\n')
    # Calibration/test output uses only pre-cutoff observations for individual MAP.
    elig=pd.read_csv(ROOT/'data/processed/eligibility.csv')
    records=[];maps=[]
    for row in elig.itertuples():
        if not row.eligible or row.split=='train':continue
        e=groups[row.id]
        o=e[(e.EVID==0)&(e.DV>0)]
        last=float(o[o.TIME<=84].sort_values('TIME').DV.iloc[-1])
        future=o[(o.TIME>84)&(o.TIME<=112)]
        before=e[(e.EVID==1)&(e.TIME<=84)].sort_values('TIME')
        lastdose=float(before.AMT.iloc[-1])
        future_dose=e[(e.EVID==1)&(e.TIME>84)&(e.TIME<=112)]
        changed=bool(np.any(abs(future_dose.AMT-lastdose)>.01) or len(future_dose)<27)
        for scenario in ['frozen_dose','recorded_future_dose']:
            p=prepare_patient(e,112,held_after=84 if scenario=='frozen_dose' else None)
            pred,mapfit=individual_map(p,par)
            pop=predict(p.grid,p.exposure,par[:4])
            chosen=p.grid[p.obs_index]>84
            maps.append(dict(id=row.id,scenario=scenario,success=bool(mapfit.success),eta_base=float(mapfit.x[0]),eta_slope=float(mapfit.x[1])))
            for idx,actual in zip(p.obs_index[chosen],p.obs[chosen]):
                records.append(dict(id=row.id,split=row.split,scenario=scenario,time=float(p.grid[idx]),actual=float(actual),
                    individual=float(pred[idx]),population=float(pop[idx]),last_anc=last,recorded_dose_changed=changed))
    pd.DataFrame(records).to_csv(ROOT/'data/processed/predictions.csv',index=False)
    pd.DataFrame(maps).to_csv(ROOT/'data/processed/map-diagnostics.csv',index=False)
    (ROOT/'outputs/environment.json').write_text(json.dumps(dict(python=platform.python_version(),numpy=np.__version__,pandas=pd.__version__,scipy=scipy.__version__,matplotlib=matplotlib.__version__,numba=numba.__version__),indent=2)+'\n')
    print(json.dumps(info,indent=2),flush=True)

if __name__=='__main__':main()
