"""Patient-equal held-out metrics, cluster bootstrap and original figures."""
from pathlib import Path
import json
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

ROOT=Path(__file__).resolve().parents[1]
MODELS=['last_anc','population','individual']
LABELS={'last_anc':'Last observed ANC','population':'Population only','individual':'Individual MAP'}
COLORS={'last_anc':'#777777','population':'#0072B2','individual':'#D55E00'}

def main():
    d=pd.read_csv(ROOT/'data/processed/predictions.csv')
    assert (d.time>84).all() and (d.time<=112).all()
    rng=np.random.default_rng(20261018)
    scores=[];intervals=[];deltas=[]
    for scenario,g in d.groupby('scenario',sort=True):
        cal=g[g.split=='calibration'];test=g[g.split=='test']
        for model in MODELS:
            # All calibration records, log absolute error; no test-calibrated scale.
            radius=float(np.quantile(abs(np.log(cal.actual/cal[model])),.90,method='higher'))
            err=(test[model]-test.actual)
            temp=test.assign(abs_error=abs(err),sq_error=err**2,
                log_error=abs(np.log(test[model]/test.actual)),
                covered=abs(np.log(test.actual/test[model]))<=radius,
                width=test[model]*(np.exp(radius)-np.exp(-radius)))
            per=temp.groupby('id')[['abs_error','sq_error','log_error','covered','width']].mean()
            per.to_csv(ROOT/'data/processed'/f'patient-metrics-{scenario}-{model}.csv')
            bootstrap=rng.choice(per.index.to_numpy(),size=(2000,len(per)),replace=True)
            means=per.abs_error.loc[bootstrap.ravel()].to_numpy().reshape(bootstrap.shape).mean(axis=1)
            scores.append(dict(scenario=scenario,model=model,patients=len(per),records=len(test),
                mae=float(per.abs_error.mean()),mae_low=float(np.quantile(means,.025)),mae_high=float(np.quantile(means,.975)),
                rmse=float(np.sqrt(per.sq_error.mean())),mean_abs_log_error=float(per.log_error.mean()),
                coverage90=float(per.covered.mean()),mean_width=float(per.width.mean()),
                calibration_radius_log=radius,calibration_patients=int(cal.id.nunique()),calibration_records=len(cal)))
            intervals.append(temp.assign(model=model,lower90=test[model]*np.exp(-radius),upper90=test[model]*np.exp(radius)))
        base=(test.assign(error=abs(test.last_anc-test.actual)).groupby('id').error.mean())
        individual=(test.assign(error=abs(test.individual-test.actual)).groupby('id').error.mean())
        diff=(individual-base).sort_index()
        sampled=rng.choice(diff.to_numpy(),size=(2000,len(diff)),replace=True).mean(axis=1)
        deltas.append(dict(scenario=scenario,difference_individual_minus_last=float(diff.mean()),
            lower95=float(np.quantile(sampled,.025)),upper95=float(np.quantile(sampled,.975))))
    score=pd.DataFrame(scores);score.to_csv(ROOT/'outputs/tables/forecast-metrics.csv',index=False)
    pd.DataFrame(deltas).to_csv(ROOT/'outputs/tables/paired-differences.csv',index=False)
    pd.concat(intervals).to_csv(ROOT/'data/processed/intervals.csv',index=False)
    strata=[]
    for (scenario,changed),g in d[d.split=='test'].groupby(['scenario','recorded_dose_changed']):
        for m in MODELS:
            value=g.assign(error=abs(g[m]-g.actual)).groupby('id').error.mean()
            strata.append(dict(scenario=scenario,dose_changed=bool(changed),model=m,patients=len(value),mae=float(value.mean())))
    pd.DataFrame(strata).to_csv(ROOT/'outputs/tables/dose-history-strata.csv',index=False)
    fit=json.loads((ROOT/'outputs/fit.json').read_text())
    stable=bool(fit['success'] and abs(fit['check_nll']-fit['nll'])/fit['training_patients']<.1)
    policy_gate=stable and all(x['upper95']<0 for x in deltas) and all(score[(score.model=='individual')].coverage90>=.80)
    conclusion=dict(numerical_gate=stable,policy_gate=bool(policy_gate),policy_simulation='not performed' if not policy_gate else 'eligible for separate planned analysis',
                    deltas=deltas,eligible_test_patients=int(d[d.split=='test'].id.nunique()))
    (ROOT/'outputs/decision.json').write_text(json.dumps(conclusion,indent=2)+'\n')
    plt.rcParams.update({'font.size':10,'axes.spines.top':False,'axes.spines.right':False})
    fig,axs=plt.subplots(1,2,figsize=(10,4.5))
    for ax,(scenario,title) in zip(axs,[('frozen_dose','Last recorded dose held constant'),('recorded_future_dose','Actual future recorded doses (retrospective)')]):
        g=score[score.scenario==scenario].set_index('model').loc[MODELS]
        for j,m in enumerate(MODELS):
            r=g.loc[m];ax.errorbar(j,r.mae,yerr=[[r.mae-r.mae_low],[r.mae_high-r.mae]],fmt='o',color=COLORS[m],capsize=4)
        ax.set(xticks=range(3),xticklabels=['Last ANC','Population','Individual'],ylabel='Patient-equal MAE (G/L)',title=title,ylim=(0,None))
    fig.suptitle('Day 84–112: held-out patients; 95% patient-bootstrap intervals');fig.tight_layout();fig.savefig(ROOT/'outputs/figures/01-errors.png',dpi=180);plt.close(fig)
    fig,axs=plt.subplots(1,2,figsize=(10,4))
    for ax,(scenario,title) in zip(axs,[('frozen_dose','Constant-dose scenario'),('recorded_future_dose','Recorded-dose conditional scenario')]):
        g=score[score.scenario==scenario].set_index('model').loc[MODELS]
        ax.bar(range(3),g.coverage90*100,color=[COLORS[m] for m in MODELS]);ax.axhline(90,color='black',ls='--')
        ax.set(xticks=range(3),xticklabels=['Last ANC','Population','Individual'],ylabel='Patient-equal empirical coverage (%)',ylim=(0,100),title=title)
    fig.suptitle('90% log-error bands calibrated on separate patients');fig.tight_layout();fig.savefig(ROOT/'outputs/figures/02-coverage.png',dpi=180);plt.close(fig)
    # Select first three eligible test IDs before looking at their errors; display aliases only.
    chosen=sorted(d[d.split=='test'].id.unique())[:3]
    raw=pd.read_csv(ROOT/'data/processed/events.csv')
    fig,axs=plt.subplots(3,1,figsize=(10,8),sharex=True)
    for ax,pid,alias in zip(axs,chosen,['A','B','C']):
        o=raw[(raw.ID==pid)&(raw.EVID==0)&(raw.DV>0)&(raw.TIME<=112)]
        ax.scatter(o.TIME,o.DV,color='black',s=15,label='Observed ANC')
        g=d[(d.id==pid)&(d.split=='test')&(d.scenario=='frozen_dose')].sort_values('time')
        for m in MODELS:ax.plot(g.time,g[m],marker='o',label=LABELS[m],color=COLORS[m])
        ax.axvline(84,color='black',ls=':');ax.set(ylabel='ANC (G/L)',title=f'Example {alias}: first eligible IDs, not chosen by performance',ylim=(0,None))
    axs[0].legend(fontsize=8,ncol=2);axs[-1].set_xlabel('Maintenance treatment time (day)');fig.tight_layout();fig.savefig(ROOT/'outputs/figures/03-examples.png',dpi=180);plt.close(fig)
    print(score.to_string(index=False));print(json.dumps(conclusion,indent=2))

if __name__=='__main__':main()
