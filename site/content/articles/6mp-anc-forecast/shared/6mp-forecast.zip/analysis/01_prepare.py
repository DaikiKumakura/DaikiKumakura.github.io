"""Audit public observed-event data and freeze patient split before modeling."""
from pathlib import Path
import hashlib,json
import numpy as np
import pandas as pd

ROOT=Path(__file__).resolve().parents[1]
SEED=20261018

def main():
    for d in ['data/processed','outputs/tables','outputs/figures','docs']:(ROOT/d).mkdir(parents=True,exist_ok=True)
    raw=ROOT/'data/raw/Data_Sheet_2.CSV'
    d=pd.read_csv(raw,encoding='utf8')
    assert list(d)==['ID','TIME','DV','CMT','AMT','MDV','EVID','IPRED','WEIGHT','HEIGHT','BSA']
    assert not d.isna().any().any()
    assert d.duplicated().sum()==0
    assert set(d.EVID)=={0,1}
    o=d[d.EVID==0];dose=d[d.EVID==1]
    assert not o.duplicated(['ID','TIME']).any()
    assert not dose.duplicated(['ID','TIME']).any()
    assert (o.MDV==0).all() and (dose.MDV==1).all()
    assert (dose.AMT>0).all() and (d.BSA>0).all() and (o.DV>=0).all()
    ids=np.sort(d.ID.unique()).astype(int)
    assert len(ids)==116
    shuffled=np.random.default_rng(SEED).permutation(ids)
    split={str(int(i)):('train' if n<60 else 'calibration' if n<80 else 'test') for n,i in enumerate(shuffled)}
    # Permanently omit published predictions and anthropometric follow-up from model input.
    clean=d[['ID','TIME','DV','CMT','AMT','MDV','EVID','BSA']].copy()
    clean.ID=clean.ID.astype(int)
    clean.to_csv(ROOT/'data/processed/events.csv',index=False)
    (ROOT/'data/processed/split.json').write_text(json.dumps(split,indent=2)+'\n')
    counts=[]
    for i in ids:
        oi=o[o.ID==i];early=oi[(oi.TIME<=84)&(oi.DV>0)];future=oi[(oi.TIME>84)&(oi.TIME<=112)&(oi.DV>0)]
        counts.append(dict(id=int(i),split=split[str(i)],early_positive=len(early),future_positive=len(future),eligible=bool(len(early)>=4 and len(future)>=1)))
    pd.DataFrame(counts).to_csv(ROOT/'data/processed/eligibility.csv',index=False)
    report=dict(rows=len(d),patients=len(ids),dose_events=len(dose),observed_anc=len(o),zero_anc=int((o.DV==0).sum()),
        missing_cells=int(d.isna().sum().sum()),exact_duplicates=int(d.duplicated().sum()),
        observation_time_duplicates=int(o.duplicated(['ID','TIME']).sum()),
        eligible_by_split=pd.DataFrame(counts).groupby('split').eligible.sum().astype(int).to_dict(),
        sha256=hashlib.sha256(raw.read_bytes()).hexdigest(),source='https://doi.org/10.3389/fphys.2020.00217',
        supplement_api='https://www.ebi.ac.uk/europepmc/webservices/rest/PMC7093595/supplementaryFiles',
        license='CC BY, original article and supplement attribution retained',
        blocked_model_inputs=['IPRED','Data_Sheet_1.CSV'],
        assumption='Absence of a recorded dose event contributes zero recorded input; ingestion and missing-record status are not established.')
    (ROOT/'outputs/audit.json').write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps(report,indent=2))

if __name__=='__main__':main()
