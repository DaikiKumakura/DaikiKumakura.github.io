"""Numerical and information-boundary QA on held-out predictions."""
from pathlib import Path
import json
import numpy as np
import pandas as pd
from model import prepare_patient,predict,individual_map

ROOT=Path(__file__).resolve().parents[1]

def main():
    par=np.array(json.loads((ROOT/'outputs/fit.json').read_text())['parameters'])
    split=json.loads((ROOT/'data/processed/split.json').read_text())
    eligible=pd.read_csv(ROOT/'data/processed/eligibility.csv')
    d=pd.read_csv(ROOT/'data/processed/events.csv')
    pred=pd.read_csv(ROOT/'data/processed/predictions.csv')
    maps=pd.read_csv(ROOT/'data/processed/map-diagnostics.csv')
    errors=[];stress=[]
    for row in eligible.itertuples():
        if row.split!='test' or not row.eligible:continue
        e=d[d.ID==row.id]
        for scenario in ['frozen_dose','recorded_future_dose']:
            held=84 if scenario=='frozen_dose' else None
            p=prepare_patient(e,112,step=.125,held_after=held)
            eta=maps[(maps.id==row.id)&(maps.scenario==scenario)].iloc[0]
            theta=par[:4].copy();theta[:2]*=np.exp([eta.eta_base,eta.eta_slope])
            output=predict(p.grid,p.exposure,theta)[p.obs_index]
            mask=p.grid[p.obs_index]>84
            old=pred[(pred.id==row.id)&(pred.scenario==scenario)].sort_values('time')
            errors.extend(abs(output[mask]-old.individual.to_numpy()).tolist())
            assert np.allclose(old.time,p.grid[p.obs_index][mask])
            # Stress test only, not a refit or a resolution of the conflicting source units.
            alternative=prepare_patient(e,112,held_after=held,clearance_scale=1/24)
            alt_theta=theta.copy();alt_theta[1]/=24
            alt=predict(alternative.grid,alternative.exposure,alt_theta)[alternative.obs_index]
            stress.append(dict(id=row.id,scenario=scenario,
                mae_source_stress=float(np.mean(abs(alt[mask]-old.actual.to_numpy())))))
    a=maps[maps.scenario=='frozen_dose'].sort_values('id')
    b=maps[maps.scenario=='recorded_future_dose'].sort_values('id')
    assert np.array_equal(a.id,b.id)
    eta_difference=float(np.max(abs(a.eta_base.to_numpy()-b.eta_base.to_numpy())))
    assert eta_difference<1e-7
    assert (maps.success).all()
    assert max(errors)<.01
    assert 'IPRED' not in d
    assert set(split)==set(str(i) for i in d.ID.unique())
    result=dict(refinement_max_abs_anc_difference=float(max(errors)),
        refinement_mean_abs_difference=float(np.mean(errors)),
        scenario_eta_difference=eta_difference,map_successes=int(maps.success.sum()),
        map_total=len(maps),blocked_input_absent=True,
        source_stress={scenario:float(np.mean([r['mae_source_stress'] for r in stress if r['scenario']==scenario])) for scenario in ['frozen_dose','recorded_future_dose']},
        source_stress_definition='kE divided by24 and slope divided by24 with all other learned parameters/eta frozen; exploratory stress, not recalibration')
    (ROOT/'outputs/verification.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result,indent=2))

if __name__=='__main__':main()
