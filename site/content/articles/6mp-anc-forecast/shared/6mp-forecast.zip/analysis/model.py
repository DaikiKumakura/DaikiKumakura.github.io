"""Fixed-PK, estimated population-PD model with event-aware integration."""
from dataclasses import dataclass
import numpy as np
import pandas as pd
from scipy.linalg import expm
from scipy.special import logsumexp
from scipy.optimize import minimize
from numpy.polynomial.hermite import hermgauss
from numba import njit
from concurrent.futures import ThreadPoolExecutor

POOL=ThreadPoolExecutor(max_workers=4)

@dataclass
class Patient:
    pid:int
    grid:np.ndarray
    exposure:np.ndarray
    obs_index:np.ndarray
    obs:np.ndarray

def prepare_patient(events:pd.DataFrame,end:float=168.,step:float=.25,
                    held_after:float|None=None,clearance_scale:float=1.) -> Patient:
    events=events.sort_values('TIME',kind='stable')
    bsa=float(events.BSA.iloc[0])
    dose=events[(events.EVID==1)&(events.TIME<=end)][['TIME','AMT']].copy()
    if held_after is not None:
        old=dose[dose.TIME<=held_after]
        assert len(old)>0
        last=old.iloc[-1]
        next_time=float(last.TIME)+np.floor(held_after-float(last.TIME))+1
        future=np.arange(next_time,end+1e-8,1.)
        dose=pd.concat([old,pd.DataFrame({'TIME':future,'AMT':float(last.AMT)})],ignore_index=True)
    obs=events[(events.EVID==0)&(events.TIME<=end)&(events.DV>0)][['TIME','DV']]
    grid=np.unique(np.concatenate([np.arange(0,end,step),[end,84.],dose.TIME.values,obs.TIME.values]))
    grid=grid[(grid>=0)&(grid<=end)]
    index=np.searchsorted(grid,obs.TIME.values)
    dose_map={float(t):float(a) for t,a in dose.itertuples(index=False,name=None)}
    # Table2 day-unit convention. k20 is total central elimination, not plus kme.
    mat=np.array([[-31.2,0,0],[31.2,-12.72,0],[0,.019*9.9216,-.219*bsa**1.16*clearance_scale]])
    state=np.zeros(3);exposure=np.empty((len(grid)-1,3));cache={}
    for j,(a,b) in enumerate(zip(grid[:-1],grid[1:])):
        state[0]+=.22*dose_map.get(a,0.)
        dt=float(b-a)
        key=round(dt,10)
        if key not in cache:cache[key]=expm(mat*dt/2)
        half=cache[key]@state;finish=cache[key]@half
        exposure[j]=[state[2],half[2],finish[2]]
        state=finish
    assert exposure.min()>-1e-8
    return Patient(int(events.ID.iloc[0]),grid,exposure,index,obs.DV.to_numpy())

@njit(cache=True)
def rhs(y,e,base,slope,ktr,gamma):
    out=np.empty(5)
    n=max(y[4],1e-8)
    out[0]=ktr*y[0]*((1-slope*e)*(base/n)**gamma-1)
    out[1]=ktr*(y[0]-y[1]);out[2]=ktr*(y[1]-y[2]);out[3]=ktr*(y[2]-y[3])
    out[4]=ktr*y[3]-2.3765*y[4]
    return out

@njit(cache=True)
def predict(grid,exposure,theta):
    base,slope,ktr,gamma=theta
    y=np.full(5,base*2.3765/ktr);y[4]=base
    out=np.empty(len(grid));out[0]=base
    for j in range(len(grid)-1):
        h=grid[j+1]-grid[j];e=exposure[j]
        k1=rhs(y,e[0],base,slope,ktr,gamma)
        k2=rhs(y+h*k1/2,e[1],base,slope,ktr,gamma)
        k3=rhs(y+h*k2/2,e[1],base,slope,ktr,gamma)
        k4=rhs(y+h*k3,e[2],base,slope,ktr,gamma)
        y=y+h*(k1+2*k2+2*k3+k4)/6
        if np.any(y<=0) or np.any(y>1e7) or not np.all(np.isfinite(y)):
            return np.full(len(grid),1e-10)
        out[j+1]=y[4]
    return out

@njit(cache=True,nogil=True)
def gh_loglike(grid,exposure,idx,obs,par,nodes,weights):
    n_slope=1 if par[5]<1e-7 else len(nodes)
    vals=np.empty(len(nodes)*n_slope);counter=0
    for a in range(len(nodes)):
        for b in range(n_slope):
            th=par[:4].copy();th[0]*=np.exp(np.sqrt(2)*par[4]*nodes[a])
            if n_slope>1:th[1]*=np.exp(np.sqrt(2)*par[5]*nodes[b])
            pred=predict(grid,exposure,th)
            res=(np.log(obs)-np.log(pred[idx]))/par[6]
            weight=weights[a]/np.sqrt(np.pi) if n_slope==1 else weights[a]*weights[b]/np.pi
            vals[counter]=-.5*np.sum(res*res)-len(obs)*np.log(par[6]*np.sqrt(2*np.pi))+np.log(weight)
            counter+=1
    maximum=np.max(vals)
    return maximum+np.log(np.sum(np.exp(vals-maximum)))

def objective(logpar,patients,order=7):
    par=np.exp(logpar);nodes,weights=hermgauss(order)
    def one(p):return gh_loglike(p.grid,p.exposure,p.obs_index,p.obs,par,nodes,weights)
    return -sum(POOL.map(one,patients))

def individual_map(patient:Patient,par:np.ndarray,cutoff=84.):
    selected=patient.grid[patient.obs_index]<=cutoff
    idx=patient.obs_index[selected];obs=patient.obs[selected]
    assert len(obs)>=4
    end_index=int(np.searchsorted(patient.grid,cutoff,side='right'))
    def loss(eta):
        th=par[:4].copy();th[:2]*=np.exp(eta)
        # Even a numerical failure after cutoff must not affect the prefix likelihood.
        pred=predict(patient.grid[:end_index],patient.exposure[:end_index-1],th)
        residual=(np.log(obs)-np.log(pred[idx]))/par[6]
        return .5*np.sum(residual**2)+.5*np.sum((eta/par[4:6])**2)
    bounds=[(-2.5,2.5),(-3,3) if par[5]>1e-7 else (0.,0.)]
    starts=[np.zeros(2),np.array([.1,-.2 if par[5]>1e-7 else 0.])]
    fits=[minimize(loss,start,method='L-BFGS-B',bounds=bounds) for start in starts]
    best=min(fits,key=lambda r:r.fun)
    th=par[:4].copy();th[:2]*=np.exp(best.x)
    return predict(patient.grid,patient.exposure,th),best
