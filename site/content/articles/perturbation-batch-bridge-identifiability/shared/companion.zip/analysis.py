from fractions import Fraction

def rank(rows):
    matrix = [[Fraction(x) for x in row] for row in rows]
    pivot = 0
    for col in range(len(matrix[0])):
        match = next((i for i in range(pivot,len(matrix)) if matrix[i][col]), None)
        if match is None:
            continue
        matrix[pivot], matrix[match] = matrix[match], matrix[pivot]
        for i in range(pivot+1,len(matrix)):
            factor = matrix[i][col]/matrix[pivot][col]
            matrix[i] = [a-factor*b for a,b in zip(matrix[i],matrix[pivot])]
        pivot += 1
    return pivot

cells = [(0,0),(1,1),(1,0),(0,1)]
for n, interaction in [(2,False),(2,True),(3,False),(3,True),(4,False),(4,True)]:
    rows = [[1,b,t]+([b*t] if interaction else []) for b,t in cells[:n]]
    print(f"{n} cells, interaction={interaction}: rank {rank(rows)}/{len(rows[0])}")
