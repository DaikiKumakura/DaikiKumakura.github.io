Run python analysis.py with Python 3. The output uses hypothetical inputs.
