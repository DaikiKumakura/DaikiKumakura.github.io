"""Figure 1: example time courses. Figure 2: maps of the ratio of time to progression (adaptive / continuous)."""
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

import analysis as an

ROOT = Path(__file__).resolve().parent
(ROOT / "figures").mkdir(exist_ok=True)

ex = pd.read_csv(ROOT / "results" / "example-trajectories.csv")
fig, axes = plt.subplots(1, 2, figsize=(9.0, 3.6), dpi=150, sharey=True)
for ax, strat, title in zip(axes, ("continuous", "adaptive"), ("Continuous dosing", "Adaptive dosing (stop at 0.5 x N0, restart at N0)")):
    d = ex[ex.strategy == strat]
    ax.plot(d.time, d.S + d.R, color="black", lw=2, label="Total burden N")
    ax.plot(d.time, d.S, color="#0072B2", lw=1.5, label="Sensitive S")
    ax.plot(d.time, d.R, color="#D55E00", lw=1.5, label="Resistant R")
    ax.axhline(an.PROGRESSION * an.N0, color="#888888", ls=":", lw=1)
    ax.set_title(title, fontsize=9)
    ax.set_xlabel("Time (units of 1 / growth rate of sensitive cells)")
axes[0].set_ylabel("Burden (fraction of carrying capacity)")
axes[0].legend(fontsize=7, loc="upper right")
fig.tight_layout()
fig.savefig(ROOT / "figures" / "01-example-time-courses.png")

fig, axes = plt.subplots(1, 2, figsize=(10.0, 4.0), dpi=150)
specs = [("map-a-competition-by-initial-resistant-fraction.csv", "f0", "a", "Initial resistant fraction", "Suppression of resistant by sensitive cells (a)"),
         ("map-b-partial-resistance-by-competition.csv", "rho", "a", "Residual drug effect on resistant cells (rho)", "Suppression of resistant by sensitive cells (a)")]
for ax, (fn, xk, yk, xl, yl) in zip(axes, specs):
    df = pd.read_csv(ROOT / "results" / fn)
    xs, ys = sorted(df[xk].unique()), sorted(df[yk].unique())
    z = np.full((len(ys), len(xs)), np.nan)
    for i, y in enumerate(ys):
        for j, x in enumerate(xs):
            r = df[(df[xk] == x) & (df[yk] == y)].iloc[0]
            z[i, j] = np.log10(r.ratio)
            txt = ">" + f"{int(np.floor(r.ratio))}" if r.adaptive_censored and not r.continuous_censored else ("none" if r.adaptive_censored and r.continuous_censored else f"{r.ratio:.2f}")
            ax.text(j, i, txt, ha="center", va="center", fontsize=7, color="white" if abs(z[i, j]) > 0.45 else "black")
    im = ax.imshow(z, origin="lower", cmap="PuOr_r", vmin=-1.5, vmax=1.5, aspect="auto")
    ax.set_xticks(range(len(xs)))
    ax.set_xticklabels([f"{x:g}" for x in xs], fontsize=8)
    ax.set_yticks(range(len(ys)))
    ax.set_yticklabels([f"{y:g}" for y in ys], fontsize=8)
    ax.set_xlabel(xl, fontsize=8)
    ax.set_ylabel(yl, fontsize=8)
fig.colorbar(im, ax=axes, shrink=0.8, label="log10 (ratio of time to progression)")
fig.text(0.01, -0.03, "'>' : adaptive arm did not progress within the horizon (lower bound); 'none': neither arm progressed.", fontsize=6.5)
fig.savefig(ROOT / "figures" / "02-ratio-maps.png", bbox_inches="tight")
