# Adaptive versus continuous dosing in a sensitive-resistant competition model: companion code

Deterministic two-population model (sensitive S, resistant R) with a threshold-based adaptive rule (stop at 0.5 x N0, restart at N0), scanned over competition strength, initial resistant fraction, residual drug effect on resistant cells and cost of resistance.

- `analysis.py`: model, event-based integration, scans.
- `sensitivity.py`: stop-level and progression-criterion sensitivity.
- `figures.py`: Figures 1 and 2.
- `test_analysis.py`: checks (`python -m pytest test_analysis.py`).
- `results/`: CSV outputs.

Parameters are assumed, not measured. No data. Requires Python 3 with numpy, scipy, pandas, matplotlib.
