"""When does threshold-based adaptive dosing delay progression compared with continuous dosing? A sensitive / resistant competition model.

Model (dimensionless; time is measured in units of 1 / growth rate of sensitive cells; carrying capacity K = 1):
  dS/dt = S (1 - S - R) - kmax * S * on
  dR/dt = (1 - c) * R (1 - a * S - R) - rho * kmax * R * on
  c: growth cost of resistance without drug (0 <= c < 1)
  a: strength of suppression of resistant cells by sensitive cells (competition coefficient; the effect of R on S is fixed at 1)
  rho: fraction of the drug effect that still acts on resistant cells (0 = fully resistant, 1 = no resistance)
  on = 1 while on treatment, 0 off treatment; the drug has a fixed maximal effect kmax and no pharmacokinetics (a deliberate simplification).
Initial total burden N0 = S + R = 0.5 K with resistant fraction f0.
Progression: N >= 1.2 * N0. Continuous arm: treat throughout. Adaptive arm: stop when N <= 0.5 * N0, restart when N >= N0.
Deterministic ODE integration with event detection. Time to progression is censored at T_MAX.
"""
from pathlib import Path

import numpy as np
import pandas as pd
from scipy.integrate import solve_ivp

ROOT = Path(__file__).resolve().parent
OUT = ROOT / "results"
OUT.mkdir(exist_ok=True)

KMAX = 2.0
N0 = 0.5
STOP_FRACTION = 0.5
PROGRESSION = 1.2
T_MAX = 600.0
BASE = dict(cost=0.2, a=1.5, rho=0.0, f0=0.01)


def rhs(t, y, on: bool, cost: float, a: float, rho: float):
    s, r = y
    ds = s * (1 - s - r) - (KMAX if on else 0.0) * s
    dr = (1 - cost) * r * (1 - a * s - r) - (rho * KMAX if on else 0.0) * r
    return [ds, dr]


def simulate(strategy: str, cost: float, a: float, rho: float, f0: float, t_max: float = T_MAX):
    """Return (time to progression or t_max, censored flag, times, S, R)."""
    y = np.array([N0 * (1 - f0), N0 * f0])
    t, on = 0.0, True
    T, S, R = [0.0], [y[0]], [y[1]]
    while t < t_max:
        def prog(tt, yy, *args):
            return yy.sum() - PROGRESSION * N0
        prog.terminal, prog.direction = True, 1
        events = [prog]
        if strategy == "adaptive":
            if on:
                def sw(tt, yy, *args):
                    return yy.sum() - STOP_FRACTION * N0
                sw.direction = -1
            else:
                def sw(tt, yy, *args):
                    return yy.sum() - N0
                sw.direction = 1
            sw.terminal = True
            events.append(sw)
        sol = solve_ivp(rhs, (t, t_max), y, args=(on, cost, a, rho), events=events, rtol=1e-9, atol=1e-12, max_step=0.5)
        T += list(sol.t[1:]); S += list(sol.y[0, 1:]); R += list(sol.y[1, 1:])
        t, y = sol.t[-1], sol.y[:, -1]
        if sol.status == 0:
            return t_max, True, np.array(T), np.array(S), np.array(R)
        if len(sol.t_events[0]) > 0:
            return t, False, np.array(T), np.array(S), np.array(R)
        on = not on
    return t_max, True, np.array(T), np.array(S), np.array(R)


def ttp_pair(cost: float, a: float, rho: float, f0: float) -> dict:
    tc, cc, *_ = simulate("continuous", cost, a, rho, f0)
    ta, ca, *_ = simulate("adaptive", cost, a, rho, f0)
    return dict(cost=cost, a=a, rho=rho, f0=f0, ttp_continuous=tc, ttp_adaptive=ta, continuous_censored=cc, adaptive_censored=ca, ratio=ta / tc)


def scan(grid: dict, base: dict) -> pd.DataFrame:
    keys = list(grid)
    rows = []
    for v1 in grid[keys[0]]:
        for v2 in grid[keys[1]]:
            p = dict(base)
            p[keys[0]], p[keys[1]] = v1, v2
            rows.append(ttp_pair(**p))
    return pd.DataFrame(rows)


def main() -> None:
    maps = {
        "map-a-competition-by-initial-resistant-fraction": ({"a": [0.5, 1.0, 1.5, 2.0, 3.0], "f0": [0.001, 0.01, 0.05, 0.1, 0.2, 0.4]}, BASE),
        "map-b-partial-resistance-by-competition": ({"rho": [0.0, 0.05, 0.1, 0.15, 0.2], "a": [0.5, 1.0, 1.5, 2.0, 3.0]}, BASE),
        "map-c-cost-by-competition": ({"cost": [0.0, 0.2, 0.4, 0.6], "a": [0.5, 1.0, 1.5, 2.0, 3.0]}, BASE),
    }
    pd.set_option("display.width", 200)
    for name, (grid, base) in maps.items():
        df = scan(grid, base)
        df.round(3).to_csv(OUT / f"{name}.csv", index=False, lineterminator=chr(10))
        keys = list(grid)
        print(name, "censored adaptive/continuous:", int(df.adaptive_censored.sum()), int(df.continuous_censored.sum()))
        print(df.pivot(index=keys[0], columns=keys[1], values="ratio").round(2).to_string())
    # example trajectories at the base parameters
    ex = []
    for strat in ("continuous", "adaptive"):
        ttp, cens, T, S, R = simulate(strat, **BASE)
        ex.append(pd.DataFrame(dict(strategy=strat, time=T, S=S, R=R)))
        print(strat, "time to progression", round(ttp, 2), "censored", cens)
    pd.concat(ex).round(5).to_csv(OUT / "example-trajectories.csv", index=False, lineterminator=chr(10))


if __name__ == "__main__":
    main()
