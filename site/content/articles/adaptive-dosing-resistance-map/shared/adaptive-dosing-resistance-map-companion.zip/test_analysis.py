import numpy as np

import analysis as an


def test_no_resistant_cells_means_no_progression_in_either_arm():
    for strat in ("continuous", "adaptive"):
        t, cens, *_ = an.simulate(strat, 0.2, 1.5, 0.0, 0.0)
        assert cens and t == an.T_MAX


def test_adaptive_keeps_burden_between_stop_and_restart_levels_before_progression():
    t, cens, T, S, R = an.simulate("adaptive", **an.BASE)
    n = S + R
    assert n.max() <= an.PROGRESSION * an.N0 + 1e-6
    assert not cens


def test_adaptive_not_worse_when_resistance_is_complete():
    for a in (0.5, 1.0, 2.0):
        for f0 in (0.001, 0.01, 0.1):
            for c in (0.0, 0.4):
                r = an.ttp_pair(c, a, 0.0, f0)
                assert r["ratio"] >= 1.0 - 1e-9


def test_time_to_progression_is_insensitive_to_integration_tolerance():
    t1 = an.simulate("continuous", **an.BASE)[0]
    import scipy.integrate as si
    orig = si.solve_ivp

    def tight(*args, **kw):
        kw["rtol"], kw["atol"], kw["max_step"] = 1e-11, 1e-13, 0.05
        return orig(*args, **kw)

    an.solve_ivp = tight
    try:
        t2 = an.simulate("continuous", **an.BASE)[0]
    finally:
        an.solve_ivp = orig
    assert abs(t1 - t2) < 1e-3
