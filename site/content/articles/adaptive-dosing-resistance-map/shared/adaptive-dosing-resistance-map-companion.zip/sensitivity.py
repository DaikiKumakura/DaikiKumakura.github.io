"""Sensitivity of the main conclusions to the adaptive stop level and the progression criterion (a few representative cells)."""
import pandas as pd

import analysis as an

rows = []
cells = [dict(label="baseline", cost=0.2, a=1.5, rho=0.0, f0=0.01), dict(label="weak competition", cost=0.2, a=0.5, rho=0.0, f0=0.01),
         dict(label="strong competition", cost=0.2, a=3.0, rho=0.0, f0=0.01), dict(label="partial resistance", cost=0.2, a=0.5, rho=0.15, f0=0.01),
         dict(label="strong competition + partial resistance", cost=0.2, a=3.0, rho=0.15, f0=0.01)]
orig = (an.STOP_FRACTION, an.PROGRESSION)
for stop in (0.3, 0.5, 0.7):
    for prog in (1.1, 1.2, 1.5):
        an.STOP_FRACTION, an.PROGRESSION = stop, prog
        for c in cells:
            p = {k: v for k, v in c.items() if k != "label"}
            r = an.ttp_pair(**p)
            rows.append(dict(cell=c["label"], stop_fraction=stop, progression_factor=prog, **r))
an.STOP_FRACTION, an.PROGRESSION = orig
df = pd.DataFrame(rows)
df.round(3).to_csv(an.OUT / "threshold-sensitivity.csv", index=False, lineterminator=chr(10))
pd.set_option("display.width", 220)
print(df[["cell", "stop_fraction", "progression_factor", "ttp_continuous", "ttp_adaptive", "ratio", "adaptive_censored", "continuous_censored"]].round(2).to_string())
