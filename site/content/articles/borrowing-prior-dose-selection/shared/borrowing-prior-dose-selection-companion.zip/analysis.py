"""M30: borrowing an existing drug's dose-comparison data for a new drug's dose selection.

Robust mixture prior per arm and endpoint: w*Beta(historical) + (1-w)*Beta(1,1),
updated conjugately with beta-binomial marginal likelihoods.
Run: python analysis.py (tests: python test_analysis.py)
"""
from pathlib import Path

import numpy as np
import pandas as pd
from scipy.special import betaln

SEED = 20261005
HIST = {
    "sotorasib": dict(eff=((26, 105), (34, 104)), harm=((20, 104), (37, 104))),
    "ifinatamab_deruxtecan": dict(eff=((12, 46), (23, 42)), harm=((20, 46), (21, 42))),
}
SCENARIOS = ["S0 same", "S1 no efficacy gain", "S2 larger efficacy gain", "S3 no extra harm", "S4 more harm"]
OMEGAS = (0.0, 0.25, 0.5, 0.75, 1.0)


def hist_beta(x, n, ess=None):
    a, b = 1 + x, 1 + n - x
    if ess is not None and a + b > ess:
        m = a / (a + b)
        a, b = m * ess, (1 - m) * ess
    return a, b


def draw_truth(hist, scenario, n, rng):
    h = HIST[hist]
    def post(xn):
        return rng.beta(1 + xn[0], 1 + xn[1] - xn[0], n)
    pL, pH = post(h["eff"][0]), post(h["eff"][1])
    qL, qH = post(h["harm"][0]), post(h["harm"][1])
    if scenario.startswith("S1"):
        pH = pL.copy()
    elif scenario.startswith("S2"):
        pH = np.clip(pH + 0.15, 0, 0.99)
    elif scenario.startswith("S3"):
        qH = qL.copy()
    elif scenario.startswith("S4"):
        qH = np.clip(qH + 0.15, 0, 0.99)
    return np.column_stack([pL, pH]), np.column_stack([qL, qH])


def mixture_posterior_draws(x, n, a_h, b_h, omega, n_post, rng):
    """Draws from the posterior of a two-component Beta mixture prior (vectorised over trials)."""
    log_m_h = betaln(a_h + x, b_h + n - x) - betaln(a_h, b_h)
    log_m_v = betaln(1 + x, 1 + n - x) - betaln(1, 1)
    if omega <= 0:
        wpost = np.zeros_like(x, dtype=float)
    elif omega >= 1:
        wpost = np.ones_like(x, dtype=float)
    else:
        lh = np.log(omega) + log_m_h
        lv = np.log(1 - omega) + log_m_v
        wpost = 1 / (1 + np.exp(lv - lh))
    comp = rng.random((len(x), n_post)) < wpost[:, None]
    dh = rng.beta(a_h + x[:, None], b_h + n - x[:, None], (len(x), n_post))
    dv = rng.beta(1 + x[:, None], 1 + n - x[:, None], (len(x), n_post))
    return np.where(comp, dh, dv), wpost


def simulate(hist, scenario, omega, n_trials=5000, n_arm=40, w=1.0, threshold=0.80, ess=None,
             n_post=2000, seed=SEED):
    rng = np.random.default_rng(seed)
    p, q = draw_truth(hist, scenario, n_trials, rng)
    u_true = p - w * q
    best = u_true.argmax(axis=1)
    h = HIST[hist]
    u_draws, wts = [], []
    for arm in (0, 1):
        x = rng.binomial(n_arm, p[:, arm])
        y = rng.binomial(n_arm, q[:, arm])
        ae, be = hist_beta(*h["eff"][arm], ess=ess)
        ah, bh = hist_beta(*h["harm"][arm], ess=ess)
        de, we = mixture_posterior_draws(x, n_arm, ae, be, omega, n_post, rng)
        dt, wt = mixture_posterior_draws(y, n_arm, ah, bh, omega, n_post, rng)
        u_draws.append(de - w * dt)
        wts.append((we + wt) / 2)
    u = np.stack(u_draws, axis=2)
    chosen = u.mean(axis=1).argmax(axis=1)
    p_best = (u.argmax(axis=2) == chosen[:, None]).mean(axis=1)
    confident = p_best >= threshold
    regret = u_true[np.arange(n_trials), best] - u_true[np.arange(n_trials), chosen]
    return dict(correct=chosen == best, confident=confident, regret=regret,
                hist_weight=np.mean(wts, axis=0), best_high=(best == 1))


def run_all(out="results", n_trials=5000):
    Path(out).mkdir(exist_ok=True)
    settings = {"main": {}, "n_arm=25": dict(n_arm=25), "n_arm=60": dict(n_arm=60), "ESS=50": dict(ess=50),
                "w=0.5": dict(w=0.5), "w=2": dict(w=2.0)}
    rows = []
    for sname, kw in settings.items():
        for hist in HIST:
            for sc in SCENARIOS:
                base = None
                for om in OMEGAS:
                    s = simulate(hist, sc, om, n_trials=n_trials, **kw)
                    r = s["regret"]
                    if om == 0:
                        base = r
                    d = r - base
                    rows.append(dict(setting=sname, history=hist, scenario=sc, omega=om,
                                     correct=s["correct"].mean(), correct_confident=(s["correct"] & s["confident"]).mean(),
                                     undecided=1 - s["confident"].mean(), regret=r.mean(),
                                     regret_vs_no_borrow=d.mean(), regret_vs_no_borrow_se=d.std(ddof=1) / np.sqrt(len(d)),
                                     hist_weight=s["hist_weight"].mean(), best_high=s["best_high"].mean()))
    df = pd.DataFrame(rows)
    df.to_csv(f"{out}/borrowing-metrics.csv", index=False)
    # acceptability rule
    acc = []
    for (sname, hist), g in df.groupby(["setting", "history"]):
        for om in OMEGAS:
            gi = g[g.omega == om]
            gain = -gi[gi.scenario == "S0 same"].regret_vs_no_borrow.iloc[0]
            worst = gi[gi.scenario != "S0 same"].regret_vs_no_borrow.max()
            acc.append(dict(setting=sname, history=hist, omega=om, gain_S0=gain, worst_loss_S1_S4=worst,
                            acceptable=bool(gain > 0 and worst <= 0.01)))
    pd.DataFrame(acc).to_csv(f"{out}/acceptability.csv", index=False)
    return df, pd.DataFrame(acc)


if __name__ == "__main__":
    df, acc = run_all()
    pd.set_option("display.width", 200)
    print(df[df.setting == "main"][["history", "scenario", "omega", "correct", "undecided", "regret", "regret_vs_no_borrow", "hist_weight"]].round(3).to_string(index=False))
    print(acc.round(4).to_string(index=False))
