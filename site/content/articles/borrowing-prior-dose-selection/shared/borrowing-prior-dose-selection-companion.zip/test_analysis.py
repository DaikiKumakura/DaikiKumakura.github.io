"""Checks of the M30 implementation. Run: python test_analysis.py"""
import numpy as np
from scipy import stats

import analysis as a


def check(cond, msg):
    assert cond, msg
    print("ok -", msg)


rng = np.random.default_rng(1)
# 1. Mixture posterior weight matches the analytic beta-binomial calculation
x = np.array([5, 30]); n = 40; ah, bh = 27.0, 81.0; om = 0.5
d, w = a.mixture_posterior_draws(x, n, ah, bh, om, 200000, rng)
mh = stats.betabinom.pmf(x, n, ah, bh); mv = stats.betabinom.pmf(x, n, 1, 1)
check(np.allclose(w, om * mh / (om * mh + (1 - om) * mv)), "posterior mixture weights equal beta-binomial formula")
exact_mean = w * (ah + x) / (ah + bh + n) + (1 - w) * (1 + x) / (2 + n)
check(np.allclose(d.mean(axis=1), exact_mean, atol=0.002), "posterior draws have the exact mixture mean")
check(w[1] < w[0], "data far from the historical rate lower the historical weight (conflict)")

# 2. omega = 0 ignores history; omega = 1 is full borrowing
d0, w0 = a.mixture_posterior_draws(np.array([10]), 40, ah, bh, 0.0, 100000, rng)
check(abs(d0.mean() - 11 / 42) < 0.002 and w0[0] == 0, "omega=0 gives the vague-prior posterior")
d1, w1 = a.mixture_posterior_draws(np.array([10]), 40, ah, bh, 1.0, 100000, rng)
check(abs(d1.mean() - 37 / 148) < 0.002 and w1[0] == 1, "omega=1 gives full borrowing")

# 3. ESS capping keeps the historical mean
a50, b50 = a.hist_beta(26, 105, ess=50)
check(abs(a50 + b50 - 50) < 1e-12 and abs(a50 / 50 - 27 / 107) < 1e-12, "ESS cap preserves the mean")

# 4. Scenario construction
p, q = a.draw_truth("sotorasib", "S1 no efficacy gain", 1000, rng)
check(np.array_equal(p[:, 0], p[:, 1]), "S1: no efficacy gain at the high dose")
p, q = a.draw_truth("sotorasib", "S3 no extra harm", 1000, rng)
check(np.array_equal(q[:, 0], q[:, 1]), "S3: no extra harm at the high dose")
print("all tests passed")
