# Independent re-implementation of the M30 simulation in R (different language and seed).
# Robust mixture prior with conjugate updating; recomputes correct selection and expected regret
# for 2 histories x 2 scenarios x 3 borrowing weights and compares with results/borrowing-metrics.csv.
# Run after analysis.py: Rscript validate.R
hist <- list(
  sotorasib = list(eff = rbind(c(26, 105), c(34, 104)), harm = rbind(c(20, 104), c(37, 104)), worst = "S3 no extra harm"),
  ifinatamab_deruxtecan = list(eff = rbind(c(12, 46), c(23, 42)), harm = rbind(c(20, 46), c(21, 42)), worst = "S1 no efficacy gain"))

lbb <- function(x, n, a, b) lchoose(n, x) + lbeta(a + x, b + n - x) - lbeta(a, b)

mix_draws <- function(x, n, a, b, omega, n_post) {
  if (omega <= 0) wpost <- 0 else if (omega >= 1) wpost <- 1 else {
    lh <- log(omega) + lbb(x, n, a, b); lv <- log(1 - omega) + lbb(x, n, 1, 1)
    wpost <- 1 / (1 + exp(lv - lh))
  }
  comp <- runif(n_post) < wpost
  ifelse(comp, rbeta(n_post, a + x, b + n - x), rbeta(n_post, 1 + x, 1 + n - x))
}

one <- function(h, scenario, omega, n_trials = 4000, n_arm = 40, n_post = 2000, w = 1) {
  H <- hist[[h]]
  post <- function(m) rbeta(n_trials, 1 + m[1], 1 + m[2] - m[1])
  pL <- post(H$eff[1, ]); pH <- post(H$eff[2, ]); qL <- post(H$harm[1, ]); qH <- post(H$harm[2, ])
  if (startsWith(scenario, "S1")) pH <- pL
  if (startsWith(scenario, "S3")) qH <- qL
  p <- cbind(pL, pH); q <- cbind(qL, qH); u <- p - w * q
  best <- max.col(u, ties.method = "first")
  correct <- regret <- numeric(n_trials)
  for (i in seq_len(n_trials)) {
    ud <- sapply(1:2, function(arm) {
      x <- rbinom(1, n_arm, p[i, arm]); y <- rbinom(1, n_arm, q[i, arm])
      e <- H$eff[arm, ]; t <- H$harm[arm, ]
      mix_draws(x, n_arm, 1 + e[1], 1 + e[2] - e[1], omega, n_post) - w * mix_draws(y, n_arm, 1 + t[1], 1 + t[2] - t[1], omega, n_post)
    })
    ch <- which.max(colMeans(ud))
    correct[i] <- ch == best[i]; regret[i] <- u[i, best[i]] - u[i, ch]
  }
  c(correct = mean(correct), regret = mean(regret), se_correct = sd(correct) / sqrt(n_trials), se_regret = sd(regret) / sqrt(n_trials))
}

set.seed(77)
ref <- read.csv("results/borrowing-metrics.csv"); ref <- ref[ref$setting == "main", ]
rows <- list(); ok <- TRUE
for (h in names(hist)) for (sc in c("S0 same", hist[[h]]$worst)) for (om in c(0, 0.5, 1)) {
  r <- one(h, sc, om)
  py <- ref[ref$history == h & ref$scenario == sc & ref$omega == om, ]
  for (m in c("correct", "regret")) {
    se <- sqrt(r[[paste0("se_", m)]]^2 * (1 + 4000 / 5000))
    z <- (r[[m]] - py[[m]]) / se
    rows[[length(rows) + 1]] <- data.frame(history = h, scenario = sc, omega = om, metric = m, r = r[[m]], python = py[[m]], z = z)
    if (abs(z) >= 4) ok <- FALSE
  }
}
res <- do.call(rbind, rows)
print(res, digits = 3)
writeLines(jsonlite::toJSON(list(status = if (ok) "pass" else "fail",
                                 method = "independent R simulation, seed 77, 4,000 trials per condition; |z| < 4",
                                 max_abs_z = max(abs(res$z)), checks = res), auto_unbox = TRUE, pretty = TRUE, digits = 6),
           "results/validation.json")
cat(if (ok) "pass\n" else "FAIL\n")
