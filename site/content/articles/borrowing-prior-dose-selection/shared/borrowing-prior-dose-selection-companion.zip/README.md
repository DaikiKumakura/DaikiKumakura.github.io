# 既存薬の用量比較を新薬に借りる：配布資料

記事「既存薬の用量比較を、新薬の用量選択にどこまで借りてよいか」の再実行用資料。

## 含むもの

- `analysis-plan.md`：問い・使いみち・混合事前分布・シナリオ・判定規則・感度解析（計算前に固定）
- `analysis.py`, `test_analysis.py`, `figures.py`：シミュレーション、8件の検査、図
- `validate.R`：別の言語・別の乱数による独立の再実装と比較
- `inputs.csv`：借用元として使った公開の群別集計と出典
- `results/`：借用の重み別の指標、許容判定、検証結果
- `figures/`：記事の図

患者のデータは含まない（公開の群別集計だけを使う）。新薬は仮想である。

## 実行

1. `python test_analysis.py`（Python 3.12、numpy、scipy、pandas）
2. `python analysis.py` → `results/`（約25分）
3. `python figures.py`（matplotlib）
4. `Rscript validate.R`（R 4.5.3、jsonlite）→ `results/validation.json`

seedは固定してある。既存薬の効果を新薬の予測値とはしない。特定の新薬の用量は推奨しない。
