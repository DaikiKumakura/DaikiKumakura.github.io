"""Figures for M30. Run after analysis.py."""
from pathlib import Path

import matplotlib
# --- Okabe-Ito colours (tools/okabe_ito) ---
from cycler import cycler as _oi_cycler
from matplotlib import rcParams as _oi_rc
from matplotlib.colors import LinearSegmentedColormap as _OI_LSC, ListedColormap as _OI_LC

OI_CYCLE = ['#0072B2', '#D55E00', '#009E73', '#E69F00', '#56B4E9', '#CC79A7', '#F0E442', '#000000']
OI_SEQ = _OI_LSC.from_list("oi_seq", ["#FFFFFF", "#56B4E9", "#0072B2", "#00263D"])
OI_SEQ_R = OI_SEQ.reversed()
OI_DIV = _OI_LSC.from_list("oi_div", ["#D55E00", "#FFFFFF", "#0072B2"])
OI_DIV_R = OI_DIV.reversed()
OI_QUAL = _OI_LC(OI_CYCLE, name="oi_qual")
_oi_rc["axes.prop_cycle"] = _oi_cycler(color=OI_CYCLE)
# --- end Okabe-Ito colours ---
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import pandas as pd

Path("figures").mkdir(exist_ok=True)
df = pd.read_csv("results/borrowing-metrics.csv")
m = df[df.setting == "main"]
LABEL = {"sotorasib": "History: sotorasib 240/960 mg", "ifinatamab_deruxtecan": "History: ifinatamab deruxtecan 8/12 mg/kg"}
STYLE = {"S0 same": ("k", "-"), "S1 no efficacy gain": ("#0072B2", "--"), "S2 larger efficacy gain": ("#009E73", "--"),
         "S3 no extra harm": ("#E69F00", ":"), "S4 more harm": ("#D55E00", ":")}

for fname, col, ylab, scale in (("01-regret-change.png", "regret_vs_no_borrow", "Regret change vs no borrowing (points)", 100),
                                ("02-correct-selection.png", "correct", "Correct selection (%)", 100)):
    fig, axes = plt.subplots(1, 2, figsize=(9, 3.6), constrained_layout=True, sharey=True)
    for ax, h in zip(axes, LABEL):
        g = m[m.history == h]
        for sc, (c, ls) in STYLE.items():
            x = g[g.scenario == sc].sort_values("omega")
            ax.plot(x.omega, x[col] * scale, color=c, linestyle=ls, marker="o", label=sc)
        if col == "regret_vs_no_borrow":
            ax.axhline(0, color="grey", lw=0.8); ax.axhline(1, color="grey", lw=0.8, ls="--")
        ax.set_xlabel("Borrowing weight ω"); ax.set_title(LABEL[h], fontsize=9)
    axes[0].set_ylabel(ylab)
    axes[1].legend(fontsize=7)
    fig.savefig(f"figures/{fname}", dpi=150)
print("figures written")
