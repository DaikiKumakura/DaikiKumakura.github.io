"""Figures for M30. Run after analysis.py."""
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import pandas as pd

Path("figures").mkdir(exist_ok=True)
df = pd.read_csv("results/borrowing-metrics.csv")
m = df[df.setting == "main"]
LABEL = {"sotorasib": "History: sotorasib 240/960 mg", "ifinatamab_deruxtecan": "History: ifinatamab deruxtecan 8/12 mg/kg"}
STYLE = {"S0 same": ("k", "-"), "S1 no efficacy gain": ("tab:blue", "--"), "S2 larger efficacy gain": ("tab:green", "--"),
         "S3 no extra harm": ("tab:orange", ":"), "S4 more harm": ("tab:red", ":")}

for fname, col, ylab, scale in (("01-regret-change.png", "regret_vs_no_borrow", "Regret change vs no borrowing (points)", 100),
                                ("02-correct-selection.png", "correct", "Correct selection (%)", 100)):
    fig, axes = plt.subplots(1, 2, figsize=(9, 3.6), constrained_layout=True, sharey=True)
    for ax, h in zip(axes, LABEL):
        g = m[m.history == h]
        for sc, (c, ls) in STYLE.items():
            x = g[g.scenario == sc].sort_values("omega")
            ax.plot(x.omega, x[col] * scale, color=c, linestyle=ls, marker="o", label=sc)
        if col == "regret_vs_no_borrow":
            ax.axhline(0, color="grey", lw=0.8); ax.axhline(1, color="grey", lw=0.8, ls="--")
        ax.set_xlabel("Borrowing weight ω"); ax.set_title(LABEL[h], fontsize=9)
    axes[0].set_ylabel(ylab)
    axes[1].legend(fontsize=7)
    fig.savefig(f"figures/{fname}", dpi=150)
print("figures written")
