"""Read the published numbers of the PERSEE trial (pembrolizumab +/- platinum chemotherapy, PD-L1 >= 50% NSCLC; Descourt et al., Ann Oncol 2026, DOI 10.1016/j.annonc.2026.10.108; ESMO 2026).

Inputs are numbers printed in the Annals of Oncology abstract (Europe PMC record) and in the ESMO 2026 coverage that quotes the presentation (OncoDaily, Targeted Oncology):
  321 patients (160 combination, 161 pembrolizumab alone); PFS medians 16.1 vs 6.9 months, HR 0.56 (95% CI 0.43-0.74); OS medians 50.2 vs 29.9 months, HR 0.77 (95% CI 0.56-1.05);
  PFS rates 12/24/36 months 54.6/45.2/39.2% vs 33.9/24.9/20.8%; OS rates 12/24/36/48 months 78.8/64.4/55.4/50.9% vs 73.3/56.2/44.9/38.9%;
  ORR 77.5% vs 50.3%; median DoR 30.0 vs 15.6 months; grade >= 3 treatment-related adverse events 53.8% vs 19.3%; grade >= 3 immune-related 13% in both arms; early progression 5.8% vs 26.5% (not defined in the coverage);
  median follow-up 38.7 months; 48% of the combination arm stopped chemotherapy because of adverse events.
Everything here is arithmetic on these printed numbers (landmark-implied hazard ratios under proportional hazards, an approximate Wald test from the reported CI, Newcombe intervals); there are no random numbers.
The full text was not available (the publisher returned an access error); individual-level data are not public.
"""
from pathlib import Path

import numpy as np
import pandas as pd
from scipy.stats import norm

ROOT = Path(__file__).resolve().parent
OUT = ROOT / "results"
OUT.mkdir(exist_ok=True)
N_COMB, N_MONO = 160, 161
PFS = {12: (0.546, 0.339), 24: (0.452, 0.249), 36: (0.392, 0.208)}             # month: (combination, monotherapy)
OS = {12: (0.788, 0.733), 24: (0.644, 0.562), 36: (0.554, 0.449), 48: (0.509, 0.389)}
MEDIANS = dict(pfs=(16.1, 6.9), os=(50.2, 29.9))
HR = dict(pfs=(0.56, 0.43, 0.74), os=(0.77, 0.56, 1.05))


def landmark_hr(s_comb: float, s_mono: float) -> float:
    """Hazard ratio implied by two survival probabilities at one time under proportional hazards: ln S1 / ln S0."""
    return float(np.log(s_comb) / np.log(s_mono))


def landmark_table() -> pd.DataFrame:
    rows = []
    for endpoint, d in (("PFS", PFS), ("OS", OS)):
        for m, (a, b) in d.items():
            rows.append(dict(endpoint=endpoint, month=m, combination=a, monotherapy=b, difference_points=100 * (a - b), implied_hr=landmark_hr(a, b)))
    return pd.DataFrame(rows)


def median_table() -> pd.DataFrame:
    rows = []
    for k, (a, b) in MEDIANS.items():
        rows.append(dict(endpoint=k.upper(), median_comb=a, median_mono=b, difference_months=a - b, hr_if_exponential=b / a, reported_hr=HR[k][0]))
    return pd.DataFrame(rows)


def wald_from_ci(hr: float, lo: float, hi: float) -> dict:
    """Approximate z and two-sided p for log HR from the reported 95% CI (symmetric on the log scale)."""
    se = (np.log(hi) - np.log(lo)) / (2 * 1.96)
    z = np.log(hr) / se
    return dict(se_log_hr=se, z=z, p_two_sided=2 * norm.sf(abs(z)), ci_midpoint_hr=float(np.exp((np.log(lo) + np.log(hi)) / 2)))


def newcombe_diff(x1: int, n1: int, x0: int, n0: int, z: float = 1.96) -> tuple[float, float, float]:
    """Newcombe hybrid-score interval for p1 - p0 (independent samples)."""
    def wilson(x, n):
        p = x / n
        d = 1 + z * z / n
        c = p + z * z / (2 * n)
        h = z * np.sqrt(p * (1 - p) / n + z * z / (4 * n * n))
        return (c - h) / d, (c + h) / d
    p1, p0 = x1 / n1, x0 / n0
    l1, u1 = wilson(x1, n1)
    l0, u0 = wilson(x0, n0)
    return p1 - p0, p1 - p0 - np.sqrt((p1 - l1) ** 2 + (u0 - p0) ** 2), p1 - p0 + np.sqrt((u1 - p1) ** 2 + (p0 - l0) ** 2)


def orr_table() -> pd.DataFrame:
    xc, xm = round(0.775 * N_COMB), round(0.503 * N_MONO)                # 124 and 81 responders implied by the printed percentages
    d, lo, hi = newcombe_diff(xc, N_COMB, xm, N_MONO)
    return pd.DataFrame([dict(responders_comb=xc, responders_mono=xm, orr_comb=xc / N_COMB, orr_mono=xm / N_MONO, diff_points=100 * d, ci_low_points=100 * lo, ci_high_points=100 * hi)])


def expected_os_difference_under_constant_hr(hr: float = 0.77) -> pd.DataFrame:
    """If the OS hazard ratio were constant at `hr`, the absolute difference in survival probability still widens with time: S1 = S0 ** hr."""
    rows = []
    for m, (a, b) in OS.items():
        rows.append(dict(month=m, observed_difference_points=100 * (a - b), expected_difference_points_constant_hr=100 * (b ** hr - b)))
    return pd.DataFrame(rows)


def benefit_harm_table() -> pd.DataFrame:
    rows = []
    for m in (12, 24, 36):
        rows.append(dict(month=m, extra_progression_free_per_100=100 * (PFS[m][0] - PFS[m][1]), extra_alive_per_100=100 * (OS[m][0] - OS[m][1])))
    d = pd.DataFrame(rows)
    d["extra_grade3plus_trae_per_100"] = 100 * (0.538 - 0.193)
    return d


def main() -> None:
    pd.set_option("display.width", 220, "display.max_columns", 30, "display.float_format", lambda v: f"{v:.4g}")
    tables = {"landmarks": landmark_table(), "medians": median_table(), "orr": orr_table(), "benefit_harm": benefit_harm_table(), "os_constant_hr": expected_os_difference_under_constant_hr()}
    for k, v in tables.items():
        v.to_csv(OUT / f"{k}.csv", index=False)
        print(k); print(v); print()
    w = {k: wald_from_ci(*HR[k]) for k in HR}
    pd.DataFrame(w).T.to_csv(OUT / "wald_from_ci.csv")
    print("wald", w)


if __name__ == "__main__":
    main()
