"""Figures for the PERSEE landmark note (reads results/*.csv)."""
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parent
RES, FIG = ROOT / "results", ROOT / "figures"
FIG.mkdir(exist_ok=True)
BLUE, ORANGE, GREY = "#0072B2", "#D55E00", "#666666"


def fig1():
    t = pd.read_csv(RES / "landmarks.csv")
    fig, axes = plt.subplots(1, 2, figsize=(9.6, 4.2), sharey=False)
    for ax, ep in zip(axes, ("PFS", "OS")):
        d = t[t.endpoint == ep]
        ax.plot(d.month, 100 * d.combination, "o-", color=BLUE, label="Pembrolizumab + chemotherapy")
        ax.plot(d.month, 100 * d.monotherapy, "s--", color=ORANGE, label="Pembrolizumab alone")
        ax.set_title(f"{ep}: landmark rates (reported values only)", fontsize=10)
        ax.set_xlabel("Months from randomization")
        ax.set_ylabel("Percent")
        ax.set_ylim(0, 100)
        ax.set_xticks(list(d.month))
        ax.grid(alpha=0.25)
    axes[0].legend(fontsize=8, loc="upper right")
    fig.tight_layout()
    fig.savefig(FIG / "01-landmark-rates.png", dpi=170)
    plt.close(fig)


def fig2():
    b = pd.read_csv(RES / "benefit_harm.csv")
    o = pd.read_csv(RES / "landmarks.csv")
    os_ = o[o.endpoint == "OS"].reset_index(drop=True)
    pfs = o[o.endpoint == "PFS"].set_index("month")
    months = [12, 24, 36, 48]
    x = np.arange(len(months))
    fig, ax = plt.subplots(figsize=(8.0, 4.6))
    ax.bar(x - 0.2, [pfs.difference_points.get(m, np.nan) for m in months], width=0.38, color=BLUE, label="PFS: difference in Kaplan-Meier estimates (points)")
    ax.bar(x + 0.2, os_.difference_points, width=0.38, color=ORANGE, label="OS: difference in Kaplan-Meier estimates (points)")
    ax.axhline(b.extra_grade3plus_trae_per_100.iloc[0], color=GREY, ls="--", label="Difference in grade 3+ treatment-related AEs (whole treatment, points)")
    ax.set_xticks(x)
    ax.set_xticklabels([f"{m} months" for m in months])
    ax.set_ylim(0, 48)
    ax.set_ylabel("Difference between arms (percentage points)")
    ax.set_title("Landmark differences and the adverse-event difference (descriptive)", fontsize=10)
    ax.legend(fontsize=7.5, loc="upper right")
    ax.grid(axis="y", alpha=0.25)
    fig.tight_layout()
    fig.savefig(FIG / "02-landmark-differences-vs-toxicity.png", dpi=170)
    plt.close(fig)


if __name__ == "__main__":
    fig1()
    fig2()
