# PERSEE landmark: companion code

Arithmetic and simple intervals on numbers printed in the abstract and conference coverage of the trial(s) discussed in the article (see `analysis.py` header for the inputs and sources). No individual patient data are used and no random numbers are involved.

- `analysis.py`: all tables.
- `figures.py`: Figures 1 and 2.
- `test_analysis.py`: checks (`python -m pytest test_analysis.py`).
- `results/`: CSV outputs.

Requires Python 3 with numpy, scipy (PERSEE note), pandas, matplotlib.
