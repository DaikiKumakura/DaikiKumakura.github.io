import numpy as np

import analysis as an


def test_landmark_hr_identity():
    assert abs(an.landmark_hr(0.5, 0.5) - 1.0) < 1e-12
    assert abs(an.landmark_hr(0.25, 0.5) - 2.0) < 1e-12


def test_pfs_landmark_hr_is_close_to_reported():
    t = an.landmark_table()
    pfs = t[t.endpoint == "PFS"].implied_hr
    assert (pfs > 0.55).all() and (pfs < 0.60).all()


def test_exponential_hr_from_medians_is_smaller_than_reported():
    m = an.median_table().set_index("endpoint")
    assert m.loc["OS", "hr_if_exponential"] < m.loc["OS", "reported_hr"]
    assert abs(m.loc["PFS", "hr_if_exponential"] - 6.9 / 16.1) < 1e-12


def test_wald_from_reported_ci():
    w = an.wald_from_ci(*an.HR["os"])
    assert 0.09 < w["p_two_sided"] < 0.12
    assert an.wald_from_ci(*an.HR["pfs"])["p_two_sided"] < 1e-3


def test_orr_counts_match_printed_percentages():
    o = an.orr_table().iloc[0]
    assert o.responders_comb == 124 and o.responders_mono == 81
    assert o.ci_low_points < o.diff_points < o.ci_high_points


def test_constant_hr_still_widens_absolute_difference():
    d = an.expected_os_difference_under_constant_hr()
    assert d.expected_difference_points_constant_hr.is_monotonic_increasing
    assert abs(d.expected_difference_points_constant_hr.iloc[0] - 5.4) < 0.2 and abs(d.expected_difference_points_constant_hr.iloc[-1] - 9.4) < 0.2
