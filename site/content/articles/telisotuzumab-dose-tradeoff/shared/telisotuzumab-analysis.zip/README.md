# Telisotuzumab vedotin initial-dose exploration

Public research, not treatment or clinical-trial dose advice.
Use an existing Python environment with requirements.txt packages.
Run: python analysis/run_analysis.py
Tests: python -m unittest discover -s analysis -p "test_*.py" -q
No downloads/account required. Numeric facts: analysis/inputs.json.

FDA BLA761384 Tables47/48,51/54 and2026DOI10.1002/psp4.70219.
Same-drug public estimated coefficients are reused; NO new individual NLME or ER
estimation and NO synthetic refit of model-generated probabilities. Linear ADC
2comp CL1.34L/day,Vc3.44L,Q1.21L/day,Vp2.41L,30min standardized hypothetical IV, not full labeled procedure/premedication.
mg/L equals microgram/mL.
4096 paired draws with logvariancesCL.0946,Vc.0268;independent here. Fixed-effect
uncertainty/residual error/covariate frequencies/tumor effects omitted. Dose weight
68.9kg chosen;cap100kg implemented. Other covariate multipliers1. Model coefficient
centering not fully verified: albumin0.75/1/1.10 are NORMALIZED RATIOS, not actual
g/L individual predictions. Their powersCL-.970,Vc-.464 are public.

Fixed1.9,fixed1.6,two1.6then1.9 Q2W over84days. Two-dose lead-in period is our
explicit hypothetical choice: FDA proposes lower start but exact duration redacted.
Finite-window AUC by analytic infusion convolution, checked against independent ODE.
These are exposure calculations, NOT clinical proof of safer sequential treatment.

Primary ER uses FIRST14day averageADC concentration, NOT steady/event-average.
ORRlogit=-5.79+2.53ln(1+E),G3PNlogit=-12.3+4.91ln(1+E),E microgram/mL. Outcome
models cover original follow-up conditions, not first14day or84day incidence.
ORR intermediate/highcMet population andPN pooled population differ; nonrandomized
exposure association is NOT causal dose response or approval-only highcMet calibration.
Lead-in and fixedlow have identical C1 scores because input identical; this is
information loss, NOT efficacy/safety equivalence. Event-average Empirical CavgC1 support bounds unverified; exposure-support.csv gives simulated
min/max/percentiles, not a source-supported range. Table52 original
projections are context, NOT validation targets for our C1-based calculations.

Additive scorepORR-lambda*pPN is illustrative preference, not estimated clinical
utility or full benefit-risk. No response-without-PN joint probability. Marginal
coefficient95%CIs define separate9x9 grids; cross-endpoint finite-grid extrema are
sensitivity scenarios, NOT joint95%CIs or guaranteed continuous-space bounds.
Coefficient covariance unavailable; no probability of preferred regimen computed.

MMAE absolute dose-generation/DAR scale and joint random effects not verified.
Only normalized steadyAUC ratio=albuminRatio^-1.99/renalFactor with constant common
generation scale assumed. No absolute MMAEng/mL or complete linked payload model
replay. PN model usesADC, not an invented payload toxicity relation. Tumor-mediated
release/fatalTEAE/time-varying tumor dynamics omitted, so two endpoints cannot
represent overall safety. Patientpercentiles conditional, not confidence intervals.

Original scripts regenerate sevenCSV/threefigures/results.json. Raw source hashes
are the consulted-file snapshot and remain unchanged when no raw directory exists;
they do not constitute renewed source validation. Raw papers, source graphics,
individual records and private planning/reviews not redistributed. Original code
MIT; numeric source facts attributed in inputs/article.
