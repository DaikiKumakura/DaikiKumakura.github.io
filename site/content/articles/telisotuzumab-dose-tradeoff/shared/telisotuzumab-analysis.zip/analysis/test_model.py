"""Independent numerical and regimen-information checks."""
import unittest
import numpy as np
from scipy.integrate import solve_ivp,quad
from model import single,regimen_auc,regimen_profile,response

P=dict(cl=1.34,vc=3.44,q=1.21,vp=2.41);INF=1/48
DAYS=[0,14,28,42,56,70];HIGH=[130.91]*6;LOW=[110.24]*6;LEAD=LOW[:2]+HIGH[2:]


class ModelChecks(unittest.TestCase):
    def test_ode_auc(self):
        def rhs(rate):
            def fun(t,x):
                ac,ap,auc=x;flow=P['q']*(ac/P['vc']-ap/P['vp'])
                return [rate-P['cl']*ac/P['vc']-flow,flow,ac/P['vc']]
            return fun
        first=solve_ivp(rhs(130.91/INF),(0,INF),[0,0,0],rtol=1e-11,atol=1e-12)
        last=solve_ivp(rhs(0),(INF,14),first.y[:,-1],rtol=1e-11,atol=1e-12)
        self.assertAlmostEqual(single(14,130.91,P,INF),last.y[0,-1]/P['vc'],places=9)
        self.assertAlmostEqual(single(14,130.91,P,INF,True),last.y[2,-1],places=8)

    def test_total_auc(self):
        self.assertAlmostEqual(single(1000,130.91,P,INF,True),130.91/P['cl'],places=10)

    def test_integral_derivative(self):
        for t in [.005,.01,.1,2,14]:
            h=1e-6;der=(single(t+h,130.91,P,INF,True)-single(t-h,130.91,P,INF,True))/(2*h)
            self.assertAlmostEqual(der,single(t,130.91,P,INF),delta=2e-6)

    def test_no_future_dose(self):
        self.assertEqual(single(-1,130.91,P,INF),0.)
        self.assertEqual(single(-1,130.91,P,INF,True),0.)

    def test_linearity(self):
        t=np.array([0,.01,.1,3,28])
        np.testing.assert_allclose(single(t,260,P,INF),2*single(t,130,P,INF))

    def test_firstcycle_identity(self):
        a=regimen_auc(0,14,LEAD,DAYS,P,INF);b=regimen_auc(0,14,LOW,DAYS,P,INF)
        self.assertEqual(a,b)
        self.assertEqual(response(a/14,-5.79,2.53),response(b/14,-5.79,2.53))

    def test_dose_ratio(self):
        for w in [(0,14),(0,28),(56,84),(0,84)]:
            a=regimen_auc(*w,LOW,DAYS,P,INF);b=regimen_auc(*w,HIGH,DAYS,P,INF)
            self.assertAlmostEqual(a/b,1.6/1.9,places=12)

    def test_regimen_numerical_integral(self):
        area=0.
        for d in DAYS:
            for start,end in [(d,d+INF),(d+INF,d+14)]:
                area+=quad(lambda t:regimen_profile(t,HIGH,DAYS,P,INF),start,end,epsabs=1e-8)[0]
        self.assertAlmostEqual(area,regimen_auc(0,84,HIGH,DAYS,P,INF),places=7)

    def test_late_recovery(self):
        ratio=regimen_auc(56,84,LEAD,DAYS,P,INF)/regimen_auc(56,84,HIGH,DAYS,P,INF)
        self.assertGreater(ratio,.999)
        self.assertLess(ratio,1.)


if __name__=='__main__':unittest.main()
