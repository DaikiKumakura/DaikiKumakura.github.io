"""Linear ADC model. Time days, dose mg, concentration mg/L = microgram/mL."""
import numpy as np
from scipy.special import expit


def coefficients(p: dict) -> tuple:
    k10=p['cl']/p['vc'];k12=p['q']/p['vc'];k21=p['q']/p['vp']
    s=k10+k12+k21;root=np.sqrt(s*s-4*k10*k21)
    alpha=(s+root)/2;beta=(s-root)/2
    a=(alpha-k21)/(alpha-beta)
    return (a,1-a),(alpha,beta)


def single(t, dose, p: dict, infusion: float, integral: bool=False):
    co,rates=coefficients(p);t=np.maximum(t,0.);result=0.
    for c,k in zip(co,rates):
        if integral:
            # Integral of a finite infusion convolved with exp(-k*t).
            before=t/(k*infusion)+np.expm1(-k*t)/(k*k*infusion)
            after=1/k-np.exp(-k*np.maximum(t-infusion,0))*(-np.expm1(-k*infusion))/(k*k*infusion)
            value=np.where(t<=infusion,before,after)
        else:
            value=np.exp(-k*np.maximum(t-infusion,0))*(-np.expm1(-k*np.minimum(t,infusion)))/(k*infusion)
        result=result+dose/p['vc']*c*value
    return result


def regimen_auc(start: float, end: float, doses: list, days: list, p: dict, infusion: float):
    return sum(single(end-day,dose,p,infusion,True)-single(start-day,dose,p,infusion,True) for dose,day in zip(doses,days))


def regimen_profile(t, doses: list, days: list, p: dict, infusion: float):
    return sum(single(np.asarray(t)-day,dose,p,infusion) for dose,day in zip(doses,days))


def response(exposure, intercept: float, slope: float):
    return expit(intercept+slope*np.log1p(exposure))
