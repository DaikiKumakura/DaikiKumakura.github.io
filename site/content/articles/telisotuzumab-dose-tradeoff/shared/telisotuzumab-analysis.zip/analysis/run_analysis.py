"""Public-coefficient replay and explicit conditional trade-off scenarios."""
from pathlib import Path
import json,hashlib,platform
import numpy as np
import pandas as pd
import scipy
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from model import single,regimen_auc,regimen_profile,response

ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'outputs'
CFG=json.loads((ROOT/'analysis/inputs.json').read_text())
for d in ['figures','tables']:(OUT/d).mkdir(parents=True,exist_ok=True)
COLORS=['#0072B2','#D55E00','#009E73']
plt.rcParams.update({'font.size':11,'axes.spines.top':False,'axes.spines.right':False})


def parameter_set(ratio,eta_cl=0,eta_vc=0):
    p=CFG['adc']
    return dict(cl=p['cl']*ratio**p['albumin_cl_power']*np.exp(eta_cl),vc=p['vc']*ratio**p['albumin_vc_power']*np.exp(eta_vc),q=p['q'],vp=p['vp'])


def main():
    rng=np.random.default_rng(CFG['seed']);z=rng.normal(size=(CFG['virtual_n'],2))
    eta=z*np.sqrt([CFG['adc']['var_cl'],CFG['adc']['var_vc']])
    doses={k:np.array(v)*min(CFG['reference_weight_kg'],CFG['dose_cap_weight_kg']) for k,v in CFG['regimens'].items()}
    days=CFG['dosing_days'];infusion=CFG['infusion_days'];pk=[];er=[];sens=[];summary=[];payload=[];support=[]
    details={}
    for ratio in CFG['albumin_ratios']:
        p=parameter_set(ratio,eta[:,0],eta[:,1]);exposures={}
        base_windows={tuple(w):regimen_auc(*w,doses['high'],days,p,infusion) for w in CFG['auc_windows']}
        for name,dose in doses.items():
            for w in CFG['auc_windows']:
                auc=regimen_auc(*w,dose,days,p,infusion)
                quant=np.quantile(auc,[.05,.5,.95]);rq=np.quantile(auc/base_windows[tuple(w)],[.05,.5,.95])
                pk.append(dict(albumin_ratio=ratio,regimen=name,start=w[0],end=w[1],p05=quant[0],median=quant[1],p95=quant[2],ratio05=rq[0],ratio_median=rq[1],ratio95=rq[2]))
            e=regimen_auc(0,14,dose,days,p,infusion)/14;exposures[name]=e
            eq=np.quantile(e,[.05,.5,.95])
            support.append(dict(albumin_ratio=ratio,regimen=name,n=len(e),minimum=e.min(),p05=eq[0],median=eq[1],p95=eq[2],maximum=e.max(),empirical_cavgc1_support_verified=False))
            for endpoint,coef in CFG['er'].items():
                score=response(e,coef['intercept'],coef['slope']);q=np.quantile(score,[.05,.5,.95])
                er.append(dict(albumin_ratio=ratio,regimen=name,endpoint=endpoint,mean=float(score.mean()),p05=q[0],median=q[1],p95=q[2]))
        np.testing.assert_array_equal(exposures['low'],exposures['lead_in'])
        high,low=exposures['high'],exposures['low'];deltas={};nominal={}
        for endpoint,coef in CFG['er'].items():
            nominal[endpoint]=float(np.mean(response(high,coef['intercept'],coef['slope'])-response(low,coef['intercept'],coef['slope'])))
            values=[]
            for a in np.linspace(*coef['intercept_ci'],9):
                for b in np.linspace(*coef['slope_ci'],9):
                    delta=float(np.mean(response(high,a,b)-response(low,a,b)));values.append(delta)
                    sens.append(dict(albumin_ratio=ratio,endpoint=endpoint,intercept=a,slope=b,delta=delta))
            deltas[endpoint]=np.array(values)
        crossover=nominal['orr']/nominal['pn']
        summary.append(dict(albumin_ratio=ratio,delta_orr=nominal['orr'],delta_pn=nominal['pn'],lambda_crossover=crossover,grid_lambda_min=deltas['orr'].min()/deltas['pn'].max(),grid_lambda_max=deltas['orr'].max()/deltas['pn'].min()))
        details[ratio]=dict(nominal=nominal,grid=deltas)
        for renal,factor in CFG['renal_factors'].items():
            payload.append(dict(albumin_ratio=ratio,renal=renal,relative_mmae_auc=ratio**(-CFG['mmae']['albumin_cl_power'])/factor,relative_adc_auc=ratio**(-CFG['adc']['albumin_cl_power'])))
    for name,data in [('pk-windows',pk),('er-scores',er),('coefficient-grid',sens),('tradeoff',summary),('payload-normalized',payload),('exposure-support',support)]:pd.DataFrame(data).to_csv(OUT/'tables'/f'{name}.csv',index=False)
    # Typical values are separate from averages across conditional subjects.
    typical=[]
    for ratio in CFG['albumin_ratios']:
        p=parameter_set(ratio)
        for name,dose in doses.items():
            e=float(regimen_auc(0,14,dose,days,p,infusion)/14)
            typical.append(dict(albumin_ratio=ratio,regimen=name,cavg_c1=e,orr=float(response(e,**{k:CFG['er']['orr'][k] for k in ['intercept','slope']})),pn=float(response(e,**{k:CFG['er']['pn'][k] for k in ['intercept','slope']}))))
    pd.DataFrame(typical).to_csv(OUT/'tables/typical.csv',index=False)
    make_figures(doses,pk,er,details)
    env=dict(python=platform.python_version(),numpy=np.__version__,pandas=pd.__version__,scipy=scipy.__version__,matplotlib=matplotlib.__version__)
    (OUT/'environment.json').write_text(json.dumps(env,indent=2)+'\n')
    result=dict(virtual_n=CFG['virtual_n'],seed=CFG['seed'],typical=typical,tradeoff=summary,firstcycle_lead_equals_low=True)
    (OUT/'results.json').write_text(json.dumps(result,indent=2)+'\n')
    hashes={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in (ROOT/'data/raw').glob('*') if p.is_file()}
    if hashes:(OUT/'source-hashes.json').write_text(json.dumps(hashes,indent=2)+'\n')
    print(json.dumps(result,indent=2))


def make_figures(doses,pk,er,details):
    fig,axes=plt.subplots(1,2,figsize=(12,4.5),dpi=140);t=np.linspace(0,84,1681);p=parameter_set(1.)
    for name,color,label,style in zip(['high','low','lead_in'],COLORS,['1.9 mg/kg Q2W','1.6 mg/kg Q2W','1.6 twice, then 1.9 mg/kg'],['-','--','-.']):
        axes[0].plot(t,regimen_profile(t,doses[name],CFG['dosing_days'],p,CFG['infusion_days']),color=color,label=label,ls=style)
    axes[0].set(xlabel='Days',ylabel='ADC concentration (microgram/mL)',ylim=(0,None));axes[0].legend(fontsize=8)
    rows=pd.DataFrame(pk);rows=rows[(rows.albumin_ratio==1)&(rows.regimen=='lead_in')]
    axes[1].errorbar(range(len(rows)),rows.ratio_median,yerr=[rows.ratio_median-rows.ratio05,rows.ratio95-rows.ratio_median],fmt='o',color=COLORS[2],capsize=5)
    axes[1].set_xticks(range(len(rows)),[f'{int(r.start)}-{int(r.end)}d' for r in rows.itertuples()]);axes[1].axhline(1,ls='--',color='#888')
    axes[1].set(ylabel='Lead-in / fixed 1.9 AUC',ylim=(0,1.1),title='Conditional 4096 subjects; 5-95% ranges')
    fig.tight_layout();fig.savefig(OUT/'figures/01-pk-regimens.png');plt.close(fig)
    fig,axes=plt.subplots(1,2,figsize=(11,4.3),dpi=140);df=pd.DataFrame(er)
    for ax,endpoint,title in zip(axes,['orr','pn'],['ORR association model','Grade >=3 neuropathy association model']):
        for name,color,label in zip(['high','low'],COLORS,['1.9 mg/kg Q2W','1.6 mg/kg Q2W']):
            sub=df[(df.endpoint==endpoint)&(df.regimen==name)]
            ax.plot(sub.albumin_ratio,100*sub['mean'],'o-',color=color,label=label)
        ax.set(xlabel='Albumin ratio to model-normalized reference',ylabel='Mean conditional model probability (%)',ylim=(0,60),title=title);ax.legend()
    fig.suptitle('Public CavgC1 equations; not causal dose effects or high-cMet calibration',fontsize=10)
    fig.tight_layout();fig.savefig(OUT/'figures/02-er-tradeoff.png');plt.close(fig)
    fig,axes=plt.subplots(1,3,figsize=(13.5,4.2),dpi=140);lambdas=np.linspace(0,5,101)
    for ax,(ratio,d),color in zip(axes,details.items(),COLORS):
        nominal=d['nominal'];grid=d['grid']
        curve=nominal['orr']-lambdas*nominal['pn']
        lower=grid['orr'].min()-lambdas*grid['pn'].max();upper=grid['orr'].max()-lambdas*grid['pn'].min()
        ax.fill_between(lambdas,100*lower,100*upper,color=color,alpha=.15,label='Finite coefficient-grid sensitivity')
        ax.plot(lambdas,100*curve,color=color,label='Nominal coefficients');ax.axhline(0,ls='--',color='#777')
        ax.set(xlabel='Preference weight lambda',ylabel='100 x delta additive score',title=f'Albumin ratio {ratio:g}');ax.legend(fontsize=7)
    fig.suptitle('Fixed 1.9 minus fixed 1.6; shaded ranges are NOT confidence intervals',fontsize=11)
    fig.tight_layout();fig.savefig(OUT/'figures/03-preference-sensitivity.png');plt.close(fig)


if __name__=='__main__':main()
