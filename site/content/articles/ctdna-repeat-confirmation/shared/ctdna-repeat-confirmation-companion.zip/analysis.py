"""Exact probabilities for serial binary testing in a static latent state."""
import csv
import sys


def first_positive_probabilities(n, p, required):
    """Return the probability of first meeting the rule at each draw."""
    streak = [1.0] + [0.0] * (required - 1)
    first_positive = []
    for _ in range(n):
        first_positive.append(p * streak[-1])
        streak = [(1.0 - p) * sum(streak)] + [p * x for x in streak[:-1]]
    return first_positive


def triggered(n, p, required):
    return sum(first_positive_probabilities(n, p, required))


def rows():
    for n in (2, 4, 8):
        for required in (1, 2):
            detected_by_draw = first_positive_probabilities(n, 0.70, required)
            sensitivity = sum(detected_by_draw)
            mean_detection_draw = sum(
                draw * probability
                for draw, probability in enumerate(detected_by_draw, start=1)
            ) / sensitivity
            for persistent_fraction in (0.0, 0.005, 0.01):
                # Preserve the per-draw false-positive probability at 0.01.
                transient = (0.01 - persistent_fraction) / (1 - persistent_fraction)
                false_positive = persistent_fraction + (1 - persistent_fraction) * triggered(
                    n, transient, required
                )
                for prevalence in (0.05, 0.20):
                    true_flag = prevalence * sensitivity
                    false_flag = (1 - prevalence) * false_positive
                    yield (n, required, persistent_fraction, prevalence, sensitivity,
                           false_positive, true_flag / (true_flag + false_flag),
                           false_flag * 1000, mean_detection_draw)


if __name__ == "__main__":
    assert abs(triggered(2, .7, 2) - .49) < 1e-12
    assert abs(triggered(8, .01, 1) - (1 - .99**8)) < 1e-12
    writer = csv.writer(sys.stdout, lineterminator="\n")
    writer.writerow(("visits", "positive_run", "persistent_fraction", "prevalence",
                     "sensitivity", "false_positive", "ppv", "false_flags_per_1000",
                     "mean_detection_draw_given_detected_mrd"))
    writer.writerows(rows())
