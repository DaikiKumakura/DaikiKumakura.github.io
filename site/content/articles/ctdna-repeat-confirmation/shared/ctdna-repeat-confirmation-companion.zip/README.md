# Serial ctDNA testing

This deterministic probability model uses no patient data.
Run with Python 3.12.4 (standard library only):

    python analysis.py > results.csv

The CSV contains 36 scenarios. Sensitivity and false-positive probability refer to
classification by the final draw conditional on true MRD status. Mean detection draw
is computed among patients with MRD classified by each rule within its draw limit.
