# Which checks flag the bias of the pooled exposure-response model when severity drives clearance?
# Reuses the data-generating code of ../dose-optimization-selection/simulate.R (definitions only) and scores, per simulated trial:
# (a) in-sample checks of the pooled logistic E-R model (significance of the exposure slope, agreement of fitted and observed response rates by arm),
# (b) a comparison with the randomized arm contrast (model-based gain versus observed arm difference), and (c) the decision flip.
# Run: Rscript check_er_checks.R 1000   (trials per cell; seed 20261124)
script_dir <- dirname(normalizePath(sub("^--file=", "", grep("^--file=", commandArgs(FALSE), value = TRUE)[1]), winslash = "/"))
src <- readLines(file.path(script_dir, "../dose-optimization-selection/simulate.R"))
eval(parse(text = src[seq_len(grep("^set.seed", src)[1] - 1)]))   # definitions only (draw, calib, truth, SCEN, constants)
args <- commandArgs(trailingOnly = TRUE); NREP3 <- if (length(args) >= 1) as.integer(args[1]) else 1000L
set.seed(20261124L); rows <- list()
for (cn in c("clean", "confounded")) {
  kappa <- if (cn == "clean") 0 else 0.4
  for (sn in c("S1_gain", "S2_flat")) {
    sc <- SCEN[[sn]]; cal <- calib(sc, kappa); tr <- truth(sc, cal, kappa); true_gain <- tr$orr[2] - tr$orr[1]
    for (n in c(40, 100)) {
      res <- t(vapply(seq_len(NREP3), function(i) {
        dose <- rep(DOSES, each = n); p <- draw(2 * n, dose, kappa)
        y <- rbinom(2 * n, 1, expit(cal$a_r + sc$b_r * p$lc - SEV_RESP * p$s))
        d <- data.frame(dose = dose, y = y, lc = p$lc)
        f <- suppressWarnings(glm(y ~ lc, binomial, d)); f0 <- suppressWarnings(glm(y ~ 1, binomial, d))
        lrt_p <- pchisq(f0$deviance - f$deviance, 1, lower.tail = FALSE)
        fit_by_arm <- tapply(fitted(f), dose, mean); obs_by_arm <- tapply(y, dose, mean)
        max_cal_gap <- max(abs(fit_by_arm - obs_by_arm))
        base <- d$lc - ifelse(d$dose == 2, log(2), 0)
        at <- function(sh) { nd <- d; nd$lc <- base + sh; mean(predict(f, nd, type = "response")) }
        gain_model <- at(log(2)) - at(0)
        r1 <- obs_by_arm[["2"]] - obs_by_arm[["1"]]
        se1 <- sqrt(obs_by_arm[["2"]] * (1 - obs_by_arm[["2"]]) / n + obs_by_arm[["1"]] * (1 - obs_by_arm[["1"]]) / n)
        c(lrt_sig = as.numeric(lrt_p < 0.05), cal_ok = as.numeric(max_cal_gap < 0.02), gain_model = gain_model, gain_arm = r1,
          flagged = as.numeric(abs(gain_model - r1) > 1.96 * se1), model_high = as.numeric(gain_model >= GAIN), arm_high = as.numeric(r1 >= GAIN),
          flip = as.numeric((gain_model >= GAIN) != (r1 >= GAIN)))
      }, numeric(8)))
      rows[[length(rows) + 1]] <- data.frame(config = cn, scenario = sn, n_per_arm = n, trials = NREP3, true_gain = true_gain,
        share_exposure_slope_significant = mean(res[, "lrt_sig"]), share_arm_rates_fit_within_0.02 = mean(res[, "cal_ok"]),
        mean_gain_model = mean(res[, "gain_model"]), mean_gain_arm = mean(res[, "gain_arm"]),
        share_model_arm_gap_flagged = mean(res[, "flagged"]), share_model_high = mean(res[, "model_high"]), share_arm_high = mean(res[, "arm_high"]), share_decision_flip = mean(res[, "flip"]))
    }
  }
}
out <- do.call(rbind, rows); rownames(out) <- NULL; write.csv(out, file.path(script_dir, "results/er-checks.csv"), row.names = FALSE)
options(width = 230); o <- out; o[5:13] <- round(o[5:13], 3); print(o, row.names = FALSE)
