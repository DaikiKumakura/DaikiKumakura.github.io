# Figure for the M15 article (Okabe-Ito palette): share of studies in which the check that compares the model with independent or richer information flagged the problem.
# Run: Rscript figures.R (after check_er_checks.R, check_nlme_aic.R and the three source analyses)
script_dir <- dirname(normalizePath(sub("^--file=", "", grep("^--file=", commandArgs(FALSE), value = TRUE)[1]), winslash = "/"))
suppressPackageStartupMessages(library(ggplot2))
er <- read.csv(file.path(script_dir, "results/er-checks.csv")); er <- er[er$scenario == "S2_flat", ]
tg <- read.csv(file.path(script_dir, "../tgi-growth-misspecification/results/summary.csv")); tg <- tg[tg$model == "exp" & tg$beta %in% c(0.02, 0.05), ]
nl <- read.csv(file.path(script_dir, "results/nlme-aic.csv"))
d <- rbind(
  data.frame(panel = "A. Exposure-response model: gap to the randomized arm contrast (x: patients per arm)", x = er$n_per_arm, share = er$share_model_arm_gap_flagged,
             series = ifelse(er$config == "confounded", "Severity drives clearance", "No confounding")),
  data.frame(panel = "B. Tumour growth model: AIC prefers the Gompertz model (x: study duration, days)", x = tg$duration_days, share = tg$aic_prefers_gompertz,
             series = ifelse(tg$beta == 0.05, "Gompertz rate 0.05 per day", "Gompertz rate 0.02 per day")),
  data.frame(panel = "C. Population PK model: AIC prefers the full random-effects model (x: samples per subject)", x = nl$samples_per_subject, share = nl$share_full_preferred_by_aic_returned, series = "40 subjects"))
d$series <- factor(d$series, c("No confounding", "Severity drives clearance", "Gompertz rate 0.02 per day", "Gompertz rate 0.05 per day", "40 subjects"))
cols <- c("No confounding" = "#000000", "Severity drives clearance" = "#D55E00", "Gompertz rate 0.02 per day" = "#E69F00", "Gompertz rate 0.05 per day" = "#0072B2", "40 subjects" = "#009E73")
xl_unused <- c("A. Exposure-response model: gap to the randomized arm contrast (x: patients per arm)" = "Patients per arm", "B. Tumour growth model: AIC prefers the Gompertz model (x: study duration, days)" = "Study duration (days)",
        "C. Population PK model: AIC prefers the full random-effects model (x: samples per subject)" = "Samples per subject")
p <- ggplot(d, aes(x, 100 * share, colour = series, group = series)) + geom_line(linewidth = 0.8) + geom_point(size = 2.6) +
  facet_wrap(~panel, scales = "free_x", labeller = label_wrap_gen(34)) + scale_colour_manual(values = cols, name = NULL) +
  scale_y_continuous(limits = c(0, 105), breaks = seq(0, 100, 25)) + scale_x_continuous(breaks = function(l) sort(unique(d$x))[sort(unique(d$x)) >= l[1] & sort(unique(d$x)) <= l[2]]) +
  labs(x = NULL, y = "Share of simulated studies in which the check flagged the problem (%)") + theme_bw(base_size = 11) + theme(legend.position = "bottom")
ggsave(file.path(script_dir, "figures/figure-1-checks.png"), p, width = 10, height = 5, dpi = 160)
