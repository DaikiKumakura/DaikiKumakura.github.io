# Does a likelihood comparison between the full model (random effects on CL, V and ka) and the reduced model (CL and V only) prefer the full model?
# Reuses the data-generating definitions of ../poppk-sparse-nlme/simulate.R. 40 subjects; 2, 3, 4 or 6 samples per subject; each study uses set.seed(SEED + rep * 1000 + ns).
# Run: Rscript check_nlme_aic.R 200   (studies per cell; seed 20261125)
script_dir <- dirname(normalizePath(sub("^--file=", "", grep("^--file=", commandArgs(FALSE), value = TRUE)[1]), winslash = "/"))
src <- readLines(file.path(script_dir, "../poppk-sparse-nlme/simulate.R"))
eval(parse(text = src[seq_len(grep("^one_study <- function", src)[1] - 1)]))   # constants and simulate_data
args <- commandArgs(trailingOnly = TRUE); NREP4 <- if (length(args) >= 1) as.integer(args[1]) else 200L
SEED4 <- 20261125L; NCORES <- max(1L, parallel::detectCores() - 1L)
one <- function(task) {
  suppressPackageStartupMessages(library(nlme)); set.seed(SEED4 + task$rep * 1000L + task$ns)
  d <- simulate_data(40, task$ns, NULL)
  model <- function(t, lCL, lV, lka) { cl <- exp(lCL); v <- exp(lV); ka <- exp(lka); ke <- cl / v; log(DOSE * ka / (v * (ka - ke)) * (exp(-ke * t) - exp(-ka * t))) }
  assign("model", model, envir = globalenv()); assign("DOSE", DOSE, envir = globalenv())
  fit <- function(re) { w <- FALSE
    f <- try(withCallingHandlers(nlme(y ~ model(t, lCL, lV, lka), data = d, fixed = lCL + lV + lka ~ 1, random = re, groups = ~id, start = START$default,
      control = nlmeControl(maxIter = 100, msMaxIter = 200, returnObject = TRUE)),
      warning = function(x) { if (!grepl("fewer observations than random effects", conditionMessage(x))) w <<- TRUE; invokeRestart("muffleWarning") }), silent = TRUE)
    if (inherits(f, "try-error")) return(c(ok = 0, aic = NA, warned = NA, sigma = NA))
    c(ok = 1, aic = AIC(f), warned = as.numeric(w), sigma = f$sigma) }
  a <- fit(pdDiag(lCL + lV + lka ~ 1)); b <- fit(pdDiag(lCL + lV ~ 1))
  c(ns = task$ns, rep = task$rep, full_ok = a[["ok"]], full_aic = a[["aic"]], full_warned = a[["warned"]], red_ok = b[["ok"]], red_aic = b[["aic"]], red_warned = b[["warned"]], full_sigma = a[["sigma"]], red_sigma = b[["sigma"]])
}
tasks <- do.call(c, lapply(c(2, 3, 4, 6), function(ns) lapply(seq_len(NREP4), function(r) list(ns = ns, rep = r))))
cl <- parallel::makeCluster(NCORES); parallel::clusterExport(cl, c("SEED4", "DOSE", "TCL", "TV", "TKA", "OMEGA", "SIGMA", "WINDOWS", "START", "simulate_data"))
res <- as.data.frame(do.call(rbind, parallel::parLapplyLB(cl, tasks, one))); parallel::stopCluster(cl)
write.csv(res, file.path(script_dir, "results/nlme-aic-raw.csv"), row.names = FALSE)
rows <- lapply(c(2, 3, 4, 6), function(ns) { r <- res[res$ns == ns, ]; both <- r$full_ok == 1 & r$red_ok == 1; clean <- both & r$full_warned == 0 & r$red_warned == 0
  data.frame(samples_per_subject = ns, studies = nrow(r), both_returned = mean(both), both_clean = mean(clean),
    share_full_preferred_by_aic_returned = mean(r$full_aic[both] < r$red_aic[both]), share_full_preferred_by_aic_clean = if (any(clean)) mean(r$full_aic[clean] < r$red_aic[clean]) else NA,
    n_clean = sum(clean), median_aic_gain_of_full_returned = median(r$red_aic[both] - r$full_aic[both])) })
out <- do.call(rbind, rows); write.csv(out, file.path(script_dir, "results/nlme-aic.csv"), row.names = FALSE)
options(width = 230); o <- out; o[3:8] <- round(o[3:8], 3); print(o, row.names = FALSE)
