# Companion: applying the ICH M15 assessment elements to three simulated dose-selection analyses

Code and results for the article "How much evaluation does model risk call for? Applying the ICH M15 assessment elements to three simulated dose-selection analyses with known truth". No patient or animal data are used.

## Files

- `check_er_checks.R`: for the near-plateau dose-selection setting, with and without severity-driven clearance, computes in-sample checks of the pooled exposure-response model (significance of the exposure slope, agreement of fitted and observed arm response rates) and the comparison of the model-based gain with the randomized arm contrast (`Rscript check_er_checks.R 1000`; seed 20261124; writes `results/er-checks.csv`). It reads the data-generating code of the dose-selection study (`simulate.R`, from that study's companion, placed in `../dose-optimization-selection/`).
- `check_nlme_aic.R`: for 40 subjects and 2, 3, 4 or 6 samples per subject, fits the full (random effects on CL, V and ka) and the reduced (CL and V) population PK model with nlme and compares them by AIC (`Rscript check_nlme_aic.R 200`; seed 20261125; writes `results/nlme-aic.csv` and `results/nlme-aic-raw.csv`). It reads the data-generating code of the population PK study (`simulate.R`, from that study's companion, placed in `../poppk-sparse-nlme/`).
- `figures.R`: draws Figure 1 from `results/er-checks.csv`, `results/nlme-aic.csv` and the results of the tumour growth study (`../tgi-growth-misspecification/results/summary.csv`). Requires ggplot2.
- `results/`: the results files and the R session information.

## Reproduce

Place the companions of the three source studies next to this folder (`dose-optimization-selection/`, `tgi-growth-misspecification/`, `poppk-sparse-nlme/`), then run

```
Rscript check_er_checks.R 1000
Rscript check_nlme_aic.R 200
Rscript figures.R
```

Each script finds its own folder, so it can be run from any directory. The outputs depend on the random-number stream of the R version used (R 4.5.3).
