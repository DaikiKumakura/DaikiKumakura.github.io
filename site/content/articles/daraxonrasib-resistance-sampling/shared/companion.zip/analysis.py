q = 16/44
for ratio in (.5, 1, 2):
    p = q/(q + ratio*(1-q))
    print(f"{ratio:g} {p:.6f}")
    assert abs(p*ratio/(p*ratio+1-p)-q) < 1e-12
