# Setidegrasib (ASP3082): non-clinical PK/PD–tumor model and what it can identify

Companion code for the note "Setidegrasib dosing interval: plasma half-life or intratumoral retention?" (Japanese and English).

## What is here

| File | Role |
| --- | --- |
| `extract_inputs.py` | Reads the public Source Data workbook and writes long-format tables to `derived/` (fields: source_doi, figure, panel, sheet, species, tumor_model, analyte, dose, dose_unit, route, time, time_unit, value, value_unit, replicate, n, uncertainty_type, data_origin) |
| `model.py` | ODE model (two-compartment plasma, saturable tumor elimination, KRAS G12D turnover with drug-driven degradation, Gompertz tumor growth with additive kill or growth modulation) |
| `analysis.py` | Stages `pk`, `pd`, `growth`, `effect`, `draws`, `external`, `extdrv`, `regimens`, `sens`; writes `results/` |
| `stages_extra.py`, `stages_sens.py`, `stages_checks.py` | Parameter draws, external prediction, regimen simulation, structural sensitivity, human-extrapolation scenarios |
| `figures.py` | Figures (`figures/`) |
| `test_analysis.py` | 10 numerical checks: units, mass balance, positivity, zero dose, closed forms, step-size independence, dose proportionality, equal-intensity exposure |
| `results/` | Fitted parameters (JSON), prediction tables, regimen metrics, scenario tables (CSV) |

## Data

The input is Supplementary Data 3 (Source Data) of Yoshinari et al., Commun Chem 2025, doi:10.1038/s42004-025-01662-4 (CC BY-NC-ND). Because of the license, the extracted tables are not redistributed. Download the workbook from the article page, save it as `inputs/raw/source_data3.xlsx` (SHA-256 `941c00c67629a7d888a2ac4050d2e41057c021c89043fb0644ecec2b4113cbb1`), and run `python extract_inputs.py`.

No human data are used in any fit.

## Run

```bash
pip install -r requirements.txt
python extract_inputs.py
python -m pytest test_analysis.py -q
python analysis.py          # about 15 min; stages can be selected, e.g. python analysis.py pk pd
python figures.py
python stages_checks.py     # method checks (interpolated kdeg intervals, QW-recalibrated direction test, dosing-clock sensitivity)
```

Random seed: 20261105 (set in `analysis.py`). Python 3.12; NumPy 2.2; SciPy 1.14; pandas 2.2; matplotlib 3.9.

## Scope

Public-data model evaluation, not a dose recommendation. Parameter draws are conditional parameter scenarios (Laplace approximation plus animal resampling), not a patient population. Human extrapolation is a scenario analysis with assumed scaling and was not compared with human PK/PD data.
