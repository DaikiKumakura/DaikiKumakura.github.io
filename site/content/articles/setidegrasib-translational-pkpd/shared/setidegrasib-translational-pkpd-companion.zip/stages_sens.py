"""Sensitivity of regimen ordering and human-extrapolation scenarios (conditional parameter scenarios, not a population)."""
from __future__ import annotations

import json

import numpy as np
import pandas as pd
from scipy.stats import spearmanr

import analysis as A
import stages_extra as X
from model import simulate

BW_MOUSE_KG = 0.025   # approximate mean body weight of the Figure 4c/5 mice (about 22-32 g in Source Data)
BW_HUMAN_KG = 70.0    # assumed reference adult; no human body weights are used in any fit
EQUAL_INTENSITY = ["QW 30 (30/wk)", "BIW 15 (30/wk)", "Q2W 60 (30/wk)"]


def regimen_set(p, names):
    out = {}
    for n in names:
        dose, iv = X.REGIMENS[n]
        m, *_ = X.regimen_metrics(p, dose, iv)
        out[n] = m
    return out


def stage_structural(pk_res, pd_res, gr, eff) -> pd.DataFrame:
    """Rank of equal-intensity regimens when kdeg (not identified) and the PD driver vary over their profile-likelihood sets."""
    prof = pd.read_csv(A.RES / "pd_kdeg_profile.csv")
    g59 = gr["PK-59"]
    rows = []
    for _, r in prof.iterrows():
        if not np.isfinite(r.kmax) or r.kmax > 1e4:
            continue
        row = dict(pk_res["params"], kdeg=r.kdeg, kmax=r.kmax, DC50=r.DC50, s1=eff["tumor|gompertz|linear"]["params"][0])
        p = X.pk59_params(row, g59, driver=r.driver)
        ms = regimen_set(p, EQUAL_INTENSITY)
        for n, m in ms.items():
            rows.append(dict(driver=r.driver, kdeg=r.kdeg, delta_2ll=r.delta_2ll, regimen=n, **m))
    df = pd.DataFrame(rows)
    df.to_csv(A.RES / "structural_scenarios.csv", index=False)
    return df


def stage_draw_sensitivity(draws: pd.DataFrame) -> pd.DataFrame:
    allm = pd.read_csv(A.RES / "regimen_metrics_all.csv")
    d = allm[(allm.source == "draw") & allm.regimen.isin(EQUAL_INTENSITY)]
    wide = d.pivot(index="draw", columns="regimen", values="min_D")
    diff = wide["Q2W 60 (30/wk)"] - wide["QW 30 (30/wk)"]
    rows = []
    for c in A.PK_NAMES + A.PD_NAMES + ["s1"]:
        rho, p = spearmanr(draws.set_index("draw").loc[diff.index, c], diff)
        rows.append(dict(parameter=c, spearman_rho=float(rho), p_value=float(p)))
    out = pd.DataFrame(rows).sort_values("spearman_rho", key=lambda s: -s.abs())
    out.to_csv(A.RES / "draw_sensitivity_trough_difference.csv", index=False)
    return out


HUMAN_DOSES_MG = [10, 25, 50, 100, 200, 300, 400, 600, 800]


def scale_params(row: dict, b: float) -> dict:
    f = (BW_HUMAN_KG / BW_MOUSE_KG) ** (b - 1.0)
    out = dict(row)
    for k in ("k10", "k12", "k21", "kin", "Vm"):
        out[k] = row[k] * f
    return out


def stage_human(pk_res, pd_res, gr, eff) -> pd.DataFrame:
    """Scenario extrapolation. Mouse PK/PD parameters fixed first; allometric exponent b scales clearance-type rate constants
    (k ~ BW^(b-1)); distribution volume per kg, Km and the PD parameters are carried over unchanged (assumptions, not estimates)."""
    base_row = dict(pk_res["params"], **pd_res["tumor_h1"]["params"], s1=eff["tumor|gompertz|linear"]["params"][0])
    kd_ci = pd_res["kdeg_profile_ci95_tumor"]
    scenarios = []
    for b in (0.67, 0.75, 0.85, 1.0):
        for kd_label, kd in (("point", base_row["kdeg"]), ("kdeg_low", kd_ci[0]), ("kdeg_high", kd_ci[1])):
            scenarios.append((b, kd_label, kd))
    rows = []
    for b, kd_label, kd in scenarios:
        row = scale_params(base_row, b)
        row["kdeg"] = kd
        # re-center kmax so that the product kmax/DC50 (the only PD potency quantity identified at low Ct) stays at its profile value
        prof = pd.read_csv(A.RES / "pd_kdeg_profile.csv")
        pt = prof[(prof.driver == "tumor")].iloc[(prof[prof.driver == "tumor"].kdeg - kd).abs().argsort()[:1]]
        row["kmax"], row["DC50"] = float(pt.kmax.iloc[0]), float(pt.DC50.iloc[0])
        for dose_mg in HUMAN_DOSES_MG:
            dose = dose_mg / BW_HUMAN_KG
            p = X.pk59_params(row, gr["PK-59"])
            t_dose = np.arange(0.0, 42.0 * 24.0, 7.0 * 24.0)
            tg = np.arange(0.0, 42.0 * 24.0 + 1e-9, 2.0)
            o = simulate(p, [(float(t), dose) for t in t_dose], tg, V0=200.0, max_step=2.0)
            D = 1.0 - o[:, 3]
            w = (tg >= 21 * 24) & (tg <= 42 * 24)
            rows.append(dict(b=b, kdeg_label=kd_label, kdeg=kd, dose_mg_qw=dose_mg, dose_mg_per_kg=dose, mean_D=float(D[w].mean()),
                             trough_D=float(D[w].min()), tumor_trough_ng_g=float(o[w, 2].min()), tumor_peak_ng_g=float(o[w, 2].max())))
    df = pd.DataFrame(rows)
    df.to_csv(A.RES / "human_scenarios.csv", index=False)
    # body-surface-area dose conversion (conventional Km factors 3 for mouse, 37 for adult human)
    hed = pd.DataFrame([dict(mouse_dose_mg_per_kg=d, hed_mg_per_kg=d * 3.0 / 37.0, hed_mg_70kg=d * 3.0 / 37.0 * BW_HUMAN_KG) for d in (0.3, 1, 3, 10, 30)])
    hed.to_csv(A.RES / "human_equivalent_dose_bsa.csv", index=False)
    return df
