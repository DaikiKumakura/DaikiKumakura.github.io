"""Figures for the setidegrasib note. Reads results/ and inputs/; writes figures/*.png (image text in English)."""
from __future__ import annotations

import json

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from matplotlib.patches import FancyArrowPatch, FancyBboxPatch

import analysis as A
import stages_extra as X
from model import simulate

FIG = A.HERE / "figures"
FIG.mkdir(exist_ok=True)
OI = dict(black="#000000", orange="#E69F00", sky="#56B4E9", green="#009E73", yellow="#F0E442", blue="#0072B2", verm="#D55E00", pink="#CC79A7")
plt.rcParams.update({"font.size": 9, "axes.spines.top": False, "axes.spines.right": False, "figure.dpi": 150, "savefig.dpi": 200})

pk_res = json.loads((A.RES / "pk_fit.json").read_text())
pd_res = json.loads((A.RES / "pd_fit.json").read_text())
gr = json.loads((A.RES / "growth_vehicle_fits.json").read_text())
eff = json.loads((A.RES / "effect_fits.json").read_text())
draws = pd.read_csv(A.RES / "param_draws.csv")
PKP = pk_res["params"]
PDT = pd_res["tumor_h1"]["params"]
PDP = pd_res["plasma_h1"]["params"]


def save(fig, name):
    fig.tight_layout()
    fig.savefig(FIG / name, bbox_inches="tight")
    plt.close(fig)
    print("saved", name)


def fig1_structure():
    fig, ax = plt.subplots(figsize=(7.2, 3.6))
    ax.set_xlim(0, 10)
    ax.set_ylim(0, 5)
    ax.axis("off")
    boxes = {"Central\nA1 (Cp)": (0.4, 3.0, OI["sky"]), "Peripheral\nA2": (0.4, 0.8, OI["sky"]), "Tumor\nCt (ng/g)": (3.0, 3.0, OI["orange"]),
             "KRAS G12D\nr = R/R0": (5.6, 3.0, OI["green"]), "Tumor volume\nV": (8.0, 3.0, OI["verm"])}
    for lab, (x, y, c) in boxes.items():
        ax.add_patch(FancyBboxPatch((x, y), 1.8, 1.2, boxstyle="round,pad=0.05", fc=c, ec="k", alpha=0.75))
        ax.text(x + 0.9, y + 0.6, lab, ha="center", va="center")

    def arr(a, b, txt, **kw):
        ax.add_patch(FancyArrowPatch(a, b, arrowstyle="-|>", mutation_scale=10, lw=1.2, **kw))
        ax.text((a[0] + b[0]) / 2, (a[1] + b[1]) / 2 + 0.2, txt, ha="center", fontsize=7.5)

    arr((2.2, 3.8), (3.0, 3.8), "kin")
    arr((4.8, 3.6), (5.6, 3.6), "kmax (drive)")
    arr((7.4, 3.6), (8.0, 3.6), "growth\nmodulation")
    arr((1.1, 3.0), (1.1, 2.0), "k12")
    arr((1.6, 2.0), (1.6, 3.0), "k21")
    arr((0.4, 3.9), (-0.1, 3.9), "k10")
    ax.text(0.1, 4.7, "IV bolus (mg/kg)", fontsize=8)
    ax.annotate("", xy=(0.6, 4.3), xytext=(0.6, 4.65), arrowprops=dict(arrowstyle="-|>"))
    ax.text(3.9, 2.55, "saturable loss\nVm Ct/(Km+Ct)", ha="center", fontsize=7.5)
    ax.text(6.5, 2.3, "resynthesis kdeg (1 - r)", ha="center", fontsize=7.5)
    ax.text(6.2, 0.9, "Structural alternatives compared:\n driver = tumor concentration Ct  |  driver = plasma concentration Cp\n effect = additive kill  |  growth modulation (1 - c D),  D = 1 - r",
            ha="center", fontsize=8, bbox=dict(boxstyle="round", fc="white", ec="grey"))
    save(fig, "fig1_model_structure.png")


def fig2_pk():
    d = pd.read_csv(A.INP / "pk_mouse_fig4a.csv")
    c = pd.read_csv(A.RES / "pk_fit_curves.csv")
    fig, axs = plt.subplots(1, 3, figsize=(8.4, 3.0), sharex=True)
    cols = {10: OI["blue"], 30: OI["verm"]}
    for ax, an, unit, key in zip(axs, ["plasma", "tumor", "pancreas"], ["ng/mL", "ng/g", "ng/g"], ["plasma_ng_ml", "tumor_ng_g", None]):
        for dose in (10, 30):
            s = d[(d.analyte == an) & (d.dose == dose)]
            ax.plot(s.time + (0.9 if dose == 30 else 0), s.value.replace(0, np.nan), "o", ms=3.5, color=cols[dose], alpha=0.7,
                    label=f"{dose} mg/kg observed")
            if key:
                cc = c[c.dose == dose]
                ax.plot(cc.time, cc[key], "-", color=cols[dose], label=f"{dose} mg/kg fitted")
        ax.set_yscale("log")
        ax.set_xlabel("Time after dose (h)")
        ax.set_ylabel(f"{an.capitalize()} ({unit})")
        ax.set_title(an.capitalize() + (" (not modelled)" if an == "pancreas" else ""), fontsize=9)
    axs[0].legend(fontsize=6.5, frameon=False)
    axs[0].text(0.02, 0.04, "plasma 10 mg/kg at 144 h: below\nquantification (not plotted)", transform=axs[0].transAxes, fontsize=6.5)
    save(fig, "fig2_pk_fit.png")


def fig3_kras():
    d = pd.read_csv(A.INP / "pd_kras_fig4b.csv")
    c = pd.read_csv(A.RES / "pd_fit_curves.csv")
    fig, axs = plt.subplots(1, 3, figsize=(8.6, 3.1))
    cols = {10: OI["blue"], 30: OI["verm"]}
    for dose in (10, 30):
        s = d[d.dose == dose]
        axs[0].plot(s.time, s.value, "o", ms=3.5, color=cols[dose], alpha=0.7, label=f"{dose} mg/kg observed")
        for nm, ls in (("tumor_h1", "-"), ("plasma_h1", "--")):
            cc = c[(c.model == nm) & (c.dose == dose)]
            axs[0].plot(cc.time, cc.rel_kras * 100, ls, color=cols[dose], lw=1.3)
    axs[0].plot([], [], "k-", label="tumor-driven fit")
    axs[0].plot([], [], "k--", label="plasma-driven fit")
    axs[0].set_xlabel("Time after dose (h)")
    axs[0].set_ylabel("KRAS(G12D) (% of vehicle)")
    axs[0].legend(fontsize=6.5, frameon=False)
    axs[0].set_title("Observed and fitted", fontsize=9)
    pk = pd.read_csv(A.RES / "pk_fit_curves.csv")
    for dose in (10, 30):
        cc = pk[pk.dose == dose]
        axs[1].plot(cc.time, cc.plasma_ng_ml, color=cols[dose], label=f"plasma {dose} mg/kg")
        axs[1].plot(cc.time, cc.tumor_ng_g, color=cols[dose], ls=":", label=f"tumor {dose} mg/kg")
    axs[1].axhline(38 * A.MW_G_MOL / 1000, color="grey", lw=0.8)
    axs[1].text(60, 38 * A.MW_G_MOL / 1000 * 1.3, "in vitro DC50 38 nM\n(about 42 ng/mL)", fontsize=6.5)
    axs[1].set_yscale("log")
    axs[1].set_ylim(0.3, 2e4)
    axs[1].set_xlabel("Time after dose (h)")
    axs[1].set_ylabel("Fitted concentration (ng/mL or ng/g)")
    axs[1].legend(fontsize=6, frameon=False, ncol=2)
    axs[1].set_title("Drivers: plasma falls, tumor stays", fontsize=9)
    prof = pd.read_csv(A.RES / "pd_kdeg_profile.csv")
    for drv, col in (("tumor", OI["green"]), ("plasma", OI["pink"])):
        pp = prof[prof.driver == drv]
        axs[2].plot(np.log(2) / pp.kdeg, pp.delta_2ll, "-o", ms=3, color=col, label=f"{drv}-driven")
    axs[2].axhline(3.84, color="grey", ls="--", lw=0.8)
    axs[2].text(1.2, 5.0, "approx. 95% cut (3.84)", fontsize=6.5)
    axs[2].set_xscale("log")
    axs[2].set_ylim(-1, 40)
    axs[2].set_xlabel("Assumed KRAS half-life ln2/kdeg (h)")
    axs[2].set_ylabel("Profile deviance increase")
    axs[2].legend(fontsize=7, frameon=False)
    axs[2].set_title("kdeg is conditional on the driver", fontsize=9)
    save(fig, "fig3_kras_degradation.png")


def fig4_tumor():
    d = A.load_tumor("tumor_pk59_fig4c.csv")
    fig, axs = plt.subplots(1, 2, figsize=(8.0, 3.2))
    cols = {0: "k", 0.3: OI["yellow"], 1: OI["orange"], 3: OI["verm"], 10: OI["blue"], 30: OI["sky"]}
    for panel, effect, dcol, key in ((0, "growthmod", "c", "tumor|gompertz|growthmod"), (1, "linear", "s1", "tumor|gompertz|linear")):
        ax = axs[panel]
        par = eff[key]["params"][0]
        for dose in (0, 0.3, 1, 3, 10, 30):
            g = d[d.dose == dose]
            m = g.groupby("time").value.mean()
            ax.plot(m.index / 24, m.values, "o", ms=3.5, color=cols[dose], mec="k" if dose in (0.3, 1, 3) else cols[dose])
            pkpd = dict(PKP, driver="tumor", **PDT)
            p = A.base_params(**pkpd, kg=gr["PK-59"]["kg_gomp_per_day"] / 24, K=gr["PK-59"]["K_gomp"], effect=effect)
            p["c" if effect == "growthmod" else "s1"] = par
            p["_dose"] = dose
            sim = A.simulate_group(p, A.SCHEDULES["fig4c"], g)
            mm = sim.groupby("time").pred.mean()
            tt = np.linspace(0, 504, 200)
            sims = []
            for a, ga in g.groupby("animal"):
                o = simulate(p, [(float(x) * 24, float(dose)) for x in A.SCHEDULES["fig4c"]] if dose > 0 else [], tt, V0=ga.sort_values("time").value.values[0])
                sims.append(o[:, 4])
            ax.plot(tt / 24, np.mean(sims, axis=0), "-" if dose in (0, 10, 30) else "--", color=cols[dose], lw=1.4,
                    label=f"{dose} mg/kg" + (" (held out)" if dose in (0.3, 1, 3) else ""))
        for dday in A.SCHEDULES["fig4c"]:
            ax.axvline(dday, color="grey", lw=0.5, ls=":")
        ax.set_xlabel("Study day")
        ax.set_ylabel("Tumor volume (mm3), mean of n = 5")
        ax.set_title(("Growth modulation" if panel == 0 else "Additive kill") + ": solid = fitted, dashed = predicted", fontsize=8)
    axs[0].legend(fontsize=6.5, frameon=False, ncol=2)
    save(fig, "fig4_tumor_growth.png")


def fig4b_external():
    c = pd.read_csv(A.INP / "external_prediction_curves.csv")
    models = list(dict.fromkeys(c.tumor_model))
    fig, axs = plt.subplots(2, 4, figsize=(9.6, 4.6), sharey=True)
    for ax, m in zip(axs.ravel(), models):
        for (sched, dose), col in (((k), v) for k, v in {("QW", 30): OI["blue"], ("BIW", 30): OI["verm"], ("BIW", 10): OI["orange"]}.items()):
            sub = c[(c.tumor_model == m) & (c.schedule == sched) & (c.dose == dose) & (c.effect_model == "growthmod")]
            if sub.empty:
                continue
            ax.plot(sub.time_h / 24, sub.obs_ratio, "o", color=col, ms=3.5)
            ax.plot(sub.time_h / 24, sub.pred_ratio, "-", color=col, lw=1.2, label=f"{sched} {dose}")
            ax.fill_between(sub.time_h / 24, sub.lo90, sub.hi90, color=col, alpha=0.15)
        ax.set_title(m, fontsize=8)
        ax.set_yscale("log")
        ax.axhline(1, color="grey", lw=0.5)
        ax.legend(fontsize=6, frameon=False)
    axs[1, 3].axis("off")
    for ax in axs[1, :3]:
        ax.set_xlabel("Study day")
    for ax in axs[:, 0]:
        ax.set_ylabel("V / V(day 0)")
    save(fig, "fig4b_external_prediction.png")


def regimen_curve(p, dose, iv, days=56):
    t = np.arange(0.0, days * 24.0 + 1e-9, 1.0)
    o = simulate(p, [(float(x), dose) for x in np.arange(0.0, days * 24.0, iv * 24.0)], t, V0=200.0, max_step=1.0)
    return t, o


def fig5_regimens():
    g59 = gr["PK-59"]
    row = dict(PKP, **PDT, s1=eff["tumor|gompertz|linear"]["params"][0])
    rowp = dict(PKP, **PDP, s1=eff["tumor|gompertz|linear"]["params"][0])
    regs = [("QW 30 (30/wk)", OI["blue"]), ("BIW 15 (30/wk)", OI["verm"]), ("Q2W 60 (30/wk)", OI["green"])]
    fig, axs = plt.subplots(2, 3, figsize=(9.2, 5.0), sharex=True)
    for j, (title, rw, drv) in enumerate((("tumor-driven", row, "tumor"), ("plasma-driven", rowp, "plasma"))):
        p = X.pk59_params(rw, g59, driver=drv)
        for name, col in regs:
            dose, iv = X.REGIMENS[name]
            t, o = regimen_curve(p, dose, iv)
            axs[j, 0].plot(t / 24, o[:, 0] / p["V1"], color=col, lw=1)
            axs[j, 1].plot(t / 24, o[:, 2], color=col, lw=1)
            axs[j, 2].plot(t / 24, 1 - o[:, 3], color=col, lw=1.2, label=name.split(" (")[0])
        axs[j, 0].set_yscale("log")
        axs[j, 0].set_ylabel(f"{title}\nPlasma (ng/mL)")
        axs[j, 1].set_ylabel("Tumor (ng/g)")
        axs[j, 2].set_ylabel("KRAS degradation D")
        axs[j, 2].set_ylim(0, 1.02)
    axs[0, 2].legend(fontsize=7, frameon=False, loc="lower right")
    for ax in axs[1]:
        ax.set_xlabel("Day")
    save(fig, "fig5_regimens.png")


def fig6_surface():
    g59 = gr["PK-59"]
    doses = np.array([5, 10, 15, 20, 30, 45, 60, 90.0])
    ivs = np.array([3.5, 7.0, 10.5, 14.0, 21.0])
    fig, axs = plt.subplots(1, 2, figsize=(8.0, 3.3))
    for ax, (title, rw, drv) in zip(axs, (("tumor-driven", dict(PKP, **PDT, s1=0.01), "tumor"), ("plasma-driven", dict(PKP, **PDP, s1=0.01), "plasma"))):
        p = X.pk59_params(rw, g59, driver=drv)
        Z = np.zeros((len(ivs), len(doses)))
        for i, iv in enumerate(ivs):
            for j, dse in enumerate(doses):
                m, *_ = X.regimen_metrics(p, dse, iv, horizon_d=84.0, window=(42.0, 84.0))
                Z[i, j] = m["frac_time_D_ge_90"]
        im = ax.imshow(Z, origin="lower", aspect="auto", vmin=0, vmax=1, cmap="viridis")
        ax.set_xticks(range(len(doses)))
        ax.set_xticklabels([f"{int(x)}" for x in doses])
        ax.set_yticks(range(len(ivs)))
        ax.set_yticklabels([f"{x:g}" for x in ivs])
        ax.set_xlabel("Dose per administration (mg/kg)")
        ax.set_ylabel("Dosing interval (days)")
        ax.set_title(title, fontsize=9)
        np.savetxt(A.RES / f"surface_frac_D90_{drv}.csv", Z, delimiter=",", fmt="%.4f")
    fig.colorbar(im, ax=axs, label="Fraction of days 42-84 with D >= 0.9", shrink=0.9)
    fig.savefig(FIG / "fig6_response_surface.png", bbox_inches="tight")
    plt.close(fig)
    print("saved fig6")


def fig7_sensitivity():
    s = pd.read_csv(A.RES / "structural_scenarios.csv")
    sen = pd.read_csv(A.RES / "draw_sensitivity_trough_difference.csv")
    fig, axs = plt.subplots(1, 3, figsize=(9.4, 3.1))
    cols = {"QW 30 (30/wk)": OI["blue"], "BIW 15 (30/wk)": OI["verm"], "Q2W 60 (30/wk)": OI["green"]}
    for ax, drv in zip(axs[:2], ("tumor", "plasma")):
        for name, col in cols.items():
            sub = s[(s.driver == drv) & (s.regimen == name)]
            ax.plot(np.log(2) / sub.kdeg, sub.min_D, "-o", ms=3, color=col, label=name.split(" (")[0])
        ax.set_xscale("log")
        ax.set_ylim(0, 1.02)
        ax.set_xlabel("Assumed KRAS half-life (h)")
        ax.set_ylabel("Trough D (days 28-56)")
        ax.set_title(f"{drv}-driven", fontsize=9)
    axs[0].legend(fontsize=7, frameon=False, loc="lower right")
    top = sen.head(8).iloc[::-1]
    axs[2].barh(top.parameter, top.spearman_rho, color=[OI["blue"] if v > 0 else OI["verm"] for v in top.spearman_rho])
    axs[2].axvline(0, color="k", lw=0.5)
    axs[2].set_xlabel("Spearman rho with trough(Q2W 60) - trough(QW 30)\nacross 60 parameter draws")
    axs[2].set_title("Within-structure parameter sensitivity", fontsize=9)
    save(fig, "fig7_uncertainty_sensitivity.png")


def fig8_human():
    h = pd.read_csv(A.RES / "human_scenarios.csv")
    fig, axs = plt.subplots(1, 2, figsize=(8.0, 3.2), sharey=True)
    cols = {0.67: OI["sky"], 0.75: OI["blue"], 0.85: OI["orange"], 1.0: OI["verm"]}
    for ax, lab in zip(axs, ("point", "kdeg_low")):
        for b, col in cols.items():
            sub = h[(h.b == b) & (h.kdeg_label == lab)]
            ax.plot(sub.dose_mg_qw, sub.trough_D, "-o", ms=3, color=col, label=f"b = {b}")
        ax.axvspan(10, 800, color="grey", alpha=0.08)
        ax.axvline(600, color="k", ls="--", lw=0.8)
        ax.set_xscale("log")
        ax.set_xlabel("Weekly IV dose (mg; 70 kg adult assumed)")
        ax.set_title(("kdeg at point estimate" if lab == "point" else "kdeg at lower profile bound (slower resynthesis)"), fontsize=8)
    axs[0].set_ylabel("Predicted trough D, weeks 4-6")
    axs[0].legend(fontsize=7, frameon=False)
    axs[0].text(620, 0.05, "600 mg\n(phase 2 dose)", fontsize=6.5)
    save(fig, "fig8_human_scenarios.png")


if __name__ == "__main__":
    fig1_structure()
    fig2_pk()
    fig3_kras()
    fig4_tumor()
    fig4b_external()
    fig5_regimens()
    fig6_surface()
    fig7_sensitivity()
    fig8_human()
