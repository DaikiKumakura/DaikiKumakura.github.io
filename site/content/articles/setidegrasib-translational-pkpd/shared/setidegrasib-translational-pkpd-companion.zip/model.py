"""Reduced PK/PD/tumor model for ASP3082 (setidegrasib) in mouse xenografts.

States (all per kg body weight of the mouse, dose-normalised units):
  A1  amount in central compartment, ng per g body weight  (= mg/kg x 1e3 ... see DOSE_TO_NG)
  A2  amount in peripheral compartment
  Ct  total tumor concentration, ng/g tumor
  r   KRAS(G12D) level relative to the untreated steady state (r = R/R0), dimensionless
  V   tumor volume, mm3

Equations
  dA1/dt = -(k10 + k12) A1 + k21 A2           (IV bolus into A1)
  dA2/dt =  k12 A1 - k21 A2
  Cp     = A1 / V1                           (ng/mL)
  dCt/dt = kin Cp - Vm Ct / (Km + Ct)         (saturable tumor elimination; Km -> inf gives linear kout = Vm/Km)
  dr/dt  = kdeg (1 - r) - kmax Ct^h/(DC50^h + Ct^h) r      (driver 'tumor') or Cp as driver ('plasma')
  dV/dt  = kg V ln(K/V) - S(D) V            additive kill, S = s1 D (effect 'linear')
  dV/dt  = kg V ln(K/V) (1 - c D)           growth modulation (effect 'growthmod'); c > 1 allows regression
  with D = 1 - r (degradation fraction); Gompertz growth (large K gives near-exponential growth)

Mass balance of the PK block is checked in test_analysis.py (A1 + A2 + eliminated = dose).
"""
from __future__ import annotations

import numpy as np
from scipy.integrate import solve_ivp

DOSE_TO_NG = 1.0e3  # 1 mg/kg = 1 ug/g body weight = 1e3 ng/g body weight


def pk_derivs(t, y, p):
    A1, A2, Ct = y[0], y[1], y[2]
    cp = A1 / p["V1"]
    dA1 = -(p["k10"] + p["k12"]) * A1 + p["k21"] * A2
    dA2 = p["k12"] * A1 - p["k21"] * A2
    dCt = p["kin"] * cp - p["Vm"] * max(Ct, 0.0) / (p["Km"] + max(Ct, 0.0))
    return dA1, dA2, dCt, cp


def full_rhs(t, y, p):
    dA1, dA2, dCt, cp = pk_derivs(t, y, p)
    Ct, r, V = max(y[2], 0.0), y[3], y[4]
    drive = Ct if p.get("driver", "tumor") == "tumor" else cp
    h = p.get("h", 1.0)
    kd = p["kmax"] * drive**h / (p["DC50"] ** h + drive**h)
    dr = p["kdeg"] * (1.0 - r) - kd * r
    D = 1.0 - r
    S = effect_rate(D, p)
    Vp = max(V, 1e-9)
    if p.get("effect", "linear") == "growthmod":
        dV = p["kg"] * Vp * np.log(p["K"] / Vp) * (1.0 - p["c"] * D)
    else:
        dV = p["kg"] * Vp * np.log(p["K"] / Vp) - S * Vp
    return [dA1, dA2, dCt, dr, dV]


def effect_rate(D, p):
    form = p.get("effect", "linear")
    D = np.clip(D, 0.0, 1.0)
    if form == "linear":
        return p["s1"] * D
    if form == "growthmod":
        return 0.0
    if form == "emax":
        return p["smax"] * D ** p.get("gamma", 1.0) / (p["D50"] ** p.get("gamma", 1.0) + D ** p.get("gamma", 1.0))
    raise ValueError(form)


def simulate(p, doses, t_eval, V0=None, with_growth=True, max_step=2.0):
    """Simulate dose events [(time_h, dose_mg_per_kg), ...] and return states at t_eval (hours).

    Doses are IV bolus into the central compartment at the given times. Each inter-dose segment is integrated up to
    its end point regardless of where t_eval falls, so the state carried into the next dose does not depend on the
    evaluation grid. A t_eval value equal to a dose time returns the post-dose state.
    Returns an array (len(t_eval), 5) with columns A1, A2, Ct, r, V.
    """
    t_eval = np.asarray(t_eval, float)
    t_end = float(t_eval.max())
    dose_at = {}
    for tm, d in sorted(doses):
        dose_at[tm] = dose_at.get(tm, 0.0) + d
    y = np.array([0.0, 0.0, 0.0, 1.0, V0 if V0 is not None else 1.0])
    out = np.full((len(t_eval), 5), np.nan)
    seg_starts = sorted(set([0.0] + [tm for tm in dose_at if 0.0 <= tm < t_end]))
    seg_starts.append(t_end)
    for i in range(len(seg_starts) - 1):
        t0, t1 = seg_starts[i], seg_starts[i + 1]
        if t0 in dose_at:
            y[0] += dose_at[t0] * DOSE_TO_NG
        if t1 <= t0:
            continue
        last = i == len(seg_starts) - 2
        sel = (t_eval >= t0) & ((t_eval <= t1) if last else (t_eval < t1))
        grid = np.unique(np.concatenate([t_eval[sel], [t1]]))
        sol = solve_ivp(lambda t, yy: full_rhs(t, yy, p), (t0, t1), y, method="LSODA", t_eval=grid,
                        rtol=1e-8, atol=1e-10, max_step=max_step)
        pos = np.searchsorted(grid, t_eval[sel])
        out[np.where(sel)[0], :] = sol.y.T[pos]
        y = sol.y[:, -1].copy()
    if t_end == 0.0:
        out[:] = y
    elif t_end in dose_at:
        out[t_eval == t_end, 0] += dose_at[t_end] * DOSE_TO_NG
    return out


def gompertz_closed(V0, kg, K, t):
    """Closed form of dV/dt = kg V ln(K/V)."""
    return K * np.exp(np.log(V0 / K) * np.exp(-kg * t))
