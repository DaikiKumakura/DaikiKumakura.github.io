"""Numerical and unit checks for model.py (pytest)."""
import json
from pathlib import Path

import numpy as np
import pandas as pd
import pytest

import analysis as A
from model import DOSE_TO_NG, gompertz_closed, simulate

HERE = Path(__file__).resolve().parent


def params(**kw):
    return A.base_params(**kw)


def test_zero_dose_gives_zero_exposure_and_unchanged_target():
    p = params(kmax=1.0, DC50=100.0, kdeg=0.05, kg=0.0, K=1e4)
    o = simulate(p, [(0.0, 0.0)], np.array([0.0, 24.0, 144.0]), V0=100.0)
    assert np.allclose(o[:, :3], 0.0)
    assert np.allclose(o[:, 3], 1.0, atol=1e-9)
    assert np.allclose(o[:, 4], 100.0, rtol=1e-6)  # kg = 0: no growth


def test_one_compartment_matches_exponential_and_dose_units():
    p = params(V1=1.5, k10=0.3, k12=0.0, k21=0.0, kin=0.0, Vm=0.0, Km=1.0, kmax=0.0, kg=0.0)
    t = np.array([0.0, 2.0, 6.0, 24.0])
    o = simulate(p, [(0.0, 10.0)], t, V0=1.0)
    cp = o[:, 0] / p["V1"]
    expect = 10.0 * DOSE_TO_NG / p["V1"] * np.exp(-0.3 * t)   # 10 mg/kg -> ng/mL
    assert np.allclose(cp, expect, rtol=1e-5)
    assert DOSE_TO_NG == 1000.0


def test_mass_balance_of_pk_block():
    """A1 + A2 + eliminated = dose when tumor uptake is switched off (kin = 0); eliminated = k10 * integral(A1)."""
    p = params(V1=1.0, k10=0.4, k12=0.1, k21=0.05, kin=0.0, Vm=0.0, Km=1.0, kmax=0.0, kg=0.0)
    t = np.linspace(0.0, 400.0, 4001)
    o = simulate(p, [(0.0, 5.0)], t, V0=1.0, max_step=0.5)
    eliminated = np.trapezoid(p["k10"] * o[:, 0], t)
    total = o[-1, 0] + o[-1, 1] + eliminated
    assert total == pytest.approx(5.0 * DOSE_TO_NG, rel=2e-3)


def test_positivity_and_bounds():
    pk = json.loads((A.RES / "pk_fit.json").read_text())["params"]
    pdp = json.loads((A.RES / "pd_fit.json").read_text())["tumor_h1"]["params"]
    p = params(**pk, **pdp, kg=0.004, K=5e3, s1=0.01, effect="linear")
    t = np.arange(0.0, 24 * 28.0, 1.0)
    o = simulate(p, [(24.0 * d, 30.0) for d in (1, 8, 15)], t, V0=200.0)
    assert (o[:, :3] >= -1e-9).all()
    assert ((o[:, 3] > 0) & (o[:, 3] <= 1.0 + 1e-9)).all()
    assert (o[:, 4] > 0).all()


def test_gompertz_matches_closed_form_without_drug():
    p = params(kg=0.004, K=3000.0, kmax=0.0)
    t = np.array([0.0, 24.0, 96.0, 240.0, 504.0])
    o = simulate(p, [], t, V0=250.0)
    assert np.allclose(o[:, 4], gompertz_closed(250.0, 0.004, 3000.0, t), rtol=1e-5)


def test_time_step_independence():
    pk = json.loads((A.RES / "pk_fit.json").read_text())["params"]
    pdp = json.loads((A.RES / "pd_fit.json").read_text())["tumor_h1"]["params"]
    p = params(**pk, **pdp, kg=0.004, K=5e3, s1=0.01, effect="linear")
    t = np.array([24.0, 96.0, 336.0, 504.0])
    a = simulate(p, [(24.0, 30.0), (192.0, 30.0)], t, V0=200.0, max_step=2.0)
    b = simulate(p, [(24.0, 30.0), (192.0, 30.0)], t, V0=200.0, max_step=0.25)
    assert np.allclose(a, b, rtol=1e-4, atol=1e-6)


def test_state_does_not_depend_on_evaluation_grid():
    """Regression test: the state carried across a dose must not depend on where t_eval falls inside the segment."""
    pk = json.loads((A.RES / "pk_fit.json").read_text())["params"]
    pdp = json.loads((A.RES / "pd_fit.json").read_text())["tumor_h1"]["params"]
    p = params(**pk, **pdp, kg=0.004, K=5e3, s1=0.01, effect="linear")
    doses = [(24.0, 0.3), (192.0, 0.3), (336.0, 0.3)]
    coarse = simulate(p, doses, np.array([0.0, 96.0, 168.0, 240.0, 504.0]), V0=300.0)
    fine = simulate(p, doses, np.arange(0.0, 505.0, 24.0), V0=300.0)
    only_end = simulate(p, doses, np.array([0.0, 504.0]), V0=300.0)
    assert coarse[-1, 4] == pytest.approx(fine[-1, 4], rel=1e-8)
    assert coarse[-1, 4] == pytest.approx(only_end[-1, 4], rel=1e-8)


def test_linear_pk_dose_proportionality_without_saturation():
    p = params(Km=1e12, Vm=1e12 * 0.0165, kmax=0.0, kg=0.0)
    t = np.array([6.0, 48.0, 144.0])
    a = simulate(p, [(0.0, 10.0)], t, V0=1.0)
    b = simulate(p, [(0.0, 30.0)], t, V0=1.0)
    assert np.allclose(b[:, :3], 3.0 * a[:, :3], rtol=1e-4)


def test_equal_intensity_exposure_linear_pk():
    """With linear PK the mean plasma amount over a long window depends on dose intensity only (QW 30 vs Q2W 60)."""
    p = params(V1=1.0, k10=0.5, k12=0.03, k21=0.03, kin=0.0, Vm=0.0, Km=1.0, kmax=0.0, kg=0.0)
    t = np.arange(0.0, 24 * 140.0, 0.5)
    qw = simulate(p, [(24.0 * 7 * k, 30.0) for k in range(20)], t, V0=1.0, max_step=0.5)
    q2 = simulate(p, [(24.0 * 14 * k, 60.0) for k in range(10)], t, V0=1.0, max_step=0.5)
    sel = (t >= 24 * 70) & (t <= 24 * 126)
    assert np.trapezoid(qw[sel, 0], t[sel]) == pytest.approx(np.trapezoid(q2[sel, 0], t[sel]), rel=2e-3)


def test_input_tables_complete():
    d = pd.read_csv(A.INP / "pk_mouse_fig4a.csv")
    assert len(d) == 108 and d.value.isna().sum() == 0
    assert set(d.analyte) == {"plasma", "tumor", "pancreas"}
    v = pd.read_csv(A.INP / "tumor_pk59_fig4c.csv")
    assert v.groupby(["dose", "time"]).size().eq(5).all()
    for f in ("tumor_fig5a.csv", "tumor_sup7a.csv", "tumor_fig5b_pdx.csv"):
        assert pd.read_csv(A.INP / f).value.notna().all()
