"""Additional checks requested by the method review: interpolated kdeg intervals, dosing-clock sensitivity, and a QW-recalibrated
test of the QW-to-BIW direction (potency re-estimated on the QW group of each tumor model, BIW predicted).

Run after the main pipeline: python stages_checks.py
"""
from __future__ import annotations

import json

import numpy as np
import pandas as pd
from scipy.optimize import least_squares

import analysis as A
import stages_extra as X


def interp_interval(prof: pd.DataFrame, driver: str, cut: float = 3.84) -> dict:
    p = prof[prof.driver == driver].sort_values("kdeg")
    lk, dv = np.log(p.kdeg.values), p.delta_2ll.values
    i_min = int(np.argmin(dv))
    lo = hi = None
    for i in range(i_min, 0, -1):          # walk left
        if dv[i - 1] > cut >= dv[i]:
            lo = float(np.exp(lk[i - 1] + (cut - dv[i - 1]) * (lk[i] - lk[i - 1]) / (dv[i] - dv[i - 1])))
            break
    for i in range(i_min, len(dv) - 1):    # walk right
        if dv[i + 1] > cut >= dv[i]:
            hi = float(np.exp(lk[i] + (cut - dv[i]) * (lk[i + 1] - lk[i]) / (dv[i + 1] - dv[i])))
            break
    return dict(driver=driver, kdeg_at_min=float(p.kdeg.values[i_min]), lower=lo, upper=hi,
                lower_open=lo is None, upper_open=hi is None,
                half_life_h_lower=float(np.log(2) / hi) if hi else None, half_life_h_upper=float(np.log(2) / lo) if lo else None)


def qw_recalibrated(pk_res, pd_res, gr) -> pd.DataFrame:
    rows = []
    for driver, pdname in (("tumor", "tumor_h1"), ("plasma", "plasma_h1")):
        pkpd = dict(pk_res["params"], driver=driver, **pd_res[pdname]["params"])
        for m, (csv, qw, biw) in X.EXT.items():
            d = A.load_tumor(csv)
            d = d[d.tumor_model == m]
            kg_h = gr[m]["kg_exp_per_day"] / 24.0
            v0 = d[d.time == 0].set_index("animal").value
            gq = d[(d.dose == 30) & (d.route == "IV:QW")]
            gb = d[(d.dose == 30) & (d.route == "IV:BIW")]

            def resid(th):
                sim = X.predict_group(pkpd, float(np.exp(th[0])), kg_h, gq, 30, qw, "growthmod")
                sim = sim[sim.time > 0]
                return (np.log(sim.pred) - np.log(sim.obs)).values

            f = least_squares(resid, [np.log(1.5)], bounds=([-5], [3]))
            c_hat = float(np.exp(f.x[0]))
            out = {}
            for lab, g, days in (("QW", gq, qw), ("BIW", gb, biw)):
                sim = X.predict_group(pkpd, c_hat, kg_h, g, 30, days, "growthmod")
                sim = sim[sim.time > 0].copy()
                sim["v0"] = sim.animal.map(v0)
                out[lab] = (float((sim.obs / sim.v0).groupby(sim.time).mean().iloc[-1]), float((sim.pred / sim.v0).groupby(sim.time).mean().iloc[-1]))
            rows.append(dict(driver=driver, tumor_model=m, c_fitted_on_QW=c_hat, obs_diff_ln_QW_over_BIW=float(np.log(out["QW"][0] / out["BIW"][0])),
                             pred_diff_ln_QW_over_BIW=float(np.log(out["QW"][1] / out["BIW"][1])), pred_QW=out["QW"][1], pred_BIW=out["BIW"][1],
                             obs_QW=out["QW"][0], obs_BIW=out["BIW"][0]))
    df = pd.DataFrame(rows)
    df.to_csv(A.INP / "external_qw_recalibrated.csv", index=False)   # observed-data summaries: not distributed
    return df


def dose_clock_shift(pk_res, pd_res, gr) -> dict:
    """Move every dose one day earlier (day d -> (d-1)*24 h) and repeat the effect fit and the external direction check."""
    orig = {k: list(v) for k, v in A.SCHEDULES.items()}
    for k in A.SCHEDULES:                 # in-place so that stages_extra.EXT lists follow
        A.SCHEDULES[k][:] = [d - 1 for d in A.SCHEDULES[k]]
    try:
        eff, _ = A.stage_effect(pk_res, pd_res, gr)
        keep = {k: dict(aic=v["aic"], params=v["params"], heldout=v.get("heldout_doses")) for k, v in eff.items() if isinstance(v, dict) and "aic" in v}
        ext = X.stage_external_driver_comparison(pk_res, pd_res, gr, eff)
        ext = ext.assign(pred_ok=ext.pred_BIW_better == ext.obs_BIW_better)
        sign = ext.groupby("driver").pred_ok.sum().to_dict()
    finally:
        for k in A.SCHEDULES:
            A.SCHEDULES[k][:] = orig[k]
    return dict(effect=keep, external_direction_matches=sign)


def replicate_noise() -> dict:
    """Within-cell replicate SD of log(relative KRAS) for the vehicle and for the treated groups used in the PD fit, and the
    lack-of-fit ratio of the fitted tumor- and plasma-driven structures (RMSE / pooled treated-group SD) with an F test."""
    from scipy.stats import f as fdist
    d = A.load_pd()
    out = {}
    for name, sel in (("vehicle", d.dose == 0), ("treated_10_30", d.dose > 0)):
        g = d[sel].assign(lr=lambda z: np.log(z.rel))
        ss = float(((g.lr - g.groupby(["dose", "time"]).lr.transform("mean")) ** 2).sum())
        df = int(len(g) - g.groupby(["dose", "time"]).ngroups)
        out[name] = dict(sd_log=float(np.sqrt(ss / df)), ss_within=ss, df=df)
    pdres = json.loads((A.RES / "pd_fit.json").read_text())
    for k in ("tumor_h1", "plasma_h1"):
        rss, n = pdres[k]["rss"], pdres[k]["n"]
        n_par = 3
        ss_lof = rss - out["treated_10_30"]["ss_within"]
        df_lof = (n - n_par) - out["treated_10_30"]["df"]
        F = (ss_lof / df_lof) / (out["treated_10_30"]["ss_within"] / out["treated_10_30"]["df"])
        out[k] = dict(rmse=pdres[k]["rmse_log"], ratio_to_treated_sd=pdres[k]["rmse_log"] / out["treated_10_30"]["sd_log"],
                      ratio_to_vehicle_sd=pdres[k]["rmse_log"] / out["vehicle"]["sd_log"], F=float(F), df_lof=int(df_lof), p=float(1 - fdist.cdf(F, df_lof, out["treated_10_30"]["df"])))
    return out


if __name__ == "__main__":
    import warnings
    warnings.filterwarnings("ignore")
    pk_res = json.loads((A.RES / "pk_fit.json").read_text())
    pd_res = json.loads((A.RES / "pd_fit.json").read_text())
    gr = json.loads((A.RES / "growth_vehicle_fits.json").read_text())
    prof = pd.read_csv(A.RES / "pd_kdeg_profile.csv")
    iv = [interp_interval(prof, d) for d in ("tumor", "plasma")]
    (A.RES / "kdeg_profile_intervals_interpolated.json").write_text(json.dumps(iv, indent=1))
    print(iv)
    q = qw_recalibrated(pk_res, pd_res, gr)
    print(q.round(3).to_string())
    shift = dose_clock_shift(pk_res, pd_res, gr)
    # the stage_effect call above rewrote effect_fits.json with shifted clocks: restore by recomputing with the original clock
    eff0, _ = A.stage_effect(pk_res, pd_res, gr)
    X.stage_external_driver_comparison(pk_res, pd_res, gr, eff0)   # restore the original-clock table overwritten by the shifted run
    noise = replicate_noise()
    (A.RES / "pd_replicate_noise.json").write_text(json.dumps(noise, indent=1))
    print(noise)
    (A.RES / "dose_clock_shift_sensitivity.json").write_text(json.dumps(shift, indent=1))
    print(json.dumps(shift["external_direction_matches"]))
