"""Stages that build on the fitted model: parameter draws, external predictions, regimen simulations.

Imported by analysis.py (main). Kept in a separate module so each file stays readable.
"""
from __future__ import annotations

import numpy as np
import pandas as pd
from scipy.optimize import least_squares

import analysis as A
from model import simulate


def resample_animals(d: pd.DataFrame, rng) -> pd.DataFrame:
    parts = []
    for dose, g in d.groupby("dose"):
        animals = g.animal.unique()
        pick = rng.choice(animals, size=len(animals), replace=True)
        for j, a in enumerate(pick):
            x = g[g.animal == a].copy()
            x["animal"] = f"{dose}|{j}"
            parts.append(x)
    return pd.concat(parts)


def fit_s1(pkpd, d4c, gr, doses=(0, 10, 30), growth_form="gompertz", effect="linear") -> float:
    f = least_squares(A.effect_resid, [np.log(0.01 if effect == "linear" else 1.3)], args=(pkpd, d4c, gr, effect, list(doses), growth_form),
                      bounds=([-12], [3]), max_nfev=60)
    return float(np.exp(f.x[0]))


def stage_draws(pk_res, pd_res, gr, n_draws: int = 60) -> pd.DataFrame:
    """PK and PD parameter draws from Laplace approximations (log scale); the effect slope s1 is re-fitted per draw on
    animal-resampled Figure 4c data (vehicle, 10 and 30 mg/kg groups)."""
    rng = np.random.default_rng(A.SEED + 1)
    d4c = A.load_tumor("tumor_pk59_fig4c.csv")
    pk_th, pk_cov = np.array(pk_res["theta_log"]), np.array(pk_res["cov_log"])
    pdf = pd_res["tumor_h1"]
    pd_th, pd_cov = np.array(pdf["theta_log"]), np.array(pdf["cov_log"])
    rows = []
    for k in range(n_draws):
        th_pk = np.clip(rng.multivariate_normal(pk_th, pk_cov, check_valid="ignore"), pk_th - 2.0, pk_th + 2.0)
        th_pd = np.clip(rng.multivariate_normal(pd_th, pd_cov, check_valid="ignore"), pd_th - 2.0, pd_th + 2.0)
        pk = dict(zip(A.PK_NAMES, np.exp(th_pk)))
        pdp = dict(zip(A.PD_NAMES, np.exp(th_pd)))
        pkpd = dict(pk, driver="tumor", **pdp)
        boot = resample_animals(d4c, rng)
        s1 = fit_s1(pkpd, boot, gr)
        s1e = fit_s1(pkpd, boot, gr, growth_form="exp")
        c_g = fit_s1(pkpd, boot, gr, growth_form="gompertz", effect="growthmod")
        c_e = fit_s1(pkpd, boot, gr, growth_form="exp", effect="growthmod")
        rows.append(dict(draw=k, **pk, **pdp, s1=s1, s1_exp=s1e, c=c_g, c_exp=c_e))
        if k % 10 == 0:
            print("draw", k, round(s1, 5), flush=True)
    df = pd.DataFrame(rows)
    df.to_csv(A.RES / "param_draws.csv", index=False)
    return df


EXT = {
    "AsPC-1": ("tumor_fig5a.csv", A.SCHEDULES["QW"], A.SCHEDULES["BIW"]),
    "GP2d": ("tumor_fig5a.csv", A.SCHEDULES["QW"], A.SCHEDULES["BIW"]),
    "HPAC": ("tumor_sup7a.csv", A.SCHEDULES["QW"], A.SCHEDULES["BIW"]),
    "KP-4": ("tumor_sup7a.csv", A.SCHEDULES["QW"], A.SCHEDULES["BIW"]),
    "GP5d": ("tumor_sup7a.csv", A.SCHEDULES["QW"], A.SCHEDULES["BIW"]),
    "PK-1": ("tumor_sup7a.csv", A.SCHEDULES["QW_PK1"], A.SCHEDULES["BIW_PK1"]),
}


def params_from_row(row, driver: str = "tumor") -> dict:
    return dict({k: float(row[k]) for k in A.PK_NAMES + A.PD_NAMES}, driver=driver)


def predict_group(pkpd, s1, kg_per_h, g, dose, days, effect="linear"):
    p = A.base_params(**pkpd, kg=kg_per_h / np.log(1e9 / 250.0), K=1.0e9, effect=effect)
    p["c" if effect == "growthmod" else "s1"] = s1
    p["_dose"] = dose
    return A.simulate_group(p, days, g)


def stage_external(pk_res, pd_res, gr, eff, draws) -> pd.DataFrame:
    point = dict(pk_res["params"], driver="tumor", **pd_res["tumor_h1"]["params"])
    rows, curves, cases = [], [], []
    for m, (csv, qw, biw) in EXT.items():
        d = A.load_tumor(csv)
        d = d[d.tumor_model == m]
        cases.append((m, d, [("QW", 30, qw), ("BIW", 30, biw)]))
    dpdx = A.load_tumor("tumor_fig5b_pdx.csv")
    cases.append(("LXFA1125 PDX", dpdx, [("BIW", 10, A.SCHEDULES["pdx_BIW"]), ("BIW", 30, A.SCHEDULES["pdx_BIW"])]))
    for effect, pkey, dcol in (("linear", "tumor|exp|linear", "s1_exp"), ("growthmod", "tumor|exp|growthmod", "c_exp")):
        eff_point = eff[pkey]["params"][0]
        for m, d, regs in cases:
            kg_h = gr[m]["kg_exp_per_day"] / 24.0
            veh = d[d.dose == 0]
            v0_all = d[d.time == 0].set_index("animal").value
            vv = veh.assign(v0=veh.animal.map(v0_all))
            vr = float((vv.value / vv.v0)[vv.time == vv.time.max()].mean())
            for sched, dose, days in regs:
                g = d[(d.dose == dose) & (d.route == f"IV:{sched}")]
                sim = predict_group(point, eff_point, kg_h, g, dose, days, effect)
                sim = sim[sim.time > 0].copy()
                sim["v0"] = sim.animal.map(v0_all)
                sim["obs_ratio"], sim["pred_ratio"] = sim.obs / sim.v0, sim.pred / sim.v0
                mo, mp = sim.groupby("time").obs_ratio.mean(), sim.groupby("time").pred_ratio.mean()
                band = []
                for _, r in draws.iterrows():
                    sb = predict_group(params_from_row(r), float(r[dcol]), kg_h, g, dose, days, effect)
                    sb = sb[sb.time > 0].copy()
                    sb["v0"] = sb.animal.map(v0_all)
                    band.append((sb.pred / sb.v0).groupby(sb.time).mean().values)
                lo, hi = np.percentile(np.array(band), [5, 95], axis=0)
                for t, o, pm, lw, hg in zip(mo.index, mo.values, mp.values, lo, hi):
                    curves.append(dict(effect_model=effect, tumor_model=m, schedule=sched, dose=dose, time_h=t,
                                       obs_ratio=o, pred_ratio=pm, lo90=lw, hi90=hg))
                rows.append(dict(effect_model=effect, tumor_model=m, schedule=sched, dose=dose, final_day=mo.index[-1] / 24.0,
                                 obs_ratio_final=float(mo.iloc[-1]), pred_ratio_final=float(mp.iloc[-1]),
                                 pred_over_obs=float(mp.iloc[-1] / mo.iloc[-1]),
                                 rmse_log_ratio=float(np.sqrt(np.mean((np.log(mp.values) - np.log(mo.values)) ** 2))),
                                 obs_in_band_final=bool(lo[-1] <= mo.iloc[-1] <= hi[-1]), obs_vehicle_ratio_final=vr))
    ext = pd.DataFrame(rows)
    ext.to_csv(A.INP / "external_prediction_summary.csv", index=False)  # contains observed-data summaries: kept out of the companion package
    pd.DataFrame(curves).to_csv(A.INP / "external_prediction_curves.csv", index=False)
    print(ext.round(3).to_string())
    return ext


def stage_external_driver_comparison(pk_res, pd_res, gr, eff) -> pd.DataFrame:
    """Point predictions of the external groups under both structural drivers (tumor / plasma), growth-modulation effect, exponential growth.
    Compares the predicted sign of (V/V0 at the end, QW) - (V/V0, BIW) with the observed sign."""
    rows = []
    cases = []
    for m, (csv, qw, biw) in EXT.items():
        d = A.load_tumor(csv)
        cases.append((m, d[d.tumor_model == m], qw, biw))
    for driver, pdname, ekey in (("tumor", "tumor_h1", "tumor|exp|growthmod"), ("plasma", "plasma_h1", "plasma|exp|growthmod")):
        pkpd = dict(pk_res["params"], driver=driver, **pd_res[pdname]["params"])
        c_par = eff[ekey]["params"][0]
        for m, d, qw, biw in cases:
            kg_h = gr[m]["kg_exp_per_day"] / 24.0
            v0_all = d[d.time == 0].set_index("animal").value
            out = {}
            for sched, days in (("QW", qw), ("BIW", biw)):
                g = d[(d.dose == 30) & (d.route == f"IV:{sched}")]
                sim = predict_group(pkpd, c_par, kg_h, g, 30, days, "growthmod")
                sim = sim[sim.time > 0].copy()
                sim["v0"] = sim.animal.map(v0_all)
                mo = (sim.obs / sim.v0).groupby(sim.time).mean()
                mp = (sim.pred / sim.v0).groupby(sim.time).mean()
                out[sched] = (float(mo.iloc[-1]), float(mp.iloc[-1]), float(np.sqrt(np.mean((np.log(mp.values) - np.log(mo.values)) ** 2))))
            rows.append(dict(driver=driver, tumor_model=m, obs_QW=out["QW"][0], obs_BIW=out["BIW"][0], pred_QW=out["QW"][1], pred_BIW=out["BIW"][1],
                             rmse_QW=out["QW"][2], rmse_BIW=out["BIW"][2],
                             obs_BIW_better=bool(out["BIW"][0] < out["QW"][0]), pred_BIW_better=bool(out["BIW"][1] < out["QW"][1]),
                             obs_diff_log=float(np.log(out["QW"][0] / out["BIW"][0])), pred_diff_log=float(np.log(out["QW"][1] / out["BIW"][1]))))
    df = pd.DataFrame(rows)
    df.to_csv(A.INP / "external_driver_comparison.csv", index=False)  # contains observed-data summaries: kept out of the companion package
    print(df.round(3).to_string())
    return df


THRESH = (0.5, 0.7, 0.9)
REGIMENS = {
    "QW 30": (30.0, 7.0), "BIW 30": (30.0, 3.5), "Q2W 30": (30.0, 14.0),
    "QW 30 (30/wk)": (30.0, 7.0), "BIW 15 (30/wk)": (15.0, 3.5), "Q2W 60 (30/wk)": (60.0, 14.0),
}


def regimen_metrics(p, dose, interval_d, horizon_d=56.0, v0=200.0, window=(28.0, 56.0)):
    t_dose = np.arange(0.0, horizon_d * 24.0, interval_d * 24.0)
    doses = [(float(t), dose) for t in t_dose]
    tg = np.arange(0.0, horizon_d * 24.0 + 1e-9, 1.0)
    o = simulate(p, doses, tg, V0=v0, max_step=1.0)
    D = 1.0 - o[:, 3]
    w = (tg >= window[0] * 24) & (tg <= window[1] * 24)
    out = dict(mean_D=float(D[w].mean()), min_D=float(D[w].min()), V_end=float(o[-1, 4]))
    for th in THRESH:
        out[f"frac_time_D_ge_{int(th * 100)}"] = float((D[w] >= th).mean())
    return out, tg, D, o


def pk59_params(row, gr_pk59, driver: str = "tumor", extra: dict | None = None) -> dict:
    pr = params_from_row(row, driver)
    pr.update(kg=gr_pk59["kg_gomp_per_day"] / 24.0, K=gr_pk59["K_gomp"], effect="linear", s1=float(row["s1"]))
    if extra:
        pr.update(extra)
    return A.base_params(**pr)


def stage_regimens(pk_res, pd_res, gr, eff, draws) -> pd.DataFrame:
    g59 = gr["PK-59"]
    point_row = dict(pk_res["params"], **pd_res["tumor_h1"]["params"], s1=eff["tumor|gompertz|linear"]["params"][0])
    rows, series = [], []
    for name, (dose, iv) in REGIMENS.items():
        m, tg, D, o = regimen_metrics(pk59_params(point_row, g59), dose, iv)
        rows.append(dict(source="point", draw=-1, regimen=name, **m))
        for t, dd, ct, v in zip(tg[::6], D[::6], o[::6, 2], o[::6, 4]):
            series.append(dict(regimen=name, time_h=t, degradation=dd, tumor_ng_g=ct, volume=v))
        for _, r in draws.iterrows():
            mm, *_ = regimen_metrics(pk59_params(r, g59), dose, iv)
            rows.append(dict(source="draw", draw=int(r.draw), regimen=name, **mm))
    pd.DataFrame(series).to_csv(A.RES / "regimen_series_point.csv", index=False)
    df = pd.DataFrame(rows)
    df.to_csv(A.RES / "regimen_metrics_all.csv", index=False)
    print(df[df.source == "point"].round(3).to_string())
    return df
