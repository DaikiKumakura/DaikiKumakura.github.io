"""Extract the Setidegrasib (ASP3082) preclinical source data used in this note into long-format CSVs.

Source: Yoshinari et al., Commun Chem 2025, doi:10.1038/s42004-025-01662-4, Supplementary Data 3 (Source Data).
Only values stored in the Source Data workbook are used; nothing is digitized from figures.
Run from the project root: python extract_inputs.py
"""
from __future__ import annotations

import csv
import hashlib
from pathlib import Path

import openpyxl

HERE = Path(__file__).resolve().parent
RAW = HERE / "inputs" / "raw" / "source_data3.xlsx"
OUT = HERE / "derived"
DOI = "10.1038/s42004-025-01662-4"
FIELDS = ["source_doi", "figure", "panel", "sheet", "species", "tumor_model", "analyte", "dose", "dose_unit",
          "route", "time", "time_unit", "value", "value_unit", "replicate", "n", "uncertainty_type", "data_origin"]


def rows_of(ws) -> list[list]:
    return [list(r) for r in ws.iter_rows(values_only=True)]


def write(name: str, rows: list[dict]) -> None:
    with (OUT / name).open("w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=FIELDS)
        w.writeheader()
        w.writerows(rows)
    print(name, len(rows), "rows")


def base(figure, panel, sheet, model, analyte, unit_value, route="IV", origin="source data"):
    return dict(source_doi=DOI, figure=figure, panel=panel, sheet=sheet, species="mouse", tumor_model=model,
                analyte=analyte, dose_unit="mg/kg", route=route, time_unit="h", value_unit=unit_value,
                uncertainty_type="individual replicate", data_origin=origin)


def pk_and_pd(wb) -> None:
    ws = rows_of(wb["Fig.4a"])
    out = []
    # header row index 5 has sampling times; data rows from index 6
    blocks = [("plasma", 1, "ng/mL", [(10, 2, 5), (30, 5, 8)]),
              ("tumor", 9, "ng/g", [(10, 10, 13), (30, 13, 16)]),
              ("pancreas", 17, "ng/g", [(10, 18, 21), (30, 21, 24)])]
    for r in ws[6:12]:
        for name, tcol, unit, groups in blocks:
            t = r[tcol]
            for dose, a, b in groups:
                for k, v in enumerate(r[a:b]):
                    d = base("Figure 4", "a", "Fig.4a", "PK-59", name, unit)
                    d.update(dose=dose, time=t, value=v, replicate=k + 1, n=3)
                    out.append(d)
    write("pk_mouse_fig4a.csv", out)

    ws = rows_of(wb["Fig.4b"])
    out = []
    # relative-to-vehicle block: find header "(%) Relative to"
    start = next(i for i, r in enumerate(ws) if r[2] and str(r[2]).startswith("(%) Relative"))
    for r in ws[start + 2:start + 8]:
        t = r[1]
        for dose, a, b in [(0, 2, 5), (10, 5, 8), (30, 8, 11)]:
            for k, v in enumerate(r[a:b]):
                d = base("Figure 4", "b", "Fig.4b", "PK-59", "KRAS(G12D)/b-actin relative to vehicle mean", "% of vehicle")
                d.update(dose=dose, time=t, value=v, replicate=k + 1, n=3)
                out.append(d)
    write("pd_kras_fig4b.csv", out)

    ws = rows_of(wb["Fig.4c"])
    out = []
    groups = [(0, 2, 7), (0.3, 7, 12), (1, 12, 17), (3, 17, 22), (10, 22, 27), (30, 27, 32)]
    for r in ws[5:12]:
        t = r[1]
        for dose, a, b in groups:
            for k, v in enumerate(r[a:b]):
                d = base("Figure 4", "c", "Fig.4c", "PK-59", "tumor volume", "mm3")
                d.update(dose=dose, time=t * 24, value=v, replicate=k + 1, n=5, time_unit="h")
                d["dose_unit"] = "mg/kg"
                out.append(d)
    write("tumor_pk59_fig4c.csv", out)


def schedule_sheet(ws_rows, sheet, figure, panel, label_cols, outname):
    """Parse sheets laid out as: <model label> | Days | Vehicle x5 | 30 QW x5 | 30 BIW x5, tumor-volume blocks only."""
    out = []
    for lc in label_cols:
        model = None
        in_tv = False
        for r in ws_rows:
            lab = r[lc] if lc < len(r) else None
            if isinstance(lab, str) and lab.strip() and lab.strip() not in ("Days",):
                model = lab.strip()
                in_tv = isinstance(r[lc + 2], str) and "Tumor Volume" in r[lc + 2]
                continue
            dcol = lc + 1
            if in_tv and dcol < len(r) and isinstance(r[dcol], (int, float)):
                day = r[dcol]
                vals = r[dcol + 1:dcol + 16]
                for lab2, dose, sched, a in [("Vehicle", 0, "vehicle", 0), ("30 QW", 30, "QW", 5), ("30 BIW", 30, "BIW", 10)]:
                    for k, v in enumerate(vals[a:a + 5]):
                        d = base(figure, panel, sheet, model, "tumor volume", "mm3")
                        d.update(dose=dose, time=day * 24, value=v, replicate=k + 1, n=5, route="IV:" + sched)
                        out.append(d)
            elif in_tv and not isinstance(r[dcol] if dcol < len(r) else None, (int, float)) and r[lc + 2] == "Days":
                continue
    write(outname, out)


def fig5a(wb) -> None:
    schedule_sheet(rows_of(wb["Fig.5a"]), "Fig.5a", "Figure 5", "a", [1], "tumor_fig5a.csv")


def sup7a(wb) -> None:
    schedule_sheet(rows_of(wb["Sup.Fig.7a"]), "Sup.Fig.7a", "Supplementary Figure 7", "a", [1, 19], "tumor_sup7a.csv")


def fig5b(wb) -> None:
    ws = rows_of(wb["Fig.5b"])
    out = []
    for r in ws[5:13]:
        day = r[1]
        for dose, sched, a, b in [(0, "vehicle", 2, 10), (10, "BIW", 10, 18), (30, "BIW", 18, 26)]:
            for k, v in enumerate(r[a:b]):
                d = base("Figure 5", "b", "Fig.5b", "LXFA1125 PDX", "tumor volume", "mm3")
                d.update(dose=dose, time=day * 24, value=v, replicate=k + 1, n=8, route="IV:" + sched)
                out.append(d)
    write("tumor_fig5b_pdx.csv", out)


def main() -> None:
    OUT.mkdir(exist_ok=True)
    wb = openpyxl.load_workbook(RAW, read_only=True, data_only=True)
    pk_and_pd(wb)
    fig5a(wb)
    sup7a(wb)
    fig5b(wb)
    h = hashlib.sha256(RAW.read_bytes()).hexdigest()
    (OUT / "source_data3.sha256").write_text(h + "  source_data3.xlsx\n")
    print("source sha256", h)


if __name__ == "__main__":
    main()
