"""Setidegrasib (ASP3082) non-clinical PK/PD-tumor model: fitting, validation, regimen simulation.

Run from this folder: python analysis.py            (all stages, results/ is rewritten)
                      python analysis.py pk pd      (selected stages)
Inputs: inputs/*.csv written by extract_inputs.py from the public Source Data of Yoshinari et al. 2025.
No human data are used for any fit. Random seed fixed below.
"""
from __future__ import annotations

import json
import sys
import warnings
import time
from pathlib import Path

import numpy as np
import pandas as pd
from scipy.optimize import least_squares

from model import simulate

HERE = Path(__file__).resolve().parent
RES = HERE / "results"
INP = HERE / "derived"
SEED = 20261105
PK_TIMES = np.array([2, 6, 24, 48, 72, 144.0])
FUP_MOUSE = 0.00784            # mouse plasma unbound fraction, Yoshinari et al. (reported, not used in fitting)
MW_G_MOL = 1117.3              # approx. average molar mass of C60H65FN12O7S, used only for unit context
DC50_INVITRO_NM = 38.0         # AsPC-1 In-Cell ELISA DC50 reported in the paper (context only)
# dosing schedules, study-day clock (day number x 24 h), from figure legends
SCHEDULES = {
    "fig4c": [1, 8, 14],
    "QW": [1, 8],
    "BIW": [1, 5, 8, 12],
    "BIW_PK1": [1, 4, 8, 11],
    "QW_PK1": [1, 8],
    "pdx_BIW": [1, 5, 8, 12, 15, 19],
}
PK_NAMES = ["V1", "k10", "k12", "k21", "kin", "Vm", "Km"]
PD_NAMES = ["kdeg", "kmax", "DC50"]


# ----------------------------------------------------------------------------------------------------------------
def aic_gauss(rss: float, n: int, k: int) -> float:
    return n * np.log(rss / n) + 2 * k


def laplace_cov(fit, n: int, k: int) -> np.ndarray:
    J = fit.jac
    s2 = 2 * fit.cost / max(n - k, 1)
    return s2 * np.linalg.pinv(J.T @ J, rcond=1e-10)


def base_params(**kw) -> dict:
    p = dict(V1=1.0, k10=0.5, k12=0.03, k21=0.03, kin=0.03, Vm=5.0, Km=250.0, kmax=0.0, DC50=100.0, kdeg=0.05,
             h=1.0, kg=0.0, K=1.0e4, s1=0.0, driver="tumor", effect="linear")
    p.update(kw)
    return p


# ---------------------------------------------------------------------------------------------------- stage: PK ---
def pk_resid(theta, data, fix=None):
    th = dict(zip(PK_NAMES, np.exp(theta)))
    if fix:
        th.update(fix)
    p = base_params(**th)
    r = []
    for dose in (10, 30):
        o = simulate(p, [(0.0, dose)], PK_TIMES, V0=100.0)
        cp, ct = o[:, 0] / p["V1"], o[:, 2]
        for an, mod in (("plasma", cp), ("tumor", ct)):
            s = data[(data.dose == dose) & (data.analyte == an)]
            for tm, v in zip(s.time.values, s.value.values):
                r.append(np.log(max(mod[int(np.where(PK_TIMES == tm)[0][0])], 1e-9)) - np.log(v))
    return np.array(r)


def stage_pk():
    d = pd.read_csv(INP / "pk_mouse_fig4a.csv")
    n_total = int(((d.analyte == "plasma") | (d.analyte == "tumor")).sum())
    d = d[(d.value > 0) & d.analyte.isin(["plasma", "tumor"])]
    n_used = len(d)
    rng = np.random.default_rng(SEED)
    start = np.log([1.1, 0.58, 0.03, 0.027, 0.025, 4.7, 286.0])
    cands = [start] + [start + rng.normal(0, 0.35, 7) for _ in range(5)]
    best = None
    for th0 in cands:
        try:
            f = least_squares(pk_resid, th0, args=(d,), method="trf", max_nfev=200)
        except Exception:
            continue
        if best is None or f.cost < best.cost:
            best = f
    # linear tumor elimination alternative: Km -> large with Vm/Km = kout
    def lin_resid(theta, data):
        V1, k10, k12, k21, kin, kout = np.exp(theta)
        th = np.log([V1, k10, k12, k21, kin, kout * 1.0e6, 1.0e6])
        return pk_resid(th, data)
    startl = np.log([1.1, 0.58, 0.03, 0.027, 0.025, 0.0165])
    fl = least_squares(lin_resid, startl, args=(d,), method="trf", max_nfev=200)
    n = len(d)
    rss_s, rss_l = float((best.fun ** 2).sum()), float((fl.fun ** 2).sum())
    cov = laplace_cov(best, n, 7)
    res = dict(
        n_obs_total=n_total, n_obs_used=n_used, excluded="plasma 10 mg/kg at 144 h (below quantification, reported as 0)",
        params=dict(zip(PK_NAMES, np.exp(best.x).tolist())), theta_log=best.x.tolist(), cov_log=cov.tolist(),
        log_se=np.sqrt(np.clip(np.diag(cov), 0, None)).tolist(),
        rss_saturable=rss_s, rss_linear=rss_l, aic_saturable=aic_gauss(rss_s, n, 7), aic_linear=aic_gauss(rss_l, n, 6),
        linear_params=dict(zip(["V1", "k10", "k12", "k21", "kin", "kout"], np.exp(fl.x).tolist())),
        rmse_log_saturable=float(np.sqrt(rss_s / n)), rmse_log_linear=float(np.sqrt(rss_l / n)),
        n_cond_jac=float(np.linalg.cond(best.jac)),
    )
    RES.mkdir(exist_ok=True)
    (RES / "pk_fit.json").write_text(json.dumps(res, indent=1))
    # predictions on the observation grid and a fine grid for plotting
    fine = np.linspace(0, 150, 301)
    p = base_params(**res["params"])
    rows = []
    for dose in (10, 30):
        o = simulate(p, [(0.0, dose)], fine, V0=100.0)
        for t, a, c in zip(fine, o[:, 0] / p["V1"], o[:, 2]):
            rows.append(dict(dose=dose, time=t, plasma_ng_ml=a, tumor_ng_g=c))
    pd.DataFrame(rows).to_csv(RES / "pk_fit_curves.csv", index=False)
    print("PK", {k: round(v, 4) for k, v in res["params"].items()}, "rmse_log", round(res["rmse_log_saturable"], 3),
          "AIC sat/lin", round(res["aic_saturable"], 1), round(res["aic_linear"], 1))
    return res


# ---------------------------------------------------------------------------------------------------- stage: PD ---
def load_pd():
    d = pd.read_csv(INP / "pd_kras_fig4b.csv")
    d["rel"] = d.value / 100.0
    return d


def pd_resid(theta, pk, pdd, driver="tumor", h=None, fix=None):
    names = PD_NAMES + (["h"] if h == "free" else [])
    th = dict(zip(names, np.exp(theta)))
    if fix:
        th.update(fix)
    p = base_params(**pk, driver=driver, **th)
    if h not in (None, "free"):
        p["h"] = float(h)
    r = []
    for dose in (10, 30):
        o = simulate(p, [(0.0, dose)], PK_TIMES, V0=100.0)
        s = pdd[pdd.dose == dose]
        for tm, v in zip(s.time.values, s.rel.values):
            rm = o[int(np.where(PK_TIMES == tm)[0][0]), 3]
            r.append(np.log(max(rm, 1e-6)) - np.log(v))
    return np.array(r)


def fit_pd(pk, pdd, driver="tumor", h=None, fix=None, n_starts=8, seed=SEED):
    rng = np.random.default_rng(seed)
    free = [n for n in PD_NAMES if not (fix and n in fix)] + (["h"] if h == "free" else [])
    def wrap(theta):
        full = {}
        it = iter(theta)
        for n in PD_NAMES + (["h"] if h == "free" else []):
            full[n] = None
        th = dict(zip(free, np.exp(theta)))
        names_all = PD_NAMES + (["h"] if h == "free" else [])
        full = {n: (fix[n] if fix and n in fix else th[n]) for n in names_all}
        return pd_resid(np.log([full[n] for n in names_all]), pk, pdd, driver, h)
    scale = {"tumor": 150.0, "plasma": 15.0}[driver]
    base = {"kdeg": 0.05, "kmax": 0.2, "DC50": scale, "h": 1.0}
    st = np.log([base[n] for n in free])
    best = None
    for k in range(n_starts):
        th0 = st + (rng.normal(0, 0.8, len(free)) if k else 0)
        try:
            f = least_squares(wrap, th0, method="trf", max_nfev=200)
        except Exception:
            continue
        if best is None or f.cost < best.cost:
            best = f
    return best, free


def stage_pd(pk_res):
    pk = pk_res["params"]
    pdd = load_pd()
    veh = pdd[pdd.dose == 0]
    veh_sd_log = float(np.log(veh.rel).std(ddof=1))
    fits = {}
    for name, driver, h in [("tumor_h1", "tumor", None), ("tumor_hfree", "tumor", "free"), ("plasma_h1", "plasma", None)]:
        f, free = fit_pd(pk, pdd, driver=driver, h=h)
        n = len(f.fun)
        rss = float((f.fun ** 2).sum())
        cov = laplace_cov(f, n, len(free))
        fits[name] = dict(free=free, params=dict(zip(free, np.exp(f.x).tolist())), rss=rss, n=n, aic=aic_gauss(rss, n, len(free)),
                          rmse_log=float(np.sqrt(rss / n)), cov_log=cov.tolist(), theta_log=f.x.tolist())
        print("PD", name, {k: round(v, 4) for k, v in fits[name]["params"].items()}, "rmse", round(fits[name]["rmse_log"], 3),
              "AIC", round(fits[name]["aic"], 2))
    # profile likelihood of kdeg (KRAS degradation rate constant) for each driver, h = 1
    grid = np.exp(np.linspace(np.log(0.002), np.log(1.0), 21))
    allprof = []
    for driver, name in (("tumor", "tumor_h1"), ("plasma", "plasma_h1")):
        rss_min, n = fits[name]["rss"], fits[name]["n"]
        s2 = rss_min / (n - 3)
        prof = []
        for kd in grid:
            f, free = fit_pd(pk, pdd, driver=driver, fix={"kdeg": kd}, n_starts=4)
            prof.append(dict(driver=driver, kdeg=float(kd), rss=float((f.fun ** 2).sum()), kmax=float(np.exp(f.x[0])), DC50=float(np.exp(f.x[1]))))
        prof = pd.DataFrame(prof)
        prof["delta_2ll"] = (prof.rss - rss_min) / s2
        allprof.append(prof)
        ok = prof[prof.delta_2ll <= 3.84]
        fits[f"kdeg_profile_ci95_{driver}"] = [float(ok.kdeg.min()), float(ok.kdeg.max())] if len(ok) else [float("nan"), float("nan")]
    pd.concat(allprof).to_csv(RES / "pd_kdeg_profile.csv", index=False)
    fits["vehicle_sd_log"] = veh_sd_log
    (RES / "pd_fit.json").write_text(json.dumps(fits, indent=1))
    # curves
    fine = np.linspace(0, 150, 301)
    rows = []
    for name in ("tumor_h1", "plasma_h1"):
        driver = "tumor" if name.startswith("tumor") else "plasma"
        pp = base_params(**pk, driver=driver, **fits[name]["params"])
        for dose in (10, 30):
            o = simulate(pp, [(0.0, dose)], fine, V0=100.0)
            for t, rr in zip(fine, o[:, 3]):
                rows.append(dict(model=name, dose=dose, time=t, rel_kras=rr))
    pd.DataFrame(rows).to_csv(RES / "pd_fit_curves.csv", index=False)
    print("kdeg profile 95% intervals (per h):", fits["kdeg_profile_ci95_tumor"], fits["kdeg_profile_ci95_plasma"], " vehicle SD(log)=", round(veh_sd_log, 3))
    return fits


# --------------------------------------------------------------------------------------------- stage: growth ----
def load_tumor(name):
    d = pd.read_csv(INP / name)
    d["animal"] = d["tumor_model"].astype(str) + "|" + d["route"].astype(str) + "|" + d["dose"].astype(str) + "|" + d["replicate"].astype(str)
    return d


def veh_resid(theta, vd, form):
    """Per-animal baseline V0 = observed day-0 volume; common kg and K per tumor model."""
    kg = np.exp(theta[0])
    r = []
    for a, g in vd.groupby("animal"):
        g = g.sort_values("time")
        v0 = g.value.values[0]
        t = (g.time.values - g.time.values[0])
        if form == "gompertz":
            K = np.exp(theta[1])
            m = K * np.exp(np.log(v0 / K) * np.exp(-kg * t / 24.0))
        else:
            m = v0 * np.exp(kg * t / 24.0)
        r.extend(np.log(m[1:]) - np.log(g.value.values[1:]))
    return np.array(r)


def stage_growth():
    tables = {"PK-59": load_tumor("tumor_pk59_fig4c.csv")}
    for f in ["tumor_fig5a.csv", "tumor_sup7a.csv", "tumor_fig5b_pdx.csv"]:
        d = load_tumor(f)
        for m, g in d.groupby("tumor_model"):
            tables[m] = g
    out = {}
    for m, d in tables.items():
        vd = d[d.dose == 0]
        K0 = max(vd.value.max() * 5, 3000.0)
        fe = least_squares(veh_resid, [np.log(0.1)], args=(vd, "exp"))
        fg = least_squares(veh_resid, [np.log(0.1), np.log(K0)], args=(vd, "gompertz"),
                           bounds=([np.log(1e-3), np.log(vd.value.max() * 1.05)], [np.log(5.0), np.log(1e6)]))
        n = len(fe.fun)
        rss_e, rss_g = float((fe.fun ** 2).sum()), float((fg.fun ** 2).sum())
        out[m] = dict(n=n, kg_exp_per_day=float(np.exp(fe.x[0])), rss_exp=rss_e, aic_exp=aic_gauss(rss_e, n, 1),
                      kg_gomp_per_day=float(np.exp(fg.x[0])), K_gomp=float(np.exp(fg.x[1])), rss_gomp=rss_g,
                      aic_gomp=aic_gauss(rss_g, n, 2), rmse_log_exp=float(np.sqrt(rss_e / n)), rmse_log_gomp=float(np.sqrt(rss_g / n)),
                      last_day=float(vd.time.max() / 24.0), K_at_upper_bound_note=bool(np.exp(fg.x[1]) > 5e5))
        print("growth", m, "exp kg", round(out[m]["kg_exp_per_day"], 3), "AIC exp/gomp", round(out[m]["aic_exp"], 1), round(out[m]["aic_gomp"], 1))
    (RES / "growth_vehicle_fits.json").write_text(json.dumps(out, indent=1))
    return out


# --------------------------------------------------------------------------------------------- stage: effect ----
def animals_of(d, dose, route=None):
    s = d[d.dose == dose]
    if route is not None:
        s = s[s.route == route]
    return s


def simulate_group(p, schedule_days, g, grow_form="exp"):
    """Predict per-animal tumor volumes for one group at its observation times; returns long DataFrame."""
    times = np.sort(g.time.unique())
    doses = [(float(dday) * 24.0, float(p["_dose"])) for dday in schedule_days] if p["_dose"] > 0 else []
    rows = []
    for a, ga in g.groupby("animal"):
        ga = ga.sort_values("time")
        v0 = ga.value.values[0]
        pp = dict(p)
        o = simulate(pp, doses, ga.time.values, V0=v0)
        for t, obs, m in zip(ga.time.values, ga.value.values, o[:, 4]):
            rows.append(dict(animal=a, time=t, obs=obs, pred=m))
    return pd.DataFrame(rows)


def growth_params(gr, m, form):
    if form == "gompertz":
        return dict(kg=gr[m]["kg_gomp_per_day"] / 24.0, K=gr[m]["K_gomp"])
    # exponential as the K -> infinity limit of Gompertz: dV/dt = kg V ln(K/V) with huge K is not exponential;
    # use a large K so ln(K/V) varies slowly and rescale kg so the initial exponential rate is kg_exp
    K = 1.0e9
    return dict(kg=gr[m]["kg_exp_per_day"] / 24.0 / np.log(K / 250.0), K=K)


def effect_resid(theta, pkpd, d4c, gr, effect, doses_fit, growth_form, with_group_free=False):
    s = np.exp(theta)
    r = []
    for dose in doses_fit:
        g = d4c[d4c.dose == dose]
        p = base_params(**pkpd, **growth_params(gr, "PK-59", growth_form), effect=effect)
        if effect == "linear":
            p["s1"] = s[0]
        elif effect == "growthmod":
            p["c"] = s[0]
        else:
            p["smax"], p["D50"] = s[0], s[1]
            p["gamma"] = 1.0
        p["_dose"] = dose
        sim = simulate_group(p, SCHEDULES["fig4c"], g)
        r.extend((np.log(sim.pred.clip(lower=1e-6)) - np.log(sim.obs)).values[sim.time.values > 0])
    return np.array(r)


def stage_effect(pk_res, pd_res, gr):
    pk = pk_res["params"]
    d4c = load_tumor("tumor_pk59_fig4c.csv")
    out = {}
    pkpd_by = {}
    for driver, pdname in (("tumor", "tumor_h1"), ("plasma", "plasma_h1")):
        pkpd = dict(pk, driver=driver, **pd_res[pdname]["params"])
        pkpd_by[driver] = pkpd
        for growth_form in ("exp", "gompertz"):
            for effect, st in (("linear", [np.log(0.5 / 24)]), ("growthmod", [np.log(1.3)]), ("emax", [np.log(1.0 / 24), np.log(0.5)])):
                bounds = ([-12] * len(st), [3] * len(st)) if effect in ("linear", "growthmod") else ([-12, np.log(0.01)], [3, np.log(5.0)])
                f = least_squares(effect_resid, st, args=(pkpd, d4c, gr, effect, [0, 10, 30], growth_form), bounds=bounds, max_nfev=80)
                n = len(f.fun)
                rss = float((f.fun ** 2).sum())
                key = f"{driver}|{growth_form}|{effect}"
                out[key] = dict(driver=driver, growth=growth_form, effect=effect, n=n, rss=rss, k=len(st), aic=aic_gauss(rss, n, len(st)),
                                params=np.exp(f.x).tolist(), rmse_log=float(np.sqrt(rss / n)))
                # held-out doses 0.3, 1, 3 mg/kg
                held = {}
                for dose in (0.3, 1.0, 3.0):
                    g = d4c[d4c.dose == dose]
                    p = base_params(**pkpd, **growth_params(gr, "PK-59", growth_form), effect=effect)
                    if effect == "linear":
                        p["s1"] = float(np.exp(f.x[0]))
                    elif effect == "growthmod":
                        p["c"] = float(np.exp(f.x[0]))
                    else:
                        p["smax"], p["D50"], p["gamma"] = float(np.exp(f.x[0])), float(np.exp(f.x[1])), 1.0
                    p["_dose"] = dose
                    sim = simulate_group(p, SCHEDULES["fig4c"], g)
                    sim = sim[sim.time > 0]
                    mo = sim.groupby("time").obs.mean()
                    mp = sim.groupby("time").pred.mean()
                    held[str(dose)] = dict(rmse_log_mean=float(np.sqrt(np.mean((np.log(mp) - np.log(mo)) ** 2))),
                                           final_obs=float(mo.iloc[-1]), final_pred=float(mp.iloc[-1]))
                out[key]["heldout_doses"] = held
                print("EFFECT", key, "rmse", round(out[key]["rmse_log"], 3), "AIC", round(out[key]["aic"], 1),
                      "held-out final pred/obs", {k: round(v["final_pred"] / v["final_obs"], 2) for k, v in held.items()})
    # no-dynamics baseline: constant kill rate S = smax * dose/(d50+dose) from the first dose on (no PK/PD link)
    def base_resid(theta, dose_list):
        smax, d50 = np.exp(theta)
        r = []
        for dose in dose_list:
            g = d4c[d4c.dose == dose]
            p = base_params(**pkpd_by["tumor"], **growth_params(gr, "PK-59", "gompertz"))
            S = smax * dose / (d50 + dose) if dose > 0 else 0.0
            for a, ga in g.groupby("animal"):
                ga = ga.sort_values("time")
                v0 = ga.value.values[0]
                t = ga.time.values
                m = _gomp_with_kill_onset(v0, p["kg"], p["K"], S, t, onset_h=24.0 * SCHEDULES["fig4c"][0])
                r.extend(np.log(m[1:]) - np.log(ga.value.values[1:]))
        return np.array(r)
    fb = least_squares(base_resid, [np.log(0.02), np.log(3.0)], args=([0, 10, 30],), bounds=([-12, -3], [2, 5]))
    nb = len(fb.fun)
    rssb = float((fb.fun ** 2).sum())
    smax_b, d50_b = np.exp(fb.x)
    held_b = {}
    for dose in (0.3, 1.0, 3.0):
        g = d4c[d4c.dose == dose]
        S = smax_b * dose / (d50_b + dose)
        preds, obs = [], []
        for a_, ga in g.groupby("animal"):
            ga = ga.sort_values("time")
            m = _gomp_with_kill_onset(ga.value.values[0], base_params(**growth_params(gr, "PK-59", "gompertz"))["kg"],
                                      growth_params(gr, "PK-59", "gompertz")["K"], S, ga.time.values, onset_h=24.0 * SCHEDULES["fig4c"][0])
            preds.append(m[-1])
            obs.append(ga.value.values[-1])
        held_b[str(dose)] = dict(final_pred=float(np.mean(preds)), final_obs=float(np.mean(obs)))
    out["baseline_constant_kill"] = dict(rss=rssb, n=nb, aic=aic_gauss(rssb, nb, 2), params=np.exp(fb.x).tolist(),
                                         rmse_log=float(np.sqrt(rssb / nb)), kill_onset_h=24.0 * SCHEDULES["fig4c"][0], heldout_doses=held_b,
                                         note="constant kill rate S = smax*dose/(d50+dose) from the first dose; no PK/PD link")
    (RES / "effect_fits.json").write_text(json.dumps(out, indent=1))
    return out, pkpd_by


def _gomp_with_kill(v0, kg, K, S, t):
    """Closed-form Gompertz with constant kill S: dV/dt = kg V ln(K/V) - S V  ->  effective carrying capacity K*exp(-S/kg)."""
    Ke = K * np.exp(-S / kg)
    return Ke * np.exp(np.log(v0 / Ke) * np.exp(-kg * t))


def _gomp_with_kill_onset(v0, kg, K, S, t, onset_h):
    """Free Gompertz growth until onset_h, then constant kill S (closed forms)."""
    t = np.asarray(t, float)
    v_on = K * np.exp(np.log(v0 / K) * np.exp(-kg * np.minimum(t, onset_h)))
    Ke = K * np.exp(-S / kg)
    late = Ke * np.exp(np.log(v_on / Ke) * np.exp(-kg * np.maximum(t - onset_h, 0.0)))
    return np.where(t <= onset_h, v_on, late)


def main(stages):
    RES.mkdir(exist_ok=True)
    np.random.seed(SEED)
    t0 = time.time()
    warnings.filterwarnings("ignore", category=UserWarning)
    warnings.filterwarnings("ignore", category=RuntimeWarning)
    pk_res = stage_pk() if "pk" in stages else json.loads((RES / "pk_fit.json").read_text())
    pd_res = stage_pd(pk_res) if "pd" in stages else json.loads((RES / "pd_fit.json").read_text())
    gr = stage_growth() if "growth" in stages else json.loads((RES / "growth_vehicle_fits.json").read_text())
    if "effect" in stages:
        eff, _ = stage_effect(pk_res, pd_res, gr)
    else:
        eff = json.loads((RES / "effect_fits.json").read_text())
    import stages_extra as X
    if "draws" in stages:
        draws = X.stage_draws(pk_res, pd_res, gr)
    else:
        draws = pd.read_csv(RES / "param_draws.csv") if (RES / "param_draws.csv").exists() else None
    if "external" in stages:
        X.stage_external(pk_res, pd_res, gr, eff, draws)
    if "extdrv" in stages:
        X.stage_external_driver_comparison(pk_res, pd_res, gr, eff)
    if "regimens" in stages:
        X.stage_regimens(pk_res, pd_res, gr, eff, draws)
    if "sens" in stages:
        import stages_sens as S
        S.stage_structural(pk_res, pd_res, gr, eff)
        print(S.stage_draw_sensitivity(draws).round(3).to_string())
        print(S.stage_human(pk_res, pd_res, gr, eff).query("b == 0.75 and kdeg_label == 'point'").round(3).to_string())
    print("elapsed s", round(time.time() - t0, 1))


if __name__ == "__main__":
    st = sys.argv[1:] or ["pk", "pd", "growth", "effect", "draws", "external", "extdrv", "regimens", "sens"]
    main(st)
