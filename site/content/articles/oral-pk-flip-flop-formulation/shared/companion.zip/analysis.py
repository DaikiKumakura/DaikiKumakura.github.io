import math
def c(t, ka, k, vf):
    return 100 * ka / vf / (ka-k) * (math.exp(-k*t)-math.exp(-ka*t))
p=[(1,.2,40),(.2,1,8)]
times=[t/10 for t in range(241)]
assert max(abs(c(t,*p[0])-c(t,*p[1])) for t in times)<1e-12
for name,ka,k,vf in [('Original A',*p[0]),('Original B',*p[1]),('Faster A',1.2,.2,40),('Faster B',1.2,1,8)]:
    t=math.log(ka/k)/(ka-k)
    print(f'{name},{t:.6f},{c(t,ka,k,vf):.6f},{c(8,ka,k,vf):.6f},{100/(k*vf):.6f}')
