Run python analysis.py with Python 3. Published aggregate inputs are declared in the source.
