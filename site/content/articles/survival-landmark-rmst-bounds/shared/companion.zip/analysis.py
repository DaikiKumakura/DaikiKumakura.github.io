from math import isclose
anchors=[(0,1),(6,.7),(12,.5),(18,.3)]
lo=sum((b[0]-a[0])*b[1] for a,b in zip(anchors,anchors[1:]))
hi=sum((b[0]-a[0])*a[1] for a,b in zip(anchors,anchors[1:]))
def area(points):
    return sum((b[0]-a[0])*a[1] for a,b in zip(points,points[1:]))
def early(e):
    return [(0,1),(e,.7),(6,.7),(6+e,.5+e),(12,.5),(12+e,.3),(18,.3)]
for e in (.1,.01,.001):
    print(e, area(early(e)),area(anchors))
assert isclose(lo,9) and isclose(hi,13.2)
assert isclose(area(early(.1)),9.66)
