from decimal import Decimal as D

ARMS = {
    "Tarlatamab": (D("13.6"), D("0.559"), D("0.303")),
    "Chemotherapy": (D("8.4"), D("0.390"), D("0.149")),
}

def rmst_bounds(median, landmarks):
    """Bounds for survival starting at 1 and first crossing 0.5 at median."""
    cuts = sorted({D(0), D(24), median, *landmarks})
    exact = {D(0): D(1), **landmarks}
    lower = upper = D(0)
    for left, right in zip(cuts, cuts[1:]):
        floor = max((s for t, s in exact.items() if t >= right), default=D(0))
        ceiling = min(s for t, s in exact.items() if t <= left)
        if right <= median:
            floor = max(floor, D("0.5"))
        if left >= median:
            ceiling = min(ceiling, D("0.5"))
        assert floor <= ceiling
        lower += (right-left)*floor
        upper += (right-left)*ceiling
    return lower, upper

for extra in [(), (12,), (12,24)]:
    a, b = (rmst_bounds(m, {D(t): s for t,s in [(12,s12),(24,s24)] if t in extra})
            for m,s12,s24 in ARMS.values())
    difference = (a[0]-b[1], a[1]-b[0])
    print(f"{extra}: tarlatamab={a[0]:.4f} to {a[1]:.4f}; "
          f"chemotherapy={b[0]:.4f} to {b[1]:.4f}; "
          f"difference={difference[0]:.4f} to {difference[1]:.4f}")
    assert difference[0] < 0 < difference[1]
