import unittest
from analysis import summarize
class Checks(unittest.TestCase):
    def test_joint_not_sum(self):
        d=summarize([dict(code025='11000',code050='10000',code075='00000',n='2'),dict(code025='00000',code050='00000',code075='00000',n='3')])
        self.assertEqual(d['any_changed'],2)
        self.assertEqual([p['changed'] for p in d['pathways']],[2,2,0,0,0])
        self.assertEqual(d['any_changed_fraction'],.4)
    def test_reject_nonmonotonic(self):
        with self.assertRaises(AssertionError): summarize([dict(code025='00000',code050='10000',code075='00000',n='1')])
    def test_reject_empty(self):
        with self.assertRaises(AssertionError): summarize([])
if __name__=='__main__': unittest.main()
