from pathlib import Path
import json
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
HERE=Path(__file__).resolve().parent
def main():
    d=json.loads((HERE/'results/summary.json').read_text())
    fig,ax=plt.subplots(figsize=(8,4.8))
    fig.subplots_adjust(left=.1,right=.98,top=.88,bottom=.18)
    for key,label,col in [('positive025','0.25','#b6cfdf'),('positive050','0.50','#367da2'),('positive075','0.75','#14384c')]:
        offset={'positive025':-.24,'positive050':0,'positive075':.24}[key]
        ax.bar([i+offset for i in range(5)],[p[key]/d['n']*100 for p in d['pathways']],width=.23,label=label,color=col)
    ax.set_xticks(range(5),[p['pathway'] for p in d['pathways']]); ax.set_ylim(0,100)
    ax.set_ylabel('Predicted positive cells (%)'); ax.set_title('Changing the threshold changes the call')
    ax.legend(title='Threshold',frameon=False); ax.spines[['top','right']].set_visible(False)
    fig.text(.1,.035,'Published Fig. 3 source data; 130,000 complete rows. Descriptive sensitivity, not accuracy.',fontsize=8)
    (HERE/'figures').mkdir(exist_ok=True); fig.savefig(HERE/'figures/threshold-sensitivity.png',dpi=180); plt.close(fig)
if __name__=='__main__': main()
