"""Extract descriptive counts from published Fig. 3 source data. No model fitting."""
from pathlib import Path
from collections import Counter
import csv, hashlib, json
import openpyxl
HERE = Path(__file__).resolve().parent
def main():
    source = HERE/'sources/figure3.xlsx'
    wb = openpyxl.load_workbook(source, read_only=True, data_only=True)
    rows = wb['Fig3ab_atlas'].iter_rows(values_only=True)
    header = next(rows)
    print(header)
    names = ['tgfb_prediction','fgf_prediction','bmp_prediction','ra_prediction','wnt_prediction']
    ix = [header.index(n) for n in names]
    counts = Counter()
    n = 0
    for row in rows:
        if row[0] is None: continue
        p = [float(row[i]) for i in ix]
        assert all(0 <= x <= 1 for x in p)
        codes = tuple(''.join('1' if x >= threshold else '0' for x in p) for threshold in [.25,.5,.75])
        counts[codes] += 1
        n += 1
    (HERE/'inputs').mkdir(exist_ok=True)
    with (HERE/'inputs/counts.csv').open('w',newline='',encoding='utf-8') as f:
        w=csv.writer(f); w.writerow(['code025','code050','code075','n'])
        for key,value in sorted(counts.items()): w.writerow([*key,value])
    (HERE/'inputs/provenance.json').write_text(json.dumps({'article':'https://doi.org/10.1038/s41592-026-03213-8','source':'https://media.springernature.com/original/springer-static/esm/art%3A10.1038%2Fs41592-026-03213-8/MediaObjects/41592_2026_3213_MOESM6_ESM.xlsx','sheet':'Fig3ab_atlas','sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'cells':n,'bit_order':names,'rule':'probability >= threshold; joint counts pooled across 130000 complete prediction rows; stage/celltype not used; 9331 trailing rows with missing predictions excluded','extraction':'extract.py; openpyxl; no scRNA-seq preprocessing or IRIS retraining'},indent=2)+'\n',encoding='utf-8')
    print(n)
if __name__=='__main__': main()
