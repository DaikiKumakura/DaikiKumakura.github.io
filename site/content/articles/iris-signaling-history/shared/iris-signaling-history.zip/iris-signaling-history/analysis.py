"""Threshold sensitivity of published IRIS outputs. No accuracy/calibration claim."""
from pathlib import Path
import csv, json
HERE=Path(__file__).resolve().parent
PATHWAYS=['TGF-beta','FGF','BMP','RA','WNT']
def summarize(rows):
    n=0; changed=0; per=[dict(pathway=p,positive025=0,positive050=0,positive075=0,changed=0) for p in PATHWAYS]
    for r in rows:
        k=int(r['n']); assert k>0
        codes=[r[c] for c in ['code025','code050','code075']]
        assert all(len(c)==5 and set(c)<=set('01') for c in codes)
        assert all(codes[0][i]>=codes[1][i]>=codes[2][i] for i in range(5))
        n+=k; changed+=k*(codes[0]!=codes[2])
        for i,p in enumerate(per):
            for j,key in enumerate(['positive025','positive050','positive075']): p[key]+=k*int(codes[j][i])
            p['changed']+=k*(codes[0][i]!=codes[2][i])
    assert n>0
    return dict(n=n,any_changed=changed,any_changed_fraction=changed/n,pathways=per)
def main():
    with (HERE/'inputs/counts.csv').open(encoding='utf-8') as f: result=summarize(list(csv.DictReader(f)))
    (HERE/'results').mkdir(exist_ok=True)
    (HERE/'results/summary.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(result,indent=2))
if __name__=='__main__': main()
