# Reproducing the threshold sensitivity calculation

This is a descriptive audit of released prediction values, not an IRIS retraining, accuracy benchmark, calibration assessment or raw scRNA-seq analysis.

Source: Hutchins NT et al., Nature Methods (2026), https://doi.org/10.1038/s41592-026-03213-8, Source Data Fig. 3, sheet Fig3ab_atlas. The exact download URL and SHA-256 are in inputs/provenance.json. Cite the original authors when using the underlying data. The paper is CC BY-NC-ND 4.0 (https://creativecommons.org/licenses/by-nc-nd/4.0/); its text, figures and workbook are not redistributed here. The code licence does not relicense source materials.

Python 3.12; matplotlib 3.9.1 was used for the figure. Recompute the provided factual aggregate counts with:

    python analysis.py
    python -m unittest test_analysis.py
    python plot.py

To extract again, download Source Data Fig. 3 from the article to sources/figure3.xlsx, verify its SHA-256, install openpyxl (tested with 3.1.5), then run python extract.py. This reads only five prediction columns from rows with a nonempty cell ID. There are 130,000 such rows. The trailing 9,331 rows have no cell ID/predictions and are excluded. Stage and cell type columns are not used or joined. This is not the entire 139,331-cell atlas.

Bit order: TGF-beta, FGF, BMP, RA, WNT. Positive means prediction >= threshold. inputs/counts.csv stores joint counts of codes at thresholds 0.25, 0.50 and 0.75, preserving overlap between changed pathways. Every complete row contributes once. Probabilities and original cell IDs are not redistributed. The alternative thresholds are illustrative sensitivity choices, not validated operating points. No ground-truth labels, embryo-level confidence intervals or causal inferences are available in this calculation.

Outputs: results/summary.json and figures/threshold-sensitivity.png. Counts are exact for this workbook subset, not estimates of population prevalence. A threshold-dependent call is not necessarily incorrect.
