Reproduce with Python 3.12. Run python analysis.py from this archive after extraction. Standard library only.
