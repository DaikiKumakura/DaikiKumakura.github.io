from itertools import product
from math import sqrt
def exact(differences):
    values=[sum(s*d for s,d in zip(sign,differences)) for sign in product((-1,1),repeat=len(differences))]
    return sum(abs(v)>=abs(sum(differences)) for v in values)/len(values)
assert exact([20,16,12,10,8,-1])==4/64
print('donors,min_two_sided_p')
for d in (4,5,6,8,12):
    print(d,2/2**d,sep=',')
print('example_p', exact([20,16,12,10,8,-1]))
for d,m in ((6,1000),(12,500)):
    print(d,m,sqrt(.2**2/d+2/(d*m)))
