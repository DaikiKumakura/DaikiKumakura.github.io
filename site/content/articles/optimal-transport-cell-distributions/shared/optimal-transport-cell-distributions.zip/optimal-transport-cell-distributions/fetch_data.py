"""Fetch a pinned public research data file; do not redistribute it in the article ZIP."""
from pathlib import Path
import hashlib
import urllib.request

HERE = Path(__file__).resolve().parent
URL = 'https://raw.githubusercontent.com/ngushchin/EntropicOTBenchmark/db2a4d0888e593659786fa27785c2fe1c82678fc/benchmark_construction_examples/single_cell_drugs/4i/8h.h5ad'
SHA256 = 'fb30ca862ad68c0b8c50a2bc98167e24c10efc1bc8df92a40fe349cf3225275d'


def verify(path):
    with path.open('rb') as f:
        digest = hashlib.file_digest(f, 'sha256').hexdigest()
    if digest != SHA256:
        raise ValueError('Data SHA256 differs from the pinned analysis input')


def main():
    folder = HERE / 'data'
    folder.mkdir(exist_ok=True)
    path = folder / '4i-8h.h5ad'
    if path.exists():
        verify(path)
        print('Existing pinned input verified.')
        return
    partial = folder / '4i-8h.h5ad.partial'
    with urllib.request.urlopen(URL, timeout=60) as r, partial.open('wb') as f:
        while chunk := r.read(1024 * 1024):
            f.write(chunk)
    verify(partial)
    partial.replace(path)
    print('Downloaded and verified 4i input (79,490,079 bytes).')


if __name__ == '__main__':
    main()
