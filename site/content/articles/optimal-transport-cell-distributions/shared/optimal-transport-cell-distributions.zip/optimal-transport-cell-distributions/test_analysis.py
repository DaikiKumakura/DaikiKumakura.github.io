"""Reference cases for the one-dimensional numerical diagnostic."""
import unittest
import numpy as np
from scipy.stats import wasserstein_distance
from analysis import quantile_transport


class QuantileReferenceTests(unittest.TestCase):
    def test_identity_for_distinct_equal_samples(self):
        x = np.array([-3., -.5, 0., 1., 7.])
        np.testing.assert_allclose(quantile_transport(x, x, x), x)

    def test_affine_map_with_ordered_equal_samples(self):
        x = np.array([0., 1., 2., 4.])
        np.testing.assert_allclose(quantile_transport(x, 3*x+2, x), 3*x+2)

    def test_monotonicity_with_ties(self):
        x = np.array([0., 0., 1., 2., 2.])
        pred = quantile_transport(x, np.array([-5., 1., 2., 7., 10.]), np.linspace(-1, 3, 25))
        self.assertTrue(np.all(np.diff(pred) >= 0))

    def test_evaluation_outside_training_range_is_clamped(self):
        pred = quantile_transport(np.array([0., 1., 2.]), np.array([4., 6., 8.]), [-10., 10.])
        np.testing.assert_allclose(pred, [4., 8.])

    def test_same_mean_different_distributions(self):
        point = np.array([0., 0.])
        spread = np.array([-1., 1.])
        self.assertEqual(point.mean(), spread.mean())
        self.assertEqual(wasserstein_distance(point, spread), 1.)

    def test_marginals_do_not_identify_pairing(self):
        x = np.array([-2., -1., 1., 2.])
        self.assertEqual(wasserstein_distance(x, x[::-1]), 0.)
        self.assertEqual(np.mean((x-x)**2), 0.)
        self.assertEqual(np.mean((x-x[::-1])**2), 10.)


if __name__ == '__main__':
    unittest.main()
