"""Original empirical distribution plots and a separate mathematical pairing example."""
import csv
from pathlib import Path
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

HERE = Path(__file__).resolve().parent
OUT = HERE / 'figures'
OUT.mkdir(exist_ok=True)
with (HERE / 'results/quantiles.csv').open(encoding='utf-8', newline='') as f:
    curves = list(csv.DictReader(f))
styles = [('observed', 'Observed test', '#222222', '-'),
          ('mean_point', 'Mean point', '#a45b32', '--'),
          ('mean_multiplier', 'Mean multiplier', '#718c95', ':'),
          ('quantile_ot', 'Quantile transport', '#166277', '-.')]
fig, axes = plt.subplots(3, 1, figsize=(8, 10), sharey=True)
for ax, drug in zip(axes, ['trametinib', 'dabrafenib', 'everolimus']):
    for method, label, color, style in styles:
        rows = [r for r in curves if r['drug'] == drug and r['method'] == method]
        ax.plot([float(r['marker_value']) for r in rows], [float(r['probability']) for r in rows],
                color=color, linestyle=style, label=label, lw=1.8)
    ax.set(title=drug.capitalize(), xlabel='Preprocessed cell pERK (log axis)', xscale='log', ylim=(0, 1))
    ax.grid(alpha=.2)
for ax in axes:
    ax.set_ylabel('Cumulative fraction')
handles, labels = axes[0].get_legend_handles_labels()
fig.legend(handles, labels, loc='lower center', ncol=4, frameon=False)
fig.tight_layout(rect=(0, .05, 1, 1))
fig.savefig(OUT / '01-marker-cdfs.png', dpi=180)
plt.close(fig)

with (HERE / 'results/toy-couplings.csv').open(encoding='utf-8', newline='') as f:
    rows = list(csv.DictReader(f))
fig, axes = plt.subplots(1, 2, figsize=(9, 4.6), sharey=True)
for ax, pairing, title in zip(axes, ['minimum_cost', 'reversed_pairing'],
                              ['Minimum squared cost: 0', 'Reversed pairing: cost 10']):
    for row in [r for r in rows if r['pairing'] == pairing]:
        x, y = float(row['source']), float(row['target'])
        ax.annotate('', xy=(1, y), xytext=(0, x),
                    arrowprops={'arrowstyle': '->', 'color': '#166277', 'lw': 1.6})
        ax.scatter([0, 1], [x, y], color=['#a45b32', '#166277'], s=45)
    ax.set(title=title, xticks=[0, 1], xticklabels=['Source', 'Target'], xlim=(-.15, 1.15), ylim=(-2.7, 2.7))
    ax.grid(axis='y', alpha=.2)
axes[0].set_ylabel('State in a mathematical example')
fig.text(.5, .025, 'Both pairings have exactly the same observed marginal distributions. Not measured cell trajectories.',
         ha='center', fontsize=9)
fig.tight_layout(rect=(0, .07, 1, 1))
fig.savefig(OUT / '02-unidentified-pairing.png', dpi=180)
plt.close(fig)
