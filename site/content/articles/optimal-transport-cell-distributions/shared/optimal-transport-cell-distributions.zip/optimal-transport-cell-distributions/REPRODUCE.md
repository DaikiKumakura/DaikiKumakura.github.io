# Recalculate the one-marker distribution diagnostic

Python 3.11 or newer is recommended. Install `requirements.txt`, then run:

```text
python fetch_data.py
python analysis.py
python -m unittest test_analysis.py
python plot.py
```

The fetch step downloads a pinned public 4i file (79,490,079 bytes) from the official EntropicOTBenchmark research repository. SHA256 is checked before use. Its original data record is https://doi.org/10.3929/ethz-b-000609681 . The original ETH download returned HTTP 429 during preparation; exact byte identity with that archive was not verified. Repository, commit, file URL and hash are recorded in `input-provenance.json`. The source data record marks noncommercial use permitted. The data itself is not bundled or relicensed.

The acquired file contains 119,479 cells and 78 features, differing in size from the analysis versions described in the CellOT and CMonge papers. This is not a reproduction of those versions. This analysis uses only `intensity-cell-pERK-mean` and control, trametinib, dabrafenib and everolimus (18,899 cells). It reads only the expression matrix, marker names and drug category. There is no patient, well, cell-line or replicate label in the observation fields used here. Do not treat cell counts as independent biological replicates or infer drug doses from this file.

Within each known condition, a seeded permutation splits cell rows 80/20. The three seeds are 20261012 (primary), 20261013 and 20261014 (split sensitivity only). Control split is shared across drugs. Every predictor uses treated training measurements; this does not evaluate unseen drugs, patients or experiments. Prediction vectors have one entry per held-out control cell, while observed treated test cells can have a different sample size.

Predictors are a constant target-training mean, a nonnegative mean-multiplier map, and a one-dimensional quantile map. The latter linearly interpolates source normalized average ranks `(rank - 1)/(n - 1)` with tie handling, then applies NumPy's linear target quantile. Source values outside its training range are clamped to endpoint average ranks. If an endpoint has ties, its mapped value need not be the absolute target minimum or maximum. This finite-sample interpolation is a diagnostic approximation to a continuous one-dimensional quantile transport, not a neural CellOT/CMonge implementation or an exact transport of arbitrary empirical masses.

Metrics are mean bias and Wasserstein-1 distance, both normalized by control-training population SD. Wasserstein distance is computed on all held-out values with SciPy, including tails. The high-side threshold is the treated-training 90th percentile for each drug. It is a statistical marker threshold, not a resistance or efficacy label. `target_train_reference` measures distance between the treated training and test distributions; it is a sampling reference, not a predictive method or a hard performance bound.

`results/quantiles.csv` has 201 quantiles per plotted curve for compact original CDF figures; it is not the input to the distance calculation. `results/toy-couplings.csv` is a separate four-state mathematical example demonstrating identical marginals with different pairings, not an experimental dataset. The six tests check identity, an affine map, monotonicity with ties, endpoint handling and analytic distance/pairing examples.

Original code, documentation and original figures are MIT licensed. No rights to the source dataset, third-party code, papers or model weights are granted. No source data file, original paper figure, model weight, individual cell identifiers or third-party code is included in this archive.
