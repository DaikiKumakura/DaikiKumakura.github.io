"""Known-condition, one-marker distribution diagnostics; not a CellOT/CMonge benchmark."""
from pathlib import Path
import argparse
import csv
import hashlib
import json
import h5py
import numpy as np
from scipy.stats import wasserstein_distance
from fetch_data import verify

HERE = Path(__file__).resolve().parent
MARKER = 'intensity-cell-pERK-mean'
DRUGS = ['trametinib', 'dabrafenib', 'everolimus']
SEEDS = [20261012, 20261013, 20261014]


def quantile_transport(source_train, target_train, source_eval):
    """Interpolate normalized empirical ranks, then linear target quantiles."""
    x, counts = np.unique(np.asarray(source_train), return_counts=True)
    n = np.sum(counts)
    p = (np.cumsum(counts) - counts / 2 - .5) / (n-1) if n > 1 else np.array([.5])
    ranks = np.interp(source_eval, x, p, left=p[0], right=p[-1])
    return np.quantile(target_train, ranks, method='linear')


def split(values, rng):
    order = rng.permutation(len(values))
    boundary = int(.8 * len(values))
    return values[order[:boundary]], values[order[boundary:]]


def write_rows(path, rows):
    with path.open('w', encoding='utf-8', newline='') as f:
        writer = csv.DictWriter(f, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def load_input(path):
    verify(path)
    with h5py.File(path, 'r') as f:
        assert f['X'].shape == (119479, 78)
        assert set(f['obs']) == {'__categories', '_index', 'drug'}
        categories = f['obs/__categories/drug'].asstr()[:]
        labels = categories[f['obs/drug'][:]]
        features = f['var/index'].asstr()[:]
        col = list(features).index(MARKER)
        values = f['X'][:, col]
    groups = {name: values[labels == name] for name in ['control'] + DRUGS}
    for name, selected in groups.items():
        if not np.all(np.isfinite(selected)) or np.any(selected < 0):
            raise ValueError(f'Selected condition has nonfinite or negative values: {name}')
    return groups


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--data', type=Path, default=HERE / 'data/4i-8h.h5ad')
    args = parser.parse_args()
    groups = load_input(args.data)
    out = HERE / 'results'
    out.mkdir(exist_ok=True)
    counts, metrics, curves = [], [], []
    probabilities = np.linspace(0, 1, 201)
    for seed in SEEDS:
        rng = np.random.default_rng(seed)
        parts = {name: split(values, rng) for name, values in groups.items()}
        control_train, control_test = parts['control']
        scale = float(np.std(control_train, ddof=0))
        if scale <= 0:
            raise ValueError('Control standard deviation must be positive')
        for name, (train, test) in parts.items():
            counts.append({'seed': seed, 'condition': name, 'total_cells': len(groups[name]),
                           'train_cells': len(train), 'test_cells': len(test),
                           'train_mean': float(np.mean(train)), 'test_mean': float(np.mean(test)),
                           'train_sd': float(np.std(train)), 'test_sd': float(np.std(test))})
        for drug in DRUGS:
            target_train, target_test = parts[drug]
            threshold = float(np.quantile(target_train, .9))
            ratio = float(np.mean(target_train) / np.mean(control_train))
            predictions = {
                'mean_point': np.full(control_test.shape, np.mean(target_train)),
                'mean_multiplier': control_test * ratio,
                'quantile_ot': quantile_transport(control_train, target_train, control_test),
                'target_train_reference': target_train,
            }
            observed_tail = float(np.mean(target_test > threshold))
            for method, pred in predictions.items():
                metrics.append({'seed': seed, 'drug': drug, 'method': method,
                                'mean_bias_control_sd': float((np.mean(pred) - np.mean(target_test)) / scale),
                                'w1_control_sd': float(wasserstein_distance(pred, target_test) / scale),
                                'pred_sd': float(np.std(pred)), 'observed_sd': float(np.std(target_test)),
                                'threshold_target_train_q90': threshold,
                                'pred_above_threshold_fraction': float(np.mean(pred > threshold)),
                                'observed_above_threshold_fraction': observed_tail})
            if seed == SEEDS[0]:
                for method, values in {'observed': target_test, **predictions}.items():
                    for probability, value in zip(probabilities, np.quantile(values, probabilities)):
                        curves.append({'drug': drug, 'method': method, 'probability': float(probability),
                                       'marker_value': float(value)})
    toy = []
    x = np.array([-2., -1., 1., 2.])
    for name, y in [('minimum_cost', x.copy()), ('reversed_pairing', x[::-1])]:
        cost = float(np.mean((y-x)**2))
        for source, target in zip(x, y):
            toy.append({'pairing': name, 'source': float(source), 'target': float(target),
                        'mean_squared_transport_cost': cost,
                        'source_target_correlation': float(np.corrcoef(x, y)[0, 1])})
    write_rows(out / 'counts.csv', counts)
    write_rows(out / 'metrics.csv', metrics)
    write_rows(out / 'quantiles.csv', curves)
    write_rows(out / 'toy-couplings.csv', toy)
    result = {'input_sha256': hashlib.sha256(args.data.read_bytes()).hexdigest(),
              'marker': MARKER, 'drugs': DRUGS, 'seeds': SEEDS,
              'raw_shape': [119479, 78], 'selected_cells': sum(len(v) for v in groups.values()),
              'primary_metrics': [r for r in metrics if r['seed'] == SEEDS[0]],
              'scope': 'Known-condition cell-row holdout, one marker. Three split sensitivities, not biological replicates. No CellOT/CMonge training, unseen drug, resistance, or lineage validation.'}
    (out / 'summary.json').write_text(json.dumps(result, indent=2) + '\n', encoding='utf-8')
    print(json.dumps({'selected_cells': result['selected_cells'], 'metric_rows': len(metrics),
                      'seed': SEEDS[0], 'scope': result['scope']}, indent=2))


if __name__ == '__main__':
    main()
