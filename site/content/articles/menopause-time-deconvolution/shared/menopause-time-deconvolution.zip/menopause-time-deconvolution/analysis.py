"""Synthetic Gaussian/probit example, not an analysis of patient data."""
from pathlib import Path
import csv
import json
import numpy as np
from scipy.integrate import quad
from scipy.special import ndtr
from scipy.stats import norm

ROOT = Path(__file__).resolve().parent
MU, SIGMA, TAU = 50.0, 4.0, 1.5


def population_curve(age, sigma=SIGMA, tau=TAU, mu=MU):
    """E[Phi((age-M)/tau)] for M~N(mu,sigma²), tau>=0."""
    if sigma < 0 or tau < 0 or sigma * sigma + tau * tau == 0:
        raise ValueError('nonnegative widths and positive total width required')
    return ndtr((np.asarray(age) - mu) / np.hypot(sigma, tau))


def numerical_mixture(age, sigma=SIGMA, tau=TAU, mu=MU):
    """Independent quadrature check for positive widths."""
    return quad(lambda z: ndtr((age-mu-sigma*z)/tau)*norm.pdf(z),
                -12, 12, epsabs=1e-12)[0]


def recovered_width(observed_width, assumed_sigma):
    if observed_width <= 0 or assumed_sigma < 0:
        raise ValueError('invalid width')
    variance = observed_width**2-assumed_sigma**2
    return float(np.sqrt(variance)) if variance >= 0 else None


def transition_span(width):
    """10%-90% transition duration for a probit curve."""
    return float(2 * norm.ppf(.9) * width)


def run():
    out = ROOT/'results'
    out.mkdir(exist_ok=True)
    observed = float(np.hypot(SIGMA, TAU))
    age = np.linspace(32, 68, 361)
    rows = []
    curves = {'age':age, 'population':population_curve(age)}
    for assumed in (0., 2., 3., 4., 4.2, 4.5):
        tau = recovered_width(observed, assumed)
        discrepancy = None
        if tau is not None:
            curve = population_curve(age, assumed, tau)
            discrepancy = float(np.max(np.abs(curve-curves['population'])))
            curves[f'intrinsic_sigma_{assumed:g}'] = ndtr((age-MU)/tau)
        rows.append({'assumed_fmp_sd_years':assumed,
                     'recovered_tau_years':tau,
                     'intrinsic_10_90_years':None if tau is None else transition_span(tau),
                     'max_population_difference':discrepancy,
                     'status':'exactly_compatible' if tau is not None else 'incompatible_in_this_model'})
    with (out/'sensitivity.csv').open('w',newline='',encoding='utf-8') as f:
        writer=csv.DictWriter(f,fieldnames=rows[0].keys());writer.writeheader();writer.writerows(rows)
    with (out/'curves.csv').open('w',newline='',encoding='utf-8') as f:
        writer=csv.writer(f);writer.writerow(curves.keys());writer.writerows(zip(*curves.values()))
    checks = [abs(numerical_mixture(a)-population_curve(a)) for a in (38,44,50,56,62)]
    summary={'kind':'synthetic explanation; no patient data',
             'model':'M~Normal(50,sigma²); response Phi((age-M)/tau)',
             'assumptions':['same response for all individuals',
                            'FMP distribution independent of sampling age',
                            'no cohort, survival, treatment or selection effects',
                            'Gaussian FMP distribution and probit response'],
             'true_fmp_mean_years':MU,'true_fmp_sd_years':SIGMA,
             'true_tau_years':TAU,'observed_width_years':observed,
             'true_intrinsic_10_90_years':transition_span(TAU),
             'population_10_90_years':transition_span(observed),
             'quadrature_max_abs_error':float(max(checks)),
             'sensitivity':rows}
    (out/'summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(summary,ensure_ascii=True,indent=2))


if __name__ == '__main__':
    run()
