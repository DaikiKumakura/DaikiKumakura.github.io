"""Render two figures from the analytic synthetic example."""
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np
from scipy.special import ndtr
from analysis import ROOT,MU,SIGMA,TAU,population_curve,recovered_width

plt.rcParams.update({'font.size':11,'axes.spines.top':False,'axes.spines.right':False})
out=ROOT/'figures';out.mkdir(exist_ok=True)
age=np.linspace(32,68,1000)
fig,ax=plt.subplots(figsize=(8,4.7))
ax.plot(age,ndtr((age-MU)/TAU),label='Response aligned to FMP (tau = 1.5 y)',lw=2.5)
ax.plot(age,population_curve(age),label='Cross-sectional mean (width = 4.27 y)',lw=2.5)
ax.set(xlabel='Age (years); mean FMP = 50',ylabel='Normalized synthetic response',ylim=(-.03,1.03))
ax.legend(frameon=False,loc='upper left');ax.grid(alpha=.15)
fig.text(.5,.01,'Synthetic example. No patient measurements.',ha='center',fontsize=9)
fig.tight_layout(rect=(0,.035,1,1));fig.savefig(out/'synthetic-blurring.png',dpi=180);plt.close(fig)

fig,(ax,bx)=plt.subplots(1,2,figsize=(11,4.6))
width=np.hypot(SIGMA,TAU)
for s in (2.,3.,4.,4.2):
    t=recovered_width(width,s)
    ax.plot(age-MU,ndtr((age-MU)/t),label=f'Assumed FMP SD {s:g} y; tau {t:.2f} y',lw=2)
    bx.plot(age,population_curve(age,s,t),lw=2,alpha=.7)
ax.set(xlabel='Years from individual FMP',ylabel='Recovered synthetic response',title='Different intrinsic trajectories')
bx.set(xlabel='Age (years)',ylabel='Cross-sectional mean',title='Exactly the same population curve')
ax.legend(frameon=False,fontsize=8);ax.grid(alpha=.15);bx.grid(alpha=.15)
fig.text(.5,.01,'Synthetic Gaussian/probit model. FMP SD 4.5 y is incompatible with observed width 4.27 y.',ha='center',fontsize=9)
fig.tight_layout(rect=(0,.045,1,1));fig.savefig(out/'synthetic-nonidentifiability.png',dpi=180);plt.close(fig)
