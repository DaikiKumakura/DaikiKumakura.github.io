import unittest
import numpy as np
from analysis import population_curve,numerical_mixture,recovered_width,transition_span


class SyntheticModelTests(unittest.TestCase):
    def test_analytic_matches_independent_quadrature(self):
        for sigma,tau in ((2,3.2),(4,1.5),(4.2,.8)):
            for age in (37,44,50,56,63):
                self.assertAlmostEqual(float(population_curve(age,sigma,tau)),
                                       numerical_mixture(age,sigma,tau),places=10)

    def test_distinct_parameters_indistinguishable(self):
        width=np.hypot(4,1.5);ages=np.linspace(30,70,400)
        for s in (0,2,3,4,4.2):
            t=recovered_width(width,s)
            np.testing.assert_allclose(population_curve(ages,s,t),population_curve(ages),atol=1e-15)

    def test_incompatible_kernel_is_reported_not_clipped(self):
        self.assertIsNone(recovered_width(np.hypot(4,1.5),4.5))

    def test_true_kernel_recovers_true_width(self):
        self.assertAlmostEqual(recovered_width(np.hypot(4,1.5),4),1.5)

    def test_span_matches_quantile_crossing(self):
        width=1.5;span=transition_span(width)
        np.testing.assert_allclose(population_curve([50-span/2,50+span/2],0,width),[.1,.9],atol=1e-14)

    def test_invalid_parameters(self):
        for args in ((0,0),(-1,2),(2,-1)):
            with self.assertRaises(ValueError):population_curve(50,*args)
        with self.assertRaises(ValueError):recovered_width(-1,2)


if __name__=='__main__':unittest.main()
