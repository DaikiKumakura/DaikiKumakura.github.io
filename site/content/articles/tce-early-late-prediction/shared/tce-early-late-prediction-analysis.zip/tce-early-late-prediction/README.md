# Early-to-late T-cell engager assay prediction

Retrospective aggregate-mean reanalysis of Figure 3, Yuan et al. (2026),
DOI:10.1208/s12248-026-01259-2. Source figure: CC BY 4.0. Attribution, URL,
license and SHA-256 are in source-provenance.json. Changes: observed gray
symbol digitization, new early-only empirical model fitting, late-time scoring,
lag/reading sensitivity, new figures and tables. Source QSP curves are not data.

Use the scientific packages in requirements.txt in an existing Python environment.
No original individual donor or culture data are included. From this directory:

```sh
python analysis/download_sources.py
python analysis/digitize.py
python analysis/run.py
python -m unittest discover -s tests
```

Only the 24/48-hour observed means enter estimation. A lag is selected using
early-time training error, never the 72-hour error. Two cell lines and nine
matched concentrations per line are available. Ten further concentrations have
72-hour observations only and are excluded; fitted source lines never fill early
measurements. The source figure is public and unblinded, so this is a retrospective
time extrapolation benchmark, not a prospective or independent-donor validation.

The assay response is derived from Alamar Blue, not a direct death census.
The 100% model maximum is an explicit assumption. Coefficients and lag are
empirical; they are not uniquely established T-cell activation or cell-death
parameters. Reading bounds/profiles are sensitivity scenarios, not biological
confidence intervals. No virtual patients, clinical dosing schedule or other-target
generalization is inferred from aggregate figure means.
