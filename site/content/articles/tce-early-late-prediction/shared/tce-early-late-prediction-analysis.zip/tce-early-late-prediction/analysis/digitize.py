"""Convert audited gray observed-symbol coordinates, never source fitted lines."""
from pathlib import Path
import csv
import hashlib
import json
from PIL import Image,ImageDraw

ROOT=Path(__file__).resolve().parents[1]


def main():
    p=ROOT/'data/processed'
    coordinates=json.loads((p/'point-coordinates.json').read_text(encoding='utf-8'))
    assert isinstance(coordinates,list) and len(coordinates)==54
    provenance=json.loads((ROOT/'source-provenance.json').read_text())
    image_path=ROOT/'data/raw/figure3.png'
    assert hashlib.sha256(image_path.read_bytes()).hexdigest()==provenance['figure_sha256']
    im=Image.open(image_path).convert('RGB');draw=ImageDraw.Draw(im)
    rows=[]
    for point in coordinates:
        pp_per_pixel=100/(point['y_zero_px']-point['y_100_px'])
        rows.append(dict(cell=point['cell'],concentration_nm=point['concentration_nm'],time_h=point['time_h'],
            response_pct=(point['y_zero_px']-point['y_px'])*pp_per_pixel,
            reading_bound_pp=point['reading_bound_px']*pp_per_pixel,x_px=point['x_px'],y_px=point['y_px'],
            y_zero_px=point['y_zero_px'],y_100_px=point['y_100_px'],source='Yuan2026 Figure3 observed mean',
            replicates='culture/donor mean composition not recoverable',et_ratio=4,cd3_kd_nm=683))
        x,y=point['x_px'],point['y_px'];draw.rectangle((x-2,y-2,x+2,y+2),outline='red')
    assert len({(r['cell'],r['concentration_nm'],r['time_h']) for r in rows})==54
    with (p/'observed-means.csv').open('w',encoding='utf-8',newline='') as f:
        writer=csv.DictWriter(f,fieldnames=rows[0]);writer.writeheader();writer.writerows(rows)
    (ROOT/'verification').mkdir(exist_ok=True)
    im.resize((1370,740)).save(ROOT/'verification/coordinate-readback.png')
    print('Observed means reconstructed:',len(rows))


if __name__=='__main__':main()
