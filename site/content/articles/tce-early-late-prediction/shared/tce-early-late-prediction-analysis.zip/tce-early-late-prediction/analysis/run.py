"""Estimate with early means only, then score the untouched late endpoints."""
from pathlib import Path
import csv
import json
import sys
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'src'))
from model import predict,fit_fixed_lag,profile,forecast,linear_forecast

LAGS=np.arange(0,48,1.)
PROFILE_RMSE_ALLOWANCE_PP=2.
READING_SCENARIOS=128
SEED=2026102609
METHODS=['carry48','linear','no_lag','early_lag']
LABELS=['Carry 48 h','Linear (clipped)','Exponential, no lag','Lag chosen by early fit']


def save_table(name,rows):
    with (ROOT/'outputs/tables'/name).open('w',encoding='utf-8',newline='') as file:
        writer=csv.DictWriter(file,fieldnames=rows[0]);writer.writeheader();writer.writerows(rows)


def metrics(obs,pred):
    e=np.asarray(pred)-np.asarray(obs)
    return dict(mae_pp=float(np.mean(abs(e))),rmse_pp=float(np.sqrt(np.mean(e**2))),max_abs_error_pp=float(max(abs(e))),
                within5=int(sum(abs(e)<=5)),within10=int(sum(abs(e)<=10)),within20=int(sum(abs(e)<=20)),n=len(e))


def main():
    for folder in ['outputs/tables','outputs/figures']:(ROOT/folder).mkdir(parents=True,exist_ok=True)
    with (ROOT/'data/processed/observed-means.csv').open(encoding='utf-8',newline='') as f:rows=list(csv.DictReader(f))
    assert len(rows)==54
    predictions,parameters,profiles,reading,profile_sensitivity,reading_scores=[],[],[],[],[],[]
    fitted={};datasets={};rng=np.random.default_rng(SEED)
    for cell in ['MDA-MB-231','MDA-MB-468']:
        observed=[r for r in rows if r['cell']==cell]
        concentrations=np.array(sorted({float(r['concentration_nm']) for r in observed}))
        assert len(concentrations)==9
        by={(float(r['concentration_nm']),int(r['time_h'])):r for r in observed}
        assert len(by)==27
        ys=np.array([[float(by[c,t]['response_pct']) for t in [24,48,72]] for c in concentrations])
        bounds=np.array([[float(by[c,t]['reading_bound_pp']) for t in [24,48,72]] for c in concentrations])
        train_c=np.repeat(concentrations,2);train_t=np.tile([24.,48.],9);train_y=ys[:,:2].ravel()
        no_lag=fit_fixed_lag(train_c,train_t,train_y)
        prof=profile(train_c,train_t,train_y,LAGS)
        best=min(prof,key=lambda x:x['training_rmse_pp'])
        for name,fit in [('no_lag',no_lag),('early_lag',best)]:parameters.append(dict(cell=cell,method=name,**fit))
        fitted[cell]=(no_lag,best,prof);datasets[cell]=(concentrations,ys,bounds)
        forecasts=dict(carry48=ys[:,1],linear=linear_forecast(ys[:,0],ys[:,1]),no_lag=forecast(concentrations,no_lag),early_lag=forecast(concentrations,best))
        for j,c in enumerate(concentrations):
            row=dict(cell=cell,concentration_nm=float(c),observed24_pct=float(ys[j,0]),observed48_pct=float(ys[j,1]),observed72_pct=float(ys[j,2]),
                     late_gain_pp=float(ys[j,2]-ys[j,1]))
            row.update({method:float(forecasts[method][j]) for method in METHODS})
            predictions.append(row)
        for fit in prof:
            late=forecast(concentrations,fit)
            for j,c in enumerate(concentrations):profiles.append(dict(cell=cell,concentration_nm=float(c),**fit,predicted72_pct=float(late[j])))
        for tolerance in [1.,2.,5.]:
            accepted=[fit for fit in prof if fit['training_rmse_pp']<=best['training_rmse_pp']+tolerance]
            arr=np.array([forecast(concentrations,f) for f in accepted])
            for j,c in enumerate(concentrations):profile_sensitivity.append(dict(cell=cell,concentration_nm=float(c),training_rmse_allowance_pp=tolerance,
                selected_lag_h=best['lag_h'],accepted_lag_min_h=min(x['lag_h'] for x in accepted),accepted_lag_max_h=max(x['lag_h'] for x in accepted),
                predicted72_min_pct=float(arr[:,j].min()),predicted72_max_pct=float(arr[:,j].max())))
        # Conditional reading sensitivity: refit rates at fixed selected lags.
        # Lag uncertainty is separately profiled; these are not biological CIs.
        for scenario in range(READING_SCENARIOS):
            jitter=ys+rng.uniform(-bounds,bounds)
            for method,pred in [('carry48',jitter[:,1]),('linear',linear_forecast(jitter[:,0],jitter[:,1]))]:
                reading_scores.append(dict(cell=cell,scenario=scenario,method=method,**metrics(jitter[:,2],pred)))
            for method,lag in [('no_lag',0.),('early_lag',best['lag_h'])]:
                fit=fit_fixed_lag(train_c,train_t,jitter[:,:2].ravel(),lag)
                pred=forecast(concentrations,fit)
                reading_scores.append(dict(cell=cell,scenario=scenario,method=method,**metrics(jitter[:,2],pred)))
                for j,c in enumerate(concentrations):reading.append(dict(cell=cell,scenario=scenario,method=method,concentration_nm=float(c),
                    fixed_lag_h=lag,predicted72_pct=float(pred[j]),read72_pct=float(jitter[j,2]),error_pp=float(pred[j]-jitter[j,2])))
    summaries=[]
    for cell in ['MDA-MB-231','MDA-MB-468','all']:
        subset=predictions if cell=='all' else [r for r in predictions if r['cell']==cell]
        for method in METHODS:summaries.append(dict(cell=cell,method=method,**metrics([r['observed72_pct'] for r in subset],[r[method] for r in subset])))
    for name,data in [('predictions.csv',predictions),('parameters.csv',parameters),('method-summary.csv',summaries),('lag-profile.csv',profiles),
                      ('profile-sensitivity.csv',profile_sensitivity),('reading-sensitivity.csv',reading),('reading-score-summary.csv',reading_scores)]:save_table(name,data)
    results=dict(mean_symbols=54,complete_trajectories=18,cell_lines=2,excluded_late_only_conditions=10,training_time_h=[24,48],heldout_time_h=72,
        primary_model='Emax100 no-lag exponential; two empirical coefficients per cell line',
        lag_selection='Minimum early-only training RMSE over 0..47 h grid; grid extended after the original upper-bound profile was unresolved, not using72h error',
        summaries=summaries,parameters=parameters,reading_scenarios=READING_SCENARIOS,seed=SEED,
        no_biological_confidence_intervals=True,clinical_or_other_target_generalization=False)
    (ROOT/'outputs/results.json').write_text(json.dumps(results,indent=2)+'\n')
    plt.rcParams.update({'font.family':'DejaVu Sans','font.size':10,'axes.spines.top':False,'axes.spines.right':False})
    blue,orange,green,gray='#0072B2','#D55E00','#009E73','#555555'
    def finish(fig,name):
        for suffix in ['png','svg']:
            p=ROOT/'outputs/figures'/(name+'.'+suffix);fig.savefig(p,dpi=180,bbox_inches='tight')
            if suffix=='svg':p.write_text('\n'.join(x.rstrip() for x in p.read_text().splitlines())+'\n')
        plt.close(fig)
    fig,axs=plt.subplots(3,2,figsize=(10.5,9),layout='constrained')
    for col,cell in enumerate(['MDA-MB-231','MDA-MB-468']):
        cs,ys,bounds=datasets[cell];no,best,_=fitted[cell]
        for row,c in enumerate([.011,.274,6.86]):
            ax=axs[row,col];j=int(np.where(cs==c)[0][0]);time=np.linspace(0,72,145)
            ax.axvspan(48,72,color='.94')
            for fit,color,label in [(no,blue,'No lag'),(best,green,'Early-selected lag')]:
                curve=predict(c,time,fit['kmax_h'],fit['ec50_nm'],fit['lag_h'])
                ax.plot(time[time<=48],curve[time<=48],color=color,label=label)
                ax.plot(time[time>=48],curve[time>=48],color=color,ls='--')
            ax.errorbar([24,48],ys[j,:2],yerr=bounds[j,:2],fmt='o',color=gray,capsize=3,label='Early means ± reading bound')
            ax.errorbar([72],[ys[j,2]],yerr=[bounds[j,2]],fmt='o',mfc='white',color=orange,capsize=3,label='Held-out 72 h mean')
            ax.set(title=f'{cell}; {c:g} nM',xlabel='Time (h)',ylabel='Assay cytotoxicity (%)',ylim=(-5,110),xlim=(0,77),xticks=[0,24,48,72])
    axs[0,0].legend(fontsize=7,frameon=False,loc='upper left')
    fig.supxlabel('Representative concentrations fixed before scoring. Lines are new empirical fits, not the source QSP curves.',fontsize=9)
    finish(fig,'01-early-late-curves')
    fig,axs=plt.subplots(1,2,figsize=(11,4.5),layout='constrained')
    for cell,color in [('MDA-MB-231',blue),('MDA-MB-468',orange)]:
        subset=[r for r in predictions if r['cell']==cell]
        axs[0].scatter([r['observed72_pct'] for r in subset],[r['no_lag'] for r in subset],label=cell,color=color)
    axs[0].plot([0,100],[0,100],color='.65',ls='--');axs[0].set(xlabel='Observed 72 h assay cytotoxicity (%)',ylabel='No-lag prediction (%)',xlim=(-5,105),ylim=(-5,105),title='18 held-out condition means')
    axs[0].legend(frameon=False,fontsize=8)
    ix=np.arange(4);allrows=[r for r in summaries if r['cell']=='all']
    axs[1].barh(ix,[r['rmse_pp'] for r in allrows],color=[gray,orange,blue,green])
    axs[1].set(yticks=ix,yticklabels=LABELS,xlabel='72 h RMSE (percentage points)',title='All conditions; no independent donor test');axs[1].invert_yaxis()
    finish(fig,'02-prediction-errors')
    fig,axs=plt.subplots(2,2,figsize=(11,7.5),layout='constrained')
    for row,cell in enumerate(['MDA-MB-231','MDA-MB-468']):
        _,best,prof=fitted[cell]
        axs[row,0].plot([r['lag_h'] for r in prof],[r['training_rmse_pp'] for r in prof],color=blue)
        axs[row,0].axhline(best['training_rmse_pp']+PROFILE_RMSE_ALLOWANCE_PP,color=gray,ls=':',label='Best + 2 pp (scenario threshold)')
        axs[row,0].axvline(best['lag_h'],color='.7',ls='--')
        axs[row,0].set(title=cell+'; early-data fit',xlabel='Fixed lag (h)',ylabel='24/48 h training RMSE (pp)');axs[row,0].legend(frameon=False,fontsize=8)
        for c,color in zip([.011,.274,6.86],[blue,orange,green]):
            axs[row,1].plot([r['lag_h'] for r in prof],[float(forecast(c,r)) for r in prof],color=color,label=f'{c:g} nM')
        axs[row,1].set(title=cell+'; resulting forecast',xlabel='Fixed lag (h)',ylabel='Predicted 72 h cytotoxicity (%)',ylim=(0,105));axs[row,1].legend(frameon=False,fontsize=8)
    fig.supxlabel('Lag profiles refit only early data. These curves are not confidence intervals or mechanistic activation-rate estimates.',fontsize=9)
    finish(fig,'03-lag-identifiability')
    print(json.dumps(dict(parameters=parameters,overall=[r for r in summaries if r['cell']=='all'])))


if __name__=='__main__':main()
