"""Retrieve the official CC BY quantitative figure and verify its bytes."""
from pathlib import Path
import json
import hashlib
import urllib.request

ROOT=Path(__file__).resolve().parents[1]


def main():
    source=json.loads((ROOT/'source-provenance.json').read_text())
    raw=ROOT/'data/raw';raw.mkdir(parents=True,exist_ok=True)
    target=raw/'figure3.png'
    if not target.exists():
        request=urllib.request.Request(source['figure_url'],headers={'User-Agent':'OpenResearchAnalysis/1.0'})
        with urllib.request.urlopen(request,timeout=90) as response:data=response.read()
        assert hashlib.sha256(data).hexdigest()==source['figure_sha256']
        target.write_bytes(data)
    assert hashlib.sha256(target.read_bytes()).hexdigest()==source['figure_sha256']
    print('Official figure verified')


if __name__=='__main__':main()
