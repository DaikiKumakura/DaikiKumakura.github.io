from pathlib import Path
import sys
import unittest
import numpy as np
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'src'))
from model import predict,fit_fixed_lag,linear_forecast,forecast


class TimePredictionTests(unittest.TestCase):
    def test_zero_and_lag(self):
        np.testing.assert_allclose(predict([1,1],[0,12],.1,.5,12),[0,0])

    def test_synthetic_recovery(self):
        c=np.repeat([.01,.1,1,10],2);t=np.tile([24,48],4)
        y=predict(c,t,.03,.2)
        f=fit_fixed_lag(c,t,y)
        self.assertAlmostEqual(f['kmax_h'],.03,places=6)
        self.assertAlmostEqual(f['ec50_nm'],.2,places=6)

    def test_reject_late_training(self):
        with self.assertRaises(ValueError):fit_fixed_lag([1,1],[48,72],[30,80])

    def test_bounded_forecast(self):
        y=predict([1e-8,1e8],[1,1e6],.1,.5)
        self.assertTrue(np.all((y>=0)&(y<=100)))

    def test_linear_clipping(self):
        np.testing.assert_array_equal(linear_forecast([0,90],[80,10]),[100,0])

    def test_fixed_lag_recovery(self):
        c=np.repeat([.01,.1,1,10],2);t=np.tile([24,48],4)
        f=fit_fixed_lag(c,t,predict(c,t,.03,.2,18),18)
        self.assertAlmostEqual(float(forecast(1,f)),float(predict(1,72,.03,.2,18)),places=5)


if __name__=='__main__':unittest.main()
