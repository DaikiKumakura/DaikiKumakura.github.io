"""Small empirical models of an in-vitro, assay-relative cytotoxicity endpoint."""
import numpy as np
from scipy.optimize import least_squares


def predict(concentration, time_h, kmax_h, ec50_nm, lag_h=0.):
    c,t=np.asarray(concentration,float),np.asarray(time_h,float)
    exposure=kmax_h*c/(ec50_nm+c)*np.maximum(t-lag_h,0.)
    return 100*(-np.expm1(-exposure))


def fit_fixed_lag(concentration,time_h,response,lag_h=0.):
    c,t,y=np.asarray(concentration,float),np.asarray(time_h,float),np.asarray(response,float)
    if not (c.shape==t.shape==y.shape) or np.any(c<=0) or np.any(t>48):
        raise ValueError("Only matched positive concentrations at times <=48 h may enter a fit")
    bounds=(np.log([1e-6,1e-8]),np.log([2.,1e3]))
    best=None
    for start in [(.03,.1),(.1,1.)]:
        f=least_squares(lambda p:predict(c,t,*np.exp(p),lag_h)-y,np.log(start),bounds=bounds,
                        max_nfev=1000,ftol=1e-10,xtol=1e-10,gtol=1e-10)
        if f.success and (best is None or np.sum(f.fun**2)<np.sum(best.fun**2)):
            best=f
    if best is None:raise RuntimeError("Optimization failed")
    values=np.exp(best.x)
    return dict(kmax_h=float(values[0]),ec50_nm=float(values[1]),lag_h=float(lag_h),
                training_rmse_pp=float(np.sqrt(np.mean(best.fun**2))))


def profile(concentration,time_h,response,lags):
    return [fit_fixed_lag(concentration,time_h,response,float(lag)) for lag in lags]


def forecast(concentrations,fit):
    return predict(concentrations,72.,fit['kmax_h'],fit['ec50_nm'],fit['lag_h'])


def linear_forecast(y24,y48):
    return np.clip(2*np.asarray(y48)-np.asarray(y24),0,100)
