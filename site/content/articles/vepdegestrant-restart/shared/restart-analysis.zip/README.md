# Vepdegestrant: conditional interruption and restart PK

Research and protocol-PK learning only. Not clinical restart/dose advice.
With existing Python matching requirements.txt:
  python analysis/run_analysis.py
  python -m unittest discover -s analysis -p "test_model.py" -q
No network, accounts, original PDF or patient-level data required.

Sources: FDA NDA219835 Table75 PDF234/printed233 and2026publication.
https://www.accessdata.fda.gov/drugsatfda_docs/nda/2026/219835Orig1s000MultidisciplineR.pdf
https://pmc.ncbi.nlm.nih.gov/articles/PMC13454499/
FDAprecisionmatchesroundedpublicationTable1;not differentmodelspooled.
ApparentCL11.759L/h,Vc477.912L,Q2.556L/h,Vp3061.810L,ka.803/h,D1 2.778h.
Zero-orderinput into gut, then first-order absorption, linear2comp elimination.
D200mg,plasma ng/mL,h. Fimplicit1 on apparentparameter scale,notabsoluteF.
No new individual-data estimates,original patientrecordsor sourceimages included.

EtaCLvariance.192,etaVcvariance.251. Sourcecrossentry .089 labels include
omega2andcorrelation ambiguously; originalcontrolstream not obtained. Main
conditional interpretation is covariance .089 (rho~.4054), alternatives rho.089
and0. Do notclaim originalOmega fully reconstructed. Fixed-coefficient CI
endpoints one-at-time,notjointbounds. OtherIIV0assumed,residualerror notadded.
Seed20261024,n2048samepaired individuals percondition.

Prior28actualdailyadministrations beforefirstomittedtime0,lastactualdose-24h.
Omit2/3/7scheduleddoses, resume atglobal48/72/168h;last-to-restart gap72/96/192h.
Outputtime0 is restart. Matchedcontinuouscounterfactual includes intendeddoses,
sameindividual/history. DailyAUCday1[0,24],day3[48,72],day7[144,168],etc.
Predoseendpoint is scheduledtimepoint,notnecessarily trueintervalminimum.
Prior7/84administrations/infiniteperiodiclimit sensitivity separate. No doubledose,
loading, changingfoodorcomedications,PDmodel or alteredAE restart rules.
90/95percent return benchmarks are analyst-defined complete24hintervals,
not efficacy/safetythresholds or continuouscrossingtimes.60daycensor reported.

IMPORTANT qualificationlimit: typicalperiodicAUC17008nearlabelmean17155,
Cmax858vs926; modelaccumAUC2.577/Cmax2.348vslabel1.4/1.3 unresolved.
Mean/representative,cohort,definition differences not adjudicated. Slowestmode
1016h not label effective19h or articlequotedterminal56h. Mathematicalsteady
not same as clinicalapproximately7daystatement. NewrestartCOUnotclinically
qualified. Results are conditionalhypotheses; noERrecovery,safeclinicalrestart,
optimaldose or individualriskprediction established.

8aggregateCSV,3originalfigures,results/environment/sourcehash snapshots.
10implementationtests independentmatrix/event PK,finite/periodic states,
missingdose exactsuperposition, integratedAUC,grid resolution andcovariance.
Implementationchecks not clinicalqualification. CodeMIT; sourcefacts attributed.
OriginalPDF/HTML notredistributed; hash refers consulted snapshot only.
