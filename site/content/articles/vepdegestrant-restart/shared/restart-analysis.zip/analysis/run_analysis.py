"""Published-model conditional interruption/restart calculations; no new patient-data fitting."""
from pathlib import Path
import json,hashlib,platform
import numpy as np
import pandas as pd
import scipy
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from model import coefficients,single,single_auc,reference,restart,daily_auc_ratios,draw,endpoints,covariance

R=Path(__file__).resolve().parents[1]
def main():
    cfg=json.loads((R/'analysis/inputs.json').read_text());p=cfg['parameters'];out=R/'outputs';tab=out/'tables';fig=out/'figures';tab.mkdir(parents=True,exist_ok=True);fig.mkdir(exist_ok=True)
    plt.rcParams.update({'font.size':10,'axes.spines.top':False,'axes.spines.right':False,'savefig.dpi':160})
    grid=np.linspace(0,24,241);first=single(grid,p);ss=reference(grid,p,None);firstauc=float(single_auc(24,p));ssauc=200000/p['cl'];k,_=coefficients(p)
    benchmark=dict(typical_cmax_periodic=float(ss.max()),typical_auc_periodic=ssauc,typical_cmax_first=float(first.max()),typical_auc_first=firstauc,typical_accum_cmax=float(ss.max()/first.max()),typical_accum_auc=ssauc/firstauc,mode_half_h=(np.log(2)/k).tolist(),typical_tmax_periodic=float(grid[ss.argmax()]),label=cfg['label'])
    pd.DataFrame([dict(parameter=k,estimate=v,low=cfg['ci'][k][0],high=cfg['ci'][k][1]) for k,v in p.items()]+[dict(parameter='eta_cl_variance',estimate=.192),dict(parameter='eta_vc_variance',estimate=.251),dict(parameter='cross_entry_definition_ambiguous',estimate=.089)]).to_csv(tab/'source-parameters.csv',index=False)
    be=[]
    for key,source in [('cmax',926),('auc',17155),('accum_cmax',1.3),('accum_auc',1.4)]:
        actual=benchmark['typical_'+key+'_periodic'] if key in ['cmax','auc'] else benchmark['typical_'+key]
        be.append(dict(endpoint=key,representative_model=actual,label_summary=source,ratio_to_label=actual/source))
    pd.DataFrame(be).to_csv(tab/'benchmark.csv',index=False)
    typ=[]
    for n in cfg['interruptions']:
        for row in endpoints(p,n,cfg['prior_days'],cfg['report_days']):typ.append(dict(omitted=n,**row))
    pd.DataFrame(typ).to_csv(tab/'typical-endpoints.csv',index=False)
    population=[];curves=[];returns=[]
    days=np.arange(cfg['recovery_days']);primary_curves={}
    for case in cfg['covariance_cases']:
        params=draw(cfg,case)
        for n in cfg['interruptions']:
            auc=np.array([daily_auc_ratios(days,pi,n,cfg['prior_days']) for pi in params])
            assert np.all((auc>=0)&(auc<=1+1e-10)) and np.all(np.diff(auc,axis=1)>=-1e-9)
            q=np.quantile(auc,[.05,.5,.95],axis=0)
            for j in days:curves.append(dict(case=case,omitted=n,day=int(j+1),p05=q[0,j],median=q[1,j],p95=q[2,j]))
            if case=='covariance':primary_curves[n]=q
            for threshold in [.9,.95]:
                hit=auc>=threshold;cross=np.where(hit.any(axis=1),hit.argmax(axis=1)+1,np.nan);finite=cross[np.isfinite(cross)]
                quant=np.quantile(finite,[.05,.5,.95]) if len(finite) else [np.nan]*3
                returns.append(dict(case=case,omitted=n,benchmark=threshold,crossed=int(len(finite)),not_reached=int(len(cross)-len(finite)),p05_among_reached=quant[0],median_among_reached=quant[1],p95_among_reached=quant[2]))
            # Cmax/predose distributions only for the primary conditional covariance interpretation.
            if case=='covariance':
                vals=np.array([[[row[x] for x in ['auc_ratio','cmax_ratio','predose_next_ratio']] for row in endpoints(pi,n,cfg['prior_days'],cfg['report_days'])] for pi in params])
                for j,day in enumerate(cfg['report_days']):
                    for m,key in enumerate(['auc_ratio','cmax_ratio','predose_next_ratio']):
                        z=np.quantile(vals[:,j,m],[.05,.5,.95]);population.append(dict(case=case,omitted=n,day=day+1,metric=key,p05=z[0],median=z[1],p95=z[2]))
    pd.DataFrame(population).to_csv(tab/'population-endpoints.csv',index=False);pd.DataFrame(curves).to_csv(tab/'population-curves.csv',index=False);pd.DataFrame(returns).to_csv(tab/'return-benchmarks.csv',index=False)
    hist=[]
    for prior in [7,28,84,None]:
        for n in cfg['interruptions']:
            for row in endpoints(p,n,prior,cfg['report_days']):hist.append(dict(prior_days=str(prior) if prior is not None else 'infinite',omitted=n,**row))
    pd.DataFrame(hist).to_csv(tab/'history-sensitivity.csv',index=False)
    fx=[]
    for name,ci in cfg['ci'].items():
        for bound,val in zip(['low','high'],ci):
            for n in cfg['interruptions']:
                pp={**p,name:val};rat=daily_auc_ratios(np.array([0,6,13]),pp,n,cfg['prior_days'])
                for day,value in zip([1,7,14],rat):fx.append(dict(parameter=name,bound=bound,omitted=n,day=day,auc_ratio=value))
    pd.DataFrame(fx).to_csv(tab/'fixed-parameter-sensitivity.csv',index=False)
    # Figure1: contextual source comparison and slow approach to mathematical periodic state.
    f,axs=plt.subplots(1,2,figsize=(10.5,4),layout='constrained');b=pd.DataFrame(be)
    axs[0].bar(np.arange(4),b.ratio_to_label,color=['#0072B2','#0072B2','#D55E00','#D55E00']);axs[0].axhline(1,c='.4',ls=':');axs[0].set_xticks(range(4),['Periodic\nCmax','Periodic\nAUC24','Cmax\naccumulation','AUC24\naccumulation']);axs[0].set(ylabel='Representative model / label summary',title='Steady exposure alone is insufficient')
    dd=np.arange(84);aa=single_auc((dd+1)*24,p)/ssauc;axs[1].plot(dd+1,aa,c='#0072B2');axs[1].axvline(7,c='.5',ls=':',label='Label: approximately7days');axs[1].set(xlabel='Days from first-ever administration',ylabel='Daily AUC / infinite-periodic AUC',title='Mathematical tail differs from effective half-life',ylim=(0,1.05));axs[1].legend(fontsize=8)
    f.savefig(fig/'model-context.png');plt.close(f)
    f,axs=plt.subplots(1,2,figsize=(11,4),layout='constrained');tt=np.linspace(0,14*24,3361)
    for n,col in zip(cfg['interruptions'],['#0072B2','#009E73','#D55E00']):
        ref=reference(tt,p,cfg['prior_days']+n);axs[0].plot(tt/24,ref,c=col,ls=':',alpha=.5);axs[0].plot(tt/24,restart(tt,p,n,cfg['prior_days']),c=col,label=f'{n} scheduled doses omitted');axs[1].plot(days[:28]+1,daily_auc_ratios(days[:28],p,n,cfg['prior_days']),c=col,label=f'{n} omitted')
    axs[0].set(xlabel='Days after restart',ylabel='Plasma concentration (ng/mL)',title='Reference parameters;200mgQD resumed');axs[0].legend(fontsize=7)
    axs[1].axhline(1,c='.5',ls=':');axs[1].set(xlabel='Complete24h interval after restart (day)',ylabel='Daily AUC / matched continuous reference',title='Matched prior history; not efficacy recovery',ylim=(0,1.05));axs[1].legend(fontsize=8)
    f.savefig(fig/'restart-profiles.png');plt.close(f)
    f,axs=plt.subplots(1,3,figsize=(11,3.7),layout='constrained')
    for ax,n,col in zip(axs,cfg['interruptions'],['#0072B2','#009E73','#D55E00']):
        q=primary_curves[n];ax.fill_between(days[:28]+1,q[0,:28],q[2,:28],color=col,alpha=.2);ax.plot(days[:28]+1,q[1,:28],c=col);ax.axhline(1,c='.5',ls=':');ax.set(xlabel='24h interval after restart (day)',ylabel='Daily AUC ratio',title=f'{n} scheduled doses omitted',ylim=(0,1.03))
    f.suptitle('Conditional n=2048; median and5-95%; covariance interpretation, not clinicalCI',fontsize=10);f.savefig(fig/'virtual-return.png');plt.close(f)
    result=dict(benchmark=benchmark,typical=typ,return_benchmarks=returns,n=cfg['n'],seed=cfg['seed'],primary_covariance=covariance(cfg,'covariance').tolist())
    (out/'results.json').write_text(json.dumps(result,indent=2)+'\n');(out/'environment.json').write_text(json.dumps(dict(python=platform.python_version(),numpy=np.__version__,pandas=pd.__version__,scipy=scipy.__version__,matplotlib=matplotlib.__version__),indent=2)+'\n')
    raw=R/'data/raw'
    if raw.exists():(out/'source-hashes.json').write_text(json.dumps({p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in raw.glob('*')},indent=2)+'\n')
    print('Benchmark',benchmark);print(pd.DataFrame(typ).to_string(index=False));print(pd.DataFrame(returns).to_string(index=False))

if __name__=='__main__':main()
