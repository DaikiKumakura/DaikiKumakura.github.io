"""Independent matrix/event checks; implementation tests are not clinical qualification."""
from pathlib import Path
import json,unittest
import numpy as np
from scipy.linalg import expm
from model import single,single_auc,reference,restart,daily_auc_ratios,covariance,draw,endpoints

C=json.loads((Path(__file__).parent/'inputs.json').read_text());P=C['parameters']

def matrix(p):
    return np.array([[-p['ka'],0,0],[p['ka'],-(p['cl']+p['q'])/p['vc'],p['q']/p['vp']],[0,p['q']/p['vc'],-p['q']/p['vp']]])

def advance(x,dt,p,rate):
    m=np.zeros((5,5));m[:3,:3]=matrix(p);m[0,4]=rate;m[3,1]=1000/p['vc']
    y=expm(m*dt)@np.r_[x,0.,1.]
    return y[:3],y[3]

def evolve(x,t,p,dosing=True,dose=200):
    """Start just before daily dose, no instantaneous amount jumps."""
    area=0.;d=p['d1']
    full=int(t//24);rem=t-full*24
    for duration in [24.]*full+([rem] if rem else []):
        a=min(duration,d);x,add=advance(x,a,p,dose/d if dosing else 0.);area+=add
        if duration>d:x,add=advance(x,duration-d,p,0.);area+=add
    return x,area

def prior_state(p,n):
    x=np.zeros(3)
    for _ in range(n):x,_=evolve(x,24,p)
    return x

class TestModel(unittest.TestCase):
    def test_single_profile_and_auc_against_matrix(self):
        for t in [0,.1,2.778,6,24,168]:
            # Isolated dose: after duration D1 no further administrations.
            x,area=advance(np.zeros(3),min(t,P['d1']),P,200/P['d1'])
            if t>P['d1']:x,add=advance(x,t-P['d1'],P,0);area+=add
            self.assertAlmostEqual(float(single(t,P)),x[1]*1000/P['vc'],places=9)
            self.assertAlmostEqual(float(single_auc(t,P)),area,places=8)

    def test_finite_reference_against_event_solver(self):
        x=prior_state(P,28)
        for t in [0,1,6,24,30,72]:
            actual,_=evolve(x,t,P)
            self.assertAlmostEqual(float(reference(t,P,28)),actual[1]*1000/P['vc'],places=8)

    def test_omitted_doses_and_restart_against_event_solver(self):
        for omitted in [2,3,7]:
            x=expm(matrix(P)*24*omitted)@prior_state(P,28)
            for t in [0,1,6,24,72,168]:
                actual,_=evolve(x,t,P)
                self.assertAlmostEqual(float(restart(t,P,omitted,28)),actual[1]*1000/P['vc'],places=8)

    def test_daily_auc_telescope_against_integrated_matrix(self):
        for n in [2,7]:
            alt=expm(matrix(P)*24*n)@prior_state(P,28);ref=prior_state(P,28+n)
            for day in range(8):
                alt,aa=evolve(alt,24,P);ref,ar=evolve(ref,24,P)
                self.assertAlmostEqual(float(daily_auc_ratios(np.array([day]),P,n,28)[0]),aa/ar,places=10)

    def test_periodic_auc_and_concentration(self):
        m=matrix(P);b,_=evolve(np.zeros(3),24,P);x=np.linalg.solve(np.eye(3)-expm(m*24),b)
        for t in [0,6,24]:
            actual,_=evolve(x,t,P);self.assertAlmostEqual(float(reference(t,P,None)),actual[1]*1000/P['vc'],places=8)
        _,area=evolve(x,24,P);self.assertAlmostEqual(area/(200000/P['cl']),1,places=11)

    def test_missing_residual_area_mass_balance(self):
        for n in [2,7]:
            # Missing-dose amounts remaining at restart from an independent event solution.
            delta=prior_state(P,28+n)-expm(matrix(P)*24*n)@prior_state(P,28)
            exact=(-np.linalg.solve(matrix(P),delta))[1]*1000/P['vc']
            analytic=sum(200000/P['cl']-float(single_auc(j*24,P)) for j in range(1,n+1))
            self.assertAlmostEqual(analytic/exact,1,places=10)

    def test_recovery_monotone_and_bounded_for_random_draws(self):
        for p in draw(C,'covariance',n=30):
            for n in [2,7]:
                r=daily_auc_ratios(np.arange(60),p,n,28)
                self.assertTrue(np.all((r>=0)&(r<=1+1e-12)))
                self.assertTrue(np.all(np.diff(r)>=-1e-12))

    def test_covariance_scenarios(self):
        a=covariance(C,'covariance');b=covariance(C,'correlation');z=covariance(C,'independent')
        self.assertAlmostEqual(a[0,1],.089);self.assertAlmostEqual(b[0,1]/np.sqrt(.192*.251),.089);self.assertEqual(z[0,1],0)
        for x in [a,b,z]:self.assertTrue(np.all(np.linalg.eigvalsh(x)>0))
        self.assertEqual(draw(C,'covariance',n=4),draw(C,'covariance',n=4))

    def test_selected_cmax_grid_resolution(self):
        for p in [P,*draw(C,'covariance',n=4)]:
            a=endpoints(p,7,days=[0,6,27],step=.1);b=endpoints(p,7,days=[0,6,27],step=.01)
            for x,y in zip(a,b):self.assertLess(abs(x['cmax_ratio']/y['cmax_ratio']-1),.0002)

    def test_long_history_and_no_omission(self):
        t=np.linspace(0,24,25)
        np.testing.assert_allclose(reference(t,P,1500),reference(t,P,None),rtol=1e-9)
        np.testing.assert_allclose(restart(t,P,0,28),reference(t,P,28),rtol=1e-12)
        np.testing.assert_allclose(daily_auc_ratios(np.arange(7),P,0,28),1.,rtol=1e-12)

if __name__=='__main__':unittest.main()
