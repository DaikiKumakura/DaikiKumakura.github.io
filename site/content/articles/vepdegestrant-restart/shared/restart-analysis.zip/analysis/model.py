"""Sequential zero/first-order oral two-compartment PK and exact omitted-dose superposition."""
import numpy as np

TAU=24.
DOSE=200.

def coefficients(p):
    k10=p['cl']/p['vc'];k12=p['q']/p['vc'];k21=p['q']/p['vp'];ka=p['ka']
    s=k10+k12+k21;disc=np.sqrt(s*s-4*k10*k21)
    alpha=(s+disc)/2;beta=(s-disc)/2
    if min(abs(ka-alpha),abs(ka-beta),abs(alpha-beta))<1e-8:
        raise ValueError('Near-coincident rates: use an independent matrix solution for this parameter set')
    a=ka/p['vc']*(k21-alpha)/((ka-alpha)*(beta-alpha))
    b=ka/p['vc']*(k21-beta)/((ka-beta)*(alpha-beta))
    return np.array([alpha,beta,ka]),np.array([a,b,-a-b])

def single(t,p,dose=DOSE):
    t=np.asarray(t,dtype=float);k,c=coefficients(p);x=np.maximum(t,0)[...,None];d=p['d1']
    a=np.minimum(x,d);post=np.maximum(x-d,0)
    ans=1000*dose/d*np.sum(c*np.exp(-k*post)*(-np.expm1(-k*a))/k,axis=-1)
    return np.where(t>=0,ans,0.)

def single_auc(t,p,dose=DOSE):
    """Cumulative single-dose AUC from zero to t, ng*h/mL."""
    k,c=coefficients(p);x=np.maximum(np.asarray(t,dtype=float),0)[...,None];d=p['d1']
    a=np.minimum(x,d);post=np.maximum(x-d,0)
    return 1000*dose/d*np.sum(c*(a-np.exp(-k*post)*(-np.expm1(-k*a))/k)/k,axis=-1)

def reference(t,p,prior_days=28,dose=DOSE):
    """Daily reference; prior_days administrations before time0, then dose at0/24/..."""
    t=np.asarray(t,dtype=float)
    if np.any(t<0):raise ValueError('Reference time must be nonnegative')
    k,c=coefficients(p);u=(t%TAU)[...,None];d=p['d1']
    past=np.exp(-k*(u+TAU-d))*(-np.expm1(-k*d))/k
    n=np.floor(t/TAU)+(prior_days or 0)
    factor=1. if prior_days is None else -np.expm1(-k*TAU*n[...,None])
    return single(t%TAU,p,dose)+1000*dose/d*np.sum(c*past*factor/(-np.expm1(-k*TAU)),axis=-1)

def restart(t,p,omitted,prior_days=28,dose=DOSE):
    """Time0 is restart: omitted doses occurred at -omitted*24,...,-24h."""
    t=np.asarray(t,dtype=float);history=None if prior_days is None else prior_days+omitted
    ref=reference(t,p,history,dose)
    deficit=sum((single(t+j*TAU,p,dose) for j in range(1,omitted+1)),np.zeros_like(t))
    return ref-deficit

def daily_auc_ratios(days,p,omitted,prior_days=28,dose=DOSE):
    """day0 means the first full24h window after restart. Exact telescoping sums."""
    days=np.asarray(days,dtype=float)
    ref=(dose*1000/p['cl'])*np.ones_like(days) if prior_days is None else single_auc((prior_days+omitted+days+1)*TAU,p,dose)
    missing=single_auc((days+omitted+1)*TAU,p,dose)-single_auc((days+1)*TAU,p,dose)
    return (ref-missing)/ref

def covariance(cfg,case):
    a,b=cfg['variances'];entry=cfg['cross_entry']
    off=entry if case=='covariance' else entry*np.sqrt(a*b) if case=='correlation' else 0.
    if case not in cfg['covariance_cases']:raise ValueError(case)
    return np.array([[a,off],[off,b]])

def draw(cfg,case,n=None):
    z=np.random.default_rng(cfg['seed']).standard_normal((n or cfg['n'],2));eta=z@np.linalg.cholesky(covariance(cfg,case)).T
    return [{**cfg['parameters'],'cl':cfg['parameters']['cl']*np.exp(e[0]),'vc':cfg['parameters']['vc']*np.exp(e[1])} for e in eta]

def endpoints(p,omitted,prior_days=28,days=(0,2,6,13,27),step=.1):
    rows=[];history=None if prior_days is None else prior_days+omitted
    grid=np.linspace(0,24,int(round(24/step))+1)
    for day in days:
        t=day*24+grid;ref=reference(t,p,history);alt=restart(t,p,omitted,prior_days)
        rows.append(dict(day=int(day+1),auc_ratio=float(daily_auc_ratios(np.array([day]),p,omitted,prior_days)[0]),cmax_ratio=float(alt.max()/ref.max()),predose_next_ratio=float(alt[-1]/ref[-1])))
    return rows
