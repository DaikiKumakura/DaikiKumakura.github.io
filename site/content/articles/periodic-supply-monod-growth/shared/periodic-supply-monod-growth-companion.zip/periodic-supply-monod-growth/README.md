# Periodic nutrient supply and long-run growth (MON-CV01)

Working folder for the article `periodic-supply-monod-growth` (ja/en). No external data: every number is computed from the equations.

## Question and use
- QOI: if the mean nutrient concentration is the same, does a periodic supply slow growth compared with a constant one, and under what conditions?
- COU: judge whether the mean concentration alone is enough when comparing growth under a varying supply. Theoretical conditions only; no prediction for any strain or drug. (A curvature analogy for response curves is given as an illustration only.)

## Model
X' = u X,  u' = (M - u)(a S(t) - g(u)),  0 <= u < M;  v = -log(1 - u/M) gives v' = a S(t) - G(v),  G(v) = g(M(1 - e^{-v})).
Transporter example g(u) = (b u + u^2)/(M - u) (taken as a definition; derivation from mass action not covered). Dropping the u^2 term gives the Monod form u = M s/(s + b); the u^2 term stands for dilution by growth. Numerics use M = 1 (dimensionless).

## Order of work (honest record)
1. The statements and proofs (Propositions 1-8, Theorem 3, Corollary 5) were derived first, from the ledger sketch of MON-CV01 (backlog) and the ODE form in MON-ODE01.
2. The numerical scripts were then written, after the derivation and by the same author, using the same formulas for G, g and the bounds; they check the statements by a different method (direct ODE integration; shooting for the periodic solution; separate long integration; Floquet multiplier two ways; seeded random draws). They are not blinded and not an independent implementation.
3. Two checks needed a tolerance fix after the first run (a round-off bracket in the periodic-solution shooting; the contraction check, where the bound underflows below the ODE tolerance). Both are described in the scripts and in the article tables. No statement was changed because of a numerical result.
4. There is no time-stamped pre-registration of the numerical protocol.

## Run (clean directory, no inputs needed)
```
python -X utf8 analysis/01_periodic_solution.py
python -X utf8 analysis/02_random_checks.py
python -X utf8 analysis/03_nonconvex_counterexample.py
python -X utf8 analysis/04_finite_window_and_response_analogy.py
python -X utf8 analysis/05_figures.py
python -X utf8 analysis/06_manifest.py          # writes outputs/MANIFEST_SHA256.txt
python -X utf8 analysis/06_manifest.py --check  # compares a re-run with the stored hashes
```
Environment: Python 3.12.4, NumPy 2.2.6, SciPy 1.14.0, pandas 2.2.2, Matplotlib 3.9.1. Seed 20261114 (script 02). ODE tolerance rtol 1e-11, atol 1e-13 (DOP853).

## Prior art (what could be checked)
Bibliographic data verified via Crossref / Europe PMC for: Monod 1949; Jensen 1906; Ruel & Ayres 1999; Armstrong & McGehee 1980; Chesson 2000; Smith & Waltman 1995; Pandey & Jain 2016; Yamagishi & Hatakeyama 2025 (open-access page read in summary form); Nguyen et al. 2021 (abstract-level); Pascual 1994. Full texts were not read except as stated. Novelty beyond what could be verified is not claimed. See `records/sources-read.md` (non-public).
