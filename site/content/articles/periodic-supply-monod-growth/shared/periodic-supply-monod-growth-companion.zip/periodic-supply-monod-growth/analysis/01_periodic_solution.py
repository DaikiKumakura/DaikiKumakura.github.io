"""Equal-mean comparison for the transport model g(u) = (b u + u^2)/(M - u), M = 1 (dimensionless).

Constant vs square wave vs sinusoid, same mean s = a*S.  Verifies:
 - the periodic solution by shooting (period map fixed point) and by long integration from a different start,
 - the period-average identity  mean(s) = mean(g(u*)),
 - Jensen:  mean(u*) <= g^{-1}(mean s)  (g convex),
 - the exact Jensen gap  mean g(u) - g(mean u) = A (E[1/w] - 1/E[w]),  w = M - u,
 - the two-sided bound on  u_c - mean(u*)  from g'' and g' bounds on the range of u*,
 - the Floquet multiplier by exp(-int G') and by a finite difference of the period map.
Run: python -X utf8 analysis/01_periodic_solution.py
"""
import math
import sys
from pathlib import Path

import numpy as np
import pandas as pd

sys.path.insert(0, str(Path(__file__).resolve().parent))
from common import PWConst, Sine, Transport, long_run_by_integration, period_stats, u_of_v  # noqa: E402

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "outputs"
sys.stdout.reconfigure(encoding="utf-8")

B = 0.5  # b/M (dimensionless)
SBAR = 1.0  # mean of s = a*S / M
AMP = 0.8  # relative amplitude (square: s = sbar (1 +- amp); sine: sbar (1 + amp sin))
PERIODS = [0.1, 0.3, 1.0, 3.0, 10.0, 30.0, 100.0]

fam = Transport(b=B, M=1.0)
u_c = float(fam.ginv(SBAR))
print(f"transport g, b={B}, M=1; mean s={SBAR}; constant-supply growth rate u_c = g^-1(s) = {u_c:.10f}")
print(f"check g(u_c) = {float(fam.g(u_c)):.12f}")

rows = []
for kind in ("square", "sine"):
    for w in PERIODS:
        if kind == "square":
            inp = PWConst([(w / 2, SBAR * (1 + AMP)), (w / 2, SBAR * (1 - AMP))])
        else:
            inp = Sine(mean=SBAR, amp=AMP, omega=w)
        st = period_stats(fam, inp)
        ubar, var = st["ubar"], st["var"]
        # a different method (direct long integration from a different start), not an independent derivation
        ubar_long, _ = long_run_by_integration(fam, inp, v_start=2.5)
        # exact Jensen gap for the transport model
        gap_formula = fam.A * (st["invw"] - 1.0 / (fam.M - ubar))
        gap_direct = st["gbar"] - float(fam.g(ubar))
        # identity mean(s) = mean(g(u*))
        ident_res = st["gbar"] - SBAR
        # bounds on u_c - ubar from g'' and g' over the range of u*
        # range of u* over the period (dense sampling of the periodic orbit via one integration)
        from scipy.integrate import solve_ivp
        from common import G_of_v

        sols = []
        for t0, t1, sfun in inp.segments():
            pass
        # sample u*(t) on the periodic orbit
        v = st["v0"]
        us = [float(u_of_v(v, 1.0))]
        for t0, t1, sfun in inp.segments():
            rhs = lambda t, y, sfun=sfun: [sfun(t) - float(G_of_v(fam, y[0]))]
            sol = solve_ivp(rhs, (t0, t1), [v], method="DOP853", rtol=1e-11, atol=1e-13, dense_output=True)
            tt = np.linspace(t0, t1, 4001)
            us.extend(u_of_v(sol.sol(tt)[0], 1.0).tolist())
            v = sol.y[0, -1]
        umin, umax = min(us), max(us)
        k1, k2 = float(fam.g2(umin)), float(fam.g2(umax))  # g'' increasing -> endpoints are the bounds
        c1, c2 = float(fam.g1(umin)), float(fam.g1(umax))  # g' increasing
        lo = k1 / (2 * c2) * var
        hi = k2 / (2 * c1) * var
        rows.append(
            dict(
                input=kind,
                period=w,
                u_const=u_c,
                u_mean_periodic=ubar,
                u_mean_by_long_integration=ubar_long,
                diff_shooting_vs_integration=ubar - ubar_long,
                growth_loss=u_c - ubar,
                relative_loss=(u_c - ubar) / u_c,
                var_u=var,
                identity_residual=ident_res,
                jensen_gap_direct=gap_direct,
                jensen_gap_formula=gap_formula,
                gap_formula_minus_direct=gap_formula - gap_direct,
                bound_lo=lo,
                bound_hi=hi,
                bound_ok=bool(lo - 1e-12 <= (u_c - ubar) <= hi + 1e-12),
                u_min=umin,
                u_max=umax,
                floquet_integral=st["floquet_int"],
                floquet_finite_diff=st["floquet_fd"],
            )
        )

df = pd.DataFrame(rows)
(OUT / "tables").mkdir(parents=True, exist_ok=True)
df.to_csv(OUT / "tables" / "equal_mean_comparison.csv", index=False, float_format="%.10g")

pd.set_option("display.width", 250, "display.max_columns", 30)
print(df[["input", "period", "u_const", "u_mean_periodic", "growth_loss", "relative_loss", "var_u"]].to_string(index=False, float_format=lambda x: f"{x:.6g}"))
print()
print("max |shooting - long integration| =", df["diff_shooting_vs_integration"].abs().max())
print("max |identity residual| =", df["identity_residual"].abs().max())
print("max |gap formula - direct| =", df["gap_formula_minus_direct"].abs().max())
print("all growth_loss >= 0:", bool((df["growth_loss"] >= -1e-12).all()))
print("all bounds satisfied:", bool(df["bound_ok"].all()))
print("max |Floquet integral - finite diff| =", (df["floquet_integral"] - df["floquet_finite_diff"]).abs().max())
print("Floquet multipliers range:", df["floquet_integral"].min(), df["floquet_integral"].max())

# slow-switching limit for the square wave: mean of the equilibrium growth rates
u_lo, u_hi = float(fam.ginv(SBAR * (1 - AMP))), float(fam.ginv(SBAR * (1 + AMP)))
print(f"slow-switching limit (square): (phi(s_lo)+phi(s_hi))/2 = {(u_lo+u_hi)/2:.10f};  fast-switching limit -> u_c = {u_c:.10f}")
