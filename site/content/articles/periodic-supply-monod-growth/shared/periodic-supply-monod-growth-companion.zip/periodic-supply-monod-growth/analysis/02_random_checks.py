"""Randomised check of the analytic statements (transport model, convex g), seeded.

For each draw (b, period, random piecewise-constant s with K pieces, or a sine) we compute the periodic
solution by shooting and test:
  (a) period-average identity           mean g(u*) = mean s          (residual)
  (b) Jensen                            mean u* <= g^{-1}(mean s)    (loss >= 0)
  (c) exact gap                         mean g - g(mean u) = A (E[1/w] - 1/E[w])
  (d) two-sided bound                   kappa_1 Var/(2 gamma_2) <= u_c - mean u* <= kappa_2 Var/(2 gamma_1)
  (e) contraction of the period map     |P^n(V) - P^n(0)| <= exp(-m n T) V,   m = min_{[0,V]} G'
  (f) Floquet multiplier                exp(-int G') <= exp(-m T)
Any violation is counted and the worst case reported.  Run: python -X utf8 analysis/02_random_checks.py
"""
import math
import sys
from pathlib import Path

import numpy as np
import pandas as pd
from scipy.integrate import solve_ivp

sys.path.insert(0, str(Path(__file__).resolve().parent))
from common import G_of_v, Gp_of_v, PWConst, Sine, Transport, integrate_period, period_stats, u_of_v, v_upper  # noqa: E402

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "outputs"
sys.stdout.reconfigure(encoding="utf-8")

SEED = 20261114
N_DRAWS = 300
rng = np.random.default_rng(SEED)
TOL = 1e-9


def orbit_u_range(fam, inp, v0):
    v = v0
    us = [float(u_of_v(v, fam.M))]
    for t0, t1, sfun in inp.segments():
        rhs = lambda t, y, sfun=sfun: [sfun(t) - float(G_of_v(fam, y[0]))]
        sol = solve_ivp(rhs, (t0, t1), [v], method="DOP853", rtol=1e-11, atol=1e-13, dense_output=True)
        tt = np.linspace(t0, t1, 1501)
        us.extend(u_of_v(sol.sol(tt)[0], fam.M).tolist())
        v = sol.y[0, -1]
    return min(us), max(us)


rows = []
for i in range(N_DRAWS):
    b = float(np.exp(rng.uniform(math.log(0.05), math.log(3.0))))
    fam = Transport(b=b, M=1.0)
    period = float(np.exp(rng.uniform(math.log(0.05), math.log(50.0))))
    if rng.random() < 0.8:
        K = int(rng.integers(2, 6))
        frac = rng.dirichlet(np.ones(K) * 1.5)
        s_vals = np.exp(rng.normal(0.0, 0.7, size=K))
        s_vals[rng.random(K) < 0.15] = 0.0  # allow supply-free pieces
        if s_vals.max() <= 0:
            s_vals[0] = 1.0
        inp = PWConst([(float(f * period), float(s)) for f, s in zip(frac, s_vals)])
        kind = f"piecewise{K}"
    else:
        inp = Sine(mean=float(np.exp(rng.normal(0, 0.5))), amp=float(rng.uniform(0.1, 1.0)), omega=period)
        kind = "sine"
    sbar = inp.mean_s
    u_c = float(fam.ginv(sbar))
    st = period_stats(fam, inp)
    ubar, var = st["ubar"], st["var"]
    umin, umax = orbit_u_range(fam, inp, st["v0"])
    c1, c2 = float(fam.g1(umin)), float(fam.g1(umax))
    k1, k2 = float(fam.g2(umin)), float(fam.g2(umax))
    loss = u_c - ubar
    lo, hi = k1 / (2 * c2) * var, k2 / (2 * c1) * var
    gap_formula = fam.A * (st["invw"] - 1.0 / (fam.M - ubar))
    gap_direct = st["gbar"] - float(fam.g(ubar))
    # contraction of the period map
    V = v_upper(fam, inp.max_s)
    grid = np.linspace(0.0, V, 2001)
    m = float(np.min(Gp_of_v(fam, grid)))
    va, vb = 0.0, V
    worst_ratio = 0.0  # only where the bound exceeds 1e-8 (below that the check is at the round-off floor)
    worst_excess = -1.0  # max over n of |P^n(V)-P^n(0)| - exp(-m n T) V  (should be <= 0 up to round-off)
    for n in (1, 2, 3):
        va = integrate_period(fam, inp, va, with_moments=False)[0]
        vb = integrate_period(fam, inp, vb, with_moments=False)[0]
        bound = math.exp(-m * n * inp.period) * V
        worst_excess = max(worst_excess, abs(vb - va) - bound)
        if bound > 1e-8:
            worst_ratio = max(worst_ratio, abs(vb - va) / bound)
    rows.append(
        dict(
            draw=i, kind=kind, b=b, period=period, mean_s=sbar, u_const=u_c, u_mean=ubar, var_u=var, loss=loss,
            identity_residual=st["gbar"] - sbar, gap_resid=gap_formula - gap_direct,
            bound_lo=lo, bound_hi=hi, within_bounds=bool(lo - TOL <= loss <= hi + TOL),
            jensen_ok=bool(loss >= -TOL), m_min_Gp=m, contraction_ratio=worst_ratio, contraction_excess=worst_excess,
            floquet=st["floquet_int"], floquet_bound=math.exp(-m * inp.period),
            floquet_ok=bool(st["floquet_int"] <= math.exp(-m * inp.period) * (1 + 1e-9) + 1e-300),
        )
    )

df = pd.DataFrame(rows)
df.to_csv(OUT / "tables" / "random_checks.csv", index=False, float_format="%.10g")
print(f"seed {SEED}; draws {N_DRAWS}; transport model (convex g), M=1 dimensionless")
print("kinds:", df["kind"].str.replace(r"\d", "", regex=True).value_counts().to_dict())
print(f"(a) max |identity residual|       = {df['identity_residual'].abs().max():.3e}")
print(f"(b) Jensen violated (loss < -tol)  = {(~df['jensen_ok']).sum()} of {N_DRAWS}; min loss = {df['loss'].min():.3e}")
print(f"(c) max |gap formula - direct|     = {df['gap_resid'].abs().max():.3e}")
print(f"(d) bound violated                 = {(~df['within_bounds']).sum()} of {N_DRAWS}")
rel = df["loss"] / df["var_u"]
print(f"    loss/Var(u): min {rel.min():.4g}, max {rel.max():.4g} (bounds hold if inside [k1/(2g2), k2/(2g1)] per draw)")
print(f"(e) contraction: max excess |P^n(V)-P^n(0)| - exp(-m n T) V = {df['contraction_excess'].max():.3e} (ODE tolerance rtol=1e-11); draws with excess > 1e-12: {(df['contraction_excess'] > 1e-12).sum()}, > 1e-10: {(df['contraction_excess'] > 1e-10).sum()} of {N_DRAWS}")
print(f"    max ratio |P^n(V)-P^n(0)| / (exp(-m n T) V) where the bound > 1e-8: {df['contraction_ratio'].max():.4g} (<= 1 expected)")
print(f"(f) Floquet bound violated         = {(~df['floquet_ok']).sum()} of {N_DRAWS}")
print("share of draws with relative growth loss > 1%:", float(((df['loss'] / df['u_const']) > 0.01).mean()))
print("max relative growth loss:", float((df['loss'] / df['u_const']).max()))
