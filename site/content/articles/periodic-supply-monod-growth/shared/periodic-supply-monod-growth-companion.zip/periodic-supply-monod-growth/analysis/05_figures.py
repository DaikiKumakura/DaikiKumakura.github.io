"""Figures (English text, colour-universal palette). Requires outputs/tables from scripts 01-04.
Run: python -X utf8 analysis/05_figures.py
"""
import sys
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from scipy.integrate import solve_ivp

sys.path.insert(0, str(Path(__file__).resolve().parent))
from common import G_of_v, NonConvex, PWConst, Sine, Transport, period_stats, u_of_v  # noqa: E402

ROOT = Path(__file__).resolve().parents[1]
T, F = ROOT / "outputs/tables", ROOT / "outputs/figures"
F.mkdir(parents=True, exist_ok=True)
sys.stdout.reconfigure(encoding="utf-8")
BLUE, ORANGE, GREEN, VERM, SKY, GREY = "#0072B2", "#E69F00", "#009E73", "#D55E00", "#56B4E9", "#666666"
plt.rcParams.update({"font.size": 9.5, "axes.spines.top": False, "axes.spines.right": False, "figure.dpi": 150})

fam = Transport(b=0.5, M=1.0)
SBAR, AMP, W = 1.0, 0.8, 10.0


def orbit(inp, n_periods=2, pts=1500):
    st = period_stats(fam, inp)
    v = st["v0"]
    ts, us = [0.0], [float(u_of_v(v, 1.0))]
    t_off = 0.0
    for _ in range(n_periods):
        for t0, t1, sfun in inp.segments():
            rhs = lambda t, y, sfun=sfun: [sfun(t) - float(G_of_v(fam, y[0]))]
            sol = solve_ivp(rhs, (t0, t1), [v], method="DOP853", rtol=1e-11, atol=1e-13, dense_output=True)
            tt = np.linspace(t0, t1, pts)
            ts.extend((tt + t_off).tolist())
            us.extend(u_of_v(sol.sol(tt)[0], 1.0).tolist())
            v = sol.y[0, -1]
        t_off += inp.period
    return np.array(ts), np.array(us), st


# ---------------- Fig 1: inputs with equal mean and the periodic responses ----------------
sq = PWConst([(W / 2, SBAR * (1 + AMP)), (W / 2, SBAR * (1 - AMP))])
sn = Sine(mean=SBAR, amp=AMP, omega=W)
u_c = float(fam.ginv(SBAR))
fig, axes = plt.subplots(2, 1, figsize=(7.4, 5.6), sharex=True)
tg = np.linspace(0, 2 * W, 2000)
axes[0].plot([0, 2 * W], [SBAR, SBAR], color=GREY, lw=2, label="constant, s = 1")
s_sq = np.where((tg % W) < W / 2, SBAR * (1 + AMP), SBAR * (1 - AMP))
axes[0].plot(tg, s_sq, color=ORANGE, lw=1.8, label="square wave")
axes[0].plot(tg, SBAR * (1 + AMP * np.sin(2 * np.pi * tg / W)), color=BLUE, lw=1.8, label="sinusoid")
axes[0].set_ylabel("Supply  s = aS(t)  (1/M units)")
axes[0].set_ylim(0.1, 2.35)
axes[0].legend(frameon=False, fontsize=8.5, loc="upper center", ncol=3)
axes[0].set_title("Three supplies with the same mean (period 10/M, relative amplitude 0.8)", fontsize=9.5)
for inp, col, lab in ((sq, ORANGE, "square wave"), (sn, BLUE, "sinusoid")):
    ts, us, st = orbit(inp)
    axes[1].plot(ts, us, color=col, lw=1.8, label=f"{lab}: mean u* = {st['ubar']:.3f}")
    axes[1].axhline(st["ubar"], color=col, ls=":", lw=1)
axes[1].axhline(u_c, color=GREY, lw=2, label=f"constant: u_c = {u_c:.3f}")
axes[1].set_xlabel("Time (units of 1/M)")
axes[1].set_ylabel("Growth rate u*(t)  (units of M)")
axes[1].legend(frameon=False, fontsize=8.5, loc="lower right")
axes[1].set_title("Periodic solutions of the transport model, b/M = 0.5 (convex g)", fontsize=9.5)
fig.tight_layout()
fig.savefig(F / "fig1_equal_mean_inputs.png")
plt.close(fig)

# ---------------- Fig 2: loss vs period (convex g) ----------------
eq = pd.read_csv(T / "equal_mean_comparison.csv")
u_lo, u_hi = float(fam.ginv(SBAR * (1 - AMP))), float(fam.ginv(SBAR * (1 + AMP)))
slow = 0.5 * (u_lo + u_hi)
fig, ax = plt.subplots(figsize=(6.6, 3.8))
for kind, col, mk in (("square", ORANGE, "o"), ("sine", BLUE, "s")):
    d = eq[eq["input"] == kind]
    ax.plot(d["period"], 100 * d["relative_loss"], color=col, marker=mk, lw=1.8, label=kind)
ax.axhline(100 * (u_c - slow) / u_c, color=ORANGE, ls="--", lw=1, label="square, slow-switching limit")
ax.set_xscale("log")
ax.set_xlabel("Period of the supply (units of 1/M)")
ax.set_ylabel("Relative growth loss vs constant supply (%)\n(u_c - mean u*) / u_c")
ax.set_title("Same mean supply, convex g: periodic supply never grows faster", fontsize=9.5)
ax.legend(frameon=False, fontsize=8.5)
fig.tight_layout()
fig.savefig(F / "fig2_loss_vs_period.png")
plt.close(fig)

# ---------------- Fig 4: non-convex counterexample ----------------
nc = NonConvex()
nct = pd.read_csv(T / "nonconvex_counterexample.csv")
us_grid = np.linspace(0.0, 0.5, 1000)
fig, axes = plt.subplots(1, 3, figsize=(11.2, 3.7))
ax = axes[0]
ax.plot(us_grid, nc.g(us_grid), color=VERM, lw=2, label="non-convex g")
ax.plot(us_grid, Transport(b=0.5).g(us_grid), color=BLUE, lw=2, label="transport g (convex)")
from scipy.optimize import brentq  # noqa: E402

u_inf = float(brentq(lambda u: float(nc.g2(u)), 1e-6, 0.5, xtol=1e-14))  # root of g'' (concave below it)
ax.axvspan(0, u_inf, color=SKY, alpha=0.25, label="g'' < 0 (non-convex g)")
ax.set_ylim(0, 0.6)
ax.set_xlabel("Growth rate u (units of M)")
ax.set_ylabel("g(u)  (supply needed to hold u)")
ax.legend(frameon=False, fontsize=8)
ax.set_title("Growth functions", fontsize=9.5)
ax = axes[1]
s_grid = np.linspace(0.0, 0.1, 400)
phi = np.array([float(nc.ginv(s)) for s in s_grid])
ax.plot(s_grid, phi, color=VERM, lw=2, label="phi(s) = g^-1(s), non-convex g")
s_lo, s_hi = 0.005, 0.08
p_lo, p_hi = float(nc.ginv(s_lo)), float(nc.ginv(s_hi))
ax.plot([s_lo, s_hi], [p_lo, p_hi], color=GREY, lw=1.5, ls="--", label="chord between the two supply levels")
sb = 0.5 * (s_lo + s_hi)
ax.scatter([sb], [float(nc.ginv(sb))], color=BLUE, zorder=3, label=f"constant mean supply: {float(nc.ginv(sb)):.4f}")
ax.scatter([sb], [0.5 * (p_lo + p_hi)], color=ORANGE, zorder=3, label=f"slow switching: {0.5*(p_lo+p_hi):.4f}")
ax.set_xlabel("Supply s = aS")
ax.set_ylabel("Equilibrium growth rate phi(s)")
ax.set_xlim(0.0, 0.1)
ax.set_ylim(0.0, 0.1)
ax.legend(frameon=False, fontsize=7.5, loc="lower right")
ax.set_title("phi is convex where g is concave", fontsize=9.5)
ax = axes[2]
for name, col in (("non-convex g", VERM), ("convex transport g (b=0.5)", BLUE)):
    d = nct[nct["g"] == name]
    ax.plot(d["period"], 100 * d["relative_change"], color=col, marker="o", lw=1.8, label=name)
ax.axhline(0, color=GREY, lw=1)
ax.set_xscale("log")
ax.set_xlabel("Period of the two-level supply (units of 1/M)")
ax.set_ylabel("Mean growth vs constant supply (%)")
ax.legend(frameon=False, fontsize=8, loc="center right")
ax.set_title("Equal-time two-level supply (0.005, 0.08)", fontsize=9.5)
fig.tight_layout()
fig.savefig(F / "fig4_nonconvex_counterexample.png")
plt.close(fig)

# ---------------- Fig 3: Jensen-gap bound vs exact ----------------
rc = pd.read_csv(T / "random_checks.csv").sort_values("loss").reset_index(drop=True)
fig, ax = plt.subplots(figsize=(7.2, 3.9))
x = np.arange(len(rc))
ax.vlines(x, rc["bound_lo"], rc["bound_hi"], color=SKY, lw=1.2, label="bound: k1 Var/(2 g2') to k2 Var/(2 g1')")
ax.scatter(x, rc["loss"], s=7, color=VERM, zorder=3, label="exact loss  u_c - mean u*")
ax.set_yscale("log")
ax.set_ylim(1e-9, 5.0)
ax.set_xlabel("Random draws (300, sorted by loss)")
ax.set_ylabel("Growth loss vs constant supply (units of M)")
ax.set_title("Two-sided Jensen-gap bound contains the exact loss in every draw", fontsize=9.5)
ax.legend(frameon=False, fontsize=8.5, loc="upper left")
fig.tight_layout()
fig.savefig(F / "fig3_jensen_gap_bound.png")
plt.close(fig)
print("figures written")
