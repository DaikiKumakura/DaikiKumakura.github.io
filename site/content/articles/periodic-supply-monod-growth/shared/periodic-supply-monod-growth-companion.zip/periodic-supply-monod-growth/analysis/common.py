"""Shared functions for the periodic-supply growth study (MON-CV01).

Model (dimensional form): X' = u X,  u' = (M - u)(a S(t) - g(u)),  0 <= u < M.
With v = -log(1 - u/M):  v' = a S(t) - G(v),  G(v) = g(M (1 - exp(-v))).
All numerical experiments use the dimensionless form M = 1 (time in units of 1/M, a S / M -> s).
"""
from __future__ import annotations

import math
from dataclasses import dataclass
from typing import Callable, Sequence

import numpy as np
from scipy.integrate import solve_ivp
from scipy.optimize import brentq

RTOL = 1e-11
ATOL = 1e-13


# ----------------------------------------------------------------------------
# growth-function families g(u); each returns (g, g', g'')
# ----------------------------------------------------------------------------
@dataclass(frozen=True)
class Transport:
    """g(u) = (b u + u^2)/(M - u): the transporter model of the ledger (MON-ODE01)."""

    b: float
    M: float = 1.0

    @property
    def A(self) -> float:
        return self.M**2 + self.b * self.M

    def g(self, u):
        return (self.b * u + u * u) / (self.M - u)

    def g1(self, u):
        return self.A / (self.M - u) ** 2 - 1.0

    def g2(self, u):
        return 2.0 * self.A / (self.M - u) ** 3

    def ginv(self, y):
        """Inverse of g on [0, M) (closed form)."""
        b, M = self.b, self.M
        return 0.5 * (-(b + y) + np.sqrt((b + y) ** 2 + 4.0 * y * M))


@dataclass(frozen=True)
class NonConvex:
    """g(u) = c u/(1 + u/k) + B u^2/(M - u): concave near 0, convex near M, g' > 0, g -> infinity."""

    c: float = 1.0
    k: float = 0.2
    B: float = 1.0
    M: float = 1.0

    def g(self, u):
        return self.c * u / (1.0 + u / self.k) + self.B * u * u / (self.M - u)

    def g1(self, u):
        return self.c / (1.0 + u / self.k) ** 2 + self.B * (self.M**2 / (self.M - u) ** 2 - 1.0)

    def g2(self, u):
        return -2.0 * self.c / self.k / (1.0 + u / self.k) ** 3 + 2.0 * self.B * self.M**2 / (self.M - u) ** 3

    def ginv(self, y):
        y = np.asarray(y, dtype=float)
        out = np.empty_like(y)
        flat_y, flat_o = y.ravel(), out.ravel()
        for i, yy in enumerate(flat_y):
            flat_o[i] = brentq(lambda u: self.g(u) - yy, 0.0, self.M * (1 - 1e-12), xtol=1e-14, rtol=1e-14) if yy > 0 else 0.0
        return out if out.shape else float(out)


# ----------------------------------------------------------------------------
# v-equation helpers
# ----------------------------------------------------------------------------
def u_of_v(v, M):
    return M * (1.0 - np.exp(-v))


def G_of_v(fam, v):
    return fam.g(u_of_v(v, fam.M))


def Gp_of_v(fam, v):
    return fam.g1(u_of_v(v, fam.M)) * fam.M * np.exp(-v)


def v_upper(fam, s_max):
    """V with G(V) = s_max (s_max = a * sup S); [0, V] is positively invariant."""
    if s_max <= 0:
        return 0.0
    return brentq(lambda v: G_of_v(fam, v) - s_max, 0.0, 25.0, xtol=1e-14, rtol=1e-14)


# ----------------------------------------------------------------------------
# periodic inputs: a list of pieces (length, s) with piecewise constant s, or a sine
# ----------------------------------------------------------------------------
@dataclass
class PWConst:
    pieces: Sequence[tuple[float, float]]  # (duration, s) with s = a * S

    @property
    def period(self):
        return float(sum(d for d, _ in self.pieces))

    @property
    def mean_s(self):
        return float(sum(d * s for d, s in self.pieces) / self.period)

    @property
    def max_s(self):
        return float(max(s for _, s in self.pieces))

    def segments(self):
        t = 0.0
        for d, s in self.pieces:
            yield t, t + d, (lambda tt, s=s: s)
            t += d


@dataclass
class Sine:
    mean: float
    amp: float  # relative amplitude in [0, 1]
    omega: float  # period

    @property
    def period(self):
        return self.omega

    @property
    def mean_s(self):
        return self.mean

    @property
    def max_s(self):
        return self.mean * (1.0 + self.amp)

    def segments(self):
        yield 0.0, self.omega, (lambda tt: self.mean * (1.0 + self.amp * math.sin(2.0 * math.pi * tt / self.omega)))


NAMES = ["v", "Iu", "Iu2", "Ig", "Iinvw", "IGp"]


def integrate_period(fam, inp, v0, with_moments=True):
    """Integrate the v-equation over one period from v0.

    Returns (v_end, moments) where moments are the time-integrals over the period of
    u, u^2, g(u), 1/(M-u), G'(v)  (needed for means, variance, exact Jensen gap, Floquet exponent).
    """
    M = fam.M
    y = np.array([v0, 0.0, 0.0, 0.0, 0.0, 0.0])
    for t0, t1, sfun in inp.segments():
        def rhs(t, y, sfun=sfun):
            v = y[0]
            u = M * (1.0 - math.exp(-v))
            return [
                sfun(t) - float(G_of_v(fam, v)),
                u,
                u * u,
                float(fam.g(u)),
                1.0 / (M - u),
                float(Gp_of_v(fam, v)),
            ]

        sol = solve_ivp(rhs, (t0, t1), y, method="DOP853", rtol=RTOL, atol=ATOL)
        y = sol.y[:, -1]
    return y[0], y[1:]


def periodic_solution(fam, inp):
    """Shooting: unique fixed point of the period map P(v0) on [0, V] (Banach contraction)."""
    V = v_upper(fam, inp.max_s)
    if V <= 0:
        return 0.0
    f = lambda v0: integrate_period(fam, inp, v0, with_moments=False)[0] - v0
    f0, fV = f(0.0), f(V)
    # theory: f(0) >= 0 and f(V) <= 0; a zero (to round-off) at an end point means the fixed point is that end point
    if f0 <= 1e-13:
        return 0.0
    if fV >= -1e-13:
        return V
    return brentq(f, 0.0, V, xtol=1e-13, rtol=1e-13)


def period_stats(fam, inp):
    """Periodic-solution statistics: mean u, Var u, mean g(u), mean 1/(M-u), Floquet multiplier."""
    v0 = periodic_solution(fam, inp)
    v1, I = integrate_period(fam, inp, v0)
    w = inp.period
    ubar = I[0] / w
    var = I[1] / w - ubar**2
    gbar = I[2] / w
    invw = I[3] / w
    floquet_int = math.exp(-I[4])
    # finite-difference derivative of the period map
    h = 1e-6
    vp = integrate_period(fam, inp, v0 + h, with_moments=False)[0]
    vm = integrate_period(fam, inp, max(v0 - h, 0.0) if v0 - h >= 0 else 0.0, with_moments=False)[0]
    lo = v0 - h if v0 - h >= 0 else 0.0
    floquet_fd = (vp - vm) / ((v0 + h) - lo)
    return dict(v0=v0, v_end=v1, ubar=ubar, var=var, gbar=gbar, invw=invw, floquet_int=floquet_int, floquet_fd=floquet_fd)


def long_run_by_integration(fam, inp, v_start, n_periods=400):
    """A different method (direct integration, not an independent derivation): integrate from an arbitrary start until the period map settles; return mean u over the last period."""
    v = v_start
    for _ in range(n_periods):
        v_new, I = integrate_period(fam, inp, v)
        if abs(v_new - v) < 1e-13:
            v = v_new
            break
        v = v_new
    v_end, I = integrate_period(fam, inp, v)
    return I[0] / inp.period, v
