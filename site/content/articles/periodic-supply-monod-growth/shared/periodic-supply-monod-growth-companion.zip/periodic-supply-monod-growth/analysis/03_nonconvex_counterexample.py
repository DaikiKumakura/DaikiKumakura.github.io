"""Non-convex g: a two-level equal-time input can beat constant supply (slow-switching limit).

g(u) = c u/(1+u/k) + B u^2/(M-u)   (c=1, k=0.2, B=1, M=1): g(0)=0, g'>0, g -> infinity, concave on [0, u*] (u*~0.106).
Input: s alternates between s_lo and s_hi for equal times (period omega); mean s = (s_lo+s_hi)/2.
Slow-switching limit:  mean(u*) -> (phi(s_lo)+phi(s_hi))/2, phi = g^{-1}; error bound  2 M V /(m omega).
Control: the convex transport model with the same input.
Run: python -X utf8 analysis/03_nonconvex_counterexample.py
"""
import sys
from pathlib import Path

import numpy as np
import pandas as pd

sys.path.insert(0, str(Path(__file__).resolve().parent))
from common import Gp_of_v, NonConvex, PWConst, Transport, period_stats, v_upper  # noqa: E402

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "outputs"
sys.stdout.reconfigure(encoding="utf-8")

S_LO, S_HI = 0.005, 0.08
S_BAR = (S_LO + S_HI) / 2
PERIODS = [0.3, 1.0, 3.0, 10.0, 30.0, 100.0, 300.0, 1000.0]

nc = NonConvex()
tr = Transport(b=0.5, M=1.0)

from scipy.optimize import brentq  # noqa: E402

# boundary of the concave stretch: root of g'' (g'' < 0 below it, > 0 above it)
u_inflect = float(brentq(lambda u: float(nc.g2(u)), 1e-6, 0.5, xtol=1e-14))
print(f"non-convex g: g'' < 0 on [0, {u_inflect:.6f}) , g'' > 0 beyond; g({u_inflect:.6f}) = {float(nc.g(u_inflect)):.5f}")
print(f"  (4 digits: concave for u < {np.floor(u_inflect * 1e4) / 1e4:.4f}; the root itself is {u_inflect:.6f})")
print(f"input: s in {{{S_LO}, {S_HI}}}, equal times, mean {S_BAR}")

rows = []
for name, fam in (("non-convex g", nc), ("convex transport g (b=0.5)", tr)):
    u_c = float(fam.ginv(S_BAR))
    u_lo, u_hi = float(fam.ginv(S_LO)), float(fam.ginv(S_HI))
    slow = 0.5 * (u_lo + u_hi)
    V = v_upper(fam, S_HI)
    m = float(np.min(Gp_of_v(fam, np.linspace(0.0, V, 4001))))
    for w in PERIODS:
        st = period_stats(fam, PWConst([(w / 2, S_HI), (w / 2, S_LO)]))
        err = st["ubar"] - slow
        rows.append(
            dict(g=name, period=w, u_const=u_c, u_slow_limit=slow, u_mean_periodic=st["ubar"],
                 change_vs_constant=st["ubar"] - u_c, relative_change=(st["ubar"] - u_c) / u_c,
                 abs_err_to_slow_limit=abs(err), err_bound_2MV_over_m_omega=2.0 * fam.M * V / (m * w),
                 bound_ok=bool(abs(err) <= 2.0 * fam.M * V / (m * w)))
        )
df = pd.DataFrame(rows)
df.to_csv(OUT / "tables" / "nonconvex_counterexample.csv", index=False, float_format="%.10g")
pd.set_option("display.width", 220, "display.max_columns", 20)
print(df.to_string(index=False, float_format=lambda x: f"{x:.6g}"))
print("all slow-limit error bounds satisfied:", bool(df["bound_ok"].all()))

# where does the reversal occur?  phi'' > 0 exactly where g'' < 0 (phi'' = -a^2 g''/g'^3)
s_inflect = float(nc.g(u_inflect))
print(f"phi = g^-1 is convex for s < g(u_inflect) = {s_inflect:.5f}; both inputs ({S_LO}, {S_HI}) lie in that region")
