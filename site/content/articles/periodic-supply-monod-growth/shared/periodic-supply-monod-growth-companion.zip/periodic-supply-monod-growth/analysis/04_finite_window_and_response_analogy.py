"""(1) Finite observation window vs the periodic mean (transient vs periodic regime).
(2) Illustration of the same convexity logic for an instantaneous effect (dose-response) curve.

(1) For arbitrary start v(0)=v0 the window mean  (1/T) int_0^T u dt  differs from mean(u*) by at most
    (M V / m + M omega) / T   (proved in the article); the log growth of X over [0, T] is T times this mean.
(2) E(C) = Emax C^h/(EC50^h + C^h) with constant exposure C_bar versus two exposure levels held for equal times
    (instantaneous response, no pharmacokinetic lag).  This is an analogy for curvature only, not a model of any drug.
Run: python -X utf8 analysis/04_finite_window_and_response_analogy.py
"""
import math
import sys
from pathlib import Path

import numpy as np
import pandas as pd
from scipy.integrate import solve_ivp

sys.path.insert(0, str(Path(__file__).resolve().parent))
from common import G_of_v, Gp_of_v, PWConst, Transport, period_stats, u_of_v, v_upper  # noqa: E402

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "outputs"
sys.stdout.reconfigure(encoding="utf-8")

# ---------------- (1) finite window ----------------
fam = Transport(b=0.5, M=1.0)
W = 10.0
inp = PWConst([(W / 2, 1.8), (W / 2, 0.2)])  # mean s = 1, same input as in 01
st = period_stats(fam, inp)
ubar = st["ubar"]
V = v_upper(fam, inp.max_s)
m = float(np.min(Gp_of_v(fam, np.linspace(0.0, V, 4001))))


def window_mean(v0, T):
    """(1/T) * integral of u over [0, T] along the solution started at v0 (piecewise constant input, repeated)."""
    t = 0.0
    v = v0
    acc = 0.0
    while t < T - 1e-15:
        for dur, s in inp.pieces:
            seg = min(dur, T - t)
            if seg <= 0:
                break
            rhs = lambda tt, y, s=s: [s - float(G_of_v(fam, y[0])), float(u_of_v(y[0], 1.0))]
            sol = solve_ivp(rhs, (0.0, seg), [v, 0.0], method="DOP853", rtol=1e-11, atol=1e-13)
            v, a = sol.y[0, -1], sol.y[1, -1]
            acc += a
            t += seg
            if t >= T - 1e-15:
                break
    return acc / T


rows = []
for v0 in (0.0, V):
    for T in (5.0, 10.0, 20.0, 50.0, 100.0, 200.0, 500.0):
        wm = window_mean(v0, T)
        bound = (fam.M * V / m + fam.M * W) / T
        rows.append(dict(v0=v0, T=T, window_mean_u=wm, periodic_mean_u=ubar, abs_diff=abs(wm - ubar), bound=bound, bound_ok=bool(abs(wm - ubar) <= bound)))
fw = pd.DataFrame(rows)
fw.to_csv(OUT / "tables" / "finite_window.csv", index=False, float_format="%.10g")
print(f"(1) finite window: transport b=0.5, square wave period {W}, mean s=1; periodic mean u* = {ubar:.8f}; V={V:.4f}, m={m:.4g}")
print(fw.to_string(index=False, float_format=lambda x: f"{x:.6g}"))
print("all window bounds satisfied:", bool(fw["bound_ok"].all()))

# ---------------- (2) response-curve analogy ----------------
def emax(c, h, ec50=1.0, emax_=1.0):
    return emax_ * c**h / (ec50**h + c**h)


rows = []
for h, c_lo, c_hi in [(1.0, 0.2, 1.8), (1.0, 0.5, 3.5), (3.0, 0.2, 0.9), (3.0, 0.4, 1.6), (3.0, 0.2, 1.8)]:
    c_bar = 0.5 * (c_lo + c_hi)
    e_const = float(emax(c_bar, h))
    e_var = 0.5 * (float(emax(c_lo, h)) + float(emax(c_hi, h)))
    rows.append(dict(hill=h, c_lo=c_lo, c_hi=c_hi, c_mean=c_bar, effect_constant=e_const, effect_two_level=e_var, difference=e_var - e_const))
em = pd.DataFrame(rows)
em.to_csv(OUT / "tables" / "response_curve_analogy.csv", index=False, float_format="%.10g")
print("\n(2) instantaneous response E(C) = C^h/(1+C^h), exposure in units of EC50, equal-time two-level exposure vs constant exposure with the same mean")
print(em.to_string(index=False, float_format=lambda x: f"{x:.5g}"))
print("Hill h=3 inflection: E'' = 0 at C = ((h-1)/(h+1))^(1/h) EC50 =", ((3 - 1) / (3 + 1)) ** (1 / 3))
