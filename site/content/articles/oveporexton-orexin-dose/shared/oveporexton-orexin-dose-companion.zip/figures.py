from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import pandas as pd

ROOT = Path(__file__).resolve().parent
FIG = ROOT / "figures"
FIG.mkdir(exist_ok=True)
arms = pd.read_csv(ROOT / "results" / "arms-outcomes.csv")
ae = pd.read_csv(ROOT / "results" / "adverse-events.csv")
COL = {"phase 2b (8 weeks)": "#0072B2", "FirstLight (12 weeks)": "#D55E00", "RadiantLight (12 weeks)": "#009E73"}
MK = {"BID": "o", "QD": "s", "split": "^"}

fig, ax = plt.subplots(figsize=(7.5, 4.6))
m = arms[(arms.outcome == "MWT") & (arms.arm != "Placebo")]
for _, r in m.iterrows():
    ax.errorbar(r.mg_per_day, r.vs_placebo, yerr=[[r.vs_placebo - r.vs_placebo_lo], [r.vs_placebo_hi - r.vs_placebo]], fmt=MK[r.schedule],
                color=COL[r.trial], capsize=3, ms=7, label=r.trial if r.schedule == "BID" else None)
h, l = ax.get_legend_handles_labels()
u = dict(zip(l, h))
ax.legend(u.values(), u.keys(), title="trial (marker: circle twice daily, square once daily, triangle 2 mg + 5 mg)", fontsize=8, title_fontsize=7, loc="lower right")
ax.set_xlabel("total daily dose (mg)")
ax.set_ylabel("MWT sleep latency, difference vs placebo (minutes, 95% CI)")
ax.set_title("Placebo-corrected MWT by total daily dose\n(n per arm 19-70; posted ClinicalTrials.gov results)", fontsize=10)
ax.set_xlim(0, 8)
ax.axhline(0, color="grey", lw=0.8)
fig.tight_layout()
fig.savefig(FIG / "01-mwt-dose.png", dpi=150)

terms = ["Insomnia", "Pollakiuria"]
fig, axs = plt.subplots(1, 2, figsize=(8.5, 4.2), sharey=True)
for ax, t in zip(axs, terms):
    d = ae[(ae.term == t)]
    for tr, g in d.groupby("trial"):
        g = g.copy()
        g["order"] = g.arm.map(lambda s: 0 if s == "Placebo" else 1)
        ax.scatter([f"{tr}\n{a}".replace("TAK-861 ", "").replace("OVE ", "").replace("Oveporexton", "2 mg BID") for a in g.arm], g.rate * 100, color=COL[tr], s=30)
        for x, (_, r) in zip(range(len(g)), g.iterrows()):
            pass
    ax.set_title(t, fontsize=10)
    ax.tick_params(axis="x", labelrotation=90, labelsize=6)
    ax.set_ylim(0, 100)
axs[0].set_ylabel("participants with the event (%)")
fig.suptitle("Adverse events reported at >= 5% (posted results; arms n 19-70)", fontsize=10)
fig.tight_layout()
fig.savefig(FIG / "02-adverse-events.png", dpi=150)
print("ok")
