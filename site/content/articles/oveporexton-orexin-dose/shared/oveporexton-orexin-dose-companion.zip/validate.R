# Independent check (base R + jsonlite): re-read the posted results and recompute the 2 mg vs 1 mg BID increment and 2 mg BID heterogeneity.
# Run from this folder: Rscript validate.R
library(jsonlite)
z <- qnorm(0.975)
get_ls <- function(nct, pat) {
  j <- fromJSON(file.path("inputs", paste0(nct, ".json")), simplifyVector = FALSE)
  o <- Filter(function(x) grepl(pat, x$title), j$resultsSection$outcomeMeasuresModule$outcomeMeasures)[[1]]
  titles <- setNames(sapply(o$groups, `[[`, "title"), sapply(o$groups, `[[`, "id"))
  out <- list()
  for (cl in o$classes) for (cat in cl$categories) for (m in cat$measurements)
    out[[titles[[m$groupId]]]] <- c(as.numeric(m$value), as.numeric(m$spread))
  out
}
fl <- get_ls("NCT06470828", "MWT"); ph <- get_ls("NCT05687903", "MWT"); rl <- get_ls("NCT06505031", "MWT")
d <- fl[["OVE 2 mg BID"]][1] - fl[["OVE 1 mg BID"]][1]
se <- sqrt(fl[["OVE 2 mg BID"]][2]^2 + fl[["OVE 1 mg BID"]][2]^2)
m <- c(ph[["TAK-861 2 mg BID"]][1], fl[["OVE 2 mg BID"]][1], rl[["Oveporexton"]][1])
s <- c(ph[["TAK-861 2 mg BID"]][2], fl[["OVE 2 mg BID"]][2], rl[["Oveporexton"]][2])
w <- 1 / s^2; pooled <- sum(w * m) / w
q <- sum(w * (m - sum(w * m) / sum(w))^2)
py_inc <- read.csv("results/increment-2mg-vs-1mg.csv"); py_het <- read.csv("results/heterogeneity-2mg-bid.csv")
ok <- abs(d - py_inc$difference_2mg_minus_1mg[1]) < 1e-3 && abs(d - z * se - py_inc$lo[1]) < 1e-3 &&
  abs(q - py_het$q[1]) < 1e-3 && abs(pchisq(q, 2, lower.tail = FALSE) - py_het$p[1]) < 1e-3
cat(sprintf("increment %.3f (%.3f, %.3f); Q %.3f p %.4f\n", d, d - z * se, d + z * se, q, pchisq(q, 2, lower.tail = FALSE)))
write_json(list(status = if (ok) "pass" else "fail", method = "base R/jsonlite recomputation from posted results"), "results/validation.json", auto_unbox = TRUE, pretty = TRUE)
cat("validation:", if (ok) "pass" else "fail", "\n")
