# オベポレキストンの用量：配布資料

記事「オベポレキストンの1 mg群と2 mg群の差を公開された試験結果から比べる」（英語版: Oveporexton 1 mg versus 2 mg twice daily, compared using posted trial results）の再実行用資料。

## 含むもの
- `inputs/`：ClinicalTrials.govの結果（NCT05687903、NCT06470828、NCT06505031）。公開された群ごとの要約で、個人のデータではない
- `analysis.py`, `test_analysis.py`, `figures.py`, `validate.R`
- `results/`, `figures/`

## 実行
`python -m pytest -q test_analysis.py && python analysis.py && python figures.py && Rscript validate.R`（Python 3.12、numpy、pandas、scipy、matplotlib；R 4.5.3、jsonlite）

2群の差の信頼区間は、標準誤差を独立として合成した近似である（共通プラセボ近似は`results/increment-sensitivity-shared-placebo.csv`）。`validate.R`は同じ筆者による再実装で、第三者の確認ではない。審査報告書は使っていない。
