# オベポレキストンの用量：配布資料

記事「日本の標準用量は1 mg、試験の主役は2 mg：オレキシン作動薬オベポレキストンの用量を、公開された試験結果から読む」の再実行用資料。

## 含むもの
- `inputs/`：ClinicalTrials.govの結果（NCT05687903、NCT06470828、NCT06505031）。公開された群ごとの要約で、個人のデータではない
- `analysis.py`, `test_analysis.py`, `figures.py`, `validate.R`
- `results/`, `figures/`

## 実行
`python -m pytest -q test_analysis.py && python analysis.py && python figures.py && Rscript validate.R`（Python 3.12、numpy、pandas、scipy、matplotlib；R 4.5.3、jsonlite）

2群の差の信頼区間は、標準誤差を独立として合成した近似である。審査報告書は使っていない。
