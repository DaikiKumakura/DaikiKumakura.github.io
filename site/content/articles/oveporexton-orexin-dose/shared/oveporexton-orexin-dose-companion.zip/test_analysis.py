import numpy as np
import pandas as pd

import analysis as a


def test_wilson_contains_point_and_is_bounded():
    lo, hi = a.wilson(38, 66)
    assert 0 <= lo < 38 / 66 < hi <= 1
    lo0, hi0 = a.wilson(0, 41)
    assert lo0 == 0 or abs(lo0) < 1e-12
    assert hi0 > 0


def test_diff_ci_symmetric():
    d, lo, hi, se = a.diff_ci(15.87, 1.205, 12.51, 1.284)
    assert abs(d - 3.36) < 1e-9
    assert abs((hi - d) - (d - lo)) < 1e-9
    assert abs(se - np.hypot(1.205, 1.284)) < 1e-9


def test_arm_map_covers_all_posted_arms():
    for nct in a.STUDIES:
        j = a.load(nct)
        for g in j["resultsSection"]["adverseEventsModule"]["eventGroups"]:
            assert g["title"] in a.ARMS, g["title"]


def test_rows_have_sample_sizes_and_both_trial_placebos():
    rows = []
    for nct in a.STUDIES:
        rows += a.outcome_rows(nct, a.load(nct))
    df = pd.DataFrame(rows)
    assert (df.n > 0).all()
    assert df[df.arm == "Placebo"].nct.nunique() == 3
