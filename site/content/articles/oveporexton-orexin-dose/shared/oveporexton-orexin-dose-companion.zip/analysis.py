"""Dose, regimen and adverse events of oveporexton (TAK-861) from the results posted on ClinicalTrials.gov.

Trials: NCT05687903 (phase 2b, 8 weeks, n = 112), NCT06470828 (FirstLight, 12 weeks, n = 168), NCT06505031 (RadiantLight, 12 weeks, n = 105).
Everything is read from the posted results JSON (inputs/); nothing is typed in by hand except the arm -> regimen map below.
"""
from pathlib import Path
import json

import numpy as np
import pandas as pd
from scipy import stats

ROOT = Path(__file__).resolve().parent
OUT = ROOT / "results"
OUT.mkdir(exist_ok=True)
STUDIES = {"NCT05687903": "phase 2b (8 weeks)", "NCT06470828": "FirstLight (12 weeks)", "NCT06505031": "RadiantLight (12 weeks)"}
# arm title -> (regimen, mg per dose list, total mg/day)
ARMS = {
    "Placebo": ("placebo", "", 0.0),
    "TAK-861 0.5 mg BID": ("0.5 mg twice daily", "BID", 1.0),
    "TAK-861 2 mg BID": ("2 mg twice daily", "BID", 4.0),
    "TAK-861 2 mg and 5 mg": ("2 mg then 5 mg", "split", 7.0),
    "TAK-861 7 mg QD": ("7 mg once daily", "QD", 7.0),
    "OVE 1 mg BID": ("1 mg twice daily", "BID", 2.0),
    "OVE 2 mg BID": ("2 mg twice daily", "BID", 4.0),
    "Oveporexton": ("2 mg twice daily", "BID", 4.0),     # RadiantLight arm description: 2 mg BID
    "TAK-861 2 mg/5 mg": ("2 mg then 5 mg", "split", 7.0),
}
Z = 1.959964


def load(nct):
    return json.load(open(ROOT / "inputs" / f"{nct}.json", encoding="utf-8"))


def outcome_rows(nct, j):
    rs = j["resultsSection"]["outcomeMeasuresModule"]["outcomeMeasures"]
    rows = []
    for key, pat in (("MWT", "MWT"), ("ESS", "ESS"), ("WCR", "Weekly Cataplexy Rate")):
        o = next(x for x in rs if pat in x["title"])
        titles = {g["id"]: g["title"] for g in o["groups"]}
        n = {c["groupId"]: int(c["value"]) for c in o["denoms"][0]["counts"]}
        vals = {m["groupId"]: (float(m["value"]), float(m["spread"]) if m.get("spread") else np.nan)
                for c in o["classes"] for cat in c["categories"] for m in cat["measurements"]}
        comp = {a["groupIds"][1]: a for a in o.get("analyses", []) if a["groupIds"][0] == "OG000"}
        for gid, t in titles.items():
            reg, kind, daily = ARMS[t]
            a = comp.get(gid, {})
            rows.append(dict(trial=STUDIES[nct], nct=nct, outcome=key, arm=t, regimen=reg, schedule=kind, mg_per_day=daily, n=n[gid],
                             value=vals[gid][0], se=vals[gid][1] if o.get("dispersionType") == "Standard Error" else np.nan,
                             unit=o["unitOfMeasure"], stat=o.get("paramType"),
                             vs_placebo=float(a["paramValue"]) if a.get("paramValue") else np.nan,
                             vs_placebo_lo=float(a["ciLowerLimit"]) if a.get("ciLowerLimit") else np.nan,
                             vs_placebo_hi=float(a["ciUpperLimit"]) if a.get("ciUpperLimit") else np.nan,
                             vs_placebo_stat=a.get("paramType", "")))
    return rows


def ae_rows(nct, j):
    ae = j["resultsSection"]["adverseEventsModule"]
    titles = {g["id"]: g["title"] for g in ae["eventGroups"]}
    rows = []
    for ev in ae["otherEvents"]:
        for s in ev["stats"]:
            k, n = int(s["numAffected"]), int(s["numAtRisk"])
            lo, hi = wilson(k, n)
            rows.append(dict(trial=STUDIES[nct], nct=nct, term=ev["term"], arm=titles[s["groupId"]], affected=k, at_risk=n, rate=k / n, lo=lo, hi=hi))
    return rows


def wilson(k, n):
    p = k / n
    d = 1 + Z * Z / n
    c = (p + Z * Z / (2 * n)) / d
    h = Z * np.sqrt(p * (1 - p) / n + Z * Z / (4 * n * n)) / d
    return c - h, c + h


def diff_ci(m1, se1, m2, se2):
    d = m1 - m2
    se = np.hypot(se1, se2)
    return d, d - Z * se, d + Z * se, se


def main():
    out, aes = [], []
    for nct in STUDIES:
        j = load(nct)
        out += outcome_rows(nct, j)
        aes += ae_rows(nct, j)
    arms = pd.DataFrame(out)
    arms.round(5).to_csv(OUT / "arms-outcomes.csv", index=False, lineterminator="\n")
    ae = pd.DataFrame(aes)
    ae.round(5).to_csv(OUT / "adverse-events.csv", index=False, lineterminator="\n")

    # 2 mg twice daily versus 1 mg twice daily inside FirstLight (difference of two LS means, standard errors combined as independent)
    fl = arms[(arms.nct == "NCT06470828")]
    inc = []
    for k in ("MWT", "ESS"):
        a = fl[(fl.outcome == k) & (fl.arm == "OVE 2 mg BID")].iloc[0]
        b = fl[(fl.outcome == k) & (fl.arm == "OVE 1 mg BID")].iloc[0]
        d, lo, hi, se = diff_ci(a.value, a.se, b.value, b.se)
        inc.append(dict(outcome=k, difference_2mg_minus_1mg=d, lo=lo, hi=hi, se=se, unit=a.unit))
    a = ae[(ae.nct == "NCT06470828")]
    for term in ("Insomnia", "Pollakiuria", "Micturition urgency", "Salivary hypersecretion"):
        x2 = a[(a.term == term) & (a.arm == "OVE 2 mg BID")].iloc[0]
        x1 = a[(a.term == term) & (a.arm == "OVE 1 mg BID")].iloc[0]
        d = x2.rate - x1.rate
        se = np.sqrt(x2.rate * (1 - x2.rate) / x2.at_risk + x1.rate * (1 - x1.rate) / x1.at_risk)
        inc.append(dict(outcome=f"AE: {term}", difference_2mg_minus_1mg=d, lo=d - Z * se, hi=d + Z * se, se=se, unit="proportion"))
    pd.DataFrame(inc).round(5).to_csv(OUT / "increment-2mg-vs-1mg.csv", index=False, lineterminator="\n")


    # sensitivity: back-solve the covariance from the posted contrasts vs placebo (shared placebo arm) instead of assuming independence
    sens = []
    for k in ("MWT", "ESS"):
        g = {r.arm: r for r in fl[fl.outcome == k].itertuples()}
        p1, p2 = g["OVE 1 mg BID"], g["OVE 2 mg BID"]
        se1 = (p1.vs_placebo_hi - p1.vs_placebo_lo) / (2 * Z)
        se2 = (p2.vs_placebo_hi - p2.vs_placebo_lo) / (2 * Z)
        var_pbo = g["Placebo"].se ** 2          # placebo LS-mean variance shared by both contrasts
        d = p2.vs_placebo - p1.vs_placebo
        se = np.sqrt(max(se1 ** 2 + se2 ** 2 - 2 * var_pbo, 0.0))
        sens.append(dict(outcome=k, difference_2mg_minus_1mg=d, lo=d - Z * se, hi=d + Z * se, se=se, method="contrasts vs placebo with shared placebo variance"))
    pd.DataFrame(sens).round(5).to_csv(OUT / "increment-sensitivity-shared-placebo.csv", index=False, lineterminator=chr(10))
    print(pd.DataFrame(sens).round(3).to_string())

    # the same regimen (2 mg twice daily) in three trials
    het = []
    for k in ("MWT", "ESS"):
        s = arms[(arms.outcome == k) & (arms.regimen == "2 mg twice daily")].copy()
        w = 1 / s.se ** 2
        pooled = (w * s.value).sum() / w.sum()
        q = float((w * (s.value - pooled) ** 2).sum())
        dfree = len(s) - 1
        het.append(dict(outcome=k, trials=len(s), min=s.value.min(), max=s.value.max(), spread=s.value.max() - s.value.min(),
                        pooled=pooled, q=q, df=dfree, p=float(stats.chi2.sf(q, dfree)), i2=max(0.0, (q - dfree) / q) if q > 0 else 0.0))
        # placebo arms in the same trials
        pl = arms[(arms.outcome == k) & (arms.arm == "Placebo")]
        het[-1]["placebo_min"], het[-1]["placebo_max"] = pl.value.min(), pl.value.max()
    pd.DataFrame(het).round(5).to_csv(OUT / "heterogeneity-2mg-bid.csv", index=False, lineterminator="\n")

    # dose-regimen comparison in phase 2b: MWT at the same or higher total daily dose
    p2 = arms[(arms.nct == "NCT05687903") & (arms.outcome == "MWT") & (arms.arm != "Placebo")].copy()
    qd = p2[p2.schedule == "QD"].iloc[0]
    split = p2[p2.schedule == "split"].iloc[0]
    bid4 = p2[p2.arm == "TAK-861 2 mg BID"].iloc[0]
    reg = []
    for nm, x in (("2 mg twice daily (4 mg/day)", bid4), ("2 mg then 5 mg (7 mg/day)", split)):
        d, lo, hi, se = diff_ci(x.value, x.se, qd.value, qd.se)
        reg.append(dict(comparison=f"{nm} minus 7 mg once daily", difference_minutes=d, lo=lo, hi=hi))
    pd.DataFrame(reg).round(4).to_csv(OUT / "regimen-phase2b.csv", index=False, lineterminator="\n")

    summ = dict(trials={k: v for k, v in STUDIES.items()}, arms=int(arms.arm.nunique()), outcome_rows=int(len(arms)))
    (OUT / "summary.json").write_text(json.dumps(summ, indent=2) + "\n", encoding="utf-8")
    pd.set_option("display.width", 220)
    print(arms[arms.outcome == "MWT"][["trial", "arm", "mg_per_day", "n", "value", "se", "vs_placebo", "vs_placebo_lo", "vs_placebo_hi"]].round(2).to_string())
    print(arms[arms.outcome == "ESS"][["trial", "arm", "n", "value", "se", "vs_placebo"]].round(2).to_string())
    print(arms[arms.outcome == "WCR"][["trial", "arm", "n", "value", "vs_placebo", "vs_placebo_lo", "vs_placebo_hi", "vs_placebo_stat"]].round(2).to_string())
    print(pd.DataFrame(inc).round(3).to_string())
    print(pd.DataFrame(het).round(3).to_string())
    print(pd.DataFrame(reg).round(2).to_string())
    print(ae[ae.term.isin(["Insomnia", "Pollakiuria"])][["trial", "term", "arm", "affected", "at_risk", "rate"]].round(3).to_string())


if __name__ == "__main__":
    main()
