# Companion archive: surrogate adoption for PK/PD simulation outputs

Contents: package source (pkpdspace 0.0.5, GPL-3, development version), scripts, configuration and result tables (results/). No third-party data.
Requirements: R 4.5.x, pkgload, rxode2, randtoolbox, xgboost, ggplot2. Run from this directory:
  Rscript workflows/03_generate_space.R --config workflows/config/surrogate.R --out workflows/out/surrogate
  Rscript workflows/08_learn.R     (the empirical-prior part needs FRDB files and is skipped without them; not used in the article)
  Rscript workflows/11_article_figures.R   (needs the result tables; the time-course and hold-out inputs of other figures are skipped if absent)
Seed 20261127. Your numbers should match results/ to printed precision.
