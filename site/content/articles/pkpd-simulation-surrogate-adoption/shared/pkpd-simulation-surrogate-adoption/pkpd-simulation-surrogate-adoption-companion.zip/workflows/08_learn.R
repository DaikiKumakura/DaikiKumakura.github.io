#!/usr/bin/env Rscript
# Stage D: T1 surrogate, T2 empirical prior, T3 inverse-mapping calibration.
# Inputs : workflows/out/surrogate/<structure>/{drugs.rds, chunk_*.rds}, workflows/data-cache/ncats/extracted/frdb
# Outputs: validation/results/stageD-*.csv
# Decision thresholds are set here, before any evaluation (design/decisions.md 12):
#   surrogate adopted for a structure/feature only if held-out RMSE (log scale) is <= 0.5 x the linear baseline's AND
#   prediction is >= 5x faster than the simulator at equal n; otherwise it is reported as not adopted.
suppressMessages(if (file.exists("DESCRIPTION")) pkgload::load_all(".", quiet = TRUE) else library(pkpdspace))
seed <- 20261127L; out <- "validation/results"; dir.create(out, FALSE, TRUE)
adopt_rmse_ratio <- 0.5; adopt_speedup <- 5
rd <- function(d) { f <- list.files(d, pattern = "^chunk_.*\\.rds$", full.names = TRUE); do.call(rbind, lapply(f, function(x) as.data.frame(readRDS(x)))) }

# ---- T1: surrogate -----------------------------------------------------------
res <- list()
for (st in c("K01xP01", "K01xP04")) {
  d <- file.path("workflows/out/surrogate", st)
  th <- readRDS(file.path(d, "drugs.rds")); f <- rd(d); f <- f[f$status == "ok", ]
  th <- th[th$status == "ok", setdiff(names(th), c("virtual_id", "structure_id", "design_index", "design_method", "seed", "status"))]
  ids <- readRDS(file.path(d, "drugs.rds")); ids <- ids$virtual_id[ids$status == "ok"]
  th$virtual_id <- ids
  # split by virtual phenotype (drug), never across regimens: 70/30 of drugs; OOD = corner of the design (top 10% of the first two varied parameters)
  set.seed(seed); u <- unique(th$virtual_id); te_ids <- sample(u, round(0.3 * length(u)))
  vp <- setdiff(names(th), "virtual_id"); vp <- vp[vapply(th[vp], function(v) length(unique(v)) > 1L, logical(1))]
  edge <- th[[vp[1]]] > stats::quantile(th[[vp[1]]], 0.9) & th[[vp[2]]] > stats::quantile(th[[vp[2]]], 0.9)
  ood_ids <- th$virtual_id[edge & !(th$virtual_id %in% te_ids)]
  tr_ids <- setdiff(u, c(te_ids, ood_ids))
  for (reg in unique(f$regimen_id)) for (tg in c("cmax", "auc", "mean_effect", "time_above")) {
    g <- f[f$regimen_id == reg, ]; g <- g[match(th$virtual_id, g$virtual_id), ]
    y <- g[[tg]]; if (tg %in% c("cmax", "auc")) y <- log(y) else if (tg == "mean_effect") y <- log(pmax(y, 1e-6)) else y <- stats::qlogis(pmin(pmax(y, 1e-3), 1 - 1e-3))
    keep <- is.finite(y)
    tr <- th$virtual_id %in% tr_ids & keep; te <- th$virtual_id %in% te_ids & keep; oo <- th$virtual_id %in% ood_ids & keep
    thx <- th[, vp, drop = FALSE]
    for (m in c("linear", "boost")) {
      t_fit <- system.time(s <- fit_surrogate(thx[tr, , drop = FALSE], y[tr], m, seed = seed))[["elapsed"]]
      t_pred <- system.time(p <- predict(s, thx[te, , drop = FALSE]))[["elapsed"]]
      po <- predict(s, thx[oo, , drop = FALSE])
      res[[length(res) + 1L]] <- data.frame(structure = st, regimen = reg, target = tg, method = m, n_train = s$n_train, n_test = sum(te),
        rmse_test = sqrt(mean((p$fit - y[te])^2, na.rm = TRUE)), rmse_ood_edge = sqrt(mean((po$fit - y[oo])^2, na.rm = TRUE)), ood_in_domain = mean(po$in_domain),
        rmse_null = sqrt(mean((mean(y[tr]) - y[te])^2)), fit_s = t_fit, predict_s_test = t_pred, stringsAsFactors = FALSE)
    }
  }
}
r <- do.call(rbind, res)
utils::write.csv(r, file.path(out, "stageD-surrogate.csv"), row.names = FALSE)
w <- merge(r[r$method == "linear", c("structure", "regimen", "target", "rmse_test", "rmse_null")], r[r$method == "boost", c("structure", "regimen", "target", "rmse_test", "predict_s_test", "rmse_ood_edge", "ood_in_domain")],
           by = c("structure", "regimen", "target"), suffixes = c("_linear", "_boost"))
w$ratio_boost_to_linear <- w$rmse_test_boost / w$rmse_test_linear
utils::write.csv(w, file.path(out, "stageD-surrogate-compare.csv"), row.names = FALSE)
print(aggregate(cbind(rmse_null, rmse_test_linear, rmse_test_boost, ratio_boost_to_linear) ~ structure + target, data = w, FUN = median))

# simulator cost from the generation run (all 5 regimens, all features), per drug-regimen row
lg <- utils::read.csv("workflows/out/surrogate/run-log.csv")
tim <- data.frame(structure = lg$structure_id, simulate_s_per_row = lg$seconds / lg$n_rows)
pr <- aggregate(predict_s_test / n_test ~ structure + method, data = r, FUN = median); names(pr)[3] <- "predict_s_per_row"
tim <- merge(tim, pr[pr$method == "boost", ], by = "structure"); tim$speedup_boost <- tim$simulate_s_per_row / tim$predict_s_per_row
utils::write.csv(tim, file.path(out, "stageD-simulator-timing.csv"), row.names = FALSE); print(tim)

# ---- T2: empirical prior (needs the FRDB files; skipped without them) ----
if (dir.exists("workflows/data-cache/ncats/extracted/frdb")) {
ev <- import_frdb("workflows/data-cache/ncats/extracted/frdb")
for (rt in c("Oral", "Intravenous")) {
  x <- drug_pk_table(ev, rt)
  cat(rt, "drugs", nrow(x), "\n")
  e <- evaluate_empirical_prior(x, reps = 10, seed = seed); e$route <- rt; e$n_drugs <- nrow(x)
  utils::write.csv(e, file.path(out, sprintf("stageD-empirical-%s.csv", tolower(rt))), row.names = FALSE); print(e)
  p <- fit_empirical_prior(x); cat("shrink", signif(p$shrink, 3), "correlation", signif(stats::cov2cor(p$cov)[1, 2], 3), "\n")
}
} else cat("NOT EVALUATED: FRDB not available for the empirical prior.
")
