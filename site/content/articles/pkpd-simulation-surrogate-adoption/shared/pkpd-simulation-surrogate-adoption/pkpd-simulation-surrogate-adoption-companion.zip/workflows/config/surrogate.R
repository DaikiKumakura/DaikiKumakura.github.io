# Training set for the surrogate study (Stage D): two structures, larger than the pilot.
config <- modifyList(local({ source("workflows/config/pilot.R", local = TRUE); config }), list(
  n_per_structure = 16384L, structures = c("K01xP01", "K01xP04"), seed = 20261127L))
