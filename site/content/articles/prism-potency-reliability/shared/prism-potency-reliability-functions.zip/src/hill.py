"""Conditional Hill fitting and profile residual diagnostics for technical replicates."""
import numpy as np
from scipy.optimize import least_squares
from scipy.stats import f

def hill(dose: np.ndarray, low: float, upper: float, logec: float, slope: float) -> np.ndarray:
    return low + (upper-low) / (1 + np.power(dose / 10**logec, slope))

def fit_curve(dose: np.ndarray, y: np.ndarray, plates: np.ndarray, offsets: bool = True, fixed_ec: float | None = None, initial: np.ndarray | None = None) -> dict:
    codes, plate_index = np.unique(plates, return_inverse=True)
    k = len(codes)-1 if offsets else 0
    minlog, maxlog = np.log10(dose.min()), np.log10(dose.max())
    bounds_low = np.r_[0,0,minlog-3,0.1,np.full(k,-1.)]
    bounds_high = np.r_[1.5,1,maxlog+3,5,np.full(k,1.)]
    def decode(params: np.ndarray) -> np.ndarray:
        full = np.insert(params,2,fixed_ec) if fixed_ec is not None else params.copy()
        full[1]=full[0]+(2.5-full[0])*full[1]
        return full
    def residual(params: np.ndarray) -> np.ndarray:
        full = decode(params)
        predicted = hill(dose,*full[:4])
        if k:
            adjustment = np.r_[full[4:], -full[4:].sum()]
            predicted = predicted + adjustment[plate_index]
        return predicted-y
    starts = [np.r_[low,upper,ec,slope,np.zeros(k)] for ec in [minlog,(minlog+maxlog)/2,maxlog] for low,upper,slope in [(.05,.8,.5),(.2,1.,1.),(.5,1.2,2.)]]
    if fixed_ec is not None:
        # EC itself is removed from optimization, so vary actual nuisance starts.
        starts=[np.r_[low,upper,fixed_ec,slope,np.zeros(k)] for low,upper,slope in [(.05,.8,.5),(.2,1.,1.),(.5,1.2,2.)]]
    if initial is not None:
        starts.insert(0,initial.copy())
    for start in starts:
        start[1]=(start[1]-start[0])/(2.5-start[0])
    if fixed_ec is not None:
        bounds_low,bounds_high=np.delete(bounds_low,2),np.delete(bounds_high,2)
        starts=[np.delete(start,2) for start in starts]
    results=[least_squares(residual,np.clip(start,bounds_low+1e-8,bounds_high-1e-8),bounds=(bounds_low,bounds_high),max_nfev=3000) for start in starts]
    result=min(results,key=lambda result: np.sum(result.fun**2))
    params=decode(result.x)
    return dict(params=params,sse=float(np.sum(result.fun**2)),success=bool(result.success),n=len(y),nparam=len(result.x),nplates=len(codes))

def profile(dose: np.ndarray, y: np.ndarray, plates: np.ndarray, fitted: dict, size: int=101) -> dict:
    minlog,maxlog=np.log10(dose.min())-3,np.log10(dose.max())+3
    grid=np.unique(np.r_[np.linspace(minlog,maxlog,size),np.clip(np.linspace(fitted['params'][2]-.6,fitted['params'][2]+.6,81),minlog,maxlog)])
    candidates=[fit_curve(dose,y,plates,fixed_ec=float(x),initial=fitted['params']) for x in grid]
    values=np.array([candidate['sse'] for candidate in candidates])
    df=fitted['n']-fitted['nparam']
    cutoff=fitted['sse']*(1+f.ppf(.95,1,df)/df)
    accepted=grid[values<=cutoff]
    # Include the estimated optimum to avoid an empty grid for a narrow profile.
    accepted=np.r_[accepted,fitted['params'][2]]
    return dict(grid=grid,sse=values,cutoff=cutoff,lower=float(accepted.min()),upper=float(accepted.max()),open_lower=bool(values[0]<=cutoff),open_upper=bool(values[-1]<=cutoff),profile_min_minus_free_sse=float(values.min()-fitted['sse']),best_params=candidates[int(values.argmin())]['params'])

def sensitivity(dose: np.ndarray, params: np.ndarray) -> np.ndarray:
    epsilon=1e-4
    above=hill(dose,params[0],params[1],params[2]+epsilon,params[3])
    below=hill(dose,params[0],params[1],params[2]-epsilon,params[3])
    return ((above-below)/(2*epsilon))**2
