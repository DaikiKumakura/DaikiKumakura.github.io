"""Meaningful numerical regression checks for dose-response interpretation."""
from pathlib import Path
import sys,unittest
import numpy as np
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'src'))
from hill import hill,fit_curve,sensitivity

class HillChecks(unittest.TestCase):
    def setUp(self):
        self.d=np.tile(np.geomspace(.00061,10,8),3)
        self.plates=np.repeat(['a','b','c'],8)
    def test_midpoint_is_not_absolute_half(self):
        self.assertAlmostEqual(float(hill(np.array([.1]),.2,1.2,-1,1)[0]),.7)
    def test_recover_known_curve(self):
        y=hill(self.d,.1,1.,-1,1.2)
        fit=fit_curve(self.d,y,self.plates)
        np.testing.assert_allclose(fit['params'][:4],[.1,1.,-1,1.2],atol=1e-5)
    def test_plate_offsets(self):
        y=hill(self.d,.1,1.,-1,1.2)+np.repeat([.1,-.05,-.05],8)
        fit=fit_curve(self.d,y,self.plates)
        np.testing.assert_allclose(fit['params'][:4],[.1,1.,-1,1.2],atol=1e-4)
    def test_order(self):
        fit=fit_curve(self.d,np.linspace(.5,1,len(self.d)),self.plates)
        self.assertLessEqual(fit['params'][0],fit['params'][1])
    def test_sensitivity(self):
        p=np.array([.1,1.,-1,1.2]);grid=np.geomspace(.001,10,1001)
        self.assertLess(abs(np.log10(grid[np.argmax(sensitivity(grid,p))]) + 1),.01)
    def test_monotonic(self):
        self.assertTrue(np.all(np.diff(hill(np.geomspace(.001,10,100),.1,1,-1,1.2))<0))

if __name__=='__main__':unittest.main()
