"""Published-number audit and an analytic counterexample, not PerturbEnergy reproduction."""
from pathlib import Path
import csv, json, math
from statistics import NormalDist
HERE=Path(__file__).resolve().parent

def toy(strength, orientation):
    """p(z|a) proportional to N(0,1)*exp[-strength*(z-a)^2/2]."""
    if strength < 0: raise ValueError('strength must be nonnegative')
    mean=strength/(1+strength)
    variance=1/(1+strength)
    recognition=NormalDist().cdf(mean/math.sqrt(variance))
    # a in {-1,+1}, equiprobable; true scalar response y=a.
    # The fixed decoder predicts orientation * E[z|a].
    error=abs(1-orientation*mean)
    return dict(strength=strength,orientation=orientation,mean=mean,variance=variance,
                recognition=recognition,response_mean_rmse=error)

def compare(rows):
    out=[]
    for d in sorted({r['dataset'] for r in rows}):
        rs=[r for r in rows if r['dataset']==d]
        baseline=min((r for r in rs if not r['method'].startswith('PerturbEnergy')),key=lambda r:float(r['rmse']))
        for method in ['PerturbEnergy-Lang','PerturbEnergy-Mis']:
            p=next(r for r in rs if r['method']==method)
            b=float(baseline['rmse']);v=float(p['rmse'])
            out.append(dict(dataset=d,method=method,baseline=baseline['method'],baseline_rmse=b,rmse=v,
                            relative_reduction_percent=100*(b-v)/b))
    return out

def main():
    with (HERE/'inputs/top50.csv').open(encoding='utf-8') as f: rows=list(csv.DictReader(f))
    result={'scope':'Published table arithmetic plus independent illustrative scalar model; no biological data/model refit',
            'benchmarks':compare(rows),
            'toy':[toy(l,g) for l in [0,.25,1,4,16] for g in [-1,0,1]],
            'recognition_relative_gain_percent':100*(52.4-28.6)/28.6,
            'recognition_absolute_gain_percentage_points':52.4-28.6}
    (HERE/'results').mkdir(exist_ok=True)
    (HERE/'results/summary.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(result,indent=2))
if __name__=='__main__':main()
