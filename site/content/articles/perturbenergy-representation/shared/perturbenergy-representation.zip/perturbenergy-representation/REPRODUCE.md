# Reproduce the calculations

Python 3.12 and matplotlib 3.9.1. Run:

    python analysis.py
    python -m unittest test_analysis.py
    python plot.py

Outputs are results/summary.json and figures/label-vs-response.png. The inputs are published numerical facts plus a deliberately simple independent analytic example. No cellular data or trained model was rerun.

## Published-number audit

Source: Yan Y, Bian Y. Learning Perturbation-Specific Representations through Conditional Energy Prior for Cellular Response Prediction, https://arxiv.org/html/2610.18456v1 (submitted 2026-10-13), Table 2. inputs/top50.csv contains the top-50 DEG RMSE means and SEM for all 12 methods and 4 datasets. Lower is better. The baseline is the smallest mean among methods not beginning with PerturbEnergy. Both PerturbEnergy variants are kept. Relative reduction = 100*(baseline - method)/baseline; negative means worse. No significance or confidence interval is inferred from the group SEMs. The actual responses selected the true top-50 DEGs, so this RMSE does not itself measure DEG retrieval. The known-label/new-context splits and the known-single/unseen-combination split do not establish unseen-compound extrapolation.

The Replogle label recognition numbers 28.6 and 52.4 are from Table 3, PerturbedVAE and PerturbEnergy-Mis respectively. The 83.2% is a relative gain, while 23.8 is a percentage-point difference. Neither is expression RMSE improvement.

Source HTML SHA-256 and the read-only implementation commit are recorded in inputs/provenance.json. The source paper, original figures and third-party code are not redistributed or relicensed. Numerical facts are attributed to the authors; the package licence covers our original code and documentation.

## Analytic example

This is not a trained PerturbEnergy model or a biological measurement. Context is fixed; a=-1,+1 with equal probability. p0(z)=N(0,1); E(z,a)=lambda*(z-a)^2/2. The resulting normal distribution has mean lambda*a/(1+lambda), variance 1/(1+lambda). The sign classifier is evaluated on samples, yielding Phi(lambda/sqrt(1+lambda)). At lambda=0 the classification accuracy is 0.5 by symmetry.

For an artificial scalar target y=a, compare fixed decoders with orientation g=-1,0,+1. Their mean predictions are g*E[z|a]. Response-mean RMSE is abs(1-g*lambda/(1+lambda)); it is not a sampled individual-response RMSE. These decoders are deliberately fixed, not trained: the example demonstrates lack of a logical implication from recognition alone, not a flaw or measured failure of the published model. Numeric integration independently checks conditional moments; a deterministic-seed Monte Carlo test checks label accuracy. There is no claim that the reported model uses quadratic energies or these decoders.
