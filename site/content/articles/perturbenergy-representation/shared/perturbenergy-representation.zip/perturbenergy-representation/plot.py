from pathlib import Path
import json
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
HERE=Path(__file__).resolve().parent
def main():
    d=json.loads((HERE/'results/summary.json').read_text())
    fig,axes=plt.subplots(1,2,figsize=(9,4.4))
    fig.subplots_adjust(left=.08,right=.98,bottom=.23,top=.82,wspace=.3)
    rows=[r for r in d['toy'] if r['orientation']==1]
    x=list(range(len(rows)));labels=[str(r['strength']) for r in rows]
    axes[0].plot(x,[r['recognition']*100 for r in rows],'-o',color='#17667a')
    axes[0].set_ylim(45,103);axes[0].set_ylabel('Label recognition (%)');axes[0].set_title('Same representation in all cases')
    for g,label,color in [(1,'Correct sign','#17667a'),(0,'Ignores latent','#8b8b8b'),(-1,'Wrong sign','#bd633f')]:
        rows=[r for r in d['toy'] if r['orientation']==g]
        axes[1].plot(x,[r['response_mean_rmse'] for r in rows],'-o',label=label,color=color)
    axes[1].set_ylim(0,2.1);axes[1].set_ylabel('Response mean RMSE');axes[1].set_title('Decoder determines response error')
    axes[1].legend(frameon=False,fontsize=8)
    for ax in axes:
        ax.set_xticks(x,labels);ax.set_xlabel('Energy strength (selected settings)',fontsize=9);ax.spines[['top','right']].set_visible(False)
    fig.suptitle('A label can become easier to read while response prediction gets worse',fontsize=11)
    fig.text(.08,.04,'Independent analytic example, not the trained PerturbEnergy model. True response: y = a.',fontsize=9)
    (HERE/'figures').mkdir(exist_ok=True);fig.savefig(HERE/'figures/label-vs-response.png',dpi=180);plt.close(fig)
if __name__=='__main__':main()
