import math, random, unittest
from analysis import toy,compare
class Checks(unittest.TestCase):
    def test_no_signal(self):
        for sign in [-1,0,1]:
            r=toy(0,sign);self.assertEqual(r['recognition'],.5);self.assertEqual(r['response_mean_rmse'],1)
    def test_monte_carlo_checks_analytic_probability(self):
        r=toy(1,-1);rng=random.Random(18456);n=100000
        observed=sum(rng.gauss(r['mean'],math.sqrt(r['variance']))>0 for _ in range(n))/n
        self.assertAlmostEqual(observed,r['recognition'],delta=.006)
    def test_numeric_energy_moments(self):
        # Integrate the unnormalised density directly, rather than using completed-square formula.
        strength=4;dx=.002;xs=[-8+i*dx for i in range(8001)]
        ws=[math.exp(-x*x/2-strength*(x-1)**2/2) for x in xs]
        total=sum(ws);mean=sum(x*w for x,w in zip(xs,ws))/total
        variance=sum((x-mean)**2*w for x,w in zip(xs,ws))/total
        r=toy(strength,1);self.assertAlmostEqual(mean,r['mean'],places=8);self.assertAlmostEqual(variance,r['variance'],places=8)
    def test_compare_keeps_negative_gain(self):
        r=compare([dict(dataset='d',method='baseline',rmse='.1'),dict(dataset='d',method='PerturbEnergy-Lang',rmse='.12'),dict(dataset='d',method='PerturbEnergy-Mis',rmse='.11')])
        self.assertAlmostEqual(r[0]['relative_reduction_percent'],-20)
    def test_negative_strength(self):
        with self.assertRaises(ValueError):toy(-1,1)
if __name__=='__main__':unittest.main()
