# GFH375 dose fractionation: public aggregate PK

Research and learning only. Not clinical treatment or dose instructions.
Run in an existing Python environment matching requirements.txt:
  python analysis/run_analysis.py
  python -m unittest discover -s analysis -p "test_model.py" -q
No network, account, source PDF or original figure needed.

Source: Nature Medicine DOI 10.1038/s41591-026-04559-4.
https://www.nature.com/articles/s41591-026-04559-4/figures/4
https://www.nature.com/articles/s41591-026-04559-4/figures/5
Public Extended Data only; original source images/PDF not redistributed.
Plasma mean curves have SEM, not SD. Fit 600QD N24; checks 400QD N27,
750QD N4, 300BID N3. AUC boxes 600QD n25,400QD n26 differ from curve sets.
Digitized coordinates and axis calibrations included. Units ng/mL,h,mg,L.

Five apparent parameters fit to 9 mean 600QD points: two-stage equal-rate
absorption and two-compartment disposition. Log-residual least squares,
not new individual-level NLME inference. CL-only lognormal variation uses
sigma=.554 from digitized600QD AUC IQR; not original patient Omega.
Box asymmetry, unknown covariates and absorption variation unresolved.
Marginal arithmetic mean computed with Gauss-Hermite integration.
Seed20261023,n2048 paired hypothetical individuals. Linear input is main
assumption; dose exponent .5/1/1.5 and alternative sigma are scenarios.
Same daily AUC is algebraic balance, not evidence of clinical equivalence.

IMPORTANT: actual 300BID 2h mean ~393ng/mL versus prediction ~203ng/mL.
The model fails this held-out cohort check. Cross-cohort n3 does not prove
BID causes higher peaks either. No efficacy, toxicity, target coverage or
optimal regimen is established. Next step is matched absorption/full-day PK.
Pixel jitter160 repeats are readout sensitivity, not patient bootstrap/CI.

9 CSV tables,3 original figures,results and environment snapshots included.
8 implementation checks compare independent matrix exponential, integral,
quadrature, time-grid and analytic balances; not clinical qualification.
Code MIT; source observations attributed above. Source SHA is consulted
snapshot provenance, not verification of the currently online publication.
