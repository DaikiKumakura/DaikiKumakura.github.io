"""Aggregate mean PK surrogate; not an individual-data NLME fit."""
import numpy as np
from scipy.optimize import least_squares
from numpy.polynomial.hermite import hermgauss

def curve(theta: np.ndarray,t: np.ndarray,dose: float=600,times: tuple=(0,),eta: np.ndarray | None=None,beta: float=1) -> np.ndarray:
    cl,volume,ka=np.exp(theta);eta=np.zeros(1) if eta is None else np.asarray(eta)
    k=cl*np.exp(eta)/volume;out=np.zeros((len(eta),len(t)))
    # Empirical per-administration dose scaling; beta=1 is proportionality.
    amount=600*(dose/600)**beta
    for at in times:
        age=np.mod(np.asarray(t)-at,24)[None,:]
        kk=k[:,None]
        out+=1000*amount/volume*ka/(ka-kk)*(np.exp(-kk*age)/(-np.expm1(-24*kk))-np.exp(-ka*age)/(-np.expm1(-24*ka)))
    return out

def mean_curve(theta: np.ndarray,t: np.ndarray,sigma: float,dose: float=600,times: tuple=(0,),beta: float=1,nodes: int=24) -> np.ndarray:
    x,w=hermgauss(nodes);v=curve(theta,t,dose,times,np.sqrt(2)*sigma*x,beta)
    return w@v/np.sqrt(np.pi)

def fit(t: np.ndarray,y: np.ndarray,sigma: float,start: np.ndarray | None=None):
    lo=np.log([5,100,.08]);hi=np.log([3000,50000,15])
    starts=[np.log([220,1800,1]),np.log([250,3000,2]),np.log([100,4000,.5])] if start is None else [start]
    fitted=[least_squares(lambda a:np.log(mean_curve(a,t,sigma))-np.log(y),s,bounds=(lo,hi),max_nfev=1200) for s in starts]
    return min(fitted,key=lambda r:np.sum(r.fun**2))

def metrics(theta: np.ndarray,eta: np.ndarray,dose: float,times: tuple,beta: float=1,step: float=.025) -> dict:
    t=np.unique(np.r_[np.arange(0,24+step/2,step),times]);c=curve(theta,t,dose,times,eta,beta)
    cl,v,ka=np.exp(theta);auc=1000*600*(dose/600)**beta*len(times)/(cl*np.exp(eta))
    return dict(cmax=c.max(1),cmin=c.min(1),auc24=auc,cavg=auc/24)

def curve2(theta,t,dose=600,times=(0,),eta=None,beta=1):
    cl,vc,q,vp,ka=np.exp(theta);eta=np.zeros(1) if eta is None else np.asarray(eta)
    k10=cl*np.exp(eta)/vc;k12=q/vc;k21=q/vp
    total=k10+k12+k21;disc=np.sqrt(total**2-4*k10*k21)
    aa=(total+disc)/2;bb=(total-disc)/2
    wa=(aa-k21)/disc;wb=(k21-bb)/disc
    out=np.zeros((len(eta),len(t)));amount=600*(dose/600)**beta
    for at in times:
        age=np.mod(np.asarray(t)-at,24)[None,:]
        ek=np.exp(-ka*age)/(-np.expm1(-ka*24))
        for rate,w in [(aa,wa),(bb,wb)]:
            rr=rate[:,None]
            out+=1000*amount/vc*w[:,None]*ka/(ka-rr)*(np.exp(-rr*age)/(-np.expm1(-24*rr))-ek)
    return out

def mean_curve2(theta,t,sigma,dose=600,times=(0,),beta=1,nodes=24):
    x,w=hermgauss(nodes);return w@curve2(theta,t,dose,times,np.sqrt(2)*sigma*x,beta)/np.sqrt(np.pi)

def fit2(t,y,sigma,start=None):
    lo=np.log([5,30,1,50,.08]);hi=np.log([3000,50000,5000,100000,15])
    starts=[np.log([200,800,100,3000,1]),np.log([200,500,300,6000,1.5]),np.log([200,1200,300,3000,2])] if start is None else [start]
    rs=[least_squares(lambda a:np.log(mean_curve2(a,t,sigma))-np.log(y),s,bounds=(lo,hi),max_nfev=1600) for s in starts]
    return min(rs,key=lambda r:np.sum(r.fun**2))

def metrics2(theta,eta,dose,times,beta=1,step=.025):
    t=np.unique(np.r_[np.arange(0,24+step/2,step),times]);c=curve2(theta,t,dose,times,eta,beta)
    cl=np.exp(theta[0]);auc=1000*600*(dose/600)**beta*len(times)/(cl*np.exp(eta))
    return dict(cmax=c.max(1),cmin=c.min(1),auc24=auc,cavg=auc/24)

def transit2_curve(theta,t,dose=600,times=(0,),eta=None,beta=1):
    cl,vc,q,vp,ka=np.exp(theta);eta=np.zeros(1) if eta is None else np.asarray(eta)
    k10=cl*np.exp(eta)/vc;k12=q/vc;k21=q/vp;total=k10+k12+k21
    disc=np.sqrt(total*total-4*k10*k21);aa=(total+disc)/2;bb=(total-disc)/2
    wa=(aa-k21)/disc;wb=(k21-bb)/disc;out=np.zeros((len(eta),len(t)))
    amount=600*(dose/600)**beta;r=np.exp(-24*ka);den=1-r
    for at in times:
        age=np.mod(np.asarray(t)-at,24)[None,:];ea=np.exp(-ka*age)
        s0=ea/den;s1=ea*(age/den+24*r/den**2)
        s2=ea*(age**2/den+48*age*r/den**2+24**2*r*(1+r)/den**3)
        for rate,w in [(aa,wa),(bb,wb)]:
            rr=rate[:,None];delta=ka-rr;near=np.abs(delta)<1e-6
            safe=np.where(near,1,delta)
            ek=np.exp(-rr*age)/(-np.expm1(-24*rr))
            v=ka**2/safe**2*(ek-s0-safe*s1)
            v=np.where(near,ka**2*s2/2,v)
            out+=1000*amount/vc*w[:,None]*v
    return out

def transit2_mean(theta,t,sigma,dose=600,times=(0,),beta=1,nodes=24):
    x,w=hermgauss(nodes);return w@transit2_curve(theta,t,dose,times,np.sqrt(2)*sigma*x,beta)/np.sqrt(np.pi)

def fit_transit2(t,y,sigma,start=None):
    starts=[np.log([200,800,100,3000,1]),np.log([200,500,300,6000,1.5]),np.log([200,1200,300,3000,2])] if start is None else [start]
    rs=[least_squares(lambda a:np.log(np.maximum(transit2_mean(a,t,sigma),1e-12))-np.log(y),s,bounds=(np.log([5,30,1,50,.08]),np.log([3000,50000,5000,100000,15])),max_nfev=1200) for s in starts]
    return min(rs,key=lambda r:sum(r.fun*r.fun))
