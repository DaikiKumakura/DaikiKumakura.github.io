"""Digitized published aggregate PK: fit, held-out checks, conditional simulations."""
from pathlib import Path
import json,hashlib,platform
import numpy as np
import pandas as pd
import scipy
from scipy.stats import norm
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from model import fit,fit2,fit_transit2,mean_curve,mean_curve2,transit2_mean,transit2_curve

ROOT=Path(__file__).resolve().parents[1]
def quant(v):
    a=np.quantile(v,[.05,.5,.95]);return dict(p05=a[0],median=a[1],p95=a[2])
def metrics(theta,eta,dose,times,beta=1,step=.01):
    t=np.unique(np.r_[np.arange(0,24+step/2,step),times]);c=transit2_curve(theta,t,dose,times,eta,beta)
    auc=1000*600*(dose/600)**beta*len(times)/(np.exp(theta[0]+eta))
    return dict(cmax=c.max(1),cmin=c.min(1),auc24=auc)

def main():
    cfg=json.loads((ROOT/'analysis/inputs.json').read_text());o=ROOT/'outputs';tabs=o/'tables';figs=o/'figures';tabs.mkdir(parents=True,exist_ok=True);figs.mkdir(exist_ok=True)
    plt.rcParams.update({'font.family':'DejaVu Sans','font.size':11,'axes.spines.top':False,'axes.spines.right':False,'savefig.dpi':160})
    d=pd.read_csv(ROOT/'analysis/pk-pixels.csv');cal=cfg['pk_axis'];span=cal['y_log100']-cal['y_log1000']
    d['concentration']=10**(3-(d.pixel_y-cal['y_log1000'])/span);d.to_csv(tabs/'digitized-curves.csv',index=False)
    box=pd.read_csv(ROOT/'analysis/auc-box-pixels.csv');ca=cfg['auc_axis'];dd=ca['y_log1000']-ca['y_log10000']
    for key in ['q1','median','q3']:box[key]=10**(4-(box[key+'_y']-ca['y_log10000'])/dd)
    box['log_sd']=(np.log(box.q3)-np.log(box.q1))/(2*norm.ppf(.75));box.to_csv(tabs/'digitized-auc-boxes.csv',index=False)
    sigma=float(box.loc[box.group=='600QD','log_sd'].iloc[0]);train=d[d.group=='600QD'];tt=train.time_h.to_numpy();yy=train.concentration.to_numpy()
    fits=[('1comp-first',fit(tt,yy,sigma),mean_curve),('2comp-first',fit2(tt,yy,sigma),mean_curve2),('2comp-two-stage',fit_transit2(tt,yy,sigma),transit2_mean)]
    comparisons=[]
    for name,r,fun in fits:
        pred=fun(r.x,tt,sigma);comparisons.append(dict(model=name,log_rss=float(np.sum(np.log(pred/yy)**2)),max_relative_error=float(np.max(np.abs(pred/yy-1))),jacobian_condition=float(np.linalg.cond(r.jac))))
    pd.DataFrame(comparisons).to_csv(tabs/'model-comparison.csv',index=False)
    r=fits[-1][1];theta=r.x;assert r.success
    checks=[]
    for group,g in d.groupby('group',sort=False):
        dose=g.dose_mg.iloc[0];times=(0,12) if group=='300BID' else (0,)
        pred=transit2_mean(theta,g.time_h.to_numpy(),sigma,dose,times)
        for (_,row),value in zip(g.iterrows(),pred):checks.append(dict(group=group,time_h=row.time_h,observed_digitized=row.concentration,predicted=value,ratio=value/row.concentration,role=row.role))
    ck=pd.DataFrame(checks);ck.to_csv(tabs/'curve-checks.csv',index=False)
    direct=[]
    for group,g in d.groupby('group',sort=False):
        area=np.trapz(g.concentration,g.time_h);direct.append(dict(group=group,interval_h=g.interval_h.iloc[0],measured_window_h=g.time_h.max(),trapezoid_auc=area,displayed_max=g.concentration.max(),n_curve=g.n_curve.iloc[0]))
    pd.DataFrame(direct).to_csv(tabs/'observed-window-summaries.csv',index=False)
    rng=np.random.default_rng(cfg['seed']);z=rng.normal(size=cfg['n']);eta=sigma*z;ref=metrics(theta,eta,600,(0,));rows=[];ab=[]
    for name,reg in cfg['regimens'].items():
        m=metrics(theta,eta,reg['dose'],tuple(reg['times']))
        for key,v in m.items():
            rows.append(dict(regimen=name,metric=key,**quant(v/ref[key])));ab.append(dict(regimen=name,metric=key,**quant(v)))
    rr=pd.DataFrame(rows);rr.to_csv(tabs/'paired-regimen-ratios.csv',index=False);pd.DataFrame(ab).to_csv(tabs/'absolute-conditional-metrics.csv',index=False)
    sensitivity=[]
    for sig in [0,sigma,float(box.loc[box.group=='400QD','log_sd'].iloc[0])]:
        fit_s=fit_transit2(tt,yy,sig,start=theta);pp=fit_s.x;ref_s=metrics(pp,sig*z,600,(0,))
        for beta in [.5,1,1.5]:
            m=metrics(pp,sig*z,300,(0,12),beta)
            sensitivity.append(dict(log_sd=sig,dose_exponent=beta,**{key+'_ratio':float(np.median(v/ref_s[key])) for key,v in m.items()}))
    pd.DataFrame(sensitivity).to_csv(tabs/'structural-sensitivity.csv',index=False)
    jitter=[]
    for i in range(cfg['bootstrap']):
        pix=train.pixel_y.to_numpy()+rng.uniform(-cfg['pixel_jitter'],cfg['pixel_jitter'],len(train));yb=10**(3-(pix-cal['y_log1000'])/span)
        rb=fit_transit2(tt,yb,sigma,start=theta)
        if not rb.success:raise RuntimeError('Digitization sensitivity fit failed')
        m=metrics(rb.x,np.zeros(1),300,(0,12));re=metrics(rb.x,np.zeros(1),600,(0,))
        jitter.append(dict(iteration=i,cl=np.exp(rb.x[0]),vc=np.exp(rb.x[1]),q=np.exp(rb.x[2]),vp=np.exp(rb.x[3]),ka=np.exp(rb.x[4]),cmax_ratio=m['cmax'][0]/re['cmax'][0],cmin_ratio=m['cmin'][0]/re['cmin'][0]))
    pd.DataFrame(jitter).to_csv(tabs/'pixel-sensitivity.csv',index=False)
    model_auc=600000/np.exp(theta[0]);empmed=box.loc[box.group=='600QD','median'].iloc[0]
    benchmark=dict(conditional_auc_median=model_auc,conditional_auc_mean=model_auc*np.exp(sigma*sigma/2),digitized_auc_median=empmed,median_ratio=model_auc/empmed)
    grid=np.linspace(0,24,481);fig,axes=plt.subplots(1,2,figsize=(10,4),layout='constrained')
    for name,fr,fn in [fits[0],fits[-1]]:axes[0].plot(grid,fn(fr.x,grid,sigma),label=name)
    axes[0].scatter(tt,yy,c='black',s=22,label='600QD mean, digitized');axes[0].set(xlabel='Hours after dose',ylabel='Plasma concentration (ng/mL)',title='Fit to 600QD only');axes[0].legend(fontsize=8)
    for group,col in [('400QD','#009E73'),('750QD','#E69F00'),('300BID','#CC79A7')]:
        g=ck[ck.group==group];axes[1].scatter(g.time_h,g.observed_digitized,color=col,s=22)
        axes[1].plot(g.time_h,g.predicted,color=col,label=group+' prediction')
    axes[1].set(xlabel='Hours after dose',ylabel='Plasma concentration (ng/mL)',title='Held-out cohort checks (unpaired)');axes[1].legend(fontsize=8)
    fig.savefig(figs/'fit-and-heldout.png');plt.close(fig)
    fig,axes=plt.subplots(1,3,figsize=(11,4),layout='constrained');cols=['#D55E00','#009E73','#8a6996']
    for ax,key in zip(axes,['cmax','cmin','auc24']):
        for i,(name,col) in enumerate(zip(list(cfg['regimens'])[1:],cols)):
            row=rr[(rr.regimen==name)&(rr.metric==key)].iloc[0];ax.errorbar(i,row['median'],yerr=[[row['median']-row.p05],[row.p95-row['median']]],fmt='o',capsize=4,color=col)
        ax.axhline(1,color='.5',ls='--');ax.set_xticks(range(3),['300BID','300BID 8/16h','400QD'],rotation=25);ax.set(ylabel='Paired ratio vs 600QD',title=key,ylim=(0,None))
    fig.suptitle('Conditional predictions, n=2048; not clinically qualified BID results',fontsize=12);fig.savefig(figs/'conditional-regimens.png');plt.close(fig)
    fig,axes=plt.subplots(1,2,figsize=(10,4),layout='constrained')
    for key in ['cmax_ratio','cmin_ratio','auc24_ratio']:
        sub=pd.DataFrame(sensitivity);sub=sub[np.isclose(sub.log_sd,sigma)];axes[0].plot(sub.dose_exponent,sub[key],'o-',label=key)
    axes[0].axhline(1,color='.5',ls='--');axes[0].set(xlabel='Assumed per-dose exposure exponent',ylabel='Median ratio, 300BID / 600QD',title='Extrapolating below the fitted dose');axes[0].legend(fontsize=8)
    g=ck[ck.group=='300BID'];axes[1].scatter(g.time_h,g.observed_digitized,c='#CC79A7',label='300BID mean, n=3');axes[1].plot(g.time_h,g.predicted,c='#0072B2',label='Prediction from 600QD')
    axes[1].set(xlabel='Hours after BID dose',ylabel='Plasma concentration (ng/mL)',title='The actual BID peak is not reproduced');axes[1].legend(fontsize=8)
    fig.savefig(figs/'sensitivity-and-bid-check.png');plt.close(fig)
    result=dict(theta=theta.tolist(),parameters=dict(zip(['cl','vc','q','vp','ka'],np.exp(theta).tolist())),sigma=sigma,model_comparison=comparisons,benchmark=benchmark,paired=rows,checks=checks,direct=direct,jitter_iterations=cfg['bootstrap'])
    (o/'results.json').write_text(json.dumps(result,indent=2,default=lambda v:v.item())+'\n');(o/'environment.json').write_text(json.dumps(dict(python=platform.python_version(),numpy=np.__version__,pandas=pd.__version__,scipy=scipy.__version__,matplotlib=matplotlib.__version__),indent=2)+'\n')
    raw=ROOT/'data/raw'
    if raw.exists():(o/'source-hashes.json').write_text(json.dumps({f.name:hashlib.sha256(f.read_bytes()).hexdigest() for f in raw.glob('*') if f.suffix in ['.jpg','.pdf']},indent=2)+'\n')
    print('Parameters',result['parameters']);print(pd.DataFrame(comparisons).to_string(index=False));print(rr.to_string(index=False));print('Benchmark',benchmark);print(pd.DataFrame(sensitivity).to_string(index=False));print(pd.DataFrame(direct).to_string(index=False))

if __name__=='__main__':main()
