"""Independent matrix-exponential and mass-balance implementation checks."""
from pathlib import Path
import json,unittest
import numpy as np
from scipy.linalg import expm
from model import transit2_curve,transit2_mean
from run_analysis import metrics
ROOT=Path(__file__).resolve().parents[1]
TH=np.log([216.942215,741.995865,160.701893,2015.13762,.87053031])

def matrix_reference(theta,t,dose=600):
    cl,vc,q,vp,ka=np.exp(theta)
    mat=np.array([[-ka,0,0,0],[ka,-ka,0,0],[0,ka,-(cl+q)/vc,q/vp],[0,0,q/vc,-q/vp]])
    x=np.linalg.solve(np.eye(4)-expm(mat*24),np.array([dose,0,0,0]))
    return np.array([(expm(mat*float(at))@x)[2]*1000/vc for at in t])

class Tests(unittest.TestCase):
    def test_closed_form_independent_matrix(self):
        for delta in [-.5,0,.8]:
            p=TH.copy();p[0]+=delta;t=np.array([0,.5,1,2,4,8,12,24])
            np.testing.assert_allclose(transit2_curve(p,t)[0],matrix_reference(p,t),rtol=1e-8,atol=1e-7)

    def test_coincident_absorption_distribution_rate(self):
        p=TH.copy();_,vc,q,vp,ka=np.exp(p);k12=q/vc;k21=q/vp
        k10=(ka*ka-ka*(k12+k21))/(ka-k21);p[0]=np.log(k10*vc)
        t=np.linspace(0,24,49)
        np.testing.assert_allclose(transit2_curve(p,t)[0],matrix_reference(p,t),rtol=1e-7,atol=1e-7)

    def test_numerical_auc(self):
        t=np.linspace(0,24,24001)
        for dose,times in [(600,(0,)),(300,(0,12)),(300,(0,8))]:
            a=np.trapz(transit2_curve(TH,t,dose,times)[0],t)
            self.assertAlmostEqual(a,1000*dose*len(times)/np.exp(TH[0]),places=3)

    def test_hermite_accuracy(self):
        t=np.linspace(0,24,49)
        for sig in [0,.554229482,.80776]:
            a=transit2_mean(TH,t,sig,nodes=24);b=transit2_mean(TH,t,sig,nodes=64)
            np.testing.assert_allclose(a,b,rtol=.0001)

    def test_paired_auc_and_power(self):
        eta=np.random.default_rng(18).normal(0,.55,30);base=metrics(TH,eta,600,(0,))
        for beta in [.5,1,1.5]:
            alt=metrics(TH,eta,300,(0,12),beta)
            np.testing.assert_allclose(alt['auc24']/base['auc24'],2**(1-beta),rtol=1e-12)

    def test_fine_grid(self):
        eta=np.random.default_rng(21).normal(0,.55,25)
        for dose,times in [(600,(0,)),(300,(0,12)),(300,(0,8))]:
            a=metrics(TH,eta,dose,times);b=metrics(TH,eta,dose,times,step=.0025)
            for k in ['cmax','cmin']:np.testing.assert_allclose(a[k],b[k],rtol=.0002)

    def test_zero_variance_and_periodicity(self):
        t=np.array([0,1,2,8,12])
        np.testing.assert_allclose(transit2_mean(TH,t,0),transit2_curve(TH,t)[0],rtol=1e-12)
        np.testing.assert_allclose(transit2_curve(TH,t),transit2_curve(TH,t+24),rtol=1e-12)

    def test_axis_anchors_and_source_roles(self):
        c=json.loads((ROOT/'analysis/inputs.json').read_text());a=c['pk_axis'];span=a['y_log100']-a['y_log1000']
        self.assertEqual(10**(3-(a['y_log1000']-a['y_log1000'])/span),1000)
        self.assertEqual(10**(3-(a['y_log100']-a['y_log1000'])/span),100)
        import pandas as pd
        d=pd.read_csv(ROOT/'analysis/pk-pixels.csv');self.assertEqual(set(d[d.role=='fit'].group),{'600QD'})

if __name__=='__main__':unittest.main()
