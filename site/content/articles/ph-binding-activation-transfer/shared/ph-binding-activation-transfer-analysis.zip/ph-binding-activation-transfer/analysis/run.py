"""Test a prespecified parent-calibrated EC50 transfer rule on held-out variants."""
from pathlib import Path
import csv
import json
import hashlib
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

ROOT=Path(__file__).resolve().parents[1]
# Exact transcription of the numeric EC50 tables embedded in source Figure 10.
# No numeric value is read from a fitted curve; all inputs are source-fit summaries.
BINDING={'Parental':{6.5:.078,7.4:.106},'Q90LE':{6.5:.17,7.4:136.64},'T89LD':{6.5:1.96,7.4:103.74}}
ACTIVATION={
 'D1':{'Parental':{6.5:6.31,7.4:10.42},'Q90LE':{6.5:20.07,7.4:227.82},'T89LD':{6.5:33.94,7.4:300.19}},
 'D2':{'Parental':{6.5:7.03,7.4:8.15},'Q90LE':{6.5:17.82,7.4:230.85},'T89LD':{6.5:30.82,7.4:230.65}}
}


def predict(binding_variant: float,binding_parent: float,activation_parent: float) -> float:
    """Fixed unit log-slope; only the parent's scaling factor is calibrated."""
    assert min(binding_variant,binding_parent,activation_parent)>0
    return binding_variant/binding_parent*activation_parent


def write_csv(path: Path,rows: list[dict]):
    with path.open('w',newline='',encoding='utf8') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)


def save(fig,name):
    fig.tight_layout();fig.savefig(ROOT/f'outputs/figures/{name}.svg');fig.savefig(ROOT/f'outputs/figures/{name}.png',dpi=170);plt.close(fig)


def main():
    for d in ['data/processed','outputs/figures','outputs/tables']:(ROOT/d).mkdir(parents=True,exist_ok=True)
    source=[];cal=[];pred=[];folds=[];metrics=[]
    for donor,clones in ACTIVATION.items():
        for clone,phs in clones.items():
            for ph,a in phs.items():source.append(dict(donor=donor,clone=clone,ph=ph,binding_ec50_nm=BINDING[clone][ph],activation_ec50_nm=a,role='calibration_parent' if clone=='Parental' else 'heldout_variant'))
        for ph in [6.5,7.4]:
            factor=clones['Parental'][ph]/BINDING['Parental'][ph]
            cal.append(dict(donor=donor,ph=ph,activation_to_binding_ec50_factor=factor,log_intercept=float(np.log(factor)),n_parental_anchor=1))
        for clone in ['Q90LE','T89LD']:
            pp={}
            for ph in [6.5,7.4]:
                a=clones[clone][ph];p=predict(BINDING[clone][ph],BINDING['Parental'][ph],clones['Parental'][ph]);pp[ph]=p
                base=clones['Parental'][ph]
                pred.append(dict(donor=donor,clone=clone,ph=ph,observed_activation_ec50_nm=a,predicted_activation_ec50_nm=p,prediction_over_observed=p/a,
                                 parent_only_baseline_nm=base,transfer_log_error=float(np.log(p/a)),baseline_log_error=float(np.log(base/a))))
            folds.append(dict(donor=donor,clone=clone,binding_selectivity=BINDING[clone][7.4]/BINDING[clone][6.5],
                              observed_activation_selectivity=clones[clone][7.4]/clones[clone][6.5],predicted_activation_selectivity=pp[7.4]/pp[6.5],
                              selectivity_prediction_over_observed=(pp[7.4]/pp[6.5])/(clones[clone][7.4]/clones[clone][6.5])))
        rr=[r for r in pred if r['donor']==donor]
        for method,key in [('Parent-calibrated binding transfer','transfer_log_error'),('Parent-only baseline','baseline_log_error')]:
            logs=np.array([r[key] for r in rr]);metrics.append(dict(donor=donor,method=method,n_heldout_variant_ph_summaries=len(logs),log_rmse=float(np.sqrt(np.mean(logs**2))),geometric_mean_absolute_fold_error=float(np.exp(np.mean(abs(logs))))))
    write_csv(ROOT/'data/processed/source-ec50.csv',source);write_csv(ROOT/'outputs/tables/calibration.csv',cal)
    write_csv(ROOT/'outputs/tables/heldout-variants.csv',pred);write_csv(ROOT/'outputs/tables/selectivity.csv',folds);write_csv(ROOT/'outputs/tables/comparison.csv',metrics)
    plt.rcParams.update({'font.size':10,'svg.fonttype':'none'})
    fig,axes=plt.subplots(1,2,figsize=(9,3.8),sharex=True,sharey=True)
    for ax,donor in zip(axes,ACTIVATION):
        for clone,marker in [('Q90LE','o'),('T89LD','s')]:
            for ph,color in [(6.5,'#D55E00'),(7.4,'#0072B2')]:
                r=next(r for r in pred if r['donor']==donor and r['clone']==clone and r['ph']==ph)
                ax.scatter(r['observed_activation_ec50_nm'],r['predicted_activation_ec50_nm'],marker=marker,color=color,s=65,label=f'{clone}, pH {ph}')
        ax.plot([5,20000],[5,20000],'k--');ax.set(xscale='log',yscale='log',xlim=(5,20000),ylim=(5,20000),xlabel='Published activation EC50 (nM)',title=donor)
        ax.grid(alpha=.2)
    axes[0].set_ylabel('Parent-calibrated prediction (nM)');axes[1].legend(frameon=False,fontsize=7)
    fig.suptitle('Bivalent anti-CD3; variant activation EC50s excluded from calibration');save(fig,'transfer-prediction')
    fig,axes=plt.subplots(1,2,figsize=(9,3.6),sharey=True)
    for ax,donor in zip(axes,ACTIVATION):
        rr=[r for r in folds if r['donor']==donor];xx=np.arange(2)
        for offset,key,color,label in [(-.23,'binding_selectivity','#777777','Binding'),(0,'observed_activation_selectivity','#009E73','Published activation'),(.23,'predicted_activation_selectivity','#0072B2','Transferred prediction')]:
            ax.scatter(xx+offset,[r[key] for r in rr],color=color,label=label,s=55,marker={'binding_selectivity':'o','observed_activation_selectivity':'s','predicted_activation_selectivity':'^'}[key])
        ax.set(yscale='log',xticks=xx,xticklabels=['Q90LE','T89LD'],title=donor);ax.legend(frameon=False,fontsize=7)
    axes[0].set_ylabel('EC50 at pH 7.4 / EC50 at pH 6.5');fig.suptitle('Binding and activation selectivity at pH 6.5 and 7.4');save(fig,'selectivity-transfer')
    fig,ax=plt.subplots(figsize=(6.8,3.7))
    for i,donor in enumerate(ACTIVATION):
        rr=[r for r in metrics if r['donor']==donor]
        ax.bar(i-.16,rr[0]['log_rmse'],.30,color='#0072B2',label='Binding transfer' if i==0 else '')
        ax.bar(i+.16,rr[1]['log_rmse'],.30,color='#E69F00',label='Parent-only baseline' if i==0 else '')
    ax.set(xticks=[0,1],xticklabels=['D1','D2'],ylabel='Held-out EC50 root mean squared log error');ax.set_ylim(0,3.5);ax.legend(frameon=False);save(fig,'prediction-errors')
    # Recalculate from printed EC50s. The original Q90LE fold is based on greater
    # unprinted precision; preserve the discrepancy instead of silently replacing it.
    rounding=[];rng=np.random.default_rng(20261028)
    for donor,clones in ACTIVATION.items():
        err=[]
        for _ in range(2000):
            b={clone:{ph:v+rng.uniform(-(.005 if clone!='Parental' else .0005),(.005 if clone!='Parental' else .0005)) for ph,v in phs.items()} for clone,phs in BINDING.items()}
            a={clone:{ph:v+rng.uniform(-.005,.005) for ph,v in phs.items()} for clone,phs in clones.items()}
            err.append(predict(b['Q90LE'][7.4],b['Parental'][7.4],a['Parental'][7.4])/a['Q90LE'][7.4])
        rounding.append(dict(donor=donor,min_neutral_Q90LE_prediction_ratio=float(min(err)),max_neutral_Q90LE_prediction_ratio=float(max(err)),scenario='half-last-printed-decimal input perturbation; not confidence interval'))
    write_csv(ROOT/'outputs/tables/rounding-sensitivity.csv',rounding)
    result={'id':'STCE-21','n_primary_donors':2,'n_binding_curves':6,'n_activation_curves':12,'n_parent_anchors':4,'n_heldout_variant_ph_donor_summaries':8,
            'calibration':cal,'predictions':pred,'selectivity':folds,'metrics':metrics,'source_sha256':hashlib.sha256((ROOT/'data/raw/figure10.jpg').read_bytes()).hexdigest()}
    result['rounding_sensitivity']=rounding
    result['source_printed_binding_folds']={'Parental':1.36,'Q90LE':789.83,'T89LD':52.93}
    (ROOT/'outputs/results.json').write_text(json.dumps(result,indent=2),encoding='utf8');print(json.dumps(result,indent=2))


if __name__=='__main__':main()
