import importlib.util
from pathlib import Path
import unittest

ROOT=Path(__file__).resolve().parents[1]
spec=importlib.util.spec_from_file_location('analysis',ROOT/'analysis/run.py')
m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)


class AnalysisTests(unittest.TestCase):
    def test_parent_anchor_is_reproduced(self):
        for donor,clones in m.ACTIVATION.items():
            for ph in [6.5,7.4]:
                b=m.BINDING['Parental'][ph];a=clones['Parental'][ph]
                self.assertAlmostEqual(m.predict(b,b,a),a)

    def test_units_rescale_correctly(self):
        self.assertAlmostEqual(m.predict(.17,.078,6.31),m.predict(170,78,6.31))

    def test_invalid_nonpositive_input_is_rejected(self):
        with self.assertRaises(AssertionError):m.predict(.1,0,2)

    def test_heldout_activation_is_not_a_predictor(self):
        b=m.BINDING['Q90LE'][7.4];parent_b=m.BINDING['Parental'][7.4];parent_a=m.ACTIVATION['D1']['Parental'][7.4]
        before=m.predict(b,parent_b,parent_a)
        original=m.ACTIVATION['D1']['Q90LE'][7.4]
        try:
            m.ACTIVATION['D1']['Q90LE'][7.4]=1e8
            self.assertAlmostEqual(before,m.predict(b,parent_b,parent_a))
        finally:m.ACTIVATION['D1']['Q90LE'][7.4]=original


if __name__=='__main__':unittest.main()
