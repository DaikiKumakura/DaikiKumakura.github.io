# Parent-calibrated binding-to-activation EC50 transfer

Independent reanalysis of Figure 10 EC50 summary tables from La Sala et al., mAbs (2026), DOI:10.1080/19420862.2026.2658902. Source figure: CC BY-NC 4.0. Attribution, public URL and SHA-256 are recorded in source-provenance.json. The source image and full article are not included in the companion.

Use the scientific packages in requirements.txt in an existing environment. From this directory:

```sh
python analysis/download_sources.py
python analysis/run.py
python -m unittest discover -s tests
```

Inputs are printed, source-fitted EC50 summaries, not raw observations. The parent supplies one anchor per donor and pH; the log-scale slope is fixed at one, not estimated. Eight engineered-variant activation EC50 summaries are excluded from calibration. Two primary donors are biological units; technical duplicates are not extra donors.

The binding assay is soluble-antibody Jurkat binding at 4 C. Activation uses plate-coated antibody and 48-h CD69 on primary CD4 T cells. Activation concentrations denote coating concentrations, not free in-culture drug exposure. Same bivalent format only; monovalent Figure 11 and pH 6.0 SPR are not pooled.

EC50 is relative to each curve's own dynamic range. Predictions do not represent a common absolute CD69 threshold, tumor killing, clinical concentrations, continuous-pH kinetics, or a clinical safety window. Rounding scenarios are not biological confidence intervals. The mismatch is already reported by the original authors; this work tests a specific fixed transfer rule rather than claiming a new biological finding.
