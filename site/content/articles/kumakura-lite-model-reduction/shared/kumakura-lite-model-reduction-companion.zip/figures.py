"""Figures generated from code.  Run after experiments.py:  python -X utf8 figures.py
Image text is English (site rule).  Okabe-Ito colours; line styles differ as well."""
from __future__ import annotations

from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

import experiments as ex
import kl_models as km

HERE = Path(__file__).parent
RES, FIG = HERE / "results", HERE / "figures"
FIG.mkdir(exist_ok=True)
C = dict(blue="#0072B2", orange="#E69F00", green="#009E73", red="#D55E00", purple="#CC79A7", sky="#56B4E9",
         black="#000000", grey="#7f7f7f")
plt.rcParams.update({"font.size": 9, "axes.spines.top": False, "axes.spines.right": False,
                     "figure.dpi": 150, "savefig.bbox": "tight"})


def save(fig, name):
    fig.savefig(FIG / f"{name}.png")
    plt.close(fig)


def fig1_relations():
    fig, ax = plt.subplots(figsize=(7.2, 3.6))
    ax.axis("off")
    boxes = {
        "orig": (0.50, 0.88, "Original model\n(N, R, M)", C["black"]),
        "S": (0.12, 0.45, "Lite-S\n(N, R), exact\nc = 0, equal yields", C["blue"]),
        "Q": (0.38, 0.45, "Lite-Q\n(N, R), asymptotic\nfast M relaxation", C["green"]),
        "W": (0.64, 0.45, "Lite-W\n(N, R), asymptotic\nweak M feedback", C["orange"]),
        "M": (0.90, 0.45, "Lite-M\n(N, R), new law\nnot a reduction", C["red"]),
        "L": (0.12, 0.05, "Logistic\n(N), exact limit\nh→0, d=0, K→∞", C["purple"]),
        "T": (0.88, 0.88, "N-clock form\n(R, M) closed;\nN by linear quadrature", C["grey"]),
    }
    for k, (x, y, txt, col) in boxes.items():
        ax.text(x, y, txt, ha="center", va="center", color=col, fontsize=8,
                bbox=dict(boxstyle="round,pad=0.4", fc="white", ec=col, lw=1.6))
    arrows = [("orig", "S", "-"), ("orig", "Q", "--"), ("orig", "W", "--"), ("S", "L", "-"), ("orig", "T", "-")]
    for a, b, ls in arrows:
        xa, ya, *_ = boxes[a]
        xb, yb, *_ = boxes[b]
        if b == "T":
            ax.annotate("", xy=(xb - 0.12, yb), xytext=(xa + 0.1, ya), arrowprops=dict(arrowstyle="->", lw=1.3, color="#444"))
            continue
        ax.annotate("", xy=(xb, yb + 0.14 if yb > 0.2 else yb + 0.13), xytext=(xa, ya - 0.12),
                    arrowprops=dict(arrowstyle="->", ls=ls, lw=1.3, color="#444"))
    ax.annotate("", xy=(0.80, 0.45), xytext=(0.74, 0.45), arrowprops=dict(arrowstyle="<-", ls=":", color=C["red"]))
    ax.text(0.5, -0.08, "solid arrow: exact; dashed: asymptotic approximation; dotted: mechanistic reformulation",
            ha="center", fontsize=7.5)
    save(fig, "fig1_model_relations")


def fig2_lite_s():
    P = km.with_params(b1=0.01, c=0.0, a2=0.01, b2=0.005)
    Y0 = dict(km.REFERENCE_Y0)
    T = ex.horizon(P, Y0)
    t, yo = ex.run("original", P, Y0, T)
    _, ys = ex.run("lite_s", P, Y0, T)
    Ms = km.M_from_R_lite_s(ys[1], P, Y0)
    fig, ax = plt.subplots(1, 3, figsize=(7.4, 2.5))
    for a, (i, nm, col) in zip(ax[:2], [(0, "N", C["blue"]), (1, "R", C["orange"])]):
        a.plot(t, yo[i], color=col, lw=2.2, label="Original")
        a.plot(t, ys[i], color="k", ls="--", lw=1.1, label="Lite-S")
        a.set_xlabel("time (h)"); a.set_ylabel(f"{nm} (model units)")
    ax[0].plot(t, yo[2], color=C["green"], lw=2.2, label="M, original")
    ax[0].plot(t, Ms, color="k", ls=":", lw=1.4, label="M, Lite-S")
    ax[0].legend(frameon=False, fontsize=6.5)
    err = np.abs(yo[0] - ys[0]) / yo[0].max()
    err = np.maximum(err, 1e-17)
    ax[2].semilogy(t, err, color=C["blue"], label="|ΔN|/N_max")
    ax[2].semilogy(t, np.maximum(np.abs(yo[2] - Ms) / yo[2].max(), 1e-17), color=C["green"], ls="--", label="|ΔM|/M_max")
    cons = np.maximum(np.abs(yo[2] + 0.5 * yo[1] - 0.5 * Y0["R"]), 1e-17)
    ax[2].semilogy(t, cons, color=C["grey"], ls=":", label="|M+νR−const|")
    ax[2].set_xlabel("time (h)"); ax[2].set_ylabel("error"); ax[2].legend(frameon=False, fontsize=6.5)
    fig.tight_layout()
    save(fig, "fig2_lite_s_exact")


def fig3_lite_q():
    df = pd.read_csv(RES / "exp2_qssa_scaling.csv")
    fig, ax = plt.subplots(1, 3, figsize=(7.6, 2.6))
    # (a) slow manifold in phase plane
    base = km.with_params(a1=0.02, b1=0.01, a2=0.01, b2=0.005, c=0.05)
    Rg = np.linspace(0, 10, 200)
    for s, col in [(1, C["orange"]), (10, C["green"]), (100, C["blue"])]:
        P = km.with_params(base, a2=base["a2"] * s, b2=base["b2"] * s, c=base["c"] * s)
        Y0 = dict(km.REFERENCE_Y0)
        T = ex.horizon(P, Y0)
        t, y = ex.run("original", P, Y0, T)
        ax[0].plot(y[1], y[2], color=col, lw=1.5, label=f"s = {s}")
    ax[0].plot(Rg, km.M_star(Rg, base), color="k", ls="--", lw=1, label="M*(R)")
    ax[0].set_xlabel("R"); ax[0].set_ylabel("M"); ax[0].legend(frameon=False, fontsize=6.5)
    # (b) error vs eps
    for start, mk in [("M0=M*(R0)", "o"), ("M0=0", "s")]:
        d = df[df.start == start]
        ax[1].loglog(d.eps, d.lite_q_err_N, marker=mk, ms=3, color=C["blue"], ls="-" if mk == "o" else "--",
                     label=f"Q0, {start}")
        ax[1].loglog(d.eps, d.lite_q1_err_N, marker=mk, ms=3, color=C["red"], ls="-" if mk == "o" else "--",
                     label=f"Q1, {start}")
    e = np.array([1e-3, 1e-1]); ax[1].loglog(e, 0.6 * e, color="k", lw=0.6, ls=":"); ax[1].loglog(e, 2 * e**2, color="k", lw=0.6, ls=":")
    ax[1].set_xlabel("ε (time-scale ratio)"); ax[1].set_ylabel("max |ΔN| / N_max"); ax[1].legend(frameon=False, fontsize=5.8)
    # (c) N0 independence
    d2 = pd.read_csv(RES / "exp2_N0_independence.csv")
    ax[2].loglog(d2.N0, d2.phase_err_q0, "o-", color=C["blue"], label="phase-plane error N(R)")
    ax[2].loglog(d2.N0, d2.time_err_q0, "s--", color=C["red"], label="time-domain error N(t)")
    ax[2].set_xlabel("N(0)"); ax[2].set_ylabel("relative error (s = 30, M(0) = 0)"); ax[2].legend(frameon=False, fontsize=6.5)
    fig.tight_layout()
    save(fig, "fig3_lite_q")


def fig4_growth_laws():
    R = np.geomspace(1e-3, 1e3, 400)
    h, Km, mu_a1 = 1.0, 2.0, 1.0
    lw = mu_a1 * R**2 / (R + h)
    mon = R / (Km + R)
    liteM = km.g_lite_m(R, dict(km.LITE_M_DEFAULT, h=h, Km=Km, Y=1.0, vmax=1.0))
    lin = mu_a1 * R
    fig, ax = plt.subplots(1, 2, figsize=(7.0, 2.8))
    ax[0].loglog(R, lin, color=C["grey"], ls=":", label="Linear (original at M=0, h→0)")
    ax[0].loglog(R, lw, color=C["orange"], label="Lite-W: R²/(R+h)")
    ax[0].loglog(R, mon, color=C["blue"], ls="--", label="Monod: R/(Km+R)")
    ax[0].loglog(R, liteM, color=C["red"], lw=2, label="Lite-M: R²/((Km+R)(h+R))")
    ax[0].set_xlabel("R (concentration units)"); ax[0].set_ylabel("g(R) (rate units, scaled)")
    ax[0].set_ylim(1e-7, 1e3); ax[0].legend(frameon=False, fontsize=6.3)
    # local slope d ln g / d ln R
    for g, col, ls in [(lw, C["orange"], "-"), (mon, C["blue"], "--"), (liteM, C["red"], "-")]:
        ax[1].semilogx(R[1:-1], np.diff(np.log(g))[1:] / np.diff(np.log(R))[1:], color=col, ls=ls)
    ax[1].axhline(2, color="k", lw=0.5, ls=":"); ax[1].axhline(1, color="k", lw=0.5, ls=":"); ax[1].axhline(0, color="k", lw=0.5, ls=":")
    ax[1].set_xlabel("R"); ax[1].set_ylabel("local exponent d ln g / d ln R")
    fig.tight_layout()
    save(fig, "fig5_growth_laws")


def fig5_phase_map():
    df = pd.read_csv(RES / "exp3_weak_feedback_grid.csv")
    fig, ax = plt.subplots(1, 2, figsize=(7.0, 2.8))
    piv = df.pivot(index="f", columns="nu", values="err_N")
    im = ax[0].imshow(np.log10(piv.values), origin="lower", aspect="auto", cmap="viridis")
    ax[0].set_xticks(range(len(piv.columns))); ax[0].set_xticklabels([f"{v:.3g}" for v in piv.columns], rotation=60, fontsize=6)
    ax[0].set_yticks(range(len(piv.index))); ax[0].set_yticklabels([f"{v:g}" for v in piv.index], fontsize=6)
    ax[0].set_xlabel("ν = a2/a1 = b2/b1"); ax[0].set_ylabel("f")
    fig.colorbar(im, ax=ax[0], label="log10 max|ΔN|/N_max")
    d0 = df[df.f == 0.0]
    ax[1].loglog(d0.zeta_max, d0.err_N, "o-", color=C["orange"], label="f = 0")
    d1 = df[df.f == 1.0]
    ax[1].loglog(d1.zeta_max, d1.err_N, "s--", color=C["red"], label="f = 1")
    ax[1].set_xlabel("ζ = max M/(R+h)"); ax[1].set_ylabel("max |ΔN| / N_max"); ax[1].legend(frameon=False, fontsize=7)
    fig.tight_layout()
    save(fig, "fig4_weak_feedback_map")


if __name__ == "__main__":
    for f in [fig1_relations, fig2_lite_s, fig3_lite_q, fig4_growth_laws, fig5_phase_map]:
        f()
        print("done", f.__name__)
