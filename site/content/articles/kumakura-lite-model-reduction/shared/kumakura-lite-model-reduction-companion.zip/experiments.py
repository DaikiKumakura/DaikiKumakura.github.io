"""Numerical experiments 1-3 and 7 (theory-only; no empirical data).

Run:  python -X utf8 experiments.py [exp1 exp2 exp3 exp7 gronwall]
Outputs CSVs to results/.  All parameter values are the REFERENCE set in kl_models.py
unless stated; they are verification parameters, not fitted values.
"""
from __future__ import annotations

import sys
import time
from pathlib import Path

import numpy as np
import pandas as pd
from scipy.integrate import solve_ivp

import kl_models as km

OUT = Path(__file__).parent / "results"
OUT.mkdir(exist_ok=True)
RTOL, ATOL = 1e-11, 1e-14
NGRID = 4001


def horizon(P, Y0, frac=1e-4, tmax=2000.0):
    """Time when R has fallen to frac*R0 in the original model (or tmax)."""
    ev = lambda t, y: y[1] - frac * Y0["R"]
    ev.terminal = True
    sol = solve_ivp(lambda t, y: km.rhs_original(t, y, P), (0, tmax), [Y0["N"], Y0["R"], Y0["M"]],
                    method="LSODA", rtol=RTOL, atol=ATOL, events=ev)
    return float(sol.t[-1])


def run(model, P, Y0, T, **kw):
    t_eval = np.linspace(0.0, T, NGRID)
    s = km.integrate(model, P, Y0, T, t_eval=t_eval, rtol=RTOL, atol=ATOL, **kw)
    if not s.success:
        raise RuntimeError(f"{model} failed: {s.message}")
    return s.t, s.y


def features(t, N):
    """Final/peak density and time to 50% of the peak (linear interpolation)."""
    Nmax = float(N.max())
    i = int(np.argmax(N >= 0.5 * Nmax))
    t50 = float(np.interp(0.5 * Nmax, N[i - 1:i + 1], t[i - 1:i + 1])) if i > 0 else float("nan")
    return Nmax, t50


def errs(y_ref, y):
    """Relative sup errors for rows present in both (N, R[, M])."""
    out = {}
    for k, name in enumerate(["N", "R", "M"][: min(len(y_ref), len(y))]):
        sc = max(np.max(np.abs(y_ref[k])), 1e-300)
        out[f"err_{name}"] = float(np.max(np.abs(y_ref[k] - y[k])) / sc)
    return out


# ---------------------------------------------------------------------------------------
def exp1_exact_reduction():
    """Lite-S vs original under c=0, a2/a1=b2/b1; conservation; tolerance convergence; yield mismatch."""
    rows = []
    P = km.with_params(b1=0.01, c=0.0, a2=0.01, b2=0.005)  # nu = a2/a1 = b2/b1 = 0.5
    Y0 = dict(km.REFERENCE_Y0)
    ok, nug, nud = km.lite_s_conditions(P)
    assert ok, (nug, nud)
    T = horizon(P, Y0)
    t, yo = run("original", P, Y0, T)
    _, ys = run("lite_s", P, Y0, T)
    Ms = km.M_from_R_lite_s(ys[1], P, Y0)
    e = errs(yo, np.vstack([ys, Ms]))
    cons = yo[2] + nug * yo[1]
    rows.append(dict(case="exact (c=0, equal yields)", T=T, **e,
                     conservation_drift=float(np.max(np.abs(cons - cons[0])))))
    # tolerance convergence: compare against a tight reference with the same solver
    ref = solve_ivp(lambda tt, y: km.rhs_original(tt, y, P), (0, T), [Y0["N"], Y0["R"], Y0["M"]],
                    method="DOP853", t_eval=t, rtol=1e-13, atol=1e-16).y
    conv = []
    for tol in [1e-4, 1e-6, 1e-8, 1e-10, 1e-12]:
        sol = solve_ivp(lambda tt, y: km.rhs_original(tt, y, P), (0, T), [Y0["N"], Y0["R"], Y0["M"]],
                        method="DOP853", t_eval=t, rtol=tol, atol=tol * 1e-3).y
        sl = solve_ivp(lambda tt, y: km.rhs_lite_s(tt, y, P, Y0), (0, T), [Y0["N"], Y0["R"]],
                       method="DOP853", t_eval=t, rtol=tol, atol=tol * 1e-3).y
        e_self = float(np.max(np.abs(sol[0] - ref[0])) / ref[0].max())
        e_mod = float(np.max(np.abs(sl[0] - ref[0])) / ref[0].max())
        conv.append(dict(rtol=tol, err_original_vs_tight=e_self, err_liteS_vs_original_tight=e_mod))
    pd.DataFrame(conv).to_csv(OUT / "exp1_tolerance_convergence.csv", index=False)

    # mismatch of yields: error of Lite-S (nu := a2/a1) and of the corrected bookkeeping
    mm = []
    for ratio in [1.0, 0.9, 0.75, 0.5, 0.25, 0.0]:
        Pm = km.with_params(P, b2=P["b1"] * nug * ratio)
        Tm = horizon(Pm, Y0)
        tm, yom = run("original", Pm, Y0, Tm)
        _, ysm = run("lite_s", Pm, Y0, Tm)  # uses nu = a2/a1
        Msm = km.M_from_R_lite_s(ysm[1], Pm, Y0)
        # exact corrected M: M = M0 + nu_D (R0-R) + (nu_G-nu_D) * int U_G dt   (c = 0)
        nuD = Pm["b2"] / Pm["b1"]
        UG = Pm["a1"] * yom[1] * yom[0] * yom[1] / (yom[1] + yom[2] + Pm["h"])
        from scipy.integrate import cumulative_trapezoid
        intUG = cumulative_trapezoid(UG, tm, initial=0.0)
        Mcorr = Y0["M"] + nuD * (Y0["R"] - yom[1]) + (nug - nuD) * intUG
        mm.append(dict(nuD_over_nuG=ratio, err_N_liteS=errs(yom, np.vstack([ysm, Msm]))["err_N"],
                       err_M_liteS=errs(yom, np.vstack([ysm, Msm]))["err_M"],
                       err_M_corrected_bookkeeping=float(np.max(np.abs(yom[2] - Mcorr)) / np.max(yom[2]))))
    pd.DataFrame(mm).to_csv(OUT / "exp1_yield_mismatch.csv", index=False)

    # c>0: monotone balance M + nu R is non-increasing and M <= M0 + nu (R0 - R)
    Pc = km.with_params(P, c=0.05)
    Tc = horizon(Pc, Y0)
    tc, yc = run("original", Pc, Y0, Tc)
    bal = yc[2] + nug * yc[1]
    dec = float(np.max(np.diff(bal)))
    bound_viol = float(np.max(yc[2] - (Y0["M"] + nug * (Y0["R"] - yc[1]))))
    rows.append(dict(case="c=0.05: balance M+nuR monotone", T=Tc, max_increment_of_balance=dec,
                     max_violation_of_upper_bound=bound_viol))
    pd.DataFrame(rows).to_csv(OUT / "exp1_summary.csv", index=False)
    return rows


# ---------------------------------------------------------------------------------------
def eps_Q(P, R0, n=400):
    """Time-scale ratio: max over R in [1e-2 R0, R0] of |dR/dtau|/(R * gamma_tau)."""
    R = np.geomspace(1e-2 * R0, R0, n)
    Ms = km.M_star(R, P)
    return float(np.max(np.abs(km.F_R(R, Ms, P)) / (R * km.gamma_M_per_cell(R, P))))


def exp2_qssa():
    """Scale (a2,b2,c) by s: M* is invariant, relaxation rate scales with s."""
    base = km.with_params(a1=0.02, b1=0.01, a2=0.01, b2=0.005, c=0.05)
    rows = []
    for start in ["M0=0", "M0=M*(R0)"]:
        for N0 in [0.01]:
            for s in np.geomspace(0.1, 1000, 15):
                P = km.with_params(base, a2=base["a2"] * s, b2=base["b2"] * s, c=base["c"] * s)
                Y0 = dict(N=N0, R=10.0, M=0.0 if start == "M0=0" else float(km.M_star(10.0, P)))
                T = horizon(P, Y0)
                t, yo = run("original", P, Y0, T)
                Nmax_o, t50_o = features(t, yo[0])
                row = dict(start=start, s=s, N0=N0, eps=eps_Q(P, Y0["R"]), T=T)
                for m in ["lite_q", "lite_q1"]:
                    _, yq = run(m, P, Y0, T)
                    Mq = km.M_recon_lite_q(yq[1], P, order=1 if m == "lite_q1" else 0)
                    e = errs(yo, np.vstack([yq, Mq]))
                    Nq, t50q = features(t, yq[0])
                    for k, v in e.items():
                        row[f"{m}_{k}"] = v
                    row[f"{m}_Nmax_relerr"] = abs(Nq - Nmax_o) / Nmax_o
                    row[f"{m}_t50_relerr"] = abs(t50q - t50_o) / t50_o
                rows.append(row)
    df = pd.DataFrame(rows)
    df.to_csv(OUT / "exp2_qssa_scaling.csv", index=False)

    # independence from N0: error along the (R, N) phase curve
    rows2 = []
    s = 30.0
    P = km.with_params(base, a2=base["a2"] * s, b2=base["b2"] * s, c=base["c"] * s)
    for N0 in [1e-4, 1e-3, 1e-2, 1e-1, 1.0]:
        Y0 = dict(N=N0, R=10.0, M=0.0)
        T = horizon(P, Y0)
        t, yo = run("original", P, Y0, T)
        _, yq = run("lite_q", P, Y0, T)
        _, yq1 = run("lite_q1", P, Y0, T)
        # phase-plane comparison: N as a function of R (R is monotone decreasing)
        Rg = np.geomspace(0.05, 9.99, 300)
        No = np.interp(-Rg, -yo[1], yo[0])
        Nq = np.interp(-Rg, -yq[1], yq[0])
        Nq1 = np.interp(-Rg, -yq1[1], yq1[0])
        t50o = features(t, yo[0])[1]; t50q = features(t, yq[0])[1]
        rows2.append(dict(N0=N0, T=T, t50_original=t50o, t50_liteq=t50q, t50_shift=t50q - t50o,
                          phase_err_q0=float(np.max(np.abs(No - Nq)) / No.max()),
                          phase_err_q1=float(np.max(np.abs(No - Nq1)) / No.max()),
                          time_err_q0=errs(yo, yq)["err_N"], time_err_q1=errs(yo, yq1)["err_N"]))
    pd.DataFrame(rows2).to_csv(OUT / "exp2_N0_independence.csv", index=False)
    return df


# ---------------------------------------------------------------------------------------
def exp3_weak_feedback():
    """Lite-W error against zeta = max M/(R+h) and fM over a (nu, f) grid; a1 != b1 so R feels p."""
    rows = []
    base = km.with_params(a1=0.02, b1=0.005, c=0.0)
    for nu in np.geomspace(1e-3, 3.0, 9):
        for f in [0.0, 1e-3, 1e-2, 1e-1, 1.0]:
            P = km.with_params(base, a2=nu * base["a1"], b2=nu * base["b1"], f=f)
            Y0 = dict(km.REFERENCE_Y0)
            T = horizon(P, Y0)
            t, yo = run("original", P, Y0, T)
            _, yw = run("lite_w", P, Y0, T)
            e = errs(yo, yw)
            rows.append(dict(nu=nu, f=f, T=T,
                             zeta_max=float(np.max(yo[2] / (yo[1] + P["h"]))),
                             fM_max=float(f * np.max(yo[2])),
                             Mmax=float(yo[2].max()), **e,
                             Nmax_relerr=abs(yw[0].max() - yo[0].max()) / yo[0].max()))
    df = pd.DataFrame(rows)
    df.to_csv(OUT / "exp3_weak_feedback_grid.csv", index=False)
    return df


def exp3b_weak_feedback_other_axes():
    """Lite-W error versus zeta when h, b1/a1 and R0 are varied (f = 0, c = 0)."""
    rows = []
    for h in [0.3, 1.0, 3.0, 10.0]:
        for ratio in [0.1, 0.25, 0.5]:
            for R0 in [10.0, 30.0]:
                for nu in [0.01, 0.03, 0.1, 0.3]:
                    P = km.with_params(a1=0.02, b1=0.02 * ratio, a2=nu * 0.02, b2=nu * 0.02 * ratio, c=0.0, f=0.0, h=h)
                    Y0 = dict(N=0.01, R=R0, M=0.0)
                    T = horizon(P, Y0)
                    t, yo = run("original", P, Y0, T)
                    _, yw = run("lite_w", P, Y0, T)
                    rows.append(dict(h=h, b1_over_a1=ratio, R0=R0, nu=nu,
                                     zeta_max=float(np.max(yo[2] / (yo[1] + P["h"]))), err_N=errs(yo, yw)["err_N"]))
    df = pd.DataFrame(rows)
    df["err_over_zeta"] = df.err_N / df.zeta_max
    df.to_csv(OUT / "exp3b_weak_feedback_other_axes.csv", index=False)
    return df


# ---------------------------------------------------------------------------------------
def gronwall_check():
    """Check the N-clock Gronwall bound |R_orig(tau)-R_W(tau)| <= (delta/L)(exp(L tau)-1)."""
    P = km.with_params(a1=0.02, b1=0.005, a2=0.01, b2=0.0025, c=0.0, f=0.0, d=0.0)
    Y0 = dict(km.REFERENCE_Y0)
    Mmax = Y0["M"] + (P["a2"] / P["a1"]) * Y0["R"]

    def f_tau(tau, y):
        R, M = y
        return [km.F_R(R, M, P), P["a2"] / P["a1"] * (-km.F_R(R, M, P))]  # c=0, equal yields
    def fw(tau, y):
        return [km.F_R(y[0], 0.0, P)]
    taus = np.linspace(0, 20, 200)
    so = solve_ivp(f_tau, (0, 20), [Y0["R"], Y0["M"]], t_eval=taus, rtol=1e-11, atol=1e-14, method="LSODA")
    sw = solve_ivp(fw, (0, 20), [Y0["R"]], t_eval=taus, rtol=1e-11, atol=1e-14, method="LSODA")
    # delta: sup |F_R(R,M) - F_R(R,0)| <= |a1-b1| * Mmax * sup R^2/((R+h)(R+M+h)) <= |a1-b1| * Mmax * R0^2/((R0+h)*h)  (loose)
    R0 = Y0["R"]
    # |F_R(R,M)-F_R(R,0)| = |a1-b1| R^2 M/((R+h)(R+M+h)) <= |a1-b1| M R^2/(R+h)^2 <= |a1-b1| M_max
    delta = abs(P["a1"] - P["b1"]) * Mmax
    # Lipschitz constant of F_W in R on [0, R0]: dF/dR bound by grid
    # Lipschitz constant of F_W(R) = -R (a1 R + b1 h)/(R+h): |F_W'(R)| <= max(a1, b1) (checked numerically below)
    L = max(P["a1"], P["b1"])
    Rg = np.linspace(0, R0, 20001)
    FW = km.F_R(Rg, 0.0, P)
    assert float(np.max(np.abs(np.gradient(FW, Rg)))) <= L + 1e-9
    actual = np.abs(so.y[0] - sw.y[0])
    bound = delta / L * (np.exp(L * taus) - 1.0)
    df = pd.DataFrame(dict(tau=taus, actual_abs_err_R=actual, gronwall_bound=bound))
    df.to_csv(OUT / "gronwall_check.csv", index=False)
    return dict(delta=delta, L=L, holds=bool(np.all(actual <= bound + 1e-12)),
                max_actual=float(actual.max()), bound_at_tau_end=float(bound[-1]))


# ---------------------------------------------------------------------------------------
def exp7_efficiency(repeats=7):
    rows = []
    P = km.with_params(a1=0.02, b1=0.01, a2=0.01, b2=0.005, c=0.05)
    Pw = km.with_params(P, c=0.0)
    Y0 = dict(km.REFERENCE_Y0)
    Y0q = dict(Y0)
    cases = [("original", Pw, "LSODA"), ("original", Pw, "Radau"), ("original", Pw, "BDF"),
             ("lite_s", Pw, "LSODA"), ("lite_s", Pw, "Radau"), ("lite_w", Pw, "LSODA"),
             ("original", P, "LSODA"), ("lite_q", P, "LSODA"), ("lite_q1", P, "LSODA"),
             ("lite_q", P, "Radau")]
    for model, PP, method in cases:
        T = horizon(PP, Y0q)
        ts = []
        nfev = 0
        for _ in range(repeats):
            t0 = time.perf_counter()
            s = km.integrate(model, PP, Y0q, T, method=method, rtol=1e-8, atol=1e-11)
            ts.append(time.perf_counter() - t0)
            nfev = s.nfev
        rows.append(dict(model=model, c=PP["c"], method=method, median_ms=1e3 * float(np.median(ts)),
                         nfev=nfev))
    df = pd.DataFrame(rows)
    df.to_csv(OUT / "exp7_timing.csv", index=False)
    return df


# ---------------------------------------------------------------------------------------
def exp8_logistic_limit():
    """One-state (logistic) approximation N' = a1 N (C - N), C = N0 + mu R0, versus the original model."""
    rows = []
    mu, a1, R0, N0 = 0.5, 0.02, 10.0, 0.01
    C = N0 + mu * R0
    for KC in [1.0, 2.0, 10.0, 1e2, 1e4, 1e8]:
        for hR in [1e-6, 1e-2, 1e-1, 1.0]:
            for dd in [0.0, 0.005]:
                P = km.with_params(mu=mu, a1=a1, b1=a1, a2=0.0, b2=0.0, c=0.0, h=hR * R0, d=dd, K=KC * C, K0=KC * C, f=0.0)
                Y0 = dict(N=N0, R=R0, M=0.0)
                T = 900.0 if hR >= 1 else 450.0
                t, yo = run("original", P, Y0, T)
                Nlog = C * N0 * np.exp(a1 * C * t) / (C - N0 + N0 * np.exp(a1 * C * t))
                rows.append(dict(K_over_C=KC, h_over_R0=hR, d=dd, T=T,
                                 err_logistic=float(np.max(np.abs(yo[0] - Nlog)) / C)))
    df = pd.DataFrame(rows)
    df.to_csv(OUT / "exp8_logistic_limit.csv", index=False)
    return df


if __name__ == "__main__":
    which = sys.argv[1:] or ["exp1", "exp2", "exp3", "gronwall", "exp7"]
    if "exp1" in which:
        print(pd.DataFrame(exp1_exact_reduction()).to_string())
    if "exp2" in which:
        print(exp2_qssa().filter(regex="^(start|s|eps|lite_q_err_N|lite_q1_err_N)$").to_string())
    if "exp3" in which:
        print(exp3_weak_feedback().filter(regex="^(nu|f|zeta_max|fM_max|err_N)$").head(45).to_string())
    if "exp3b" in which:
        d_ = exp3b_weak_feedback_other_axes(); print(d_[d_.zeta_max < 0.3].err_over_zeta.describe())
    if "gronwall" in which:
        print(gronwall_check())
    if "exp8" in which:
        print(exp8_logistic_limit().round(5).to_string())
    if "exp7" in which:
        print(exp7_efficiency().to_string())
