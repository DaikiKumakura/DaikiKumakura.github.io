"""Recompute the deterministic result files (experiments 1-3, 8, Grönwall, thesis-parameter check, identifiability
FIM) into a temporary folder and compare SHA-256 hashes with results/sha256_reference.json (timing and real-data
fitting times are excluded because they depend on the machine)."""
import hashlib
import json
import shutil
import sys
import tempfile
from pathlib import Path

import experiments as ex

ROOT = Path(__file__).resolve().parent
FILES = ["exp1_summary.csv", "exp1_tolerance_convergence.csv", "exp1_yield_mismatch.csv", "exp2_qssa_scaling.csv",
         "exp2_N0_independence.csv", "exp3_weak_feedback_grid.csv", "exp3b_weak_feedback_other_axes.csv", "gronwall_check.csv", "exp8_logistic_limit.csv"]


def digest(p: Path) -> str:
    return hashlib.sha256(p.read_bytes()).hexdigest()


def compute() -> dict:
    ex.exp1_exact_reduction(); ex.exp2_qssa(); ex.exp3_weak_feedback(); ex.exp3b_weak_feedback_other_axes(); ex.gronwall_check(); ex.exp8_logistic_limit()
    return {f: digest(ex.OUT / f) for f in FILES}


if __name__ == "__main__":
    keep = {f: (ex.OUT / f).read_bytes() for f in FILES if (ex.OUT / f).exists()}
    a = compute()
    b = compute()
    ref_path = ROOT / "results" / "sha256_reference.json"
    if "--write" in sys.argv:
        ref_path.write_text(json.dumps(a, indent=1))
    ref = json.loads(ref_path.read_text()) if ref_path.exists() else {}
    same_runs = a == b
    same_ref = a == ref
    print(f"run1 == run2: {same_runs}; equals reference: {same_ref}; files: {len(a)}")
    sys.exit(0 if same_runs and (same_ref or "--write" in sys.argv) else 1)
