"""Compare the fixed-step RK4 used in realdata.py with LSODA (rtol 1e-10) at the fitted parameters of all converged fits."""
import numpy as np
import pandas as pd
from scipy.integrate import solve_ivp

import realdata as rd

df = pd.read_csv(rd.OUT / "realdata_fits.csv")
df = df[(df.split == "all") & df.params.notna()]
rows = []
for _, r in df.iterrows():
    if r.model not in rd.MECH:
        continue
    concs, X, _ = rd.load(int(r.strain))
    pars = {k: float(v) for k, v in (kv.split("=") for kv in r.params.split(";"))}
    names = list(rd.BOUNDS[r.model])
    th = np.log10([pars[k] for k in names])
    pr = rd.simulate_accurate(r.model, th, names, concs)
    p = {k: pars[k] for k in names}
    f = rd.rhs_factory(r.model)
    err = 0.0
    for i, c in enumerate(concs):
        R0 = np.array([c])
        def rhs(t, y):
            a, b = f(np.array([y[0]]), np.array([max(y[1], 0.0)]), p, R0)
            return [a[0], b[0]]
        s = solve_ivp(rhs, (0, rd.TGRID[-1]), [p["N0"], c], t_eval=rd.TGRID, method="LSODA", rtol=1e-10, atol=1e-13)
        if s.success:
            err = max(err, float(np.max(np.abs(s.y[0] - p["N0"] - pr[i]))))
    rows.append(dict(strain=r.strain, model=r.model, max_abs_diff_OD=err))
out = pd.DataFrame(rows)
out.to_csv(rd.OUT / "realdata_integrator_check.csv", index=False)
print(out.groupby("model").max_abs_diff_OD.agg(["median", "max"]).to_string())
