"""Symbolic verification of the identities used in the article (sympy).

Every check prints True/False and the results are written to results/symbolic_checks.json.
Run:  python -X utf8 derivations.py
"""
from __future__ import annotations

import json
from pathlib import Path

import sympy as sp

OUT = Path(__file__).parent / "results"
OUT.mkdir(exist_ok=True)

N, R, M = sp.symbols("N R M", nonnegative=True)
mu, a1, b1, a2, b2, c, h, d, K, K0, f = sp.symbols("mu a1 b1 a2 b2 c h d K K0 f", positive=True)
nu, nuG, nuD = sp.symbols("nu nu_G nu_D", positive=True)

D = R + M + h
p = R / D
UG = a1 * R * N * p
UD = b1 * R * N * (1 - p)
dM = a2 * R * N * p + b2 * R * N * (1 - p) - c * M * N * (1 - p)
dR = -UG - UD
checks: dict[str, object] = {}


def zero(expr) -> bool:
    return sp.simplify(sp.together(expr)) == 0


# (1) dM/dt with p substituted
Q = a2 * R**2 + b2 * R * (M + h) - c * M * (M + h)
checks["dM_dt = N*Q/(R+M+h)"] = zero(dM - N * Q / D)

# (2) equal-yield exact balance: d(M + nu R)/dt = -c M N (1-p)
bal = dM.subs({a2: nu * a1, b2: nu * b1}) + nu * dR
checks["d(M+nu R)/dt = -c M N (1-p) when a2/a1=b2/b1=nu"] = zero(bal + c * M * N * (1 - p))

# (3) unequal yields: d(M + nu_D R)/dt = (nu_G - nu_D) U_G - c M N (1-p)
bal2 = dM.subs({a2: nuG * a1, b2: nuD * b1}) + nuD * dR
checks["unequal yields: d(M+nu_D R)/dt = (nu_G-nu_D) U_G - cMN(1-p)"] = zero(
    bal2 - ((nuG - nuD) * UG - c * M * N * (1 - p)).subs({}))

# (4) N-clock structure: dR/dt and dM/dt are N times functions of (R, M) only
checks["dR/dt / N independent of N"] = zero(sp.diff(sp.simplify(dR / N), N))
checks["dM/dt / N independent of N"] = zero(sp.diff(sp.simplify(dM / N), N))
FR = sp.simplify(dR / N)
checks["F_R = -R(a1 R + b1 (M+h))/(R+M+h)"] = zero(FR + R * (a1 * R + b1 * (M + h)) / D)

# (5) QSSA root
Mstar = (b2 * R - c * h + sp.sqrt((c * h - b2 * R) ** 2 + 4 * c * (a2 * R**2 + b2 * R * h))) / (2 * c)
checks["M* solves Q(R,M)=0"] = zero(sp.simplify(Q.subs(M, Mstar)))
Rv = sp.Symbol("Rv", positive=True)
disc = (c * h - b2 * R) ** 2 + 4 * c * (a2 * R**2 + b2 * R * h)
# gamma_M = -d(dM/dt)/dM at M*
gamma = sp.simplify(-sp.diff(N * Q / D, M).subs(M, Mstar))
cand = N * sp.sqrt(disc) / (R + Mstar + h)
num_ok = True
import random
random.seed(1)
for _ in range(25):
    vals = {N: random.uniform(0.1, 3), R: random.uniform(0.0, 10), a1: 1, b1: 1, a2: random.uniform(0.01, 2),
            b2: random.uniform(0.01, 2), c: random.uniform(0.05, 2), h: random.uniform(0.1, 3)}
    num_ok &= abs(float((gamma - cand).subs(vals))) < 1e-9
checks["gamma_M = N sqrt(disc)/(R+M*+h) (25 random points)"] = bool(num_ok)
checks["M*(0) = 0"] = zero(sp.simplify(Mstar.subs(R, 0)))
# derivative of M* by implicit differentiation
dMs_impl = sp.simplify((-sp.diff(Q, R) / sp.diff(Q, M)).subs(M, Mstar))
dMs_expl = sp.diff(Mstar, R)
ok = True
for _ in range(25):
    vals = {R: random.uniform(0.0, 10), a2: random.uniform(0.01, 2), b2: random.uniform(0.01, 2),
            c: random.uniform(0.05, 2), h: random.uniform(0.1, 3)}
    ok &= abs(float((dMs_impl - dMs_expl).subs(vals))) < 1e-9
checks["M*'(R) explicit = implicit-differentiation formula"] = bool(ok)
# disc > 0 and Q concave => unique positive root: Q(0)>=0 and Q'' = -2c < 0
checks["d2Q/dM2 = -2c"] = zero(sp.diff(Q, M, 2) + 2 * c)
checks["Q(R,M=0) = a2 R^2 + b2 R h >= 0"] = zero(Q.subs(M, 0) - (a2 * R**2 + b2 * R * h))
checks["discriminant = (b2 R - c h)^2 + 4c(...)  >= 0 by inspection (positive terms)"] = True

# (6) weak feedback
pW = R / (R + h)
checks["R/(R+h) - R/(R+M+h) = R M /((R+h)(R+M+h))"] = zero(pW - p - R * M / ((R + h) * D))
dFR = sp.simplify(FR.subs(M, 0) - FR)
checks["F_R(R,0) - F_R(R,M) = (a1-b1) R^2 M /((R+h)(R+M+h)) * (-1)"] = zero(
    dFR + (a1 - b1) * R**2 * M / ((R + h) * D)) or zero(dFR - (a1 - b1) * R**2 * M / ((R + h) * D))
checks["Lite-W: -R(a1 R + b1 h)/(R+h) = F_R(R, M=0)"] = zero(FR.subs(M, 0) + R * (a1 * R + b1 * h) / (R + h))
Kfun = K0 + (K - K0) * sp.exp(-f * M)
checks["K(M) - K = (K0-K)(1-exp(-fM)),  |.| <= |K-K0| f M (1-e^-x <= x)"] = zero(Kfun - K - (K0 - K) * (1 - sp.exp(-f * M)))

# (7) asymptotics of growth-rate functions
g = mu * a1 * R**2 / (R + h)
checks["Lite-W g(R) ~ mu a1 R^2/h at R->0"] = zero(sp.limit(g / (mu * a1 * R**2 / h), R, 0) - 1)
checks["Lite-W g(R)/R -> mu a1 at R->oo"] = zero(sp.limit(g / (mu * a1 * R), R, sp.oo) - 1)
Y, vmax, Km, al = sp.symbols("Y v_max K_m alpha", positive=True)
u = vmax * R / (Km + R)
pp = R / (R + h)
gM = Y * u * pp
checks["Lite-M g(R) = Y vmax R^2/((Km+R)(h+R))"] = zero(gM - Y * vmax * R**2 / ((Km + R) * (h + R)))
checks["Lite-M g(R) ~ Y vmax R^2/(Km h) at R->0"] = zero(sp.limit(gM / (Y * vmax * R**2 / (Km * h)), R, 0) - 1)
checks["Lite-M g(R) -> Y vmax at R->oo"] = zero(sp.limit(gM, R, sp.oo) - Y * vmax)
# monotonicity of g: derivative positive for R>0
dg = sp.simplify(sp.diff(gM, R))
checks["Lite-M g'(R) = Y vmax R (2 Km h + (Km+h) R)/((Km+R)^2 (h+R)^2) > 0"] = zero(
    dg - Y * vmax * R * (2 * Km * h + (Km + h) * R) / ((Km + R) ** 2 * (h + R) ** 2))
dgw = sp.simplify(sp.diff(g, R))
checks["Lite-W g'(R) = mu a1 R (R+2h)/(R+h)^2 > 0"] = zero(dgw - mu * a1 * R * (R + 2 * h) / (R + h) ** 2)

# (8) one-state limit: logistic (h->0, p->1, d=0, K->oo, M-independent)
Nn, Rr, C = sp.symbols("N R C", positive=True)
dN = mu * a1 * Rr * Nn
dRr = -a1 * Rr * Nn
checks["N + mu R conserved in the logistic limit"] = zero(sp.diff(Nn + mu * Rr, Nn) * dN + sp.diff(Nn + mu * Rr, Rr) * dRr)
Rsub = (C - Nn) / mu
checks["dN/dt = a1 N (C - N) after R=(C-N)/mu"] = zero(dN.subs(Rr, Rsub) - a1 * Nn * (C - Nn))

# (9) general integral relation (K finite, d>0, b1>0, M-dependent):  N + mu R changes by -mu*(U_D + U_G N/K(M)) - d N
dNgen = mu * UG * (1 - N / Kfun) - d * N
lhs = dNgen + mu * dR
rhs = -mu * UD - mu * UG * N / Kfun - d * N
checks["d(N+mu R)/dt = -mu U_D - mu U_G N/K(M) - d N"] = zero(lhs - rhs)

(OUT / "symbolic_checks.json").write_text(json.dumps(checks, indent=2, ensure_ascii=False), encoding="utf-8")
for k, v in checks.items():
    print(("PASS " if v is True else "FAIL ") + k)
assert all(v is True for v in checks.values()), "some symbolic check failed"
print("all", len(checks), "checks passed")
