"""Practical identifiability of the original model (batch) from simulated observations (experiment 5).

Parameters (log scale): a1, b1, a2, b2, c, h, K, f  (mu = 1, d = 0.01, K0 = 1.5 fixed as in the thesis table).
Observation sets: N | N+R | N+M | N+R+M, for one initial condition or three initial resource levels.
Noise: Gaussian, SD = 2% of the maximum of each observed variable (stated assumption).  Local analysis at the
thesis Fig. 3 parameter set; the profile likelihood for c uses refits on one noisy data set (seed fixed).
Run:  python -X utf8 identifiability.py
"""
from __future__ import annotations

import json
from pathlib import Path

import numpy as np
import pandas as pd
from scipy.integrate import solve_ivp
from scipy.optimize import least_squares

import kl_models as km

OUT = Path(__file__).parent / "results"
SEED = 20261106
NAMES = ["a1", "b1", "a2", "b2", "c", "h", "K", "f"]
BASE = km.with_params(mu=1.0, a1=0.00025, b1=0.0015, a2=0.001, b2=0.001, c=0.01, d=0.01, h=1e-5, K=3.0, K0=1.5, f=0.01)
# h = 1e-5 is practically at the boundary of the model; keep it fixed to keep the problem well defined
FREE = [n for n in NAMES if n != "h"]
TOBS = np.linspace(0, 2400, 61)       # minutes
R0S = {"single": [100.0], "multi": [30.0, 100.0, 300.0]}
OBS = {"N": [0], "N+R": [0, 1], "N+M": [0, 2], "N+R+M": [0, 1, 2]}


def sim(theta_log, R0):
    P = dict(BASE)
    P.update({k: 10.0 ** v for k, v in zip(FREE, theta_log)})
    s = solve_ivp(lambda t, y: km.rhs_original(t, y, P), (0, TOBS[-1]), [0.1, R0, 0.0], t_eval=TOBS,
                  method="LSODA", rtol=1e-9, atol=1e-12)
    return s.y


TH0 = np.log10([BASE[k] for k in FREE])


def stacked(theta, obs, design, scales):
    parts = []
    for R0 in R0S[design]:
        y = sim(theta, R0)
        for j in OBS[obs]:
            parts.append(y[j] / scales[(R0, j)])
    return np.concatenate(parts)


def make_scales(design):
    sc = {}
    for R0 in R0S[design]:
        y = sim(TH0, R0)
        for j in range(3):
            sc[(R0, j)] = 0.02 * max(np.max(np.abs(y[j])), 1e-12)   # 2% of the max = noise SD
    return sc


def fim(obs, design):
    sc = make_scales(design)
    f0 = stacked(TH0, obs, design, sc)
    J = np.zeros((len(f0), len(TH0)))
    for i in range(len(TH0)):
        e = np.zeros_like(TH0); e[i] = 1e-4
        J[:, i] = (stacked(TH0 + e, obs, design, sc) - stacked(TH0 - e, obs, design, sc)) / 2e-4
    return J.T @ J


def run_fim():
    rows = []
    for design in R0S:
        for obs in OBS:
            F = fim(obs, design)
            w = np.linalg.eigvalsh(F)[::-1]
            w = np.maximum(w, 1e-300)
            cov = np.linalg.pinv(F) if w[-1] > 1e-12 else None
            rows.append(dict(design=design, observed=obs, eig_max=float(w[0]), eig_min=float(w[-1]),
                             log10_cond=float(np.log10(w[0] / w[-1])),
                             n_eig_gt_1em3_of_max=int(np.sum(w > 1e-3 * w[0])),
                             n_eig_gt_1em6_of_max=int(np.sum(w > 1e-6 * w[0])),
                             **({f"cv_{n}": float(np.sqrt(cov[i, i]) * np.log(10)) for i, n in enumerate(FREE)}
                                if cov is not None else {})))
    df = pd.DataFrame(rows)
    df.to_csv(OUT / "exp5_fim.csv", index=False)
    return df


def run_profile(obs="N", design="single", n_grid=15):
    rng = np.random.default_rng(SEED)
    sc = make_scales(design)
    truth = stacked(TH0, obs, design, sc)
    data = truth + rng.normal(size=truth.shape)
    lo, hi = TH0 - 2.0, TH0 + 2.0
    out = []
    ic = FREE.index("c")
    for g in np.linspace(TH0[ic] - 1.5, TH0[ic] + 1.5, n_grid):
        idx = [i for i in range(len(TH0)) if i != ic]
        def res(p):
            th = TH0.copy(); th[idx] = p; th[ic] = g
            return stacked(th, obs, design, sc) - data
        best = None
        for jitter in [0.0, 0.3, -0.3]:
            try:
                s = least_squares(res, TH0[idx] + jitter, bounds=(lo[idx], hi[idx]), max_nfev=80)
            except Exception:
                continue
            if best is None or s.cost < best.cost:
                best = s
        out.append(dict(observed=obs, design=design, log10_c=g, chi2=float(2 * best.cost)))
    df = pd.DataFrame(out)
    df["delta_chi2"] = df.chi2 - df.chi2.min()
    return df


if __name__ == "__main__":
    print(run_fim().round(3).to_string())
    profs = [run_profile(o, d) for o, d in [("N", "single"), ("N+M", "single"), ("N", "multi")]]
    pd.concat(profs).to_csv(OUT / "exp5_profile_c.csv", index=False)
    for p in profs:
        print(p.observed.iloc[0], p.design.iloc[0], "min dchi2 span (grid):", round(p.delta_chi2.max(), 2))
