"""Growth-law comparison on a public dilution-series data set (Sun et al. 2026 raw_data, 16 strains x 20 relative
medium concentrations x 4 replicate wells, OD600 every 10 min for 48 h).

Design
  * Observation x(t) = OD(t) - OD(initial reading) per concentration (replicate mean); model output is N(t) - N(0).
  * Mechanistic models are fitted JOINTLY over the training concentrations with ONE parameter vector per strain and
    the initial resource R0 = (relative concentration), so that unseen concentrations are predicted without refitting.
  * Phenomenological models (Logistic, Gompertz, Richards, Baranyi) are fitted per concentration; their parameters
    for an unseen concentration come from regressions on the training concentrations (K linear in c, log r linear in log c).
  * Splits: interp (hold out interior concentrations), high (train low, test highest), low (train high, test mid-low),
    all (in-sample curve fitting).
Run:  python -X utf8 realdata.py [--quick]   -> results/realdata_*.csv
"""
from __future__ import annotations

import sys
import time
from multiprocessing import Pool
from pathlib import Path

import numpy as np
import pandas as pd
from scipy.optimize import least_squares

HERE = Path(__file__).parent
DATA = HERE / "sources" / "data-sun2026-SR-Monod"
OUT = HERE / "results"
SEED = 20261106
DT, SUB = 0.25, 2           # RK4 step (h), output every SUB steps -> 0.5 h
NT = 97                      # 0..48 h in 0.5 h steps
TGRID = np.arange(NT) * DT * SUB
STRAINS = [105, 1287, 1292, 1299, 1842, 1896, 1972, 1977, 2160, 2164, 2443, 2659, 3031, 3237, 403, 6]
SPLITS = {
    "interp": dict(test=[1, 4, 7, 10, 13, 16]),
    "high": dict(test=[14, 15, 16, 17, 18, 19]),
    "low": dict(test=[3, 4, 5, 6, 7, 8, 9]),
    "all": dict(test=[]),
}
SPLITS["interp2"] = dict(test=[2, 5, 8, 11, 14, 17])
SPLITS["interp2"]["train"] = [i for i in range(20) if i not in SPLITS["interp2"]["test"]]
SPLITS["interp"]["train"] = [i for i in range(20) if i not in SPLITS["interp"]["test"]]
SPLITS["high"]["train"] = list(range(0, 14))
SPLITS["low"]["train"] = list(range(10, 20))
SPLITS["all"]["train"] = list(range(20))


# ------------------------------------------------------------------ data
def load(strain: int):
    d = pd.read_csv(DATA / f"Rs0i{strain}.csv")
    concs = np.sort(d.conc.unique())
    reps = ["1", "2", "3", "4"]
    X = np.zeros((len(concs), NT))
    Xrep = np.zeros((len(concs), 4, NT))
    for i, c in enumerate(concs):
        s = d[np.isclose(d.conc, c)].sort_values("Time")
        od = s[reps].to_numpy(float)[::3][:NT]                  # 30 min steps
        base = s[reps].to_numpy(float)[:3].mean(axis=0)
        Xrep[i] = (od - base).T
        X[i] = Xrep[i].mean(axis=0)
    return concs, X, Xrep


# ------------------------------------------------------------------ mechanistic models
def _M_star(R, a, b, h):  # c scaled out: alpha=a2/c, beta=b2/c
    return (b * R - h + np.sqrt((h - b * R) ** 2 + 4 * (a * R**2 + b * R * h))) / 2


def rhs_factory(name):
    def monod(N, R, p, R0):
        mu, Km, Y = p["mu"], p["Km"], p["Y"]
        g = mu * R / (Km + R)
        return g * N, -g * N / Y
    def hill(N, R, p, R0):
        g = p["mu"] * R ** p["n"] / (p["Km"] ** p["n"] + R ** p["n"])
        return g * N, -g * N / p["Y"]
    def monodK(N, R, p, R0):
        g = p["mu"] * R / (p["Km"] + R)
        return g * N * (1 - N / p["K"]), -g * N / p["Y"]
    def litew(N, R, p, R0):
        h, a1 = p["h"], p["a1"]
        dN = p["mu"] * a1 * R**2 / (R + h) * N * (1 - N / p["K"])
        dR = -R * N * (a1 * R + p["alpha"] * a1 * h) / (R + h)
        return dN, dR
    def litem(N, R, p, R0):
        u = p["vmax"] * R / (p["Km"] + R)
        pp = R / (R + p["h"])
        return N * p["Y"] * u * pp * (1 - N / p["K"]), -N * u * (pp + p["alpha"] * (1 - pp))
    def litem1(N, R, p, R0):          # ablation: alpha = 1 (yield-coupled consumption), allocation kept
        u = p["vmax"] * R / (p["Km"] + R)
        pp = R / (R + p["h"])
        return N * p["Y"] * u * pp * (1 - N / p["K"]), -N * u
    def litem0(N, R, p, R0):          # ablation: alpha = 0 (consumption fully coupled to the growth fraction)
        u = p["vmax"] * R / (p["Km"] + R)
        pp = R / (R + p["h"])
        return N * p["Y"] * u * pp * (1 - N / p["K"]), -N * u * pp
    def monodKa(N, R, p, R0):         # ablation: no allocation, density limit, free (uncoupled) consumption factor a
        u = p["vmax"] * R / (p["Km"] + R)
        return N * p["Y"] * u * (1 - N / p["K"]), -p["a"] * N * u
    def lites(N, R, p, R0):
        M = p["nu"] * (R0 - R)
        D = R + M + p["h"]
        pp = R / D
        Kc = p["K0"] + (p["K"] - p["K0"]) * np.exp(-p["f"] * M)
        UG, UD = p["a1"] * R * N * pp, p["b1"] * R * N * (1 - pp)
        return p["mu"] * UG * (1 - N / Kc) - p["d"] * N, -UG - UD
    def liteq(N, R, p, R0):
        M = _M_star(R, p["ka"], p["kb"], p["h"])
        D = R + M + p["h"]
        pp = R / D
        Kc = p["K0"] + (p["K"] - p["K0"]) * np.exp(-p["f"] * M)
        UG, UD = p["a1"] * R * N * pp, p["b1"] * R * N * (1 - pp)
        return p["mu"] * UG * (1 - N / Kc) - p["d"] * N, -UG - UD
    return dict(monod=monod, hill=hill, monodK=monodK, litew=litew, litem=litem, litem1=litem1, litem0=litem0, monodKa=monodKa, lites=lites, liteq=liteq)[name]


# (low, high) bounds on log10 of every parameter
BOUNDS = {
    "monod": dict(mu=(-2, 0.7), Km=(-1, 3), Y=(-4, -0.5), N0=(-5, -1.3)),
    "hill": dict(mu=(-2, 0.7), Km=(-1, 3), n=(-0.5, 0.7), Y=(-4, -0.5), N0=(-5, -1.3)),
    "monodK": dict(mu=(-2, 0.7), Km=(-1, 3), Y=(-4, -0.5), K=(-2, 2), N0=(-5, -1.3)),
    "litew": dict(mu=(-4, 0), a1=(-3, 2), alpha=(-3, 1), h=(-2, 3), K=(-2, 2), N0=(-5, -1.3)),
    "litem": dict(Y=(-4, -0.5), vmax=(-1, 4), Km=(-1, 3), h=(-2, 3), alpha=(-3, 1), K=(-2, 2), N0=(-5, -1.3)),
    "litem1": dict(Y=(-4, -0.5), vmax=(-1, 4), Km=(-1, 3), h=(-2, 3), K=(-2, 2), N0=(-5, -1.3)),
    "litem0": dict(Y=(-4, -0.5), vmax=(-1, 4), Km=(-1, 3), h=(-2, 3), K=(-2, 2), N0=(-5, -1.3)),
    "monodKa": dict(Y=(-4, -0.5), vmax=(-1, 4), Km=(-1, 3), a=(-2, 2), K=(-2, 2), N0=(-5, -1.3)),
    "lites": dict(mu=(-4, 0), a1=(-3, 2), b1=(-4, 2), nu=(-3, 1), h=(-2, 3), K=(-2, 2), K0=(-2, 2), f=(-4, 1),
                  d=(-4, -1), N0=(-5, -1.3)),
    "liteq": dict(mu=(-4, 0), a1=(-3, 2), b1=(-4, 2), ka=(-3, 2), kb=(-3, 2), h=(-2, 3), K=(-2, 2), K0=(-2, 2),
                  f=(-4, 1), d=(-4, -1), N0=(-5, -1.3)),
}
MECH = list(BOUNDS)


def simulate(name, theta_log, names, R0):
    p = {k: 10.0 ** v for k, v in zip(names, theta_log)}
    f = rhs_factory(name)
    N = np.full(R0.shape, p["N0"])
    R = R0.astype(float).copy()
    out = np.empty((len(R0), NT))
    out[:, 0] = N
    for k in range(1, NT):
        for _ in range(SUB):
            k1 = f(N, R, p, R0)
            k2 = f(N + 0.5 * DT * k1[0], R + 0.5 * DT * k1[1], p, R0)
            k3 = f(N + 0.5 * DT * k2[0], R + 0.5 * DT * k2[1], p, R0)
            k4 = f(N + DT * k3[0], R + DT * k3[1], p, R0)
            N = N + DT / 6 * (k1[0] + 2 * k2[0] + 2 * k3[0] + k4[0])
            R = np.maximum(R + DT / 6 * (k1[1] + 2 * k2[1] + 2 * k3[1] + k4[1]), 0.0)
        out[:, k] = N
    return out - p["N0"]


def simulate_accurate(name, theta_log, names, R0, rtol=1e-7, atol=1e-10):
    """All concentrations integrated together with LSODA (adaptive, stiff-capable). Returns N(t) - N0, NaN on failure."""
    from scipy.integrate import solve_ivp
    p = {k: 10.0 ** v for k, v in zip(names, theta_log)}
    f = rhs_factory(name)
    nc = len(R0)
    R0 = np.asarray(R0, float)

    def rhs(t, y):
        N, R = y[:nc], np.maximum(y[nc:], 0.0)
        a, b = f(N, R, p, R0)
        return np.concatenate([a, b])

    y0 = np.concatenate([np.full(nc, p["N0"]), R0])
    with np.errstate(all="ignore"):
        s = solve_ivp(rhs, (0.0, TGRID[-1]), y0, t_eval=TGRID, method="LSODA", rtol=rtol, atol=atol)
    if (not s.success) or s.y.shape[1] != NT or not np.all(np.isfinite(s.y)):
        return np.full((nc, NT), np.nan)
    return s.y[:nc] - p["N0"]


def nested_start(name, monod_names, monod_th):
    """Parameters of `name` that reproduce the fitted Monod model (limit in which the model reduces to Monod)."""
    m = dict(zip(monod_names, monod_th))          # log10 values
    names = list(BOUNDS[name])
    v = {}
    if name == "hill":
        v = dict(mu=m["mu"], Km=m["Km"], n=0.0, Y=m["Y"], N0=m["N0"])
    elif name == "monodK":
        v = dict(mu=m["mu"], Km=m["Km"], Y=m["Y"], K=BOUNDS["monodK"]["K"][1], N0=m["N0"])
    elif name == "litem":   # h -> small, alpha = 1, vmax = mu / Y, Y = Y_monod
        v = dict(Y=m["Y"], vmax=m["mu"] - m["Y"], Km=m["Km"], h=BOUNDS["litem"]["h"][0], alpha=0.0,
                 K=BOUNDS["litem"]["K"][1], N0=m["N0"])
    elif name == "litem1":
        v = dict(Y=m["Y"], vmax=m["mu"] - m["Y"], Km=m["Km"], h=BOUNDS["litem1"]["h"][0], K=BOUNDS["litem1"]["K"][1], N0=m["N0"])
    elif name == "litem0":
        v = dict(Y=m["Y"], vmax=m["mu"] - m["Y"], Km=m["Km"], h=BOUNDS["litem0"]["h"][0], K=BOUNDS["litem0"]["K"][1], N0=m["N0"])
    elif name == "monodKa":
        v = dict(Y=m["Y"], vmax=m["mu"] - m["Y"], Km=m["Km"], a=0.0, K=BOUNDS["monodKa"]["K"][1], N0=m["N0"])
    else:
        return None
    return np.array([v[k] for k in names])


def fit_mech(name, concs_tr, X_tr, n_rand=60, n_refine=3, seed=0, warm=None):
    names = list(BOUNDS[name])
    lo = np.array([BOUNDS[name][k][0] for k in names])
    hi = np.array([BOUNDS[name][k][1] for k in names])
    rng = np.random.default_rng(seed)

    def resid_screen(th):
        with np.errstate(all="ignore"):
            pr = simulate(name, th, names, concs_tr)
        r = (pr - X_tr).ravel()
        return np.where(np.isfinite(r), r, 10.0)

    def resid(th):
        pr = simulate_accurate(name, th, names, concs_tr)
        r = (pr - X_tr).ravel()
        return np.where(np.isfinite(r), r, 10.0)

    cand = rng.uniform(lo, hi, size=(n_rand, len(names)))
    sse = np.array([np.sum(resid_screen(c) ** 2) for c in cand])
    best = cand[np.argsort(sse)[:n_refine]]
    if warm is not None:   # nested warm start: the optimum of the nested model is always among the refined starts
        best = np.vstack([best, np.clip(warm, lo, hi)[None, :]])
    sol_best = None
    for th0 in best:
        try:
            s = least_squares(resid, th0, bounds=(lo, hi), method="trf", max_nfev=150, x_scale=1.0)
        except Exception:
            continue
        if sol_best is None or s.cost < sol_best.cost:
            sol_best = s
    if sol_best is None:
        return names, best[0], float(np.min(sse))
    return names, sol_best.x, float(2 * sol_best.cost)


# ------------------------------------------------------------------ phenomenological models (closed forms)
def pheno_curve(kind, t, P):
    K, r, N0 = P["K"], P["r"], P["N0"]
    if kind == "logistic":
        N = K * N0 / (N0 + (K - N0) * np.exp(-r * t))
    elif kind == "gompertz":    # Zwietering-style in N: N = N0 exp(ln(K/N0)(1-exp(-r t)))
        N = N0 * np.exp(np.log(K / N0) * (1 - np.exp(-r * t)))
    elif kind == "richards":
        v = P["v"]
        N = K / (1 + ((K / N0) ** v - 1) * np.exp(-r * v * t)) ** (1 / v)
    elif kind == "baranyi":     # Baranyi-Roberts 1994 with nu = r, lag parameter h0
        A = t + np.log(np.exp(-r * t) + np.exp(-P["h0"]) - np.exp(-r * t - P["h0"])) / r
        y0, ymax = np.log(N0), np.log(K)
        y = y0 + r * A - np.log(1 + (np.exp(r * A) - 1) / np.exp(ymax - y0))
        N = np.exp(y)
    return N - N0


PH_B = {
    "logistic": dict(K=(-2, 2), r=(-2, 0.7), N0=(-5, -1.3)),
    "gompertz": dict(K=(-2, 2), r=(-2, 0.7), N0=(-5, -1.3)),
    "richards": dict(K=(-2, 2), r=(-2, 0.7), N0=(-5, -1.3), v=(-1, 1)),
    "baranyi": dict(K=(-2, 2), r=(-2, 0.7), N0=(-5, -1.3), h0=(-1, 1.5)),
}


def fit_pheno_one(kind, x, seed=0):
    names = list(PH_B[kind])
    lo = np.array([PH_B[kind][k][0] for k in names])
    hi = np.array([PH_B[kind][k][1] for k in names])
    rng = np.random.default_rng(seed)

    def resid(th):
        P = {k: 10.0 ** v for k, v in zip(names, th)}
        with np.errstate(all="ignore"):
            r = pheno_curve(kind, TGRID, P) - x
        return np.where(np.isfinite(r), r, 10.0)

    cand = rng.uniform(lo, hi, size=(60, len(names)))
    sse = [np.sum(resid(c) ** 2) for c in cand]
    best, bc = None, np.inf
    for th0 in cand[np.argsort(sse)[:3]]:
        try:
            s = least_squares(resid, th0, bounds=(lo, hi), max_nfev=150)
        except Exception:
            continue
        if s.cost < bc:
            best, bc = s, s.cost
    P = {k: 10.0 ** v for k, v in zip(names, best.x)}
    return P, float(2 * bc)


GROW_THRESHOLD = 0.02   # OD units: max(x) below this is treated as "no detectable growth"


def pheno_fit_predict(kind, concs_tr, X_tr, concs_te):
    """Per-concentration fits on training concentrations; regress parameters; predict unseen concentrations."""
    fits, sse_tr = [], 0.0
    grow = X_tr.max(axis=1) >= GROW_THRESHOLD
    pars = []
    for i in range(len(concs_tr)):
        P, s = fit_pheno_one(kind, X_tr[i], seed=i)
        sse_tr += s
        pars.append(P)
    npar = len(PH_B[kind]) * len(concs_tr)
    idx = np.where(grow)[0]
    pred = np.zeros((len(concs_te), NT))
    if len(idx) < 3:
        return pred, sse_tr, npar
    c = concs_tr[idx]
    K = np.array([pars[i]["K"] for i in idx])
    r = np.array([pars[i]["r"] for i in idx])
    cK = np.polyfit(c, K, 1)
    cr = np.polyfit(np.log(c), np.log(r), 1)
    med = {k: float(np.median([pars[i][k] for i in idx])) for k in PH_B[kind] if k not in ("K", "r")}
    for j, cc in enumerate(concs_te):
        Kp = np.polyval(cK, cc)
        if Kp - med["N0"] < GROW_THRESHOLD:
            continue
        P = dict(med)
        P["K"] = Kp
        P["r"] = float(np.exp(np.polyval(cr, np.log(cc))))
        with np.errstate(all="ignore"):
            q = pheno_curve(kind, TGRID, P)
        pred[j] = np.where(np.isfinite(q), q, 0.0)
    return pred, sse_tr, npar


# ------------------------------------------------------------------ evaluation
def metrics(pred, obs, Xrep):
    e = pred - obs
    return dict(rmse=float(np.sqrt(np.mean(e**2))), mae=float(np.mean(np.abs(e))),
                final_abs_err=float(np.mean(np.abs(e[:, -1]))),
                rmse_rep=float(np.sqrt(np.mean((pred[:, None, :] - Xrep) ** 2))))


def job(args):
    strain, split, model = args
    concs, X, Xrep = load(strain)
    tr, te = SPLITS[split]["train"], SPLITS[split]["test"]
    t0 = time.perf_counter()
    row = dict(strain=strain, split=split, model=model, n_train_conc=len(tr), n_test_conc=len(te))
    try:
        if model in MECH:
            warm = None
            if model in ("hill", "monodK", "litem", "litem1", "litem0", "monodKa"):
                mn, mth, _ = fit_mech("monod", concs[tr], X[tr], seed=strain + 7)
                warm = nested_start(model, mn, mth)
            names, th, sse = fit_mech(model, concs[tr], X[tr], seed=strain + 7, warm=warm)
            tr_pred = simulate_accurate(model, th, names, concs[tr])
            row.update(n_params=len(names), train_rmse=float(np.sqrt(np.mean((tr_pred - X[tr]) ** 2))),
                       params=";".join(f"{k}={10**v:.4g}" for k, v in zip(names, th)))
            if te:
                pred = simulate_accurate(model, th, names, concs[te])
        else:
            pred_te, sse, npar = pheno_fit_predict(model, concs[tr], X[tr], concs[te] if te else concs[tr][:1])
            row.update(n_params=npar, train_rmse=float(np.sqrt(sse / (len(tr) * NT))))
            if te:
                pred = pred_te
        if te:
            row.update(metrics(pred, X[te], Xrep[te]))
        row["status"] = "ok"
    except Exception as ex:  # keep failures in the record
        row["status"] = f"failed: {type(ex).__name__}: {ex}"
    row["seconds"] = time.perf_counter() - t0
    return row


def noise_floor():
    """Replicate-to-mean RMSE (irreducible measurement spread) per strain."""
    rows = []
    for s in STRAINS:
        _, X, Xrep = load(s)
        rows.append(dict(strain=s, rep_sd=float(np.sqrt(np.mean((Xrep - X[:, None, :]) ** 2)))))
    return pd.DataFrame(rows)


if __name__ == "__main__":
    quick = "--quick" in sys.argv
    models = MECH + list(PH_B)
    strains = STRAINS[:2] if quick else STRAINS
    splits = ["interp"] if quick else list(SPLITS)
    import json
    INTERP2_MODELS = ["monod", "hill", "monodK", "litem", "litem1", "litem0", "monodKa"]
    jobs = [(s, sp, m) for s in strains for sp in splits for m in (INTERP2_MODELS if sp == "interp2" else models)]
    ck = OUT / ("realdata_quick.jsonl" if quick else "realdata_checkpoint.jsonl")
    done = {}
    if ck.exists():
        for line in ck.read_text(encoding="utf-8").splitlines():
            r = json.loads(line)
            done[(r["strain"], r["split"], r["model"])] = r
    todo = [j for j in jobs if j not in done]
    print(len(jobs), "jobs,", len(todo), "to run (checkpoint:", ck.name, ")")
    t0 = time.perf_counter()
    rows = list(done.values())
    with Pool(11) as pool, open(ck, "a", encoding="utf-8") as fh:
        for i, r in enumerate(pool.imap_unordered(job, todo, chunksize=1)):
            rows.append(r)
            fh.write(json.dumps(r) + chr(10)); fh.flush()
            if i % 20 == 0:
                print(i, "done", round(time.perf_counter() - t0), "s", flush=True)
    df = pd.DataFrame(rows).sort_values(["strain", "split", "model"])
    df.to_csv(OUT / ("realdata_quick.csv" if quick else "realdata_fits.csv"), index=False)
    noise_floor().to_csv(OUT / "realdata_noise_floor.csv", index=False)
    print(df.groupby(["split", "model"])[["rmse", "train_rmse", "n_params"]].median().round(4).to_string())
    print((df.status != "ok").sum(), "failed")
