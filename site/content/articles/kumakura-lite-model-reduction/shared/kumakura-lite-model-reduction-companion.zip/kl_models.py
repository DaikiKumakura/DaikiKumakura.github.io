"""Original functional-specialization model and reduced models (batch culture, lambda = 0 unless stated).

State vectors
  Original : y = (N, R, M)
  Lite-S   : y = (N, R)   exact when c = 0 and a2/a1 = b2/b1 (= nu); M recovered algebraically
  Lite-Q   : y = (N, R)   M replaced by the quasi-steady-state curve M*(R) (optionally first order)
  Lite-W   : y = (N, R)   weak metabolite feedback, p -> R/(R+h), K(M) -> K
  Lite-M   : y = (N, R)   saturating uptake u(R) x functional allocation p(R)  (NOT a reduction)

All right-hand sides are plain numpy functions of (t, y, params dict).
"""
from __future__ import annotations

import numpy as np
from scipy.integrate import solve_ivp

# --------------------------------------------------------------------------
# Parameters
# --------------------------------------------------------------------------
# Provisional reference set used for verification experiments (units are those of the
# model: N in cells/mL-like units, R and M in concentration units, time in hours).
# The values are chosen to give a full growth/depletion cycle; they are NOT fitted values.
REFERENCE = dict(
    mu=0.5,     # conversion of used resource into biomass (dimensionless yield-like factor)
    a1=0.02,    # uptake coefficient, growth function     [1/(N*time)]
    b1=0.02,    # uptake coefficient, non-growth function [1/(N*time)]
    a2=0.01,    # metabolite production, growth function
    b2=0.01,    # metabolite production, non-growth function
    c=0.0,      # metabolite degradation coefficient
    h=1.0,      # allocation half-saturation constant
    d=0.0,      # death rate [1/time]
    K=10.0,     # carrying capacity (no metabolite)
    K0=2.0,     # carrying capacity at M -> infinity
    f=0.1,      # metabolite sensitivity of carrying capacity
    lam=0.0,    # resource inflow (batch: 0)
)
REFERENCE_Y0 = dict(N=0.01, R=10.0, M=0.0)


def with_params(base: dict | None = None, **kw) -> dict:
    p = dict(REFERENCE if base is None else base)
    p.update(kw)
    return p


# --------------------------------------------------------------------------
# Original three-state model
# --------------------------------------------------------------------------
def alloc_p(R, M, h):
    return R / (R + M + h)


def carrying_capacity(M, P):
    return P["K0"] + (P["K"] - P["K0"]) * np.exp(-P["f"] * M)


def rhs_original(t, y, P):
    N, R, M = y
    D = R + M + P["h"]
    p = R / D
    UG = P["a1"] * R * N * p
    UD = P["b1"] * R * N * (1.0 - p)
    dN = P["mu"] * UG * (1.0 - N / carrying_capacity(M, P)) - P["d"] * N
    dR = P["lam"] - UG - UD
    dM = P["a2"] * R * N * p + P["b2"] * R * N * (1.0 - p) - P["c"] * M * N * (1.0 - p)
    return [dN, dR, dM]


def fluxes_original(y, P):
    """Return (U_G, U_D, metabolite decay flux) for state array y of shape (3, n)."""
    N, R, M = y
    p = R / (R + M + P["h"])
    return P["a1"] * R * N * p, P["b1"] * R * N * (1 - p), P["c"] * M * N * (1 - p)


# --------------------------------------------------------------------------
# Lite-S (exact for c = 0 and equal yields)
# --------------------------------------------------------------------------
def lite_s_conditions(P, tol=1e-12):
    ok_c = abs(P["c"]) <= tol
    nu_g = P["a2"] / P["a1"]
    nu_d = P["b2"] / P["b1"]
    return ok_c and abs(nu_g - nu_d) <= tol * max(1.0, abs(nu_g)), nu_g, nu_d


def M_from_R_lite_s(R, P, Y0):
    nu = P["a2"] / P["a1"]
    return Y0["M"] + nu * (Y0["R"] - R)


def rhs_lite_s(t, y, P, Y0):
    N, R = y
    M = M_from_R_lite_s(R, P, Y0)
    return rhs_original(t, [N, R, M], P)[:2]


# --------------------------------------------------------------------------
# Lite-Q (quasi-steady M)
# --------------------------------------------------------------------------
def M_star(R, P):
    """Non-negative root of a2 R^2 + b2 R (M+h) - c M (M+h) = 0 (needs c > 0)."""
    c, h, a2, b2 = P["c"], P["h"], P["a2"], P["b2"]
    disc = (c * h - b2 * R) ** 2 + 4.0 * c * (a2 * R**2 + b2 * R * h)
    return (b2 * R - c * h + np.sqrt(disc)) / (2.0 * c)


def disc_Q(R, P):
    c, h, a2, b2 = P["c"], P["h"], P["a2"], P["b2"]
    return (c * h - b2 * R) ** 2 + 4.0 * c * (a2 * R**2 + b2 * R * h)


def dMstar_dR(R, P):
    c, h, a2, b2 = P["c"], P["h"], P["a2"], P["b2"]
    disc = disc_Q(R, P)
    ddisc = -2.0 * b2 * (c * h - b2 * R) + 4.0 * c * (2 * a2 * R + b2 * h)
    return (b2 + ddisc / (2.0 * np.sqrt(disc))) / (2.0 * c)


def gamma_M_per_cell(R, P):
    """Local relaxation rate of M divided by N (the N-clock rate), evaluated at M*(R)."""
    Ms = M_star(R, P)
    return np.sqrt(disc_Q(R, P)) / (R + Ms + P["h"])


def F_R(R, M, P):
    """dR/d(tau) with dtau = N dt (batch)."""
    D = R + M + P["h"]
    return -R * (P["a1"] * R + P["b1"] * (M + P["h"])) / D


def rhs_lite_q(t, y, P, order=0):
    N, R = y
    Ms = M_star(R, P)
    if order == 1:
        gam = gamma_M_per_cell(R, P)
        dRdtau = F_R(R, Ms, P)
        Ms = Ms - dMstar_dR(R, P) * dRdtau / gam  # N cancels: both dR/dt and gamma carry N
        Ms = max(Ms, 0.0)
    return rhs_original(t, [N, R, Ms], P)[:2]


def M_recon_lite_q(R, P, order=0):
    Ms = M_star(R, P)
    if order == 1:
        gam = gamma_M_per_cell(R, P)
        Ms = Ms - dMstar_dR(R, P) * F_R(R, Ms, P) / gam
    return np.maximum(Ms, 0.0)


# --------------------------------------------------------------------------
# Lite-W (weak metabolite feedback)
# --------------------------------------------------------------------------
def rhs_lite_w(t, y, P):
    N, R = y
    h = P["h"]
    dN = P["mu"] * P["a1"] * R**2 / (R + h) * N * (1 - N / P["K"]) - P["d"] * N
    dR = -R * N * (P["a1"] * R + P["b1"] * h) / (R + h)
    return [dN, dR]


def g_lite_w(R, P):
    return P["mu"] * P["a1"] * R**2 / (R + P["h"])


# --------------------------------------------------------------------------
# Lite-M (saturating uptake x allocation) -- a new mechanistic model
# --------------------------------------------------------------------------
LITE_M_DEFAULT = dict(Y=0.5, vmax=0.4, Km=2.0, h=1.0, alpha=1.0, d=0.0, K=10.0)


def rhs_lite_m(t, y, P):
    N, R = y
    u = P["vmax"] * R / (P["Km"] + R)
    p = R / (R + P["h"])
    dN = N * (P["Y"] * u * p * (1 - N / P["K"]) - P["d"])
    dR = -N * u * (p + P["alpha"] * (1 - p))
    return [dN, dR]


def g_lite_m(R, P):
    return P["Y"] * P["vmax"] * R**2 / ((P["Km"] + R) * (P["h"] + R))


# --------------------------------------------------------------------------
# Integration helpers
# --------------------------------------------------------------------------
def integrate(model: str, P: dict, Y0: dict, t_end: float, t_eval=None, method="LSODA",
              rtol=1e-10, atol=1e-13, order=0):
    """Integrate one of: original, lite_s, lite_q, lite_q1, lite_w, lite_m. Returns solve_ivp result."""
    if model == "original":
        f = lambda t, y: rhs_original(t, y, P)
        y0 = [Y0["N"], Y0["R"], Y0["M"]]
    elif model == "lite_s":
        f = lambda t, y: rhs_lite_s(t, y, P, Y0)
        y0 = [Y0["N"], Y0["R"]]
    elif model in ("lite_q", "lite_q1"):
        o = 1 if model == "lite_q1" else order
        f = lambda t, y: rhs_lite_q(t, y, P, order=o)
        y0 = [Y0["N"], Y0["R"]]
    elif model == "lite_w":
        f = lambda t, y: rhs_lite_w(t, y, P)
        y0 = [Y0["N"], Y0["R"]]
    elif model == "lite_m":
        f = lambda t, y: rhs_lite_m(t, y, P)
        y0 = [Y0["N"], Y0["R"]]
    else:
        raise ValueError(model)
    return solve_ivp(f, (0.0, t_end), y0, method=method, t_eval=t_eval, rtol=rtol, atol=atol)


def summary_features(t, N):
    """Peak density, peak time, and time of maximal specific growth rate (finite differences on log N)."""
    i = int(np.argmax(N))
    return dict(Nmax=float(N[i]), t_peak=float(t[i]))
