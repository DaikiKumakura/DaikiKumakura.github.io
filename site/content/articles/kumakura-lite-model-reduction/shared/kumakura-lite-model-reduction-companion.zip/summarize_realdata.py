"""Summaries, bootstrap intervals and figures 6-8 for the dilution-series comparison.
Run after realdata.py:  python -X utf8 summarize_realdata.py
Cluster bootstrap over strains (16 clusters), 4000 resamples, seed fixed; statistic = geometric mean of the
per-strain ratio  RMSE_model / RMSE_Monod  (held-out concentrations).
"""
from __future__ import annotations

from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

import realdata as rd

HERE = Path(__file__).parent
RES, FIG = HERE / "results", HERE / "figures"
SEED = 20261106
LABEL = dict(litem0="Lite-M (alpha=0)", litem1="Lite-M (alpha=1)", monodKa="Monod + K + free uptake factor", monod="Monod", hill="Hill-Monod", monodK="Monod + K", litew="Lite-W", litem="Lite-M", lites="Lite-S",
             liteq="Lite-Q", logistic="Logistic+reg", gompertz="Gompertz+reg", richards="Richards+reg",
             baranyi="Baranyi+reg")
COL = dict(litem0="#B8860B", litem1="#E69F00", monodKa="#44AA99", monod="#0072B2", hill="#56B4E9", monodK="#009E73", litew="#E69F00", litem="#D55E00", lites="#CC79A7",
           liteq="#7f7f7f", logistic="#000000", gompertz="#999933", richards="#882255", baranyi="#44AA99")
plt.rcParams.update({"font.size": 8.5, "axes.spines.top": False, "axes.spines.right": False, "figure.dpi": 150,
                     "savefig.bbox": "tight"})


def boot_ci(x, n=4000):
    rng = np.random.default_rng(SEED)
    x = np.asarray(x, float)
    idx = rng.integers(0, len(x), size=(n, len(x)))
    m = np.exp(np.log(x)[idx].mean(axis=1))
    return float(np.exp(np.log(x).mean())), float(np.percentile(m, 2.5)), float(np.percentile(m, 97.5))


def main():
    df = pd.read_csv(RES / "realdata_fits.csv")
    ok = df[df.status == "ok"].copy()
    # prediction failures: non-finite or implausible (> 1 OD unit) held-out RMSE are counted and capped at 1.0
    ok["failed_pred"] = ok.split.ne("all") & (~np.isfinite(ok.rmse) | (ok.rmse > 1.0))
    ok["rmse_raw"] = ok.rmse
    ok.loc[ok.split.ne("all"), "rmse"] = ok.loc[ok.split.ne("all"), "rmse"].fillna(1.0).clip(upper=1.0)
    fails = ok[ok.failed_pred].groupby(["split", "model"]).size().rename("n_failed").reset_index()
    fails.to_csv(RES / "realdata_prediction_failures.csv", index=False)
    print(fails.to_string())
    rows, summ = [], []
    for split in ["interp", "interp2", "high", "low"]:
        d = ok[ok.split == split].pivot(index="strain", columns="model", values="rmse")
        for m in d.columns:
            r = (d[m] / d["monod"]).dropna()
            g, lo, hi = boot_ci(r.values)
            rows.append(dict(split=split, model=m, n_strains=len(r), gmean_ratio_vs_monod=g, ci_lo=lo, ci_hi=hi,
                             wins_vs_monod=int((r < 1).sum()), median_rmse=float(d[m].median())))
    pd.DataFrame(rows).to_csv(RES / "realdata_ratio_vs_monod.csv", index=False)
    pair = []
    for split in ["interp", "interp2", "high", "low"]:
        d = ok[ok.split == split].pivot(index="strain", columns="model", values="rmse")
        for a, b in [("litem", "monodK"), ("litem", "hill"), ("litem", "monod"), ("monodK", "monod"), ("litem", "litem1"),
                     ("litem", "litem0"), ("litem0", "monodK"), ("litem1", "monodK")]:
            if a not in d or b not in d:
                continue
            r = (d[a] / d[b]).dropna()
            g, lo, hi = boot_ci(r.values)
            pair.append(dict(split=split, numerator=a, denominator=b, n_strains=len(r), gmean_ratio=g, ci_lo=lo, ci_hi=hi,
                             wins=int((r < 1).sum())))
    pd.DataFrame(pair).to_csv(RES / "realdata_pairwise.csv", index=False)
    # sensitivity of the high-concentration split to strains where the Monod baseline failed (RMSE capped at 1)
    bad = sorted(ok[(ok.split == "high") & (ok.model == "monod") & ok.failed_pred].strain.unique().tolist())
    sens = []
    d = ok[(ok.split == "high") & ~ok.strain.isin(bad)].pivot(index="strain", columns="model", values="rmse")
    for m in d.columns:
        r_ = (d[m] / d["monod"]).dropna()
        g, lo, hi = boot_ci(r_.values)
        sens.append(dict(model=m, excluded_strains=";".join(map(str, bad)), n_strains=len(r_), gmean_ratio_vs_monod=g,
                         ci_lo=lo, ci_hi=hi, wins=int((r_ < 1).sum())))
    pd.DataFrame(sens).to_csv(RES / "realdata_high_sensitivity.csv", index=False)
    print("high split without", bad); print(pd.DataFrame(sens).round(3).to_string())
    # parameter bound hits of Lite-M and the ablations (all-concentration fits)
    hits = []
    for m in ["litem", "litem1", "litem0"]:
        sub = df[(df.model == m) & (df.split == "all") & df.params.notna()]
        for _, r_ in sub.iterrows():
            pv = {k: float(v) for k, v in (kv.split("=") for kv in r_.params.split(";"))}
            for k, v in pv.items():
                lo_, hi_ = rd.BOUNDS[m][k]
                hits.append(dict(model=m, strain=int(r_.strain), param=k, at_lower=bool(np.log10(v) < lo_ + 0.01),
                                 at_upper=bool(np.log10(v) > hi_ - 0.01)))
    hh = pd.DataFrame(hits).groupby(["model", "param"]).agg(at_lower=("at_lower", "sum"), at_upper=("at_upper", "sum")).reset_index()
    hh.to_csv(RES / "realdata_bound_hits.csv", index=False)
    print(hh[(hh.at_lower > 0) | (hh.at_upper > 0)].to_string())
    # training-fit order violations of nested models (optimiser check): train RMSE of nested model > Monod
    tr = df[df.status == "ok"].pivot_table(index=["split", "strain"], columns="model", values="train_rmse")
    viol = {m: int((tr[m] > tr["monod"] * (1 + 1e-3)).sum()) for m in ["hill", "monodK", "litem", "litem1", "litem0"]}
    print("nested-model training RMSE above Monod (count of 64 split-strain fits):", viol)
    pd.Series(viol).to_csv(RES / "realdata_nested_violations.csv", header=["n_above_monod"])
    print(pd.DataFrame(pair).round(3).to_string())
    a = ok[ok.split == "all"].groupby("model").agg(train_rmse=("train_rmse", "median"), n_params=("n_params", "median"),
                                                     seconds=("seconds", "median"))
    a.to_csv(RES / "realdata_insample.csv")
    t = ok.groupby("model").agg(seconds_median=("seconds", "median"), n_params_median=("n_params", "median"))
    t.to_csv(RES / "realdata_cost.csv")
    ratio = pd.DataFrame(rows)
    print(ratio.round(3).to_string())
    print(a.round(4).to_string())
    print("failures:", int((df.status != "ok").sum()))

    # ---- Fig 7: ratio vs Monod with CI
    fig, axs = plt.subplots(1, 3, figsize=(7.6, 3.0), sharey=True)
    order = ["hill", "monodK", "litem0", "litem1", "litew", "litem", "lites", "liteq", "logistic", "gompertz", "richards", "baranyi"]
    for ax, split, title in zip(axs, ["interp", "high", "low"],
                                ["interpolation", "high-concentration extrapolation", "low-concentration extrapolation"]):
        d = ratio[ratio.split == split].set_index("model").loc[order]
        y = np.arange(len(order))[::-1]
        ax.errorbar(d.gmean_ratio_vs_monod, y, xerr=[d.gmean_ratio_vs_monod - d.ci_lo, d.ci_hi - d.gmean_ratio_vs_monod],
                    fmt="o", ms=3.5, color="k", ecolor="#555", elinewidth=1, capsize=2)
        ax.axvline(1, color="#D55E00", lw=0.9, ls="--")
        ax.set_xscale("log"); ax.set_title(title, fontsize=8)
        from matplotlib.ticker import FixedLocator, FixedFormatter
        ax.xaxis.set_major_locator(FixedLocator([0.5, 1, 2, 4])); ax.xaxis.set_major_formatter(FixedFormatter(["0.5", "1", "2", "4"])); ax.xaxis.set_minor_formatter(FixedFormatter([]))
        ax.set_yticks(y); ax.set_yticklabels([LABEL[m] for m in order])
        ax.set_xlabel("RMSE ratio vs Monod")
    fig.tight_layout()
    fig.savefig(FIG / "fig7_prediction_ratio.png"); plt.close(fig)

    # ---- Fig 8: complexity / error / time
    fig, ax = plt.subplots(1, 2, figsize=(7.2, 2.9))
    for split, mk in [("interp", "o"), ("high", "s"), ("low", "^")]:
        d = ok[ok.split == split].groupby("model").agg(rmse=("rmse", "median"), npar=("n_params", "median"))
        for m, r in d.iterrows():
            ax[0].scatter(r.npar if m in rd.MECH else np.nan, r.rmse, marker=mk, color=COL[m], s=22,
                          label=None)
    for m in rd.MECH:
        ax[0].annotate(LABEL[m], (ok[(ok.model == m)].n_params.median(), ok[(ok.model == m) & (ok.split == "interp")].rmse.median()), fontsize=6)
    from matplotlib.lines import Line2D
    ax[0].legend(handles=[Line2D([], [], marker=m_, ls="", color="k", label=l_) for m_, l_ in
                          [("o", "interpolation"), ("s", "high extrapolation"), ("^", "low extrapolation")]],
                 frameon=False, fontsize=6.5, loc="upper left")
    ax[0].set_xlabel("free parameters (mechanistic models)"); ax[0].set_ylabel("median held-out RMSE (OD)")
    ax[0].set_yscale("log")
    tt = ok.groupby("model").seconds.median().loc[rd.MECH]
    ax[1].bar([LABEL[m] for m in tt.index], tt.values, color=[COL[m] for m in tt.index])
    ax[1].set_ylabel("median fitting time (s)"); ax[1].tick_params(axis="x", rotation=45)
    fig.tight_layout()
    fig.savefig(FIG / "fig8_complexity.png"); plt.close(fig)

    # ---- Fig 6: example fits for the strain with median Lite-M/Monod ratio in the interpolation split
    d = ok[ok.split == "interp"].pivot(index="strain", columns="model", values="rmse")
    rr = (d["litem"] / d["monod"]).sort_values()
    strain = int(rr.index[len(rr) // 2])
    concs, X, Xrep = rd.load(strain)
    sp = rd.SPLITS["interp"]
    tr, te = sp["train"], sp["test"]
    fig, axs = plt.subplots(2, 3, figsize=(7.6, 4.2), sharex=True)
    for ax, j in zip(axs.ravel(), [te[1], te[2], te[3], te[4], te[5], te[0]]):
        ax.plot(rd.TGRID, X[j], "k.", ms=2.2, label="observed (mean of 4)")
        ax.set_title(f"c = {concs[j]:.3g} (held out)", fontsize=7.5)
    for m in ["monod", "litew", "litem", "lites"]:
        row = ok[(ok.split == "interp") & (ok.strain == strain) & (ok.model == m)].iloc[0]
        pars = {k: float(v) for k, v in (kv.split("=") for kv in row.params.split(";"))}
        names = list(rd.BOUNDS[m])
        th = np.log10([pars[k] for k in names])
        pr = rd.simulate(m, th, names, concs[te])
        for ax, j in zip(axs.ravel(), [1, 2, 3, 4, 5, 0]):
            ax.plot(rd.TGRID, pr[j], color=COL[m], lw=1.2, label=LABEL[m])
    pl, _, _ = rd.pheno_fit_predict("logistic", concs[tr], X[tr], concs[te])
    for ax, j in zip(axs.ravel(), [1, 2, 3, 4, 5, 0]):
        ax.plot(rd.TGRID, pl[j], color="k", ls="--", lw=1, label="Logistic+reg")
    h_, l_ = axs[0, 0].get_legend_handles_labels()
    for ax in axs[1]:
        ax.set_xlabel("time (h)")
    for ax in axs[:, 0]:
        ax.set_ylabel("OD600 above initial reading")
    fig.suptitle(f"Strain {strain} (median Lite-M/Monod ratio among 16 strains), interpolation split", fontsize=8)
    fig.tight_layout(rect=(0, 0.06, 1, 0.97))
    fig.legend(*axs[0, 0].get_legend_handles_labels(), loc="lower center", ncol=6, frameon=False, fontsize=6.5)
    fig.savefig(FIG / "fig6_example_fits.png"); plt.close(fig)
    (RES / "fig6_strain.txt").write_text(str(strain))


if __name__ == "__main__":
    main()
