"""Run every computation in the order used for the article (about 1.5 hours with 12 cores, dominated by realdata.py).
python -X utf8 run_all.py [--skip-realdata]"""
import subprocess
import sys

STEPS = [["derivations.py"], ["experiments.py"], ["thesis_check.py"], ["identifiability.py"],
         ["fetch_data.py"], ["realdata.py"], ["summarize_realdata.py"], ["integrator_check.py"], ["figures.py"],
         ["-m", "pytest", "-q", "test_analysis.py"]]
skip = "--skip-realdata" in sys.argv
for s in STEPS:
    if skip and s[0] in ("realdata.py", "summarize_realdata.py", "fetch_data.py", "integrator_check.py"):
        continue
    print(">>", " ".join(s), flush=True)
    subprocess.run([sys.executable, "-X", "utf8", *s], check=True)
