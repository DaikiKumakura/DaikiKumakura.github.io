"""pytest suite for the reduction identities and numerical claims.  Run: python -X utf8 -m pytest -q"""
import numpy as np
import pytest
from scipy.integrate import solve_ivp

import experiments as ex
import kl_models as km

Y0 = dict(km.REFERENCE_Y0)
SEED = 20261106


def exact_params(**kw):
    base = dict(b1=0.01, c=0.0, a2=0.01, b2=0.005)  # nu = 0.5 for both
    base.update(kw)
    return km.with_params(**base)


def traj(model, P, Y0=Y0, **kw):
    T = ex.horizon(P, Y0)
    return ex.run(model, P, Y0, T, **kw)


def test_nonnegativity_random_parameters():
    rng = np.random.default_rng(SEED)
    for _ in range(15):
        P = km.with_params(a1=rng.uniform(0.005, 0.05), b1=rng.uniform(0.0, 0.05),
                           a2=rng.uniform(0, 0.05), b2=rng.uniform(0, 0.05), c=rng.uniform(0, 0.2),
                           h=rng.uniform(0.1, 5), d=rng.uniform(0, 0.02), f=rng.uniform(0, 0.5))
        T = 300.0
        t, y = ex.run("original", P, Y0, T)
        assert y.min() > -1e-9


def test_balance_identity_equal_yields_c_positive():
    P = exact_params()
    P["c"] = 0.05
    _, y = traj("original", P)
    bal = y[2] + 0.5 * y[1]
    assert np.max(np.diff(bal)) <= 1e-9          # M + nu R non-increasing
    assert np.all(y[2] <= 0.5 * (Y0["R"] - y[1]) + 1e-9)


def test_balance_conserved_when_c_zero():
    P = exact_params()
    _, y = traj("original", P)
    assert np.max(np.abs(y[2] + 0.5 * y[1] - 0.5 * Y0["R"])) < 1e-9


def test_lite_s_matches_original_under_conditions():
    P = exact_params()
    t, yo = traj("original", P)
    _, ys = ex.run("lite_s", P, Y0, t[-1])
    Ms = km.M_from_R_lite_s(ys[1], P, Y0)
    err = ex.errs(yo, np.vstack([ys, Ms]))
    assert max(err.values()) < 1e-8


def test_lite_s_fails_when_yields_differ():
    P = exact_params(b2=0.0025)   # nu_D = 0.25 != nu_G = 0.5
    t, yo = traj("original", P)
    _, ys = ex.run("lite_s", P, Y0, t[-1])
    assert ex.errs(yo, ys)["err_N"] > 1e-3


def test_lite_q_converges_with_timescale_separation():
    base = km.with_params(a1=0.02, b1=0.01, a2=0.01, b2=0.005, c=0.05)
    errs0, errs1 = [], []
    for s in [10.0, 100.0, 1000.0]:
        P = km.with_params(base, a2=base["a2"] * s, b2=base["b2"] * s, c=base["c"] * s)
        Y = dict(Y0, M=float(km.M_star(Y0["R"], P)))
        t, yo = traj("original", P, Y)
        for m, store in [("lite_q", errs0), ("lite_q1", errs1)]:
            _, yq = ex.run(m, P, Y, t[-1])
            store.append(ex.errs(yo[:2], yq)["err_N"])
    assert errs0[0] > errs0[1] > errs0[2]
    assert errs1[2] < errs0[2] / 10             # first-order correction helps on the slow manifold
    assert errs1[2] < 1e-4


def test_lite_w_converges_in_weak_feedback_limit():
    out = []
    for nu in [1e-1, 1e-2, 1e-3]:
        P = km.with_params(a1=0.02, b1=0.005, a2=nu * 0.02, b2=nu * 0.005, c=0.0, f=nu * 0.1)
        t, yo = traj("original", P)
        _, yw = ex.run("lite_w", P, Y0, t[-1])
        out.append(ex.errs(yo, yw)["err_N"])
    assert out[0] > out[1] > out[2]
    assert out[2] < 1e-3


def test_logistic_limit():
    N0, R0, mu, a1 = Y0["N"], Y0["R"], 0.5, 0.02
    P = km.with_params(mu=mu, a1=a1, b1=a1, a2=0.0, b2=0.0, c=0.0, h=1e-9, d=0.0, K=1e12, K0=1e12, f=0.0)
    t, y = ex.run("original", P, Y0, 400.0)
    C = N0 + mu * R0
    Nlog = C * N0 * np.exp(a1 * C * t) / (C - N0 + N0 * np.exp(a1 * C * t))
    assert np.max(np.abs(y[0] - Nlog)) / C < 1e-6


def test_tolerance_convergence():
    P = exact_params()
    T = 200.0
    ref = solve_ivp(lambda t, y: km.rhs_original(t, y, P), (0, T), [Y0["N"], Y0["R"], Y0["M"]],
                    method="DOP853", t_eval=np.linspace(0, T, 50), rtol=1e-13, atol=1e-16).y
    errs = []
    for tol in [1e-4, 1e-7, 1e-10]:
        y = solve_ivp(lambda t, y: km.rhs_original(t, y, P), (0, T), [Y0["N"], Y0["R"], Y0["M"]],
                      method="DOP853", t_eval=np.linspace(0, T, 50), rtol=tol, atol=tol * 1e-3).y
        errs.append(np.max(np.abs(y - ref)))
    assert errs[0] > errs[1] > errs[2]


def test_reproducible_same_seed():
    def draw():
        rng = np.random.default_rng(SEED)
        P = km.with_params(a1=rng.uniform(0.01, 0.03), c=rng.uniform(0, 0.1))
        return ex.run("original", P, Y0, 100.0)[1]
    assert np.array_equal(draw(), draw())


def test_gamma_M_formula_matches_jacobian():
    P = km.with_params(a2=0.3, b2=0.2, c=0.4, h=1.5)
    for R in [0.1, 1.0, 7.0]:
        N = 0.7
        Ms = km.M_star(R, P)
        g = lambda M: km.rhs_original(0, [N, R, M], P)[2]
        eps = 1e-6
        dg = (g(Ms + eps) - g(Ms - eps)) / (2 * eps)
        assert abs(g(Ms)) < 1e-12
        assert -dg == pytest.approx(N * km.gamma_M_per_cell(R, P), rel=1e-6)


def test_Mstar_derivative_finite_difference():
    P = km.with_params(a2=0.3, b2=0.2, c=0.4, h=1.5)
    for R in [0.1, 1.0, 7.0]:
        eps = 1e-6
        fd = (km.M_star(R + eps, P) - km.M_star(R - eps, P)) / (2 * eps)
        assert km.dMstar_dR(R, P) == pytest.approx(fd, rel=1e-6)


def test_R_dynamics_independent_of_N0_in_N_clock():
    """(R, M) form a closed system in tau (dtau = N dt): the phase curve N(R) of R, M is N0-independent."""
    P = km.with_params(b1=0.005, a2=0.01, b2=0.0025, c=0.02, f=0.0)
    curves = []
    for N0 in [1e-3, 1e-1]:
        Yn = dict(N=N0, R=10.0, M=0.0)
        t, y = traj("original", P, Yn)
        Rg = np.linspace(0.5, 9.5, 20)
        curves.append(np.interp(-Rg, -y[1], y[2]))   # M as a function of R
    assert np.max(np.abs(curves[0] - curves[1])) < 5e-5   # linear interpolation on a 4001-point time grid


def test_lite_m_limits():
    P = km.LITE_M_DEFAULT
    R = np.array([1e-4, 1e-3])
    g = km.g_lite_m(R, P)
    assert g[1] / g[0] == pytest.approx(100.0, rel=1e-2)       # quadratic at low R
    assert km.g_lite_m(np.array([1e8]), P)[0] == pytest.approx(P["Y"] * P["vmax"], rel=1e-6)
