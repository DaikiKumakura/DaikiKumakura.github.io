"""Apply the reductions to the thesis parameter set (Chapter 3, Fig. 3: batch, time in minutes).

Writes results/thesis_params_reductions.csv.  Run: python -X utf8 thesis_check.py
"""
from pathlib import Path

import numpy as np
import pandas as pd

import experiments as ex
import kl_models as km

OUT = Path(__file__).parent / "results"
P = km.with_params(mu=1.0, a1=0.00025, b1=0.0015, a2=0.001, b2=0.001, c=0.01, d=0.01, h=1e-5, K=3.0, K0=1.5, f=0.01)
Y0 = dict(N=0.1, R=100.0, M=0.0)
T = 4000.0
rows = []
t, yo = ex.run("original", P, Y0, T)
info = dict(Nmax=float(yo[0].max()), t_peak=float(t[np.argmax(yo[0])]), R_end=float(yo[1][-1]),
            Mmax=float(yo[2].max()), nu_G=P["a2"] / P["a1"], nu_D=P["b2"] / P["b1"], eps_Q=ex.eps_Q(P, Y0["R"]),
            zeta_max=float(np.max(yo[2] / (yo[1] + P["h"]))), fM_max=float(P["f"] * yo[2].max()))
print(info)
for start in ["M0=0 (thesis)", "M0=M*(R0)"]:
    Y = dict(Y0) if start.startswith("M0=0") else dict(Y0, M=float(km.M_star(Y0["R"], P)))
    t, yref = ex.run("original", P, Y, T)
    for m in ["lite_s", "lite_q", "lite_q1", "lite_w"]:
        if m != "lite_q" and m != "lite_q1" and start != "M0=0 (thesis)":
            continue
        _, y = ex.run(m, P, Y, T)
        e = ex.errs(yref, y)
        rows.append(dict(start=start, model=m, err_N=e["err_N"], err_R=e["err_R"]))
pd.DataFrame(rows).to_csv(OUT / "thesis_params_reductions.csv", index=False)
pd.Series(info).to_csv(OUT / "thesis_params_info.csv", header=["value"])
print(pd.DataFrame(rows))
