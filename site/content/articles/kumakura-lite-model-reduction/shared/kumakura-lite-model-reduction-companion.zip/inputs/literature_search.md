# Literature search record (accessed 2026-11-06)

Purpose: check prior art for the forms and arguments used in the article. The search was limited (web search and Crossref checks of DOIs); not finding a source is not evidence that none exists.

| Topic | What was searched | Result |
| --- | --- | --- |
| Growth rate of the form R^2/(R+h) (product of a Monod-type term and a saturating allocation) | Monod, Hill, Contois, generalized Monod, resource-allocation models, 2024-2026 symbolic-regression studies | No paper with exactly this form found. Contois (1959) uses a half-saturation constant proportional to biomass; Sun et al. 2026 report Monod-type laws recovered by symbolic regression |
| Quasi-steady-state or singular-perturbation reduction of a batch substrate-consumer-metabolite model | QSSA, singular perturbation, fast-slow reduction of consumer-resource and microbial growth models, 2024-2026 | No direct prior art found; nearest classical references are Segel and Slemrod 1989 (enzyme setting) and Fenichel 1979 (geometric singular perturbation theory) |
| Logistic growth from resource consumption with conserved N + mu R | logistic equation and mass balance, Verhulst, Monod yield | No source stating the identity was verified; treated as a known structure |
| Benchmarks of growth-model reduction | growth-model comparison and benchmarking | None found; related model-comparison papers (Zwietering et al. 1990; Baranyi and Roberts 1994) were used as the standard forms for phenomenological models |

DOIs checked in Crossref on 2026-11-06: 10.1016/j.jtbi.2023.111597, 10.1146/annurev.mi.03.100149.002103, 10.1099/00221287-21-1-40, 10.1016/0022-0396(79)90152-9, 10.1137/1031091, 10.1111/2041-210x.70335, 10.1016/0168-1605(94)90157-0, 10.1128/aem.56.6.1875-1881.1990, 10.1038/s41597-025-05356-3, 10.1101/2025.06.02.657040.
