# Kumakura-Lite: reductions of the functional-specialization growth model

Companion code for the article "Kumakura-Lite: when the functional-specialization growth model reduces to two states, and what the reduced and reformulated models predict on measured growth curves" (Japanese and English).

## What is here

| File | Role |
| --- | --- |
| `kl_models.py` | Original three-state model, Lite-S (exact), Lite-Q (quasi-steady state, zero and first order), Lite-W (weak feedback), Lite-M (saturating uptake x allocation); integrators |
| `derivations.py` | 27 symbolic identities checked with SymPy (balance laws, M*(R), relaxation rate, weak-feedback difference, limits, logistic limit); writes `results/symbolic_checks.json` |
| `experiments.py` | Experiments 1-3, 3b, 7, 8 and the Gronwall bound check (exact reduction, quasi-steady state, weak feedback, other axes of the weak-feedback error, timing, logistic limit) |
| `thesis_check.py` | Reductions applied to the parameter set of the thesis figure |
| `identifiability.py` | Fisher-information and profile-likelihood analysis of the original model (simulated observations) |
| `fetch_data.py` | Downloads the 16 dilution-series CSV files of Sun et al. (2026) and verifies SHA-256 hashes (`inputs/sun2026_sha256.json`); the data are not redistributed |
| `realdata.py` | Joint fits of 9 mechanistic models (incl. Lite-M ablations with alpha = 1 and alpha = 0; a free-consumption-factor form is kept in the results but not interpreted) and 4 phenomenological models on 16 strains, four splits plus a second interpolation split for six models; nested-model warm starts; checkpointed |
| `integrator_check.py` | Compares the adaptive integration used in the fits with a tighter tolerance at the fitted parameters |
| `summarize_realdata.py` | Cluster bootstrap over strains, summary tables, Figures 6-8 |
| `figures.py` | Figures 1-5 |
| `test_analysis.py` | 14 pytest checks |
| `check_reproducibility.py` | Recomputes the deterministic result files twice and compares SHA-256 hashes |
| `run_all.py` | Runs everything in order |

## Run

```bash
pip install -r requirements.txt
python -X utf8 derivations.py
python -X utf8 experiments.py
python -X utf8 -m pytest -q test_analysis.py
python -X utf8 check_reproducibility.py
python -X utf8 fetch_data.py
python -X utf8 realdata.py            # about 1.5 hours on 12 cores
python -X utf8 summarize_realdata.py
python -X utf8 figures.py
```

Random seed: 20261106. Python 3.12; NumPy 2.2; SciPy 1.14; SymPy 1.14; pandas 2.2; matplotlib 3.9. Timing results (`exp7_timing.csv`, fitting seconds) depend on the machine and are excluded from the hash check.

## Scope

All parameter values in the verification experiments are reference values, not fitted values. The real-data comparison uses one public dilution-series data set (16 strains, 20 relative medium concentrations, 4 wells each); held-out concentrations come from the same strain and plate series, not from new strains. See the article for limits.

## Licence

Code: MIT License. Result files and figures: CC BY 4.0. The third-party data are not included; follow the licence of the source repository (see `LICENSE`).
