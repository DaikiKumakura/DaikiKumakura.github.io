"""Download the 16 dilution-series CSV files of Sun et al. (2026) from the authors' public repository
(https://github.com/anthony-sun/SR-Monod, GPL-3.0) into sources/data-sun2026-SR-Monod/ and verify SHA-256 hashes.
The data are NOT redistributed with this archive."""
import hashlib
import json
import urllib.request
from pathlib import Path

HERE = Path(__file__).parent
DEST = HERE / "sources" / "data-sun2026-SR-Monod"
BASE = "https://raw.githubusercontent.com/anthony-sun/SR-Monod/main/raw_data/"


def main() -> None:
    DEST.mkdir(parents=True, exist_ok=True)
    expected = json.loads((HERE / "inputs" / "sun2026_sha256.json").read_text())
    for name, digest in expected.items():
        path = DEST / name
        if not path.exists():
            urllib.request.urlretrieve(BASE + name, path)
        got = hashlib.sha256(path.read_bytes()).hexdigest()
        status = "ok" if got == digest else "HASH MISMATCH (file differs from the version used in the article)"
        print(name, status)


if __name__ == "__main__":
    main()
