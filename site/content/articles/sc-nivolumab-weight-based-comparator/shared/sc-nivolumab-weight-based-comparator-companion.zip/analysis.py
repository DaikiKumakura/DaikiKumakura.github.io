"""Subcutaneous nivolumab (CheckMate-67T): how much of the exposure ratios is dose intensity and how much is bioavailability?

Trial design and PK values are taken from the Opdivo Qvantig prescribing information (sections 12.3 and 14.1):
SC 1,200 mg every 4 weeks vs IV nivolumab 3 mg/kg every 2 weeks; geometric mean ratios (90% CI)
Cavg over 28 days 2.10 (2.00-2.20), Cavg steady state 1.98 (1.87-2.11), Cmin at 28 days 1.60 (1.49-1.72), Cmin steady state 1.77 (1.63-1.93);
bioavailability 74%, peak concentration by about 6 days, volume of distribution 6.8 L, steady-state clearance 8.2 mL/h, half-life 25 days.
The IV dose per patient is 3 mg/kg x body weight, so the ratios depend on the weight of the compared patients (not given in the label).
Model: one compartment, first-order absorption (ka from the 6-day peak), typical patient, constant clearance, exact superposition.
"""
from pathlib import Path

import numpy as np
import pandas as pd
from scipy.optimize import brentq

ROOT = Path(__file__).resolve().parent
OUT = ROOT / "results"
OUT.mkdir(exist_ok=True)

F, TMAX, HALF_LIFE = 0.74, 6.0, 25.0       # label: bioavailability, peak time (days), elimination half-life (days)
V_LABEL, CL_LABEL = 6.8, 8.2 * 24 / 1000    # L, L/day (steady-state clearance 8.2 mL/h)
DOSE_SC, TAU_SC, MGKG_IV, TAU_IV = 1200.0, 28.0, 3.0, 14.0
REPORTED = {  # ratio: (GMR, lower, upper) of the 90% CI
    "Cavg 28 d": (2.10, 2.00, 2.20), "Cavg steady state": (1.98, 1.87, 2.11),
    "Cmin 28 d": (1.60, 1.49, 1.72), "Cmin steady state": (1.77, 1.63, 1.93)}
N_SS = 40                                  # doses treated as steady state (> 5 half-lives)


def rate_constants(k_source: str = "half_life"):
    k = np.log(2) / HALF_LIFE if k_source == "half_life" else CL_LABEL / V_LABEL
    ka = brentq(lambda a: np.log(a / k) / (a - k) - TMAX, k * 1.01, 50.0)
    return k, ka


def conc_sc(t, dose, tau, n, k, ka, f=F):
    """Concentration x V (mg) after n SC doses at 0, tau, 2 tau ..."""
    t = np.asarray(t, float)
    out = np.zeros_like(t)
    for i in range(n):
        tt = t - i * tau
        m = tt > 0
        out[m] += f * dose * ka / (ka - k) * (np.exp(-k * tt[m]) - np.exp(-ka * tt[m]))
    return out


def conc_iv(t, dose, tau, n, k):
    """IV doses treated as boluses (30-minute infusion has a negligible effect on 2-week and 4-week troughs)."""
    t = np.asarray(t, float)
    out = np.zeros_like(t)
    for i in range(n):
        tt = t - i * tau
        m = tt >= 0
        out[m] += dose * np.exp(-k * tt[m])
    return out


def auc_sc(a, b, dose, tau, n, k, ka, f=F):
    """Integral of conc x V over [a, b] for the SC regimen (closed form)."""
    tot = 0.0
    for i in range(n):
        lo, hi = max(a - i * tau, 0.0), b - i * tau
        if hi <= 0:
            continue
        g = lambda x: -np.exp(-k * x) / k + np.exp(-ka * x) / ka
        tot += f * dose * ka / (ka - k) * (g(hi) - g(lo))
    return tot


def auc_iv(a, b, dose, tau, n, k):
    tot = 0.0
    for i in range(n):
        lo, hi = max(a, i * tau), b
        s = i * tau
        if hi <= s:
            continue
        tot += dose / k * (np.exp(-k * (lo - s)) - np.exp(-k * (hi - s)))
    return tot


def ratios(weight_kg: float, f: float = F, k_source: str = "half_life") -> dict:
    k, ka = rate_constants(k_source)
    d_iv = MGKG_IV * weight_kg
    # 28 days after the first dose: Cavg = AUC(0-28)/28; Cmin = concentration at day 28 (SC) and just before the 3rd IV dose (day 28)
    n_iv28, n_sc28 = 2, 1
    cavg28 = auc_sc(0, 28, DOSE_SC, TAU_SC, n_sc28, k, ka, f) / auc_iv(0, 28, d_iv, TAU_IV, n_iv28, k)
    cmin28 = conc_sc([28.0], DOSE_SC, TAU_SC, n_sc28, k, ka, f)[0] / conc_iv([28.0 - 1e-9], d_iv, TAU_IV, n_iv28, k)[0]
    # steady state: last SC interval and last IV interval-pair within the same time window
    t0 = (N_SS - 1) * TAU_SC
    a_sc = auc_sc(t0, t0 + TAU_SC, DOSE_SC, TAU_SC, N_SS, k, ka, f) / TAU_SC
    a_iv = auc_iv(t0, t0 + TAU_SC, d_iv, TAU_IV, 2 * N_SS, k) / TAU_SC
    cmin_sc = conc_sc([t0 + TAU_SC], DOSE_SC, TAU_SC, N_SS, k, ka, f)[0]
    cmin_iv = conc_iv([t0 + TAU_SC - 1e-9], d_iv, TAU_IV, 2 * N_SS, k)[0]
    return {"Cavg 28 d": cavg28, "Cavg steady state": a_sc / a_iv, "Cmin 28 d": cmin28, "Cmin steady state": cmin_sc / cmin_iv}


def implied_weight(name: str, target: float, f: float = F) -> float:
    return brentq(lambda w: ratios(w, f)[name] - target, 30.0, 200.0)


def main() -> None:
    k, ka = rate_constants()
    print("k", k, "ka", ka, "k from CL/V", CL_LABEL / V_LABEL)
    rows = []
    for name, (g, lo, hi) in REPORTED.items():
        rows.append(dict(ratio=name, reported=g, lo=lo, hi=hi, implied_weight_kg=implied_weight(name, g),
                         weight_for_lower=implied_weight(name, hi), weight_for_upper=implied_weight(name, lo)))
    imp = pd.DataFrame(rows)
    imp.round(3).to_csv(OUT / "implied-weight.csv", index=False, lineterminator=chr(10))
    pd.set_option("display.width", 200)
    print(imp.round(3).to_string())
    pred = []
    for w in (60, 70, 75, 80, 90):
        r = ratios(float(w))
        pred.append(dict(weight_kg=w, **r))
    pd.DataFrame(pred).round(3).to_csv(OUT / "ratios-by-weight.csv", index=False, lineterminator=chr(10))
    print(pd.DataFrame(pred).round(3).to_string())
    # predicted Cmin ratios at the weight implied by the Cavg ratios
    w_c = implied_weight("Cavg steady state", REPORTED["Cavg steady state"][0])
    print("ratios at weight implied by steady-state Cavg:", {a: round(b, 3) for a, b in ratios(w_c).items()}, w_c)
    sens = []
    for f in (0.60, 0.74, 0.85):
        for w in (70.0, 80.0):
            r = ratios(w, f)
            sens.append(dict(f=f, weight_kg=w, **r))
    pd.DataFrame(sens).round(3).to_csv(OUT / "sensitivity-f.csv", index=False, lineterminator=chr(10))
    global TMAX
    tm_rows, tm0 = [], TMAX
    for tm in (6.0, 8.0, 10.0, 12.0, 15.0):
        TMAX = tm
        tm_rows.append(dict(tmax_days=tm, weight_kg=75.0, **ratios(75.0)))
    TMAX = tm0
    pd.DataFrame(tm_rows).round(3).to_csv(OUT / "sensitivity-tmax.csv", index=False, lineterminator=chr(10))
    print(pd.DataFrame(tm_rows).round(3).to_string())
    kcl, kacl = rate_constants("cl_over_v")
    print("alt k (CL/V):", kcl, kacl, {a: round(b, 3) for a, b in ratios(w_c, F, "cl_over_v").items()})


if __name__ == "__main__":
    main()
