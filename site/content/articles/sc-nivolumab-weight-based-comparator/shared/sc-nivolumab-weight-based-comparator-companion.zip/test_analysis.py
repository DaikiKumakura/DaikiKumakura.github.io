import numpy as np
from scipy.integrate import quad

import analysis as an


def test_ka_reproduces_label_peak():
    k, ka = an.rate_constants()
    assert abs(np.log(ka / k) / (ka - k) - an.TMAX) < 1e-6


def test_closed_form_auc_matches_quadrature():
    k, ka = an.rate_constants()
    num = quad(lambda t: an.conc_sc([t], an.DOSE_SC, an.TAU_SC, 3, k, ka)[0], 20, 70, limit=200)[0]
    assert abs(num - an.auc_sc(20, 70, an.DOSE_SC, an.TAU_SC, 3, k, ka)) < 1e-6 * num
    num_iv = quad(lambda t: an.conc_iv([t], 240.0, an.TAU_IV, 5, k)[0], 20, 60, limit=200, points=[28, 42, 56])[0]
    assert abs(num_iv - an.auc_iv(20, 60, 240.0, an.TAU_IV, 5, k)) < 1e-6 * num_iv


def test_cmin_ratio_equal_at_28_days_and_steady_state_in_constant_clearance_model():
    r = an.ratios(75.0)
    assert abs(r["Cmin 28 d"] - r["Cmin steady state"]) < 5e-3


def test_steady_state_cavg_ratio_is_dose_ratio():
    r = an.ratios(75.0)
    # per 28 days: SC delivers F x 1,200 mg, IV delivers 2 x 3 mg/kg x weight
    assert abs(r["Cavg steady state"] - an.F * an.DOSE_SC / (2 * an.MGKG_IV * 75.0)) < 1e-3
