"""Figure 1: body weight of the intravenous comparator implied by each reported exposure ratio."""
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import pandas as pd

import analysis as an

ROOT = Path(__file__).resolve().parent
(ROOT / "figures").mkdir(exist_ok=True)
df = pd.read_csv(ROOT / "results" / "implied-weight.csv")
labels = ["Cavg, 28 days", "Cavg, steady state", "Cmin, 28 days", "Cmin, steady state"]
fig, ax = plt.subplots(figsize=(7.2, 3.6), dpi=150)
for i, r in df.iterrows():
    y = len(df) - i
    ax.hlines(y, r.weight_for_lower, r.weight_for_upper, color="#0072B2", lw=3)
    ax.plot(r.implied_weight_kg, y, "o", color="#D55E00", ms=7)
    ax.text(r.weight_for_upper + 0.8, y, f"{r.implied_weight_kg:.0f} kg", va="center", fontsize=8)
ax.axvline(80, color="#777777", lw=1, ls=":")
ax.text(80.4, 4.45, "80 kg (stratification cut-off)", fontsize=7, color="#555555")
ax.set_yticks(range(len(df), 0, -1))
ax.set_yticklabels(labels)
ax.set_xlabel("Body weight giving the reported ratio (kg; bar: reported 90% CI)")
ax.set_xlim(60, 100)
ax.set_ylim(0.4, 4.8)
ax.set_title("Weight implied by SC 1,200 mg q4w / IV 3 mg/kg q2w ratios (bioavailability 0.74)", fontsize=9)
fig.tight_layout()
fig.savefig(ROOT / "figures" / "01-implied-weight.png")
