# SC nivolumab exposure ratios: companion code

Solves for the intravenous comparator body weight at which a one-compartment model reproduces each reported exposure ratio of subcutaneous nivolumab 1,200 mg every 4 weeks versus 3 mg/kg every 2 weeks.

- `analysis.py`: model, implied weights, sensitivity tables.
- `figures.py`: Figure 1.
- `test_analysis.py`: checks (`python -m pytest test_analysis.py`).
- `results/`: CSV outputs.

Inputs are published prescribing-information values. No patient data. Requires Python 3 with numpy, scipy, pandas, matplotlib.
