"""Non-additive share of double-CRISPRa expression changes (Norman et al. 2019), noise-corrected."""
from pathlib import Path
import json

import anndata as ad
import numpy as np
import pandas as pd
import scipy.sparse as sp

ROOT = Path(__file__).resolve().parent
SEED = 20261020
SENS_SEEDS = (1, 2, 3)
MIN_DETECTION = 0.10      # genes detected in at least 10% of cells
TOP_GENES = 50
SENS_TOP = (20, 200, None)
CHUNK = 1000
F_CUT = 0.2


def split_labels(obs, seed):
    """Group label per cell: control, single|H1/H2, double|T1/T2/T3."""
    rng = np.random.default_rng(seed)
    lab = np.empty(len(obs), dtype=object)
    for p, idx in obs.groupby("perturbation", observed=True).indices.items():
        if p == "control":
            lab[idx] = "control"
            continue
        k = 3 if "_" in p else 2
        tag = "T" if k == 3 else "H"
        parts = rng.permutation(np.arange(len(idx)) % k)
        lab[idx] = [f"{p}|{tag}{i + 1}" for i in parts]
    return pd.Series(lab, index=obs.index)


def group_means(path, labels, genes):
    """Mean log1p(CP10k) per group for the selected genes, reading the CSC matrix in chunks."""
    a = ad.read_h5ad(path, backed="r")
    n = a.n_obs
    totals = np.zeros(n)
    for s in range(0, a.n_vars, CHUNK):
        totals += np.asarray(a.X[:, s:s + CHUNK].sum(axis=1)).ravel()
    groups = pd.Categorical(labels)
    ind = sp.csr_matrix((np.ones(n), (groups.codes, np.arange(n))), shape=(len(groups.categories), n))
    counts = np.asarray(ind.sum(axis=1)).ravel()
    cols = np.flatnonzero(genes)
    out = np.zeros((len(groups.categories), len(cols)))
    for s in range(0, len(cols), CHUNK):
        c = cols[s:s + CHUNK]
        x = sp.csr_matrix(a.X[:, c[0]:c[-1] + 1])[:, c - c[0]]
        x = sp.diags(1e4 / totals) @ x
        x.data = np.log1p(x.data)
        out[:, s:s + len(c)] = (ind @ x).toarray()
    sums = pd.DataFrame(out, index=groups.categories, columns=a.var_names[cols])
    return sums, pd.Series(counts, index=groups.categories), totals


def combine(sums, counts, prefix):
    keys = [k for k in sums.index if k.split("|")[0] == prefix]
    return sums.loc[keys].sum() / counts[keys].sum()


def f_share(t2, t3, pred):
    den = float(np.dot(t2, t3))
    return float(np.dot(t2 - pred, t3 - pred) / den) if den > 0 else np.nan


def evaluate(sums, counts, top):
    ctrl = sums.loc["control"] / counts["control"]
    doubles = sorted({k.split("|")[0] for k in sums.index if "_" in k.split("|")[0]})
    rows = []
    for d in doubles:
        a_, b_ = d.split("_")
        if not any(k.split("|")[0] == a_ for k in sums.index) or not any(k.split("|")[0] == b_ for k in sums.index):
            continue
        t = [sums.loc[f"{d}|T{i}"] / counts[f"{d}|T{i}"] - ctrl for i in (1, 2, 3)]
        da, db = combine(sums, counts, a_) - ctrl, combine(sums, counts, b_) - ctrl
        # independent single-perturbation halves for the sensitivity on single-arm noise
        ha = [sums.loc[f"{a_}|H{i}"] / counts[f"{a_}|H{i}"] - ctrl for i in (1, 2)]
        hb = [sums.loc[f"{b_}|H{i}"] / counts[f"{b_}|H{i}"] - ctrl for i in (1, 2)]
        # the CRISPRa targets themselves are excluded from evaluation (their own induction dominates otherwise)
        ranked = t[0].drop([g for g in (a_, b_) if g in t[0].index], errors="ignore").abs().sort_values(ascending=False).index
        sel = ranked[:top] if top else ranked
        t1, t2, t3 = t[0][sel].to_numpy(), t[1][sel].to_numpy(), t[2][sel].to_numpy()
        add = (da + db)[sel].to_numpy()
        # scale factor(s) estimated on T1, independent of T2 and T3
        c = float(np.dot(t1, add) / np.dot(add, add)) if np.dot(add, add) > 0 else 1.0
        X2 = np.column_stack([da[sel].to_numpy(), db[sel].to_numpy()])
        c12 = np.linalg.lstsq(X2, t1, rcond=None)[0]
        add_h1, add_h2 = (ha[0] + hb[0])[sel].to_numpy(), (ha[1] + hb[1])[sel].to_numpy()
        rows.append(dict(double=d, n_cells=int(sum(counts[f"{d}|T{i}"] for i in (1, 2, 3))),
                         F_additive=f_share(t2, t3, add), F_scaled=f_share(t2, t3, c * add), scale_c=c,
                         F_two_coef=f_share(t2, t3, X2 @ c12), c1=float(c12[0]), c2=float(c12[1]),
                         targets_in_genes=int(sum(g in t[0].index for g in (a_, b_))),
                         F_additive_half1=f_share(t2, t3, add_h1), F_additive_half2=f_share(t2, t3, add_h2),
                         # post hoc: single-arm noise adds a positive bias that doubles with half the cells,
                         # so 2 F(full) - F(half) removes it to first order
                         F_debiased=2 * f_share(t2, t3, add) - (f_share(t2, t3, add_h1) + f_share(t2, t3, add_h2)) / 2,
                         r2_naive=float(1 - np.sum((t3 - add) ** 2) / np.sum(t3 ** 2)),
                         replicate_r2=float(1 - np.sum((t3 - t2) ** 2) / np.sum(t3 ** 2)),
                         signal=float(np.dot(t2, t3))))
    return pd.DataFrame(rows)


def summary(df, col="F_additive"):
    x = df[col].dropna()
    return dict(n=len(x), median=float(x.median()), q1=float(x.quantile(0.25)), q3=float(x.quantile(0.75)),
                frac_gt_cut=float((x > F_CUT).mean()), frac_lt0=float((x < 0).mean()))


def main():
    path = ROOT / "inputs" / "NormanWeissman2019_filtered.h5ad"
    a = ad.read_h5ad(path, backed="r")
    obs = a.obs[["perturbation", "nperts"]].copy()
    genes = (a.var.ncells >= MIN_DETECTION * a.n_obs).to_numpy()
    print("cells:", a.n_obs, "perturbations:", obs.perturbation.nunique(), "genes kept:", int(genes.sum()))
    assert obs.perturbation.notna().all()
    out = ROOT / "results"
    out.mkdir(exist_ok=True)
    res, sens = {}, []
    for seed in (SEED, *SENS_SEEDS):
        sums, counts, totals = group_means(path, split_labels(obs, seed), genes)
        if seed == SEED:
            assert counts.sum() == a.n_obs and (totals > 0).all()
            print("double perturbations:", sum("_" in k for k in counts.index) // 3)
        for top in (TOP_GENES, *SENS_TOP):
            df = evaluate(sums, counts, top)
            tag = f"seed={seed}, top={top or 'all'}"
            s = summary(df)
            s.update(setting=tag, seed=seed, top=top or "all",
                     median_F_scaled=summary(df, "F_scaled")["median"],
                     median_F_half1=summary(df, "F_additive_half1")["median"],
                     median_F_half2=summary(df, "F_additive_half2")["median"],
                     median_F_two_coef=summary(df, "F_two_coef")["median"],
                     frac_scaled_gt_cut=summary(df, "F_scaled")["frac_gt_cut"],
                     median_F_debiased=summary(df, "F_debiased")["median"],
                     frac_debiased_gt_cut=summary(df, "F_debiased")["frac_gt_cut"],
                     median_scale_c=float(df.scale_c.median()), frac_c_lt_08=float((df.scale_c < 0.8).mean()),
                     median_r2_naive=float(df.r2_naive.median()), median_replicate_r2=float(df.replicate_r2.median()))
            sens.append(s)
            if seed == SEED and top == TOP_GENES:
                res = df
    res.sort_values("F_additive", ascending=False).round(5).to_csv(out / "per-double.csv", index=False, lineterminator="\n")
    sens = pd.DataFrame(sens)
    sens.round(5).to_csv(out / "settings.csv", index=False, lineterminator="\n")
    main_s = sens.iloc[0].to_dict()
    (out / "summary.json").write_text(json.dumps({k: (v if not isinstance(v, np.generic) else v.item())
                                                  for k, v in main_s.items()}, indent=2) + "\n", encoding="utf-8")
    pd.set_option("display.width", 220)
    print(sens.round(3).to_string())
    print(res.sort_values("F_additive", ascending=False).head(15).round(3).to_string())


if __name__ == "__main__":
    main()
