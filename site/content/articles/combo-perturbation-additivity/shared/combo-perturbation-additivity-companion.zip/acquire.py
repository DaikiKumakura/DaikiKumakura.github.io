"""Download the Norman et al. 2019 combinatorial CRISPRa Perturb-seq file (scPerturb, Zenodo 7041849, CC BY 4.0).

Files are written once to inputs/ and pinned by SHA-256 in input-provenance.json.
"""
from pathlib import Path
import hashlib
import json
import time

import requests

ROOT = Path(__file__).resolve().parent
RECORD = "7041849"
FILES = ["NormanWeissman2019_filtered.h5ad"]


def digest(path, algo="sha256"):
    h = hashlib.new(algo)
    with open(path, "rb") as fh:
        for block in iter(lambda: fh.read(1 << 20), b""):
            h.update(block)
    return h.hexdigest()


def main():
    (ROOT / "inputs").mkdir(exist_ok=True)
    meta = requests.get(f"https://zenodo.org/api/records/{RECORD}", timeout=60).json()
    entries = {f["key"]: f for f in meta["files"]}
    prov_path = ROOT / "input-provenance.json"
    pinned = json.loads(prov_path.read_text(encoding="utf-8")) if prov_path.exists() else None
    records = []
    for name in FILES:
        dest = ROOT / "inputs" / name
        if not dest.exists():
            with requests.get(entries[name]["links"]["self"], stream=True, timeout=600) as r:
                r.raise_for_status()
                with open(dest.with_suffix(".part"), "wb") as fh:
                    for chunk in r.iter_content(1 << 22):
                        fh.write(chunk)
            dest.with_suffix(".part").rename(dest)
        assert entries[name]["checksum"] == "md5:" + digest(dest, "md5"), name
        records.append({"path": f"inputs/{name}", "bytes": dest.stat().st_size, "sha256": digest(dest)})
    if pinned:
        assert {r["path"]: r["sha256"] for r in records} == {r["path"]: r["sha256"] for r in pinned["files"]}
        print("inputs match pinned checksums")
        return
    prov_path.write_text(json.dumps({"source": f"https://doi.org/10.5281/zenodo.{RECORD}", "licence": "CC BY 4.0",
                                     "retrieved": time.strftime("%Y-%m-%d"), "files": records}, indent=2) + "\n",
                         encoding="utf-8")
    print("downloaded", [r["path"] for r in records])


if __name__ == "__main__":
    main()
