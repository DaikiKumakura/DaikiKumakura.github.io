"""Figures from results/ (run analysis.py first)."""
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parent
d = pd.read_csv(ROOT / "results/per-double.csv")
(ROOT / "figures").mkdir(exist_ok=True)

# Figure 1: distribution of the noise-corrected non-additive share, additive vs one-scale additive
fig, ax = plt.subplots(figsize=(7, 3.6), constrained_layout=True)
for col, lab, c in (("F_additive", "Sum of single effects", "#0072B2"),
                    ("F_scaled", "Sum rescaled by one factor c", "#E69F00")):
    x = np.sort(d[col].to_numpy())
    ax.step(x, np.arange(1, len(x) + 1) / len(x), where="post", color=c, label=f"{lab} (median {np.median(x):.2f})")
ax.axvline(0.2, color="k", linestyle=":", label="0.2")
ax.set_xlim(-0.1, 1.4)
ax.set_xlabel("Non-additive share of the double-perturbation change (noise-corrected F)")
ax.set_ylabel("Cumulative fraction of pairs")
ax.set_title(f"Norman et al. 2019 CRISPRa, {len(d)} gene pairs, top 50 changed genes per pair", fontsize=9)
ax.legend(fontsize=8, loc="lower right")
fig.savefig(ROOT / "figures/01-nonadditive-share.png", dpi=150)

# Figure 2: scale factor vs non-additive share
fig, ax = plt.subplots(figsize=(7, 4), constrained_layout=True)
ax.scatter(d.scale_c, d.F_additive, s=14 + 0.03 * d.n_cells, color="#0072B2", alpha=0.6, edgecolor="none")
for _, r in d.sort_values("F_additive", ascending=False).head(8).iterrows():
    ax.annotate(r["double"], (r.scale_c, r.F_additive), fontsize=6.5, xytext=(3, 2), textcoords="offset points")
ax.axvline(1, color="grey", linestyle="--", linewidth=1)
ax.axhline(0.2, color="k", linestyle=":", linewidth=1)
ax.set_xlabel("Best single scale factor c on the additive prediction (1 = purely additive)")
ax.set_ylabel("Non-additive share F (additive model)")
big = d[d.F_additive > 0.2]
ax.set_title(f"Pairs with F > 0.2 (n = {len(big)}) have median c = {big.scale_c.median():.2f}; marker size reflects cell number", fontsize=9)
fig.savefig(ROOT / "figures/02-scale-vs-share.png", dpi=150)
print("figures written")
