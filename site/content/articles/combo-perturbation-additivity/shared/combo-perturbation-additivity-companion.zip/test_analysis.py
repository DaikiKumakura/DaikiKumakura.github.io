"""Checks on synthetic data for the noise-corrected non-additive share."""
import numpy as np
import pandas as pd

import analysis as A


def test_f_share_zero_for_additive_truth():
    rng = np.random.default_rng(0)
    truth = rng.normal(0, 1, 20000)
    t2, t3 = truth + rng.normal(0, 1, truth.size), truth + rng.normal(0, 1, truth.size)
    assert abs(A.f_share(t2, t3, truth)) < 0.02          # noise does not inflate F


def test_f_share_recovers_nonadditive_fraction():
    rng = np.random.default_rng(1)
    add = rng.normal(0, 1, 50000)
    extra = rng.normal(0, 0.5, add.size)                   # non-additive part, variance 0.25
    truth = add + extra
    t2, t3 = truth + rng.normal(0, 1, add.size), truth + rng.normal(0, 1, add.size)
    expected = 0.25 / 1.25
    assert abs(A.f_share(t2, t3, add) - expected) < 0.02


def test_split_labels_balanced_and_complete():
    obs = pd.DataFrame({"perturbation": ["control"] * 5 + ["A"] * 10 + ["A_B"] * 9})
    lab = A.split_labels(obs, 0)
    assert (lab[:5] == "control").all()
    assert sorted(lab[lab.str.startswith("A|")].value_counts().tolist()) == [5, 5]
    assert sorted(lab[lab.str.startswith("A_B|")].value_counts().tolist()) == [3, 3, 3]


def test_evaluate_on_exactly_additive_groups():
    genes = [f"g{i}" for i in range(30)]
    rng = np.random.default_rng(2)
    da, db = rng.normal(0, 1, 30), rng.normal(0, 1, 30)
    rows, counts = {}, {}
    rows["control"] = np.zeros(30); counts["control"] = 1
    for i in (1, 2):
        rows[f"A|H{i}"] = da; rows[f"B|H{i}"] = db; counts[f"A|H{i}"] = counts[f"B|H{i}"] = 1
    for i in (1, 2, 3):
        rows[f"A_B|T{i}"] = da + db; counts[f"A_B|T{i}"] = 1
    sums = pd.DataFrame(rows, index=genes).T
    df = A.evaluate(sums, pd.Series(counts), 10)
    assert len(df) == 1 and abs(df.F_additive[0]) < 1e-12 and abs(df.scale_c[0] - 1) < 1e-12


if __name__ == "__main__":
    for name, fn in list(globals().items()):
        if name.startswith("test_"):
            fn()
    print("all tests passed")
