"""Independent re-implementation with scanpy for 12 double perturbations; writes results/validation.json.

Normalisation, splitting and gene selection are recomputed with different code (scanpy + dense numpy),
using the same seed and split rule, and F_additive is compared with results/per-double.csv.
"""
from pathlib import Path
import json
import warnings

import anndata as ad
import numpy as np
import pandas as pd
import scanpy as sc

warnings.filterwarnings("ignore")
ROOT = Path(__file__).resolve().parent
SEED = 20261020
CHECK = 12

ref = pd.read_csv(ROOT / "results/per-double.csv").set_index("double")
doubles = list(ref.sort_values("n_cells").index[:: max(1, len(ref) // CHECK)][:CHECK])
singles = sorted({g for d in doubles for g in d.split("_")})

full = ad.read_h5ad(ROOT / "inputs/NormanWeissman2019_filtered.h5ad", backed="r")
keep_genes = full.var.ncells.to_numpy() >= 0.10 * full.n_obs
obs = full.obs[["perturbation"]].copy()

# split labels: same rule (permutation of index mod k within each perturbation, groups in sorted order)
rng = np.random.default_rng(SEED)
part = pd.Series(-1, index=obs.index)
for p, idx in obs.groupby("perturbation", observed=True).indices.items():
    if p == "control":
        continue
    k = 3 if "_" in p else 2
    part.iloc[idx] = rng.permutation(np.arange(len(idx)) % k)

need = obs.perturbation.isin(["control", *doubles, *singles]).to_numpy()
rows = np.flatnonzero(need)
sub = full[rows].to_memory()
sub.obs["part"] = part.iloc[rows].to_numpy()
sc.pp.normalize_total(sub, target_sum=1e4)   # totals over all genes, before any gene filter
sc.pp.log1p(sub)
sub = sub[:, keep_genes]
X = sub.X.toarray() if hasattr(sub.X, "toarray") else np.asarray(sub.X)
pert = sub.obs.perturbation.astype(str).to_numpy()
ctrl = X[pert == "control"].mean(axis=0)


def mean(mask):
    return X[mask].mean(axis=0) - ctrl


out = {}
for d in doubles:
    a_, b_ = d.split("_")
    t = [mean((pert == d) & (sub.obs.part.to_numpy() == i)) for i in range(3)]
    add = mean(pert == a_) + mean(pert == b_)
    names = np.asarray(sub.var_names)
    order = [i for i in np.argsort(-np.abs(t[0]), kind="stable") if names[i] not in (a_, b_)]
    sel = np.array(order[:50])
    t2, t3, ad_ = t[1][sel], t[2][sel], add[sel]
    out[d] = float(np.dot(t2 - ad_, t3 - ad_) / np.dot(t2, t3))

cmp = pd.DataFrame({"validate": out, "analysis": ref.loc[doubles, "F_additive"]})
cmp["abs_diff"] = (cmp.validate - cmp.analysis).abs()
print(cmp.round(5))
ok = bool((cmp.abs_diff < 1e-3).all())
(ROOT / "results/validation.json").write_text(json.dumps({
    "status": "pass" if ok else "fail", "method": "scanpy re-implementation on a subset of doubles",
    "n_doubles": len(doubles), "max_abs_diff": float(cmp.abs_diff.max()),
    "doubles": {k: {"validate": v, "analysis": float(ref.loc[k, "F_additive"])} for k, v in out.items()}},
    indent=2) + "\n", encoding="utf-8")
print("validation:", "pass" if ok else "fail")
