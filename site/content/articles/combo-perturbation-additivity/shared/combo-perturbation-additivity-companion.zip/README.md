# 2遺伝子の同時摂動と加法モデル：配布資料

記事「2遺伝子の同時摂動は「足し算」でどこまで説明できるか：Norman 2019をノイズ込みで読み直す」の再実行用資料。

## 含むもの

- `analysis-plan.md`：問い・使いみち・処理・感度・判断の規則（計算前に固定、追記あり）
- `acquire.py`：scPerturb（Zenodo 10.5281/zenodo.7041849、CC BY 4.0）からの取得
- `input-provenance.json`：入力ファイルのSHA-256
- `analysis.py`, `test_analysis.py`, `figures.py`：集計、検査、図
- `validate.py`：scanpyによる独立の再実装（12組）
- `results/`：組み合わせごとの値、設定ごとの要約、検証結果
- `figures/`：記事の図

入力のh5adファイル本体（約700 MB）は同梱しない。`acquire.py` で取得し、SHA-256で照合する。

## 実行

1. `python acquire.py`（Python 3.12、requests）
2. `python test_analysis.py && python analysis.py && python figures.py && python validate.py`（anndata、scanpy、numpy、scipy、pandas、matplotlib。メモリ約3 GBで動くよう、行列を分割して読む）
