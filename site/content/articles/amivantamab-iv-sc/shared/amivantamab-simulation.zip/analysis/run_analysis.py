"""Conditional simulations of the public EMA IV/SC structural model; no refitting."""
from pathlib import Path
import json
import platform
import csv
import time
import numpy as np
import scipy
from scipy.integrate import solve_ivp
from scipy.special import expit, logit
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

ROOT = Path(__file__).resolve().parents[1]
PARAM = dict(F=.683, ka=.0172, lag=8.44, CL=.00889, V1=2.63,
             V2=2.41, Q=.0373, vmax=.751, km=18.4)
RSE = dict(F=.016, ka=.041, lag=.10, CL=.016, V1=.013,
           V2=.022, Q=.023, vmax=.041, km=.215)
DOSE_HOURS = [0,168,336,504,672,1008,1344,1680]
END = 2016.

def parameters(weight=60., bmi=24., age=63., albumin=40., male=0):
    p = PARAM.copy()
    p['F'] = float(expit(logit(p['F'])-.0363*(bmi-24)))
    p['ka'] *= (age/63)**(-.521)
    p['CL'] *= (weight/60)**.48*(albumin/40)**(-.52)*(age/63)**(-.218)*(1+.206*male)
    p['V1'] *= (weight/60)**.421*(1+.121*male)
    p['V2'] *= (weight/60)**.421
    return p

def simulate(route='sc', p=None, weight=60., dose_mode='standard',
             loading=True, infusion_scale=1., rtol=1e-8, nonlinear=True):
    p = parameters(weight=weight) if p is None else p.copy()
    iv_dose = 1050. if weight < 80 else 1400.
    sc_dose = 1600. if weight < 80 else 2240.
    dose = {'standard':sc_dose, 'same_nominal':iv_dose,
            'F_corrected':iv_dose/p['F']}[dose_mode] if route=='sc' else iv_dose
    times = DOSE_HOURS if loading else [0,672,1008,1344,1680]
    jumps = {}; infusions = []
    if route == 'sc':
        for t in times:
            jumps[t+p['lag']] = dose*p['F']
    else:
        for t in times:
            if t == 0:
                # 250 mL, first 2h at initial rate, then increased rate; no IRR.
                for start,d,initial,subsequent in [(0.,350.,50.,75.),
                    (24.,dose-350.,50. if weight<80 else 35.,75. if weight<80 else 50.)]:
                    first_hours=2.*infusion_scale
                    first_fraction=2.*initial/250.
                    final_hours=(250.-2.*initial)/subsequent*infusion_scale
                    infusions.append((start,start+first_hours,d*first_fraction/first_hours))
                    infusions.append((start+first_hours,start+first_hours+final_hours,
                                      d*(1-first_fraction)/final_hours))
            else:
                dur = (250/(85 if weight<80 else 65) if t==168
                       else 250/85 if weight>=80 and t==336 else 2.)*infusion_scale
                infusions.append((float(t),t+dur,dose/dur))
    bounds = sorted(set([0.,END,672.,1008.] + list(jumps) +
                        [x for a,b,_ in infusions for x in [a,b]]))
    state=np.zeros(5); results=[]; curves=[]; delivered=0.
    for left,right in zip(bounds[:-1],bounds[1:]):
        # Records at boundaries are always predose (before any instantaneous depot addition).
        if left in [672.,1008.]: results.append((left,state.copy()))
        if left in jumps:
            state[0]+=jumps[left]; delivered+=jumps[left]
        rin=sum(r for a,b,r in infusions if a<=left<b)
        delivered += rin*(right-left)
        def rhs(t,y):
            c1=y[1]/p['V1']; c2=y[2]/p['V2']
            elimination=p['CL']*c1+(p['vmax']*c1/(p['km']+c1) if nonlinear else 0.)
            transfer=p['Q']*(c1-c2); absorption=p['ka']*y[0]
            return [-absorption,rin+absorption-elimination-transfer,
                    transfer,c1,elimination]
        sol=solve_ivp(rhs,(left,right),state,rtol=rtol,atol=rtol*.01,
                      dense_output=True,max_step=6.)
        assert sol.success
        ts=np.linspace(left,right,max(2,int((right-left)/2)+1))
        ys=sol.sol(ts)
        curves.append(np.column_stack([ts,ys[1]/p['V1']]))
        state=sol.y[:,-1]
    results.append((END,state.copy()))
    points=dict(results)
    assert np.min(state[:3]) > -1e-7
    balance=abs(sum(state[:3])+state[4]-delivered)/delivered
    assert balance < 1e-7
    return dict(c2_trough=points[672.][1]/p['V1'],
                c2_auc=points[1008.][3]-points[672.][3],
                c4_trough=state[1]/p['V1'],mass_error=balance),np.vstack(curves)

def write_csv(name,rows):
    with (ROOT/'outputs/tables'/name).open('w',newline='',encoding='utf8') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)

def paired(p,weight=60.,**kwargs):
    iv,_=simulate('iv',p,weight=weight,**kwargs)
    sc,_=simulate('sc',p,weight=weight,**kwargs)
    return {k:sc[k]/iv[k] for k in ['c2_auc','c2_trough','c4_trough']}

def main():
    tic=time.perf_counter()
    for d in ['outputs/tables','outputs/figures']: (ROOT/d).mkdir(parents=True,exist_ok=True)
    plt.rcParams.update({'font.size':10,'axes.spines.top':False,'axes.spines.right':False})
    p=parameters(); rows=[]; fig,axs=plt.subplots(2,1,figsize=(9,7),sharex=False)
    for route,mode,color,label in [('iv','standard','#0072B2','IV 1050 mg'),
        ('sc','standard','#D55E00','SC 1600 mg'),
        ('sc','F_corrected','#009E73','SC 1050/F mg'),
        ('sc','same_nominal','#CC79A7','SC 1050 mg')]:
        m,c=simulate(route,p,dose_mode=mode)
        rows.append(dict(scenario=label,**m))
        axs[0].plot(c[:,0]/24,c[:,1],color=color,label=label)
        early=c[:,0]<=168;axs[1].plot(c[early,0]/24,c[early,1],color=color,label=label)
    axs[0].set(xlabel='Time since first dose (day)',ylabel='Serum concentration (mg/L)',title='Conditional reference profile: 60 kg, BMI 24, 63 years, female, albumin 40 g/L')
    axs[1].set(xlabel='Time since first dose (day)',ylabel='Serum concentration (mg/L)',title='First week: systemic input amount does not determine absorption timing')
    axs[0].legend(fontsize=8,ncol=2);fig.tight_layout();fig.savefig(ROOT/'outputs/figures/01-profiles.png',dpi=180);plt.close(fig)
    write_csv('reference.csv',rows)
    base=paired(p); comparison=[]
    published={'c2_auc':(1.032,.976,1.090),'c2_trough':(1.145,1.040,1.261),'c4_trough':(1.427,1.266,1.610)}
    sizes={'c2_auc':(140,132),'c2_trough':(160,142),'c4_trough':(98,98)}
    for k,vals in published.items(): comparison.append(dict(endpoint=k,conditional_ratio=base[k],trial_gmr=vals[0],trial_lower90=vals[1],trial_upper90=vals[2],trial_sc_n=sizes[k][0],trial_iv_n=sizes[k][1],source='EMA Table 11, observed'))
    write_csv('trial-context.csv',comparison)
    fig,ax=plt.subplots(figsize=(8,4));x=np.arange(3)
    vals=np.array(list(published.values()))
    ax.errorbar(x-.08,vals[:,0],yerr=np.vstack([vals[:,0]-vals[:,1],vals[:,2]-vals[:,0]]),fmt='o',label='PALOMA-3 observed GMR and 90% CI',color='#0072B2')
    ax.scatter(x+.08,list(base.values()),label='Conditional reference ratios (not GMR)',color='#D55E00')
    ax.axhline(.8,color='grey',ls=':',label='Trial lower-CI criterion: 0.80');ax.axhline(1,color='black',ls='--')
    ax.set(xticks=x,xticklabels=['C2 AUC day 1–15\nSC/IV n=140/132','C2 day 1 predose\nSC/IV n=160/142','C4 day 1 predose\nSC/IV n=98/98'],ylabel='SC / IV ratio',ylim=(.65,1.8));ax.legend(fontsize=8,loc='upper left');fig.tight_layout();fig.savefig(ROOT/'outputs/figures/02-endpoints.png',dpi=180);plt.close(fig)
    control=[]
    iv,_=simulate('iv',p)
    for mode in ['standard','same_nominal','F_corrected']:
        m,_=simulate('sc',p,dose_mode=mode)
        control.append(dict(sc_mode=mode,**{k:m[k]/iv[k] for k in base}))
    write_csv('input-controls.csv',control)
    grid=[]
    for weight in [50.,60.,79.,80.,100.]:
        for bmi in [20.,24.,30.,35.]:
            q=parameters(weight=weight,bmi=bmi)
            grid.append(dict(weight_kg=weight,bmi=bmi,**paired(q,weight)))
    write_csv('covariate-grid.csv',grid)
    fig,axs=plt.subplots(1,3,figsize=(11,3.8))
    for ax,k in zip(axs,base):
        for weight,color,marker in zip([50.,60.,79.,80.,100.],['#0072B2','#E69F00','#009E73','#CC79A7','#000000'],['o','s','^','D','x']):
            g=[r for r in grid if r['weight_kg']==weight]
            ax.plot([r['bmi'] for r in g],[r[k] for r in g],marker=marker,color=color,label=f'{weight:g} kg')
        ax.axhline(1,color='grey',ls='--');ax.set(xlabel='BMI (kg/m²)',ylabel='SC / IV ratio',title=k.replace('_',' '))
    axs[-1].legend(fontsize=8);fig.suptitle('Conditional profiles, not a sampled patient population');fig.tight_layout();fig.savefig(ROOT/'outputs/figures/03-covariates.png',dpi=180);plt.close(fig)
    sensitivity=[]
    for key in PARAM:
        for direction in [-1,1]:
            q=p.copy();q[key]*=(1+direction*1.96*RSE[key])
            sensitivity.append(dict(parameter=key,direction=direction,**paired(q)))
    for factor in [.5,2.]:
        sensitivity.append(dict(parameter='IV_duration',direction=factor,**paired(p,infusion_scale=factor)))
    sensitivity.append(dict(parameter='no_nonlinear_elimination',direction=0,**paired(p,nonlinear=False)))
    sensitivity.append(dict(parameter='omit_weekly_loading',direction=0,**paired(p,loading=False)))
    write_csv('sensitivity.csv',sensitivity)
    # Independent dose/F check and solver convergence, not observed-data validation.
    a,_=simulate('sc',p);b,_=simulate('sc',p,rtol=1e-10)
    convergence=max(abs(a[k]/b[k]-1) for k in base)
    assert convergence<1e-6
    summary=dict(reference_ratios=base,systemic_input_ratio=p['F']*1600/1050,
                 solver_relative_difference=convergence,max_mass_error=max(r['mass_error'] for r in rows),
                 seconds=time.perf_counter()-tic,
                 bmi35=next(r for r in grid if r['weight_kg']==60 and r['bmi']==35),
                 sensitivity_range={k:[min(r[k] for r in sensitivity if r['parameter'] in PARAM),max(r[k] for r in sensitivity if r['parameter'] in PARAM)] for k in base})
    (ROOT/'outputs/verification.json').write_text(json.dumps(summary,indent=2)+'\n')
    (ROOT/'outputs/environment.json').write_text(json.dumps(dict(python=platform.python_version(),numpy=np.__version__,scipy=scipy.__version__,matplotlib=matplotlib.__version__),indent=2)+'\n')
    print(json.dumps(summary,indent=2))

if __name__=='__main__':main()
