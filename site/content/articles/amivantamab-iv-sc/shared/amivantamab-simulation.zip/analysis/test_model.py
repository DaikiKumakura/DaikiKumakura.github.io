"""Tests for implementation, not for clinical prediction performance."""
import unittest
import numpy as np
from run_analysis import simulate, parameters, PARAM

class ModelTests(unittest.TestCase):
    def test_reference_covariates(self):
        for key,value in PARAM.items():self.assertAlmostEqual(parameters()[key],value)
    def test_bmi_logit(self):
        self.assertLess(parameters(bmi=35)['F'],parameters(bmi=24)['F'])
        self.assertGreater(parameters(age=40)['ka'],parameters(age=80)['ka'])
    def test_mass_and_convergence(self):
        for route in ['iv','sc']:
            a,_=simulate(route);b,_=simulate(route,rtol=1e-10)
            self.assertLess(a['mass_error'],1e-7)
            for key in ['c2_auc','c2_trough','c4_trough']:
                self.assertLess(abs(a[key]/b[key]-1),1e-6)
    def test_independent_bateman(self):
        p=parameters();p['Q']=0;p['vmax']=0
        m,_=simulate('sc',p)
        ke=p['CL']/p['V1'];expected=0.
        for td in [0,168,336,504]:
            t=672-td-p['lag']
            expected+=p['F']*1600/p['V1']*p['ka']/(p['ka']-ke)*(np.exp(-ke*t)-np.exp(-p['ka']*t))
        self.assertAlmostEqual(m['c2_trough']/expected,1,places=7)
    def test_linear_equal_systemic_input(self):
        p=parameters();p['vmax']=0
        iv,_=simulate('iv',p);sc,_=simulate('sc',p,dose_mode='F_corrected')
        # Delayed absorption changes trough despite equal systemic input per dose.
        self.assertGreater(sc['c2_trough'],iv['c2_trough'])

if __name__=='__main__':unittest.main()
