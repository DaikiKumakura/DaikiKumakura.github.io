# Amivantamab IV/SC structural PK simulations

Independent Python implementation of EMA/61503/2025 Table 4 (pages 30-31),
https://www.ema.europa.eu/en/documents/variation-report/rybrevant-h-c-005454-x-0014-epar-assessment-report-variation_en.pdf
Observed aggregate GMRs: Table 11, page 41, same report; PALOMA-3 original:
https://doi.org/10.1200/JCO.24.01001
IV initial split and infusion speeds: https://www.medicines.org.uk/emc/product/13084/smpc
Historical PALOMA-3 dosing is used, not all current regional indications.

Uses hours, mg, L, mg/L (numerically equal to microgram/mL).
SC depot receives F*dose after ALAG: no second F multiplier in RHS.
Reference female 60kg, BMI24, age63, albumin40g/L, eta=0.
Infusion uses two rates for first two infusion days, no interruptions.
SC injection duration is neglected relative to the hours-scale absorption.
C2D1 predose t672h; C2 AUC672-1008h; C4D1 predose t2016h.
Week1 split350mg/remainder; weekly days1,8,15,22 then Q2W from day29.
No IIV population sampling, residual-noise simulation, fitting or clinical dose recommendation.
Single-covariate grids are conditional profiles, not patient frequencies.
Structural one-at-a-time RSE ranges are not joint 95% prediction intervals.
The trial used model development data, so this is not external validation.
C4 observed n98/98 is distinct from the hybrid observed/model-predicted endpoint.

Python and library versions: outputs/environment.json.
Install requirements.txt in your chosen environment.
Run python analysis/run_analysis.py to regenerate original figures and CSVs.
Run python -m unittest discover -s analysis -p "test_*.py" -q.
Public source PDFs/images and private work/review notes are not included.
