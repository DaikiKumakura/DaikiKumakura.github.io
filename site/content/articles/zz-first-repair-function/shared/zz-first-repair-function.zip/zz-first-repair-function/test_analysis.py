import unittest,json
import numpy as np
import pandas as pd
from analysis import ROOT,gene_z,paired_deltas

class PairedAnalysisTests(unittest.TestCase):
    def setUp(self):
        self.x=pd.read_csv(ROOT/'inputs/panel_logcpm.csv',index_col=0)
        self.m=pd.read_csv(ROOT/'inputs/paired_metadata.csv')
        self.p=json.loads((ROOT/'inputs/panels.json').read_text())
    def test_gene_standardization(self):
        z=gene_z(self.x)
        np.testing.assert_allclose(z.mean(axis=1),0,atol=1e-13)
        np.testing.assert_allclose(z.std(axis=1,ddof=1),1,atol=1e-13)
    def test_pairs_not_inferred_from_prefix(self):
        self.assertEqual(len(self.m),24)
        self.assertNotIn('ZZHDST01',set(self.m.pair))
        self.assertNotIn('ZZHDST18_C2D1',set(self.m.sampleID))
        d=paired_deltas(gene_z(self.x),self.m,self.p)
        self.assertEqual(len(d),12)
        self.assertEqual(list(d.loc[~d.same_site,'pair']),['ZZHDST17'])
    def test_timepoint_reversal_reverses_delta(self):
        z=gene_z(self.x);a=paired_deltas(z,self.m,self.p)
        m=self.m.copy();m.timepoint=m.timepoint.map({'baseline':'on-treatment','on-treatment':'baseline'})
        b=paired_deltas(z,m,self.p)
        np.testing.assert_allclose(a[['repair_delta','cycle_delta']],-b[['repair_delta','cycle_delta']])
    def test_incomplete_pair_rejected(self):
        with self.assertRaises(ValueError):paired_deltas(gene_z(self.x),self.m.iloc[1:],self.p)
    def test_overlapping_panel_rejected(self):
        p={k:list(v) for k,v in self.p.items()};p['cycle'].append(p['repair'][0])
        with self.assertRaises(ValueError):paired_deltas(gene_z(self.x),self.m,p)
    def test_expression_invalid_rejected(self):
        x=self.x.copy();x.iloc[0,:]=1
        with self.assertRaises(ValueError):gene_z(x)

if __name__=='__main__':unittest.main()
