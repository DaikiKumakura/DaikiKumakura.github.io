"""Extract a small CC BY 4.0 subset from downloaded Zenodo source files."""
from pathlib import Path
from zipfile import ZipFile
from xml.etree import ElementTree as ET
import csv,hashlib,json
import pandas as pd

ROOT=Path(__file__).resolve().parent
PANELS={'repair':['RAD51','BRCA1','BRCA2','PALB2','RAD54L','RAD51AP1'],
        'cycle':['PCNA','MCM2','MCM4','CDC6','CCNB1','CDK1']}

def read_metadata(path):
    ns={'m':'http://schemas.openxmlformats.org/spreadsheetml/2006/main'}
    with ZipFile(path) as z:
        ss=[''.join(n.itertext()) for n in ET.fromstring(z.read('xl/sharedStrings.xml')).findall('m:si',ns)]
        rows=[]
        for row in ET.fromstring(z.read('xl/worksheets/sheet1.xml')).findall('.//m:row',ns):
            vals={}
            for c in row.findall('m:c',ns):
                v=c.find('m:v',ns);value='' if v is None else v.text
                if c.get('t')=='s':value=ss[int(value)]
                if c.get('t')=='inlineStr':value=''.join(c.find('m:is',ns).itertext())
                col=''.join(ch for ch in c.attrib['r'] if ch.isalpha())
                vals[col]=value
            rows.append(vals)
    keys=list(rows[0]);return pd.DataFrame([{rows[0][k]:r.get(k,'') for k in keys} for r in rows[1:]])

def run():
    data=ROOT/'data';out=ROOT/'inputs';out.mkdir(exist_ok=True)
    record=json.loads((data/'zenodo-record.json').read_text())
    for f in record['files']:
        actual=hashlib.md5((data/f['key']).read_bytes()).hexdigest()
        if actual!=f['checksum'].split(':')[1]:raise ValueError('source checksum mismatch')
    m=read_metadata(data/'Zacchi2026_metadata_pseudobulked_tumor.xlsx')
    x=pd.read_csv(data/'Zacchi2026_expression.normalized_logCPM.batch_corrected_pseudobulked_tumor.tsv',sep='\t').set_index('geneID')
    m=m[m['sampleID'].isin(x.columns)&(m['remove']!='yes')]
    complete=[]
    for patient,g in m.groupby('Subject_ID'):
        if len(g)==2 and set(g['timepoint'])=={'baseline','on-treatment'}:
            if len(set(g['pair']))!=1 or 'unpaired' in set(g['pair']):raise ValueError('pair annotation disagrees')
            complete.extend(g.index)
    m=m.loc[complete].copy().sort_values(['pair','timepoint'])
    # Subject_ID verifies pairing but is unnecessary in the distributable subset.
    m[['sampleID','pair','timepoint','Lesion_origin']].to_csv(out/'paired_metadata.csv',index=False)
    genes=sum(PANELS.values(),[])
    x.loc[genes,m['sampleID']].rename_axis('gene').to_csv(out/'panel_logcpm.csv')
    (out/'panels.json').write_text(json.dumps(PANELS,indent=2)+'\n',encoding='utf-8')
    provenance={'source_doi':'10.5281/zenodo.21218835','creators':'Zacchi, Imbach, Aguilar, Mir Arnau and Mateo (2026)',
        'license':'CC BY 4.0','license_url':'https://creativecommons.org/licenses/by/4.0/',
        'changes':'12-gene, 24-sample extraction from published batch-corrected logCPM; complete subject pairs only. Metadata subset omits Subject_ID.',
        'retrieved':'2026-10-18','source_files':[{k:f[k] for k in ['key','size','checksum']} for f in record['files']]}
    (out/'provenance.json').write_text(json.dumps(provenance,indent=2)+'\n',encoding='utf-8')
    print('Complete pairs:',len(m)//2,'genes:',len(genes))

if __name__=='__main__':run()
