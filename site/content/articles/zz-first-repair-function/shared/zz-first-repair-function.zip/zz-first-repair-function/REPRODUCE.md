# 公開腫瘍pseudobulkの小パネル解析

データ出典：Zacchi, Imbach, Aguilar, Mir Arnau and Mateo (2026), https://doi.org/10.5281/zenodo.21218835 。CC BY 4.0（https://creativecommons.org/licenses/by/4.0/）。本配布物の `inputs/` は公開済みbatch-corrected logCPMから12遺伝子・24検体を抽出し、必要なメタデータのみ付けた改変物です。取得日2026-10-18。元ファイルのチェックサムと改変内容は `inputs/provenance.json`。

これは原著のKEGG HR/E2F ssGSEAやGSEAの再現ではありません。作者が選んだ修復関連6遺伝子と細胞周期関連6遺伝子の記述的集約です。臨床妥当性未検証で、修復機能やHRDを測る指標ではありません。原著には既に遺伝子集合重複を除く感度分析があり、この論点を新発見とは扱いません。

Python 3.11以上で当該ディレクトリから実行：

```sh
python -m pip install -r requirements.txt
python analysis.py
python -m unittest -v test_analysis.py
python plot.py
```

全原データのダウンロードは不要です。`prepare_inputs.py` は原著データを `data/` に別途保存したときに小パネル抽出を再現する補助スクリプトです。公開配布に全原データや論文本文を含めません。

## 定義

- `inputs/panels.json` の2パネルは互いに遺伝子が重複しません。
- 遺伝子ごとに24検体の平均を引き、標本標準偏差（ddof=1）で割り、そのz値をパネル内で平均します。スコアは相対的で、絶対修復能力を表しません。
- 患者の同定には元データのSubject_IDを使い、baseline/on-treatment各1検体がある12人に限定しました。ZZHDST01等の接頭辞が同じでも患者が異なる場合があり、接頭辞からペアを作ってはいけません。公開サブセットのpairは元データのペア注記です。
- 差はon-treatmentからbaselineを引きます。患者内の差同士のPearson相関を計算し、前後を混ぜた横断相関には依存しません。
- 全患者・全遺伝子の固定z値を使い、患者1人除外、遺伝子1個除外、採取部位変更例ZZHDST17除外を感度分析します。除外後の再標準化はしません。平均差の範囲は信頼区間ではありません。
- これらは全員がADT＋enzalutamide導入中の検体です。無作為化されたtalazoparib追加の群間効果を解析するデータではありません。

12人の選別された小集団、作者によるパネル選択、公開元の正規化・バッチ補正に依存します。低下の相関から、細胞周期が修復発現低下の原因であること、修復機能が保たれること、PARP阻害薬が不要であることは証明できません。原著の機能測定と臨床評価を別に読む必要があります。統計的有意性の検定や予後予測は行いません。
