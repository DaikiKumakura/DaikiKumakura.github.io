import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import pandas as pd
from analysis import ROOT

plt.rcParams.update({'font.size':11,'axes.spines.top':False,'axes.spines.right':False})
out=ROOT/'figures';out.mkdir(exist_ok=True)
d=pd.read_csv(ROOT/'results/paired_scores.csv')
fig,ax=plt.subplots(figsize=(6.7,5.2))
for _,r in d.iterrows():
    ax.scatter(r.cycle_delta,r.repair_delta,s=60,marker='o' if r.same_site else 'D',color='#24638b' if r.same_site else '#c25724')
    ax.annotate(r.pair.replace('ZZHDST',''),(r.cycle_delta,r.repair_delta),xytext=(5,3),textcoords='offset points',fontsize=9)
ax.axhline(0,color='gray',lw=.8);ax.axvline(0,color='gray',lw=.8)
ax.set(xlabel='Cycle panel change (on - baseline)',ylabel='Repair panel change (on - baseline)',title='Within-patient changes: 12 complete pairs')
ax.text(.02,.97,'Pearson r = 0.735\nDiamond: biopsy site changed',transform=ax.transAxes,va='top',fontsize=10)
fig.text(.5,.015,'Author-selected, nonvalidated mean gene-z scores. Not repair function.',ha='center',fontsize=9)
fig.tight_layout(rect=(0,.04,1,1));fig.savefig(out/'paired-panel-changes.png',dpi=180);plt.close(fig)

fig,axes=plt.subplots(1,2,figsize=(10,4.8),sharey=True)
for ax,panel,label in zip(axes,['repair','cycle'],['Repair panel','Cycle panel']):
    for _,r in d.iterrows():
        ax.plot([0,1],[r[panel+'_baseline'],r[panel+'_on']],color='#24638b' if r.same_site else '#c25724',alpha=.65,marker='o',lw=1)
    ax.plot([0,1],[d[panel+'_baseline'].mean(),d[panel+'_on'].mean()],color='black',lw=3,marker='s',label='Mean')
    ax.set(xticks=[0,1],xticklabels=['Baseline','On treatment'],title=label,xlim=(-.1,1.1))
    ax.legend(frameon=False);ax.grid(axis='y',alpha=.15)
axes[0].set_ylabel('Mean gene-z score (fixed 24-specimen scaling)')
fig.text(.5,.015,'12 pairs; orange: biopsy site changed. Panels contain six disjoint genes each.',ha='center',fontsize=9)
fig.tight_layout(rect=(0,.04,1,1));fig.savefig(out/'paired-panel-trajectories.png',dpi=180);plt.close(fig)
