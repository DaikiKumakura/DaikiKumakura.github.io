"""Descriptive, nonvalidated two-panel analysis; no repair function inference."""
from pathlib import Path
import json
import numpy as np
import pandas as pd

ROOT=Path(__file__).resolve().parent

def gene_z(x):
    sd=x.std(axis=1,ddof=1)
    if (sd<=0).any() or not np.isfinite(x.to_numpy()).all():raise ValueError('invalid expression')
    return x.sub(x.mean(axis=1),axis=0).div(sd,axis=0)

def paired_deltas(z,metadata,panels):
    if set(panels['repair'])&set(panels['cycle']):raise ValueError('overlapping panels')
    scores=pd.DataFrame({name:z.loc[genes].mean(axis=0) for name,genes in panels.items()})
    rows=[]
    for pair,g in metadata.groupby('pair',sort=True):
        if len(g)!=2 or set(g.timepoint)!={'baseline','on-treatment'}:raise ValueError('incomplete pair')
        b=g[g.timepoint=='baseline'].iloc[0];o=g[g.timepoint=='on-treatment'].iloc[0]
        row={'pair':pair,'same_site':bool(b.Lesion_origin==o.Lesion_origin)}
        for panel in panels:
            row[panel+'_baseline']=float(scores.loc[b.sampleID,panel])
            row[panel+'_on']=float(scores.loc[o.sampleID,panel])
            row[panel+'_delta']=row[panel+'_on']-row[panel+'_baseline']
        rows.append(row)
    return pd.DataFrame(rows)

def describe(d):
    return {'n_pairs':len(d),'mean_repair_delta':float(d.repair_delta.mean()),
            'mean_cycle_delta':float(d.cycle_delta.mean()),
            'median_repair_delta':float(d.repair_delta.median()),
            'median_cycle_delta':float(d.cycle_delta.median()),
            'repair_decreases':int((d.repair_delta<0).sum()),
            'cycle_decreases':int((d.cycle_delta<0).sum()),
            'delta_pearson_r':float(d.repair_delta.corr(d.cycle_delta))}

def run():
    inp=ROOT/'inputs';out=ROOT/'results';out.mkdir(exist_ok=True)
    x=pd.read_csv(inp/'panel_logcpm.csv',index_col=0)
    m=pd.read_csv(inp/'paired_metadata.csv');panels=json.loads((inp/'panels.json').read_text())
    if set(x.columns)!=set(m.sampleID):raise ValueError('metadata mismatch')
    z=gene_z(x);d=paired_deltas(z,m,panels)
    d.to_csv(out/'paired_scores.csv',index=False)
    patient=[]
    # Fixed score definition: do not rescale the expression after dropping a patient.
    for pair in d.pair:patient.append({'excluded_pair':pair,**describe(d[d.pair!=pair])})
    pd.DataFrame(patient).to_csv(out/'patient_leave_one_out.csv',index=False)
    genes=[]
    for panel,members in panels.items():
        for gene in members:
            altered={k:[g for g in v if g!=gene] for k,v in panels.items()}
            genes.append({'excluded_panel':panel,'excluded_gene':gene,**describe(paired_deltas(z,m,altered))})
    pd.DataFrame(genes).to_csv(out/'gene_leave_one_out.csv',index=False)
    summary={'type':'exploratory descriptive analysis of public tumor pseudobulk logCPM',
        'score':'mean of within-gene z values; sample SD across all 24 paired specimens',
        'panels':'author-selected nonvalidated disjoint 6-gene panels, not KEGG/E2F ssGSEA',
        'full':describe(d),'same_site_only_fixed_scaling':describe(d[d.same_site]),
        'patient_loo':{k:[float(min(a[k] for a in patient)),float(max(a[k] for a in patient))] for k in ['mean_repair_delta','mean_cycle_delta','delta_pearson_r']},
        'gene_loo':{k:[float(min(a[k] for a in genes)),float(max(a[k] for a in genes))] for k in ['mean_repair_delta','mean_cycle_delta','delta_pearson_r']},
        'limitations':['No validated HRR functional score','No randomization contrast in these lead-in samples',
                       'No causal decomposition of proliferation versus repair','Selected small paired subset',
                       'One pair changes biopsy site','Author-provided normalization and batch correction not rerun']}
    (out/'summary.json').write_text(json.dumps(summary,indent=2)+'\n',encoding='utf-8');print(json.dumps(summary,indent=2))

if __name__=='__main__':run()
