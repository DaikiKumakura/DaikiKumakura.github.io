# M13-1：資料・データ監査（非公開の制作記録）

2026-10-05。取得区分：R（公表PopPKモデル）＋公開の体重分布（NHANES）。登録・同意が必要な資料は使わない。

## 一次資料

| 資料 | 入手 | 使う内容 | ハッシュ |
| --- | --- | --- | --- |
| Ahamadi M, et al. Model-based characterization of the pharmacokinetics of pembrolizumab. CPT Pharmacometrics Syst Pharmacol 2017;6:49–57. doi:10.1002/psp4.12139（PMC5270291、OA） | Europe PMC REST（fullTextXML） | Table 3：最終モデルの推定値 | `sources/SHA256SUMS` |
| Bajaj G, et al. Model-based population pharmacokinetic analysis of nivolumab in patients with solid tumors. CPT Pharmacometrics Syst Pharmacol 2017;6:58–66. doi:10.1002/psp4.12143（PMC5270302、OA） | Europe PMC REST（fullTextXML） | Table 1：最終モデルの推定値、式(7)–(10)、本文の体重範囲 | 同上 |
| NHANES 2017–March 2020 Pre-pandemic：Body Measures（P_BMX）、Demographics（P_DEMO） | CDC公開ファイル（登録不要、パブリックドメイン） | 成人の体重・性・調査重み（WTMECPRP）・人種（RIDRETH3） | 同上 |

PMCのHTMLはCAPTCHAが表示されたため使わず、Europe PMCの公開APIから全文XMLを取得した。

## Pembrolizumab（Ahamadi 2017、Table 3）

2-compartment、線形、時間不変CL。KEYNOTE-001/002/006の2,195例。

| 項目 | 値 |
| --- | --- |
| CL | 0.22 L/day |
| Vc | 3.48 L |
| Q | 0.795 L/day |
| Vp | 4.06 L |
| 体重の指数（CL・Q） | 0.595（95% CI 0.506–0.686） |
| 体重の指数（Vc・Vp） | 0.489（0.431–0.545） |
| 基準体重 | 76.8 kg（脚注aの式より） |
| 性（女性）on CL | −0.152（女性で ×(1−0.152)） |
| 性（女性）on Vc | −0.134 |
| ALB on CL | −0.907（基準39.6 g/L） |
| IIV CL・Q | ω² 0.134（38% CV） |
| IIV Vc・Vp | ω² 0.0417（21% CV） |
| 残差 | 0.272（対数スケール加算） |

**不一致：** Table 3の脚注aの式は `CL = 0.202 (WGT/76.8)^0.578 × (ALB/39.6)^(−0.854) × …` で、本表（CL 0.22、指数0.595、ALB −0.907）と数値が異なる。どちらが最終値かは本文から決められない。**主解析は本表の値**、脚注の値（CL 0.202、指数0.578）を感度解析に使う。体重の分布（中央値・範囲）は論文に記載がない。

## Nivolumab（Bajaj 2017、Table 1）

2-compartment、0次点滴、線形、時間変化するCL（sigmoid Emax）。11試験の1,895例、0.3–10 mg/kg。

| 項目 | 値 |
| --- | --- |
| CL_REF | 9.4 mL/h（= 0.2256 L/day） |
| VC_REF | 3.63 L |
| Q_REF | 32.1 mL/h |
| VP_REF | 2.78 L |
| CL_BW | 0.566（0.479–0.658） |
| VC_BW | 0.597（0.514–0.681） |
| 基準 | 白人女性、80 kg、eGFR 90、PS 0（脚注a） |
| CL_SEX | 0.165（式(7)：×exp(0.165·SEX)、男性=1と解釈） |
| VC_SEX | 0.152 |
| CL_EMAX | −0.295、T50 1.41×10³ h、Hill 3.15（式(8)） |
| ω² CL / VC / VP / EMAX | 0.123 / 0.123 / 0.258 / 0.0719 |
| cov(CL, VC) | 0.0432（相関0.352） |
| 残差 | 比例0.215 |
| 体重 | 平均79.09 kg（SD 19.28）、範囲34.1–168.2 kg（本文） |

**解釈上の注意：** SEXの符号化（男性=1）は本文「男性でCLが18%高い」と exp(0.165)=1.18 の一致から判断した。Q と VP の体重効果は表にない（式(7)(10)にも無い）ため、体重に依存させない。

## NHANES（体重分布）

- 成人（18歳以上）で体重と調査重みがある 8,811 人。調査重み付きの体重の分位：1% 46.4 kg、5% 53.2 kg、50% 80.4 kg、95% 126.1 kg、99% 157.6 kg。範囲 32.6–254.3 kg。
- 中央値は男性85.0 kg、女性74.1 kg。
- 米国の一般成人であり、がん患者の体重分布ではない。がん患者の試験集団（nivolumabでは平均79.1 kg、範囲34–168 kg）とは異なりうるため、体重帯ごとの結果を主に示し、集団全体の割合は参考とする。より軽い集団の感度として、NHANESの非ヒスパニック系アジア人（RIDRETH3=6）を使う。

## 判定

続行。2剤とも、体重の指数・IIV・性の効果が一次資料の表から取れ、体重分布は公開データで得られる。脚注との不一致は感度解析で扱う。
