# 抗PD-1抗体の固定用量と体重換算：配布資料

記事「抗PD-1抗体の固定用量は、極端な体重の患者でも曝露を保てるか」の再実行用資料。

## 含むもの

- `analysis-plan.md`：問い・使いみち・範囲の定義・判定規則・感度解析（計算前に固定）
- `data-audit.md`：使った公表モデルのパラメータと、論文の表と脚注の不一致の記録
- `analysis.R`, `test_analysis.R`, `figures.R`：実装、10件の検査、図
- `export_params.R`, `validate.py`：独立の再計算（Pythonで投与ごとに微分方程式を積分）と公表値との比較
- `results/`：体重帯別の割合、下限・上限、極端な体重、感度解析、事後のCavg確認、検証結果
- `figures/`：記事の図
- `sources/SHA256SUMS`：入力ファイルのハッシュ

患者のデータは含まない。NHANESのファイルと論文の全文XMLは含めていないので、次から取得して `sources/` に置く。

- NHANES 2017–March 2020 Pre-Pandemic：`P_BMX.xpt`、`P_DEMO.xpt`（https://wwwn.cdc.gov/Nchs/Data/Nhanes/Public/2017/DataFiles/ ）
- 公表モデルの数値は `data-audit.md` に転記してあり、実行に全文XMLは不要。

## 実行

1. `Rscript test_analysis.R`（R 4.5.3、rxode2 5.1.8、foreign）
2. `Rscript analysis.R` → `results/`（約6分。仮想患者の曝露 `exposures-*.csv` も作る）
3. `Rscript figures.R`（ggplot2）→ `figures/`
4. `Rscript export_params.R` と `python validate.py`（Python 3.12、numpy、scipy、pandas）→ `results/validation.json`

seedは固定してある。結果は曝露の比較であり、用量の推奨や臨床便益の評価ではない。
