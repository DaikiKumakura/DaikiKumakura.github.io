# M13: fixed versus weight-based dosing of anti-PD-1 antibodies.
# Re-implements published population PK models (pembrolizumab: Ahamadi 2017
# Table 3; nivolumab: Bajaj 2017 Table 1) and computes exposures for a
# virtual population drawn from NHANES 2017-March 2020 adult body weights.
# Run from this folder: Rscript analysis.R  (tests: Rscript test_analysis.R)

suppressMessages(library(rxode2))

# ---------------------------------------------------------------------------
# Models (time in days, amounts in mg, volumes in L, concentrations in mg/L)

pk_model <- rxode2({
  CLt <- CL * exp(EMAX * (t * 24)^HILL / (T50^HILL + (t * 24)^HILL))
  d/dt(centr) <- -CLt / V1 * centr - Q / V1 * centr + Q / V2 * peri
  d/dt(peri) <- Q / V1 * centr - Q / V2 * peri
  cp <- centr / V1
  d/dt(auc) <- cp
})

PEMBRO <- list(drug = "pembrolizumab", cl = 0.22, v1 = 3.48, q = 0.795, v2 = 4.06,
               e_cl = 0.595, e_v = 0.489, wref = 76.8,
               female_cl = -0.152, female_v = -0.134, alb_cl = -0.907, alb_ref = 39.6,
               om_cl = 0.134, om_v = 0.0417)
NIVO <- list(drug = "nivolumab", cl = 9.4 * 24 / 1000, v1 = 3.63, q = 32.1 * 24 / 1000, v2 = 2.78,
             e_cl = 0.566, e_v = 0.597, wref = 80, male_cl = 0.165, male_v = 0.152,
             emax = -0.295, t50 = 1410, hill = 3.15,
             om_cl = 0.123, om_v = 0.123, om_vp = 0.258, om_emax = 0.0719, cov_cl_v = 0.0432)

REGIMENS <- list(
  pembrolizumab = list(
    `2 mg/kg Q3W` = list(tau = 21, per_kg = 2),
    `200 mg Q3W` = list(tau = 21, fixed = 200),
    `400 mg Q6W` = list(tau = 42, fixed = 400),
    `10 mg/kg Q2W` = list(tau = 14, per_kg = 10)),
  nivolumab = list(
    `3 mg/kg Q2W` = list(tau = 14, per_kg = 3),
    `240 mg Q2W` = list(tau = 14, fixed = 240),
    `480 mg Q4W` = list(tau = 28, fixed = 480),
    `10 mg/kg Q2W` = list(tau = 14, per_kg = 10)))
REFERENCE <- c(pembrolizumab = "2 mg/kg Q3W", nivolumab = "3 mg/kg Q2W")
CEILING_REGIMEN <- "10 mg/kg Q2W"
BANDS <- c(0, 50, 60, 80, 100, 120, 150, Inf)
SS_START <- 364   # steady-state window: first full interval starting on or after day 364
INF_DUR <- 30 / (60 * 24)

# ---------------------------------------------------------------------------
# Virtual population

read_nhanes <- function(dir = "sources") {
  b <- foreign::read.xport(file.path(dir, "P_BMX.xpt"))
  d <- foreign::read.xport(file.path(dir, "P_DEMO.xpt"))
  x <- merge(d[, c("SEQN", "RIDAGEYR", "RIAGENDR", "RIDRETH3", "WTMECPRP")], b[, c("SEQN", "BMXWT")], by = "SEQN")
  x <- x[x$RIDAGEYR >= 18 & !is.na(x$BMXWT) & !is.na(x$WTMECPRP) & x$WTMECPRP > 0, ]
  data.frame(wt = x$BMXWT, female = as.integer(x$RIAGENDR == 2), asian = as.integer(x$RIDRETH3 == 6),
             svy = x$WTMECPRP)
}

sample_population <- function(nh, n, seed, subset = NULL) {
  if (!is.null(subset)) nh <- nh[subset(nh), ]
  set.seed(seed)
  idx <- sample.int(nrow(nh), n, replace = TRUE, prob = nh$svy)
  nh[idx, c("wt", "female")]
}

# Random effects, drawn once per drug and reused across scenarios
draw_etas <- function(drug, n, seed) {
  set.seed(seed)
  if (drug$drug == "pembrolizumab") {
    data.frame(e_cl = rnorm(n, 0, sqrt(drug$om_cl)), e_v = rnorm(n, 0, sqrt(drug$om_v)))
  } else {
    S <- matrix(c(drug$om_cl, drug$cov_cl_v, drug$cov_cl_v, drug$om_v), 2)
    z <- matrix(rnorm(2 * n), n) %*% chol(S)
    data.frame(e_cl = z[, 1], e_v = z[, 2], e_vp = rnorm(n, 0, sqrt(drug$om_vp)),
               e_emax = rnorm(n, 0, sqrt(drug$om_emax)))
  }
}

# Individual parameters for a population and scenario modifications
individual_parameters <- function(drug, pop, eta, sc = list()) {
  e_cl <- if (is.null(sc$e_cl)) drug$e_cl else sc$e_cl
  e_v <- if (is.null(sc$e_v)) drug$e_v else sc$e_v
  cl_typ <- if (is.null(sc$cl)) drug$cl else sc$cl
  female <- if (isTRUE(sc$ignore_sex)) rep(sc$ref_female, nrow(pop)) else pop$female
  w <- pop$wt / drug$wref
  if (drug$drug == "pembrolizumab") {
    alb <- if (is.null(sc$alb)) drug$alb_ref else sc$alb
    cl <- cl_typ * w^e_cl * (1 + drug$female_cl * female) * (alb / drug$alb_ref)^drug$alb_cl * exp(eta$e_cl)
    q <- drug$q * w^e_cl * exp(eta$e_cl)
    v1 <- drug$v1 * w^e_v * (1 + drug$female_v * female) * exp(eta$e_v)
    v2 <- drug$v2 * w^e_v * exp(eta$e_v)
    data.frame(CL = cl, V1 = v1, Q = q, V2 = v2, EMAX = 0, T50 = 1, HILL = 1)
  } else {
    male <- 1 - female
    cl <- cl_typ * w^e_cl * exp(drug$male_cl * male) * exp(eta$e_cl)
    v1 <- drug$v1 * w^e_v * exp(drug$male_v * male) * exp(eta$e_v)
    v2 <- drug$v2 * exp(eta$e_vp)
    emax <- if (isTRUE(sc$no_time_varying)) 0 else drug$emax + eta$e_emax
    data.frame(CL = cl, V1 = v1, Q = drug$q, V2 = v2, EMAX = emax, T50 = drug$t50, HILL = drug$hill)
  }
}

# Concentrations after repeated 1 mg doses (linear PK): Cmin1, Cmax_ss, Cmin_ss, Cavg_ss
unit_exposure <- function(params, tau) {
  n_dose <- ceiling(SS_START / tau) + 2
  ss0 <- ceiling(SS_START / tau) * tau
  ev <- et(amt = 1, dur = INF_DUR, ii = tau, addl = n_dose - 1, cmt = "centr")
  obs <- c(tau - 1e-4, ss0, ss0 + INF_DUR, ss0 + tau - 1e-4)
  ev <- et(ev, obs)
  s <- suppressMessages(rxSolve(pk_model, params = params, events = ev, returnType = "data.frame",
                                atol = 1e-10, rtol = 1e-8))
  id <- if ("sim.id" %in% names(s)) s$sim.id else rep(1L, nrow(s))
  s <- s[order(id, s$time), ]
  m <- matrix(s$cp, ncol = 4, byrow = TRUE)
  a <- matrix(s$auc, ncol = 4, byrow = TRUE)
  data.frame(cmin1 = m[, 1], cmax_ss = m[, 3], cmin_ss = m[, 4], cavg_ss = (a[, 4] - a[, 2]) / tau)
}

# Exposures for all regimens of a drug
regimen_exposures <- function(drug, pop, eta, sc = list()) {
  par <- individual_parameters(drug, pop, eta, sc)
  regs <- REGIMENS[[drug$drug]]
  taus <- unique(vapply(regs, `[[`, numeric(1), "tau"))
  unit <- lapply(stats::setNames(taus, taus), function(tau) unit_exposure(par, tau))
  do.call(rbind, lapply(names(regs), function(r) {
    g <- regs[[r]]
    dose <- if (!is.null(g$fixed)) rep(g$fixed, nrow(pop)) else g$per_kg * pop$wt
    u <- unit[[as.character(g$tau)]]
    data.frame(regimen = r, wt = pop$wt, female = pop$female, dose = dose,
               cmin1 = u$cmin1 * dose, cmax_ss = u$cmax_ss * dose,
               cmin_ss = u$cmin_ss * dose, cavg_ss = u$cavg_ss * dose)
  }))
}

thresholds <- function(ex, drug_name) {
  ref <- ex[ex$regimen == REFERENCE[[drug_name]], ]
  top <- ex[ex$regimen == CEILING_REGIMEN, ]
  c(floor = unname(stats::quantile(ref$cmin_ss, 0.05)),
    floor1 = unname(stats::quantile(ref$cmin1, 0.05)),
    ceiling = unname(stats::median(top$cmax_ss)))
}

band_summary <- function(ex, thr, drug_name) {
  ex <- ex[ex$regimen != CEILING_REGIMEN, ]
  ex$band <- cut(ex$wt, BANDS, right = FALSE,
                 labels = c("<50", "50-60", "60-80", "80-100", "100-120", "120-150", ">=150"))
  ref <- ex[ex$regimen == REFERENCE[[drug_name]], ]
  out <- aggregate(cbind(below_floor = cmin_ss < thr[["floor"]], above_ceiling = cmax_ss > thr[["ceiling"]],
                         below_floor_cycle1 = cmin1 < thr[["floor1"]]) ~ regimen + band, data = ex, FUN = mean)
  n <- aggregate(wt ~ regimen + band, data = ex, FUN = length)
  med <- aggregate(cbind(cmin_ss, cavg_ss, cmax_ss) ~ regimen + band, data = ex, FUN = stats::median)
  out <- merge(merge(out, n, by = c("regimen", "band")), med, by = c("regimen", "band"))
  names(out)[names(out) == "wt"] <- "n"
  out$protected <- out$below_floor <= 0.10 & out$above_ceiling <= 0.05
  out[order(out$regimen, out$band), ]
}

overall_summary <- function(ex, thr) {
  ex <- ex[ex$regimen != CEILING_REGIMEN, ]
  aggregate(cbind(below_floor = cmin_ss < thr[["floor"]], above_ceiling = cmax_ss > thr[["ceiling"]]) ~ regimen,
            data = ex, FUN = mean)
}

# Fixed-weight virtual patients (40 and 160 kg), half female
fixed_weight_population <- function(weights, n_each) {
  do.call(rbind, lapply(weights, function(w) data.frame(wt = w, female = rep(0:1, length.out = n_each))))
}

# ---------------------------------------------------------------------------

run_all <- function(n = 20000, seed = 20261005, out = "results") {
  dir.create(out, showWarnings = FALSE)
  nh <- read_nhanes()
  pop <- sample_population(nh, n, seed)
  pop_asian <- sample_population(nh, n, seed + 1, subset = function(d) d$asian == 1)
  extremes <- fixed_weight_population(c(40, 160), 5000)
  scenarios <- list(
    main = list(),
    pembro_footnote = list(drug = "pembrolizumab", cl = 0.202, e_cl = 0.578),
    exponent_low = list(e_cl = c(pembrolizumab = 0.506, nivolumab = 0.479)),
    exponent_high = list(e_cl = c(pembrolizumab = 0.686, nivolumab = 0.658)),
    asian_weights = list(population = "asian"),
    ignore_sex = list(ignore_sex = TRUE),
    pembro_low_albumin = list(drug = "pembrolizumab", alb = 30),
    nivo_constant_cl = list(drug = "nivolumab", no_time_varying = TRUE))
  bands <- list(); overall <- list(); thr_all <- list(); ext <- list()
  for (drug in list(PEMBRO, NIVO)) {
    eta <- draw_etas(drug, n, seed + 10)
    eta_ext <- draw_etas(drug, nrow(extremes), seed + 20)
    main_thr <- NULL
    for (sn in names(scenarios)) {
      sc <- scenarios[[sn]]
      if (!is.null(sc$drug) && sc$drug != drug$drug) next
      if (!is.null(sc$e_cl) && length(sc$e_cl) > 1) sc$e_cl <- sc$e_cl[[drug$drug]]
      sc$ref_female <- if (drug$drug == "pembrolizumab") 0 else 1   # reference sex of each model
      p <- if (identical(sc$population, "asian")) pop_asian else pop
      ex <- regimen_exposures(drug, p, eta, sc)
      thr <- if (identical(sc$population, "asian")) main_thr else thresholds(ex, drug$drug)
      if (sn == "main") main_thr <- thr
      b <- band_summary(ex, thr, drug$drug); b$drug <- drug$drug; b$scenario <- sn
      o <- overall_summary(ex, thr); o$drug <- drug$drug; o$scenario <- sn
      bands[[length(bands) + 1]] <- b; overall[[length(overall) + 1]] <- o
      thr_all[[length(thr_all) + 1]] <- data.frame(drug = drug$drug, scenario = sn, t(thr))
      if (sn == "main") {
        exe <- regimen_exposures(drug, extremes, eta_ext, sc)
        exe <- exe[exe$regimen != CEILING_REGIMEN, ]
        e <- aggregate(cbind(below_floor = cmin_ss < thr[["floor"]], above_ceiling = cmax_ss > thr[["ceiling"]],
                             below_floor_cycle1 = cmin1 < thr[["floor1"]]) ~ regimen + wt, data = exe, FUN = mean)
        e$drug <- drug$drug
        ext[[length(ext) + 1]] <- e
        utils::write.csv(ex, file.path(out, paste0("exposures-", drug$drug, ".csv")), row.names = FALSE)
      }
    }
  }
  bands <- do.call(rbind, bands); overall <- do.call(rbind, overall)
  thr_all <- do.call(rbind, thr_all); ext <- do.call(rbind, ext)
  utils::write.csv(bands, file.path(out, "bands.csv"), row.names = FALSE)
  utils::write.csv(overall, file.path(out, "overall.csv"), row.names = FALSE)
  utils::write.csv(thr_all, file.path(out, "thresholds.csv"), row.names = FALSE)
  utils::write.csv(ext, file.path(out, "extreme-weights.csv"), row.names = FALSE)
  pop_q <- data.frame(population = c("NHANES adults", "NHANES non-Hispanic Asian"),
                      rbind(stats::quantile(pop$wt, c(0.01, 0.05, 0.5, 0.95, 0.99)),
                            stats::quantile(pop_asian$wt, c(0.01, 0.05, 0.5, 0.95, 0.99))), check.names = FALSE)
  utils::write.csv(pop_q, file.path(out, "population-weights.csv"), row.names = FALSE)
  invisible(list(bands = bands, overall = overall, thresholds = thr_all, extremes = ext))
}

if (sys.nframe() == 0L) {
  r <- run_all()
  print(r$thresholds)
  print(r$overall)
  print(r$extremes)
}
