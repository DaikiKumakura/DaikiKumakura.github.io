# Figures and the post-hoc Cavg check for M13. Run after analysis.R.
suppressMessages(library(ggplot2))
dir.create("figures", showWarnings = FALSE)
thr <- read.csv("results/thresholds.csv")
bands <- read.csv("results/bands.csv", check.names = FALSE)
band_levels <- c("<50", "50-60", "60-80", "80-100", "100-120", "120-150", ">=150")
reg_levels <- c("2 mg/kg Q3W", "200 mg Q3W", "400 mg Q6W", "3 mg/kg Q2W", "240 mg Q2W", "480 mg Q4W")

ex <- rbind(read.csv("results/exposures-pembrolizumab.csv", check.names = FALSE),
            read.csv("results/exposures-nivolumab.csv", check.names = FALSE))
ex$drug <- ifelse(ex$regimen %in% c("2 mg/kg Q3W", "200 mg Q3W", "400 mg Q6W") |
                    (ex$regimen == "10 mg/kg Q2W" & seq_len(nrow(ex)) <= nrow(read.csv("results/exposures-pembrolizumab.csv"))),
                  "pembrolizumab", "nivolumab")
ex <- ex[ex$regimen != "10 mg/kg Q2W", ]
ex$band <- factor(as.character(cut(ex$wt, c(0, 50, 60, 80, 100, 120, 150, Inf), right = FALSE, labels = band_levels)),
                  levels = band_levels)
ex$regimen <- factor(ex$regimen, levels = reg_levels)

# Figure 1: Cmin,ss by weight band (median and 5th-95th percentiles) with the floor
q <- aggregate(cmin_ss ~ drug + regimen + band, ex, function(v) stats::quantile(v, c(0.05, 0.5, 0.95)))
q <- data.frame(q[, 1:3], lo = q$cmin_ss[, 1], med = q$cmin_ss[, 2], hi = q$cmin_ss[, 3])
fl <- thr[thr$scenario == "main", c("drug", "floor")]
p1 <- ggplot(q, aes(band, med, colour = regimen, group = regimen)) +
  geom_pointrange(aes(ymin = lo, ymax = hi), position = position_dodge(width = 0.6), size = 0.3) +
  geom_hline(data = fl, aes(yintercept = floor), linetype = 2, colour = "grey30") +
  facet_wrap(~drug, scales = "free_y") + scale_y_log10() +
  labs(x = "Body weight (kg)", y = "Steady-state trough (mg/L, log)", colour = NULL,
       caption = "Points: median; bars: 5th-95th percentiles. Dashed line: floor (5th percentile under the weight-based reference regimen).") +
  theme_bw(base_size = 10) + theme(legend.position = "bottom", axis.text.x = element_text(angle = 30, hjust = 1))
ggsave("figures/01-trough-by-weight.png", p1, width = 8, height = 4.4, dpi = 150)

# Figure 2: probability below the floor by weight band, main analysis
bm <- bands[bands$scenario == "main", ]
bm$band <- factor(bm$band, levels = band_levels); bm$regimen <- factor(bm$regimen, levels = reg_levels)
p2 <- ggplot(bm, aes(band, 100 * below_floor, fill = regimen)) +
  geom_col(position = position_dodge(width = 0.75), width = 0.7) +
  geom_hline(yintercept = 10, linetype = 2) +
  facet_wrap(~drug) +
  labs(x = "Body weight (kg)", y = "Below the floor (%)", fill = NULL,
       caption = "Dashed line: 10%, the limit used in the judgement rule.") +
  theme_bw(base_size = 10) + theme(legend.position = "bottom", axis.text.x = element_text(angle = 30, hjust = 1))
ggsave("figures/02-below-floor-by-weight.png", p2, width = 8, height = 4.2, dpi = 150)

# Post-hoc (not in the analysis plan): the same check on Cavg,ss instead of Cmin,ss
ref <- c(pembrolizumab = "2 mg/kg Q3W", nivolumab = "3 mg/kg Q2W")
post <- do.call(rbind, lapply(names(ref), function(d) {
  e <- ex[ex$drug == d, ]
  floor_avg <- stats::quantile(e$cavg_ss[e$regimen == ref[[d]]], 0.05)
  a <- aggregate(cbind(below_cavg_floor = cavg_ss < floor_avg) ~ regimen + band, e, mean)
  a$drug <- d; a$cavg_floor <- unname(floor_avg)
  a[a$regimen %in% unique(e$regimen), ]
}))
post <- post[order(post$drug, post$regimen, post$band), ]
write.csv(post, "results/posthoc-cavg.csv", row.names = FALSE)
print(post[post$band %in% c("<50", "80-100", ">=150"), ])

# Figure 3: sensitivity of the judgement for the fixed regimens at the heaviest band
sens <- bands[bands$band == ">=150" & bands$regimen %in% c("200 mg Q3W", "240 mg Q2W"), ]
sens$scenario <- factor(sens$scenario, levels = rev(unique(bands$scenario)))
p3 <- ggplot(sens, aes(100 * below_floor, scenario)) + geom_point() +
  geom_vline(xintercept = 10, linetype = 2) + facet_wrap(~regimen) +
  labs(x = "Below the floor at >=150 kg (%)", y = NULL) + theme_bw(base_size = 10)
ggsave("figures/03-sensitivity-heavy.png", p3, width = 7, height = 3.4, dpi = 150)
cat("figures written\n")
