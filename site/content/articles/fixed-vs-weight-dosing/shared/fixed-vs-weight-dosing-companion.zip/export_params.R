# Exports individual parameters of the first 300 virtual patients of the main
# analysis (same seeds as analysis.R) for the independent check in validate.py.
source("analysis.R")
n <- 20000; seed <- 20261005
nh <- read_nhanes()
pop <- sample_population(nh, n, seed)
out <- list()
for (drug in list(PEMBRO, NIVO)) {
  eta <- draw_etas(drug, n, seed + 10)
  sc <- list(ref_female = if (drug$drug == "pembrolizumab") 0 else 1)
  par <- individual_parameters(drug, pop, eta, sc)[1:300, ]
  par$drug <- drug$drug; par$wt <- pop$wt[1:300]; par$id <- 1:300
  out[[drug$drug]] <- par
}
write.csv(do.call(rbind, out), "results/validation-params.csv", row.names = FALSE)
cat("exported\n")
