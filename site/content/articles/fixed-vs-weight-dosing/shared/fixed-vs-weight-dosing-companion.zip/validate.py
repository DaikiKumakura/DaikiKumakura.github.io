"""Independent checks of the M13 results (Python; scipy). Run after analysis.R and export_params.R.

1. Pharmacokinetics: for every 10th of the first 300 virtual patients of each drug, recompute the
   first-interval and steady-state exposures by direct numerical integration of the dose-by-dose
   two-compartment system (scipy LSODA, actual dose rather than 1 mg scaling), and compare with the
   rxode2 exposures in results/exposures-*.csv.
2. Summary statistics: recompute the floor/ceiling thresholds and the band probabilities of the main
   analysis directly from the exposure files and compare with results/thresholds.csv and bands.csv.
3. External consistency: exposure ratios against published model-based comparisons (reported, not pass/fail).
"""
import json
from pathlib import Path

import numpy as np
import pandas as pd
from scipy.integrate import solve_ivp

R = Path(__file__).resolve().parent
INF = 30 / (60 * 24)
SS_START = 364
REGIMENS = {"pembrolizumab": {"2 mg/kg Q3W": (21, None, 2), "200 mg Q3W": (21, 200, None), "400 mg Q6W": (42, 400, None),
                              "10 mg/kg Q2W": (14, None, 10)},
            "nivolumab": {"3 mg/kg Q2W": (14, None, 3), "240 mg Q2W": (14, 240, None), "480 mg Q4W": (28, 480, None),
                          "10 mg/kg Q2W": (14, None, 10)}}


def rates(t, p):
    cl = p.CL * np.exp(p.EMAX * (t * 24) ** p.HILL / (p.T50 ** p.HILL + (t * 24) ** p.HILL))
    return cl / p.V1, p.Q / p.V1, p.Q / p.V2


def unit_exposure(p, tau):
    """General solution by numerical integration (handles time-varying CL)."""
    n_ss = int(np.ceil(SS_START / tau))
    ss0 = n_ss * tau

    def f(t, y, infusing):
        k10, k12, k21 = rates(t, p)
        inp = 1 / INF if infusing else 0.0
        c, pe, auc = y
        return [inp - (k10 + k12) * c + k21 * pe, k12 * c - k21 * pe, c / p.V1]

    y = np.zeros(3)
    res = {}
    for k in range(n_ss + 1):
        t0 = k * tau
        s = solve_ivp(f, (t0, t0 + INF), y, args=(True,), rtol=1e-10, atol=1e-13, method="LSODA"); y = s.y[:, -1]
        if k == n_ss:
            res["cmax_ss"] = y[0] / p.V1
        s = solve_ivp(f, (t0 + INF, t0 + tau), y, args=(False,), rtol=1e-10, atol=1e-13, method="LSODA"); y = s.y[:, -1]
        if k == 0:
            res["cmin1"] = y[0] / p.V1
        if k == n_ss - 1:
            auc_ss0 = y[2]
        if k == n_ss:
            res["cmin_ss"] = y[0] / p.V1
            res["cavg_ss"] = (y[2] - auc_ss0) / tau
    return res


def check_pk():
    par = pd.read_csv(R / "results/validation-params.csv")
    worst = 0.0; n = 0
    for drug, regs in REGIMENS.items():
        ex = pd.read_csv(R / f"results/exposures-{drug}.csv")
        P = par[par.drug == drug].reset_index(drop=True)
        cache = {}
        for reg, (tau, fixed, perkg) in regs.items():
            rows = ex[ex.regimen == reg].reset_index(drop=True).iloc[:len(P)]
            assert np.allclose(rows.wt.values, P.wt.values), "subject order"
            for i in range(0, len(P), 10):           # every 10th of the 300 patients
                key = (i, tau)
                if key not in cache:
                    cache[key] = unit_exposure(P.iloc[i], tau)
                u = cache[key]
                dose = fixed if fixed else perkg * P.wt[i]
                for m in ("cmin1", "cmax_ss", "cmin_ss", "cavg_ss"):
                    rel = abs(u[m] * dose - rows[m][i]) / rows[m][i]
                    worst = max(worst, rel); n += 1
    return dict(check="PK recomputed by numerical integration (30 patients x 4 regimens x 2 drugs x 4 metrics)",
                comparisons=n, max_relative_difference=worst, ok=bool(worst < 1e-4))


def check_summaries():
    thr = pd.read_csv(R / "results/thresholds.csv"); thr = thr[thr.scenario == "main"].set_index("drug")
    bands = pd.read_csv(R / "results/bands.csv"); bands = bands[bands.scenario == "main"]
    ref = {"pembrolizumab": "2 mg/kg Q3W", "nivolumab": "3 mg/kg Q2W"}
    edges = [0, 50, 60, 80, 100, 120, 150, np.inf]
    labels = ["<50", "50-60", "60-80", "80-100", "100-120", "120-150", ">=150"]
    worst = 0.0
    for drug in ref:
        ex = pd.read_csv(R / f"results/exposures-{drug}.csv")
        r = ex[ex.regimen == ref[drug]]
        # R's default quantile (type 7) equals numpy's linear interpolation
        floor = np.quantile(r.cmin_ss, 0.05); ceiling = np.median(ex[ex.regimen == "10 mg/kg Q2W"].cmax_ss)
        worst = max(worst, abs(floor - thr.loc[drug, "floor"]) / floor, abs(ceiling - thr.loc[drug, "ceiling"]) / ceiling)
        ex = ex[ex.regimen != "10 mg/kg Q2W"].copy()
        ex["band"] = pd.cut(ex.wt, edges, right=False, labels=labels)
        ex["below"] = ex.cmin_ss < floor
        mine = ex.groupby(["regimen", "band"], observed=True)["below"].mean()
        b = bands[bands.drug == drug].set_index(["regimen", "band"]).below_floor
        for k, v in mine.items():
            worst = max(worst, abs(v - b.loc[k]))
    return dict(check="floor/ceiling and band probabilities recomputed from exposure files", max_difference=float(worst),
                ok=bool(worst < 1e-9))


def external():
    n = pd.read_csv(R / "results/exposures-nivolumab.csv"); p = pd.read_csv(R / "results/exposures-pembrolizumab.csv")
    gm = lambda x: float(np.exp(np.log(x).mean()))
    def ratio(df, a, b, m):
        return gm(df[df.regimen == a][m]) / gm(df[df.regimen == b][m])
    q3w_min = min(p[p.regimen == "200 mg Q3W"].cmin_ss.min(), p[p.regimen == "2 mg/kg Q3W"].cmin_ss.min())
    return [
        dict(source="Long 2018 (nivolumab 480 mg Q4W vs 3 mg/kg Q2W)", metric="Cavg,ss ratio", published="similar",
             here=ratio(n, "480 mg Q4W", "3 mg/kg Q2W", "cavg_ss")),
        dict(source="Long 2018", metric="Cmin,ss ratio", published="about 16% lower", here=ratio(n, "480 mg Q4W", "3 mg/kg Q2W", "cmin_ss")),
        dict(source="Long 2018", metric="Cmax,ss ratio", published="about 45% higher", here=ratio(n, "480 mg Q4W", "3 mg/kg Q2W", "cmax_ss")),
        dict(source="Lala 2020 (pembrolizumab 400 mg Q6W vs 200 mg Q3W)", metric="Cavg,ss ratio", published="about 1% higher",
             here=ratio(p, "400 mg Q6W", "200 mg Q3W", "cavg_ss")),
        dict(source="Lala 2020", metric="share of 400 mg Q6W below the lowest Q3W Cmin,ss", published="fewer than 1%",
             here=float((p[p.regimen == "400 mg Q6W"].cmin_ss < q3w_min).mean())),
        dict(source="Lala 2020", metric="Cmax,ss ratio, 400 mg Q6W vs 10 mg/kg Q2W", published="about 65% lower",
             here=ratio(p, "400 mg Q6W", "10 mg/kg Q2W", "cmax_ss")),
    ]


def main():
    checks = [check_pk(), check_summaries()]
    report = dict(status="pass" if all(c["ok"] for c in checks) else "fail", checks=checks, external_consistency=external())
    (R / "results/validation.json").write_text(json.dumps(report, indent=2) + "\n")
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()
