# Checks of the M13 implementation. Run: Rscript test_analysis.R
source("analysis.R")
ok <- function(cond, msg) { if (!isTRUE(cond)) stop("FAILED: ", msg); cat("ok -", msg, "\n") }

# 1. Steady-state average concentration equals dose / (CL * tau) for a
#    time-invariant model (pembrolizumab typical patient, 1 mg every 21 days).
par <- data.frame(CL = 0.22, V1 = 3.48, Q = 0.795, V2 = 4.06, EMAX = 0, T50 = 1, HILL = 1)
u <- unit_exposure(par, 21)
ok(abs(u$cavg_ss - 1 / (0.22 * 21)) / (1 / (0.22 * 21)) < 1e-4, "Cavg,ss = dose/(CL*tau) without time-varying CL")
ok(u$cmax_ss > u$cavg_ss && u$cavg_ss > u$cmin_ss, "Cmax > Cavg > Cmin at steady state")

# 2. With time-varying CL, late Cavg approaches dose / (CL*exp(Emax) * tau).
par2 <- data.frame(CL = 0.2256, V1 = 3.63, Q = 0.7704, V2 = 2.78, EMAX = -0.295, T50 = 1410, HILL = 3.15)
u2 <- unit_exposure(par2, 14)
target <- 1 / (0.2256 * exp(-0.295) * 14)
ok(abs(u2$cavg_ss - target) / target < 0.02, "late Cavg uses the steady-state CL (within 2%)")

# 3. Covariate model reproduces the reference: typical male pembrolizumab
#    patient at 76.8 kg and typical female nivolumab patient at 80 kg.
z <- data.frame(e_cl = 0, e_v = 0, e_vp = 0, e_emax = 0)
p1 <- individual_parameters(PEMBRO, data.frame(wt = 76.8, female = 0), z)
ok(abs(p1$CL - 0.22) < 1e-12 && abs(p1$V1 - 3.48) < 1e-12, "pembrolizumab reference parameters")
p2 <- individual_parameters(NIVO, data.frame(wt = 80, female = 1), z)
ok(abs(p2$CL - 9.4 * 24 / 1000) < 1e-12 && abs(p2$V1 - 3.63) < 1e-12, "nivolumab reference parameters")
p3 <- individual_parameters(NIVO, data.frame(wt = 80, female = 0), z)
ok(abs(p3$CL / p2$CL - exp(0.165)) < 1e-12, "nivolumab male CL is exp(0.165) times female (18% higher)")
p4 <- individual_parameters(PEMBRO, data.frame(wt = 153.6, female = 0), z)
ok(abs(p4$CL / 0.22 - 2^0.595) < 1e-12, "pembrolizumab CL scales with weight^0.595")

# 4. Linear scaling: weight-based dose doubles exposure when weight doubles
#    only to the extent CL does not; fixed dose exposure falls with weight.
pop <- data.frame(wt = c(50, 100), female = 0)
ex <- regimen_exposures(PEMBRO, pop, data.frame(e_cl = 0, e_v = 0))
f <- ex[ex$regimen == "200 mg Q3W", ]; k <- ex[ex$regimen == "2 mg/kg Q3W", ]
ok(f$cavg_ss[1] > f$cavg_ss[2], "fixed dose: lower exposure at higher weight")
ok(abs(k$cavg_ss[2] / k$cavg_ss[1] - 2^(1 - 0.595)) < 1e-3, "per-kg dose: exposure ratio 2^(1-0.595) between 100 and 50 kg")

# 5. NHANES reading
nh <- read_nhanes()
ok(nrow(nh) == 8811 && all(nh$wt > 30), "NHANES adults with weight and survey weight: 8,811")
cat("all tests passed\n")
