"""Checks for event timing, source extraction and reported forecasts."""
import importlib.util
from pathlib import Path
import unittest
import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
spec = importlib.util.spec_from_file_location('analysis_run', ROOT/'analysis/run.py')
run = importlib.util.module_from_spec(spec)
spec.loader.exec_module(run)

class AnalysisTests(unittest.TestCase):
    def test_bolus_estimation_uses_predose_zero(self):
        t=np.array([0., .5, 1.])
        p=np.array([np.log(2.)])
        sampled=run.sample_response(t,p,'bolus')
        self.assertEqual(sampled[0],0.)
        np.testing.assert_allclose(sampled,run.forecast(t,p,'bolus'))

    def test_positive_production_and_equal_rate_limit(self):
        t=np.array([0.,.1,1.])
        k=run.kernel(t,np.array([np.log(2),np.log(.0025)]))
        self.assertEqual(k[0],0)
        np.testing.assert_allclose(k[1:],t[1:]*np.exp(-2*t[1:]),rtol=.002)

    def test_predose_event_and_superposition(self):
        p=np.array([0.,1.])
        np.testing.assert_allclose(run.forecast(np.array([7.]),p,'production'),run.kernel(np.array([7.]),p))
        np.testing.assert_allclose(run.forecast(np.array([7.5]),p,'production'),run.kernel(np.array([7.5]),p)+run.kernel(np.array([.5]),p))

    def test_observation_keys_and_training_split(self):
        d=pd.read_csv(ROOT/'data/processed/pk-observations.csv')
        self.assertEqual(len(d),210)
        self.assertEqual(d.duplicated(['animal_id','study_day']).sum(),0)
        self.assertEqual(d.query("split == 'first_dose'").study_day.max(),8)
        self.assertEqual(d.concentration_ng_ml.eq(0).sum(),91)

    def test_independent_metric_recalculation(self):
        p=pd.read_csv(ROOT/'outputs/tables/predictions.csv')
        m=pd.read_csv(ROOT/'outputs/tables/model-performance.csv')
        for model in ['bolus','production','first_profile_replay']:
            selected=p.query('model == @model and study_day >= 22')
            rmse=np.sqrt(np.mean((selected.observed_ng_ml-selected.predicted_ng_ml)**2))
            recorded=m.query("model == @model and subset == 'fourth_occasion'").rmse_ng_ml.iloc[0]
            self.assertAlmostEqual(rmse,recorded,places=9)

    def test_replay_does_not_estimate_later_observations(self):
        d=pd.read_csv(ROOT/'data/processed/pk-observations.csv')
        p=pd.read_csv(ROOT/'outputs/tables/predictions.csv')
        for animal in d.animal_id.unique():
            first=d.query('animal_id == @animal and study_day == 1.5').concentration_ng_ml.iloc[0]
            forecast=p.query("model == 'first_profile_replay' and animal_id == @animal and study_day == 22.5").predicted_ng_ml.iloc[0]
            self.assertAlmostEqual(first,forecast,places=10)

if __name__=='__main__':unittest.main()
