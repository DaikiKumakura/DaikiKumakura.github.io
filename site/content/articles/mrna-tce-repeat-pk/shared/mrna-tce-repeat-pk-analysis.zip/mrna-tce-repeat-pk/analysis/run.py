"""Fit first-dose TCE observations and forecast later dosing occasions."""
from pathlib import Path
import json
import sys
import hashlib
import numpy as np
import pandas as pd
import openpyxl
from scipy.optimize import least_squares
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

ROOT = Path(__file__).resolve().parents[1]
SEED = 20261028
SOURCE_URL = 'https://media.springernature.com/original/springer-static/esm/art%3A10.1038%2Fs41467-025-66087-y/MediaObjects/41467_2025_66087_MOESM8_ESM.xlsx'

def kernel(t: np.ndarray, p: np.ndarray, model: str = 'production') -> np.ndarray:
    """Ordered empirical rates avoid assigning unidentifiable biological labels."""
    age = np.maximum(np.asarray(t), 0)
    slow = np.exp(p[0])
    if model == 'production':
        fast = slow + np.exp(p[1])
        gap = fast - slow
        return np.exp(-slow * age) * (-np.expm1(-gap * age)) / gap * (np.asarray(t) >= 0)
    return np.exp(-slow * age) * (np.asarray(t) >= 0)

def forecast(t: np.ndarray, rates: np.ndarray, model: str) -> np.ndarray:
    # At an exact predose sample the new dose has not yet been administered.
    return sum(sample_response(np.asarray(t) - day, rates, model) for day in [0, 7, 14, 21])

def sample_response(t: np.ndarray, rates: np.ndarray, model: str) -> np.ndarray:
    """Use the same predose sampling convention in estimation and forecasting."""
    return kernel(np.asarray(t), rates, model) * (np.asarray(t) > 1e-8)

def fit(t: np.ndarray, y: np.ndarray, model: str = 'production', scale: float = 1., exclude_zero: bool = False):
    n_rates = 2 if model == 'production' else 1
    mask = y > 0 if exclude_zero else np.ones(y.shape, bool)
    def residual(p):
        pred = sample_response(t, p[:n_rates], model)[:, None] * np.exp(p[n_rates:])[None, :]
        return (np.arcsinh(pred / scale) - np.arcsinh(y / scale))[mask]
    low = [-6.] * n_rates + [-5.] * y.shape[1]
    high = [6.] * n_rates + [12.] * y.shape[1]
    starts = [[0., 2.], [-1., 1.], [1., 3.]] if n_rates == 2 else [[0.], [1.], [-1.]]
    result = min((least_squares(residual, np.r_[s, np.log(np.maximum(y.max(axis=0), 1) * 2)], bounds=(low, high), max_nfev=1500) for s in starts), key=lambda a: np.sum(a.fun ** 2))
    return result.x[:n_rates], np.exp(result.x[n_rates:]), float(np.sum(result.fun ** 2))

def metrics(observed, predicted):
    return {'rmse_ng_ml': float(np.sqrt(np.mean((observed-predicted)**2))), 'asinh_rmse_scale_1': float(np.sqrt(np.mean((np.arcsinh(observed)-np.arcsinh(predicted))**2))), 'mean_observed_ng_ml':float(np.mean(observed)), 'mean_predicted_ng_ml':float(np.mean(predicted))}

def main():
    for part in ['data/processed','outputs/figures','outputs/tables']:
        (ROOT/part).mkdir(parents=True, exist_ok=True)
    book = openpyxl.load_workbook(ROOT/'data/raw/source-data.xlsx', data_only=True)
    rows = list(book['Fig.6B'].values)
    ids = [str(x) for x in rows[3][2:12]]
    values = np.array([[float(x) for x in row[1:12]] for row in rows[4:]])
    day, y = values[:,0], values[:,1:]
    assert y.shape == (21,10) and np.isfinite(y).all() and (y >= 0).all()
    t = day-1
    train = day <= 8
    # Day 8 is a predose observation. Days 8.5 onward never enter fitting.
    held = day > 8
    fourth = day >= 22
    long = pd.DataFrame([{'animal_id':animal,'study_day':d,'concentration_ng_ml':value,'split':'first_dose' if d <= 8 else 'later_occasions','reported_zero':value == 0} for d, row in zip(day,y) for animal,value in zip(ids,row)])
    long.to_csv(ROOT/'data/processed/pk-observations.csv',index=False)
    summary=[];parameters=[];predictions=[]; fits={}
    for model in ['bolus','production']:
        rates,amp,sse=fit(t[train],y[train],model)
        pred=forecast(t,rates,model)[:,None]*amp
        # The exact first predose point is zero by the event convention.
        fits[model]=(rates,amp,pred)
        for name,selected in [('training',train),('later_occasions',held),('fourth_occasion',fourth)]:
            summary.append({'model':model,'subset':name,'n':int(selected.sum()*10),**metrics(y[selected],pred[selected])})
        for animal,a in zip(ids,amp): parameters.append({'model':model,'animal_id':animal,'amplitude':a,'amplitude_unit':'ng/mL/day' if model=='production' else 'ng/mL','slow_rate_per_day':np.exp(rates[0]),'fast_rate_per_day':np.exp(rates[0])+np.exp(rates[1]) if model=='production' else None})
        for i,d in enumerate(day):
            for j,animal in enumerate(ids):predictions.append({'model':model,'animal_id':animal,'study_day':d,'observed_ng_ml':y[i,j],'predicted_ng_ml':pred[i,j]})
    replay=np.zeros_like(y)
    for dose in [0,7,14,21]:
        age=t-dose
        selected=(age>1e-8)&(age<=7+1e-8)
        for j in range(10):replay[selected,j]+=np.interp(age[selected],t[train],y[train,j])
    for name,selected in [('training',train),('later_occasions',held),('fourth_occasion',fourth)]:
        summary.append({'model':'first_profile_replay','subset':name,'n':int(selected.sum()*10),**metrics(y[selected],replay[selected])})
    for i,d in enumerate(day):
        for j,animal in enumerate(ids):predictions.append({'model':'first_profile_replay','animal_id':animal,'study_day':d,'observed_ng_ml':y[i,j],'predicted_ng_ml':replay[i,j]})
    pd.DataFrame(summary).to_csv(ROOT/'outputs/tables/model-performance.csv',index=False)
    pd.DataFrame(parameters).to_csv(ROOT/'outputs/tables/parameters.csv',index=False)
    pd.DataFrame(predictions).to_csv(ROOT/'outputs/tables/predictions.csv',index=False)
    sensitivity=[]
    for scale,exclude in [(0.5,False),(1.,False),(2.,False),(1.,True)]:
        rates,amp,sse=fit(t[train],y[train],'production',scale,exclude)
        pred=forecast(t,rates,'production')[:,None]*amp
        sensitivity.append({'asinh_scale_ng_ml':scale,'exclude_reported_zero':exclude,**metrics(y[fourth],pred[fourth]),'slow_rate_per_day':np.exp(rates[0]),'fast_rate_per_day':np.exp(rates[0])+np.exp(rates[1])})
    pd.DataFrame(sensitivity).to_csv(ROOT/'outputs/tables/zero-sensitivity.csv',index=False)
    paired=[]
    for j,animal in enumerate(ids):
        first=np.trapezoid(y[train,j],t[train]);last=np.trapezoid(y[fourth,j],t[fourth]-21)
        paired.append({'animal_id':animal,'first_auc_ng_day_ml':first,'fourth_auc_ng_day_ml':last,'fourth_to_first_auc_ratio':last/first,'first_sampled_peak_ng_ml':y[train,j].max(),'fourth_sampled_peak_ng_ml':y[fourth,j].max()})
    pd.DataFrame(paired).to_csv(ROOT/'outputs/tables/paired-exposure.csv',index=False)
    rng=np.random.default_rng(SEED)
    errors=[]
    for name,pred in [('production',fits['production'][2]),('first_profile_replay',replay)]:
        squared=np.mean((y[fourth]-pred[fourth])**2,axis=0)
        sampled=np.sqrt(np.mean(squared[rng.integers(0,10,size=(10000,10))],axis=1))
        errors.append({'model':name,'metric':'fourth-occasion RMSE','conditional_animal_bootstrap_low':np.quantile(sampled,.025),'conditional_animal_bootstrap_high':np.quantile(sampled,.975),'n_bootstrap':10000})
    pd.DataFrame(errors).to_csv(ROOT/'outputs/tables/conditional-score-uncertainty.csv',index=False)
    plt.rcParams.update({'font.size':10,'axes.spines.top':False,'axes.spines.right':False})
    fig,axes=plt.subplots(1,2,figsize=(11,4),layout='constrained')
    dense=np.linspace(.001,28,2500)
    for ax,(left,right,title) in zip(axes,[(0,7,'First dose: estimation'),(21,28,'Fourth dose: prediction')]):
        selected=(t>=left)&(t<=right)
        ax.plot(t[selected]-left,y[selected].mean(axis=1),'o',color='#0072B2',label='Observed mean (10 animals)')
        for model,color in [('bolus','#D55E00'),('production','#009E73')]:
            r,a,_=fits[model];chosen=(dense>=left)&(dense<=right)
            ax.plot(dense[chosen]-left,forecast(dense[chosen],r,model)*a.mean(),color=color,label=model)
        local_grid=np.linspace(.001,7,500)
        replay_mean=np.interp(local_grid,t[train],y[train].mean(axis=1))
        ax.plot(local_grid,replay_mean,'--',color='#777777',label='First-profile replay')
        ax.set(xlabel='Time after dose (day)',ylabel='TCE concentration (ng/mL)',title=title,ylim=(0,None));ax.legend(fontsize=8)
    fig.savefig(ROOT/'outputs/figures/occasion-prediction.png',dpi=180);plt.close(fig)
    fig,axes=plt.subplots(2,5,figsize=(14,5.5),layout='constrained')
    r,a,_=fits['production'];local=np.linspace(.001,7,300)
    for j,ax in enumerate(axes.flat):
        ax.plot(t[train],y[train,j],'o',color='#0072B2',label='First')
        ax.plot(t[fourth]-21,y[fourth,j],'s',color='#D55E00',label='Fourth')
        ax.plot(local,forecast(local+21,r,'production')*a[j],color='#009E73',label='Forecast')
        ax.set(title=f'Animal {ids[j]}',xlabel='Time after dose (day)',ylabel='TCE (ng/mL)',ylim=(0,None))
    axes.flat[0].legend(fontsize=7);fig.savefig(ROOT/'outputs/figures/paired-animal-prediction.png',dpi=180);plt.close(fig)
    fig,ax=plt.subplots(figsize=(7,4),layout='constrained');ratios=np.array([p['fourth_to_first_auc_ratio'] for p in paired]);ax.scatter(np.arange(10),ratios,color='#0072B2');ax.axhline(1,color='gray',linestyle='--');ax.set(xticks=np.arange(10),xticklabels=ids,xlabel='Animal ID',ylabel='Fourth / first observed AUC ratio',title='Paired trapezoidal exposure from reported samples');fig.savefig(ROOT/'outputs/figures/paired-exposure.png',dpi=180);plt.close(fig)
    result={'n_animals':10,'n_observations':int(y.size),'n_training':int(train.sum()*10),'n_later':int(held.sum()*10),'n_fourth':int(fourth.sum()*10),'reported_zeros':int((y==0).sum()),'reported_zeros_first':int((y[train]==0).sum()),'reported_zeros_fourth':int((y[fourth]==0).sum()),'mean_auc_ratio':float(np.mean(ratios)),'median_auc_ratio':float(np.median(ratios)),'min_auc_ratio':float(ratios.min()),'max_auc_ratio':float(ratios.max()),'zero_auc_animals':int((ratios==0).sum()),'performance':summary,'sensitivity':sensitivity,'source_sha256':hashlib.sha256((ROOT/'data/raw/source-data.xlsx').read_bytes()).hexdigest()}
    (ROOT/'outputs/tables/results.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
    print(json.dumps(result,indent=2))

if __name__ == '__main__':main()
