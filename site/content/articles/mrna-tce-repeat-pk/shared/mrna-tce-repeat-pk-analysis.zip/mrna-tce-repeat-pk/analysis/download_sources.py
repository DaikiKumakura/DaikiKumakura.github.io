"""Download and verify the official public source workbook without overwriting."""
from pathlib import Path
import hashlib
import urllib.request

ROOT=Path(__file__).resolve().parents[1]
URL='https://media.springernature.com/original/springer-static/esm/art%3A10.1038%2Fs41467-025-66087-y/MediaObjects/41467_2025_66087_MOESM8_ESM.xlsx'
EXPECTED='7cb4475da0e4861b9692ae75ec63407473c9cb2f43f2472ffef2aa340f2a84d0'
path=ROOT/'data/raw/source-data.xlsx'
if path.exists():
    payload=path.read_bytes()
else:
    payload=urllib.request.urlopen(URL,timeout=60).read()
    assert hashlib.sha256(payload).hexdigest()==EXPECTED,'Unexpected source version'
    path.parent.mkdir(parents=True,exist_ok=True)
    path.write_bytes(payload)
assert hashlib.sha256(payload).hexdigest()==EXPECTED,'Source checksum differs'
print('Official source workbook verified:',len(payload),'bytes')
