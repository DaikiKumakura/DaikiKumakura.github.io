import unittest,json,copy
from analysis import ROOT,summarize,percentage

class AggregateTests(unittest.TestCase):
    def setUp(self):self.a=json.loads((ROOT/'inputs/aggregates.json').read_text())
    def test_patient_episode_denominators(self):
        s=summarize(self.a)
        self.assertAlmostEqual(s['patient_episode_percent'],100*24357/52236)
        self.assertNotEqual(self.a['n_episodes'],self.a['n_episode_patients'])
    def test_histogram_mismatch_rejected(self):
        a=copy.deepcopy(self.a);a['hist_start_to_nadir']['counts'][0]+=1
        with self.assertRaises(ValueError):summarize(a)
    def test_episode_multiplicity_mismatch_rejected(self):
        a=copy.deepcopy(self.a);a['episode_count_distribution']['2']+=1
        with self.assertRaises(ValueError):summarize(a)
    def test_threshold_groups_sum(self):
        g=self.a['threshold_groups']
        for k in ['n_episodes','end_loss_below_5','end_loss_below_applicable_threshold']:
            self.assertEqual(g[0][k],g[1][k]+g[2][k])
        self.assertNotEqual(g[0]['end_loss_below_5'],g[0]['end_loss_below_applicable_threshold'])
    def test_invalid_denominator(self):
        for n,d in [(1,0),(2,1),(-1,5)]:
            with self.assertRaises(ValueError):percentage(n,d)
    def test_temporal_summary_order(self):
        q=self.a['start_to_nadir_days_quantiles'];self.assertEqual(q['0.5'],196)
        self.assertEqual(list(q.values()),sorted(q.values()))

if __name__=='__main__':unittest.main()
