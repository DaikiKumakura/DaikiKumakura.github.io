"""Audit publicly deposited episode CSV and export aggregate-only inputs."""
from pathlib import Path
import hashlib,json
import numpy as np
import pandas as pd

ROOT=Path(__file__).resolve().parent

def audit_aggregate(d):
    if d.duplicated(['DMP_ID','episode_id']).any():raise ValueError('duplicate patient/episode')
    for col in ['reached_WL10_6mo','reached_WL15_6mo']:
        if (d.groupby('DMP_ID')[col].nunique()>1).any():raise ValueError('patient flags inconsistent')
    e=d[d.episode==1].copy();patients=d.groupby('DMP_ID').episode.max()
    if e[['start_day','end_day','nadir_day','start_bmi_smooth','weight_loss_max','weight_loss_start_to_end']].isna().any().any():raise ValueError('episode fields missing')
    if ((e.nadir_day<e.start_day)|(e.nadir_day>e.end_day)).any():raise ValueError('invalid temporal order')
    np.testing.assert_allclose(e.end_day-e.start_day,e.episode_duration,atol=1e-8)
    np.testing.assert_allclose((e.start_bmi_smooth-e.nadir_bmi)/e.start_bmi_smooth*100,e.weight_loss_max,atol=1e-8)
    np.testing.assert_allclose((e.start_bmi_smooth-e.end_bmi_smooth)/e.start_bmi_smooth*100,e.weight_loss_start_to_end,atol=1e-8)
    applicable=np.where(e.start_bmi_smooth<20,2.,5.)
    if (e.weight_loss_max+1e-8<applicable).any():raise ValueError('episode below applicable maximum loss threshold')
    if (e.weight_loss_max+1e-8<e.weight_loss_start_to_end).any():raise ValueError('end loss exceeds maximum')
    counts=e.groupby('DMP_ID').size();flags=d.drop_duplicates('DMP_ID')
    def quant(v):return {str(q):float(v.quantile(q)) for q in [0,.1,.25,.5,.75,.9,1]}
    def group(mask,label):
        g=e[mask];threshold=applicable[mask]
        return {'group':label,'n_episodes':len(g),'end_loss_below_5':int((g.weight_loss_start_to_end<5).sum()),
                'end_loss_below_applicable_threshold':int((g.weight_loss_start_to_end<threshold).sum()),
                'end_loss_negative':int((g.weight_loss_start_to_end<0).sum()),
                'max_minus_end_positive':int(((g.weight_loss_max-g.weight_loss_start_to_end)>1e-8).sum())}
    delays=e.nadir_day-e.start_day;rebound=e.weight_loss_max-e.weight_loss_start_to_end
    bins_days=[0,30,60,90,120,180,365,730,float('inf')]
    bins_pp=[0,1,2,5,10,20,float('inf')]
    def hist(v,bins):
        n,_=np.histogram(v,bins=bins)
        return {'edges':[None if np.isinf(x) else x for x in bins],'counts':n.tolist()}
    return {'n_rows':len(d),'n_patients':len(patients),'n_episode_patients':int(patients.sum()),
            'n_non_episode_patients':int((patients==0).sum()),'n_episodes':len(e),
            'n_recurrent_patients':int((counts>=2).sum()),'max_episodes_per_patient':int(counts.max()),
            'patients_wl10_flag':int(flags.reached_WL10_6mo.sum()),'patients_wl15_flag':int(flags.reached_WL15_6mo.sum()),
            'episode_count_distribution':{str(int(k)):int(v) for k,v in counts.value_counts().sort_index().items()},
            'start_to_nadir_days_quantiles':quant(delays),'nadir_to_end_days_quantiles':quant(e.end_day-e.nadir_day),
            'episode_duration_days_quantiles':quant(e.episode_duration),
            'max_minus_end_percentage_points_quantiles':quant(rebound),
            'threshold_groups':[group(np.ones(len(e),dtype=bool),'all'),group(applicable==2,'start_BMI_below20_threshold2'),group(applicable==5,'start_BMI_atleast20_threshold5')],
            'hist_start_to_nadir':hist(delays,bins_days),'hist_max_minus_end':hist(rebound.clip(lower=0),bins_pp)}

def run():
    record=json.loads((ROOT/'zenodo-record.json').read_text())
    for f in record['files']:
        if hashlib.md5((ROOT/f['key']).read_bytes()).hexdigest()!=f['checksum'].split(':')[1]:raise ValueError('checksum mismatch')
    d=pd.read_csv(ROOT/'deidentified_episodes_cachexia_20260821.csv')
    a=audit_aggregate(d)
    bad=(d.episode==1)&(d.end_day>d.os_days)
    a['episode_end_after_followup_count']=int(bad.sum())
    if bad.any():
        sensitivity=audit_aggregate(d[~bad])
        a['exclude_end_after_followup_episode_sensitivity']={k:sensitivity[k] for k in ['n_episodes','start_to_nadir_days_quantiles','episode_duration_days_quantiles','threshold_groups']}
    out=ROOT/'inputs';out.mkdir(exist_ok=True)
    (out/'aggregates.json').write_text(json.dumps(a,indent=2)+'\n',encoding='utf-8')
    prov={'source_doi':record['doi'],'license':'CC BY 4.0','license_url':'https://creativecommons.org/licenses/by/4.0/',
        'source_title':record['metadata']['title'],'creators':[x['name'] for x in record['metadata']['creators']],'retrieved':'2026-10-18',
        'modifications':'Aggregate-only summaries and histograms calculated from public episode CSV. No individual records distributed.',
        'files':[{k:f[k] for k in ['key','checksum','size']} for f in record['files']]}
    (out/'provenance.json').write_text(json.dumps(prov,indent=2)+'\n',encoding='utf-8');print(json.dumps(a,indent=2))

if __name__=='__main__':run()
