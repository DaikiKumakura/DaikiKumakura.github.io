"""Calculate descriptive percentages from audited aggregate-only inputs."""
from pathlib import Path
import json,csv

ROOT=Path(__file__).resolve().parent

def percentage(n,den):
    if den<=0 or n<0 or n>den:raise ValueError('invalid count/denominator')
    return 100*n/den

def summarize(a):
    if a['n_episode_patients']+a['n_non_episode_patients']!=a['n_patients']:raise ValueError('patient total mismatch')
    dist=a['episode_count_distribution']
    if sum(int(k)*v for k,v in dist.items())!=a['n_episodes']:raise ValueError('episode count mismatch')
    if sum(dist.values())!=a['n_episode_patients']:raise ValueError('episode patient mismatch')
    for name in ['hist_start_to_nadir','hist_max_minus_end']:
        if sum(a[name]['counts'])!=a['n_episodes']:raise ValueError('histogram denominator mismatch')
    return {'patient_episode_percent':percentage(a['n_episode_patients'],a['n_patients']),
      'recurrent_percent_all_patients':percentage(a['n_recurrent_patients'],a['n_patients']),
      'recurrent_percent_episode_patients':percentage(a['n_recurrent_patients'],a['n_episode_patients']),
      'wl10_percent_all_patients':percentage(a['patients_wl10_flag'],a['n_patients']),
      'wl15_percent_all_patients':percentage(a['patients_wl15_flag'],a['n_patients']),
      'threshold_groups':[{**g,**{k+'_percent':percentage(g[k],g['n_episodes']) for k in ['end_loss_below_5','end_loss_below_applicable_threshold','end_loss_negative','max_minus_end_positive']}} for g in a['threshold_groups']]}

def run():
    a=json.loads((ROOT/'inputs/aggregates.json').read_text());s=summarize(a)
    out=ROOT/'results';out.mkdir(exist_ok=True)
    (out/'summary.json').write_text(json.dumps({'aggregates':a,'derived':s},indent=2)+'\n',encoding='utf-8')
    with (out/'threshold_summary.csv').open('w',newline='',encoding='utf-8') as f:
        w=csv.DictWriter(f,fieldnames=s['threshold_groups'][0]);w.writeheader();w.writerows(s['threshold_groups'])
    print(json.dumps(s,indent=2))

if __name__=='__main__':run()
