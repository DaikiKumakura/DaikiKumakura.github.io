# 悪液質エピソード公開データの記述集計

出典：Reznik, Ed and Castillon, Venise Jan (2026), https://doi.org/10.5281/zenodo.22045313 。CC BY 4.0（https://creativecommons.org/licenses/by/4.0/）。本配布物の入力は原データから算出した集約値・分布に改変しています。患者行は同梱していません。取得日2026-10-18。ファイル名・チェックサム・改変は `inputs/provenance.json`。

Python 3.11以上で実行：

```sh
python -m pip install -r requirements.txt
python analysis.py
python -m unittest -v test_analysis.py
python plot.py
```

集約JSONから割合・整合性を再計算し、results/とfigures/PNG2枚を生成します。元CSVからの集約も追試する場合のみ次を先に実行します（公開Zenodoへのネット接続が必要）。

```sh
python download_sources.py
python extract_aggregates.py
```

補助ダウンロードは約9.8 MBの公開CSVと辞書を取得しMD5を検証します。著者の検出アルゴリズムをBMI原系列から再実行するものではありません。

## 分母と時刻

- 患者単位はDMP_IDで重複を除いた52,236人。58,817行は患者数ではありません。
- episode=1の30,938行は24,357人のエピソード。複数エピソードの割合は患者分母とepisodeあり患者分母を区別します。
- `reached_WL10_6mo` と `reached_WL15_6mo` は独立に検出を再実行した患者単位フラグです。今回のepisodeの最大減少で10/15%を切って再定義しません。
- `start_day` は180日検出窓のbaselineで、閾値到達日やオンラインで検出が確定した日ではありません。start→nadirを検出遅延と呼びません。
- `nadir_day` は結合されたエピソード全体の最低BMI日、`end_day` は移動窓の基準を最後に満たす日。いずれも後から決まる記述量です。エピソードが結合されるため期間が180日を超えても定義違反とは限りません。
- start BMI<20では減少閾値2%、それ以外は5%。end減少<5%とend減少<適用閾値を分けます。全episodeの最大減少は適用閾値を満たしています。
- 最大減少−end減少はパーセントポイント差であり、筋力・代謝・悪液質そのものの回復を測りません。

## 監査と感度

元CSVの患者内フラグ、episode識別子重複、時刻順序、期間、BMIからの減少量を検査しました。end_dayがos_daysを8日超えるepisodeが1件あります。公開ファイル全件を主集計とし、その1行を除外したepisode単位の感度をinputs/aggregates.jsonとresults/summary.jsonに収録。start→nadir中央値196日、IQR147–273、期間中央値212日、IQR167–294はいずれも不変。端点閾値未満の分子も不変（分母30,938→30,937）。患者単位の全体分母をその除外感度で再定義しません。

分位点はpandas既定の線形補間。棒グラフ区間は左端含む・右端含まず、最後の区間は無限大まで。0–<1ppには変化なしを含みます。観察密度や追跡長に依存する記述解析であり、前兆予測・生存効果・ゲノム因果推定はしません。全エピソードを重み1で集計しているため、エピソードの多い患者の寄与も増えます。
