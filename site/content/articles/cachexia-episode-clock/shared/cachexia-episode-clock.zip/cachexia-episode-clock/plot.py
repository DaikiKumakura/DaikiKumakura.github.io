import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import json
from analysis import ROOT

a=json.loads((ROOT/'inputs/aggregates.json').read_text());out=ROOT/'figures';out.mkdir(exist_ok=True)
plt.rcParams.update({'font.size':11,'axes.spines.top':False,'axes.spines.right':False})
fig,axes=plt.subplots(1,2,figsize=(11,4.8))
labels=[('hist_start_to_nadir',['0-29','30-59','60-89','90-119','120-179','180-364','365-729','730+'],'Start baseline to eventual nadir','Days'),
        ('hist_max_minus_end',['0-<1','1-<2','2-<5','5-<10','10-<20','20+'],'Maximum loss minus end loss','Percentage points')]
for ax,(key,labs,title,xlabel) in zip(axes,labels):
    ax.bar(labs,[100*n/a['n_episodes'] for n in a[key]['counts']],color='#2c6e8f')
    ax.set(title=title,xlabel=xlabel,ylabel='Episodes (%)');ax.tick_params(axis='x',rotation=45)
fig.text(.5,.015,'30,938 retrospective episodes. Baseline is not the date of threshold confirmation.',ha='center',fontsize=9)
fig.tight_layout(rect=(0,.04,1,1));fig.savefig(out/'episode-clock-distributions.png',dpi=180);plt.close(fig)

groups=a['threshold_groups'][1:]
fig,ax=plt.subplots(figsize=(7.5,4.8));xx=[0,1];width=.33
ax.bar([v-width/2 for v in xx],[100*g['end_loss_below_5']/g['n_episodes'] for g in groups],width,label='End loss < 5%',color='#2c6e8f')
ax.bar([v+width/2 for v in xx],[100*g['end_loss_below_applicable_threshold']/g['n_episodes'] for g in groups],width,label='End loss < applicable threshold',color='#d07b3f')
ax.set(xticks=xx,xticklabels=['Start BMI < 20\n2% criterion; n = 2,692','Start BMI >= 20\n5% criterion; n = 28,246'],ylabel='Episodes (%)',title='End loss is not maximum loss')
ax.legend(frameon=False);ax.grid(axis='y',alpha=.15)
fig.text(.5,.015,'All episodes satisfy their applicable criterion by maximum loss.',ha='center',fontsize=9)
fig.tight_layout(rect=(0,.04,1,1));fig.savefig(out/'end-versus-maximum-loss.png',dpi=180);plt.close(fig)
