"""Optional public source download. No credentials or access request needed."""
from pathlib import Path
from urllib.request import urlopen
import hashlib,json

root=Path(__file__).resolve().parent
with urlopen('https://zenodo.org/api/records/22045313',timeout=90) as r:record=json.load(r)
if record['metadata']['license']['id']!='cc-by-4.0':raise ValueError('Unexpected license; inspect source terms')
for f in record['files']:
    with urlopen(f['links']['self'],timeout=90) as r:content=r.read()
    if hashlib.md5(content).hexdigest()!=f['checksum'].split(':')[1]:raise ValueError('Checksum mismatch')
    target=root/f['key']
    if target.exists() and target.read_bytes()!=content:raise ValueError('Refusing to overwrite different local file')
    target.write_bytes(content)
(root/'zenodo-record.json').write_text(json.dumps(record,indent=2),encoding='utf-8')
print('Public source files downloaded and checksums verified.')
