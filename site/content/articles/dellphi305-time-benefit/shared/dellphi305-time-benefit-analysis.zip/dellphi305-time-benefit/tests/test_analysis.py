import importlib.util,unittest
from pathlib import Path
import numpy as np
import pymupdf
P=Path(__file__).resolve().parents[1]
s=importlib.util.spec_from_file_location('run',P/'analysis/run.py');m=importlib.util.module_from_spec(s);s.loader.exec_module(m)
class Tests(unittest.TestCase):
 def test_exact_step_integral(self):
  t=np.array([0,2,2,4,4,6.]);v=np.array([1,1,.8,.8,.5,.5]);self.assertAlmostEqual(m.area(t,v,5),4.1)
 def test_no_tail_extrapolation(self):
  with self.assertRaises(AssertionError):m.area(np.array([0,1.]),np.array([1,.5]),2)
 def test_survival_boundaries(self):
  t=np.array([0,2,2,4.]);v=np.array([1,1,.6,.6]);self.assertEqual(m.survival(t,v,-.001),1);self.assertEqual(m.survival(t,v,2),.6)
 def test_source_curves_and_risk_sets(self):
  d=pymupdf.open(m.SOURCE)
  for e,c in m.CONFIG.items():
   for g in ['combo','control']:
    t,v=m.trace(d[c['page']],g,c);self.assertTrue(np.all(np.diff(t)>=-1e-5));self.assertTrue(np.all(np.diff(v)<=1e-5));self.assertGreater(t[-1],12)
   self.assertEqual(c['combo'][4],222 if e=='OS' else 86);self.assertEqual(c['control'][4],146 if e=='OS' else 18)
 def test_unreported_risk_cells_not_zero_imputed(self):
  self.assertEqual(len(m.CONFIG['OS']['combo']),9);self.assertEqual(len(m.CONFIG['PFS']['control']),8)
if __name__=='__main__':unittest.main()
