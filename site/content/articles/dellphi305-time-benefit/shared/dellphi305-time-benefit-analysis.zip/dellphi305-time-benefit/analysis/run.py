"""Integrate public, plotted KM vector paths; never reconstruct patient records."""
from pathlib import Path
import hashlib,json,csv
import numpy as np
import pymupdf
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

ROOT=Path(__file__).resolve().parents[1]
SOURCE=ROOT/'data/raw/amgen-esmo2026.pdf'
SEED=20261028
CONFIG={'OS':{'page':16,'x0':105.48,'xref':906.84,'tref':27,'y0':365.49,'y100':190.85,'combo':[282,276,258,246,222,132,55,9,0],'control':[281,252,208,171,146,81,33,8,1,0]},'PFS':{'page':18,'x0':133.56,'xref':904.68,'tref':24,'y0':358.29,'y100':135.39,'combo':[282,225,147,122,86,32,14,1,0],'control':[281,106,46,36,18,8,2,0]}}

def trace(page,group,config):
    target=(0,.388,.765) if group=='combo' else (.376,.365,.459)
    paths=[d for d in page.get_drawings() if d.get('color') and np.allclose(d['color'],target,atol=.001) and len(d['items'])>100]
    assert len(paths)==1
    points=[paths[0]['items'][0][1]]+[item[2] for item in paths[0]['items']]
    assert all(item[0]=='l' for item in paths[0]['items'])
    x=np.array([pt.x for pt in points]);y=np.array([pt.y for pt in points])
    t=(x-config['x0'])/(config['xref']-config['x0'])*config['tref']
    s=(config['y0']-y)/(config['y0']-config['y100'])
    assert len(t)>100 and np.min(np.diff(t))>-.00001 and np.max(np.diff(s))<.00001
    assert t[0]<.05 and t[-1]>=12 and abs(s[0]-1)<.001
    return t,np.clip(s,0,1)

def area(t,s,tau,shift_t=0.,shift_s=0.):
    assert 0<=tau<=t[-1]+shift_t, 'No unsupported tail integration'
    left=np.maximum(0,t[:-1]+shift_t);right=np.minimum(tau,t[1:]+shift_t)
    value=np.clip(s[:-1]+shift_s,0,1)
    total=float(np.sum(np.maximum(0,right-left)*value))
    if t[0]+shift_t>0:total+=min(tau,t[0]+shift_t)
    return total

def survival(t,s,at):
    assert at<=t[-1], 'No unsupported tail lookup'
    if at<t[0]: return 1.
    return float(s[np.searchsorted(t,at,side='right')-1])

def csvout(name,rows):
    with (ROOT/'outputs/tables'/name).open('w',newline='',encoding='utf8') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)

def main():
    for directory in ['outputs/tables','outputs/figures']:(ROOT/directory).mkdir(parents=True,exist_ok=True)
    doc=pymupdf.open(SOURCE);curves={};summary=[];intervals=[];risk=[];coords=[]
    for endpoint,c in CONFIG.items():
        for group in ['combo','control']:
            t,s=trace(doc[c['page']],group,c);curves[endpoint,group]=(t,s)
            for k,(x,y) in enumerate(zip(t,s)):coords.append(dict(endpoint=endpoint,group=group,vertex=k,month=float(x),survival=float(y)))
            for month,n in zip(range(0,28,3),c[group]):risk.append(dict(endpoint=endpoint,group=group,month=month,at_risk=n))
        a,b=curves[endpoint,'combo'],curves[endpoint,'control']
        for tau in [3,6,9,12]:
            ra,rb=area(*a,tau),area(*b,tau)
            summary.append(dict(endpoint=endpoint,horizon_months=tau,rmst_combo=ra,rmst_control=rb,rmst_difference=ra-rb,survival_combo=survival(*a,tau),survival_control=survival(*b,tau)))
        for lo,hi in [(0,3),(3,6),(6,9),(9,12)]:
            ha=-np.log(survival(*a,hi)/survival(*a,lo))/(hi-lo);hb=-np.log(survival(*b,hi)/survival(*b,lo))/(hi-lo)
            intervals.append(dict(endpoint=endpoint,start_month=lo,end_month=hi,interval_log_survival_rate_combo=float(ha),interval_log_survival_rate_control=float(hb),descriptive_rate_ratio=float(ha/hb)))
    rng=np.random.default_rng(SEED);sensitivity=[]
    for endpoint in CONFIG:
        draws=[]
        for _ in range(2000):
            # Whole-trace perturbations preserve each arm's monotonicity.
            areas=[area(*curves[endpoint,g],12,shift_t=rng.uniform(-.05,.05),shift_s=rng.uniform(-.005,.005)) for g in ['combo','control']]
            draws.append(areas[0]-areas[1])
        sensitivity.append(dict(endpoint=endpoint,scenario_min=float(min(draws)),scenario_max=float(max(draws)),scenario='independent whole-arm shifts: time +/-0.05 month and survival +/-0.005; not sampling confidence interval'))
    for name,rows in [('curve-vertices.csv',coords),('risk-sets.csv',risk),('rmst.csv',summary),('interval-rates.csv',intervals),('reading-sensitivity.csv',sensitivity)]:csvout(name,rows)
    plt.rcParams.update({'font.size':10,'svg.fonttype':'none'})
    fig,axes=plt.subplots(1,2,figsize=(10,4))
    for ax,endpoint in zip(axes,CONFIG):
        for group,label,color in [('combo','Tarlatamab + durvalumab','#0072B2'),('control','Durvalumab','#D55E00')]:
            t,s=curves[endpoint,group];ax.step(t,s,where='post',label=label,color=color)
        ax.set(xlim=(0,12),ylim=(0,1.02),xlabel='Months from maintenance randomization',ylabel='Plotted survival probability',title=f'{endpoint}; randomized n=282 / 281');ax.legend(fontsize=8)
    save(fig,'survival-common-window')
    fig,ax=plt.subplots(figsize=(7,4))
    for endpoint,color in [('OS','#0072B2'),('PFS','#D55E00')]:
        ts=np.linspace(0,12,241);diff=[area(*curves[endpoint,'combo'],t)-area(*curves[endpoint,'control'],t) for t in ts]
        ax.plot(ts,diff,label=endpoint,color=color)
    ax.set(xlabel='Restriction horizon (months)',ylabel='Restricted mean difference (months)',title='Area between the public KM curves; no tail extrapolation');ax.legend();save(fig,'accumulated-absolute-benefit')
    result={'source_sha256':hashlib.sha256(SOURCE.read_bytes()).hexdigest(),'source_pages':[17,19],'method':'Direct integration of plotted vector-path horizontal segments, not patient-level reconstruction','primary_horizon_months':12,'summary':summary,'interval_rates':intervals,'reading_sensitivity':sensitivity,'risk_set_at_12_months':{'OS':[222,146],'PFS':[86,18]}}
    (ROOT/'outputs/results.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf8');print(json.dumps(result,indent=2))

def save(fig,name):
    fig.tight_layout()
    for ext in ['png','svg']:fig.savefig(ROOT/f'outputs/figures/{name}.{ext}',dpi=170)
    plt.close(fig)

if __name__=='__main__':main()
