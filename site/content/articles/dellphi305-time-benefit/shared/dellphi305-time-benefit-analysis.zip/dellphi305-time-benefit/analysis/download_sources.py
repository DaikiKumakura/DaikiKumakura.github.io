"""Acquire the original public presentation without redistributing it."""
from pathlib import Path
import urllib.request,hashlib
ROOT=Path(__file__).resolve().parents[1]
URL='https://investors.amgen.com/static-files/b4ad55cd-2ca8-4082-9485-2141bd493d3d'
SHA='43565693daa4a3d5e378f4c631c76bfa3c8ea19c030fd3f22118dc89b7ce6b6e'
def main():
 p=ROOT/'data/raw/amgen-esmo2026.pdf'
 if not p.exists():
  data=urllib.request.urlopen(URL,timeout=120).read()
  assert hashlib.sha256(data).hexdigest()==SHA
  p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data)
 assert hashlib.sha256(p.read_bytes()).hexdigest()==SHA
 print('Public presentation source hash verified')
if __name__=='__main__':main()
