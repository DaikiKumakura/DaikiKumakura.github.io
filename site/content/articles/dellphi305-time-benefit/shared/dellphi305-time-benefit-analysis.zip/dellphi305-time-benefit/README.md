# DeLLphi-305 survival benefit over time

Independent integration of public, plotted OS/PFS Kaplan–Meier vector paths, not patient-level data reconstruction. Primary horizon: 12 months from maintenance randomization. Analysis compares randomized tarlatamab+durvalumab with durvalumab only.

## Reproduction

Use Python3.12 with the packages recorded in requirements.txt:

```sh
python analysis/download_sources.py
python analysis/run.py
python -m unittest discover -s tests -v
```

The unchanged public presentation is hash-checked and retained locally under data/raw. It and rendered source pages are excluded from the companion. Newly computed curve coordinates and aggregate tables are in outputs/tables; new figures in outputs/figures. All results are in outputs/results.json.

Vertical vectors have zero integration width. Horizontal segments use the left survival value up to the restriction horizon. No survival tail beyond the plotted data is extrapolated. Whole-trace shifts preserve monotonicity; their range is a reading scenario, not a patient-sampling confidence interval. Interval log-survival rates describe plotted curve shape and are not adjusted Cox hazard-ratio estimates. Risk tables are used to check support, not to infer unreported event/censoring times.

The analysis does not compare starting treatment at different times, treatment interruption or finite versus continuing maintenance. It cannot identify each drug's separate contribution or pharmacologic synergy. Individual outcomes and clinical trial effect estimates are not re-estimated.
