# Does the steroid effect on TCE cytotoxicity depend on the effector-to-target ratio?

Independent reanalysis of published observations. Source article and derivative digitized observations: CC BY-NC 4.0, with attribution to Kauer et al. (2020). Newly computed model fits and figures are explicitly reanalyses. Source: https://doi.org/10.1136/jitc-2020-000621

## Reproduction

Python 3.12; install requirements.txt in a separate environment, then run:

```sh
python analysis/download_sources.py
python analysis/run.py
python -m unittest discover -s tests -v
```

No participant simulation or treatment recommendation is made. Outputs are derived from the published observations; aggregate means and repeated lesions are not independent participants. The manuscripts describe the evaluation unit, exclusions and limitations.

Original sources are not redistributed. source-provenance.json records acquisition locations and file hashes. data/processed contains extracted observations; outputs/tables contains predictions and evaluation metrics; outputs/figures contains newly drawn figures. Rounding/reading perturbations are sensitivity scenarios, not population confidence intervals.
