import unittest,importlib.util
from pathlib import Path
import numpy as np
p=Path(__file__).resolve().parents[1]
s=importlib.util.spec_from_file_location('run',p/'analysis/run.py');m=importlib.util.module_from_spec(s);s.loader.exec_module(m)
class Tests(unittest.TestCase):
 def test_equal_conditions_when_no_effect(self):
  x=np.geomspace(.625,10,20);p=np.log([100,1,2,1])
  for model in ['horizontal','vertical']:
   np.testing.assert_allclose(m.response(x,p,np.zeros(20),model),m.response(x,p,np.ones(20),model))
 def test_horizontal_shift_keeps_asymptote(self):
  p=np.log([100,1,2,4]);self.assertAlmostEqual(m.response(np.array([1e7]),p,np.array([1]),'horizontal')[0],100,places=7)
  self.assertAlmostEqual(m.response(np.array([1e7]),p,np.array([1]),'vertical')[0],25,places=7)
 def test_whole_ratio_split_excludes_both_conditions(self):
  x=np.tile(m.X,2)
  for ratio in m.X:
   self.assertEqual(sum(x==ratio),2);self.assertEqual(sum(x!=ratio),8)
if __name__=='__main__':unittest.main()
