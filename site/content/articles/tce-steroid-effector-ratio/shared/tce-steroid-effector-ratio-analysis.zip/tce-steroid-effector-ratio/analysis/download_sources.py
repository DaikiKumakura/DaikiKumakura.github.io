from pathlib import Path
import urllib.request,zipfile,io,hashlib
ROOT=Path(__file__).resolve().parents[1]
d=ROOT/'data/raw';d.mkdir(parents=True,exist_ok=True)
u='https://www.ebi.ac.uk/europepmc/webservices/rest/PMC7264835/supplementaryFiles'
b=urllib.request.urlopen(u,timeout=120).read()
with zipfile.ZipFile(io.BytesIO(b)) as z:
 name=next(n for n in z.namelist() if n.endswith('jitc-2020-000621f01.jpg'))
 image=z.read(name)
 assert hashlib.sha256(image).hexdigest()=='75ec5ba4caaa30b31a986021405da354de21d80eb15889dd7e0249f294cdbfbf'
 (d/'jitc-2020-000621f01.jpg').write_bytes(image)
print('Source image acquired and hash verified')
