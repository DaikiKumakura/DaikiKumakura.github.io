"""Reanalyze observed Figure 1C means without treating them as donor records."""
from pathlib import Path
import hashlib,json
import numpy as np
import pandas as pd
from scipy.optimize import least_squares
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

ROOT=Path(__file__).resolve().parents[1]
SEED=20261028
X=np.array([.625,1.25,2.5,5.,10.])
PIXELS={'CC1_TOCI':np.array([273.,277.,274.,268.,275.]),'CC1_DEX':np.array([364.,337.,315.,283.,278.])}
Y0,Y100=376.,273.

def response(x,p,group,model):
    emax,k,h=np.exp(p[:3]);effect=np.exp(p[3])
    if model=='horizontal': k=k*np.where(group==1,effect,1.)
    else:emax=emax*np.where(group==1,1/effect,1.)
    return emax/(1+np.exp(np.clip(h*(np.log(k)-np.log(x)),-700,700)))

def fit(x,y,group,model,emax_cap=100.):
    lo=np.log([1.,1e-5,.1,1.]);hi=np.log([emax_cap,100.,12.,1e7])
    starts=[np.log([105.,.1,2.,10.]),np.log([105.,.01,1.,3.]),np.log([110.,1.,1.,2.])]
    r=min((least_squares(lambda p:response(x,p,group,model)-y,np.clip(s,lo+1e-8,hi-1e-8),bounds=(lo,hi),max_nfev=700) for s in starts),key=lambda a:sum(a.fun**2))
    return r.x

def main():
    for d in ['data/processed','outputs/figures','outputs/tables']:(ROOT/d).mkdir(parents=True,exist_ok=True)
    records=[]
    for group,yp in PIXELS.items():
        for ratio,px,py in zip(X,[101,140,180,219,258],yp):records.append({'condition':group,'effector_target_ratio':ratio,'marker_x_px':px,'marker_y_px':py,'response_percent_of_control':100*(Y0-py)/(Y0-Y100),'aggregate_donors':4})
    d=pd.DataFrame(records);d.to_csv(ROOT/'data/processed/observed-means.csv',index=False)
    x=d.effector_target_ratio.to_numpy();y=d.response_percent_of_control.to_numpy();g=(d.condition=='CC1_DEX').to_numpy().astype(int)
    assert len(d)==10 and not d.duplicated(['condition','effector_target_ratio']).any()
    summaries=[];params=[];cv=[];fitted=[]
    for model in ['horizontal','vertical']:
        p=fit(x,y,g,model);pred=response(x,p,g,model)
        params.append({'model':model,'emax_percent':np.exp(p[0]),'reference_K_ET':np.exp(p[1]),'shared_hill':np.exp(p[2]),'effect_factor':np.exp(p[3])})
        for i in range(10):fitted.append({'model':model,**records[i],'prediction':pred[i]})
        held=np.zeros(10)
        for ratio in X:
            train=x!=ratio;q=fit(x[train],y[train],g[train],model);mask=~train;held[mask]=response(x[mask],q,g[mask],model)
            for i in np.flatnonzero(mask):cv.append({'model':model,'excluded_ET':ratio,'condition':records[i]['condition'],'observed':y[i],'prediction':held[i]})
        summaries.append({'model':model,'parameters':4,'training_RMSE_pp':np.sqrt(np.mean((pred-y)**2)),'paired_ET_holdout_RMSE_pp':np.sqrt(np.mean((held-y)**2)),'holdout_DEX_RMSE_pp':np.sqrt(np.mean((held[g==1]-y[g==1])**2))})
    cap_results=[]
    for cap in [100.,150.]:
        for model in ['horizontal','vertical']:
            p=fit(x,y,g,model,cap);held=np.zeros(10)
            for ratio in X:
                train=x!=ratio;q=fit(x[train],y[train],g[train],model,cap);held[~train]=response(x[~train],q,g[~train],model)
            cap_results.append({'model':model,'emax_cap_percent':cap,'training_RMSE_pp':np.sqrt(np.mean((response(x,p,g,model)-y)**2)),'paired_ET_holdout_RMSE_pp':np.sqrt(np.mean((held-y)**2))})
    pd.DataFrame(cap_results).to_csv(ROOT/'outputs/tables/ceiling-cap-sensitivity.csv',index=False)
    pd.DataFrame(params).to_csv(ROOT/'outputs/tables/model-parameters.csv',index=False)
    pd.DataFrame(summaries).to_csv(ROOT/'outputs/tables/model-comparison.csv',index=False)
    pd.DataFrame(cv).to_csv(ROOT/'outputs/tables/condition-holdout.csv',index=False)
    pd.DataFrame(fitted).to_csv(ROOT/'outputs/tables/fitted-means.csv',index=False)
    # Perturb only marker reading, not donor-level biology.
    rng=np.random.default_rng(SEED);sens=[]
    for rep in range(100):
        yr=y+rng.uniform(-1.5,1.5,size=10)*100/(Y0-Y100)
        for model in ['horizontal','vertical']:
            p=fit(x,yr,g,model)
            sens.append({'iteration':rep,'model':model,'RMSE_pp':np.sqrt(np.mean((response(x,p,g,model)-yr)**2)),'effect_factor':np.exp(p[3]),'reference_K_ET':np.exp(p[1])})
    pd.DataFrame(sens).to_csv(ROOT/'outputs/tables/reading-sensitivity.csv',index=False)
    plt.rcParams.update({'font.size':10,'axes.spines.top':False,'axes.spines.right':False})
    fig,axs=plt.subplots(1,2,figsize=(10,4),layout='constrained');dense=np.geomspace(.625,10,200)
    for ax,model,title in zip(axs,['horizontal','vertical'],['Horizontal-shift model','Ceiling-change model']):
        p=fit(x,y,g,model)
        for group,label,color,marker in [(0,'CC-1 + TOCI','#0072B2','s'),(1,'CC-1 + DEX','#D55E00','^')]:
            ax.scatter(x[g==group],y[g==group],color=color,marker=marker,label=label)
            ax.plot(dense,response(dense,p,np.full(200,group),model),color=color)
        ax.set(xscale='log',xlabel='PBMC:target ratio',ylabel='Tumor cell lysis (% of control)',title=title,ylim=(0,120));ax.legend(fontsize=8)
    fig.savefig(ROOT/'outputs/figures/et-model-comparison.png',dpi=180);fig.savefig(ROOT/'outputs/figures/et-model-comparison.svg');plt.close(fig)
    cvd=pd.DataFrame(cv);fig,ax=plt.subplots(figsize=(6,4),layout='constrained')
    for model,color in [('horizontal','#009E73'),('vertical','#CC79A7')]:
        a=cvd.query('model == @model and condition == "CC1_DEX"');ax.plot(a.excluded_ET,a.prediction-a.observed,'o-',label=model,color=color)
    ax.axhline(0,color='gray');ax.set(xscale='log',xlabel='Excluded PBMC:target ratio',ylabel='Held-out DEX error (percentage points)',title='One entire ratio excluded from both conditions');ax.legend();fig.savefig(ROOT/'outputs/figures/heldout-ratio.png',dpi=180);fig.savefig(ROOT/'outputs/figures/heldout-ratio.svg');plt.close(fig)
    pdiff=y[:5]-y[5:];pd.DataFrame({'ET':X,'TOCI_minus_DEX_pp':pdiff}).to_csv(ROOT/'outputs/tables/observed-difference.csv',index=False)
    result={'n_observed_means':10,'n_donors_in_source':4,'models':summaries,'parameters':params,'observed_difference_pp':pdiff.tolist(),'source_sha256':hashlib.sha256((ROOT/'data/raw/jitc-2020-000621f01.jpg').read_bytes()).hexdigest(),'pixel_y_to_response':{'zero':Y0,'hundred':Y100},'reading_sensitivity':pd.DataFrame(sens).groupby('model').agg({'RMSE_pp':['min','max'],'effect_factor':['min','max']}).to_dict()}
    # Tuple column keys are flattened for valid portable JSON.
    result['reading_sensitivity']={str(k):v for k,v in result['reading_sensitivity'].items()}
    result['ceiling_cap_sensitivity']=cap_results
    (ROOT/'outputs/tables/results.json').write_text(json.dumps(result,indent=2),encoding='utf8');print(json.dumps(result,indent=2))

if __name__=='__main__':main()
