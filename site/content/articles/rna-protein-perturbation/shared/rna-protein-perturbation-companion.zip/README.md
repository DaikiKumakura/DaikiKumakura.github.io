# 摂動後のRNAとタンパク質の変化：配布資料

記事「RNAで摂動の効果を読む限界：同じ細胞の表面タンパク質で確かめる」の再実行用資料。

## 含むもの

- `analysis-plan.md`：問い・使いみち・処理・感度・判断の規則（計算前に固定、追記あり）
- `acquire.py`：scPerturb（Zenodo 10.5281/zenodo.7041849、CC BY 4.0）からの取得
- `input-provenance.json`：入力ファイルのSHA-256
- `analysis.py`, `test_analysis.py`, `figures.py`：集計、検査、図
- `validate.py`：h5pyで直接読む独立の再計算
- `results/`：直接の標的、間接の効果の要約、全組の値、B2Mの例、タンパク質の背景、検証結果
- `figures/`：記事の図

入力のh5adファイル本体（約1.5 GB）は同梱しない。`acquire.py` で取得し、SHA-256で照合する。

## 実行

1. `python acquire.py`（Python 3.12、requests）
2. `python test_analysis.py && python analysis.py && python figures.py && python validate.py`（anndata、h5py、numpy、scipy、pandas、matplotlib）
