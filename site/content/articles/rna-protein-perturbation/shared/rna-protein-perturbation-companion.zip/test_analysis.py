"""Checks on synthetic data for the change, reliability and disattenuation calculations."""
import numpy as np
import pandas as pd

import analysis as A


def test_changes_against_same_condition_control():
    obs = pd.DataFrame({"condition": ["c1"] * 4 + ["c2"] * 4,
                        "perturbation": ["control", "control", "X", "X"] * 2},
                       index=[f"cell{i}" for i in range(8)])
    v = pd.DataFrame({"g": [1.0, 3.0, 5.0, 7.0, 10.0, 10.0, 10.0, 12.0]}, index=obs.index)
    A.MIN_CELLS = 2
    obs = pd.concat([obs, obs.iloc[[0, 1, 4, 5]].set_axis([f"cell{i}" for i in range(8, 12)])])
    v = pd.concat([v, v.iloc[[0, 1, 4, 5]].set_axis(obs.index[8:])])
    d = A.changes(v, obs, np.random.default_rng(0))
    full = d[d.part == "full"].set_index("condition").delta
    assert full["c1"] == 4.0 and full["c2"] == 1.0
    A.MIN_CELLS = 30


def test_spearman_brown():
    assert abs(A.spearman_brown(0.5) - 2 / 3) < 1e-12


def test_disattenuation_recovers_true_correlation():
    rng = np.random.default_rng(1)
    n = 40000
    true_r = 0.6
    z = rng.normal(size=(n, 2))
    tr = z[:, 0]
    tp = true_r * z[:, 0] + np.sqrt(1 - true_r ** 2) * z[:, 1]
    # each half carries noise with variance 2 (so a full-sample mean carries variance 1)
    h1r, h2r = tr + rng.normal(0, np.sqrt(2), n), tr + rng.normal(0, np.sqrt(2), n)
    h1p, h2p = tp + rng.normal(0, np.sqrt(2), n), tp + rng.normal(0, np.sqrt(2), n)
    m = pd.DataFrame({"h1_rna": h1r, "h2_rna": h2r, "full_rna": (h1r + h2r) / 2,
                      "h1_prot": h1p, "h2_prot": h2p, "full_prot": (h1p + h2p) / 2, "direct": False,
                      "condition": "c", "protein": np.arange(n) % 4})
    s = A.indirect_stats(m)
    assert s["pearson"] < 0.4                       # attenuated
    assert abs(s["disattenuated"] - true_r) < 0.03
    assert abs(s["noise_sd_prot"] - 1.0) < 0.02


def test_clr_rows_sum_to_zero():
    import anndata as ad
    p = ad.AnnData(np.array([[1.0, 5.0, 9.0], [0.0, 2.0, 2.0]]))
    p.var_names = ["a", "b", "c"]
    c = A.protein_matrix(p, ["a", "b", "c"])
    assert np.allclose(c.sum(axis=1), 0)


if __name__ == "__main__":
    for name, fn in list(globals().items()):
        if name.startswith("test_"):
            fn()
    print("all tests passed")
