"""Figures from results/ (run analysis.py first)."""
from pathlib import Path
import json

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parent
res = ROOT / "results"
(ROOT / "figures").mkdir(exist_ok=True)
COL = {"Control": "#0072B2", "IFNg": "#E69F00", "Co-culture": "#009E73"}

# Figure 1: knocked-out gene's own mRNA change vs its protein change
d = pd.read_csv(res / "direct-targets.csv")
fig, ax = plt.subplots(figsize=(8.2, 4.2), constrained_layout=True)
for cond, g in d.groupby("condition"):
    ax.scatter(g.full_rna, g.full_prot, color=COL[cond], label=cond, s=36)
for pert, g in d.groupby("perturbation"):
    r = g.loc[g.full_prot.idxmin()]
    ax.annotate(pert, (r.full_rna, r.full_prot), fontsize=7, xytext=(4, -2), textcoords="offset points")
ax.axhline(0, color="grey", linewidth=0.8)
ax.axvline(0, color="grey", linewidth=0.8)
ax.axvline(-0.1, color="k", linestyle=":", linewidth=1, label="mRNA change -0.1")
ax.set_xlabel("Change in the knocked-out gene's own mRNA (log1p CP10k, vs control)")
ax.set_ylabel("Change in its surface protein (CLR, vs control)")
ax.set_title(f"Frangieh et al. 2021: 10 knocked-out genes with a measured protein x 3 conditions (n = {len(d)})", fontsize=8.5)
ax.legend(fontsize=7.5, loc="upper left", bbox_to_anchor=(1.01, 1), borderaxespad=0)
fig.savefig(ROOT / "figures/01-direct-targets.png", dpi=150)

# Figure 2: indirect effects, mRNA change vs protein change, with B2M highlighted
a = pd.read_csv(res / "all-pairs.csv")
s = json.loads((res / "summary.json").read_text(encoding="utf-8"))["main"]
ind = a[~a.direct]
fig, ax = plt.subplots(figsize=(7, 4.4), constrained_layout=True)
hb = ax.hexbin(ind.full_rna, ind.full_prot, gridsize=60, bins="log", cmap="viridis", mincnt=1,
               extent=(-0.4, 0.4, -1.6, 0.8))
b = ind[ind.perturbation == "B2M"]
hl = b[b.protein.isin(["HLA_A", "HLA_E"])]
ax.scatter(hl.full_rna, hl.full_prot, color="#D55E00", s=40, marker="D", label="B2M knockout: HLA-A, HLA-E proteins")
ax.set_xlim(-0.4, 0.4)
ax.set_ylim(-1.6, 0.8)
ax.set_xlabel("mRNA change of the gene encoding the protein (log1p CP10k)")
ax.set_ylabel("Protein change (CLR)")
ax.set_title(f"Indirect effects: {int(s['n_pairs']):,} perturbation x protein x condition pairs; "
             f"r = {s['pearson']:.2f}, noise-corrected {s['disattenuated']:.2f}", fontsize=8.5)
fig.colorbar(hb, ax=ax, label="Pairs per bin (log scale)")
ax.legend(fontsize=7.5, loc="lower right")
fig.savefig(ROOT / "figures/02-indirect-effects.png", dpi=150)
print("figures written")
