"""How well does the mRNA change of a gene predict the change of its surface protein after CRISPR knockout?

Frangieh et al. 2021 Perturb-CITE-seq (RNA and 20 surface proteins in the same cells).
"""
from pathlib import Path
import json

import anndata as ad
import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parent
SEED = 20261020
MIN_CELLS = 30
CHUNK = 2000
Z_CUT = 3.0
RNA_FLAT = -0.1
PROTEIN_TO_GENE = {"CD117": "KIT", "CD119": "IFNGR1", "CD140a": "PDGFRA", "CD140b": "PDGFRB", "CD172a": "SIRPA",
                   "CD184": "CXCR4", "CD202b": "TEK", "CD274": "CD274", "CD29": "ITGB1", "CD309": "KDR",
                   "CD44": "CD44", "CD47": "CD47", "CD49f": "ITGA6", "CD58": "CD58", "CD59": "CD59",
                   "CD61": "ITGB3", "HLA_A": "HLA-A", "HLA_E": "HLA-E", "CD9": "CD9", "CD279": "PDCD1"}
ISOTYPES = ["Rat_IgG2a", "Mouse_IgG1", "Mouse_IgG2a", "Mouse_IgG2b"]


def rna_matrix(path, genes):
    """log1p(CP10k) for the requested genes; totals are over all genes."""
    a = ad.read_h5ad(path, backed="r")
    totals = np.zeros(a.n_obs)
    for s in range(0, a.n_vars, CHUNK):
        totals += np.asarray(a.X[:, s:s + CHUNK].sum(axis=1)).ravel()
    cols = [int(np.flatnonzero(a.var_names == g)[0]) for g in genes]
    x = np.column_stack([np.asarray(a.X[:, c].toarray()).ravel() for c in cols])
    return pd.DataFrame(np.log1p(x * (1e4 / totals)[:, None]), index=a.obs_names, columns=genes), totals


def protein_matrix(p, proteins, method="clr", rna_totals=None):
    x = p[:, proteins].X
    x = x.toarray() if hasattr(x, "toarray") else np.asarray(x)
    if method == "rna_size":    # post hoc: not compositional across proteins
        return pd.DataFrame(np.log1p(1e4 * x / rna_totals[:, None]), index=p.obs_names, columns=proteins)
    if method == "clr":
        lx = np.log1p(x)
        return pd.DataFrame(lx - lx.mean(axis=1, keepdims=True), index=p.obs_names, columns=proteins)
    tot = x.sum(axis=1, keepdims=True)
    return pd.DataFrame(np.log1p(1e3 * x / np.maximum(tot, 1)), index=p.obs_names, columns=proteins)


def changes(values, obs, rng):
    """Per (perturbation, condition): full, half-1 and half-2 mean minus the same-condition control mean."""
    out = []
    for cond, oc in obs.groupby("condition", observed=True):
        cidx = oc.index[oc.perturbation == "control"].to_numpy()
        chalf = rng.permutation(np.arange(len(cidx)) % 2)
        cv = values.loc[cidx]
        # control cells are split too, so the two halves share no cells (unbiased split-half reliability)
        ctrl = {"full": cv.mean(), "h1": cv[chalf == 0].mean(), "h2": cv[chalf == 1].mean()}
        for pert, op in oc[oc.perturbation != "control"].groupby("perturbation", observed=True):
            if len(op) < MIN_CELLS:
                continue
            idx = op.index.to_numpy()
            half = rng.permutation(np.arange(len(idx)) % 2)
            v = values.loc[idx]
            for name, sel in (("full", slice(None)), ("h1", half == 0), ("h2", half == 1)):
                d = v[sel].mean() - ctrl[name]
                out.append(pd.DataFrame({"condition": cond, "perturbation": pert, "part": name,
                                         "feature": d.index, "delta": d.to_numpy(), "n": len(idx)}))
    return pd.concat(out, ignore_index=True)


def spearman_brown(r):
    return 2 * r / (1 + r)


def compare(rna_d, prot_d, mapping, targets):
    """Join RNA and protein changes per (condition, perturbation, protein)."""
    r = rna_d.pivot_table(index=["condition", "perturbation", "feature"], columns="part", values="delta")
    p = prot_d.pivot_table(index=["condition", "perturbation", "feature"], columns="part", values="delta")
    r = r.reset_index().rename(columns={"feature": "gene"})
    p = p.reset_index().rename(columns={"feature": "protein"})
    p["gene"] = p.protein.map(mapping)
    m = p.merge(r, on=["condition", "perturbation", "gene"], suffixes=("_prot", "_rna"))
    n = rna_d[rna_d.part == "full"].groupby(["condition", "perturbation"]).n.first().rename("n").reset_index()
    m = m.merge(n, on=["condition", "perturbation"])
    m["direct"] = m.perturbation == m.gene
    m["is_ko_target_protein"] = m.gene.isin(targets)
    return m


def indirect_stats(m):
    d = m[~m.direct]
    r = np.corrcoef(d.full_rna, d.full_prot)[0, 1]
    rel_rna = spearman_brown(np.corrcoef(d.h1_rna, d.h2_rna)[0, 1])
    rel_prot = spearman_brown(np.corrcoef(d.h1_prot, d.h2_prot)[0, 1])
    noise_sd = np.std(d.h1_prot - d.h2_prot, ddof=1) / 2      # SD of a full-sample mean difference
    big = d[np.abs(d.full_prot) >= Z_CUT * noise_sd]
    slope = np.polyfit(d.full_rna, d.full_prot, 1)[0]
    return dict(n_pairs=len(d), pearson=r, rel_rna=rel_rna, rel_prot=rel_prot,
                disattenuated=r / np.sqrt(rel_rna * rel_prot), noise_sd_prot=noise_sd,
                n_big_protein=len(big), sign_agree_big=float((np.sign(big.full_rna) == np.sign(big.full_prot)).mean()),
                r_big=float(np.corrcoef(big.full_rna, big.full_prot)[0, 1]) if len(big) > 2 else np.nan,
                median_r_per_protein=float(np.median([np.corrcoef(g.full_rna, g.full_prot)[0, 1]
                                                      for _, g in d.groupby(["condition", "protein"]) if len(g) > 2])),
                r_centred=float(np.corrcoef(d.full_rna - d.groupby(["condition", "protein"]).full_rna.transform("mean"),
                                            d.full_prot - d.groupby(["condition", "protein"]).full_prot.transform("mean"))[0, 1]),
                slope=slope)


def above_background(p, proteins):
    """Post hoc: proteins whose mean log1p count exceeds the highest isotype-control mean."""
    lx = lambda cols: np.log1p(np.asarray(p[:, cols].X.toarray() if hasattr(p.X, "toarray") else p[:, cols].X)).mean(axis=0)
    iso = lx(ISOTYPES).max()
    means = pd.Series(lx(proteins), index=proteins)
    return means, iso


def main():
    rna_path = ROOT / "inputs/FrangiehIzar2021_RNA.h5ad"
    p = ad.read_h5ad(ROOT / "inputs/FrangiehIzar2021_protein.h5ad")
    a = ad.read_h5ad(rna_path, backed="r")
    assert (a.obs_names == p.obs_names).all()
    obs = a.obs[["perturbation", "perturbation_2", "MOI", "nperts"]].rename(columns={"perturbation_2": "condition"})
    obs["condition"] = obs.condition.astype(str).map(lambda s: "IFNg" if s.startswith("IFN") else s)
    print("cells:", len(obs), "perturbations:", obs.perturbation.nunique(), "conditions:", obs.condition.unique().tolist())
    mapping = {k: v for k, v in PROTEIN_TO_GENE.items() if v in set(a.var_names)}
    proteins = list(mapping)
    genes = sorted(set(mapping.values()))
    targets = sorted(g for g in genes if g in set(obs.perturbation))
    print("proteins with RNA:", len(proteins), "knocked-out genes with a measured protein:", targets)
    rna, totals = rna_matrix(rna_path, genes)
    out = ROOT / "results"
    out.mkdir(exist_ok=True)
    assert (totals > 0).all()
    rows, keep = [], None
    settings = {"main (CLR, all cells)": (obs, "clr"), "MOI = 1 only": (obs[obs.MOI <= 1], "clr"),
                "protein log-normalised": (obs, "lognorm"),
                "protein per RNA library size (post hoc)": (obs, "rna_size"),
                "proteins above isotype background (post hoc)": (obs, "clr_bg")}
    means, iso = above_background(p, proteins)
    expressed = [q for q in proteins if means[q] > iso]
    print("isotype max mean:", round(float(iso), 3), "proteins above background:", len(expressed))
    pd.DataFrame({"mean_log1p": means, "above_isotype": means > iso}).round(4).to_csv(
        ROOT / "results/protein-background.csv", index_label="protein", lineterminator="\n")
    for name, (o, method) in settings.items():
        if method == "clr_bg":
            prot = protein_matrix(p, expressed, "clr")
        else:
            prot = protein_matrix(p, proteins, method, totals)
        rng = np.random.default_rng(SEED)
        m = compare(changes(rna, o, rng), changes(prot, o, np.random.default_rng(SEED + 1)), mapping, targets)
        s = indirect_stats(m)
        s["setting"] = name
        rows.append(s)
        for cond, g in m.groupby("condition"):
            s2 = indirect_stats(g)
            s2["setting"] = f"{name}: {cond}"
            rows.append(s2)
        if keep is None:
            keep = m
    stats = pd.DataFrame(rows).set_index("setting")
    stats.round(5).to_csv(out / "indirect-summary.csv", lineterminator="\n")
    direct = keep[keep.direct][["condition", "perturbation", "protein", "n", "full_rna", "full_prot"]].copy()
    direct["rna_flat"] = direct.full_rna > RNA_FLAT
    direct.sort_values(["perturbation", "condition"]).round(5).to_csv(out / "direct-targets.csv", index=False, lineterminator="\n")
    keep.round(5).to_csv(out / "all-pairs.csv", index=False, lineterminator="\n")
    b2m = keep[keep.perturbation == "B2M"][["condition", "protein", "full_rna", "full_prot"]]
    b2m.round(5).to_csv(out / "b2m.csv", index=False, lineterminator="\n")
    summary = {"cells": len(obs), "targets": targets, "proteins": proteins,
               "direct_n": len(direct), "direct_rna_flat_frac": float(direct.rna_flat.mean()),
               "direct_prot_mean": float(direct.full_prot.mean()), "direct_rna_mean": float(direct.full_rna.mean()),
               "main": stats.loc["main (CLR, all cells)"].to_dict()}
    (out / "summary.json").write_text(json.dumps(summary, indent=2, default=float) + "\n", encoding="utf-8")
    pd.set_option("display.width", 220)
    print(stats.round(3).to_string())
    print(direct.round(3).to_string())
    print(b2m.round(3).to_string())


if __name__ == "__main__":
    main()
