"""Independent recomputation of the full-sample changes, reading the h5ad files with h5py.

Library sizes are recomputed from the raw CSC arrays (data/indices), CLR and group means use separate code,
and the direct-target table and the indirect Pearson correlation are compared with results/.
"""
from pathlib import Path
import json

import h5py
import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parent
spec = __import__("analysis")
MAP = {k: v for k, v in spec.PROTEIN_TO_GENE.items() if v != "PDCD1"}


def read_obs(f, cols):
    out = {}
    for c in cols:
        g = f["obs"][c]
        if isinstance(g, h5py.Group):
            cats = [x.decode() if isinstance(x, bytes) else x for x in g["categories"][:]]
            out[c] = pd.Categorical.from_codes(g["codes"][:], cats).astype(str)
        else:
            out[c] = g[:]
    return pd.DataFrame(out)


with h5py.File(ROOT / "inputs/FrangiehIzar2021_RNA.h5ad", "r") as f:
    X = f["X"]
    assert X.attrs["encoding-type"] == "csc_matrix"
    n_obs = X.attrs["shape"][0]
    data, indices, indptr = X["data"], X["indices"], X["indptr"][:]
    totals = np.zeros(n_obs)
    step = 20_000_000
    for s in range(0, len(data), step):
        np.add.at(totals, indices[s:s + step], data[s:s + step])
    var = [x.decode() if isinstance(x, bytes) else x for x in f["var"][f["var"].attrs["_index"]][:]]
    rna = {}
    for g in sorted(set(MAP.values())):
        j = var.index(g)
        col = np.zeros(n_obs)
        col[indices[indptr[j]:indptr[j + 1]]] = data[indptr[j]:indptr[j + 1]]
        rna[g] = np.log1p(col / totals * 1e4)
    obs = read_obs(f, ["perturbation", "perturbation_2"])

with h5py.File(ROOT / "inputs/FrangiehIzar2021_protein.h5ad", "r") as f:
    pv = [x.decode() if isinstance(x, bytes) else x for x in f["var"][f["var"].attrs["_index"]][:]]
    g = f["X"]
    if isinstance(g, h5py.Group):
        from scipy.sparse import csc_matrix, csr_matrix
        cls = csc_matrix if g.attrs["encoding-type"] == "csc_matrix" else csr_matrix
        P = cls((g["data"][:], g["indices"][:], g["indptr"][:]), shape=tuple(g.attrs["shape"])).toarray()
    else:
        P = g[:]
cols = [pv.index(k) for k in MAP]
L = np.log1p(P[:, cols])
clr = L - L.mean(axis=1, keepdims=True)

df = pd.DataFrame(rna)
for i, k in enumerate(MAP):
    df["P_" + k] = clr[:, i]
df["pert"] = obs.perturbation.to_numpy()
df["cond"] = np.where(obs.perturbation_2.str.startswith("IFN"), "IFNg", obs.perturbation_2)
means = df.groupby(["cond", "pert"]).mean()
sizes = df.groupby(["cond", "pert"]).size()
rows = []
for (cond, pert), m in means.iterrows():
    if pert == "control" or sizes[(cond, pert)] < 30:
        continue
    c = means.loc[(cond, "control")]
    for k, gname in MAP.items():
        rows.append(dict(condition=cond, perturbation=pert, protein=k,
                         rna=m[gname] - c[gname], prot=m["P_" + k] - c["P_" + k], direct=pert == gname))
mine = pd.DataFrame(rows)
ind = mine[~mine.direct]
r_mine = float(np.corrcoef(ind.rna, ind.prot)[0, 1])
ref = json.loads((ROOT / "results/summary.json").read_text(encoding="utf-8"))["main"]
dref = pd.read_csv(ROOT / "results/direct-targets.csv").set_index(["condition", "perturbation"])
dm = mine[mine.direct].set_index(["condition", "perturbation"]).loc[dref.index]
diff = max(np.abs(dm.rna - dref.full_rna).max(), np.abs(dm.prot - dref.full_prot).max())
ok = bool(diff < 1e-4 and abs(r_mine - ref["pearson"]) < 1e-4 and len(ind) == ref["n_pairs"])
print(f"direct max abs diff {diff:.2e}; indirect r {r_mine:.5f} vs {ref['pearson']:.5f}; pairs {len(ind)} vs {ref['n_pairs']}")
(ROOT / "results/validation.json").write_text(json.dumps({
    "status": "pass" if ok else "fail", "method": "h5py read, recomputed library sizes, separate CLR and group means",
    "direct_max_abs_diff": float(diff), "indirect_pearson": r_mine, "analysis_pearson": ref["pearson"],
    "n_pairs": int(len(ind))}, indent=2) + "\n", encoding="utf-8")
print("validation:", "pass" if ok else "fail")
