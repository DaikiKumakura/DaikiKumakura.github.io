"""Small empirical dose-exposure and periodic oral PK models."""
import numpy as np
from scipy.optimize import least_squares


def fit_dose(dose, auc, kind):
    x=np.asarray(dose);y=np.log(np.asarray(auc))
    if kind=='linear':
        p=np.array([np.mean(y-np.log(x))])
    else:
        fit=least_squares(lambda p:p[0]+np.log(x)-np.log(np.exp(p[1])+x)-y,
                          [np.log(15000),np.log(1000)],
                          bounds=([-15,np.log(1)],[35,np.log(1e7)]),
                          ftol=1e-10,xtol=1e-10,gtol=1e-10)
        assert fit.success
        p=fit.x
    residual=y-np.log(dose_auc(x,p,kind))
    return p,residual


def dose_auc(dose,p,kind):
    return np.exp(p[0])*np.asarray(dose) if kind=='linear' else np.exp(p[0])*np.asarray(dose)/(np.exp(p[1])+np.asarray(dose))


def profile(t,k,ka,lag,doses,p,kind,multiplier=1):
    t=np.asarray(t);c=np.zeros_like(t,dtype=float)
    for d,h in doses:
        s=(t-h-lag)%24
        c+=dose_auc(d,p,kind)*k*ka/(ka-k)*(np.exp(-k*s)/(-np.expm1(-24*k))-np.exp(-ka*s)/(-np.expm1(-24*ka)))
    return c*multiplier


def shape_curve(t,v):
    k=np.exp(v[0]);ka=k+np.exp(v[1]);lag=v[2];auc=np.exp(v[3])
    s=(np.asarray(t)-lag)%12
    return auc*k*ka/(ka-k)*(np.exp(-k*s)/(-np.expm1(-12*k))-np.exp(-ka*s)/(-np.expm1(-12*ka)))


def fit_shape(t,c):
    fit=least_squares(lambda v:np.log(shape_curve(t,v))-np.log(c),
                      [np.log(.23),np.log(.8),.3,np.log(2000)],
                      bounds=([np.log(.01),np.log(.01),0,np.log(.1)],
                              [np.log(2),np.log(20),1,np.log(1e6)]),
                      ftol=1e-11,xtol=1e-11,gtol=1e-11)
    assert fit.success
    return fit.x


def endpoints(k,ka,lag,doses,p,kind,step=.02):
    t=np.arange(0,24,step)
    # Include all lag events, where periodic concentrations can reach minima.
    t=np.unique(np.r_[t,[(h+lag)%24 for d,h in doses]])
    c=profile(t,k,ka,lag,doses,p,kind)
    return dict(auc24=float(sum(dose_auc(d,p,kind) for d,h in doses)),cmax=float(c.max()),cmin=float(c.min()))
