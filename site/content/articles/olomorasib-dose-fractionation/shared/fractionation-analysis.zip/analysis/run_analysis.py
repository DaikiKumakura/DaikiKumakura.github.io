from pathlib import Path
import json,platform,hashlib
import numpy as np
import pandas as pd
import scipy
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from model import fit_dose,dose_auc,fit_shape,shape_curve,profile,endpoints

R=Path(__file__).resolve().parents[1]


def main():
    cfg=json.loads((R/'analysis/inputs.json').read_text())
    a=pd.read_csv(R/'analysis/auc-data.csv');c=pd.read_csv(R/'analysis/mean-data.csv')
    assert not a.duplicated(['block','dose']).any() and a.auc.gt(0).all()
    t=R/'outputs/tables';f=R/'outputs/figures';t.mkdir(parents=True,exist_ok=True);f.mkdir(exist_ok=True)
    summary=[]
    for d,g in a.groupby('dose'):
        summary.append(dict(dose=d,n=len(g),geomean=np.exp(np.log(g.auc).mean()),mean=g.auc.mean(),median=g.auc.median(),gcv=np.sqrt(np.expm1(np.log(g.auc).var(ddof=1)))))
    sm=pd.DataFrame(summary);sm.to_csv(t/'source-auc-summary.csv',index=False)
    pars={};fits=[]
    for kind in ['linear','sat']:
        p,res=fit_dose(a.dose,a.auc,kind);pars[kind]=p
        fits.append(dict(model=kind,a_or_amax=np.exp(p[0]),d50=np.exp(p[1]) if kind=='sat' else None,log_rss=sum(res**2),residual_log_sd=res.std(ddof=len(p))))
    pd.DataFrame(fits).to_csv(t/'dose-model-fit.csv',index=False)
    g=c[c.dose==150];v=fit_shape(g.time.values,g.concentration.values)
    k=np.exp(v[0]);ka=k+np.exp(v[1]);lag=v[2]
    shape=[]
    for d,g in c.groupby('dose'):
        norm=shape_curve(g.time.values,v)/np.exp(v[3])
        scale=np.exp(np.mean(np.log(g.concentration)-np.log(norm)))
        pred=scale*norm
        shape.append(dict(dose=d,check='fit' if d==150 else 'shape_check_rescaled',scale_auc=scale,max_abs_relative_error=max(abs(pred/g.concentration-1)),log_rmse=np.sqrt(np.mean((np.log(pred/g.concentration))**2))))
    pd.DataFrame(shape).to_csv(t/'shape-check.csv',index=False)
    # Cluster bootstrap uses recoded source-ID blocks, not asserted unique persons.
    rng=np.random.default_rng(cfg['seed']);groups=[g for _,g in a.groupby('block',sort=True)]
    bs=[]
    for b in range(cfg['bootstrap']):
        ix=rng.integers(0,len(groups),len(groups));sample=pd.concat([groups[j] for j in ix],ignore_index=True)
        p,res=fit_dose(sample.dose,sample.auc,'sat')
        bs.append(dict(replicate=b,d50=np.exp(p[1]),near_linear_bound=bool(np.exp(p[1])>1e6),tid_bid_auc_ratio=float(3*dose_auc(100,p,'sat')/(2*dose_auc(150,p,'sat')))))
    boot=pd.DataFrame(bs);boot.to_csv(t/'bootstrap.csv',index=False)
    # Same empirical exposure multiplier per virtual pair; ratios therefore cancel.
    z=fit_dose(a.dose,a.auc,'sat')[1];multipliers=np.exp(rng.choice(z,size=cfg['n'],replace=True)-z.mean())
    rows=[];typ={}
    for kind,p in pars.items():
        for name,reg in cfg['regimens'].items():
            e=endpoints(k,ka,lag,reg,p,kind,cfg['time_step']);typ[kind,name]=e
            ref=endpoints(k,ka,lag,cfg['regimens']['150BID'],p,kind,cfg['time_step'])
            row=dict(model=kind,regimen=name,daily_dose=sum(d for d,h in reg),**e)
            for ep,val in e.items():
                lo,med,hi=np.quantile(val*multipliers,[.05,.5,.95]);row.update({ep+'_p05':lo,ep+'_median':med,ep+'_p95':hi,ep+'_ratio':val/ref[ep]})
            rows.append(row)
    reg=pd.DataFrame(rows);reg.to_csv(t/'regimen-endpoints.csv',index=False)
    sens=[]
    for half in [cfg['source_half_ci'][0],np.log(2)/k,cfg['source_half_ci'][1]]:
        for kafold in [.5,1,2]:
            ks=np.log(2)/half;kas=ka*kafold
            for name in ['100TID','100TID_6_6_12']:
                e=endpoints(ks,kas,lag,cfg['regimens'][name],pars['sat'],'sat',cfg['time_step']);ref=endpoints(ks,kas,lag,cfg['regimens']['150BID'],pars['sat'],'sat',cfg['time_step'])
                sens.append(dict(half_h=half,ka_factor=kafold,regimen=name,**{ep+'_ratio':e[ep]/ref[ep] for ep in e}))
    pd.DataFrame(sens).to_csv(t/'shape-sensitivity.csv',index=False)
    plt.rcParams.update({'font.size':11,'axes.spines.top':False,'axes.spines.right':False})
    colors=['#0072B2','#D55E00','#009E73','#CC79A7']
    fig,axs=plt.subplots(1,2,figsize=(11,4.6),layout='constrained')
    for col,(d,g) in zip(colors,c.groupby('dose')):
        axs[0].plot(g.time,g.concentration,'o-',label=f'{d} mg BID',color=col)
    grid=np.linspace(0,12,500);axs[0].plot(grid,shape_curve(grid,v),'k--',label='150 mg mean-profile fit')
    axs[0].set(xlabel='Hours after nominal dose',ylabel='Mean plasma concentration (ng/mL)');axs[0].legend(fontsize=8)
    xx=np.linspace(50,200,150)
    axs[1].scatter(sm.dose,sm.geomean,color='k',label='Source AUC geometric mean')
    for kind,col in zip(pars,colors):axs[1].plot(xx,dose_auc(xx,pars[kind],kind),label=kind,color=col)
    axs[1].set(xlabel='Dose per administration (mg)',ylabel='Steady-state AUC0-12 (ng h/mL)');axs[1].legend(fontsize=9)
    fig.suptitle('Observed mean profiles and individual-AUC dose models')
    fig.savefig(f/'data-and-models.png',dpi=160);plt.close(fig)
    fig,axs=plt.subplots(1,2,figsize=(11,4.4),layout='constrained');grid=np.linspace(0,24,1201)
    for name,col in zip(['150BID','100TID','100TID_6_6_12'],colors):
        axs[0].plot(grid,profile(grid,k,ka,lag,cfg['regimens'][name],pars['sat'],'sat'),label=name,color=col)
    axs[0].set(xlabel='Hours in a periodic day',ylabel='Representative plasma concentration (ng/mL)');axs[0].legend(fontsize=9)
    d=reg[reg.regimen=='100TID'];xx=np.arange(3)
    for shift,(kind,col) in enumerate(zip(['linear','sat'],colors)):
        q=d[d.model==kind].iloc[0];axs[1].bar(xx+(shift-.5)*.3,[q.auc24_ratio,q.cmax_ratio,q.cmin_ratio],.3,label=kind,color=col)
    axs[1].axhline(1,color='.5',ls='--');axs[1].set(xticks=xx,xticklabels=['AUC24','Cmax','Cmin'],ylabel='100 TID / 150 BID');axs[1].legend()
    fig.suptitle('Same 300 mg/day: conditional dose-frequency comparisons')
    fig.savefig(f/'regimen-comparison.png',dpi=160);plt.close(fig)
    fig,axs=plt.subplots(1,2,figsize=(11,4.2),layout='constrained')
    axs[0].hist(boot.tid_bid_auc_ratio,bins=30,color=colors[0],edgecolor='white');axs[0].axvline(1,color='.4',ls='--');axs[0].set(xlabel='100 TID / 150 BID AUC24, saturating model',ylabel='Bootstrap replicates')
    q=reg[(reg.model=='sat')&reg.regimen.isin(['150BID','100TID'])]
    for i,x in enumerate(q.itertuples()):axs[1].errorbar([i],[x.auc24_median],yerr=[[x.auc24_median-x.auc24_p05],[x.auc24_p95-x.auc24_median]],fmt='o',capsize=5,color=colors[i])
    axs[1].set(xticks=[0,1],xticklabels=q.regimen.tolist(),ylabel='Conditional AUC24 (ng h/mL)',ylim=(0,float(q.auc24_p95.max())*1.15))
    axs[0].set_title('1,000 source-ID bootstrap replicates')
    axs[1].set_title('2,048 pairs; median and P5-P95')
    fig.suptitle('Dose-model uncertainty and conditional exposure spread are distinct')
    fig.savefig(f/'uncertainty.png',dpi=160);plt.close(fig)
    result=dict(seed=cfg['seed'],n=cfg['n'],auc_records=len(a),source_id_blocks=a.block.nunique(),multi_dose_blocks=int((a.groupby('block').size()>1).sum()),curve_points=len(c),shape=dict(k=k,ka=ka,lag=lag,half_h=np.log(2)/k,scale_auc=np.exp(v[3])),bootstrap=dict(replicates=len(boot),auc_ratio_quantiles=boot.tid_bid_auc_ratio.quantile([.025,.5,.975]).tolist(),near_linear_bound_fraction=float(boot.near_linear_bound.mean())),model_fit=fits,regimens=rows)
    (R/'outputs/results.json').write_text(json.dumps(result,indent=2)+'\n')
    (R/'outputs/environment.json').write_text(json.dumps(dict(python=platform.python_version(),numpy=np.__version__,pandas=pd.__version__,scipy=scipy.__version__,matplotlib=matplotlib.__version__),indent=2)+'\n')
    if (R/'docs/source-provenance.json').exists():(R/'outputs/source-hashes.json').write_text((R/'docs/source-provenance.json').read_text())
    print('fit',fits,'shape',result['shape'],'bootstrap',result['bootstrap']);print(reg[['model','regimen','auc24_ratio','cmax_ratio','cmin_ratio']].to_string(index=False))


if __name__=='__main__':main()
