import unittest
import numpy as np
from scipy.integrate import solve_ivp,quad
from model import dose_auc,fit_dose,shape_curve,profile,endpoints,fit_shape


class Checks(unittest.TestCase):
    def setUp(self):
        self.k=.22;self.ka=.95;self.lag=.37;self.p=np.log([14500,1000]);self.doses=[[150,0],[150,12]]

    def test_periodic_ode(self):
        reg=[[100,0],[100,6],[100,12]];initial=np.zeros(2);prev=-240
        events=sorted((day*24+h+self.lag,d) for day in range(-10,2) for d,h in reg)
        for at,d in events:
            if at>0:break
            initial=solve_ivp(lambda t,y:[-self.ka*y[0],self.ka*y[0]-self.k*y[1]],(prev,at),initial,rtol=1e-10,atol=1e-10).y[:,-1]
            initial[0]+=dose_auc(d,self.p,'sat')*self.k;prev=at
        # Continue through positive events and compare at independent observation times.
        for at in [.1,.5,3,6.2,6.8,11,12.5,18,23.9]:
            inside=[(e,d) for e,d in events if prev<e<=at]
            for ev,d in inside:
                initial=solve_ivp(lambda t,y:[-self.ka*y[0],self.ka*y[0]-self.k*y[1]],(prev,ev),initial,rtol=1e-10,atol=1e-10).y[:,-1];initial[0]+=dose_auc(d,self.p,'sat')*self.k;prev=ev
            initial=solve_ivp(lambda t,y:[-self.ka*y[0],self.ka*y[0]-self.k*y[1]],(prev,at),initial,rtol=1e-10,atol=1e-10).y[:,-1];prev=at
            self.assertAlmostEqual(initial[1],float(profile(at,self.k,self.ka,self.lag,reg,self.p,'sat')),places=5)

    def test_mass(self):
        reg=[[100,0],[100,8],[100,16]]
        area=quad(lambda x:profile(x,self.k,self.ka,self.lag,reg,self.p,'sat'),0,24,points=[.37,8.37,16.37],epsabs=1e-7)[0]
        self.assertAlmostEqual(area,3*dose_auc(100,self.p,'sat'),places=5)

    def test_linear_equal_amount(self):
        p=np.log([12.5]);a=endpoints(self.k,self.ka,self.lag,self.doses,p,'linear');b=endpoints(self.k,self.ka,self.lag,[[100,0],[100,8],[100,16]],p,'linear')
        self.assertAlmostEqual(a['auc24'],b['auc24'],places=8);self.assertLess(b['cmax'],a['cmax']);self.assertGreater(b['cmin'],a['cmin'])

    def test_structural_ratio(self):
        K=np.exp(self.p[1]);ratio=3*dose_auc(100,self.p,'sat')/(2*dose_auc(150,self.p,'sat'))
        self.assertAlmostEqual(ratio,(K+150)/(K+100));self.assertGreater(ratio,1);self.assertLess(ratio,1.5)

    def test_fit(self):
        x=np.array([50,100,150,200]*4);y=dose_auc(x,self.p,'sat')
        p,res=fit_dose(x,y,'sat');np.testing.assert_allclose(p,self.p,atol=1e-6)

    def test_grid(self):
        a=endpoints(self.k,self.ka,self.lag,self.doses,self.p,'sat',.02);b=endpoints(self.k,self.ka,self.lag,self.doses,self.p,'sat',.002)
        for name in a:self.assertAlmostEqual(a[name]/b[name],1,delta=1e-5)

    def test_multiplier(self):
        t=np.linspace(0,24,301);a=profile(t,self.k,self.ka,self.lag,self.doses,self.p,'sat');b=profile(t,self.k,self.ka,self.lag,self.doses,self.p,'sat',2.1)
        np.testing.assert_allclose(b/a,2.1)

    def test_periodic_and_positive(self):
        t=np.linspace(-24,24,200);a=profile(t,self.k,self.ka,self.lag,self.doses,self.p,'sat');b=profile(t+24,self.k,self.ka,self.lag,self.doses,self.p,'sat')
        self.assertTrue(np.all(a>0));np.testing.assert_allclose(a,b,atol=1e-10)

    def test_shape_fit(self):
        v=np.array([np.log(.22),np.log(.7),.37,np.log(2000)]);t=np.array([0,.5,1,1.5,2,3,4,8,12]);c=shape_curve(t,v);p=fit_shape(t,c)
        np.testing.assert_allclose(shape_curve(t,p),c,rtol=1e-5)


if __name__=='__main__':unittest.main()
