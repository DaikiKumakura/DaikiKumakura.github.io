# Olomorasib: conditional fractionation of 300 mg/day

Research and PK comparison planning only, not treatment instructions.
Existing Python matching requirements.txt:
  python analysis/run_analysis.py
  python -m unittest discover -s analysis -p "test_model.py" -q
No network, original workbook/PDF or account needed.

Murciano-Goroff et al. Nature Communications2026;17:3834.
https://doi.org/10.1038/s41467-026-69943-7
SourceData SuppFig2A and2B, 36 mean concentration points and212NCA AUC records.
Units mg,h,plasma ng/mL,AUC ng*h/mL, BIDsteady-state AUC0-12h.
Extracted input values adapted under CC BY4.0:
https://creativecommons.org/licenses/by/4.0/
Changes: columns selected, long-form dose/endpoints, original source-ID labels
replaced by unrelated block numbers preserving grouping. No outcome/genomic
columns, full workbook, original IDs or protocol included. These are real public
NCA endpoints, not reconstructed patient concentration timecourses.
Dose counts16/37/146/13;201source-ID labels,8multidose blocks. Not212people or
201verifieduniquepeople. Sourcepatient195denominator differs; chronology unknown.

Fit logAUC=aD versus Amax*D/(D50+D). No claim absorption mechanism or NLMEfit.
Allrecords contribute;150mgdominates due group size. No independentAIC/LRT.
1000 source-ID blockbootstrap, seed20261024; source-ID may not exhaust actual
patientdependence. D50upper bound1e7,nearlinear flag>1e6. Saturatingmodel TID/BID
AUC ratio=(D50+150)/(D50+100)>1 by construction, not evidence for clinical
superiority. Proportional model ratio1. Retain model-choice uncertainty.

150mg mean9points estimate k,ka>k,lag<1h andscale using logresiduals. Mean
profile scale differs NCA geometric mean and is not forced equal. Half3.18h
not source2.96h. Otherdoseprofile scales refitted;notabsoluteexternalvalidation.
Timeprofile9points/dose noSD/n, noIIVtimeparameter estimation. Fixedshape
combined with doseAUC scale under independent absorption peradministration.
No measuredTID, no occupancy/efficacy/safety or optimalclinicalregimen prediction.

Regimens150BID0/12,100TID0/8/16,100BID,200BID,100TID0/6/12.24hperiodicstate,
truecycleCmin including lag points,not arbitrarypredose. No startup comparison.
2048 common empiricalcenteredlogresidual exposuremultipliers preserve paired
comparison; ratioscancel multiplier. Residual not separable patient/occasion/error.
No sourcepatientpopreconstruction, no newtreatmentheterogeneity. Shape sensitivity
sourcehalfCI ends/modelhalf andka0.5/2 are assumptions,notjointIIVorCI.
6aggregateCSV including bootstrap output,3originalfigures,results/environment/hashes.
9 tests: independentODE event solution,periodicmass,fit,grid andalgebra checks.
CodeMIT. ExtractedsourceinputdataCCBY4.0 as cited,notcoveredbycodeMIT.
