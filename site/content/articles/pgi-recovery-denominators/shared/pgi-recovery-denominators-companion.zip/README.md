# PGI headline numbers by denominator: companion code

Exact (Clopper-Pearson) intervals and a Newcombe interval computed from counts printed in the PGI preprint (Qiao et al., bioRxiv 10.64898/2026.10.23.761278), the implied spread of per-study recovery, and two figures. No model or data are re-run.

- `analysis.py`: counts, intervals, implied spread.
- `figures.py`: Figures 1 and 2.
- `test_analysis.py`: checks (`python -m pytest test_analysis.py`).
- `results/`: CSV outputs.

Requires Python 3 with numpy, scipy, pandas, matplotlib.
