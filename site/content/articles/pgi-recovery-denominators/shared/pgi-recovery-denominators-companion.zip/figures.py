"""Figure 1: path-level recovery decomposition. Figure 2: proportions with exact intervals for the benchmark rows and the two T1D denominators."""
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parent
(ROOT / "figures").mkdir(exist_ok=True)
t = pd.read_csv(ROOT / "results" / "reported-proportions-with-intervals.csv").set_index("item")
rows = [
    ("313 published questions: VariantAgent", "Published genetic-reasoning questions: VariantAgent", "#D55E00"),
    ("313 published questions: best comparator (OpenCode)", "Published genetic-reasoning questions: OpenCode", "#0072B2"),
    ("26 GWAS-grounded, correct: VariantAgent", "GWAS-grounded questions: VariantAgent", "#D55E00"),
    ("26 GWAS-grounded, correct: Biomni", "GWAS-grounded questions: Biomni", "#0072B2"),
    ("26 GWAS-grounded, process-validated: VariantAgent", "GWAS-grounded process-validated: VariantAgent", "#D55E00"),
    ("26 GWAS-grounded, process-validated: Biomni", "GWAS-grounded process-validated: Biomni", "#0072B2"),
    ("T1D: 5 of 7 prespecified findings", "T1D: prespecified directly comparable findings recovered", "#009E73"),
    ("T1D: 3 of 12 source-study paths", "T1D: source-study paths recovered", "#009E73"),
]
fig, ax = plt.subplots(figsize=(8.0, 4.4), dpi=150)
for i, (lab, key, col) in enumerate(rows):
    r = t.loc[key]
    y = len(rows) - i
    ax.hlines(y, r.ci_lo, r.ci_hi, color=col, lw=3)
    ax.plot(r.percent, y, "o", color=col, ms=6)
    ax.text(101, y, f"{int(r.k)}/{int(r.n)}", va="center", fontsize=7)
ax.set_yticks(range(len(rows), 0, -1))
ax.set_yticklabels([r[0] for r in rows], fontsize=7)
ax.set_xlim(0, 112)
ax.set_xlabel("Percent (exact 95% interval)")
fig.tight_layout()
fig.savefig(ROOT / "figures" / "02-benchmark-proportions.png")

fig, ax = plt.subplots(figsize=(7.2, 2.8), dpi=150)
cats = [("Fully recovered", 155, "#0072B2"), ("Recovered and extended", 450, "#56B4E9"), ("Partially recovered", 89, "#E69F00"), ("Not recovered", 45, "#D55E00")]
left = 0
for lab, k, col in cats:
    ax.barh(0, 100 * k / 739, left=left, color=col, label=f"{lab} ({k}, {100 * k / 739:.1f}%)")
    left += 100 * k / 739
ax.set_yticks([])
ax.set_xlim(0, 100)
ax.set_xlabel("Share of the 739 directly comparable source-study paths (%)")
ax.legend(fontsize=7, loc="upper center", bbox_to_anchor=(0.5, 1.45), ncol=2)
fig.tight_layout()
fig.savefig(ROOT / "figures" / "01-path-level-recovery.png", bbox_inches="tight")
