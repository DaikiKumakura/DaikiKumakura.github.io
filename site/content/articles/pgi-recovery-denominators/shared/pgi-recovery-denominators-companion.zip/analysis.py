"""What do the headline numbers of the Post-GWAS Intelligence (PGI) preprint count? Denominators, intervals and a decomposition, from reported counts.

Source: Qiao et al., Scaling genetic discovery through automated post-GWAS interpretation (bioRxiv 10.64898/2026.10.23.761278, version 1).
Only counts and percentages printed in the preprint are used; intervals are computed here (exact Clopper-Pearson for single proportions, Newcombe for a difference of two proportions
treated as independent). Reported intervals from the preprint (82.1%, 95% CI 75.3-88.9 over 34 studies; 7.7 points, 95% CI 3.8-11.8 by a paired bootstrap) are used as printed.
"""
from pathlib import Path

import numpy as np
import pandas as pd
from scipy.stats import beta, norm, t

ROOT = Path(__file__).resolve().parent
OUT = ROOT / "results"
OUT.mkdir(exist_ok=True)


def clopper_pearson(k: int, n: int, level: float = 0.95):
    a = (1 - level) / 2
    return (0.0 if k == 0 else beta.ppf(a, k, n - k + 1)), (1.0 if k == n else beta.ppf(1 - a, k + 1, n - k))


def newcombe(k1, n1, k2, n2, level=0.95):
    z = norm.ppf(1 - (1 - level) / 2)

    def wilson(k, n):
        p = k / n
        d = 1 + z * z / n
        c = (p + z * z / (2 * n)) / d
        h = z * np.sqrt(p * (1 - p) / n + z * z / (4 * n * n)) / d
        return c - h, c + h

    l1, u1 = wilson(k1, n1)
    l2, u2 = wilson(k2, n2)
    p1, p2 = k1 / n1, k2 / n2
    d = p1 - p2
    return d, d - np.sqrt((p1 - l1) ** 2 + (u2 - p2) ** 2), d + np.sqrt((u1 - p1) ** 2 + (p2 - l2) ** 2)


COUNTS = [  # label, k, n, what is counted (as printed in the preprint)
    ("Published genetic-reasoning questions: VariantAgent", 270, 313, "correct answers"),
    ("Published genetic-reasoning questions: OpenCode", 246, 313, "correct answers"),
    ("Published genetic-reasoning questions: Tool Universe", 241, 313, "correct answers"),
    ("Published genetic-reasoning questions: Claude Code", 235, 313, "correct answers"),
    ("GWAS-grounded questions: VariantAgent", 17, 26, "open-answer accuracy"),
    ("GWAS-grounded questions: Biomni", 14, 26, "open-answer accuracy"),
    ("GWAS-grounded questions: Claude Code", 12, 26, "open-answer accuracy"),
    ("GWAS-grounded process-validated: VariantAgent", 16, 26, "answers correct and methodologically supported"),
    ("GWAS-grounded process-validated: Biomni", 8, 26, "answers correct and methodologically supported"),
    ("GWAS-grounded process-validated: Claude Code", 2, 26, "answers correct and methodologically supported"),
    ("Valid trace among correct answers: VariantAgent", 16, 17, "correct answers with valid trace"),
    ("Valid trace among correct answers: Biomni", 8, 14, "correct answers with valid trace"),
    ("Valid trace among correct answers: Claude Code", 2, 12, "correct answers with valid trace"),
    ("Evidence-admission decisions agreeing with blinded experts", 24, 26, "traces (92.3% printed)"),
    ("T1D: prespecified directly comparable findings recovered", 5, 7, "findings"),
    ("T1D: source-study paths recovered", 3, 12, "paths"),
    ("34 GWAS: paths fully recovered", 155, 739, "directly comparable source-study paths"),
    ("34 GWAS: paths recovered and extended", 450, 739, "directly comparable source-study paths"),
    ("34 GWAS: paths recovered or extended", 605, 739, "directly comparable source-study paths"),
    ("34 GWAS: paths partially recovered", 89, 739, "directly comparable source-study paths"),
    ("34 GWAS: paths not recovered", 45, 739, "directly comparable source-study paths"),
]


def main() -> None:
    rows = []
    for label, k, n, what in COUNTS:
        lo, hi = clopper_pearson(k, n)
        rows.append(dict(item=label, k=k, n=n, percent=100 * k / n, ci_lo=100 * lo, ci_hi=100 * hi, counted=what))
    tab = pd.DataFrame(rows)
    tab.round(2).to_csv(OUT / "reported-proportions-with-intervals.csv", index=False, lineterminator=chr(10))
    pd.set_option("display.width", 250)
    print(tab.round(1).to_string())
    # path-level categories add up
    cats = dict(full=155, extended=450, partial=89, none=45)
    assert sum(cats.values()) == 739
    # difference of the two top agents on 313 questions
    d, lo, hi = newcombe(270, 313, 246, 313)
    print("VariantAgent - OpenCode: %.2f points (Newcombe unpaired %.1f to %.1f); preprint: 7.7 (3.8 to 11.8, paired bootstrap)" % (100 * d, 100 * lo, 100 * hi))
    # study-level spread implied by the reported interval of the mean per-study recovery (34 studies)
    half = (88.9 - 75.3) / 2
    for name, crit in (("normal", norm.ppf(0.975)), ("t, 33 df", t.ppf(0.975, 33))):
        se = half / crit
        print("implied SE %.2f points, implied SD across studies %.1f points (%s)" % (se, se * np.sqrt(34), name))
    pd.DataFrame([dict(difference_points=100 * d, newcombe_lo=100 * lo, newcombe_hi=100 * hi, implied_study_sd_normal=half / norm.ppf(0.975) * np.sqrt(34),
                       implied_study_sd_t=half / t.ppf(0.975, 33) * np.sqrt(34))]).round(2).to_csv(OUT / "difference-and-implied-spread.csv", index=False, lineterminator=chr(10))
    # T1D: share of the 608 assembled paths by evidence type
    t1d = dict(source_backed_only=566, source_and_predictive=18, graph_nominated=24)
    print("T1D paths:", t1d, "sum", sum(t1d.values()), "predictive or graph-nominated share %.1f%%" % (100 * (18 + 24) / 608))
    ratio = 608 / 12
    print("T1D assembled / source paths ratio %.1f" % ratio)


if __name__ == "__main__":
    main()
