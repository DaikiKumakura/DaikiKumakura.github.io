import numpy as np
from scipy.stats import binomtest

import analysis as an


def test_clopper_pearson_matches_scipy():
    for k, n in [(270, 313), (17, 26), (5, 7), (605, 739)]:
        ref = binomtest(k, n).proportion_ci(confidence_level=0.95, method="exact")
        lo, hi = an.clopper_pearson(k, n)
        assert abs(lo - ref.low) < 1e-9 and abs(hi - ref.high) < 1e-9


def test_reported_percentages_are_reproduced_from_counts():
    printed = {"Published genetic-reasoning questions: VariantAgent": 86.3, "Published genetic-reasoning questions: OpenCode": 78.6,
               "GWAS-grounded questions: VariantAgent": 65.4, "GWAS-grounded process-validated: VariantAgent": 61.5,
               "Valid trace among correct answers: VariantAgent": 94.1, "34 GWAS: paths recovered or extended": 81.9}
    counts = {c[0]: (c[1], c[2]) for c in an.COUNTS}
    for k, v in printed.items():
        assert abs(100 * counts[k][0] / counts[k][1] - v) < 0.06


def test_path_categories_sum_to_739_and_recovered_or_extended_is_the_sum():
    assert 155 + 450 + 89 + 45 == 739 and 155 + 450 == 605


def test_newcombe_difference_equals_point_difference():
    d, lo, hi = an.newcombe(270, 313, 246, 313)
    assert abs(d - 24 / 313) < 1e-12 and lo < d < hi
