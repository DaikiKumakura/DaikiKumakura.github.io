# Zongertinib weight-based dosing

Public-model research only, not treatment or clinical-trial dose advice.
Use your Python environment with requirements.txt.
Run: python analysis/run_analysis.py
Tests: python -m unittest discover -s analysis -p "test_*.py" -q
No downloads or accounts required. Numeric facts and source URLs: analysis/inputs.json.

FDA NDA219042 multidisciplinary review, Table79 PDF297-298, Figure19 PDF303,
Table89 PDF361. February2026 US label and August2026 DailyMed update. Data-derived
clinical estimation is NOT performed. New inverse least-squares fitting only
reconstructs the rounded MODEL-DERIVED120mg row of Table89;180mg row is a
same-model numerical holdout, not clinical external validation. Fixed allometry
of0.75 is used in the main analysis. No confidence interval for this inverse fit.

Two-compartment PK with zero-order input to absorption compartment then first-order
absorption. CL7.22L/h,Vc82.6L,Vp48.2L,Q3.55L/h,D1=1.03h,ka1.22/h are public apparent
coefficients. Do NOT multiply absolute F0.76 again. Reference70kg; other covariate
effects are fixed at unity. This is a transparent reconstruction, not original
NONMEM code replay. MAT IIV scalesD1 and inverseka jointly as an explicit choice.
The convolution input first momentD1/2+1/ka=1.335h differs from named publicMAT1.85h
(approximatelyD1+1/ka). Original definition/code is unresolved: PK shapes are
auxiliary reconstructions, NOT qualified predictions of original absorption.
Weight-AUC results do not depend on this input-time interpretation.

IIV CV(CL,Vc,MAT)=0.244,0.285,0.415 converted by log(1+CV^2); etaCL/etaVc
correlation0.601 retained. IOVMAT and transformedIOVF are NOT reproduced; fixed0.
No residual assay error added to true exposure.4096 identical eta draws per weight
stratum, same patient across policies. No clinical joint covariate distribution or
patient weight frequencies assumed; no pooled population improvement rates.

Fixed120QD, current120/180QD at90kg, theoretical120*(weight/70)^0.75 comparison.
Continuous-dose AUC matching follows algebra, not new empirical evidence.
The ideal dose is not necessarily deliverable with60mg tablets. No new dose
recommendation. The0.8-1.25 reference band is purely illustrative, NOT a therapeutic
window or evidence of bioequivalence. Patient percentiles are NOT confidence bounds.
Same fixed weight and periodic steady state, not a time-varying weight dosing rule.

Nearest-log-reference-AUC switching weight91.7kg follows our specified mathematical
loss, not FDA's clinical utility function. Exponent0.5-1 sensitivity is assumed,
not an estimated confidence interval. No new ORR/DOR/PFS/toxicity prediction.
Reference AUC/Cmax differ from label population geometric means; no validation claim.

Tables/figures are regenerated. Source-hashes.json is the original consulted-source
snapshot; rerunning without raw PDFs retains it and is not fresh source verification.
Raw PDFs, original figures, patient records and private notes are not redistributed.
Original code uses MIT (LICENSE); numerical source facts remain attributed.
