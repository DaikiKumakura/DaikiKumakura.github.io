"""Conditional reconstruction; mg,h,L. No original NONMEM code replay."""
import numpy as np
from scipy.optimize import least_squares

def fit_power(table: dict) -> dict:
    x=np.log(np.asarray(table['weight'])/70.)
    y=np.log(np.asarray(table['ratio120_percent'])/100.)
    result=least_squares(lambda a:y+a[0]*x,[.75])
    assert result.success
    a=float(result.x[0]);pred=100*np.exp(-a*x)
    hold=150*(np.asarray(table['weight180'])/70.)**(-a)
    return dict(exponent=a,max120_error_percentage_points=float(np.max(abs(pred-np.array(table['ratio120_percent'])))),max180_error_percentage_points=float(np.max(abs(hold-np.array(table['ratio180_percent'])))),method='Inverse fit to rounded model-derived table; no clinical parameter estimation or confidence interval')

def dose(weight, policy: str, exponent: float = .75):
    w=np.asarray(weight,dtype=float)
    if policy=='fixed':return np.full_like(w,120.)
    if policy=='step':return np.where(w<90,120.,180.)
    if policy=='continuous':return 120*(w/70.)**exponent
    raise ValueError(policy)

def ratio(weight, dose_mg, exponent: float = .75):
    return np.asarray(dose_mg)/120*(np.asarray(weight)/70.)**(-exponent)

def switching_weight(exponent: float):
    return 70*1.5**(1/(2*exponent))

def draw_eta(n: int, seed: int, cv: dict):
    z=np.random.default_rng(seed).normal(size=(n,3));rho=cv['correlation_cl_vc']
    z[:,1]=rho*z[:,0]+np.sqrt(1-rho*rho)*z[:,1]
    sd=np.sqrt(np.log1p(np.array([cv['cl'],cv['vc'],cv['mat']])**2))
    return z*sd

def matrices(p: dict, weight: float, eta: np.ndarray):
    eta=np.atleast_2d(eta);w=weight/p['weight_ref']
    cl=p['cl']*w**p['cl_power']*np.exp(eta[:,0])
    vc=p['vc']*w**p['volume_power']*np.exp(eta[:,1])
    vp=p['vp']*w**p['volume_power'];q=p['q']*w**p['cl_power']
    scale=np.exp(eta[:,2]);ka=p['ka']/scale;d1=p['d1']*scale
    m=np.zeros((len(eta),3,3));m[:,0,0]=-ka;m[:,1,0]=ka
    m[:,1,1]=-(cl+q)/vc;m[:,1,2]=q/vp;m[:,2,1]=q/vc;m[:,2,2]=-q/vp
    return m,vc,cl,d1

def profile(p: dict, weight: float, dose_mg: float, eta: np.ndarray, dt: float = .05):
    """Exact piecewise-constant input, periodic24h solution via spectral modes."""
    m,vc,cl,d1=matrices(p,weight,eta);assert np.all(d1<24)
    lam,v=np.linalg.eig(m);assert np.max(abs(lam.imag))<1e-9
    lam=lam.real;v=v.real;vinv=np.linalg.inv(v)
    u=vinv[:,:,0]*(dose_mg/d1)[:,None]
    x0=u/lam*np.exp(lam*(24-d1[:,None]))*np.expm1(lam*d1[:,None])/(-np.expm1(lam*24))
    t=np.arange(round(24/dt)+1)*dt
    lt=lam[:,:,None]*t[None,None,:]
    during=np.minimum(t[None,:],d1[:,None]);after=np.maximum(t[None,:]-d1[:,None],0)
    response=np.exp(lam[:,:,None]*after[:,None,:])*np.expm1(lam[:,:,None]*during[:,None,:])
    modes=np.exp(lt)*x0[:,:,None]+u[:,:,None]/lam[:,:,None]*response
    conc=np.einsum('nk,nkt->nt',v[:,1,:],modes)/vc[:,None]
    assert conc.min()>-1e-9
    auc=dose_mg/cl
    return dict(time=t,conc=conc,auc24=auc,cmax=conc.max(axis=1),cmin=conc.min(axis=1),tmax=t[conc.argmax(axis=1)],auc_numeric=np.trapz(conc,t,axis=1),state0=np.einsum('nij,nj->ni',v,x0),d1=d1)
