from pathlib import Path
import json,unittest
import numpy as np
from scipy.integrate import solve_ivp
from model import fit_power,dose,ratio,switching_weight,draw_eta,profile,matrices
I=json.loads((Path(__file__).parent/'inputs.json').read_text(encoding='utf8'));P=I['pk'];Z=np.zeros((1,3))
class ModelTests(unittest.TestCase):
    def test_rounded_table_reconstruction_and_holdout(self):
        f=fit_power(I['table89'])
        self.assertAlmostEqual(f['exponent'],.75,delta=.005)
        self.assertLess(f['max180_error_percentage_points'],.51)
    def test_boundary_inclusive(self):
        self.assertEqual(dose(89.999,'step'),120)
        self.assertEqual(dose(90,'step'),180)
    def test_nearest_log_boundary(self):
        c=switching_weight(.75)
        self.assertAlmostEqual(abs(np.log(ratio(c,120))),abs(np.log(ratio(c,180))))
        for w in [c-1,c+1]:
            winner=120 if w<c else 180
            loser=180 if w<c else 120
            self.assertLess(abs(np.log(ratio(w,winner))),abs(np.log(ratio(w,loser))))
    def test_continuous_normalization_is_algebraic(self):
        w=np.array([33.6,70,90,122]);np.testing.assert_allclose(ratio(w,dose(w,'continuous')),1)
    def test_absolute_auc_mass_balance_and_units(self):
        a=profile(P,70,120,Z)
        self.assertAlmostEqual(a['auc24'][0],120/7.22)
        np.testing.assert_allclose(a['auc_numeric'],a['auc24'],rtol=1e-5)
        self.assertAlmostEqual(a['auc24'][0]*1000/535.6,31.0315508121,places=7)
    def test_spectral_solution_against_independent_ode(self):
        a=profile(P,90,180,Z);m,vc,_,d1=matrices(P,90,Z);u=np.array([180/d1[0],0,0]);x0=a['state0'][0]
        first=solve_ivp(lambda t,x:m[0]@x+u,(0,d1[0]),x0,rtol=1e-10,atol=1e-12,dense_output=True)
        last=solve_ivp(lambda t,x:m[0]@x,(d1[0],24),first.y[:,-1],rtol=1e-10,atol=1e-12,dense_output=True)
        y=np.column_stack([first.sol(t) if t<=d1[0] else last.sol(t) for t in a['time']])
        np.testing.assert_allclose(y[1]/vc[0],a['conc'][0],rtol=2e-8)
        np.testing.assert_allclose(y[:,-1],x0,rtol=2e-8,atol=1e-10)
    def test_linear_dose_scaling(self):
        a=profile(P,110,120,Z);b=profile(P,110,180,Z)
        np.testing.assert_allclose(b['conc'],1.5*a['conc'],rtol=1e-12)
    def test_public_cv_conversion_and_correlation(self):
        e=draw_eta(30000,42,I['iiv_cv']);np.testing.assert_array_equal(e,draw_eta(30000,42,I['iiv_cv']))
        np.testing.assert_allclose(np.var(e,axis=0),np.log1p(np.array([.244,.285,.415])**2),rtol=.03)
        self.assertAlmostEqual(np.corrcoef(e[:,:2].T)[0,1],.601,delta=.02)
    def test_extreme_weights_finite_and_balance(self):
        eta=draw_eta(64,42,I['iiv_cv'])
        for w in [33.6,122]:
            a=profile(P,w,120,eta)
            self.assertTrue(np.isfinite(a['conc']).all())
            np.testing.assert_allclose(a['auc_numeric'],a['auc24'],rtol=1e-4)
if __name__=='__main__':unittest.main()
