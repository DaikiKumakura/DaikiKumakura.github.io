from pathlib import Path
import hashlib,json,platform
import numpy as np,pandas as pd,scipy,matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from scipy.stats import norm
from model import fit_power,dose,ratio,switching_weight,draw_eta,profile

ROOT=Path(__file__).resolve().parents[1];I=json.loads((Path(__file__).parent/'inputs.json').read_text(encoding='utf8'))
OUT=ROOT/'outputs';TAB=OUT/'tables';FIG=OUT/'figures';POL=['fixed','step','continuous'];LABEL=['Fixed 120 mg','120/180 mg at 90 kg','Continuous power dose'];COLOR=['#0072B2','#D55E00','#009E73']
def save(p,d):p.write_text(json.dumps(d,indent=2,ensure_ascii=False)+'\n',encoding='utf8')
def main():
    TAB.mkdir(parents=True,exist_ok=True);FIG.mkdir(parents=True,exist_ok=True)
    p=I['pk'];cfg=I['config'];fit=fit_power(I['table89']);fit['public_fixed_exponent']=p['cl_power'];fit['switching_weight_kg']=switching_weight(p['cl_power']);save(OUT/'fit.json',fit)
    wt=np.array(I['table89']['weight']);r=np.array(I['table89']['ratio120_percent']);pr=100*ratio(wt,120,fit['exponent'])
    pd.DataFrame(dict(weight=wt,reported_percent=r,reconstructed_percent=pr,error_pp=pr-r)).to_csv(TAB/'table89-fit.csv',index=False)
    wt2=np.array(I['table89']['weight180']);pred=100*ratio(wt2,180,fit['exponent'])
    pd.DataFrame(dict(weight=wt2,reported_percent=I['table89']['ratio180_percent'],reconstructed_percent=pred,error_pp=pred-np.array(I['table89']['ratio180_percent']))).to_csv(TAB/'table89-holdout.csv',index=False)
    eta=draw_eta(cfg['n'],cfg['seed'],I['iiv_cv']);rows=[];typical=[];curves=[]
    ref_auc=120/p['cl'];ref_avg=ref_auc/24;maxerr=0.
    for w in cfg['weights']:
        base=profile(p,w,120,eta,cfg['dt']);maxerr=max(maxerr,float(np.max(abs(base['auc_numeric']/base['auc24']-1))))
        typ=profile(p,w,120,np.zeros((1,3)),cfg['dt'])
        for policy in POL:
            d=float(dose(w,policy,p['cl_power']));scale=d/120
            ar=base['auc24']*scale/ref_auc
            q=np.quantile(ar,[.05,.5,.95]);rows.append(dict(weight=w,policy=policy,dose_mg=d,auc_ratio_p05=q[0],auc_ratio_median=q[1],auc_ratio_p95=q[2],below_illustrative_band=float(np.mean(ar<cfg['band'][0])),above_illustrative_band=float(np.mean(ar>cfg['band'][1])),cmax_ratio_median=float(np.median(base['cmax']*scale/ref_avg)),cmin_ratio_median=float(np.median(base['cmin']*scale/ref_avg))))
            typical.append(dict(weight=w,policy=policy,dose_mg=d,auc_ratio=float(typ['auc24'][0]*scale/ref_auc),cmax_mg_l=float(typ['cmax'][0]*scale),cmin_mg_l=float(typ['cmin'][0]*scale)))
            if policy=='step' and w in [70,89.9,90]:curves.append((w,typ['time'],typ['conc'][0]*scale/ref_avg))
    frame=pd.DataFrame(rows);frame.to_csv(TAB/'conditional-population.csv',index=False);pd.DataFrame(typical).to_csv(TAB/'typical.csv',index=False)
    sens=[]
    for power in [.5,.75,1.]:
        c=switching_weight(power)
        for w in [70,90,110]:sens.append(dict(exponent=power,switching_weight=c,weight=w,step_auc_ratio=float(ratio(w,dose(w,'step'),power)),continuous_auc_ratio=float(ratio(w,dose(w,'continuous',p['cl_power']),power))))
    pd.DataFrame(sens).to_csv(TAB/'power-sensitivity.csv',index=False)
    d=draw_eta(100000,cfg['seed'],I['iiv_cv']);analytic_low=norm.cdf(np.log(.8)/np.sqrt(np.log1p(I['iiv_cv']['cl']**2)))
    verification=dict(reconstructed_input_mean_h=p['d1']/2+1/p['ka'],public_named_mat_h=p['mat'],duration_plus_inverse_ka_h=p['d1']+1/p['ka'],n_per_weight=cfg['n'],seed=cfg['seed'],max_auc_relative_error=maxerr,reference_auc_umol_h_l=ref_auc*1000/p['molecular_weight'],reference_cmax_umol_l=float(profile(p,70,120,np.zeros((1,3)))['cmax'][0]*1000/p['molecular_weight']),monte_carlo_reference_low=float(np.mean(np.exp(-d[:,0])<.8)),analytic_reference_low=float(analytic_low),near_boundary_step_auc_jump=float(ratio(90,180)/ratio(89.9,120)),continuous_exact_auc_deviation=float(max(abs(ratio(w,dose(w,'continuous'),.75)-1) for w in cfg['weights'])))
    assert maxerr<.001
    save(OUT/'verification.json',verification)
    save(OUT/'environment.json',dict(python=platform.python_version(),numpy=np.__version__,pandas=pd.__version__,scipy=scipy.__version__,matplotlib=matplotlib.__version__))
    files={f.name:hashlib.sha256(f.read_bytes()).hexdigest() for f in (ROOT/'data/raw').glob('*') if f.is_file()}
    if files:save(OUT/'source-hashes.json',files)
    plt.rcParams.update({'font.size':11,'axes.spines.top':False,'axes.spines.right':False,'axes.titleweight':'bold','text.color':'#23384d'})
    w=np.linspace(33.6,122,800)
    fig,ax=plt.subplots(figsize=(9,5.2),layout='constrained')
    for j,pol in enumerate(POL):ax.plot(w,ratio(w,dose(w,pol,p['cl_power'])),label=LABEL[j],color=COLOR[j],ls=['-','--','-.'][j],lw=2)
    ax.scatter(wt,r/100,s=25,color='#4c5660',marker='o',facecolors='none',label='FDA Table 89: 120 mg')
    ax.axvline(90,ls=':',color='#67727b');ax.axhline(1,ls=':',color='#67727b');ax.set(xlabel='Body weight (kg)',ylabel='Typical AUC0-24 / reference AUC',ylim=(0,1.9),title='Weight adjustment reduces a trend; the step remains')
    ax.legend(frameon=False,fontsize=9);fig.savefig(FIG/'01-weight-exposure.png',dpi=180);plt.close(fig)
    fig,axes=plt.subplots(1,2,figsize=(11,4.8),layout='constrained');s=np.sqrt(np.log1p(I['iiv_cv']['cl']**2))
    for j,pol in enumerate(POL):
        r=ratio(w,dose(w,pol,p['cl_power']))
        low=norm.cdf(np.log(.8/r)/s);high=norm.sf(np.log(1.25/r)/s)
        for a,y in zip(axes,[low,high]):a.plot(w,y*100,color=COLOR[j],ls=['-','--','-.'][j],label=LABEL[j]);a.set(xlabel='Body weight (kg)',ylabel='Conditional proportion (%)',ylim=(0,100))
    axes[0].set_title('Below 0.8 of typical reference AUC');axes[1].set_title('Above 1.25 of typical reference AUC');axes[0].legend(frameon=False,fontsize=9)
    fig.suptitle('Illustrative exposure band, NOT a therapeutic window\nCL IIV only; IOV fixed at 0; no patient weight distribution assumed',fontsize=12)
    fig.savefig(FIG/'02-exposure-tails.png',dpi=180);plt.close(fig)
    fig,axes=plt.subplots(1,2,figsize=(11,4.7),layout='constrained')
    for j,(ww,t,c) in enumerate(curves):axes[0].plot(t,c,label=f'{ww:g}kg, {float(dose(ww,"step")):g}mg',color=COLOR[j],ls=['-','--','-.'][j])
    axes[0].set(xlabel='Hours after dose at periodic steady state',ylabel='C / reference mean concentration',title='Auxiliary profiles near 90 kg',xlim=(0,24),ylim=(0,None));axes[0].legend(frameon=False,fontsize=9)
    powers=np.linspace(.5,1,200);axes[1].plot(powers,switching_weight(powers),color='#526473');axes[1].axhline(90,ls=':',color='#526473');axes[1].scatter([p['cl_power']],[fit['switching_weight_kg']],color=COLOR[1]);axes[1].set(xlabel='Assumed CL weight exponent',ylabel='Nearest-log-AUC switching weight (kg)',title='A mathematical comparator to 90 kg')
    fig.suptitle('Boundary effects and assumptions',fontsize=13);fig.savefig(FIG/'03-boundary.png',dpi=180);plt.close(fig)
    print(json.dumps({'fit':fit,'verification':verification,'selected':frame[(frame.weight.isin([70,89.9,90,110]))].to_dict(orient='records')},indent=2))
if __name__=='__main__':main()
