"""Independent adaptive quadrature of the two-eta log-normal linear PK likelihood.

Uses analytic infusion concentrations, explicit normal constants, posterior-mode
centering, a numerical posterior Hessian and 15/25-node Gauss-Hermite rules.
No population parameters are refit; this validates the likelihood of archived fits.
"""
from pathlib import Path
import numpy as np
import pandas as pd
from scipy.optimize import minimize
from scipy.special import logsumexp
from numpy.polynomial.hermite import hermgauss
from scipy.integrate import solve_ivp
ROOT=Path(__file__).resolve().parent
DATA=pd.read_csv(ROOT/'raw/nimoData.csv')

def concentrations(times,doses,fixed,etas,model):
    cl=np.exp(fixed.tcl+etas[:,0])[:,None]
    v=np.exp(fixed.tv+etas[:,1])[:,None]
    if model=='M1': rates=[cl/v];weights=[np.ones_like(cl)]
    else:
        q=np.exp(fixed.tq);v2=np.exp(fixed.tv2)
        k10=cl/v;k12=q/v;k21=q/v2
        total=k10+k12+k21;disc=np.sqrt(total*total-4*k10*k21)
        alpha=(total+disc)/2;beta=2*k10*k21/(total+disc)
        rates=[alpha,beta];weights=[(alpha-k21)/(alpha-beta),(k21-beta)/(alpha-beta)]
    result=np.zeros((len(etas),len(times)))
    for _,d in doses.iterrows():
        age=times[None,:]-d.TIME;u=np.minimum(np.maximum(age,0),d.AMT/d.RATE)
        post=np.maximum(age-d.AMT/d.RATE,0)
        for rate,weight in zip(rates,weights):
            result += (age>0)*d.RATE/v*weight*(-np.expm1(-rate*u))/rate*np.exp(-rate*post)
    return result

def nonlinear_concentrations(times,doses,fixed,etas):
    n=len(etas);cl=np.exp(fixed.tcl+etas[:,0]);v=np.exp(fixed.tv+etas[:,1])
    q=np.exp(fixed.tq);v2=np.exp(fixed.tv2);vmax=np.exp(fixed.tvmax);km=np.exp(fixed.tkm)
    starts=doses.TIME.to_numpy();ends=starts+(doses.AMT/doses.RATE).to_numpy()
    boundaries=np.unique(np.r_[0,times,starts,ends]);boundaries=boundaries[boundaries<=times.max()]
    state=np.zeros(2*n);values={0.:np.zeros(n)}
    for left,right in zip(boundaries[:-1],boundaries[1:]):
        mid=(left+right)/2;infusion=float(doses.loc[(starts<=mid)&(ends>mid),'RATE'].sum())
        def ode(t,a):
            center=a[:n];peripheral=a[n:];c=center/v
            return np.r_[infusion-cl*c-q*c+q/v2*peripheral-vmax*c/(km+c),q*c-q/v2*peripheral]
        solution=solve_ivp(ode,(left,right),state,method='DOP853',rtol=1e-9,atol=1e-10)
        if not solution.success:raise RuntimeError(solution.message)
        state=solution.y[:,-1];values[float(right)]=state[:n]/v
    return np.column_stack([values[float(t)] for t in times])

def individual_loglik(obs,dose,fixed,omega,model,initial=None):
    y=obs.DV.to_numpy();t=obs.TIME.to_numpy();sigma=fixed.sigma
    def joint(etas):
        c=nonlinear_concentrations(t,dose,fixed,etas) if model=='M3' else concentrations(t,dose,fixed,etas,model)
        prediction=np.log(c+1e-12)
        residual=y[None,:]-prediction
        log_observation=-len(y)*np.log(sigma)-len(y)/2*np.log(2*np.pi)-np.sum(residual*residual,axis=1)/(2*sigma*sigma)
        log_prior=-np.log(2*np.pi)-np.sum(np.log(omega))/2-np.sum(etas*etas/omega[None,:],axis=1)/2
        return log_observation+log_prior
    def negative(x):return -float(joint(np.asarray(x)[None,:])[0])
    optimum=minimize(negative,np.zeros(2) if initial is None else initial,method='BFGS',options={'gtol':1e-5,'maxiter':500})
    x=optimum.x;step=1e-3 if model=='M3' else 1e-4;h=np.zeros((2,2));center=negative(x)
    for i in range(2):
        ei=np.eye(2)[i]*step
        h[i,i]=(negative(x+ei)-2*center+negative(x-ei))/step**2
        for j in range(i):
            ej=np.eye(2)[j]*step
            h[i,j]=h[j,i]=(negative(x+ei+ej)-negative(x+ei-ej)-negative(x-ei+ej)+negative(x-ei-ej))/(4*step**2)
    assert np.linalg.eigvalsh(h).min()>0
    transform=np.linalg.cholesky(np.linalg.inv(h))
    values=[]
    for nodes in [15,25]:
        z,w=hermgauss(nodes);xx,yy=np.meshgrid(z,z,indexing='ij')
        grid=np.column_stack([xx.ravel(),yy.ravel()])
        etas=x[None,:]+np.sqrt(2)*grid@transform.T
        logweights=(np.log(w)[:,None]+np.log(w)[None,:]).ravel()
        integral=np.log(2)+np.linalg.slogdet(transform)[1]+logsumexp(logweights+joint(etas)+np.sum(grid*grid,axis=1))
        values.append(float(integral))
    return values

def run():
    rows=[]
    directories=[]
    for name in ['M1','M2','M3','refinement-corrected-M2','refinement-corrected-M3']:
        directories.extend(sorted((ROOT/'a02'/name).glob('start-*/completed.txt')))
    for marker in directories:
        directory=marker.parent;model=directory.parent.name[-2:]
        cache=directory/'independent-likelihood.json'
        if cache.exists():
            import json
            rows.append(json.loads(cache.read_text()));continue
        fixed=pd.read_csv(directory/'fixed-estimates.csv').set_index('parameter').estimate
        omega=np.diag(pd.read_csv(directory/'omega.csv',index_col=0).to_numpy())
        totals=np.zeros(2)
        predictions=pd.read_csv(directory/'predictions.csv')
        for pid,obs in DATA[DATA.EVID.eq(0)].groupby('ID'):
            dose=DATA[DATA.ID.eq(pid)&DATA.EVID.eq(1)]
            estimate=predictions[predictions.ID.eq(pid)].iloc[0]
            totals+=individual_loglik(obs,dose,fixed,omega,model,np.array([estimate['eta.cl'],estimate['eta.v']]))
        objective=pd.read_csv(directory/'objectives.csv',index_col=0)
        official=-2*float(objective.iloc[0]['Log-likelihood'])
        row=dict(run=directory.parent.name,start=int(directory.name.split('-')[1]),
            independent_minus2loglik_15=float(-2*totals[0]),independent_minus2loglik_25=float(-2*totals[1]),
            official_minus2loglik=official,independent_25_minus15=float(-2*(totals[1]-totals[0])),
            official_minus_independent_25=float(official+2*totals[1]),
            AIC_independent=float(-2*totals[1]+{'M1':5,'M2':7,'M3':9}[model]*2))
        import json
        cache.write_text(json.dumps(row,indent=2))
        rows.append(row)
        print('Independent likelihood:',directory.parent.name,directory.name,row['independent_minus2loglik_25'],flush=True)
    result=pd.DataFrame(rows)
    result.to_csv(ROOT/'a02/independent-likelihood-checks.csv',index=False)
    print(result.round(6).to_string(index=False))
    return result
if __name__=='__main__':run()
