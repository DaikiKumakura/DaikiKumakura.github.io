"""Higher-resolution independent-seed check of marginal LOSO metrics."""
from analyze_a03 import *
from scipy.stats import qmc
rows=[]
for m in BASE:
 for pid,ob in OBS.groupby('ID'):
  d=OUT/('nlminb-M1' if m=='M1' else m)/f'loso-{pid}';f,o=params(d)
  e=norm.ppf(qmc.Sobol(2,scramble=True,seed=20261005+int(pid)).random_base2(13))*np.sqrt(o)
  dose=DATA[DATA.ID.eq(pid)&DATA.EVID.eq(1)]
  lp=np.log(pred(ob.TIME.to_numpy(),dose,f,e,m)+1e-12)
  point=lp.mean(axis=0);ys=lp+np.random.default_rng(20261005+int(pid)).normal(scale=f.sigma,size=lp.shape)
  low,high=np.quantile(ys,[.05,.95],axis=0);dv=ob.DV.to_numpy()
  lpd=logsumexp(norm.logpdf(dv[None,:],loc=lp,scale=f.sigma),axis=0)-np.log(len(e))
  rows.append(dict(model=m,ID=pid,RMSE=float(np.sqrt(np.mean((dv-point)**2))),coverage=float(np.mean((dv>=low)&(dv<=high))),mean_lpd=float(lpd.mean())))
 print(m,'8192-draw Sobol verification finished',flush=True)
x=pd.DataFrame(rows).groupby('model')[['RMSE','coverage','mean_lpd']].mean().reset_index();x['RMSE_improvement_percent']=100*(1-x.RMSE/x.loc[x.model=='M1','RMSE'].iloc[0]);x.to_csv(OUT/'loso-integration-check.csv',index=False)
assert abs(x.RMSE_improvement_percent).max()<10
print(x.to_string(index=False))
