"""Subject exclusion sensitivity, with optimizer warnings retained."""
from analyze_a03 import *
rows=[]
for m in BASE:
 for pid in sorted(DATA.ID.unique()):
  d=OUT/('nlminb-M1' if m=='M1' else m)/f'loso-{pid}'
  f,o=params(d);x=scenario(f,o,m,n=1,amount=200)['tenth']['AUC'][0];y=scenario(f,o,m,n=1,amount=400)['tenth']['AUC'][0]
  s=pd.read_csv(d/'status.csv').iloc[0]
  rows.append(dict(model=m,excluded_ID=pid,screen_pass=bool(s.qualified),CL=np.exp(f.tcl),V1=np.exp(f.tv),Km=np.exp(f.tkm)if'tkm'in f else np.nan,Vmax=np.exp(f.tvmax)if'tvmax'in f else np.nan,typical_AUC200=x,typical_AUC400=y,typical_ratio400_200=y/x))
pd.DataFrame(rows).to_csv(OUT/'subject-influence.csv',index=False)
summary=[]
for m,g in pd.DataFrame(rows).groupby('model'):
 for n in ['CL','V1','Km','Vmax','typical_AUC200','typical_ratio400_200']:
  v=g[n].dropna()
  if len(v):summary.append(dict(model=m,endpoint=n,n=len(v),minimum=v.min(),median=v.median(),maximum=v.max(),screen_pass_folds=int(g.screen_pass.sum())))
pd.DataFrame(summary).to_csv(OUT/'subject-influence-summary.csv',index=False)
print(pd.DataFrame(summary).to_string(index=False))
