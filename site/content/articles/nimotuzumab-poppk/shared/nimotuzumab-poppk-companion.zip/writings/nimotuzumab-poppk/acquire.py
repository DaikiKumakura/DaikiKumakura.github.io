"""Download pinned package inputs and verify their recorded SHA-256."""
from pathlib import Path
import hashlib,json,urllib.request
root=Path(__file__).resolve().parent/'raw'
manifest=json.loads((root/'source-manifest.json').read_text())
for item in manifest['files']:
    data=urllib.request.urlopen(item['url'],timeout=60).read()
    if hashlib.sha256(data).hexdigest()!=item['sha256']:
        raise ValueError('Source hash mismatch: '+item['path'])
    target=root/item['file']
    if target.exists() and target.read_bytes()!=data:
        raise ValueError('Existing local file differs: '+str(target))
    target.write_bytes(data)
    print(item['path'],item['sha256'])
