"""Collect completed A03 runs and distinguish numerical output from qualification."""
from pathlib import Path
import numpy as np,pandas as pd,json
from analyze_a03 import params,scenario,BASE,DATA
R=Path(__file__).resolve().parent;A=R/'a03'
def run():
 statuses=[];bs=[];sens=[];profiles=[]
 for group in ['M1','M2','M3','nlminb-M1']:
  for st in sorted((A/group).glob('*/status.csv')):
   s=pd.read_csv(st).iloc[0].to_dict();s['group']=group;statuses.append(s)
   d=st.parent
   if s['finite'] and (d/'fixed-estimates.csv').exists():
    f,o=params(d)
    if s['run'].startswith('bootstrap-'):
     bs.extend([dict(group=group,replicate=int(s['run'].split('-')[1]),qualified=s['qualified'],parameter=n,natural_estimate=float(np.exp(v) if n.startswith('t') else v))for n,v in f.items()])
    if s['run'].startswith('profile-'):
     obj=pd.read_csv(d/'objectives.csv',index_col=0).iloc[0];profiles.append(dict(group=group,run=s['run'],qualified=s['qualified'],minus2loglik=-2*obj['Log-likelihood'],Km=np.exp(f.tkm),Vmax=np.exp(f.tvmax)))
    if s['run'] in ['baseline','infusion-0.5h','allometry-fixed']:
     x=scenario(f,o,group[-2:],n=1)
     for cyc,metrics in x.items():
      for ep,v in metrics.items():sens.append(dict(group=group,run=s['run'],qualified=s['qualified'],cycle=cyc,endpoint=ep,typical_value=v[0],weight_kg=70 if s['run']=='allometry-fixed' else np.nan))
 S=pd.DataFrame(statuses);S.to_csv(A/'run-status.csv',index=False);B=pd.DataFrame(bs);B.to_csv(A/'bootstrap-parameters.csv',index=False);pd.DataFrame(sens).to_csv(A/'input-sensitivity.csv',index=False);pd.DataFrame(profiles).to_csv(A/'profiles.csv',index=False)
 sums=[];ci=[]
 for group,g in S[S.run.str.startswith('bootstrap-')].groupby('group'):
  n=len(g);rate=g.qualified.mean();sums.append(dict(group=group,attempted=n,finite=int(g.finite.sum()),qualified=int(g.qualified.sum()),qualified_rate=rate,CI_defensible=n==200 and rate>=.8))
  if n==200 and rate>=.8:
   for p,v in B[(B.group==group)&B.qualified].groupby('parameter'):
    lo,med,hi=np.quantile(v.natural_estimate,[.025,.5,.975]);ci.append(dict(group=group,parameter=p,lower=lo,median=med,upper=hi))
 pd.DataFrame(sums).to_csv(A/'bootstrap-summary.csv',index=False);pd.DataFrame(ci,columns=['group','parameter','lower','median','upper']).to_csv(A/'bootstrap-CI.csv',index=False)
 # Retain screened estimates for audit; do not call selected successful runs a CI.
 xr=[]
 for st in sorted((A/'nlminb-M1').glob('bootstrap-*/status.csv')):
  s=pd.read_csv(st).iloc[0]
  if not s.qualified:continue
  f,o=params(st.parent);x=scenario(f,o,'M1',n=1)
  for cyc,metrics in x.items():
   for ep,v in metrics.items():xr.append(dict(replicate=s.run,cycle=cyc,endpoint=ep,value=v[0]))
 X=pd.DataFrame(xr);X.to_csv(A/'bootstrap-typical-exposure.csv',index=False)
 if len(X) and next(s for s in sums if s['group']=='nlminb-M1')['CI_defensible']:
  X.groupby(['cycle','endpoint']).value.quantile([.025,.5,.975]).unstack().to_csv(A/'bootstrap-typical-exposure-CI.csv')
 else:
  pd.DataFrame(columns=['cycle','endpoint','lower','median','upper']).to_csv(A/'bootstrap-typical-exposure-CI.csv',index=False)
 checks=json.loads((A/'integration-grid-check.json').read_text());err=[]
 for m in BASE:
  c=[r for r in checks if r['model']==m];maximum=max(float(np.max(np.abs(np.array(c[0][ep])/np.array(c[1][ep])-1)))for ep in ['AUC_first','AUC_tenth']);assert maximum<.01,(m,maximum);err.append(dict(model=m,max_relative_AUC_grid_change=maximum))
 pd.DataFrame(err).to_csv(A/'numerical-QA.csv',index=False)
 print(pd.DataFrame(sums).to_string(index=False));print(pd.read_csv(A/'loso-summary.csv').to_string(index=False))
if __name__=='__main__':run()
