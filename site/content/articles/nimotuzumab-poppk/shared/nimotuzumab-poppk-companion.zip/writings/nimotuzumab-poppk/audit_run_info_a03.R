p <- 'writings/nimotuzumab-poppk'
.libPaths(c(normalizePath(file.path(p,'.r-library')),.libPaths()))
library(nlmixr2est)
files <- list.files(file.path(p,'a03'),pattern='fit.rds$',recursive=TRUE,full.names=TRUE)
for (file in files) {
 d <- dirname(file); f <- readRDS(file); ri <- as.character(f$runInfo)
 writeLines(ri,file.path(d,'run-info-full.txt'))
 s <- read.csv(file.path(d,'status.csv')); w <- readLines(file.path(d,'warnings.txt'),warn=FALSE)
 s$qualified <- s$finite && !grepl('not at minimum|maximum.*iteration|failed|convergence',paste(c(ri,w),collapse=' '),ignore.case=TRUE)
 write.csv(s,file.path(d,'status.csv'),row.names=FALSE)
}
cat(length(files),'complete optimizer records audited\n')
