"""A03 diagnostics and exposure comparisons; writes no public data."""
from pathlib import Path
import json, numpy as np,pandas as pd
from scipy.special import logsumexp
from scipy.stats import norm
from verify_a02_likelihood import concentrations,nonlinear_concentrations
R=Path(__file__).resolve().parent;OUT=R/'a03';DATA=pd.read_csv(R/'raw/nimoData.csv');OBS=DATA[DATA.EVID.eq(0)].copy()
BASE={'M1':R/'a02/M1/start-3','M2':R/'a02/refinement-corrected-M2/start-2','M3':R/'a02/refinement-corrected-M3/start-3'}
def params(d):
 return pd.read_csv(d/'fixed-estimates.csv').set_index('parameter').estimate,np.diag(pd.read_csv(d/'omega.csv',index_col=0))
def pred(t,d,f,e,m):return nonlinear_concentrations(np.asarray(t),d,f,e) if m=='M3' else concentrations(np.asarray(t),d,f,e,m)
def diagnose():
 gofs=[];shrink=[];folds=[];vpcs=[];binrows=[]
 for m,d in BASE.items():
  f,o=params(d);g=pd.read_csv(d/'predictions.csv').merge(OBS[['ID','TIME','DOS','OCC']],on=['ID','TIME'],validate='one_to_one');assert len(g)==321
  g['model']=m;gofs.append(g)
  eta=g.groupby('ID')[['eta.cl','eta.v']].first()
  for j,n in enumerate(eta.columns):shrink.append(dict(model=m,parameter=n,SD_shrinkage=1-eta[n].std(ddof=1)/np.sqrt(o[j]),variance_shrinkage=1-eta[n].var(ddof=1)/o[j]))
  rng=np.random.default_rng(20261004);sim=[]
  for pid,ob in OBS.groupby('ID'):
   doses=DATA[DATA.ID.eq(pid)&DATA.EVID.eq(1)];e=rng.normal(size=(1000,2))*np.sqrt(o);cp=pred(ob.TIME.to_numpy(),doses,f,e,m);y=np.log(cp+1e-12)+rng.normal(scale=f.sigma,size=cp.shape)
   sim.append(pd.DataFrame(y.T,index=ob.index));last=doses.TIME.to_numpy();tad=ob.TIME.to_numpy()-last[np.searchsorted(last,ob.TIME.to_numpy(),side='right')-1]
   binrows.extend([dict(index=i,DOS=ob.DOS.iloc[0],occasion='first' if oc==1 else ('tenth' if oc==10 else 'other'),TAD=t) for i,oc,t in zip(ob.index,ob.OCC,tad)]) if m=='M1' else None
   ld=(OUT/'nlminb-M1'/f'loso-{pid}') if m=='M1' and (OUT/'nlminb-M1'/f'loso-{pid}'/'fixed-estimates.csv').exists() else OUT/m/f'loso-{pid}';ff,oo=params(ld);er=rng.normal(size=(2048,2))*np.sqrt(oo);lp=np.log(pred(ob.TIME.to_numpy(),doses,ff,er,m)+1e-12)
   # Marginal prediction uses no held-out DV to infer etas.
   point=lp.mean(axis=0);ys=lp+rng.normal(scale=ff.sigma,size=lp.shape);lo,hi=np.quantile(ys,[.05,.95],axis=0);lpd=logsumexp(norm.logpdf(ob.DV.to_numpy()[None,:],loc=lp,scale=ff.sigma),axis=0)-np.log(len(er))
   for i in range(len(ob)):folds.append(dict(model=m,ID=pid,DOS=ob.DOS.iloc[i],OCC=ob.OCC.iloc[i],TIME=ob.TIME.iloc[i],DV=ob.DV.iloc[i],marginal_prediction=point[i],lower=lo[i],upper=hi[i],covered=bool(lo[i]<=ob.DV.iloc[i]<=hi[i]),pointwise_log_predictive_density=lpd[i],squared_error=(ob.DV.iloc[i]-point[i])**2))
   print('diagnostic',m,pid,flush=True)
  sy=pd.concat(sim).sort_index();bins=pd.DataFrame(binrows).drop_duplicates('index').set_index('index');bins['bin']=pd.cut(bins.TAD,[0,2,30,72,168,360,720],include_lowest=True)
  for (dose,occ,b),ix in bins.groupby(['DOS','occasion','bin'],observed=True).groups.items():
   if occ=='other' or len(ix)<3:continue
   observed=np.quantile(OBS.loc[ix,'DV'],[.1,.5,.9]);sq=np.quantile(sy.loc[ix].to_numpy(),[.1,.5,.9],axis=0)
   for j,q in enumerate([.1,.5,.9]):
    low,med,high=np.quantile(sq[j],[.05,.5,.95]);vpcs.append(dict(model=m,dose=dose,occasion=occ,bin=str(b),quantile=q,n=len(ix),observed_log=observed[j],simulation_lower=low,simulation_median=med,simulation_upper=high))
 pd.concat(gofs).to_csv(OUT/'gof.csv',index=False);pd.DataFrame(shrink).to_csv(OUT/'shrinkage.csv',index=False);pd.DataFrame(folds).to_csv(OUT/'loso-observations.csv',index=False);pd.DataFrame(vpcs).to_csv(OUT/'vpc.csv',index=False)
 ff=pd.DataFrame(folds);pp=ff.groupby(['model','ID']).agg(MSE=('squared_error','mean'),coverage=('covered','mean'),mean_lpd=('pointwise_log_predictive_density','mean'));pp['RMSE']=np.sqrt(pp.MSE);pp.to_csv(OUT/'loso-patients.csv');pp.groupby('model').mean().to_csv(OUT/'loso-summary.csv')
 ff.groupby(['model','DOS','OCC']).agg(MSE=('squared_error','mean'),coverage=('covered','mean'),mean_lpd=('pointwise_log_predictive_density','mean'),n=('DV','size')).to_csv(OUT/'loso-dose-occasion.csv')

def scenario(f,o,m,n=10000,amount=200,interval=168,duration=.5,weights=None):
 e=np.zeros((1,2)) if n==1 else np.random.default_rng(20261004).normal(size=(n,2))*np.sqrt(o)
 if weights is not None:
  e[:,0]+=.75*np.log(np.asarray(weights)/70)
  e[:,1]+=np.log(np.asarray(weights)/70)
 doses=pd.DataFrame({'TIME':np.arange(10)*interval,'AMT':amount,'RATE':amount/duration})
 # Only evaluate first and tenth intervals; ODE still propagates through all doses.
 t=np.unique(np.r_[np.linspace(0,interval,337),duration,np.linspace(9*interval,10*interval,337),9*interval+duration]);cp=pred(t,doses,f,e,m)
 res={}
 for label,start in [('first',0),('tenth',9*interval)]:
  ix=(t>=start)&(t<=start+interval);c=cp[:,ix];times=t[ix];auc=np.trapezoid(c,times,axis=1)
  res[label]=dict(AUC=auc,Cmax=c.max(axis=1),Ctrough=c[:,-1],Cavg=auc/interval)
 return res

def exposure():
 rows=[];ratios=[]
 specs=[(f'dose-{a}',a,168,.5) for a in [50,100,200,400]]+[(f'interval-{h}',200,h,.5)for h in [144,192]]+[('infusion-1h',200,168,1)]
 for m,d in BASE.items():
  f,o=params(d);reference=scenario(f,o,m)
  for name,a,h,dur in specs:
   s=reference if name=='dose-200' else scenario(f,o,m,amount=a,interval=h,duration=dur)
   for cycle,metrics in s.items():
    for ep,v in metrics.items():
     q=np.quantile(v,[.1,.5,.9]);rq=np.quantile(v/reference[cycle][ep],[.1,.5,.9]);rows.append(dict(model=m,scenario=name,amount_mg=a,interval_h=h,infusion_h=dur,cycle=cycle,endpoint=ep,p10=q[0],median=q[1],p90=q[2]));ratios.append(dict(model=m,scenario=name,cycle=cycle,endpoint=ep,p10=rq[0],median=rq[1],p90=rq[2]))
   pd.DataFrame(rows).to_csv(OUT/'exposure.csv',index=False);pd.DataFrame(ratios).to_csv(OUT/'paired-ratios.csv',index=False);print('exposure',m,name,flush=True)
 # Numerical grid check for AUC; dense grid result on a small, identical cohort.
 checks=[]
 for m,d in BASE.items():
  f,o=params(d);e=np.random.default_rng(20261004).normal(size=(32,2))*np.sqrt(o);dose=pd.DataFrame({'TIME':np.arange(10)*168,'AMT':200,'RATE':400})
  for k in [337,673]:
   t=np.unique(np.r_[np.linspace(0,168,k),.5,np.linspace(1512,1680,k),1512.5]);c=pred(t,dose,f,e,m)
   checks.append(dict(model=m,grid=k,AUC_first=np.trapezoid(c[:,t<=168],t[t<=168],axis=1).tolist(),AUC_tenth=np.trapezoid(c[:,t>=1512],t[t>=1512],axis=1).tolist()))
 (OUT/'integration-grid-check.json').write_text(json.dumps(checks),encoding='utf-8')

if __name__=='__main__':
 import sys
 if sys.argv[1]=='diagnose':diagnose()
 if sys.argv[1]=='exposure':exposure()
