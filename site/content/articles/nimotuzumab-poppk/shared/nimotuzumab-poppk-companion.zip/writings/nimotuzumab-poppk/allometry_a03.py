from analyze_a03 import *
rows=[]
weights=np.random.default_rng(20261004).choice(DATA.groupby('ID').WGT.first().to_numpy(),size=10000,replace=True)
for m in BASE:
 f,o=params(OUT/m/'allometry-fixed')
 x=scenario(f,o,m,weights=weights)
 y=scenario(f,o,m,weights=np.full(10000,70.))
 for cyc,metrics in x.items():
  for ep,v in metrics.items():
   q=np.quantile(v,[.1,.5,.9]); r=np.quantile(v/y[cyc][ep],[.1,.5,.9])
   rows.append(dict(model=m,cycle=cyc,endpoint=ep,p10=q[0],median=q[1],p90=q[2],paired_weight_ratio_p10=r[0],paired_weight_ratio_median=r[1],paired_weight_ratio_p90=r[2]))
 print(m,'weight resampling complete',flush=True)
pd.DataFrame(rows).to_csv(OUT/'allometry-exposure.csv',index=False)
