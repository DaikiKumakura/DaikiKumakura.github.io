"""Independently check nlmixr2est's event handling using analytic linear PK."""
from pathlib import Path
import numpy as np
import pandas as pd
from scipy.integrate import solve_ivp
ROOT=Path(__file__).resolve().parent
raw=pd.read_csv(ROOT/'raw/nimoData.csv')

def linear_predictions(times,doses,cl,v,q=None,v2=None):
    if q is None:
        rates=[cl/v]; weights=[1.]
    else:
        k10=cl/v;k12=q/v;k21=q/v2
        total=k10+k12+k21
        disc=np.sqrt(total*total-4*k10*k21)
        alpha=(total+disc)/2; beta=2*k10*k21/(total+disc)
        rates=[alpha,beta]; weights=[(alpha-k21)/(alpha-beta),(k21-beta)/(alpha-beta)]
    concentration=np.zeros(len(times))
    for _,d in doses.iterrows():
        age=times-d.TIME; positive=age>0
        duration=d.AMT/d.RATE
        u=np.minimum(np.maximum(age,0),duration)
        post=np.maximum(age-duration,0)
        for rate,weight in zip(rates,weights):
            concentration += positive*d.RATE/v*weight*(-np.expm1(-rate*u))/rate*np.exp(-rate*post)
    return concentration

def nonlinear_predictions(times,doses,cl,v,q,v2,vmax,km):
    starts=doses.TIME.to_numpy();ends=starts+(doses.AMT/doses.RATE).to_numpy()
    boundaries=np.unique(np.r_[0,times,starts,ends])
    boundaries=boundaries[boundaries<=np.max(times)]
    state=np.zeros(2);values={0.:0.}
    for left,right in zip(boundaries[:-1],boundaries[1:]):
        mid=(left+right)/2
        infusion=float(doses.loc[(starts<=mid)&(ends>mid),'RATE'].sum())
        def ode(t,a):
            c=a[0]/v
            return [infusion-cl*c-q*c+q/v2*a[1]-vmax*c/(km+c),q*c-q/v2*a[1]]
        solution=solve_ivp(ode,(left,right),state,method='LSODA',rtol=1e-9,atol=1e-10)
        assert solution.success,solution.message
        state=solution.y[:,-1]
        values[float(right)]=state[0]/v
    return np.array([values[float(t)] for t in times])

def run():
    summaries=[]
    for name in ['M1','M2','M3','refinement-corrected-M2','refinement-corrected-M3']:
        model=name[-2:]
        runs=sorted((ROOT/'a02'/name).glob('start-*/completed.txt'))
        for completed in runs:
            directory=completed.parent
            coefficients=pd.read_csv(directory/'fixed-estimates.csv').set_index('parameter').estimate
            predictions=pd.read_csv(directory/'predictions.csv')
            deltas=[]
            for pid,g in predictions.groupby('ID'):
                doses=raw[raw.ID.eq(pid)&raw.EVID.eq(1)]
                for kind in ['PRED','IPRED']:
                    cl=np.exp(coefficients.tcl+(g['eta.cl'].iloc[0] if kind=='IPRED' else 0))
                    v=np.exp(coefficients.tv+(g['eta.v'].iloc[0] if kind=='IPRED' else 0))
                    kw={} if model=='M1' else dict(q=np.exp(coefficients.tq),v2=np.exp(coefficients.tv2))
                    if model=='M3':
                        c=nonlinear_predictions(g.TIME.to_numpy(),doses,cl,v,**kw,vmax=np.exp(coefficients.tvmax),km=np.exp(coefficients.tkm))
                    else:
                        c=linear_predictions(g.TIME.to_numpy(),doses,cl,v,**kw)
                    independent=np.log(c+1e-12)
                    deltas.extend(np.abs(independent-g[kind].to_numpy()))
            maximum=float(np.max(deltas))
            assert maximum<1e-4,(model,directory.name,maximum)
            summaries.append(dict(model=name,start=int(directory.name.split('-')[1]),
                                  compared_predictions=2*len(predictions),max_abs_log_prediction_error=maximum,
                                  passed_tolerance_1e_4=True))
    result=pd.DataFrame(summaries)
    result.to_csv(ROOT/'a02/independent-prediction-checks.csv',index=False)
    print(result.to_string(index=False))

if __name__=='__main__':run()
