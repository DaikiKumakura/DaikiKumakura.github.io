# Supplemental FOCEi refinement, preserving the original SAEM runs.
args <- commandArgs(trailingOnly=TRUE)
mid <- args[1]
starts <- if(length(args)>1) as.integer(args[-1]) else 1:3
project <- 'writings/nimotuzumab-poppk'
.libPaths(c(normalizePath(file.path(project,'.r-library')),.libPaths()))
library(nlmixr2est);library(rxode2)
source(file.path(project,'models_a02.R'))
models <- list(M1=m1,M2=m2,M3=m3)
for(k in starts) {
  original <- file.path(project,'a02',mid,paste0('start-',k),'fit.rds')
  if(!file.exists(original)) {cat('NOT YET AVAILABLE',mid,k,'\n');next}
  out <- file.path(project,'a02',paste0('refinement-corrected-',mid),paste0('start-',k))
  dir.create(out,recursive=TRUE,showWarnings=FALSE)
  if(file.exists(file.path(out,'completed.txt'))) next
  previous <- readRDS(original)
  fn <- models[[mid]];b <- body(fn);expr <- b[[2]][[2]]
  theta <- fixef(previous);omega <- previous$omega
  for(j in seq_along(expr)[-1]) {
    term <- expr[[j]]
    if(is.call(term) && identical(term[[1]],as.name('<-'))) {
      name <- as.character(term[[2]])
      if(name %in% names(theta)) expr[[j]][[3]] <- theta[[name]]
    } else if(is.call(term) && identical(term[[1]],as.name('~'))) {
      name <- as.character(term[[2]])
      if(name %in% rownames(omega)) expr[[j]][[3]] <- omega[name,name]
    }
  }
  b[[2]][[2]] <- expr;body(fn) <- b
  d <- read.csv(file.path(project,'raw/nimoData.csv'))[,c('ID','TIME','AMT','RATE','DV','EVID','MDV')]
  d[['CMT']] <- 1
  control <- foceiControl(seed=c(1101,2202,3303)[k],outerOpt='bobyqa',maxOuterIterations=1000,
                 maxInnerIterations=300,print=50,covMethod='r,s',adjLik=TRUE,
                 rxControl=rxControl(atol=1e-9,rtol=1e-6,cores=1))
  saveRDS(list(model=fn,control=control,input=d,source=original),file.path(out,'specification.rds'))
  warnings <- character();started <- Sys.time()
  fit <- tryCatch(withCallingHandlers(nlmixr2(fn,d,est='focei',control=control),
                   warning=function(w)warnings<<-c(warnings,conditionMessage(w))),error=function(e)e)
  writeLines(warnings,file.path(out,'warnings.txt'))
  if(inherits(fit,'error')) {writeLines(conditionMessage(fit),file.path(out,'error.txt'));next}
  saveRDS(fit,file.path(out,'fit.rds'))
  write.csv(fit$parFixedDf,file.path(out,'parameter-summary.csv'))
  write.csv(fit$cov,file.path(out,'covariance.csv'))
  if(!is.null(fit$cov)) write.csv(cov2cor(fit$cov),file.path(out,'parameter-correlation.csv'))
  write.csv(fit$objDf,file.path(out,'objectives.csv'))
  write.csv(fit$omega,file.path(out,'omega.csv'))
  write.csv(data.frame(parameter=names(fixef(fit)),estimate=unname(fixef(fit))),file.path(out,'fixed-estimates.csv'),row.names=FALSE)
  write.csv(as.data.frame(fit),file.path(out,'predictions.csv'),row.names=FALSE)
  write.csv(fit$parHistData,file.path(out,'iterations.csv'),row.names=FALSE)
  capture.output(print(fit),file=file.path(out,'fit-summary.txt'))
  capture.output(str(fit$runInfo),file=file.path(out,'run-info.txt'))
  capture.output(sessionInfo(),file=file.path(out,'sessionInfo.txt'))
  elapsed <- as.numeric(difftime(Sys.time(),started,units='secs'))
  write.csv(data.frame(model=mid,start=k,method='focei',seconds=elapsed),file.path(out,'status.csv'),row.names=FALSE)
  # Evaluate the source SAEM solution with the same Laplace approximation.
  tryCatch({
    setOfv(previous,'focei')
    write.csv(previous$objDf,file.path(out,'source-saem-objectives-with-focei.csv'))
  },error=function(e)writeLines(conditionMessage(e),file.path(out,'source-evaluation-error.txt')))
  writeLines(format(Sys.time(),tz='Asia/Tokyo',usetz=TRUE),file.path(out,'completed.txt'))
  cat('REFINED',mid,k,'seconds',elapsed,'\n')
}
