"""Independent prediction, dimensional, paired-simulation and count checks."""
from analyze_a03 import *
rows=[]
for m in BASE:
 for name in ['baseline','infusion-0.5h','allometry-fixed']:
  d=OUT/m/name;f,o=params(d);g=pd.read_csv(d/'predictions.csv');maxerr=0.
  for pid,ob in g.groupby('ID'):
   dose=DATA[DATA.ID.eq(pid)&DATA.EVID.eq(1)].copy()
   if name=='infusion-0.5h':dose.RATE=2*dose.AMT
   eta=ob[['eta.cl','eta.v']].iloc[0].to_numpy().copy()[None,:]
   pop=np.zeros((1,2))
   if name=='allometry-fixed':
    w=DATA[DATA.ID.eq(pid)].WGT.iloc[0];adj=np.array([.75*np.log(w/70),np.log(w/70)])
    eta+=adj;pop+=adj
   p=np.log(pred(ob.TIME.to_numpy(),dose,f,pop,m)[0]+1e-12)
   ip=np.log(pred(ob.TIME.to_numpy(),dose,f,eta,m)[0]+1e-12)
   maxerr=max(maxerr,float(np.max(abs(p-ob.PRED))),float(np.max(abs(ip-ob.IPRED))))
  rows.append(dict(model=m,run=name,max_absolute_log_prediction_difference=maxerr))
pd.DataFrame(rows).to_csv(OUT/'independent-prediction-checks.csv',index=False)
assert max(x['max_absolute_log_prediction_difference']for x in rows)<.001,rows
e=pd.read_csv(OUT/'exposure.csv');rr=pd.read_csv(OUT/'paired-ratios.csv')
assert len(e)==168 and len(rr)==168
for m in ['M1','M2']:
 for a in [50,100,200,400]:
  q=rr[(rr.model==m)&(rr.scenario==f'dose-{a}')]
  assert np.max(abs(q[['p10','median','p90']].to_numpy()-a/200))<1e-8
assert len(pd.read_csv(OUT/'loso-patients.csv'))==36
assert len(pd.read_csv(OUT/'loso-observations.csv'))==963
assert len(pd.read_csv(OUT/'vpc.csv'))>0
print(pd.DataFrame(rows).to_string(index=False))
