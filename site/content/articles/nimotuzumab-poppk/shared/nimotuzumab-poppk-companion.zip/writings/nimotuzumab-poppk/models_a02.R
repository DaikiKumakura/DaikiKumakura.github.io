# Shared model definitions: log concentration, diagonal CL/V IIV, central infusion.
m1 <- function() {
  ini({
    tcl <- log(0.01)
    tv <- log(1)
    eta.cl ~ 0.3
    eta.v ~ 0.3
    sigma <- 0.5
  })
  model({
    cl <- exp(tcl+eta.cl)
    v <- exp(tv+eta.v)
    d/dt(central) <- -cl/v*central
    cp <- central/v
    pred <- log(cp+1e-12)
    pred ~ add(sigma)
  })
}
m2 <- function() {
  ini({
    tcl <- log(0.01)
    tv <- log(1)
    tq <- log(0.02)
    tv2 <- log(5)
    eta.cl ~ 0.3
    eta.v ~ 0.3
    sigma <- 0.5
  })
  model({
    cl <- exp(tcl+eta.cl)
    v <- exp(tv+eta.v)
    q <- exp(tq)
    v2 <- exp(tv2)
    d/dt(central) <- -cl/v*central-q/v*central+q/v2*peripheral
    d/dt(peripheral) <- q/v*central-q/v2*peripheral
    cp <- central/v
    pred <- log(cp+1e-12)
    pred ~ add(sigma)
  })
}
m3 <- function() {
  ini({
    tcl <- log(0.005)
    tv <- log(1)
    tq <- log(0.02)
    tv2 <- log(5)
    tvmax <- log(0.2)
    tkm <- log(50)
    eta.cl ~ 0.3
    eta.v ~ 0.3
    sigma <- 0.5
  })
  model({
    cl <- exp(tcl+eta.cl)
    v <- exp(tv+eta.v)
    q <- exp(tq)
    v2 <- exp(tv2)
    vmax <- exp(tvmax)
    km <- exp(tkm)
    cp <- central/v
    d/dt(central) <- -cl*cp-q/v*central+q/v2*peripheral-vmax*cp/(km+cp)
    d/dt(peripheral) <- q/v*central-q/v2*peripheral
    pred <- log(cp+1e-12)
    pred ~ add(sigma)
  })
}
