# Usage from workspace root: Rscript .../run_a02.R M1 [start_index]
args <- commandArgs(trailingOnly=TRUE)
model_id <- if(length(args)) args[1] else 'M1'
starts <- if(length(args)>1) as.integer(args[2]) else 1:3
project <- 'writings/nimotuzumab-poppk'
.libPaths(c(normalizePath(file.path(project,'.r-library')),.libPaths()))
library(nlmixr2est)
library(rxode2)
source(file.path(project,'models_a02.R'))
models <- list(M1=m1,M2=m2,M3=m3)
stopifnot(model_id %in% names(models))
input <- read.csv(file.path(project,'raw/nimoData.csv'))
d <- input[,c('ID','TIME','AMT','RATE','DV','EVID','MDV')]
d[['CMT']] <- 1
stopifnot(nrow(d)==441,sum(d[['EVID']]==0)==321,length(unique(d[['ID']]))==12)
base <- c(tcl=.01,tv=1,tq=.02,tv2=5,tvmax=.2,tkm=50)
if(model_id=='M3') base[['tcl']] <- .005
seeds <- c(1101,2202,3303)
scales <- c(.5,1,2)
root <- file.path(project,'a02',model_id)
dir.create(root,recursive=TRUE,showWarnings=FALSE)
for(k in starts) {
  run_dir <- file.path(root,paste0('start-',k))
  dir.create(run_dir,showWarnings=FALSE)
  if(file.exists(file.path(run_dir,'completed.txt'))) {
    cat('SKIP completed:',model_id,k,'\n');next
  }
  cat('START:',model_id,k,'seed',seeds[k],'scale',scales[k],'\n')
  fn <- models[[model_id]]
  b <- body(fn)
  ini_expr <- b[[2]][[2]]
  for(j in seq_along(ini_expr)[-1]) {
    expr <- ini_expr[[j]]
    if(is.call(expr) && identical(expr[[1]],as.name('<-'))) {
      nm <- as.character(expr[[2]])
      if(nm %in% names(base)) ini_expr[[j]][[3]] <- log(base[[nm]]*scales[k])
    }
  }
  b[[2]][[2]] <- ini_expr
  body(fn) <- b
  control <- saemControl(seed=seeds[k],nBurn=400,nEm=800,nmc=3,nu=c(2,2,2),
        print=200,covMethod='sa',nSaCov=500,calcTables=TRUE,logLik=FALSE,adjObf=FALSE,
        rxControl=rxControl(atol=1e-9,rtol=1e-6,cores=1))
  saveRDS(list(model=fn,control=control,seed=seeds[k],scale=scales[k],input=d),file.path(run_dir,'specification.rds'))
  capture.output(fn,file=file.path(run_dir,'model.txt'))
  warnings <- character()
  started <- Sys.time()
  result <- tryCatch(withCallingHandlers({
    fit <- nlmixr2(fn,d,est='saem',control=control)
    saveRDS(fit,file.path(run_dir,'fit-before-likelihood.rds'))
    for(kind in c('gauss15_6','gauss25_6')) setOfv(fit,kind)
    setOfv(fit,'gauss25_6')
    fit
  },warning=function(w) {warnings <<- c(warnings,conditionMessage(w))}),error=function(e)e)
  writeLines(warnings,file.path(run_dir,'warnings.txt'))
  elapsed <- as.numeric(difftime(Sys.time(),started,units='secs'))
  if(inherits(result,'error')) {
    writeLines(conditionMessage(result),file.path(run_dir,'error.txt'))
    write.csv(data.frame(model=model_id,start=k,seed=seeds[k],status='failed',seconds=elapsed),file.path(run_dir,'status.csv'),row.names=FALSE)
    cat('FAILED',model_id,k,conditionMessage(result),'\n'); next
  }
  fit <- result
  saveRDS(fit,file.path(run_dir,'fit.rds'))
  capture.output(print(fit),file=file.path(run_dir,'fit-summary.txt'))
  write.csv(data.frame(parameter=names(fixef(fit)),estimate=unname(fixef(fit))),file.path(run_dir,'fixed-estimates.csv'),row.names=FALSE)
  write.csv(fit$parFixedDf,file.path(run_dir,'parameter-summary.csv'))
  write.csv(fit$omega,file.path(run_dir,'omega.csv'))
  write.csv(fit$cov,file.path(run_dir,'covariance.csv'))
  write.csv(cov2cor(fit$cov),file.path(run_dir,'parameter-correlation.csv'))
  write.csv(fit$objDf,file.path(run_dir,'objectives.csv'))
  write.csv(fit$parHistData,file.path(run_dir,'iterations.csv'),row.names=FALSE)
  write.csv(as.data.frame(fit),file.path(run_dir,'predictions.csv'),row.names=FALSE)
  capture.output(str(fit$runInfo),file=file.path(run_dir,'run-info.txt'))
  capture.output(sessionInfo(),file=file.path(run_dir,'sessionInfo.txt'))
  write.csv(data.frame(model=model_id,start=k,seed=seeds[k],status='estimated',seconds=elapsed),file.path(run_dir,'status.csv'),row.names=FALSE)
  writeLines(format(Sys.time(),tz='Asia/Tokyo',usetz=TRUE),file.path(run_dir,'completed.txt'))
  cat('COMPLETE',model_id,k,'seconds',elapsed,'\n')
}
