project <- 'writings/nimotuzumab-poppk'
lib <- file.path(project,'.r-library')
dir.create(lib, recursive=TRUE, showWarnings=FALSE)
dir.create(file.path(project,'outputs'),recursive=TRUE,showWarnings=FALSE)
.libPaths(c(normalizePath(lib),.libPaths()))
options(repos=c(CRAN='https://cloud.r-project.org'),timeout=300,Ncpus=2)
install.packages('nlmixr2est',lib=lib,type='binary')
write.csv(as.data.frame(installed.packages(lib.loc=lib))[,c('Package','Version','Built','License')],
          file.path(project,'outputs/a02-r-packages.csv'),row.names=FALSE)
capture.output(sessionInfo(),file=file.path(project,'outputs/a02-install-session.txt'))
library(nlmixr2est)
cat('nlmixr2est load successful\n')
