# A03 additions are written separately; original A02 fits are immutable.
args <- commandArgs(trailingOnly=TRUE); mid <- args[1]
p <- 'writings/nimotuzumab-poppk'; out <- file.path(p,'a03',mid)
dir.create(out,recursive=TRUE,showWarnings=FALSE)
.libPaths(c(normalizePath(file.path(p,'.r-library')),.libPaths()))
library(nlmixr2est);library(rxode2);source(file.path(p,'models_a02.R'))
models <- list(M1=m1,M2=m2,M3=m3)
sourcefit <- if(mid=='M1') file.path(p,'a02/M1/start-3/fit.rds') else file.path(p,paste0('a02/refinement-corrected-',mid),paste0('start-',if(mid=='M2')2 else 3),'fit.rds')
basefit <- readRDS(sourcefit)
raw <- read.csv(file.path(p,'raw/nimoData.csv')); raw$CMT <- 1
ids <- sort(unique(raw$ID)); strata <- split(ids,sapply(ids,function(id)raw$DOS[raw$ID==id][1]))
factory <- function(theta=fixef(basefit),omega=basefit$omega,fixed=NULL,weight=FALSE) {
 fn <- models[[mid]];b<-body(fn);ie<-b[[2]][[2]]
 for(j in seq_along(ie)[-1]) {term<-ie[[j]]
  if(is.call(term)&&identical(term[[1]],as.name('<-'))) {nm<-as.character(term[[2]]);if(nm %in% names(theta))ie[[j]][[3]]<-theta[[nm]];if(nm %in% names(fixed))ie[[j]][[3]]<-call('fix',fixed[[nm]])}
  if(is.call(term)&&identical(term[[1]],as.name('~'))) {nm<-as.character(term[[2]]);if(nm %in% rownames(omega))ie[[j]][[3]]<-omega[nm,nm]}
 }
 b[[2]][[2]]<-ie
 if(weight){me<-b[[3]][[2]];for(j in seq_along(me)[-1]) {e<-me[[j]];if(is.call(e)&&identical(e[[1]],as.name('<-'))){nm<-as.character(e[[2]]);if(length(nm)==1 && nm=='cl')me[[j]][[3]]<-quote(exp(tcl+eta.cl)*(WGT/70)^0.75);if(length(nm)==1 && nm=='v')me[[j]][[3]]<-quote(exp(tv+eta.v)*(WGT/70))}};b[[3]][[2]]<-me}
 body(fn)<-b;fn
}
run <- function(label,d,fixed=NULL,weight=FALSE) {
 path<-file.path(out,label);dir.create(path,recursive=TRUE,showWarnings=FALSE)
 if(file.exists(file.path(path,'status.csv')))return(invisible(NULL))
 warnings<-character();started<-Sys.time()
 ctl<-foceiControl(seed=20261004,outerOpt='bobyqa',maxOuterIterations=1000,maxInnerIterations=300,print=0,covMethod='',adjLik=TRUE,rxControl=rxControl(atol=1e-9,rtol=1e-6,cores=1))
 fn<-factory(fixed=fixed,weight=weight)
 saveRDS(list(model=fn,input=d,control=ctl,source=sourcefit,fixed=fixed),file.path(path,'specification.rds'))
 f<-tryCatch(withCallingHandlers(nlmixr2(fn,d,est='focei',control=ctl),warning=function(w){warnings<<-c(warnings,conditionMessage(w));invokeRestart('muffleWarning')}),error=function(e)e)
 if(inherits(f,'error')) {writeLines(conditionMessage(f),file.path(path,'error.txt'));ok<-FALSE;ri<-conditionMessage(f)} else {
  saveRDS(f,file.path(path,'fit.rds'));theta<-fixef(f);write.csv(data.frame(parameter=names(theta),estimate=unname(theta)),file.path(path,'fixed-estimates.csv'),row.names=FALSE)
  write.csv(f$omega,file.path(path,'omega.csv'));write.csv(as.data.frame(f),file.path(path,'predictions.csv'),row.names=FALSE);write.csv(f$objDf,file.path(path,'objectives.csv'))
  ri<-paste(as.character(f$runInfo),collapse='\n');writeLines(ri,file.path(path,'run-info.txt'));writeLines(ri,file.path(path,'run-info-full.txt'));ok<-all(is.finite(theta))&&all(is.finite(f$omega))
 }
 writeLines(warnings,file.path(path,'warnings.txt'))
 qualified<-ok&&!grepl('not at minimum|maximum.*iteration|failed|convergence',paste(ri,warnings),ignore.case=TRUE)
 write.csv(data.frame(model=mid,run=label,finite=ok,qualified=qualified,seconds=as.numeric(difftime(Sys.time(),started,units='secs'))),file.path(path,'status.csv'),row.names=FALSE)
 cat('DONE',mid,label,'finite',ok,'qualified',qualified,'\n');flush.console()
}
worker <- length(args)>1
if(!worker)run('baseline',raw)
if(!worker)for(id in ids)run(paste0('loso-',id),raw[raw$ID!=id,])
set.seed(20261004); samples<-lapply(1:200,function(i)unlist(lapply(strata,function(s)sample(s,length(s),replace=TRUE))))
write.csv(do.call(rbind,lapply(seq_along(samples),function(i)data.frame(replicate=i,new_id=seq_along(samples[[i]]),source_id=samples[[i]]))),file.path(out,'bootstrap-sampling.csv'),row.names=FALSE)
for(i in if(worker)as.integer(args[2]):as.integer(args[3]) else 1:200) {d<-do.call(rbind,lapply(seq_along(samples[[i]]),function(j){x<-raw[raw$ID==samples[[i]][j],];x$ID<-j;x}));run(sprintf('bootstrap-%03d',i),d)}
if(worker)quit(save='no')
alt<-raw;alt$RATE[alt$EVID==1]<-2*alt$AMT[alt$EVID==1];run('infusion-0.5h',alt)
w<-raw;initial<-sapply(ids,function(id)w$WGT[w$ID==id][1]);w$WGT<-initial[match(w$ID,ids)];run('allometry-fixed',w,weight=TRUE)
if(mid=='M3')for(nm in c('tkm','tvmax'))for(k in -3:3) {v<-fixef(basefit)[[nm]]+k*log(4);run(paste0('profile-',nm,'-',k),raw,fixed=setNames(list(v),nm))}
capture.output(sessionInfo(),file=file.path(out,'sessionInfo.txt'))
writeLines('All planned A03 fits attempted; inspect every status and warning.',file.path(out,'completed.txt'))
