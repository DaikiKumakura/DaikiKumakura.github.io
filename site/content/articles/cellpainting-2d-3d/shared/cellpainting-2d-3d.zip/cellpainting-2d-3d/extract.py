"""Extract two drug profiles from author-published figure-source feature tables."""
from pathlib import Path
import hashlib
import json
import numpy as np
import pandas as pd

HERE=Path(__file__).resolve().parent
PREFIXES=('AreaShape_', 'Correlation_', 'Granularity_', 'Intensity_', 'Neighbors_', 'RadialDistribution_', 'Texture_')


def main():
    folder=HERE/'inputs'
    folder.mkdir(exist_ok=True)
    records=[]
    for fmt, name in [('2D','Fig5b.csv'),('3D','Fig4b.csv')]:
        path=HERE/'sources/source_data'/name
        frame=pd.read_csv(path)
        frame=frame[frame.Metadata_name.isin(['Fluor','Olapa'])].copy()
        features=[c for c in frame if c.startswith(PREFIXES)]
        renamed=[c.replace('_illum','_') for c in features]
        assert len(set(renamed))==len(renamed)
        meta=pd.DataFrame(dict(drug=frame.Metadata_name.map({'Fluor':'5-FU','Olapa':'Olaparib'}), dose_uM=frame.Metadata_cmpd_conc, plate=frame.Metadata_barcode, well=frame.Metadata_Well))
        assert not meta.duplicated(['plate','well']).any()
        np.savez_compressed(folder/(fmt+'.npz'), x=frame[features].to_numpy(dtype=float), features=np.array(renamed))
        meta.to_csv(folder/(fmt+'_wells.csv'),index=False)
        records.append(dict(format=fmt,figure_source=name,source_sha256=hashlib.sha256(path.read_bytes()).hexdigest(),rows=len(frame),features=len(features)))
    for name in ['Fig5d.csv','SupplFig5d.csv','Fig6b.csv','Fig6c.csv','Fig6d.csv']:
        (folder/name).write_bytes((HERE/'sources/source_data'/name).read_bytes())
    public=dict(repository='pharmbio/colopaint3D', revision='5f209bcfbccdef2b5c0c97060b9d82aef085f2cb', retrieved='2026-10-23',selection='Metadata_name is Fluor or Olapa in Fig5b (2D) and Fig4b (3D); exported processing and filtering retained.',feature_prefixes=PREFIXES,figure_sources=records)
    public['files']=[dict(file=f.name,sha256=hashlib.sha256(f.read_bytes()).hexdigest()) for f in sorted(folder.iterdir()) if f.suffix in ['.npz','.csv']]
    (folder/'provenance.json').write_text(json.dumps(public,indent=2)+'\n')
    print(records)


if __name__=='__main__':main()
