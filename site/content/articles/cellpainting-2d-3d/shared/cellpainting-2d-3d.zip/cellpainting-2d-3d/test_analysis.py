import unittest
import numpy as np
import pandas as pd
from analysis import HERE,similarity,grid,DOSES


class AnalysisTests(unittest.TestCase):
    def test_cosine_geometry_and_pearson(self):
        self.assertAlmostEqual(similarity(np.array([1.,0]),np.array([0.,1.])),0)
        self.assertAlmostEqual(similarity(np.array([1.,2,3]),np.array([4.,8,12])),1)
        self.assertAlmostEqual(similarity(np.array([1.,2,3]),np.array([7.,6,5]),'pearson'),-1)

    def test_exported_pair_table(self):
        d=pd.read_csv(HERE/'inputs/Fig5d.csv')
        self.assertEqual(len(d),630)
        self.assertEqual(len({tuple(sorted([a,b])) for a,b in zip(d.Drug1,d.Drug2)}),630)
        np.testing.assert_allclose(d.Similarity_3D-d.Similarity_2D,d.difference,atol=1e-14)

    def test_independent_shared_feature_computation(self):
        a=np.load(HERE/'inputs/2D.npz');b=np.load(HERE/'inputs/3D.npz')
        common=sorted(set(a['features'])&set(b['features']))
        self.assertEqual(len(common),416)
        for fmt,z in [('2D',a),('3D',b)]:
            metadata=pd.read_csv(HERE/'inputs'/(fmt+'_wells.csv'))
            x=z['x'][:,[z['features'].tolist().index(c) for c in common]]
            u=np.percentile(x[((metadata.drug=='5-FU')&(metadata.dose_uM==10)).to_numpy()],50,axis=0)
            v=np.percentile(x[((metadata.drug=='Olaparib')&(metadata.dose_uM==3)).to_numpy()],50,axis=0)
            expected=float(np.sum(u*v)/np.sqrt(np.sum(u*u)*np.sum(v*v)))
            self.assertAlmostEqual(grid(x,metadata)[3,2],expected,places=14)
            self.assertEqual(len(x[((metadata.drug=='5-FU')&(metadata.dose_uM==10)).to_numpy()]),4)


if __name__=='__main__':unittest.main()
