from pathlib import Path
import json
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

HERE=Path(__file__).resolve().parent
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':11,'axes.spines.top':False,'axes.spines.right':False})


def main():
    out=HERE/'figures';out.mkdir(exist_ok=True)
    pairs=pd.read_csv(HERE/'inputs/Fig5d.csv')
    target=pairs[(pairs.Drug1.eq('Fluor')&pairs.Drug2.eq('Olapa'))].iloc[0]
    fig,ax=plt.subplots(figsize=(7.2,5.4),layout='constrained')
    ax.scatter(pairs.Similarity_2D,pairs.Similarity_3D,s=17,alpha=.35,color='#576c81',edgecolors='none')
    ax.plot([-.3,1],[-.3,1],ls='--',lw=1,color='#999999')
    ax.scatter(target.Similarity_2D,target.Similarity_3D,s=95,color='#b34726',zorder=3)
    ax.annotate('5-FU / olaparib\n0.886 -> 0.377',xy=(target.Similarity_2D,target.Similarity_3D),xytext=(.27,-.13),arrowprops={'arrowstyle':'->','color':'#b34726'},color='#91391e')
    ax.set(xlabel='2D: author-reported maximum similarity across passing doses',ylabel='3D: author-reported maximum similarity across passing doses',title='The nearest drug can depend on the assay',xlim=(-.3,1.03),ylim=(-.3,1.03))
    ax.text(.02,.97,'HCT116 | 36 shared drugs | 630 dependent pairs',transform=ax.transAxes,va='top',fontsize=9)
    fig.savefig(out/'drug-neighborhoods.png',dpi=180);plt.close(fig)
    summary=json.loads((HERE/'results/summary.json').read_text())
    dose=pd.read_csv(HERE/'results/dose_comparison.csv')
    row=dose[(dose.feature_mode=='shared')&(dose.aggregation=='median')&(dose.metric=='cosine')&(dose.fu_uM==10)&(dose.ola_uM==3)].iloc[0]
    omit=pd.read_csv(HERE/'results/plate_omission.csv')
    fig,axs=plt.subplots(1,2,figsize=(10,4.4),layout='constrained',gridspec_kw={'width_ratios':[1,1.45]})
    colors=['#326b9c','#b34726']
    for i,fmt in enumerate(['2D','3D']):
        axs[0].scatter(i,row[fmt],s=90,color=colors[i],zorder=4)
        values=omit[omit['format']==fmt].similarity.to_numpy()
        axs[0].scatter(np.repeat(i,len(values))+np.array([-.1,.1]),values,s=48,marker='x',color=colors[i])
        axs[0].text(i+.17,row[fmt],f'{row[fmt]:.3f}',va='center',fontsize=10)
    axs[0].set(xticks=[0,1],xticklabels=['2D','3D'],ylabel='Cosine similarity',ylim=(0,1),xlim=(-.5,1.65),title='Fixed doses, 416 shared features')
    axs[0].text(.02,.03,'Dots: all wells\nCrosses: omit one plate\nNot confidence intervals',transform=axs[0].transAxes,fontsize=9)
    grid=dose[(dose.feature_mode=='shared')&(dose.aggregation=='median')&(dose.metric=='cosine')].pivot(index='fu_uM',columns='ola_uM',values='delta_3D_minus_2D')
    image=axs[1].imshow(grid,cmap='RdBu_r',vmin=-.6,vmax=.6)
    for i in range(4):
        for j in range(4):axs[1].text(j,i,f'{grid.iloc[i,j]:+.2f}',ha='center',va='center',color='white' if abs(grid.iloc[i,j])>.36 else '#222222',fontsize=10)
    axs[1].set(xticks=range(4),yticks=range(4),xticklabels=['0.3','1','3','10'],yticklabels=['0.3','1','3','10'],xlabel='Olaparib (uM)',ylabel='5-FU (uM)',title='Difference depends on dose (3D - 2D)')
    axs[1].add_patch(plt.Rectangle((1.5,2.5),1,1,fill=False,edgecolor='#111111',lw=2))
    fig.colorbar(image,ax=axs[1],label='Difference in cosine similarity',shrink=.8)
    fig.suptitle('Processed HCT116 profiles: 5-FU 10 uM / olaparib 3 uM',fontsize=12)
    fig.savefig(out/'fixed-dose-sensitivity.png',dpi=180);plt.close(fig)


if __name__=='__main__':main()
