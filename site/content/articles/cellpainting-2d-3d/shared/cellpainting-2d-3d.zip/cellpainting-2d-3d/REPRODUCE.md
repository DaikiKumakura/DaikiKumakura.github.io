# Cell Painting: 2D and 3D drug-response profiles

This companion reanalyzes author-exported, already processed feature tables. It does not start from raw images or RNA-seq counts. It neither trains an AI model nor tests clinical efficacy.

## Run offline

Python 3.12 was used. Install `requirements.txt`, then run:

```sh
python analysis.py
python plot.py
python -m unittest test_analysis.py
```

`inputs/` contains the extracted arrays, well metadata, source-data panels and SHA-256 provenance. `results/` contains the numerical outputs. The archive includes deterministic plot code and the article's two figures.

## Inputs and transformations

Source: Ringers C, Holmberg D, et al. *High-content morphological profiling by Cell Painting in 3D spheroids*. Nature Communications 17, 10790 (2026), DOI https://doi.org/10.1038/s41467-026-78596-5 .

The author repository is pinned at https://github.com/pharmbio/colopaint3D/tree/5f209bcfbccdef2b5c0c97060b9d82aef085f2cb . Figure source files Fig5b.csv (2D) and Fig4b.csv (3D) supply processed HCT116 well features. `extract.py` keeps only Fluor/Olapa profiles and seven declared CellProfiler feature prefixes. It strips `_illum` from feature names, not from measured values. It excludes UMAP coordinates, indices, metadata, object IDs, locations and parent IDs. There are 849 features in 2D and 594 in 3D; 416 names are shared. Duplicate well keys and nonfinite values cause an error.

The 2D extraction has 40 wells, including 0.1 uM doses that are not used in the common 4-by-4 dose grid. The 3D extraction has 30 wells. Its 0.3 uM 5-FU group and 10 uM olaparib group have three wells; the other groups have four. At the main comparison (5-FU 10 uM and olaparib 3 uM), each drug has four wells per format. The figure exports inherit author filtering; they do not restore omitted wells. Each format has two plate IDs; omitting a plate leaves two wells per drug at the main doses. Plate omission is descriptive, not a biological confidence interval.

`analysis.py` calculates similarity within each format, without comparing a 2D vector directly to a 3D vector. The main analysis uses component-wise medians, the 416 shared features, cosine similarity and fixed doses from the molecular-validation experiment. Mean aggregation, Pearson correlation and each format's own declared features are sensitivity checks. These are post-publication descriptive choices, not a preregistered experiment. Original normalization and image segmentation are not repeated.

Fig5d.csv supplies the published 36-drug, 630-pair comparisons. Its similarity is the maximum over passing dose pairs, and dose choices can differ between formats. The rank calculation uses only the 35 other drugs in that shared panel. It does not compare all 52 screened drugs. Pair observations are dependent.

Fig6b.csv supplies technical-replicate spheroid measurements from one experiment. Fig6c.csv and Fig6d.csv supply the authors' RNA-seq outputs; no raw-count differential expression is performed. The published RNA design has two biological and two technical replicates. Between-drug differences in significance are not inferred from separate FDRs against control.

The supplementary dose matrix uses different inputs, including a different retained feature set and well filtering. The companion reports its discrepancy, rather than asserting exact reproduction of every supplementary value.

## Refresh and extract

`fetch_data.py` downloads the pinned figure sources, notebooks, and paper to `sources/`. `extract.py` rebuilds the small offline inputs from those figure sources. No source notebook is executed. Fetching is optional; the offline calculation requires no network. Original images/features are archived as S-BIAD2254, RNA-seq as GSE343958.

## Attribution and reuse

Original figure-source data and their transformations are credited above. Article and associated source data: CC BY 4.0, https://creativecommons.org/licenses/by/4.0/ . The article's original code repository is MIT licensed. This companion's new code is MIT licensed (LICENSE). Do not interpret a data transformation as new experimental measurements.
