"""Descriptive reanalysis of processed morphological profiles and figure-source data."""
from pathlib import Path
import hashlib
import json
import numpy as np
import pandas as pd

HERE=Path(__file__).resolve().parent
DOSES=[.3,1.,3.,10.]


def similarity(x,y,metric='cosine'):
    if metric=='pearson':x=x-x.mean();y=y-y.mean()
    den=np.linalg.norm(x)*np.linalg.norm(y)
    if not den:raise ValueError('zero norm')
    return float(x@y/den)


def grid(x,meta,metric='cosine',aggregate='median'):
    agg=np.median if aggregate=='median' else np.mean
    profiles={}
    for drug in ['5-FU','Olaparib']:
        for dose in DOSES:
            subset=x[(meta.drug.eq(drug)&meta.dose_uM.eq(dose)).to_numpy()]
            if not len(subset):raise ValueError('empty condition')
            profiles[drug,dose]=agg(subset,axis=0)
    return np.array([[similarity(profiles['5-FU',a],profiles['Olaparib',b],metric) for b in DOSES] for a in DOSES])


def main():
    inp=HERE/'inputs';out=HERE/'results';out.mkdir(exist_ok=True)
    provenance=json.loads((inp/'provenance.json').read_text())
    for f in provenance['files']:
        assert hashlib.sha256((inp/f['file']).read_bytes()).hexdigest()==f['sha256']
    arrays={}; metas={}; features={}
    for fmt in ['2D','3D']:
        with np.load(inp/(fmt+'.npz')) as z: arrays[fmt]=z['x'];features[fmt]=z['features'].tolist()
        metas[fmt]=pd.read_csv(inp/(fmt+'_wells.csv'))
        assert len(arrays[fmt])==len(metas[fmt]) and np.isfinite(arrays[fmt]).all()
    common=sorted(set(features['2D'])&set(features['3D']))
    records=[];sensitivity=[];main_grids={}
    for feature_mode in ['own','shared']:
        for aggregation in ['median','mean']:
            for metric in ['cosine','pearson']:
                for fmt in ['2D','3D']:
                    x=arrays[fmt]
                    if feature_mode=='shared':x=x[:,[features[fmt].index(c) for c in common]]
                    mat=grid(x,metas[fmt],metric,aggregation)
                    for i,a in enumerate(DOSES):
                        for j,b in enumerate(DOSES):records.append(dict(feature_mode=feature_mode,aggregation=aggregation,metric=metric,format=fmt,fu_uM=a,ola_uM=b,similarity=mat[i,j]))
                    if aggregation=='median' and metric=='cosine':main_grids[feature_mode,fmt]=mat
                    if feature_mode=='shared' and aggregation=='median' and metric=='cosine':
                        for plate in sorted(metas[fmt].plate.unique()):
                            keep=~metas[fmt].plate.eq(plate)
                            m=grid(x[keep.to_numpy()],metas[fmt][keep],metric,aggregation)
                            sensitivity.append(dict(format=fmt,removed_plate=plate,fu_uM=10.,ola_uM=3.,similarity=m[3,2]))
    values=pd.DataFrame(records)
    joined=values.pivot(index=['feature_mode','aggregation','metric','fu_uM','ola_uM'],columns='format',values='similarity').reset_index()
    joined['delta_3D_minus_2D']=joined['3D']-joined['2D']
    pairs=pd.read_csv(inp/'Fig5d.csv')
    assert len(pairs)==630 and len(set(pairs.Drug1)|set(pairs.Drug2))==36
    pair=pairs[(pairs.Drug1.eq('Fluor')&pairs.Drug2.eq('Olapa'))|(pairs.Drug2.eq('Fluor')&pairs.Drug1.eq('Olapa'))].iloc[0]
    neighbors=pairs[pairs.Drug1.eq('Fluor')|pairs.Drug2.eq('Fluor')].copy()
    neighbors['other']=np.where(neighbors.Drug1.eq('Fluor'),neighbors.Drug2,neighbors.Drug1)
    for fmt in ['2D','3D']:neighbors['rank_'+fmt]=neighbors['Similarity_'+fmt].rank(method='min',ascending=False).astype(int)
    damage=pd.read_csv(inp/'Fig6b.csv')
    damage_summary=damage.groupby('Drug').agg(wells=('Drug','size'),median_gammaH2AX=('yH2AX_foci_per_nucleus','median'),median_EdU=('edu_fraction','median')).reset_index()
    gene=pd.read_csv(inp/'Fig6d.csv')
    cdkn=gene[gene.gene.eq('CDKN1A')].iloc[0]
    reference=pd.read_csv(inp/'SupplFig5d.csv')
    own=values[(values.feature_mode=='own')&(values.aggregation=='median')&(values.metric=='cosine')]
    compare=own.merge(reference, left_on=['format','fu_uM','ola_uM'],right_on=['representation','level_0','level_1'],validate='one_to_one')
    ref_error=float(np.max(np.abs(compare.similarity-compare.cosine)))
    assert len(compare)==32
    target=joined[joined.fu_uM.eq(10)&joined.ola_uM.eq(3)]
    summary=dict(scope='HCT116; author-exported processed well profiles; no raw-image or raw-count reanalysis; descriptive analysis, no independent-run confidence interval.',n_wells={k:len(v) for k,v in metas.items()},n_features={k:len(v) for k,v in features.items()},shared_features=len(common),doses_uM=DOSES,grid_reference_max_error=ref_error,
                 pair_from_author_table=dict(similarity_2D=float(pair.Similarity_2D),similarity_3D=float(pair.Similarity_3D),delta=float(pair.difference),ola_rank_2D=int(neighbors.loc[neighbors.other.eq('Olapa'),'rank_2D'].iloc[0]),ola_rank_3D=int(neighbors.loc[neighbors.other.eq('Olapa'),'rank_3D'].iloc[0])),
                 fixed_dose=target.to_dict('records'),damage=damage_summary.to_dict('records'),cdkn1a=dict(log2FC_5FU=float(cdkn.lfc_fu),log2FC_ola=float(cdkn.lfc_ola),fdr_5FU=float(cdkn.fdr_fu),fdr_ola=float(cdkn.fdr_ola)))
    summary['supplementary_comparison_note']='Figure-exported features and filtered wells differ from the supplementary notebook inputs; max difference is descriptive, not a reproduction tolerance.'
    summary['fixed_dose_wells']={fmt:metas[fmt][((metas[fmt].drug=='5-FU')&(metas[fmt].dose_uM==10))|((metas[fmt].drug=='Olaparib')&(metas[fmt].dose_uM==3))].groupby('drug').size().to_dict() for fmt in metas}
    for name,frame in [('dose_grid',values),('dose_comparison',joined),('plate_omission',pd.DataFrame(sensitivity)),('neighbors',neighbors[['other','Similarity_2D','Similarity_3D','rank_2D','rank_3D']]),('damage_summary',damage_summary)]:frame.to_csv(out/(name+'.csv'),index=False,float_format='%.10g')
    (out/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
    (out/'shared_features.txt').write_text('\n'.join(common)+'\n')
    print(json.dumps(summary,indent=2))


if __name__=='__main__':main()
