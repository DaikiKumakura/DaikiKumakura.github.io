"""Fetch author-released source data pinned to a Git commit."""
from pathlib import Path
import hashlib
import json
import requests

HERE = Path(__file__).resolve().parent
REVISION = '5f209bcfbccdef2b5c0c97060b9d82aef085f2cb'
BASE = f'https://raw.githubusercontent.com/pharmbio/colopaint3D/{REVISION}/'
FILES = ['README.md','LICENSE','utils/data_manifest.tsv','source_data/MANIFEST.csv',
         'source_data/Fig5b.csv','source_data/Fig5c.csv','source_data/Fig5d.csv','source_data/Fig5f.csv',
         'source_data/Fig6b.csv','source_data/Fig6c.csv','source_data/Fig6d.csv','source_data/Fig6e.csv',
         'source_data/SupplFig5d.csv',
         'analysis/3_Figure5/3_Fig5a_grit_overlap.ipynb',
         'analysis/3_Figure6/3_Fig6e_5fu_neighbours.ipynb',
         'analysis/3_SupplFigure5/3_dose_similarity_5FU_Olaparib.ipynb',
         'analysis/3_Figure4/3_PairwiseCorrelations.ipynb',
         'analysis/3_Figure4/PCAUMAP_pathway_v2.ipynb',
         'source_data/Fig4b.csv','source_data/SupplFig5c.csv']


def main():
    records = []
    for name in FILES:
        r = requests.get(BASE+name, timeout=90)
        r.raise_for_status()
        path = HERE/'sources'/name
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_bytes(r.content)
        records.append(dict(file=name, url=BASE+name, bytes=len(r.content), sha256=hashlib.sha256(r.content).hexdigest()))
    r = requests.get('https://www.nature.com/articles/s41467-026-78596-5.pdf', timeout=90)
    r.raise_for_status()
    (HERE/'sources/paper.pdf').write_bytes(r.content)
    import pymupdf
    doc = pymupdf.open(stream=r.content, filetype='pdf')
    (HERE/'sources/paper.txt').write_text('\n'.join(f'\nPAGE {i+1}\n'+p.get_text() for i,p in enumerate(doc)),encoding='utf-8')
    (HERE/'sources/provenance.json').write_text(json.dumps(dict(revision=REVISION, retrieved='2026-10-23', paper_sha256=hashlib.sha256(r.content).hexdigest(), files=records),indent=2)+'\n')
    print('downloaded',len(records),'files; paper pages',len(doc))


if __name__ == '__main__':
    main()
