# バイオブーム10見出し 出典メモ（2026-10-31改訂）

取得日はすべて2026-10-31。承認状況の基準日は記事と同じ2026-10-30。旧版は `article.before-rules.md`（本文）と `source-notes.before-rules.md`（本メモの旧版。誤って上書きしたため、読んだ内容から全文を復元した）。

元の投稿（約551万ビューと伝えられる）は検索で発見できなかった。10項目は依頼時に伝えられた見出しの要約であり、元の文言は未確認。

## 確認水準の定義

- A 論文抄録：PubMed E-utilities（efetch XML）で逐語取得。全文は未読。
- B 試験登録：ClinicalTrials.gov API v2のJSONを逐語取得。
- C 企業発表の全文：PDFをpdftotextで抽出し、結果の節を読んだ（Merck/Moderna 2026-10-22のみ）。
- D ページ抽出：WebFetchが返す要約（小型モデルによる抽出）。逐語照合なし。FDA・企業・報道のページはすべてこの水準。
- E 検索結果の抜粋のみ：ページ本体が取得不能（Veradermicsの発表。businesswire.comとir.veradermics.comは403）。

## 項目別（最高水準と出典）

| # | 最高水準 | 出典（記事の参照番号は記事末尾の参照欄を正とする） |
| --- | --- | --- |
| 1 daraxonrasib | A（NEJM抄録）+ D（FDA 2ページ、ASCO Post） | NEJM 2026;395(4):325-337, doi 10.1056/NEJMoa2605555（電子版2026-05-31、PubMedのArticleDate）。FDA承認ページ（2026-08-26）。FDA press announcement。ASCO Post 2026-06（G12集団のN=459、1年生存53.3%対18.7%、LBA5） |
| 2 lonvo-z | A（NEJM抄録）+ D（Intellia発表、8-K Ex.99.1） | NEJM 2026;395(15):1471-1482, doi 10.1056/NEJMoa2600931（電子版2026-06-13）。Intellia PR 2026-04-27（BioSpace転載）。8-K 2026-09-08（BLA受理、優先審査、PDUFA 2027-03-10、諮問委員会は予定なし） |
| 3 VERVE-102 | A | NEJM 2026;395(7):648-659, doi 10.1056/NEJMoa2601283（電子版2026-05-25）。最高用量群の例数は抄録になく未確認 |
| 4 intismeran | C（Merck/Moderna 2026-10-22）+ D（CancerNetwork 2026-10-24） | 企業発表PDF（q4cdn）。NEJM掲載受理と記載。PubMed検索（intismeran melanoma INTerpath-001）で論文は見つからず。OS HR 0.77はCancerNetworkのみ |
| 5 retatrutide | D | Lilly医療情報ページ（最終確認2026-08-26）。Lilly PR 2026-07-23（BioSpace転載。TRIUMPH-2 20.8%、BLA 2027年第1四半期予定、未承認）。TRIUMPH-1の発表原文（2026-05-21）は未読。論文は未確認 |
| 6 rentosertib | B + A | NCT07687459（第3相、推定320例、開始2026-09-09、主要評価項目の完了推定2029-10-30、最終更新2026-10-13）。Nat Med 2025;31(8):2602-2610, doi 10.1038/s41591-025-03743-2（第2a相、71例） |
| 7 VDPHL01 | E | Veradermics PR 2026-10-19（businesswire）。検索結果の抜粋のみ。Practical Dermatology、Fierce Pharmaも取得不能（404/403）。試験登録は未確認 |
| 8 dostarlimab | D（FDA）+ B + A | FDA 2026-10-19。NCT05723562（第2相、154例、最終更新2026-05-26）。Ann Oncol 2026-10-25 Epub, doi 10.1016/j.annonc.2026.10.1280。FDA Accelerated Approval Program（2026-08-25時点） |
| 9 ブタ腎臓 | A + D | Lancet 2026;408(10559):1029-1040, doi 10.1016/S0140-6736(26)01295-X（電子版2026-09-03）。eGenesis PR 2026-09-03 |
| 10 DNA移動 | A | Cell 2026;189(15):4548-4561.e14, doi 10.1016/j.cell.2026.04.041。Science 2025;390(6777):1038-1043, doi 10.1126/science.adv9797 |

## 承認状況の再確認（2026-10-31）

- daraxonrasib：FDA承認2026-08-26（再取得で確認）。通常承認か加速承認かはページに記載なし。
- dostarlimab：加速承認2026-10-19（再取得で確認）。
- lonvo-z：BLA受理・優先審査（2026-09-08）。承認の報道は検索で見つからず。
- retatrutide・intismeran・rentosertib・VDPHL01・EGEN-2784：検索で承認の報道なし。検索結果は否定の証明ではない。
- 記事執筆時（2026-10-30）から承認状況に変化は見つかっていない。

## 旧版からの数値・記述の訂正

| 項目 | 旧 | 新 |
| --- | --- | --- |
| 3 | 最高用量群（約7例） | 例数は抄録になく未確認。記載を削除 |
| 9 | 66歳。記録は暫定（別の症例の報道） | 年齢は読んだ一次資料にないため削除。eGenesis自身の発表が別の1例の9か月超を報告。RESTOREは2027年第1四半期、33例 |
| 8 | 一部報道の93%・100%はFDA記載と食い違い | 93%・100%はFDAページ上の別試験（NCT04165772、研究者主導、50例）のcCR12と奏効率。AZUR-1の値ではない。独立判定47%の95%CI「27〜56%」はFDAページの抽出（WebFetch、2回とも同じ表示）で得た値。二項区間（参考計算 54-55/116で37.2〜38.1%、上限56.0〜56.9%）と下限が合わないが、FDAのHTMLをcurlで直接取得できず（404/ボット遮断）原文を確認できないため、記事では区間自体を扱わない（2026-11-01改訂） |
| 8 | 加速承認は確認試験が条件 | FDAの加速承認制度ページに根拠（dostarlimabのページ抽出に確認試験の記述はない） |
| 1 | 第3相の最初の中間解析 | 資料で確認できず削除。FDAのCIを追加（全体OS 13.2か月[10.0〜推定不能]対6.7か月[5.8〜8.0]、HR 0.40[0.30〜0.53]） |
| 2 | 申請中 | BLA受理・優先審査、PDUFA 2027-03-10。87%は相対差−87%（95%CI −93〜−78、最小二乗平均0.26対2.10）。62%は企業発表のみで論文抄録にない |
| 4 | 数値は報道の記載 | 企業発表全文で確認（HR 0.58、2年RFS 82.2%対70.0%）。最初の6か月HR 0.99、6か月以降の感度分析0.42、mITT 0.51を追加。0.55はDMFSのmITT値 |
| 5 | プラセボ値・estimandは未確認 | 医療情報ページで確認。効果推定対象−28.3%（プラセボ−2.2%）、治療レジメン推定対象−25.0%（−3.9%） |
| 6 | 有効性データは第2a相のみ | 同じ。第2aの主要評価項目は安全性で、FVC +98.4 mLは副次評価項目、CIは重なる |

見出しの主要な数値（13.2対6.6/6.7、87%/62%、−62%、HR 0.58、−28.3%、+28.6/+36.4対+6.6、47%/68%、271日）に誤りは見つからなかった。訂正は、裏付けのない付随情報の削除と補足である。

## 筆者計算

- 82.2−70.0=12.2、88.5−80.2=8.3（記事では未使用）、−28.3−(−2.2)の絶対差26.1、−25.0−(−3.9)の絶対差21.1、28.6−6.6=22.0、36.4−6.6=29.8、1−0.58=0.42。
- Clopper–Pearson区間（参考計算のみ。記事では不使用）：54/116=37.2〜56.0%、55/116=38.1〜56.9%、98/144=59.8〜75.6%（scipy）。

## 未確認として残る点

- 元の投稿。見出しの正確な文言。
- 論文全文（NEJM、Lancet、Cell、Science、Nat Med、Ann Oncol）。
- 発作なし62%の定義の詳細、1年生存53.3%対18.7%、OS HR 0.77の原典。
- VERVE-102最高用量群の例数。
- VDPHL01のStudy 304の数値の原文と試験登録。
- INTerpath-001の論文掲載。見出しの発毛薬の同定。
- FDAのdostarlimabページの95%CI「27〜56%」が原文の記載か抽出の誤りか（curl直接取得は不可。記事から区間を削除）。

## 数値台帳（記事本文の数値すべて。2026-11-01改訂）

水準：A=論文抄録（PubMed XMLを逐語取得）、B=試験登録（ClinicalTrials.gov API JSONを逐語取得）、C=企業発表PDF（pdftotextで逐語抽出）、D=ページ抽出（WebFetchの要約モデル経由。逐語未照合）、E=検索結果の抜粋のみ、F=筆者計算。読んだ日はすべて2026-10-31（CancerNetwork・ASCO Postの発行日の確認は2026-11-01）。出典は記事の参照欄のURL/DOIと同じ。

### 1 daraxonrasib
| 数値 | 意味 | 出典 | 水準 |
| --- | --- | --- | --- |
| 500、248、252 | 無作為化例数、daraxonrasib群、化学療法群 | NEJM 10.1056/NEJMoa2605555 抄録 | A |
| 91.8% | RAS G12変異の割合 | 同上 | A |
| 13.2 vs 6.6か月 | G12集団の全生存期間中央値 | 同上 | A |
| 13.2 vs 6.7か月、HR 0.40 | 全体集団、HR（両集団とも0.40） | 同上 | A |
| 10.0〜推定不能、5.8〜8.0、HR CI 0.30〜0.53 | 全体集団のOSの95%CI | FDA drugsページ（2026-08-26） | D |
| 2026-08-26 | 承認日、対象（少なくとも1回の全身療法、または多剤療法の対象外） | FDA drugsページ、FDA press announcement | D |
| 53.3% vs 18.7% | G12集団の1年生存率 | ASCO Post 2026-06-10（報道、抄録に無い） | D |

### 2 lonvo-z
| 数値 | 意味 | 出典 | 水準 |
| --- | --- | --- | --- |
| 80、52、28、50 mg、16歳以上 | 例数、割付、用量、年齢 | NEJM 10.1056/NEJMoa2600931 抄録 | A |
| 7.5か月（4.9〜12.8） | 追跡期間中央値（範囲） | 同上 | A |
| 週5〜28 | 評価期間 | 同上 | A |
| 0.26（0.15〜0.45）vs 2.10（1.55〜2.86） | 月あたり発作率の最小二乗平均（95%CI） | 同上 | A |
| −87%（−93〜−78） | 相対差（95%CI） | 同上 | A |
| 62% vs 11%（6か月） | 発作なしかつ長期予防療法なし | Intellia PR 2026-04-27（BioSpace転載）。抄録に無い | D |
| 2026-09-08、2027-03-10 | BLA受理・優先審査、PDUFA目標日、諮問委員会予定なし | SEC 8-K Ex.99.1 | D |

### 3 VERVE-102
| 数値 | 意味 | 出典 | 水準 |
| --- | --- | --- | --- |
| 35、6用量、0.3〜1.0 mg/kg | 解析例数、用量 | NEJM 10.1056/NEJMoa2601283 抄録 | A |
| 9%、62%、78 mg/dL | LDL-C平均低下（0.3、1.0 mg/kg）、絶対低下 | 同上 | A |
| 51%〜88% | PCSK9低下 | 同上 | A |
| 15例、1年以上 | 追跡1年以上の参加者 | 同上 | A |

### 4 intismeran（INTerpath-001）
| 数値 | 意味 | 出典 | 水準 |
| --- | --- | --- | --- |
| 1,137、2:1 | 例数、割付 | Merck/Moderna PDF 2026-10-22 | C |
| 24.6か月 | 追跡期間中央値 | 同上 | C |
| HR 0.58（0.45〜0.75）、42% | RFS（ITT）、企業の表現 | 同上 | C |
| 82.2%（79.3〜84.8）vs 70.0%（65.0〜74.5） | 2年RFS | 同上 | C |
| 12.2ポイント | 2年RFSの差 | 筆者計算 | F |
| 88.5% vs 80.2%、HR 0.62（0.45〜0.85） | 2年DMFS、DMFSのHR | 同上 | C |
| HR 0.99（0.66〜1.49）、0.42（0.30〜0.58）、0.51（0.39〜0.67） | 最初の6か月、6か月以降（感度分析）、投与を受けた例の解析 | 同上 | C |
| OS HR 0.77（0.45〜1.31） | 全生存期間（未成熟、境界未達） | CancerNetwork 2026-10-24 | D |
| NEJM掲載受理 | 企業の記載。PubMed検索で論文は見つからず | 同PDF、PubMed検索（2026-10-31） | C |

### 5 retatrutide
| 数値 | 意味 | 出典 | 水準 |
| --- | --- | --- | --- |
| 2,339、80週 | 例数、期間 | Lilly医療情報ページ（最終確認2026-08-26） | D |
| −28.3%/−25.0%（12 mg）、−25.9%/−23.7%（9 mg）、−19.0%/−17.6%（4 mg）、プラセボ−2.2%/−3.9% | 効果推定対象／治療レジメン推定対象 | 同上 | D |
| 26.1、21.1ポイント | プラセボとの差 | 筆者計算 | F |
| 20.8% | TRIUMPH-2（2型糖尿病）12 mg 80週の最大値 | Lilly PR 2026-07-23（BioSpace転載） | D |
| 2027年第1四半期 | BLA提出予定、未承認 | 同上 | D |

### 6 rentosertib
| 数値 | 意味 | 出典 | 水準 |
| --- | --- | --- | --- |
| 320、52週、2026-09-09、2029-10-30、FVC年間低下率 | 予定例数、投与期間、開始、主要評価項目の完了予定、主要評価項目 | NCT07687459（更新2026-10-13） | B |
| 71、12週、30 mg QD/BID、60 mg QD | 第2a相の例数、期間、群 | Nat Med 10.1038/s41591-025-03743-2 抄録 | A |
| +98.4 mL（10.9〜185.9）vs −20.3 mL（−116.1〜75.6） | 60 mg QD群とプラセボのFVC変化（副次評価項目） | 同上 | A |

### 7 VDPHL01（未照合）
| 数値 | 意味 | 出典 | 水準 |
| --- | --- | --- | --- |
| 536、8.5 mg QD/BID、+28.6/+36.4 vs +6.6本/cm²、6か月 | Study 304の例数、用量、非軟毛数の増加 | Veradermics PR 2026-10-19（businesswire。ページは403） | E |
| 22.0、29.8 | プラセボとの差 | 筆者計算 | F |

### 8 dostarlimab
| 数値 | 意味 | 出典 | 水準 |
| --- | --- | --- | --- |
| 2026-10-19、加速承認、II/III期MSI-H/dMMR | 承認日、種類、対象 | FDAページ | D |
| 154 | 治療を受けた例数 | FDAページ、NCT05723562 | D、B |
| 47%（116例）、68%（144例） | cCR12（独立中央判定、試験医師判定） | FDAページ。68%（144例）はAnn Oncol抄録でも確認 | D、A |
| 38例（33%） | ICRでcCRだが追跡12か月未満 | FDAページ | D |
| 26.3か月 | 追跡期間中央値 | FDAページ、Ann Oncol抄録 | D、A |
| 93%、100%、50例 | 別試験（NCT04165772）のcCR12と奏効率 | FDAページ | D |
| 第2相 | 登録上の区分 | NCT05723562 | B |
| 加速承認では確認試験が必要 | 制度の記述 | FDA Accelerated Approval Program（2026-08-25時点） | D |

### 9 ブタ腎臓
| 数値 | 意味 | 出典 | 水準 |
| --- | --- | --- | --- |
| 3例計画の最初の1例、2025-01-25、271日、14日目の拒絶、82日、231日 | 症例の経過 | Lancet 10.1016/S0140-6736(26)01295-X 抄録 | A |
| 糖鎖抗原の欠失、内在性レトロウイルス不活化、ヒト導入遺伝子7個 | EGEN-2784の改変 | 同上 | A |
| 5例、9か月超、33例、50〜70歳、2027年第1四半期 | eGenesisの拡大アクセス例数、別症例、RESTORE | eGenesis PR 2026-09-03 | D |

### 10 DNA移動
Cell 10.1016/j.cell.2026.04.041、Science 10.1126/science.adv9797。数値は書誌（巻・頁・年）のみで、いずれも抄録（A）。

### 構成上の数
- 10項目、うち薬・ワクチン・治療法8項目、承認済み2項目：筆者の分類（記事内に定義）。
- 参照23件：記事内の初出順。


## Primary-source update (2026-11-02)

The earlier snippet-only assessment above is superseded for VDPHL01 Study 304. The complete official announcement and SEC Form 8-K were read. The announcement reports 536 randomized participants, 8.5 mg once or twice daily, and month-6 mean non-vellus target-area hair-count changes of 28.6, 36.4 and 6.6 hairs/cm². Placebo-adjusted differences are 22.0 and 29.8 hairs/cm² (independent subtraction). These are sponsor-reported results, not a peer-reviewed efficacy publication.

SEC: https://www.sec.gov/Archives/edgar/data/1827635/000182763526000036/mane-20261019.htm

The NCT06972264 registry version last updated 2026-02-12 gives an estimated enrollment of 480 and has no posted results. It is an earlier planned count, not evidence contradicting the later reported actual 536. The original social-media headline's drug remains unidentified. Historical source-access notes are retained above rather than silently rewritten. The revised article has 24 references.
