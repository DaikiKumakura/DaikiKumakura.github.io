# バイオブーム10主張 ファクトチェック調査メモ

調査日（アクセス日）: 2026-10-30 / 方法: Web検索＋ページ取得（要約モデル経由）。一次資料の全文PDF・NEJM/Lancet本文は直接確認できていないものが多い。そのため「二次報道経由」「未確認」を明記。
元ポスト（約551万ビュー）: 検索では発見できず → **未確認**。10項目はタスク記載のまま扱った。

## 一覧表

| # | 主張 | 一次/準一次ソース | 数値・条件（出典記載） | 主張との一致 | 承認状況（2026-10-30時点） |
|---|---|---|---|---|---|
| 1 | daraxonrasib OS 13.2 vs 6.6か月（膵癌2L） | Revolution Medicines 2026-04-13 トップライン（BioSpace転載）; ASCO Post 2026-06 | ITT: 13.2 vs 6.7か月, HR 0.40。RAS G12変異集団(主要): 13.2 vs 6.6か月, HR 0.40, 1年生存 53.3% vs 18.7%（ASCO Post）。対照=医師選択の化学療法。治療歴ありの転移性PDAC、約500例 | 概ね一致。6.6はG12集団、ITTは6.7。第1中間解析で最終扱い、OS CIの上限は推定不能 | FDAが2026-08-26に承認（FDAの発表を確認済み） |
| 2 | HAE遺伝子編集 87%/62% | Intellia 2026-04-27 PR（BioSpace転載）; EAACI 2026・NEJM同時掲載（二次報道） | lonvo-z (NTLA-2002) HAELO第3相, 80例(52 vs 28)、16歳以上I/II型HAE、1回50mg。週5-28で月間発作 0.26 vs 2.10 → **87%は発作減少率**。**62%は発作なし＋HAE治療なし**の割合（プラセボ11%） | 「87%がattack-free」と読める書き方は**誤り**。87%=発作減少、attack-freeは62% | 未承認。rolling BLA提出中、2027上半期発売見込み(承認なら) |
| 3 | 遺伝子編集でLDL −62% | NEJM（VERVE-102, Heart-2第1相; DOI 10.1056/NEJMoa2601283）二次報道 | PCSK9塩基編集。用量依存で−9%〜−62%（1.0 mg/kg群で−62%, 絶対−78 mg/dL）。35例、HeFH/早発CAD、追跡中央値約9か月、1年以上は15例。1.0 mg/kg群は約7例(Carenet) | 数値は最高用量群の平均で、「遺伝子編集でLDL−62%」は一般化しすぎ。第1相・少数 | 未承認（第1相） |
| 4 | INTerpath-001 1,137例で42%減 | Merck/Moderna PR 2026-08-19, 2026-10-22; ESMO 2026 LBA1 (Long G et al., 2026-10-24)（Healio/CancerNetwork経由） | 完全切除IIB-IV期皮膚黒色腫、2:1（757 vs 380）。RFS HR 0.58 (0.45-0.75) → **42%はリスク減**、24か月RFS 82.2% vs 70%。DMFS HR 0.62。中央値追跡24.6か月。OS HR 0.77 (0.45-1.31) 未成熟・非有意。対照=pembrolizumab+プラセボ。G3以上AE 14.2% vs 13.4% | 一致（42%=再発または死亡のHR由来の相対リスク減）。ただし絶対差は約12ポイント、OSは未確認的 | 未承認（investigational）。査読論文は**未確認** |
| 5 | retatrutide 約28% | Lilly PR 2026-05（TRIUMPH-1）; ADA 2026 | 非糖尿病の肥満/過体重, 2,339例, 80週: 12mg −28.3%, 9mg −25.9%, 4mg −19.0%。延長104週(BMI≥35,532例): −30.3%。TRIUMPH-2(T2D) 最大−20.8%, TRIUMPH-3 最大−22.6% | 12mg・80週・非糖尿病では一致。プラセボ値・estimand（効果推定/治療方針）は**未確認** | 未承認。BLA 2027年Q1予定 |
| 6 | rentosertib 第3相 | Insilico PR 2026-07-07; ClinicalTrials.gov NCT07687459 | GENESIS-IPF-3, 特発性肺線維症, 無作為二重盲検プラセボ対照, 約320例, 52週。CT.gov開始日 2026-09-09、一次完了見込み 2029-10。第2a相(71例)で12週60mg FVC +98.4 mL vs −20.3 mL | 「第3相」は一致（開始した段階であり結果ではない）。有効性データは第2aのみ | 未承認。第3相は結果なし |
| 7 | 発毛薬 第3相 | Veradermics 2026-10-19 Study 304（Fierce Pharma/Practical Dermatology経由）; 302試験PR 2026-04-27 | **候補同定: VDPHL01（徐放経口ミノキシジル）**。男性型脱毛。Study 304 (第3相) 536例, 8.5mg 1日1回/2回/プラセボ, 6か月の非軟毛本数増加 +28.6 / +36.4 vs +6.6 /cm²。302は第2/3相519例 | 元ポストの対象薬が本当にこれかは**未確認**（clascoterone等の可能性も排除できず） | 未承認 |
| 8 | dostarlimab 直腸癌 FDA承認 | FDA 2026-10-19 加速承認ページ | Jemperli, MSI-H/dMMR のII/III期局所進行直腸癌、成人。AZUR-1単群、154例, cCR12 47%（95%CI は出典の記載に誤記の疑いがあり本記事では使わない, 独立判定評価可能116例）。一部報道の「93%/100%」はFDA記載と食い違い→採用せず | 承認は事実。ただし**加速承認**・単群・中間結果・MSI-H/dMMRのみ | **承認済み（加速承認）**。確認試験での検証が条件 |
| 9 | ブタ腎臓 271日 | Lancet症例報告 2026-09-03頃; Mass General Brigham（二次報道） | Tim Andrews, 66歳, 2025-01-25移植, 69遺伝子改変(eGenesis EGEN-2784)、271日で機能廃絶(TMA)、透析82日後にヒト腎移植。拡大アクセスでの1例。**「透析なし最長」と報じられるが、別症例が285日との未確認報道あり** | 数値は一致。n=1の症例で「記録」は暫定 | 未承認。FDA許可のRESTORE試験は2027Q1開始予定 |
| 10 | 染色体サイズDNAの細胞間移動 | (a) Cell 2026 Maurais...Ly (UT Southwestern); (b) Science 2025-12-04 Petris...Chin (DOI 10.1126/science.adv9797) | (a) 核外に出た大きなゲノムDNA片（Y染色体断片等）がナノチューブ経由で隣接ヒト細胞へ。培養細胞系の観察。(b) ヒト染色体をマウスES細胞へ移し、また戻す工学的手法 | 元ポストがどちらを指すか**未確認**。「染色体サイズ」の厳密さは(a)でも要確認 | 基礎研究（in vitro）。承認の概念なし |

## 注記
- **事実と解釈**: 上表の数値は取得ページの記載。一部の差（例：82.2% − 70%）は筆者が引き算した。出所URLを下に付す。
- **最大の誤り候補**: #2（87%=発作減少、attack-free=62%）。#1は6.6/6.7のITT/G12混在。#4は42%が相対リスク減であることの説明が要る。
- **承認済みは#1（2026-08-26）と#8（加速承認、2026-10-19）の2つ**。他は investigational または対象外。#2は2027年承認見込み、#5はBLA前。
- 要約ツール経由の取得のため、CI・分母・estimandなどは原文での再確認を推奨。ClinicalTrials.govの個別NCT（RASolute 302、HAELO、INTerpath-001: 未確認）は未検証。
- 複数ソース間の不一致: INTerpath-001で49%/HR0.51（medpath）という記述は第2b相KEYNOTE-942の値と見られ、第3相の42%とは別。dostarlimabのORR 79% vs 100%も不一致→FDA/ASCO Post側を採用。

## URL（アクセス日 2026-10-30）
1. https://www.biospace.com/press-releases/daraxonrasib-demonstrates-unprecedented-overall-survival-benefit-in-pivotal-phase-3-rasolute-302-clinical-trial-in-patients-with-metastatic-pancreatic-cancer
   https://ascopost.com/news/june-2026/daraxonrasib-nearly-doubles-survival-in-previously-treated-metastatic-pancreatic-cancer/
2. https://www.biospace.com/press-releases/intellia-therapeutics-reports-positive-phase-3-results-in-hereditary-angioedema-marking-a-global-first-for-in-vivo-gene-editing
3. https://medicaldialogues.in/amp/cardiology-ctvs/news/verve-102-gene-editing-therapy-shows-promise-in-ldl-reduction-nejm-171735 （NEJM DOI経由は未確認）
4. https://www.healio.com/news/hematology-oncology/20261023/personalized-mrna-vaccine-reduced-melanoma-recurrence-risk-42-after-surgery
   https://www.cancernetwork.com/view/novel-cancer-vaccine-meets-primary-secondary-end-points-in-resected-melanoma
5. https://www.ajmc.com/view/retatrutide-achieves-up-to-30-3-average-weight-loss-in-phase-3-triumph-1-trial
6. https://clinicaltrials.gov/study/NCT07687459 ; https://insilico.com/news/xmjsn4l091
7. https://www.fiercepharma.com/pharma/veradermics-hot-streak-continue-another-phase-3-win-against-hair-loss
8. https://www.fda.gov/drugs/resources-information-approved-drugs/fda-grants-accelerated-approval-dostarlimab-locally-advanced-rectal-cancer ; https://ascopost.com/news/october-2026/fda-approves-dostarlimab-for-msi-hdmmr-locally-advanced-rectal-cancer/
9. https://www.nbcnewyork.com/news/national-international/pig-kidney-record-271-days-human-body/6544124/ ; https://egenesisbio.com/news-media/press-releases/egenesis-announces-clinical-update-in-ongoing-expanded-access-study-of-egen-2784-in-patients-with-kidney-failure
10. https://phys.org/news/2026-05-human-cells-exchange-genomic-dna.html ; https://pubmed.ncbi.nlm.nih.gov/41343641/

## 追記（2026-10-30）
- daraxonrasibの承認（FDA、2026-08-26、Rasonque）：https://www.fda.gov/news-events/press-announcements/fda-approves-first-class-targeted-therapy-metastatic-pancreatic-cancer （検索結果で確認。全体で13.2 vs 6.7か月）
- 公開日までに承認状況が変わりうるため、公開前に再確認する。
- dostarlimab（FDA、取得日2026-10-30）：cCR12は、独立の中央判定で47%（116例評価、FDA記載の95%CI 27〜56%）、試験医師の判定で68%（144例、60〜76%）。報道の食い違いは、判定主体の違いによる。
