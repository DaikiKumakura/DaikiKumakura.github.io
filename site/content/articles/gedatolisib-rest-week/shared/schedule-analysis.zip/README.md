# Gedatolisib: redistribute a 540 mg four-week amount

Research and learning only, not clinical dose/treatment instructions.
Existing Python environment matching requirements.txt:
  python analysis/run_analysis.py
  python -m unittest discover -s analysis -p "test_model.py" -q
No network, account, original FDA PDF or patient data required.

Source FDA NDA219908 multidiscipline review Table66 PDF236/printed235:
https://www.accessdata.fda.gov/drugsatfda_docs/nda/2026/219908Orig1s000MultidisciplineR.pdf
Four compartments, not one: CL7.99,V1 7.31,Q2 4.77,V2 8.21,Q3 3.46,V3 98.1,
Q4 .741,V4 279. L,h,mg; plasma ng/mL. Original model4238PK/605people pooled.
Source reused, not new IPD parameter estimation. Fixed-effect CI endpoints
one-at-time sensitivity are not joint bounds. WT70kg AST32 reference,CL powers
WT.246/AST-.124. Eta variances CL.0507,V1.195,Q4.204; independent assumed,
CL-Q4 corr+/-0.5 sensitivity. Other IIV0assumed, residualerror notadded to latentPK.
Seed20261023,n2048paired conditionalvirtualindividuals; not sourcepopulation
reconstruction. FDA PDF228 warns model may overpredict observed dispersion.

All30mininfusions.180mgD1/8/15 vs135mgD1/8/15/22,540mg/28days.180x4has720mg,
not equalamount. Periodiccycle is infinite repeat limit; zero-initial firstcycle
and56daystartup separate. Sameperiodic AUC is linearbalance, not efficacy
preservation. Firstcycle AUC not identical. Week4 is hours504-672; absolute
exposurefraction emphasized alongside ratios with a small reference denominator.
Cmin is true cycleminimum, not arbitrarypostdose or predose convention.

CentralV1 not label393L; sumV=392.62. Typicalsourcedmodel singleCmax14791 vs
labelmean13700; not independentqualification. FDA PDF40 identifies label
AUC21400 as steady0-168h; whichweeklyoccasion notspecified. Model firstthree
periodicweekAUC21870-22277. AUCinf22528 not sameendpoint. Slowestmatrixmode
half286h not label36h; no newlyvalidatedtail,washout,PDrecovery or effectthreshold.
No efficacy/safety/optimalregimen inference, no copartnerPKorDDImodel.

9 implementationtests against independent event/matrix exponentials, integrated
AUC, startup, densegrid extrema,weeklyrepresentation and correlateddraws.
Implementationverification is not clinicalqualification of a newregimen.
7aggregateCSV,3originalfigures,results/environment/sourcehash snapshots.
OriginalFDA PDF/images notredistributed; hash is consultedsnapshotprovenance.
CodeMIT, source facts attributed above. Independent FDA publicmodel acceptance
for its original purpose does not validate the newhypothetical regimen.
