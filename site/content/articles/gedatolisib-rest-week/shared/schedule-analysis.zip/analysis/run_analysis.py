"""Reuse published same-drug PopPK; conditional paired regimen calculations."""
from pathlib import Path
import json,platform,hashlib
import numpy as np
import pandas as pd
import scipy
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from model import rates_weights,periodic,initial,metrics,sample_parameters

R=Path(__file__).resolve().parents[1]
def main():
    cfg=json.loads((R/'analysis/inputs.json').read_text());p=cfg['parameters'];out=R/'outputs';tab=out/'tables';fig=out/'figures';tab.mkdir(parents=True,exist_ok=True);fig.mkdir(exist_ok=True)
    plt.rcParams.update({'font.size':10,'axes.spines.top':False,'axes.spines.right':False,'savefig.dpi':160})
    regs=cfg['regimens'];typ={name:metrics(p,v['dose_mg'],v['times_h']) for name,v in regs.items()}
    pd.DataFrame([dict(regimen=n,total_mg=v['dose_mg']*len(v['times_h']),**typ[n]) for n,v in regs.items()]).to_csv(tab/'typical-regimens.csv',index=False)
    pd.DataFrame([dict(parameter=k,estimate=v,low=cfg['ci'][k][0],high=cfg['ci'][k][1]) for k,v in p.items()]).to_csv(tab/'source-parameters.csv',index=False)
    k,w=rates_weights(p);single_peak=float(initial(np.array([.5]),p,180,[0],cycle=1e8)[0]);naive_peak=1000*180/.5/p['cl']*(-np.expm1(-p['cl']/393*.5))
    bench=dict(single_cmax=single_peak,label_mean_cmax=13700,cmax_ratio=single_peak/13700,auc_infinity=180000/p['cl'],label_mean_auc=21400,label_auc_interval_h=[0,168],total_volume=sum(p[x] for x in ['v1','v2','v3','v4']),eigen_half_lives_h=(np.log(2)/k).tolist(),label_half_h=36,naive_one_comp_peak=naive_peak,reference_week_auc=[__import__('model').integral(a,a+168,p,180,[0,168,336]) for a in [0,168,336]])
    pd.DataFrame([dict(endpoint='Single-dose Cmax',model=single_peak,label=13700),dict(endpoint='Periodic reference week1 AUC0-168 (source week unspecified)',model=bench['reference_week_auc'][0],label=21400),dict(endpoint='Single-dose AUCinf (no matched label endpoint)',model=180000/p['cl'],label=np.nan),dict(endpoint='Vsum',model=bench['total_volume'],label=393),dict(endpoint='Slowest eigen half-life',model=max(bench['eigen_half_lives_h']),label=36)]).to_csv(tab/'benchmark.csv',index=False)
    rows=[]
    for corr in [0.,-.5,.5]:
        pp=sample_parameters(cfg,corr=corr)
        for i,pi in enumerate(pp):
            ref=metrics(pi,180,[0,168,336]);alt=metrics(pi,135,[0,168,336,504])
            for key in ['cmax','cmin','c_end','auc28','auc_week4','first_auc28']:
                rows.append(dict(corr_cl_q4=corr,id=i,metric=key,reference=ref[key],redistributed=alt[key],ratio=alt[key]/ref[key]))
    a=pd.DataFrame(rows);summ=[]
    for (corr,key),g in a.groupby(['corr_cl_q4','metric'],sort=False):
        q=g.ratio.quantile([.05,.5,.95]).to_numpy();summ.append(dict(corr_cl_q4=corr,metric=key,p05=q[0],median=q[1],p95=q[2]))
    ss=pd.DataFrame(summ);ss.to_csv(tab/'paired-summary.csv',index=False)
    sens=[]
    for name,interval in cfg['ci'].items():
        for bound,value in zip(['low','high'],interval):
            pi={**p,name:value};ref=metrics(pi,180,[0,168,336]);alt=metrics(pi,135,[0,168,336,504])
            sens.append(dict(parameter=name,bound=bound,**{x:alt[x]/ref[x] for x in ['cmax','c_end','auc28','auc_week4','first_auc28']}))
    pd.DataFrame(sens).to_csv(tab/'fixed-parameter-sensitivity.csv',index=False)
    cov=[]
    for wt,ast in [(70,32),(50,32),(100,32),(70,16),(70,64)]:
        pi={**p,'cl':p['cl']*(wt/70)**.246*(ast/32)**(-.124)}
        ref=metrics(pi,180,[0,168,336]);alt=metrics(pi,135,[0,168,336,504]);cov.append(dict(weight=wt,ast=ast,cl=pi['cl'],**{x:alt[x]/ref[x] for x in ['cmax','c_end','auc28','auc_week4']}))
    pd.DataFrame(cov).to_csv(tab/'covariate-scenarios.csv',index=False)
    t=np.unique(np.r_[np.arange(0,1344.001,1.),[s+c+.5 for c in [0,672] for s in [0,168,336,504]]]);profiles=[]
    for name,v in regs.items():
        profiles.append(pd.DataFrame(dict(regimen=name,time_h=t,initial=initial(t,p,v['dose_mg'],v['times_h']),periodic=periodic(t,p,v['dose_mg'],v['times_h']))))
    pd.concat(profiles).to_csv(tab/'profiles.csv',index=False)
    xs=np.linspace(0,8,801);first=initial(xs,p,180,[0],cycle=1e8)
    one=np.where(xs<=.5,1000*360/p['cl']*(-np.expm1(-p['cl']/393*xs)),naive_peak*np.exp(-p['cl']/393*(xs-.5)))
    f,axs=plt.subplots(1,2,figsize=(10,4),layout='constrained')
    axs[0].plot(xs,first,label='Published four-compartment model');axs[0].plot(xs,one,label='One compartment, V=393L');axs[0].axhline(13700,color='.5',ls=':',label='Label mean Cmax (summary)');axs[0].set(xlabel='Hours after infusion start',ylabel='Plasma concentration (ng/mL)',title='393 L is not the central volume');axs[0].legend(fontsize=7)
    tail=np.linspace(0,672,1345);axs[1].plot(tail/24,initial(tail,p,180,[0],cycle=1e8),color='#0072B2');axs[1].set(yscale='log',xlabel='Days after a single infusion',ylabel='Plasma concentration (ng/mL)',title='Model tail: not a validated washout threshold')
    f.savefig(fig/'model-check.png');plt.close(f)
    f,axs=plt.subplots(1,2,figsize=(11,4),layout='constrained')
    names={'reference':'180 mg x3 / 28d (540 mg)','redistributed':'135 mg x4 / 28d (540 mg)','higher_total':'180 mg x4 / 28d (720 mg)'}
    for name,color,style in [('reference','#0072B2','-'),('redistributed','#D55E00','--'),('higher_total','.5',':')]:
        v=regs[name];a1=t[t<=672];axs[0].plot(a1/24,periodic(a1,p,v['dose_mg'],v['times_h']),color=color,ls=style,label=names[name]);axs[1].plot(t/24,initial(t,p,v['dose_mg'],v['times_h']),color=color,ls=style)
    for ax in axs:ax.set(yscale='log',xlabel='Days',ylabel='Plasma concentration (ng/mL)')
    axs[0].axvspan(21,28,color='#EEE8AA',alpha=.3);axs[0].set_title('Periodic cycle; shaded last week');axs[1].set_title('First two cycles, zero initial amount');axs[0].legend(fontsize=7)
    f.savefig(fig/'regimen-profiles.png');plt.close(f)
    f,axs=plt.subplots(1,3,figsize=(11,3.7),layout='constrained')
    for ax,key,title in zip(axs,['cmax','c_end','auc_week4'],['Cmax','End-of-cycle concentration','Last-week AUC']):
        for j,(co,col) in enumerate([(0.,'#0072B2'),(-.5,'#D55E00'),(.5,'#009E73')]):
            v=ss[(ss.corr_cl_q4==co)&(ss.metric==key)].iloc[0];ax.errorbar(j,v['median'],yerr=[[v['median']-v.p05],[v.p95-v['median']]],fmt='o',color=col,capsize=4)
        ax.axhline(1,color='.5',ls=':');ax.set_xticks([0,1,2],['0','-0.5','+0.5']);ax.set(xlabel='Assumed CL-Q4 correlation',ylabel='135 x4 / 180 x3 paired ratio',title=title,ylim=(0,None))
    f.suptitle('Conditional virtual individuals n=2048; median and 5-95%, not confidence intervals',fontsize=10);f.savefig(fig/'paired-sensitivity.png');plt.close(f)
    result=dict(benchmark=bench,typical=typ,paired=summ,seed=cfg['seed'],n=cfg['n'])
    (out/'results.json').write_text(json.dumps(result,indent=2)+'\n');(out/'environment.json').write_text(json.dumps(dict(python=platform.python_version(),numpy=np.__version__,pandas=pd.__version__,scipy=scipy.__version__,matplotlib=matplotlib.__version__),indent=2)+'\n')
    raw=R/'data/raw/fda-review.pdf'
    if raw.exists():(out/'source-hashes.json').write_text(json.dumps({'fda-review.pdf':hashlib.sha256(raw.read_bytes()).hexdigest()},indent=2)+'\n')
    print('Benchmark',bench);print(pd.DataFrame(typ).T.to_string());print(ss.to_string(index=False))

if __name__=='__main__':main()
