"""Four-compartment linear IV PK; periodic and first-cycle finite-infusion solutions."""
import numpy as np

def rates_weights(p):
    """Symmetric similarity transform of the amount-state matrix."""
    v=np.array([p['v1'],p['v2'],p['v3'],p['v4']])
    q=np.array([p['q2'],p['q3'],p['q4']])
    m=np.zeros((4,4));m[0,0]=-(p['cl']+q.sum())/v[0]
    for j in range(1,4):
        m[j,j]=-q[j-1]/v[j];m[0,j]=m[j,0]=q[j-1]/np.sqrt(v[0]*v[j])
    eig,u=np.linalg.eigh(m);k=-eig;w=u[0,:]**2/v[0]
    assert np.all(k>0) and np.all(w>=0)
    return k,w

def periodic(t,p,dose,starts,cycle=672.,duration=.5):
    k,w=rates_weights(p);t=np.asarray(t,dtype=float);out=np.zeros_like(t)
    for start in starts:
        u=(t-start)%cycle;z=u[...,None];kk=k
        past=np.exp(-kk*(cycle-duration))*(-np.expm1(-kk*duration))/(kk*(-np.expm1(-kk*cycle)))
        current=np.where(z<=duration,-np.expm1(-kk*z)/kk,
                         np.exp(-kk*(z-duration))*(-np.expm1(-kk*duration))/kk)
        out+=1000*dose/duration*np.sum(w*(past*np.exp(-kk*z)+current),axis=-1)
    return out

def primitive(u,k,duration):
    """Integral of one isolated unit-rate infusion response over [0,u]."""
    z=np.asarray(u)[...,None];a=np.minimum(z,duration)
    inside=a/k-(-np.expm1(-k*a))/(k*k)
    tail=(-np.expm1(-k*duration))*(-np.expm1(-k*np.maximum(z-duration,0)))/(k*k)
    return inside+tail

def integral(a,b,p,dose,starts,cycle=672.,duration=.5,periodic_state=True):
    k,w=rates_weights(p)
    if periodic_state:
        past=np.exp(-k*(cycle-duration))*(-np.expm1(-k*duration))/(k*(-np.expm1(-k*cycle)))
        def total(x):
            n=np.floor(x/cycle);u=x%cycle
            return n*duration/k+past*(-np.expm1(-k*u))/k+primitive(u,k,duration)
    else:
        def total(x):return primitive(max(x,0),k,duration)
    return float(1000*dose/duration*sum(np.sum(w*(total(b-s)-total(a-s))) for s in starts))

def initial(t,p,dose,starts,cycle=672.,duration=.5):
    k,w=rates_weights(p);t=np.asarray(t,dtype=float);out=np.zeros_like(t)
    max_cycle=int(max(0,np.max(t))//cycle)
    for c in range(max_cycle+1):
        for s in starts:
            u=t-(s+c*cycle);z=np.maximum(u,0)[...,None]
            current=np.where(z<=duration,-np.expm1(-k*z)/k,
                             np.exp(-k*(z-duration))*(-np.expm1(-k*duration))/k)
            out+=np.where(u>=0,1000*dose/duration*np.sum(w*current,axis=-1),0.)
    return out

def metrics(p,dose,starts,cycle=672.,duration=.5):
    # With positive exponential weights, peaks occur at infusion ends; minima at starts.
    peaks=periodic(np.array(starts)+duration,p,dose,starts,cycle,duration)
    lows=periodic(np.array(starts,dtype=float),p,dose,starts,cycle,duration)
    return dict(cmax=float(peaks.max()),cmin=float(lows.min()),c_end=float(periodic(np.array([cycle]),p,dose,starts,cycle,duration)[0]),
                auc28=integral(0,cycle,p,dose,starts,cycle,duration),
                auc_week4=integral(504,672,p,dose,starts,cycle,duration),
                first_auc28=integral(0,cycle,p,dose,starts,cycle,duration,False))

def sample_parameters(cfg,n=None,corr=0):
    n=n or cfg['n'];rng=np.random.default_rng(cfg['seed']);z=rng.standard_normal((n,3))
    cov=np.eye(3);cov[0,2]=cov[2,0]=corr
    eta=z@np.linalg.cholesky(cov).T*np.sqrt(list(cfg['variances'].values()))
    return [{**cfg['parameters'],**{key:cfg['parameters'][key]*np.exp(e) for key,e in zip(['cl','v1','q4'],row)}} for row in eta]
