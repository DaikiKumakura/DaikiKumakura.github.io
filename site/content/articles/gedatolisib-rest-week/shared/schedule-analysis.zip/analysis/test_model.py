"""Independent event/matrix checks of periodic infusion and exposure integrals."""
from pathlib import Path
import json,unittest
import numpy as np
from scipy.linalg import expm
from model import rates_weights,periodic,initial,integral,metrics,sample_parameters

C=json.loads((Path(__file__).parent/'inputs.json').read_text());P=C['parameters']

def matrix(p):
    v=[p[f'v{i}'] for i in range(1,5)];m=np.zeros((4,4));m[0,0]=-p['cl']/v[0]
    for j in range(1,4):
        q=p[f'q{j+1}'];m[0,0]-=q/v[0];m[0,j]=q/v[j];m[j,0]=q/v[0];m[j,j]=-q/v[j]
    return m

def advance(x,dt,p,rate):
    # Four amounts, integral concentration, and an affine constant.
    a=np.zeros((6,6));a[:4,:4]=matrix(p);a[0,5]=rate;a[4,0]=1000/p['v1']
    z=np.r_[x[:4],0.,1.];y=expm(a*dt)@z
    return y[:4],y[4]

def evolve(x,end,p,dose,starts):
    events=sorted(set([0.,end]+[float(t) for s in starts for t in [s,s+.5] if 0<t<end]))
    area=0.
    for a,b in zip(events[:-1],events[1:]):
        rate=sum(dose/.5 for s in starts if s <= (a+b)/2 < s+.5)
        x,add=advance(x,b-a,p,rate);area+=add
    return x,area

def independent(t,p,dose,starts):
    end,_=evolve(np.zeros(4),672,p,dose,starts)
    before=np.linalg.solve(np.eye(4)-expm(matrix(p)*672),end)
    return np.array([evolve(before,float(x),p,dose,starts)[0][0]*1000/p['v1'] for x in t]),before

class TestPK(unittest.TestCase):
    def test_impulse_against_matrix_exponential(self):
        k,w=rates_weights(P)
        for t in [0,.001,.5,24,168,672]:
            exact=(expm(matrix(P)*t)@np.array([1,0,0,0]))[0]/P['v1']
            self.assertAlmostEqual(float(np.sum(w*np.exp(-k*t))),exact,places=12)

    def test_periodic_infusions_against_independent_event_solver(self):
        times=np.array([0,.25,.5,8,168,168.5,400,504,504.5,672])
        for dose,starts in [(180,[0,168,336]),(135,[0,168,336,504])]:
            actual,_=independent(times,P,dose,starts)
            np.testing.assert_allclose(periodic(times,P,dose,starts),actual,rtol=1e-10,atol=1e-8)

    def test_cycle_and_last_week_integrals_against_augmented_matrix(self):
        for dose,starts in [(180,[0,168,336]),(135,[0,168,336,504])]:
            _,before=independent([0],P,dose,starts)
            _,allarea=evolve(before,672,P,dose,starts)
            _,prearea=evolve(before,504,P,dose,starts)
            self.assertAlmostEqual(integral(0,672,P,dose,starts)/allarea,1,places=10)
            self.assertAlmostEqual(integral(504,672,P,dose,starts)/(allarea-prearea),1,places=9)

    def test_mass_balance_for_draws(self):
        for p in sample_parameters(C,n=15):
            for dose,starts in [(180,[0,168,336]),(135,[0,168,336,504])]:
                expected=dose*len(starts)*1000/p['cl']
                self.assertAlmostEqual(integral(0,672,p,dose,starts)/expected,1,places=9)

    def test_weekly_and_four_week_representation_equivalent(self):
        t=np.linspace(0,672,1501)
        np.testing.assert_allclose(periodic(t,P,135,[0,168,336,504]),periodic(t,P,135,[0],cycle=168),rtol=1e-11)

    def test_first_cycle_matches_zero_state_event_solver(self):
        times=[0,.5,12,168,504,672]
        for dose,starts in [(180,[0,168,336]),(135,[0,168,336,504])]:
            actual=[evolve(np.zeros(4),t,P,dose,starts)[0][0]*1000/P['v1'] for t in times]
            np.testing.assert_allclose(initial(np.array(times),P,dose,starts),actual,rtol=1e-10,atol=1e-9)
            _,area=evolve(np.zeros(4),672,P,dose,starts)
            self.assertAlmostEqual(integral(0,672,P,dose,starts,periodic_state=False)/area,1,places=10)

    def test_peak_min_candidates_match_dense_grid(self):
        t=np.unique(np.r_[np.arange(0,672,.025),[0,.5,168,168.5,336,336.5,504,504.5,672]])
        for dose,starts in [(180,[0,168,336]),(135,[0,168,336,504])]:
            c=periodic(t,P,dose,starts);m=metrics(P,dose,starts)
            self.assertAlmostEqual(m['cmax']/c.max(),1,places=10)
            self.assertAlmostEqual(m['cmin']/c.min(),1,places=10)

    def test_periodic_vs_startup_are_distinct(self):
        a=metrics(P,180,[0,168,336]);b=metrics(P,135,[0,168,336,504])
        self.assertAlmostEqual(a['auc28']/b['auc28'],1,places=10)
        self.assertGreater(abs(a['first_auc28']/b['first_auc28']-1),1e-4)

    def test_correlated_draws_and_reproducibility(self):
        a=sample_parameters(C,n=4000,corr=.5);b=sample_parameters(C,n=4000,corr=.5)
        self.assertEqual(a,b)
        e=np.array([[np.log(x[k]/P[k]) for k in ['cl','v1','q4']] for x in a])
        self.assertLess(abs(np.corrcoef(e.T)[0,2]-.5),.04)

if __name__=='__main__':unittest.main()
