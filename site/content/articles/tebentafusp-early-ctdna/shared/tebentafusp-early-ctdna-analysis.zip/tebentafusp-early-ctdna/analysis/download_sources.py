"""Obtain unchanged public source data without redistributing the workbook."""
from pathlib import Path
from io import BytesIO
import hashlib
import urllib.request
import zipfile

ROOT=Path(__file__).resolve().parents[1]
URL="https://www.ebi.ac.uk/europepmc/webservices/rest/PMC11473804/supplementaryFiles"
MEMBER="41467_2024_53145_MOESM4_ESM.xlsx"
SHA256="dba84aae3190886f524516d8378d0e0a8533e91b9d18c30b83049b1999639017"


def main() -> None:
    path=ROOT/"data/raw/source.xlsx"
    if not path.exists():
        path.parent.mkdir(parents=True,exist_ok=True)
        archive=zipfile.ZipFile(BytesIO(urllib.request.urlopen(URL,timeout=90).read()))
        payload=archive.read(next(n for n in archive.namelist() if n.endswith(MEMBER)))
        assert hashlib.sha256(payload).hexdigest()==SHA256
        with path.open("xb") as handle:
            handle.write(payload)
    assert hashlib.sha256(path.read_bytes()).hexdigest()==SHA256
    print("Verified public source workbook SHA-256.")


if __name__=="__main__":
    main()
