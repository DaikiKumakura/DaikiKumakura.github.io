"""Participant-level internal prediction of recorded week-12 ctDNA detection."""
from pathlib import Path
import csv
import hashlib
import json
import platform

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import openpyxl
from scipy.special import expit
from scipy.stats import rankdata

ROOT = Path(__file__).resolve().parents[1]
SEED = 20261028
RIDGE = 1.0
BOOTSTRAPS = 4000
NUMERIC = (int, float)
MODEL_NAMES = ("baseline", "baseline+week3", "week3")


def numeric(value: object) -> bool:
    return isinstance(value, NUMERIC) and not isinstance(value, bool)


def state(value: object) -> str:
    if numeric(value):
        assert value >= 0
        return "detected" if value > 0 else "recorded_zero"
    if value is None:
        return "blank"
    if value == "NA":
        return "NA"
    if value == "Not analysable*":
        return "not_analysable"
    raise ValueError(f"Unexpected ctDNA encoding: {value!r}")


def write_csv(path: Path, rows: list[dict]) -> None:
    with path.open("w", encoding="utf-8", newline="") as handle:
        writer=csv.DictWriter(handle,fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def fit_logistic(x: np.ndarray, y: np.ndarray, ridge: float=RIDGE) -> np.ndarray:
    """Fixed ridge on slopes, no penalty on the intercept; sum log likelihood."""
    assert len(x)==len(y) and x.shape[1]>=1
    beta=np.zeros(x.shape[1])
    beta[0]=np.log((sum(y)+.5)/(len(y)-sum(y)+.5))
    penalty=np.r_[0., np.full(x.shape[1]-1,ridge)]
    for _ in range(100):
        p=expit(x@beta)
        gradient=x.T@(p-y)+penalty*beta
        hessian=x.T@((p*(1-p))[:,None]*x)+np.diag(penalty)
        step=np.linalg.solve(hessian,gradient)
        beta-=step
        if np.max(abs(step))<1e-10:
            break
    else:
        raise RuntimeError("Logistic fit did not converge")
    assert np.isfinite(beta).all()
    return beta


def design(baseline: np.ndarray, week3: np.ndarray, model: str) -> np.ndarray:
    cols=[np.ones(len(baseline))]
    if "baseline" in model:
        cols.append(baseline)
    if "week3" in model:
        cols.append(week3)
    return np.column_stack(cols)


def loo(x: np.ndarray, y: np.ndarray, ridge: float=RIDGE) -> np.ndarray:
    return np.array([expit(x[i]@fit_logistic(np.delete(x,i,axis=0),np.delete(y,i),ridge))
                     for i in range(len(y))])


def auc(y: np.ndarray, p: np.ndarray) -> float:
    positives=int(sum(y))
    ranks=rankdata(p,method="average")
    return float((sum(ranks[y==1])-positives*(positives+1)/2)/
                 (positives*(len(y)-positives)))


def score(y: np.ndarray, p: np.ndarray) -> dict:
    assert ((p>=0)&(p<=1)).all()
    # Log loss is not reported for the deterministic persistence rule.
    loss=None if np.any((p==0)|(p==1)) else float(np.mean(np.logaddexp(0,np.log(p/(1-p)))-y*np.log(p/(1-p))))
    prediction=p>=.5
    return dict(brier=float(np.mean((y-p)**2)),log_loss=loss,auc=auc(y,p),
                calibration_in_large=float(np.mean(p)-np.mean(y)),
                threshold=.5, false_negative=int(sum((y==1)&~prediction)),
                false_positive=int(sum((y==0)&prediction)),
                true_positive=int(sum((y==1)&prediction)),true_negative=int(sum((y==0)&~prediction)))


def main() -> None:
    for name in ["data/processed","outputs/tables","outputs/figures"]:
        (ROOT/name).mkdir(parents=True,exist_ok=True)
    tables=ROOT/"outputs/tables"
    figures=ROOT/"outputs/figures"
    book=openpyxl.load_workbook(ROOT/"data/raw/source.xlsx",data_only=True)
    raw=[r for r in list(book["Source data"].values)[1:] if numeric(r[0])]
    assert len(raw)==69 and len({r[0] for r in raw})==69
    assert all(r[20]=="Baseline" and r[22]=="3w" and r[24]=="12w" for r in raw)
    figure1=[r for r in list(book["Figure 1"].values)[1:] if numeric(r[0])]
    reference={int(r[0]):r for r in figure1}
    assert len(reference)==69
    assert all(r[21:28]==reference[int(r[0])][6:13] for r in raw)
    counts=[]
    for label,column in [("baseline",21),("week3",23),("week12",25),("progression",27)]:
        values=[state(r[column]) for r in raw]
        for category in ["detected","recorded_zero","blank","NA","not_analysable"]:
            counts.append(dict(timepoint=label,state=category,participants=values.count(category)))
    write_csv(tables/"measurement_states.csv",counts)
    track=[r for r in raw if r[2] != "mutation not detected"]
    assert len(track)==67
    baseline=[r for r in track if numeric(r[21])]
    early=[r for r in baseline if numeric(r[23])]
    complete=[r for r in early if numeric(r[25])]
    assert (len(baseline),len(early),len(complete))==(64,61,54)
    # No imputation: all complete records are evaluable at all three times.
    y=np.array([r[25]>0 for r in complete],dtype=float)
    b=np.array([r[21]>0 for r in complete],dtype=float)
    w=np.array([r[23]>0 for r in complete],dtype=float)
    assert sum(y)==21 and sum(b)==31 and sum(w)==26
    processed=[dict(participant_id=int(r[0]),baseline_detected=int(r[21]>0),
                    week3_detected=int(r[23]>0),week12_detected=int(r[25]>0)) for r in complete]
    write_csv(ROOT/"data/processed/complete_cases.csv",processed)
    flow=[dict(stage="cohort",participants=69),dict(stage="trackable_mutation",participants=67),
          dict(stage="evaluable_baseline",participants=64),dict(stage="baseline_and_week3",participants=61),
          dict(stage="all_three_timepoints",participants=54)]
    write_csv(tables/"cohort_flow.csv",flow)
    missing=[r for r in early if not numeric(r[25])]
    audit=dict(participants=69,trackable=67,not_trackable=2,unique_participant_ids=69,
        source_figure1_ctdna_concordant=69,evaluable_baseline=64,evaluable_week3=64,
        evaluable_week12=56,paired_baseline_week3=61,paired_baseline_week12=54,
        three_timepoints_complete=54,complete_positive_week12=int(sum(y)),
        complete_negative_week12=int(len(y)-sum(y)),
        week12_missing_after_early_pair=len(missing),
        missing_early_pair_pfs_under12weeks=sum(r[10]<84/30.4375 and r[11]==1 for r in missing),
        missing_early_pair_os_under12weeks=sum(r[12]<84/30.4375 and r[13]==1 for r in missing),
        no_imputation=True,recorded_zero_is_true_concentration_zero=False,
        genomic_input_and_variant_lod_available_per_specimen=False,
        xlsx_sha256=hashlib.sha256((ROOT/"data/raw/source.xlsx").read_bytes()).hexdigest())
    (ROOT/"outputs/data-quality-audit.json").write_text(json.dumps(audit,indent=2),encoding="utf-8")
    cross=[]
    for bb in [0,1]:
        for ww in [0,1]:
            sel=(b==bb)&(w==ww)
            cross.append(dict(baseline_detected=bb,week3_detected=ww,participants=int(sum(sel)),
                              week12_detected=int(sum(y[sel])),week12_not_detected=int(sum(1-y[sel]))))
    write_csv(tables/"detection_transitions.csv",cross)
    models={name:loo(design(b,w,name),y) for name in MODEL_NAMES}
    # Persistence is a hard state forecast; no arbitrary smoothing for log loss.
    models["persistence"]=w.copy()
    metric_rows=[dict(model=name,participants=len(y),**score(y,p)) for name,p in models.items()]
    write_csv(tables/"model_metrics.csv",metric_rows)
    prediction_rows=[dict(participant_id=processed[i]["participant_id"],model=name,
                         observed=int(y[i]),predicted=float(p[i]))
                     for name,p in models.items() for i in range(len(y))]
    write_csv(ROOT/"outputs/heldout_predictions_private.csv",prediction_rows)
    calibration=[]
    for name,p in models.items():
        for low,high in [(0.,.25),(.25,.5),(.5,.75),(.75,1.000001)]:
            sel=(p>=low)&(p<high)
            if sum(sel):
                calibration.append(dict(model=name,lower=low,upper=min(high,1.),
                    participants=int(sum(sel)),mean_prediction=float(np.mean(p[sel])),
                    observed_fraction=float(np.mean(y[sel]))))
    write_csv(tables/"calibration.csv",calibration)
    ridge_sensitivity=[]
    for penalty in [.25,.5,1.,2.,4.]:
        for name in MODEL_NAMES:
            prediction=loo(design(b,w,name),y,penalty)
            ridge_sensitivity.append(dict(ridge=penalty,model=name,**score(y,prediction)))
    write_csv(tables/"ridge_sensitivity.csv",ridge_sensitivity)
    # Conditional paired bootstrap: existing held-out predictions are fixed.
    # This does not pretend to include refitting or external-cohort uncertainty.
    rng=np.random.default_rng(SEED)
    boot=rng.integers(0,len(y),(BOOTSTRAPS,len(y)))
    delta=(y-models["baseline+week3"])**2-(y-models["baseline"])**2
    intervals=np.quantile(delta[boot].mean(axis=1),[.025,.975])
    baselinecoef=fit_logistic(design(b,w,"baseline"),y)
    jointcoef=fit_logistic(design(b,w,"baseline+week3"),y)
    coefrows=[dict(model=name,parameter=parameter,coefficient=float(value))
        for name,coef,labels in [("baseline",baselinecoef,["intercept","baseline_detected"]),
                                 ("baseline+week3",jointcoef,["intercept","baseline_detected","week3_detected"])]
        for parameter,value in zip(labels,coef)]
    write_csv(tables/"full_data_coefficients.csv",coefrows)
    summary=dict(audit=audit,seed=SEED,ridge=RIDGE,metrics=metric_rows,transitions=cross,
        brier_delta_joint_minus_baseline=float(np.mean(delta)),
        conditional_paired_bootstrap_delta_95=intervals.tolist(),bootstrap_draws=BOOTSTRAPS,
        refit_uncertainty_included=False,coefficients=coefrows,
        python=platform.python_version(),numpy=np.__version__)
    (ROOT/"outputs/results.json").write_text(json.dumps(summary,indent=2),encoding="utf-8")
    plt.rcParams.update({"font.size":10,"axes.spines.top":False,"axes.spines.right":False})
    fig,axs=plt.subplots(1,2,figsize=(9.2,4),layout="constrained")
    axs[0].barh(["All participants","Trackable mutation","Baseline evaluable","Baseline + week 3","All three visits"],[69,67,64,61,54],color="#0072B2")
    axs[0].invert_yaxis();axs[0].set(xlabel="Participants",title="Recorded measurement availability",xlim=(0,75))
    for j,n in enumerate([69,67,64,61,54]):axs[0].text(n+.7,j,str(n),va="center")
    labels=[f"B{x['baseline_detected']} / W3 {x['week3_detected']}" for x in cross]
    detected=np.array([x["week12_detected"] for x in cross]);negative=np.array([x["week12_not_detected"] for x in cross])
    axs[1].bar(labels,negative,label="Week 12 not detected",color="#56B4E9")
    axs[1].bar(labels,detected,bottom=negative,label="Week 12 detected",color="#D55E00")
    axs[1].set(ylabel="Complete-case participants",title="Baseline / week-3 detection states")
    axs[1].legend(fontsize=8)
    for j,x in enumerate(cross):axs[1].text(j,x["participants"]+.3,str(x["participants"]),ha="center")
    for ext in ["svg","png"]:fig.savefig(figures/f"availability-transitions.{ext}",dpi=180)
    plt.close(fig)
    fig,axs=plt.subplots(1,2,figsize=(9.2,4),layout="constrained")
    names=["baseline","baseline+week3","week3","persistence"]
    colors=["#999999","#0072B2","#009E73","#E69F00"]
    axs[0].barh(names,[score(y,models[n])["brier"] for n in names],color=colors)
    axs[0].invert_yaxis();axs[0].set(xlabel="Brier score (lower is better)",title="Internal held-out prediction; n=54")
    for j,n in enumerate(names):axs[0].text(score(y,models[n])["brier"]+.003,j,f"{score(y,models[n])['brier']:.3f}",va="center")
    axs[0].set_xlim(0,.26)
    axs[1].plot([0,1],[0,1],"k--",lw=1)
    for name,color,marker in [("baseline","#999999","o"),("baseline+week3","#0072B2","s")]:
        rr=[r for r in calibration if r["model"]==name]
        axs[1].scatter([r["mean_prediction"] for r in rr],[r["observed_fraction"] for r in rr],
                       s=[r["participants"]*10 for r in rr],marker=marker,color=color,label=name,alpha=.75)
    axs[1].set(xlabel="Mean held-out probability",ylabel="Observed detected fraction",xlim=(-.03,1.03),ylim=(-.03,1.03),title="Fixed quarter-probability bins")
    axs[1].legend(fontsize=8)
    for ext in ["svg","png"]:fig.savefig(figures/f"heldout-calibration.{ext}",dpi=180)
    plt.close(fig)
    fig,ax=plt.subplots(figsize=(6.4,4),layout="constrained")
    for name,color,mark in [("baseline","#999999","o"),("baseline+week3","#0072B2","s"),("week3","#009E73","^")]:
        rr=[r for r in ridge_sensitivity if r["model"]==name]
        ax.plot([r["ridge"] for r in rr],[r["brier"] for r in rr],label=name,color=color,marker=mark)
    ax.set(xscale="log",xlabel="Fixed ridge penalty",ylabel="Held-out Brier score",title="Penalty sensitivity; no selection by test score")
    ax.legend()
    for ext in ["svg","png"]:fig.savefig(figures/f"ridge-sensitivity.{ext}",dpi=180)
    plt.close(fig)
    print(json.dumps({"audit":audit,"metrics":metric_rows,"delta":summary["brier_delta_joint_minus_baseline"],
                      "conditional_delta_interval":intervals.tolist(),"coefficients":coefrows},indent=2))


if __name__=="__main__":
    main()
