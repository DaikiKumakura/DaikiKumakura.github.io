from pathlib import Path
import importlib.util
import unittest
import numpy as np

ROOT=Path(__file__).resolve().parents[1]
spec=importlib.util.spec_from_file_location("ctdna_run",ROOT/"analysis/run.py")
run=importlib.util.module_from_spec(spec)
spec.loader.exec_module(run)


class AnalysisTests(unittest.TestCase):
    def test_zero_and_unavailable_are_distinct(self):
        self.assertEqual(run.state(0),"recorded_zero")
        self.assertEqual(run.state(None),"blank")
        self.assertEqual(run.state("NA"),"NA")
        self.assertEqual(run.state("Not analysable*"),"not_analysable")
        self.assertEqual(run.state(.1),"detected")
        with self.assertRaises(AssertionError):run.state(-1)

    def test_heldout_label_does_not_affect_own_prediction(self):
        b=np.array([0,0,0,1,1,1,0,1],float)
        w=np.array([0,1,0,1,0,1,0,1],float)
        y=np.array([0,0,1,1,0,1,0,0],float)
        x=run.design(b,w,"baseline+week3")
        before=run.loo(x,y)
        y[2]=1-y[2]
        after=run.loo(x,y)
        self.assertAlmostEqual(before[2],after[2],places=12)

    def test_ridge_handles_separated_binary_data(self):
        x=np.column_stack([np.ones(8),[0,0,0,0,1,1,1,1]])
        y=np.array([0,0,0,0,1,1,1,1],float)
        beta=run.fit_logistic(x,y)
        self.assertTrue(np.isfinite(beta).all())
        self.assertLess(max(abs(beta)),10)

    def test_persistence_brier_and_confusion(self):
        y=np.array([0,1,0,1],float)
        p=np.array([0,0,0,1],float)
        score=run.score(y,p)
        self.assertEqual(score["brier"],.25)
        self.assertIsNone(score["log_loss"])
        self.assertEqual(score["false_negative"],1)
        self.assertEqual(score["false_positive"],0)

    def test_auc_ties(self):
        y=np.array([0,0,1,1],float)
        self.assertEqual(run.auc(y,np.ones(4)),.5)


if __name__=="__main__":
    unittest.main()
