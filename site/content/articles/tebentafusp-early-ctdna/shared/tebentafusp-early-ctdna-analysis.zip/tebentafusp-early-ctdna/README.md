# Early ctDNA and subsequent recorded detection on tebentafusp

Exploratory participant-level internal prediction using the public Source Data
of Rodrigues et al., Nature Communications 15, 8851 (2024),
DOI:10.1038/s41467-024-53145-0. This project creates new statistical results and
new figures. The original workbook and figures are not included in the release.
The source article is CC BY-NC-ND 4.0; use the original publisher/API links for
the source and its terms. No adapted original figure or translated source article
is distributed.

In an existing Python environment with requirements.txt packages:

```sh
python analysis/download_sources.py
python analysis/run.py
python -m unittest discover -s tests
```

No install is performed. Raw inputs are preserved; the downloader checks the
workbook SHA-256 and refuses to overwrite an existing source. The local script
creates participant-level intermediate/prediction files for inspection, but
those files and the workbook must not be put into the public companion ZIP.

The model uses **recorded detection states**, not assumed zero biological
concentrations. Numeric zero, unavailable, blank and non-analysable are separate.
No imputation is performed. Fifty-four complete participants are analysed,
including 21 with recorded week-12 detection. Of the 61 baseline/week-3 pairs,
seven lack a week-12 measurement; all seven have recorded PFS below 12 weeks.
Complete-case performance cannot be transported to all treatment starters.

Fixed-ridge logistic models use one or two binary predictors, an unpenalized
intercept and ridge=1 on the summed negative log likelihood. There is no penalty
selection using the held-out outcomes. Each participant is excluded from their
own estimation. The deterministic carry-forward rule uses week-3 detection;
its log loss is undefined, so only Brier/accuracy/ranking are reported.

Conditional bootstrap intervals resample participant-level loss differences
while holding the existing out-of-fold predictions fixed; they omit refitting
uncertainty. Ridge sensitivity is descriptive, not tuning. Leave-one-out AUC
with binary predictors has within-state fold-prevalence ranking artifacts;
Brier score and log loss are the principal scores, not that AUC.

This is neither external validation, survival-effect estimation nor a rule to
stop treatment, skip week-12 sampling or select a patient regimen. Assay-specific
LoD/genomic input prevents interpreting nondetection as molecular absence.

Public release allow-list: README.md, requirements.txt, analysis/*.py, tests/*.py,
source-provenance.json, outputs/results.json, outputs/data-quality-audit.json,
outputs/tables/*.csv, outputs/figures/*.svg and *.png. Exclude data/raw/,
data/processed/ and outputs/heldout_predictions_private.csv.
