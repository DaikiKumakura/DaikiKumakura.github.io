"""Step 2: half-life bins, threshold rules, logistic models with out-of-sample evaluation, sensitivity analyses.

Run: python -X utf8 analysis/02_models.py   (needs outputs/tables/dataset_tidy.csv from step 1)
Seed: 20261114.  Outcome: multi_daily (BID or TID = 1; QD, QD-or-less, weekly = 0).
"""
import json
import sys
from pathlib import Path

import numpy as np
import pandas as pd
from scipy import stats
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import roc_auc_score

sys.stdout.reconfigure(encoding="utf-8")
ROOT = Path(__file__).resolve().parents[1]
T = ROOT / "outputs/tables"
SEED = 20261114
C_RIDGE = 100.0          # weak L2 penalty (inverse strength) used for all logistic fits
N_BOOT = 2000
BINS = [0, 3, 6, 12, 24, 48, np.inf]
BIN_LABELS = ["<3", "3-6", "6-12", "12-24", "24-48", ">=48"]
THRESHOLDS = [6, 8, 12]

df = pd.read_csv(T / "dataset_tidy.csv")
print("tidy rows:", len(df))


def wilson(k, n, z=1.959964):
    if n == 0:
        return (np.nan, np.nan)
    p = k / n
    den = 1 + z**2 / n
    c = (p + z**2 / (2 * n)) / den
    h = z * np.sqrt(p * (1 - p) / n + z**2 / (4 * n**2)) / den
    return (c - h, c + h)


# ---- primary analysis set ----
prim = df[(~df.is_combination) & df.hl_h.notna() & df.multi_daily.notna()].copy().reset_index(drop=True)
print("primary set: single-ingredient, usable half-life, unambiguous frequency:", len(prim),
      "| multi-daily:", int(prim.multi_daily.sum()), f"({100*prim.multi_daily.mean():.1f}%)")
excl = df[~df.name.isin(prim.name)][["name", "is_combination", "freq"]]
print("excluded from primary:", len(excl), "(combination:", int(excl.is_combination.sum()), ", other:", excl[~excl.is_combination].name.tolist(), ")")
summary = dict(n_primary=len(prim), n_multi=int(prim.multi_daily.sum()), n_excluded=len(excl))

prim["log2hl"] = np.log2(prim.hl_h)
prim["bin"] = pd.cut(prim.hl_h, BINS, labels=BIN_LABELS, right=False)

# ---- bins ----
rows = []
for b in BIN_LABELS:
    g = prim[prim.bin == b]
    k, n = int(g.multi_daily.sum()), len(g)
    lo, hi = wilson(k, n)
    rows.append(dict(bin_h=b, n=n, n_multi_daily=k, prop_multi_daily=k / n if n else np.nan, wilson_lo=lo, wilson_hi=hi,
                     n_qd=int((g.freq == "QD").sum()), n_weekly=int((g.freq == "weekly").sum())))
bins_df = pd.DataFrame(rows)
bins_df.to_csv(T / "bins_multi_daily_by_half_life.csv", index=False)
print(bins_df.round(3).to_string(index=False))

# rank association
rho, p_rho = stats.spearmanr(prim.hl_h, prim.multi_daily)
print(f"Spearman rho (half-life vs multi-daily) = {rho:.3f} (p = {p_rho:.2g}, n = {len(prim)})")
summary["spearman_rho"] = float(rho)

# interval / half-life ratio
tau = prim.freq.map({"QD": 24.0, "BID": 12.0, "TID": 8.0, "weekly": 168.0})
prim["tau_over_hl"] = tau / prim.hl_h
prim["frac_left_24h"] = 2.0 ** (-24.0 / prim.hl_h)
prim["frac_left_own_tau"] = 2.0 ** (-prim.tau_over_hl)   # fraction of a dose's peak left at the end of the regimen's own dosing interval (one compartment, first order)
ratio_tab = prim.groupby("freq").agg(n=("name", "size"), median_hl=("hl_h", "median"), q1_hl=("hl_h", lambda x: x.quantile(.25)), q3_hl=("hl_h", lambda x: x.quantile(.75)),
                                      q1_tau_over_hl=("tau_over_hl", lambda x: x.quantile(.25)), median_tau_over_hl=("tau_over_hl", "median"), q3_tau_over_hl=("tau_over_hl", lambda x: x.quantile(.75)), median_frac_left_24h=("frac_left_24h", "median"), median_frac_left_own_tau=("frac_left_own_tau", "median")).round(3)
ratio_tab.to_csv(T / "half_life_by_frequency.csv")
print(ratio_tab.to_string())

# ---- threshold rules ----
rule_rows = []
y = prim.multi_daily.values.astype(int)
for th in THRESHOLDS:
    pred = (prim.hl_h.values < th).astype(int)
    tp = int(((pred == 1) & (y == 1)).sum()); fn = int(((pred == 0) & (y == 1)).sum())
    tn = int(((pred == 0) & (y == 0)).sum()); fp = int(((pred == 1) & (y == 0)).sum())
    sens_ci, spec_ci, acc_ci = wilson(tp, tp + fn), wilson(tn, tn + fp), wilson(tp + tn, len(y))
    ppv_ci = wilson(tp, tp + fp)
    rule_rows.append(dict(rule=f"predict multi-daily if t1/2 < {th} h", tp=tp, fn=fn, tn=tn, fp=fp,
                          sensitivity=tp / (tp + fn), sens_lo=sens_ci[0], sens_hi=sens_ci[1],
                          specificity=tn / (tn + fp), spec_lo=spec_ci[0], spec_hi=spec_ci[1],
                          accuracy=(tp + tn) / len(y), acc_lo=acc_ci[0], acc_hi=acc_ci[1],
                          ppv=tp / (tp + fp), ppv_lo=ppv_ci[0], ppv_hi=ppv_ci[1],
                          lr_plus=(tp / (tp + fn)) / (fp / (tn + fp))))
base_acc = max(y.mean(), 1 - y.mean())
rules = pd.DataFrame(rule_rows)
rules["accuracy_always_once_daily"] = 1 - y.mean()
rules.to_csv(T / "threshold_rules.csv", index=False)
print(rules.round(3).to_string(index=False))

# ---- logistic models ----
M1_COLS = ["log2hl"]
M2_COLS = ["log2hl", "fic", "orphan", "oncology", "active_metabolite"]
for c in ["fic", "orphan", "active_metabolite"]:
    prim[c] = prim[c].astype(int)


def fit_predict(Xtr, ytr, Xte, cols, C=C_RIDGE):
    if cols is None:  # M0: base rate
        return np.full(len(Xte), (ytr.sum() + 0.0) / len(ytr))
    m = LogisticRegression(C=C, max_iter=5000)
    m.fit(Xtr[cols].values, ytr)
    return m.predict_proba(Xte[cols].values)[:, 1]


def oos_predictions(data, cols, groups=None, C=C_RIDGE):
    yv = data.multi_daily.values.astype(int)
    p = np.zeros(len(data))
    ids = np.arange(len(data)) if groups is None else groups
    for g in np.unique(ids):
        te = ids == g
        p[te] = fit_predict(data[~te], yv[~te], data[te], cols, C)
    return np.clip(p, 1e-6, 1 - 1e-6)


def logloss(y_, p_):
    return float(-np.mean(y_ * np.log(p_) + (1 - y_) * np.log(1 - p_)))


def brier(y_, p_):
    return float(np.mean((p_ - y_) ** 2))


def calib(y_, p_):
    lp = np.log(p_ / (1 - p_)).reshape(-1, 1)
    m = LogisticRegression(C=1e6, max_iter=5000).fit(lp, y_)
    return float(m.intercept_[0]), float(m.coef_[0, 0])


MODELS = {"M0 base rate": None, "M1 log2 half-life": M1_COLS, "M2 + FIC, orphan, oncology, metabolite": M2_COLS}
rng = np.random.default_rng(SEED)
idx_boot = rng.integers(0, len(prim), size=(N_BOOT, len(prim)))

results, preds = [], {}
for scheme in ["leave-one-out", "leave-one-disease-group-out"]:
    groups = None if scheme == "leave-one-out" else pd.factorize(prim.disease_group)[0]
    for name, cols in MODELS.items():
        p = oos_predictions(prim, cols, groups)
        preds[(scheme, name)] = p
    for name in MODELS:
        p = preds[(scheme, name)]
        b = np.array([brier(y[i], p[i]) for i in idx_boot])
        ll = np.array([logloss(y[i], p[i]) for i in idx_boot])
        row = dict(scheme=scheme, model=name, brier=brier(y, p), brier_lo=np.percentile(b, 2.5), brier_hi=np.percentile(b, 97.5),
                   log_loss=logloss(y, p), log_loss_lo=np.percentile(ll, 2.5), log_loss_hi=np.percentile(ll, 97.5))
        if name != "M0 base rate":
            auc = roc_auc_score(y, p)
            aucb = []
            for i in idx_boot:
                if 0 < y[i].sum() < len(i):
                    aucb.append(roc_auc_score(y[i], p[i]))
            row.update(auc=auc, auc_lo=np.percentile(aucb, 2.5), auc_hi=np.percentile(aucb, 97.5))
            a, s = calib(y, p)
            row.update(calib_intercept=a, calib_slope=s)
        results.append(row)
res = pd.DataFrame(results)
res.to_csv(T / "model_comparison.csv", index=False)
base_in_sample = float(y.mean() * (1 - y.mean()))
m0_loo = float(res[(res.scheme == "leave-one-out") & (res.model == "M0 base rate")].brier.iloc[0])
print(f"in-sample base-rate Brier score p(1-p) = {base_in_sample:.4f}; leave-one-out M0 = {m0_loo:.4f}; artefact of leaving one drug out of the base rate = {m0_loo - base_in_sample:.4f}")
summary.update(brier_base_rate_in_sample=base_in_sample, brier_M0_loo_artefact=m0_loo - base_in_sample)
onc_train_const = prim[prim.disease_group != "Oncology"].oncology.nunique()
print(f"leave-one-disease-group-out, oncology held out: oncology indicator takes {onc_train_const} distinct value(s) in the training data, so the M2 oncology term is not estimable from it (the L2 penalty shrinks it to zero)")
print(res.round(3).to_string(index=False))

# differences vs M0 and M2 vs M1 (bootstrap over entries on fixed out-of-sample predictions)
diff_rows = []
for scheme in ["leave-one-out", "leave-one-disease-group-out"]:
    p0, p1, p2 = (preds[(scheme, n)] for n in MODELS)
    for lab, pa, pb in [("M1 minus M0", p1, p0), ("M2 minus M1", p2, p1), ("M2 minus M0", p2, p0)]:
        for metric, f in [("brier", brier), ("log_loss", logloss)]:
            d = f(y, pa) - f(y, pb)
            db = np.array([f(y[i], pa[i]) - f(y[i], pb[i]) for i in idx_boot])
            diff_rows.append(dict(scheme=scheme, contrast=lab, metric=metric, difference=d, lo=np.percentile(db, 2.5), hi=np.percentile(db, 97.5)))
diffs = pd.DataFrame(diff_rows)
diffs.to_csv(T / "model_differences.csv", index=False)
print(diffs.round(4).to_string(index=False))

pred_out = prim[["name", "hl_h", "freq", "multi_daily", "disease_group"]].copy()
for (scheme, name), p in preds.items():
    pred_out[f"{scheme}|{name}"] = p
pred_out.to_csv(T / "oos_predictions.csv", index=False)

# calibration bins for M1 and M2 (LOO)
cal_rows = []
for name in ["M1 log2 half-life", "M2 + FIC, orphan, oncology, metabolite"]:
    p = preds[("leave-one-out", name)]
    q = pd.qcut(p, 4, duplicates="drop")
    for iv, g in pd.DataFrame({"p": p, "y": y, "q": q}).groupby("q", observed=True):
        lo, hi = wilson(int(g.y.sum()), len(g))
        cal_rows.append(dict(model=name, group=str(iv), n=len(g), mean_predicted=g.p.mean(), observed=g.y.mean(), wilson_lo=lo, wilson_hi=hi))
pd.DataFrame(cal_rows).to_csv(T / "calibration_quartiles.csv", index=False)

# ---- full-data coefficients with refit bootstrap ----
X = prim[M1_COLS].values
m1 = LogisticRegression(C=C_RIDGE, max_iter=5000).fit(X, y)
b1 = float(m1.coef_[0, 0]); a1 = float(m1.intercept_[0])
bs = []
for i in idx_boot:
    if 0 < y[i].sum() < len(i):
        mm = LogisticRegression(C=C_RIDGE, max_iter=5000).fit(X[i], y[i])
        bs.append(mm.coef_[0, 0])
lo_b, hi_b = np.percentile(bs, [2.5, 97.5])
print(f"M1 (full data): intercept {a1:.3f}, slope per doubling of half-life {b1:.3f} (odds ratio {np.exp(b1):.3f}); refit-bootstrap 95% interval for the slope {lo_b:.3f} to {hi_b:.3f} (OR {np.exp(lo_b):.3f} to {np.exp(hi_b):.3f})")
for h in [2, 4, 6, 8, 12, 24, 48, 96]:
    print(f"  fitted P(multi-daily) at t1/2 = {h} h: {1/(1+np.exp(-(a1 + b1*np.log2(h)))):.3f}")
summary.update(m1_intercept=a1, m1_slope=b1, m1_slope_lo=float(lo_b), m1_slope_hi=float(hi_b))
fit_curve = pd.DataFrame({"hl_h": np.geomspace(0.8, 300, 120)})
fit_curve["p_multi_daily"] = 1 / (1 + np.exp(-(a1 + b1 * np.log2(fit_curve.hl_h))))
fit_curve["frac_left_24h"] = 2.0 ** (-24.0 / fit_curve.hl_h)
fit_curve.to_csv(T / "fitted_curve.csv", index=False)

m2 = LogisticRegression(C=C_RIDGE, max_iter=5000).fit(prim[M2_COLS].values, y)
coef2 = pd.DataFrame({"term": M2_COLS, "coef_log_odds": m2.coef_[0], "odds_ratio": np.exp(m2.coef_[0])})
coef2.to_csv(T / "m2_coefficients.csv", index=False)
print(coef2.round(3).to_string(index=False))

# ---- sensitivity (leave-one-out, M1 vs M0) ----
sens_rows = []


def sens(label, data, hl_col, note="", C=C_RIDGE):
    d = data.copy()
    d["log2hl"] = np.log2(d[hl_col])
    yy = d.multi_daily.values.astype(int)
    p0 = oos_predictions(d.assign(multi_daily=yy), None)
    p1 = oos_predictions(d.assign(multi_daily=yy), M1_COLS, None, C)
    mm = LogisticRegression(C=C, max_iter=5000).fit(d[M1_COLS].values, yy)
    sens_rows.append(dict(analysis=label, n=len(d), n_multi=int(yy.sum()), slope_per_doubling=float(mm.coef_[0, 0]),
                          brier_M0=brier(yy, p0), brier_M1=brier(yy, p1), logloss_M0=logloss(yy, p0), logloss_M1=logloss(yy, p1),
                          auc_M1=roc_auc_score(yy, p1), note=note))


sens("primary", prim, "hl_h")
sens("range lower bound", prim, "hl_lo_h", "half-life = lower bound of reported range")
sens("range upper bound", prim, "hl_hi_h", "half-life = upper bound of reported range")
sens("weekly drug removed", prim[prim.freq != "weekly"], "hl_h")
print("flagged as discontinued in the workbook, in the primary set:", prim[prim.discontinued.astype(bool)].name.tolist(), "| with half-life < 6 h and once daily:", prim[prim.discontinued.astype(bool) & (prim.hl_h < 6) & (prim.multi_daily == 0)].name.tolist())
sens("discontinued drugs removed", prim[~prim.discontinued.astype(bool)], "hl_h", "drugs flagged as discontinued in the workbook removed")
sens("ridge C = 1e6", prim, "hl_h", "almost unpenalised", C=1e6)
for lab, col in [("combinations at shortest component", "hl_shortest_comp_h"), ("combinations at longest component", "hl_longest_comp_h")]:
    d = df[df.multi_daily.notna() & df[col].notna()].copy().reset_index(drop=True)
    d["hl_h_sens"] = d[col]
    sens(lab, d, "hl_h_sens", "includes the 9 combination entries that have component half-lives")
for lab, val in [("maralixibat coded once daily", 0), ("maralixibat coded multi-daily", 1)]:
    d = df[(~df.is_combination)].copy()
    d.loc[d.name == "maralixibat", "hl_h"] = 1.6  # label value read in the label audit (healthy adults, 30 mg oral solution)
    d.loc[d.name == "maralixibat", "multi_daily"] = val
    d = d[d.hl_h.notna() & d.multi_daily.notna()].reset_index(drop=True)
    sens(lab, d, "hl_h", "maralixibat half-life 1.6 h taken from the current label (not in the workbook)")
sens_df = pd.DataFrame(sens_rows)
sens_df.to_csv(T / "sensitivity.csv", index=False)
print(sens_df.round(3).to_string(index=False))

# ---- case tables ----
cases_short = prim[(prim.hl_h < 6) & (prim.multi_daily == 0)].sort_values("hl_h")[["name", "year", "hl_h", "freq", "disease", "total_daily_dose", "active_metabolite", "orphan", "fic"]]
cases_long = prim[(prim.hl_h >= 24) & (prim.multi_daily == 1)].sort_values("hl_h")[["name", "year", "hl_h", "freq", "disease", "total_daily_dose", "active_metabolite", "orphan", "fic"]]
cases_short.to_csv(T / "cases_short_half_life_once_daily.csv", index=False)
cases_long.to_csv(T / "cases_long_half_life_multi_daily.csv", index=False)
print("short half-life (<6 h) once-daily or weekly:", len(cases_short), "of", int(((prim.hl_h < 6)).sum()), "with half-life < 6 h")
print(cases_short.to_string(index=False))
print("long half-life (>=24 h) multi-daily:", len(cases_long), "of", int((prim.hl_h >= 24).sum()), "with half-life >= 24 h")
print(cases_long.to_string(index=False))

prim.to_csv(T / "primary_set.csv", index=False)
(T / "model_summary.json").write_text(json.dumps(summary, indent=2), encoding="utf-8")
print("done")
