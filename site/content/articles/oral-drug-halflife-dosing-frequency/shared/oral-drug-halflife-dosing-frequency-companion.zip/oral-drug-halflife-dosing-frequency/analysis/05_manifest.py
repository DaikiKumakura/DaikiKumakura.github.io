"""Step 5: SHA256 manifest of every table written to outputs/tables (so a re-run can be checked file by file).
Run after steps 1-4: python -X utf8 analysis/05_manifest.py            -> writes outputs/MANIFEST_SHA256.txt
Check a re-run:      python -X utf8 analysis/05_manifest.py --check   -> compares the current tables with the stored manifest
"""
import hashlib
import sys
from pathlib import Path

sys.stdout.reconfigure(encoding="utf-8")
ROOT = Path(__file__).resolve().parents[1]
T = ROOT / "outputs/tables"
M = ROOT / "outputs/MANIFEST_SHA256.txt"


def current():
    return {p.name: hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(T.iterdir()) if p.suffix in {".csv", ".json"}}


if "--check" in sys.argv:
    stored = dict(line.split("  ", 1)[::-1] for line in M.read_text(encoding="utf-8").splitlines() if line.strip())
    cur = current()
    bad = [n for n in sorted(set(stored) | set(cur)) if stored.get(n) != cur.get(n)]
    print("tables checked:", len(cur), "| mismatches:", bad if bad else "none")
    sys.exit(1 if bad else 0)
M.write_text("".join(f"{h}  {n}\n" for n, h in current().items()), encoding="utf-8")
print("manifest written:", len(current()), "tables")
