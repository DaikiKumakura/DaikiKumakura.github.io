"""Step 3: figures (English text, Okabe-Ito palette). Needs outputs/tables from steps 1-2.
Run: python -X utf8 analysis/03_figures.py
"""
import json
import sys
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

sys.stdout.reconfigure(encoding="utf-8")
ROOT = Path(__file__).resolve().parents[1]
T, F = ROOT / "outputs/tables", ROOT / "outputs/figures"
F.mkdir(parents=True, exist_ok=True)
BLUE, ORANGE, GREEN, VERM, GREY, SKY, PINK = "#0072B2", "#E69F00", "#009E73", "#D55E00", "#666666", "#56B4E9", "#CC79A7"
plt.rcParams.update({"font.size": 9.5, "axes.spines.top": False, "axes.spines.right": False, "figure.dpi": 150})

prim = pd.read_csv(T / "primary_set.csv")
bins = pd.read_csv(T / "bins_multi_daily_by_half_life.csv")
curve = pd.read_csv(T / "fitted_curve.csv")
mc = pd.read_csv(T / "model_comparison.csv")
summ = json.loads((T / "model_summary.json").read_text())
audit = json.loads((T / "audit_counts.json").read_text())

# ---- Fig 1: observed proportion by bin, fitted curve, reference curve ----
fig, ax = plt.subplots(figsize=(8.2, 4.6))
edges = [0.5, 3, 6, 12, 24, 48, 300]
centres = [np.sqrt(edges[i] * edges[i + 1]) for i in range(6)]
ax.hlines(1 - 0, 0, 0)  # placeholder to keep axes simple
ax.errorbar(centres, bins.prop_multi_daily, yerr=[bins.prop_multi_daily - bins.wilson_lo, bins.wilson_hi - bins.prop_multi_daily],
            fmt="o", color=BLUE, capsize=3, label="Observed share dosed more than once daily (Wilson 95% interval)", zorder=3)
for x, p, n, k in zip(centres, bins.prop_multi_daily, bins.n, bins.n_multi_daily):
    ax.annotate(f"{k}/{n}", (x, p), textcoords="offset points", xytext=(0, 9), ha="center", fontsize=8, color=BLUE)
ax.plot(curve.hl_h, curve.p_multi_daily, color=ORANGE, lw=2, label="Logistic fit on log2 half-life (all 93 entries)")
ax.axhline(prim.multi_daily.mean(), color=GREY, ls=":", lw=1.2, label=f"Base rate {100*prim.multi_daily.mean():.0f}%")
for e in edges[1:-1]:
    ax.axvline(e, color="#dddddd", lw=0.7, zorder=0)
ax.set_xscale("log")
ax.set_xlim(0.7, 300)
ax.set_ylim(0, 1.0)
ax.set_xticks([1, 3, 6, 12, 24, 48, 100, 300])
ax.get_xaxis().set_major_formatter(matplotlib.ticker.ScalarFormatter())
ax.set_xlabel("Elimination half-life of the parent drug (h, log scale; bin edges 3, 6, 12, 24, 48 h)")
ax.set_ylabel("Share dosed twice or three times daily")
ax2 = ax.twinx()
ax2.spines["right"].set_visible(True)
ax2.plot(curve.hl_h, curve.frac_left_24h, color=VERM, lw=1.6, ls="--", label="Reference: fraction of a dose's peak left at 24 h, 2^(-24/t1/2) (right axis; one-compartment assumption)")
ax2.set_ylim(0, 1.0)
ax2.set_ylabel("Fraction of peak left at 24 h", fontsize=9)
h1, l1 = ax.get_legend_handles_labels()
h2, l2 = ax2.get_legend_handles_labels()
ax.legend(h1 + h2, l1 + l2, frameon=False, fontsize=7.2, loc="upper right", bbox_to_anchor=(1.0, 1.0))
ax.set_title("Dosed more than once daily, by half-life (n = 93 single-ingredient entries)", fontsize=9.5)
fig.tight_layout()
fig.savefig(F / "fig2_halflife_vs_multi_daily.png")
plt.close(fig)

# ---- Fig 2: model comparison ----
fig, axes = plt.subplots(1, 2, figsize=(9.6, 3.6), sharey=True)
labels = ["M0 base rate", "M1 log2 half-life", "M2 + FIC, orphan, oncology, metabolite"]
short = ["M0 base rate", "M1 half-life only", "M2 half-life + 4 terms"]
cols = [GREY, BLUE, ORANGE]
for ax, metric, ttl in zip(axes, ["brier", "log_loss"], ["Brier score (lower is better)", "Log loss, nats (lower is better)"]):
    for k, scheme in enumerate(["leave-one-out", "leave-one-disease-group-out"]):
        for j, lab in enumerate(labels):
            r = mc[(mc.scheme == scheme) & (mc.model == lab)].iloc[0]
            y = j + (0.15 if k == 0 else -0.15)
            ax.errorbar(r[metric], y, xerr=[[r[metric] - r[metric + "_lo"]], [r[metric + "_hi"] - r[metric]]], fmt="o" if k == 0 else "s",
                        color=cols[j], capsize=3, mfc=cols[j] if k == 0 else "white", label=None)
    ax.set_yticks(range(3))
    ax.set_yticklabels(short)
    ax.set_title(ttl, fontsize=9)
    ax.set_xlabel("Out-of-sample value (95% bootstrap interval)")
from matplotlib.lines import Line2D
fig.legend(handles=[Line2D([0], [0], marker="o", color="#444", ls="", label="Leave-one-out (each entry held out)"),
                    Line2D([0], [0], marker="s", color="#444", mfc="white", ls="", label="Leave-one-disease-group-out")],
           frameon=False, fontsize=8, loc="lower center", ncol=2)
axes[0].invert_yaxis()
fig.suptitle("Out-of-sample prediction of 'dosed more than once daily' (n = 93; M0 always predicts the base rate)", fontsize=9)
fig.tight_layout(rect=(0, 0.07, 1, 1))
fig.savefig(F / "fig3_model_comparison.png")
plt.close(fig)

# ---- Fig 3: calibration (LOO quartiles) ----
cal = pd.read_csv(T / "calibration_quartiles.csv")
fig, ax = plt.subplots(figsize=(4.8, 4.4))
ax.plot([0, 0.8], [0, 0.8], color="#999", lw=1)
for name, col, mk in [("M1 log2 half-life", BLUE, "o"), ("M2 + FIC, orphan, oncology, metabolite", ORANGE, "s")]:
    g = cal[cal.model == name]
    ax.errorbar(g.mean_predicted, g.observed, yerr=[g.observed - g.wilson_lo, g.wilson_hi - g.observed], fmt=mk + "-", color=col, capsize=3,
                label="M1 half-life only" if name.startswith("M1") else "M2 half-life + 4 terms")
ax.set_xlim(0, 0.8)
ax.set_ylim(0, 1)
ax.set_xlabel("Mean out-of-sample predicted probability (quartile groups)")
ax.set_ylabel("Observed share dosed more than once daily")
ax.set_title("Calibration, leave-one-out (n = 93; about 23 entries per point;\nWilson 95% intervals)", fontsize=8.5)
ax.legend(frameon=False, fontsize=8)
fig.tight_layout()
fig.savefig(F / "fig4_calibration.png")
plt.close(fig)

# ---- Fig 4: case map (two panels) ----
fig, axes = plt.subplots(1, 2, figsize=(9.6, 4.8))
short = prim[(prim.hl_h < 6) & (prim.multi_daily == 0)].sort_values("hl_h", ascending=False)
long_ = prim[(prim.hl_h >= 24) & (prim.multi_daily == 1)].sort_values("hl_h")
n_lt6, n_ge24 = int((prim.hl_h < 6).sum()), int((prim.hl_h >= 24).sum())
ax = axes[0]
ax.scatter(short.hl_h, range(len(short)), color=BLUE, s=32, zorder=3)
ax.set_yticks(range(len(short)))
ax.set_yticklabels(short.name, fontsize=8)
ax.set_xscale("log")
ax.set_xlim(0.6, 8)
ax.set_xticks([1, 2, 3, 4, 6])
ax.get_xaxis().set_major_formatter(matplotlib.ticker.ScalarFormatter())
ax.axvline(6, color=GREY, ls=":", lw=1)
ax.get_xaxis().set_minor_formatter(matplotlib.ticker.NullFormatter())
ax.set_xlabel("Half-life (h, log scale)")
ax.set_title(f"Half-life < 6 h, once daily or weekly ({len(short)} of {n_lt6} with half-life < 6 h)", fontsize=8.5)
ax = axes[1]
colr = {"BID": ORANGE, "TID": VERM}
for i, r in enumerate(long_.itertuples()):
    ax.scatter(r.hl_h, i, color=colr[r.freq], s=32, zorder=3, label=None)
ax.set_yticks(range(len(long_)))
ax.set_yticklabels([f"{r.name} ({r.freq})" for r in long_.itertuples()], fontsize=8)
ax.set_xscale("log")
ax.set_xlim(18, 150)
ax.set_xticks([24, 36, 48, 72, 100])
ax.get_xaxis().set_major_formatter(matplotlib.ticker.ScalarFormatter())
ax.axvline(24, color=GREY, ls=":", lw=1)
ax.get_xaxis().set_minor_formatter(matplotlib.ticker.NullFormatter())
ax.set_xlabel("Half-life (h, log scale)")
ax.set_title(f"Half-life >= 24 h, BID or TID ({len(long_)} of {n_ge24} with half-life >= 24 h)", fontsize=8.5)
fig.suptitle("Entries where half-life alone points the other way (primary set, n = 93)", fontsize=9.5)
fig.tight_layout()
fig.savefig(F / "fig5_case_map.png")
plt.close(fig)

# ---- Fig 5: data audit flow ----
fig, ax = plt.subplots(figsize=(8.6, 3.5))
ax.axis("off")


def box(x, y, w, h, text, color):
    ax.add_patch(plt.Rectangle((x, y), w, h, fc=color, ec="#444", lw=0.8, alpha=0.25))
    ax.text(x + w / 2, y + h / 2, text, ha="center", va="center", fontsize=8)


box(0.0, 0.55, 0.22, 0.3, "Dose_and_Class sheet\n104 approved entries\n(2020-2024)", SKY)
box(0.30, 0.62, 0.26, 0.2, "10 combination products\nexcluded from the primary model\n(sensitivity analysis only)", GREY)
box(0.30, 0.28, 0.26, 0.2, "1 entry (maralixibat) excluded:\nlabel 'QD or BID' and no half-life\nin the workbook", GREY)
box(0.64, 0.45, 0.22, 0.28, f"Primary set\n{summ['n_primary']} single-ingredient entries\n{summ['n_multi']} dosed BID or TID\n{summ['n_primary'] - summ['n_multi']} once daily or weekly", BLUE)
ax.annotate("", xy=(0.30, 0.72), xytext=(0.22, 0.72), arrowprops=dict(arrowstyle="->"))
ax.annotate("", xy=(0.30, 0.38), xytext=(0.22, 0.62), arrowprops=dict(arrowstyle="->"))
ax.annotate("", xy=(0.64, 0.55), xytext=(0.22, 0.60), arrowprops=dict(arrowstyle="->", color=BLUE))
n_all = audit["dose_and_class_entries"]
ax.text(0.0, 0.12, f"Row checks: Sheet1 frequency labels agree with Dose_and_Class for {n_all - audit['frequency_disagreements']} of {n_all} entries (maralixibat differs); "
        f"orphan flags agree for {n_all - audit['orphan_disagreements']} of {n_all};\nFIC flags disagree for {audit['fic_disagreements']} entries between Dose_and_Class and the second FIC column of Sheet1 (Dose_and_Class used).",
        fontsize=7.6, va="top")
ax.set_xlim(0, 1)
ax.set_ylim(0, 1)
ax.set_title("Data audit flow", fontsize=9.5, loc="left")
fig.tight_layout()
fig.savefig(F / "fig1_data_audit_flow.png")
plt.close(fig)
for f in sorted(F.glob("fig*.png")):
    print("written:", f.name, f.stat().st_size, "bytes")
print("figures written")
