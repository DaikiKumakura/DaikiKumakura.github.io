"""Step 4: compare the ten hand-checked labels (inputs/label_audit.csv) with the workbook values.
Run: python -X utf8 analysis/04_label_audit_compare.py
"""
import sys
from pathlib import Path

import numpy as np
import pandas as pd

sys.stdout.reconfigure(encoding="utf-8")
ROOT = Path(__file__).resolve().parents[1]
T = ROOT / "outputs/tables"
lab = pd.read_csv(ROOT / "inputs/label_audit.csv")
df = pd.read_csv(T / "dataset_tidy.csv")
m = lab.merge(df[["name", "year", "freq", "hl_h", "hl_lo_h", "hl_hi_h", "hl_raw_own"]], on="name", how="left", validate="one_to_one")
assert len(m) == 10 and m.year.notna().all()


def freq_status(r):
    if r.label_frequency_class == r.freq:
        return "agree"
    if r.label_frequency_class == "ambiguous_qd_or_bid" and r.freq == "ambiguous_qd_or_bid":
        return "agree"
    return "differ"


def hl_status(r):
    if pd.isna(r.hl_h):
        return "workbook has no value"
    # overlap of the workbook range with the label range
    if r.hl_lo_h <= r.label_half_life_hi_h and r.label_half_life_lo_h <= r.hl_hi_h:
        return "agree" if abs(np.log(r.hl_h / np.sqrt(r.label_half_life_lo_h * r.label_half_life_hi_h))) < 0.1 else "overlap"
    gap = min(abs(r.hl_h - r.label_half_life_lo_h), abs(r.hl_h - r.label_half_life_hi_h))
    return f"differ (gap {gap:.2f} h)"


m["frequency_check"] = m.apply(freq_status, axis=1)
m["half_life_check"] = m.apply(hl_status, axis=1)
out = m[["name", "year", "freq", "label_frequency_class", "frequency_check", "hl_raw_own", "label_half_life_text", "half_life_check"]]
out.to_csv(T / "label_audit_comparison.csv", index=False)
print(out.to_string(index=False))
print("frequency agree:", int((m.frequency_check == "agree").sum()), "of 10")
print("half-life agree:", int((m.half_life_check == "agree").sum()), "| overlap:", int((m.half_life_check == "overlap").sum()),
      "| differ:", int(m.half_life_check.str.startswith("differ").sum()), "| workbook has no value:", int((m.half_life_check == "workbook has no value").sum()))
