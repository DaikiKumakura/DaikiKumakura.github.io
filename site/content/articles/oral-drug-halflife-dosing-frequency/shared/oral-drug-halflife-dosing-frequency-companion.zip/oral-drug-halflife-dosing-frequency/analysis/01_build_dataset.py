"""Step 1: clean the Supporting Information workbook of Brown (J Med Chem 2025) into one row per approved entry.

Run: python -X utf8 analysis/01_build_dataset.py [path/to/jm5c02863_si_002.xlsx]
Default path: inputs/raw/jm5c02863_si_002.xlsx (not redistributed; see inputs/PROVENANCE.md).
Writes: outputs/tables/dataset_tidy.csv (per-drug; derived from the publisher workbook, not redistributed),
        outputs/tables/audit_*.csv, outputs/tables/audit_counts.json, outputs/logs/01_build_dataset.txt (stdout).
"""
import hashlib
import json
import re
import sys
from pathlib import Path

import numpy as np
import openpyxl
import pandas as pd

sys.stdout.reconfigure(encoding="utf-8")
ROOT = Path(__file__).resolve().parents[1]
XLSX = Path(sys.argv[1]) if len(sys.argv) > 1 else ROOT / "inputs/raw/jm5c02863_si_002.xlsx"
OUT = ROOT / "outputs/tables"
OUT.mkdir(parents=True, exist_ok=True)
EXPECTED_SHA256 = "796452e02efe3edd647375d15d5b1911682ef44d2709499f8846387fdf950213"

sha = hashlib.sha256(XLSX.read_bytes()).hexdigest()
print("workbook", XLSX.name, "bytes", XLSX.stat().st_size, "sha256", sha)
assert sha == EXPECTED_SHA256, "unexpected workbook version"

wb = openpyxl.load_workbook(XLSX, data_only=True)
audit = {}


def norm(s):
    return re.sub(r"\s+", " ", str(s).replace("\xa0", " ")).strip().lower() if s is not None else None


# ---- Dose_and_Class: one row per entry (rows 2..105) ----
ws = wb["Dose_and_Class"]
dose_rows = []
for r in ws.iter_rows(min_row=2, max_row=105, values_only=True):
    if r[0] is None:
        continue
    dose_rows.append(r)
dc = pd.DataFrame(
    [
        dict(name_raw=r[0], name=norm(r[0]), fic_dc=(r[1] == "Y"), orphan_dc=(r[2] == "Y"), year=r[3],
             freq_dc_raw=r[7], dose_raw=r[6], total_daily_dose=r[8], dose_note=r[10])
        for r in dose_rows
    ]
)
print("Dose_and_Class entries:", len(dc), "unique names:", dc.name.nunique())
audit["dose_and_class_entries"] = len(dc)
assert len(dc) == 104 and dc.name.is_unique
print("entries per year:", dc.year.value_counts().sort_index().to_dict())
audit["entries_per_year"] = {int(k): int(v) for k, v in dc.year.value_counts().sort_index().items()}


def norm_freq(f):
    f = norm(f)
    if f is None:
        return None
    if "weekly" in f:
        return "weekly"
    if f.startswith("qd or bid"):
        return "ambiguous_qd_or_bid"
    if f.startswith("bid"):
        return "BID"
    if f.startswith("tid"):
        return "TID"
    if f.startswith("qd"):
        return "QD"
    raise ValueError("unrecognised frequency label: " + str(f))


dc["freq"] = dc.freq_dc_raw.map(norm_freq)
dc["short_course"] = dc.dose_note.fillna("").str.contains(r"\bdays?\b|one day|once", case=False) & dc.name.isin(
    ["zuranolone", "ibrexafungerp", "nirmatrelvir, ritonavir", "sulopenem etzadroxil and probenecid", "vonoprazan, amoxicillin, and clarithromycin",
     "nifurtimox", "fexinidazole", "lenacapavir (note this is combination of sc and oral admin). values are for oral only"])
print("frequency labels (Dose_and_Class, normalised):", dc.freq.value_counts().to_dict())

# ---- Sheet1: assign rows to entries ----
ws = wb["Sheet1"]
hdr = [c for c in next(ws.iter_rows(min_row=1, max_row=1, values_only=True))]
s1_all = [r for r in ws.iter_rows(min_row=2, values_only=True)]
s1_rows = [r for r in s1_all if r[0] is not None or r[2] is not None]
print("Sheet1 non-empty rows:", len(s1_rows), "of", len(s1_all), "physical rows")
audit["sheet1_nonempty_rows"] = len(s1_rows)

names = set(dc.name)
blocks = []  # list of dict(entry=name, rows=[...])
cur = None
unmatched = []
for r in s1_rows:
    nm = norm(r[2])
    if nm in names and (cur is None or nm != cur["entry"]) and nm not in {b["entry"] for b in blocks}:
        cur = {"entry": nm, "rows": [r]}
        blocks.append(cur)
    else:
        if cur is None:
            raise RuntimeError("row before first entry: " + str(r[:4]))
        cur["rows"].append(r)
        if nm not in names and nm != cur["entry"]:
            unmatched.append((cur["entry"], r[2]))
print("Sheet1 blocks:", len(blocks), "continuation rows with a different name (metabolites/components):", len(unmatched))
audit["sheet1_blocks"] = len(blocks)
missing_entries = sorted(names - {b["entry"] for b in blocks})
print("Dose_and_Class entries without a Sheet1 block:", missing_entries)
audit["dose_entries_without_sheet1_block"] = missing_entries
assert not missing_entries and len(blocks) == 104

# ---- half-life parser ----
RANGE = re.compile(r"(\d+(?:\.\d+)?)\s*(?:to|-|–)\s*(\d+(?:\.\d+)?)")
NUM = re.compile(r"\d+(?:\.\d+)?")


def parse_hl(x):
    """Return dict(lo, hi, point, note) in hours; None if no usable value."""
    if x is None:
        return None
    s = str(x).strip()
    low = s.lower()
    factor = 24.0 if "day" in low else 1.0
    note = []
    m = RANGE.search(s)
    if "±" in s:  # mean +- SD: first number only
        v = float(NUM.search(s).group()) * factor
        return dict(lo=v, hi=v, point=v, is_range=False, note="mean +- SD text")
    if m:
        lo, hi = float(m.group(1)) * factor, float(m.group(2)) * factor
        if "cyp2c19" in low:
            note.append("second value for CYP2C19 poor metabolisers ignored")
        return dict(lo=lo, hi=hi, point=float(np.sqrt(lo * hi)), is_range=True, note="; ".join(note))
    m = NUM.search(s)
    if not m:
        return None
    v = float(m.group()) * factor
    for key, lab in [("terminal", "terminal"), ("transplant", "transplant patients"), ("patients", "patients")]:
        if key in low:
            note.append(lab)
    return dict(lo=v, hi=v, point=v, is_range=False, note="; ".join(note))


raw_hl_strings = sorted({str(r[19]) for b in blocks for r in b["rows"] if r[19] is not None})
print("distinct half-life strings:", len(raw_hl_strings))
bad = []
for s in raw_hl_strings:
    p = parse_hl(s)
    if p is None:
        bad.append(s)
print("unparsable half-life strings:", bad)
audit["unparsable_half_life_strings"] = bad
pd.DataFrame(
    [dict(raw=s, **(parse_hl(s) or {})) for s in raw_hl_strings]
).to_csv(OUT / "audit_half_life_parsing.csv", index=False)

COMBO = {"decitabine and cedazuridine", "drospirenone and estetrol", "olanzapine and samidorphan", "serdexmethylphenidate and dexmethylphenidate",
         "sodium phenylbutyrate/taurursodiol", "nirmatrelvir, ritonavir", "vonoprazan, amoxicillin, and clarithromycin",
         "deutivacaftor, tezacaftor, vanzacaftor", "sulopenem etzadroxil and probenecid", "xanomeline and trospium chloride"}

recs = []
for b in blocks:
    first = b["rows"][0]
    e = b["entry"]
    is_combo = e in COMBO
    # candidates: the entry's own row, then continuation rows
    own = parse_hl(first[19])
    same_name = [parse_hl(r[19]) for r in b["rows"][1:] if norm(r[2]) == e and r[19] is not None]
    comps = [parse_hl(r[19]) for r in b["rows"][1:] if norm(r[2]) != e and r[19] is not None]
    if is_combo:
        comp_vals = [p["point"] for p in ([own] if own else []) + same_name + comps if p]
        hl_primary = None
        hl_lo = hl_hi = hl_note = None
        shortest = min(comp_vals) if comp_vals else None
        longest = max(comp_vals) if comp_vals else None
        hl_source = "combination"
    else:
        p = own or (same_name[0] if same_name else None)
        hl_source = "own row" if own else ("continuation row, same name" if same_name else "none")
        hl_primary = p["point"] if p else None
        hl_lo = p["lo"] if p else None
        hl_hi = p["hi"] if p else None
        hl_note = p["note"] if p else None
        shortest = longest = hl_primary
    sheet_freq_L = norm_freq(first[11])
    sheet_freq_W = norm_freq(first[22])
    recs.append(dict(
        name=e, approval_year_sheet1=first[1], disease=first[23], active_metabolite=(first[3] == "Y"), discontinued=(first[4] == "Y"),
        sheet1_orphan=(first[8] == "Y"), sheet1_fic_M=(first[12] == "Y"), sheet1_fic_N=(first[13] == "Y"),
        freq_sheet1_L=sheet_freq_L, freq_sheet1_W=sheet_freq_W, hl_raw_own=first[19],
        is_combination=is_combo, hl_h=hl_primary, hl_lo_h=hl_lo, hl_hi_h=hl_hi, hl_note=hl_note, hl_source=hl_source,
        hl_shortest_comp_h=shortest, hl_longest_comp_h=longest, n_hl_values=len(([own] if own else []) + same_name + comps),
        cl_f=first[20], hppb_raw=first[21],
    ))
s1 = pd.DataFrame(recs)
df = dc.merge(s1, on="name", how="left", validate="one_to_one")
print("merged rows:", len(df))
audit["merged_rows"] = len(df)

# ---- reconcile ----
mism_freq = df[(df.freq != df.freq_sheet1_L) | (df.freq != df.freq_sheet1_W)][["name", "freq_dc_raw", "freq", "freq_sheet1_L", "freq_sheet1_W"]]
print("frequency disagreements (Dose_and_Class vs Sheet1 L/W):", len(mism_freq))
print(mism_freq.to_string(index=False))
mism_freq.to_csv(OUT / "audit_frequency_disagreements.csv", index=False)
audit["frequency_disagreements"] = len(mism_freq)

mism_year = df[df.year != pd.to_numeric(df.approval_year_sheet1, errors="coerce")][["name", "year", "approval_year_sheet1"]]
print("approval-year disagreements:", len(mism_year))
audit["year_disagreements"] = len(mism_year)

df["fic"] = df.fic_dc
df["orphan"] = df.orphan_dc
fic_diff = df[(df.fic_dc != df.sheet1_fic_M) | (df.fic_dc != df.sheet1_fic_N)][["name", "fic_dc", "sheet1_fic_M", "sheet1_fic_N"]]
orph_diff = df[df.orphan_dc != df.sheet1_orphan][["name", "orphan_dc", "sheet1_orphan"]]
print("FIC disagreements (Dose_and_Class vs Sheet1 M, N):", len(fic_diff), "| orphan disagreements:", len(orph_diff))
fic_diff.to_csv(OUT / "audit_fic_disagreements.csv", index=False)
orph_diff.to_csv(OUT / "audit_orphan_disagreements.csv", index=False)
audit["fic_disagreements"] = len(fic_diff)
audit["orphan_disagreements"] = len(orph_diff)

# ---- outcome & covariates ----
df["multi_daily"] = df.freq.map({"QD": 0, "weekly": 0, "BID": 1, "TID": 1})  # ambiguous -> NaN
DIS = {"Oncology": "Oncology", "Nueroscience": "Neuroscience", "Metabolic": "Metabolic/Renal/CV", "Renal": "Metabolic/Renal/CV", "CV": "Metabolic/Renal/CV",
       "Infection": "Infection", "Autoimmune": "Autoimmune", "Gastroenterology": "Autoimmune"}
df["disease_group"] = df.disease.map(lambda d: DIS.get(d, "Other"))
df["oncology"] = (df.disease == "Oncology").astype(int)

print("frequency counts (all 104):", df.freq.value_counts().to_dict(), "->",
      {k: round(100 * v / 104, 1) for k, v in df.freq.value_counts().items()})
audit["frequency_counts_104"] = {k: int(v) for k, v in df.freq.value_counts().items()}
print("disease groups:", df.disease_group.value_counts().to_dict())
print("combination entries:", int(df.is_combination.sum()))
print("single-ingredient entries with a usable half-life:", int((~df.is_combination & df.hl_h.notna()).sum()),
      "| without:", df[(~df.is_combination) & df.hl_h.isna()].name.tolist())
audit["combination_entries"] = int(df.is_combination.sum())
audit["single_with_half_life"] = int((~df.is_combination & df.hl_h.notna()).sum())
audit["single_without_half_life"] = df[(~df.is_combination) & df.hl_h.isna()].name.tolist()

# half-life summary vs the paper (n=104, median 14.8, Q1 6, Q3 30.8, mean 30.5, SD 48.17)
vals = df.hl_h.dropna()
q1, med, q3 = np.percentile(vals, [25, 50, 75])
print(f"half-life (single entries, own value): n={len(vals)} median {med:.2f} h, Q1 {q1:.2f}, Q3 {q3:.2f}, mean {vals.mean():.1f}, SD {vals.std(ddof=1):.1f}")
alt = pd.concat([df.hl_h.where(~df.is_combination, df.hl_shortest_comp_h)]).dropna()
alt2 = df.hl_h.where(~df.is_combination, df.hl_longest_comp_h).dropna()
print(f"  with combinations at their shortest component: n={len(alt)} median {np.median(alt):.2f}; at longest: n={len(alt2)} median {np.median(alt2):.2f}")
audit["half_life_summary"] = dict(n=int(len(vals)), median=float(med), q1=float(q1), q3=float(q3), mean=float(vals.mean()), sd=float(vals.std(ddof=1)),
                                  n_alt_shortest=int(len(alt)), median_alt_shortest=float(np.median(alt)),
                                  n_alt_longest=int(len(alt2)), median_alt_longest=float(np.median(alt2)))

df.drop(columns=["name_raw", "dose_raw"], errors="ignore").to_csv(OUT / "dataset_tidy.csv", index=False)
(OUT / "audit_counts.json").write_text(json.dumps(audit, indent=2, ensure_ascii=False, default=str), encoding="utf-8")
print("wrote dataset_tidy.csv rows:", len(df))
