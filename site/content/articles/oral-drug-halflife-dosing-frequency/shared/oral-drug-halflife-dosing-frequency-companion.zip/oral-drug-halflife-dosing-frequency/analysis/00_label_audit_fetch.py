"""Label audit helper: read the current US label text of the ten pre-selected drugs from the
DailyMed web service (text is read into memory; nothing is saved) and print dosing-frequency and
half-life sentences.  The curated result is stored by hand in inputs/label_audit.csv.

Run: python -X utf8 analysis/00_label_audit_fetch.py
Network access required.  Not part of the offline re-run.
"""
import re
import subprocess
import sys

sys.stdout.reconfigure(encoding="utf-8")

SETIDS = {
    "selpercatinib": "7fa848ba-a59c-4144-9f52-64d090f4d828",
    "finerenone": "fc726765-5d5a-4d6e-b037-b847bda9fb7c",
    "avacopan": "c93cbc0b-29a3-46a5-9c85-41815ea5cf4a",
    "maralixibat": "64000394-1ef6-4e76-8ba8-11f25ba1b167",
    "futibatinib": "0b1332a1-0581-4707-9bf6-1eccfa39bef4",
    "olutasidenib": "4a0c7c8b-b95f-455d-9600-b7351e4397fe",
    "ganaxolone": "d91612c4-b03a-4be4-a1ee-6a13e3b83d4e",
    "daprodustat": "d82aa06e-5a33-4844-99b7-4701313455a4",
    "ritlecitinib": "1882f799-61b0-4813-965a-4910c4ae419c",
    "tovorafenib": "ea3a9631-3a66-6a7c-e053-2995a90ae2ad",
}
FREQ = re.compile(r"(once daily|twice daily|three times (a|per) day|once weekly|once a week|every 12 hours|every 8 hours|every 24 hours|orally once|orally twice|BID|QD)", re.I)
HALF = re.compile(r"half-?life", re.I)


def sentences(text):
    return [s.strip() for s in re.split(r"(?<=[.;])\s+", text) if s.strip()]


for name, sid in SETIDS.items():
    url = f"https://dailymed.nlm.nih.gov/dailymed/services/v2/spls/{sid}.xml"
    raw = subprocess.run(["curl", "-sS", "-m", "60", url], capture_output=True, text=True, encoding="utf-8").stdout
    text = re.sub(r"<[^>]+>", " ", raw)
    text = re.sub(r"\s+", " ", text)
    ss = sentences(text)
    print("=" * 8, name, sid, "chars", len(text))
    f = [s for s in ss if FREQ.search(s) and re.search(r"(recommended|dosage|dose)", s, re.I)]
    for s in f[:4]:
        print("  FREQ:", s[:230])
    h = [s for s in ss if HALF.search(s) and re.search(r"\d", s)]
    for s in h[:4]:
        print("  HALF:", s[:230])
