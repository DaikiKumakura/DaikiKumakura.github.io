# Half-life and once-daily dosing of approved oral small molecules (X26-06)

Working folder for the article `oral-drug-halflife-dosing-frequency` (ja/en). Source data: Brown DG, J Med Chem 2025;68(22):23751-23780, doi:10.1021/acs.jmedchem.5c02863, Supporting Information file `jm5c02863_si_002.xlsx` (not redistributed).

## Protocol (written 2026-11-14, after the workbook rows had been listed, before any model was fitted)

Written after the supplementary workbook (Sheet1, Dose_and_Class) had been listed row by row, and before any model was fitted or any half-life/frequency cross-tabulation or figure was produced. The cohort definition, the coding rules for ambiguous rows, the half-life bin edges, the thresholds and the label-audit drugs below were set from that listing (which included the half-life values), so they are not blind to the data. There is no timestamp, hash or commit for this record, so that it preceded the model fits cannot be verified from outside. Analyses added after the first results were seen: sensitivity analysis excluding drugs flagged as discontinued in the workbook; PPV and LR+ of the threshold rules; the check of the artefact in the leave-one-out base-rate Brier score; own-interval remaining fractions (Table 5).

### Question and use
- QOI: how much does the elimination half-life explain whether an approved small-molecule oral drug is dosed once daily or more often?
- COU: descriptive check, on the 104 oral small-molecule drugs approved by the FDA in 2020-2024, of how far half-life alone can serve as a rule of thumb for "once daily or not". Not a dosing recommendation, not a causal claim.

### Unit, outcome, coding
- Unit: one approved entry (Dose_and_Class rows 2-105 = 104 entries; a combination product is one entry).
- Outcome Y = 1 if the approved frequency is BID or TID; Y = 0 if once daily (QD, "QD (or less)", cyclic QD such as 21 on/7 off) or less frequent (tovorafenib, weekly).
- Ambiguous label "QD or BID" (maralixibat; Sheet1 says QD): excluded from the primary analysis; sensitivity with Y=0 and Y=1.
- Short courses (1-14 days) keep their frequency label and are flagged.
- Frequency source: Dose_and_Class column "Frequency"; Sheet1 columns L and W are audited against it.
- FIC / orphan: Dose_and_Class columns; Sheet1 FIC columns audited against them.

### Half-life
- Primary exposure: half-life of the parent drug (own row; if blank, the continuation row with the same drug name), in hours; days x 24; ranges -> geometric mean of the bounds (bounds kept for sensitivity); effective-, population-PK- and patient-group values are flagged, not removed.
- Combination entries (two or more active ingredients): excluded from the primary model; sensitivity with the shortest and with the longest component half-life.
- Entries without a usable numeric half-life are excluded from models and counted.
- Summary statistics are compared with the paper (n=104, median 14.8 h, quartiles 6 and 30.8 h).

### Models (logistic; Y = multi-daily)
- M0 base rate (training-fold proportion). M1: logit p = a + b log2(t1/2). M2: M1 + FIC + orphan + oncology indicator + active-metabolite indicator (no interactions, no further search).
- Pre-specified single-threshold rules: predict multi-daily if t1/2 < 6, 8 or 12 h (sensitivity, specificity, accuracy).
- Evaluation: leave-one-out (each entry is its own group) and leave-one-disease-group-out (Oncology, Neuroscience, Metabolic/Renal/CV, Infection, Autoimmune, Other). Brier score, log score, AUC, calibration intercept and slope from pooled out-of-sample predictions. Intervals: percentile bootstrap over entries (2,000 resamples, seed 20261114) on the fixed out-of-sample predictions (models are not refitted inside the bootstrap; an approximation). No p-values as primary evidence.
- Half-life bins fixed in advance: <3, 3-6, 6-12, 12-24, 24-48, >=48 h; Wilson 95% intervals.
- Reference curve: fraction of a dose's peak remaining at 24 h under mono-exponential elimination, 2^(-24/t1/2); drawn next to the observed proportions, not fitted.

### Case review
Short half-life (< 6 h) once-daily entries and long half-life (>= 24 h) multi-daily entries are listed. For each case only what the label says about the regimen is recorded; otherwise "not stated".

### Label audit (chosen after listing the rows, before modelling)
Ten entries spanning years and atypical cases (8 of the 10 are among the 22 drugs of the case map, so the sample is not representative): selpercatinib (2020), finerenone (2021), avacopan (2021), maralixibat (2021), futibatinib (2022), olutasidenib (2022), ganaxolone (2022), daprodustat (2023), ritlecitinib (2023), tovorafenib (2024). Compared with the current US label (DailyMed web page) for approved frequency and half-life. Agreement is reported; disagreements are listed, not silently corrected.

### Out of scope
Dose-regimen recommendations, per-indication dose choice, inference about why a sponsor chose a regimen, the paper's other tables (protein binding, drug-drug interactions, boxed warnings).

## Layout
- `inputs/raw/` the publisher workbook (not redistributed; SHA256 in `inputs/PROVENANCE.md`)
- `analysis/` numbered scripts (`python -X utf8 analysis/NN_*.py [path-to-xlsx]`)
- `outputs/{tables,figures,logs}`
- `article/{ja,en}.md`
- `records/` non-public notes

## Added after the first results
- `analysis/05_manifest.py` writes `outputs/MANIFEST_SHA256.txt` (SHA256 of every table in `outputs/tables`); `--check` compares a re-run with it.
- `analysis/02_models.py` also writes PPV / LR+ of the threshold rules, the own-interval remaining fraction, the sensitivity analysis without drugs flagged as discontinued, and the in-sample base-rate Brier score.
