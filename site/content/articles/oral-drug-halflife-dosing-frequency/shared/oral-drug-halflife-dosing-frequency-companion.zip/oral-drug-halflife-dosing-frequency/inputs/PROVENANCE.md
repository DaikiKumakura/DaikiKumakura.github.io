# Provenance of inputs

## Publisher workbook (not redistributed)

- Brown DG. What do oral drugs really look like? Dose regimen, pharmacokinetics, and safety of recently approved small-molecule oral drugs. J Med Chem. 2025;68(22):23751-23780. doi:10.1021/acs.jmedchem.5c02863 (PMC12670434).
- File: `jm5c02863_si_002.xlsx` ("Data_files" in Supporting Information; 62,715 bytes; SHA256 `796452e02efe3edd647375d15d5b1911682ef44d2709499f8846387fdf950213`). Sheets: `Sheet1` (164 x 81; one block of rows per approved entry, with metabolite/component rows underneath) and `Dose_and_Class` (128 x 11; one row per approved entry in rows 2-105).
- How to obtain: open the article page (https://doi.org/10.1021/acs.jmedchem.5c02863), Supporting Information, file `jm5c02863_si_002.xlsx`; or the Supplementary Materials of PMC12670434. Both sites were not reachable by script (publisher returned 403; PMC asks a browser proof-of-work check before download), so the file was saved by hand in a browser on 2026-11-14. The file is the publisher's copyrighted material and is not included in the companion archive. Put it at `inputs/raw/jm5c02863_si_002.xlsx` (or pass its path as the first argument of `analysis/01_build_dataset.py`); the script stops if the SHA256 differs.
- The main text of the article was read through the PMC page (text only; Table 1 is an image and was not read as an image).

## Label audit (hand-checked)

- `label_audit.csv`: ten entries chosen before modelling. Each row is read from the current US prescribing information as served by the DailyMed web service (https://dailymed.nlm.nih.gov/dailymed/services/v2/spls/<setid>.xml, read into memory on 2026-11-14; no file saved). `spl_published` is the version date reported by the DailyMed lookup service. The wording of frequency and half-life sentences is paraphrased in short form; the full text is at the DailyMed page of the set ID.
- Helper used for the read-out: `analysis/00_label_audit_fetch.py` (network needed; not part of the offline re-run).

## Derived tables

All files under `outputs/tables/` are produced by `analysis/01..04`. `dataset_tidy.csv`, `primary_set.csv`, `oos_predictions.csv` and the case tables contain per-drug values taken from the publisher workbook; they are kept in the working folder and are not part of the companion archive. Aggregated tables are.

## Known data issues (kept as found, not corrected)

- Entries per approval year in the workbook: 22, 24, 13, 24, 21 (2020-2024). The main text of the article gives 22, 24, 12, 25, 21. The cause was not traced.
- Frequency labels in `Sheet1` (two columns) and `Dose_and_Class` differ for one entry (maralixibat: "QD" against "QD or BID").
- First-in-class flags: `Dose_and_Class` and the second FIC column of `Sheet1` differ for six entries (the second column is blank for them); `Dose_and_Class` is used. Orphan flags agree.
- Half-life cells are text in mixed forms (ranges, patient-group values, days, mean +- SD text); the parsing rules and the 94 distinct strings are in `analysis/01_build_dataset.py` and `outputs/tables/audit_half_life_parsing.csv`.
- The workbook has no half-life for maralixibat; the current label gives 1.6 h (healthy adults, 30 mg oral solution). It is used only in a sensitivity analysis.
- The workbook flags 6 of the 104 entries as discontinued (4 in the primary set: daprodustat, gepirone, infigratinib, umbralisib). They are kept in the primary analysis; a sensitivity analysis removes them.
- Disease group "Autoimmune" in the scripts includes the workbook's "Gastroenterology" entries (named immunology/gastroenterology in the article).
- The label-audit entries were chosen after the workbook rows had been listed; 8 of the 10 are among the 22 discordant drugs of the case map, so the audit is not a representative sample.
