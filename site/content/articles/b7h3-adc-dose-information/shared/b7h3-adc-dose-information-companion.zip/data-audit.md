# M02-1: evidence and data audit

Checked 2026-10-04. Classification G/S: published aggregate observations plus explicitly hypothetical trials; no individual participant or exposure data.

## Primary sources and cohort separation

1. Rudin et al., JCO primary report, DOI [10.1200/JCO-25-02142](https://doi.org/10.1200/JCO-25-02142), open-access full text PMC12834294 and supplementary appendix s002, acquired from Europe PMC; source bytes and hashes in `sources/manifest.json`.
2. Public primary release of the WCLC2024 Part 1 interim results, dated 2024-09-07, [public interim evidence](https://www.merck.com/news/ifinatamab-deruxtecan-continues-to-demonstrate-promising-objective-response-rates-in-patients-with-extensive-stage-small-cell-lung-cancer-in-ideate-lung01-phase-2-trial/). Acquired HTML bytes, snapshot 2024-04-25. This is a public sponsor report, not a substitute for participant data or an independently adjudicated trial database. The abstract DOI is [10.1016/j.jtho.2024.09.033](https://doi.org/10.1016/j.jtho.2024.09.033), but publisher full abstract access failed; do not claim it was downloaded. Original WCLC presentation PDF downloads returned 403, not used as extracted numerical evidence.

46 participants at 8 mg/kg and 42 at 12 mg/kg received at least one dose in randomized Part 1. The 95-person nonrandomized Part 2 is excluded; pooled 137-person high-dose safety is unsuitable as the high arm of the randomized comparison. Randomization was stratified, but public margins cannot recover strata or adjust them. A treated-randomized analysis is not automatically a full randomized-ITT analysis.

## Endpoints, timing, and integer recovery

Primary snapshot 2024-04-25. Confirmed BICR ORR: 12/46 vs 23/42; all-cause Grade >=3 TEAE: 20/46 vs 21/42; AE-associated discontinuation: 3/46 vs 7/42; adjudicated treatment-related ILD: 4/46 vs 5/42. Safety counts from rounded percentages are uniquely recoverable at these denominators and flagged as reconstructed. The ILD totals are explicit. They are participants with >=1 endpoint, not independent event totals.

ORR's same integer total is corroborated in the later Table 2, although CR/PR classification changed at 8 mg/kg (interim 1+11, later 2+10). Later counts are not new independent observations. Unlisted BOR residuals of 4 and 2 are not assigned a new biological outcome; only the hypothetical recoding sensitivity changes them. Later Table 2 explicitly reports not-evaluable 4/2; their interim status is not established patient-by-patient.

| Snapshot | Follow-up, low/high randomized (months) | Treatment duration, low/high (months) | Use |
| --- | --- | --- | --- |
| 2024-04-25 | 14.6 / 15.3 | 3.5 / 4.7 | Primary matched snapshot |
| 2025-03-03 | 24.6 / 26.4 | 4.1 / 5.4 | Follow-up audit only |

Both arms share a cutoff, not equal time at risk. Later supplementary Table S4 (PDF page 6) has 21 severe all-cause TEAE participants at 8 mg/kg, one more than interim. Later high-dose safety Table 5 pools 42+95; cannot estimate the corresponding late randomized high-dose change or time-standardized harm from medians. Do not divide event proportions by median follow-up or treatment time. Supplementary Table S2 (page 3) separates survival cohorts but provides no randomized comparative HR; median differences cannot supply one.

Fatal/nonfatal ILD must not be interpreted as equivalent harm: interim low dose includes one grade 5 event, high dose one grade 3 event. The all-grade ILD scalar is a sensitivity only; neither its count nor sample size qualifies a fatal-harm trade-off.

## Missing information

Response/AE joint tables, event dates, exposure, longitudinal risk sets, stratified counts, discontinuation mechanisms, patient utilities and future target population size are unavailable. Independent marginal posteriors and exchangeable future event rates are assumptions. Joint-table extrema and unobserved late-harm penalties are stress tests, not fitted estimates.

## Access and redistribution

The primary JCO XML states CC BY-NC-ND 4.0; public accessibility does not grant unrestricted commercial reuse or altered publisher illustrations. Keep PDFs, HTML, XML, presentation images and their extraction text local. Release only a small fact/provenance table, original analysis/code/figures and links. Do not reproduce original figures, full tables or article prose. Primary data files require a request-based route, not acquired or implied open IPD here. Any license assigned to original code or original figures does not relicense source documents. Source documents and private context are excluded by a release whitelist.
