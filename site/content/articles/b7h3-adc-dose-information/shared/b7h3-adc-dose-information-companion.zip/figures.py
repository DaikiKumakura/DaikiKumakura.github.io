from pathlib import Path
import csv,json
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.ticker import PercentFormatter

ROOT=Path(__file__).resolve().parent
BLUE='#245B83'; GOLD='#A67720'; INK='#263238'; GRAY='#68747D'
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':11,'axes.spines.top':False,'axes.spines.right':False,'axes.labelcolor':INK,'text.color':INK,'axes.edgecolor':GRAY,'savefig.facecolor':'white','figure.facecolor':'white'})
def read(name):
    with (ROOT/'results'/name).open() as f:return list(csv.DictReader(f))
def save(fig,name):
    (ROOT/'figures').mkdir(exist_ok=True)
    for suffix in ['png','svg']:fig.savefig(ROOT/'figures'/f'{name}.{suffix}',dpi=180,bbox_inches='tight')
    plt.close(fig)
def evidence():
    data=read('endpoint-posteriors.csv');fig,axes=plt.subplots(1,2,figsize=(10,4.1),layout='constrained')
    fig.suptitle('Randomized dose cohorts: marginal endpoint evidence',fontsize=15)
    for ax,endpoint,title in zip(axes,['response','grade3_teae'],['Confirmed BICR response','All-cause Grade >=3 TEAE']):
        for y,dose in enumerate([8,12]):
            row=next(r for r in data if r['endpoint']==endpoint and int(r['dose'])==dose)
            mu=float(row['posterior_mean']);lo=float(row['ci_low']);hi=float(row['ci_high'])
            ax.errorbar(mu,y,xerr=[[mu-lo],[hi-mu]],fmt='o' if dose==8 else 's',color=BLUE,mfc='white' if dose==8 else BLUE,capsize=4,markersize=8)
        ax.set(yticks=[0,1],yticklabels=['8 mg/kg (n=46)','12 mg/kg (n=42)'],xlim=(0,1),ylim=(-.6,1.6),xlabel='Endpoint probability',title=title)
        ax.xaxis.set_major_formatter(PercentFormatter(1));ax.grid(axis='x',alpha=.15)
    fig.supxlabel('Part 1, cutoff 25 Apr 2024 | Beta(1,1) prior; posterior means and 95% credible intervals',fontsize=10)
    save(fig,'endpoint-evidence')
def tradeoff():
    rows=read('decision-curve.csv'); w=np.array([float(r['weight']) for r in rows]); p=np.array([float(r['p_high_better']) for r in rows]); mean=np.array([float(r['mean_delta']) for r in rows]);lo=np.array([float(r['ci_low']) for r in rows]);hi=np.array([float(r['ci_high']) for r in rows])
    fig,axes=plt.subplots(2,1,figsize=(9,7),sharex=True,layout='constrained')
    fig.suptitle('Response–harm trade-off',fontsize=15)
    axes[0].plot(w,p,color=BLUE,lw=2);axes[0].axhline(.8,color=GRAY,ls='--',lw=1);axes[0].axhline(.2,color=GRAY,ls='--',lw=1);axes[0].set(ylabel='P(utility12 > utility8)',ylim=(0,1),title='Certainty about superiority; 0.80 / 0.20 are descriptive thresholds')
    axes[1].fill_between(w,lo,hi,color=BLUE,alpha=.13,label='95% credible interval');axes[1].plot(w,mean,color=BLUE,lw=2,label='Posterior mean');axes[1].axhline(0,color=INK,lw=1);axes[1].legend(frameon=False,loc='lower left');axes[1].set(ylabel='Utility12 − utility8',xlabel='w: response-equivalent penalty per severe TEAE participant',title='A positive expected utility does not imply a well-resolved choice')
    for ax in axes:ax.set_xlim(0,6);ax.grid(alpha=.12)
    fig.supxlabel('Independent marginal model | U = p(response) − w × p(severe TEAE)',fontsize=10)
    save(fig,'tradeoff-uncertainty')
def information():
    rows=read('information-value.csv');fig,axes=plt.subplots(1,3,figsize=(11,4.4),layout='constrained')
    fig.suptitle('Value of an additional randomized comparison',fontsize=15)
    for ax,w in zip(axes,[1,2,4]):
        data=[r for r in rows if float(r['weight'])==w];n=[int(r['extra_per_arm']) for r in data];evsi=[100*float(r['evsi_exact']) for r in data];evpi=100*float(data[0]['evpi_mc'])
        ax.plot(n,evsi,'o-',color=BLUE,lw=2,label='EVSI (exact)');ax.axhline(evpi,color=INK,ls='--',lw=1.4,label='EVPI (MC)');ax.set(title=f'w = {w}',xlabel='Additional participants / arm',ylim=(0,evpi*1.13));ax.grid(alpha=.15)
    axes[0].set_ylabel('Response-equivalent benefit / 100 future subjects');axes[1].legend(loc='lower right',frameon=False,fontsize=9)
    fig.supxlabel('Separate y-scales | Fixed hypothetical utility; no trial cost, delay or survival benefit included',fontsize=10)
    save(fig,'information-value')
def assumptions():
    joint=read('joint-sensitivity.csv');sens=read('sensitivity.csv');fig,axes=plt.subplots(1,2,figsize=(11,5),layout='constrained')
    fig.suptitle('Information value depends on unobserved assumptions',fontsize=15)
    labels=['Minimum overlap','Independence-nearest','Maximum overlap'];modes=['minimum_overlap','independence_nearest','maximum_overlap']
    for y,mode in enumerate(modes):
        r=next(r for r in joint if r['joint_assumption']==mode and int(r['extra_per_arm'])==50 and float(r['weight'])==2)
        axes[0].errorbar(100*float(r['evsi_mc']),y,xerr=100*1.96*float(r['evsi_mcse']),fmt='o',color=BLUE,capsize=4)
    axes[0].set(yticks=range(3),yticklabels=labels,xlim=(0,3.2),title='Reconstructed joint response / harm tables',xlabel='EVSI / 100 future subjects');axes[0].grid(axis='x',alpha=.15)
    scenarios=['primary','late_harm_5pt','late_harm_10pt'];labels=['No extra late-harm penalty','Hypothetical +5 percentage points','Hypothetical +10 percentage points']
    vals=[100*float(next(r for r in sens if r['scenario']==s and float(r['weight'])==2)['evsi_n50']) for s in scenarios]
    axes[1].barh(range(3),vals,color=BLUE,height=.5);axes[1].set(yticks=range(3),yticklabels=labels,xlim=(0,5.4),title='Fixed unobserved high-dose late-harm penalty',xlabel='EVSI / 100 future subjects');axes[1].grid(axis='x',alpha=.15)
    for y,v in enumerate(vals):axes[1].text(v+.08,y,f'{v:.2f}',va='center',fontsize=10)
    for ax in axes:ax.invert_yaxis()
    fig.supxlabel('w = 2; +50 / arm | Left: 95% Monte Carlo error bars, not uncertainty intervals; right: exact conditional EVSI',fontsize=9)
    save(fig,'assumption-sensitivity')
if __name__=='__main__':
    evidence();tradeoff();information();assumptions();print('Four original figures saved as PNG and SVG.')
