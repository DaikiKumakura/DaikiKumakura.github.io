from pathlib import Path
from html.parser import HTMLParser
import xml.etree.ElementTree as ET
import csv,json,hashlib,re

ROOT=Path(__file__).resolve().parent
class Text(HTMLParser):
    def __init__(self): super().__init__(); self.parts=[]
    def handle_data(self,text): self.parts.append(text)
def unique_count(percent,n):
    candidates=[k for k in range(n+1) if abs(100*k/n-percent)<.05000001]
    assert len(candidates)==1,(percent,n,candidates)
    return candidates[0]
def audit():
    parser=Text(); parser.feed((ROOT/'sources/interim-release.html').read_text(encoding='utf-8'))
    text=' '.join(' '.join(parser.parts).split())
    for phrase in ['50.0% and 43.5%','16.7% and 6.5%','Five (11.9%) and four (8.7%)','April 25, 2024','15.3 months','14.6 months','Twenty-three partial responses','One complete response (CR) and eleven PRs']:
        assert phrase in text,phrase
    xml=ET.parse(ROOT/'sources/primary.xml'); t=xml.find(".//table-wrap[@id='tbl2']")
    rows=[[''.join(c.itertext()).strip() for c in row] for row in t.findall('.//tr')]
    cr=next(r for r in rows if r[0]=='CR'); pr=next(r for r in rows if r[0]=='PR')
    assert int(cr[1].split()[0])+int(pr[1].split()[0])==12
    assert int(cr[2].split()[0])+int(pr[2].split()[0])==23
    assert int(cr[3].split()[0])+int(pr[3].split()[0])==43
    assert int(cr[4].split()[0])+int(pr[4].split()[0])==66
    data=[]
    specs=[('response',26.1,54.8,'BICR confirmed ORR','explicit response totals; checked against Table 2'),('grade3_teae',43.5,50.,'all-cause Grade >=3 TEAE','unique count reconstructed from rounded percentage'),('ae_discontinuation',6.5,16.7,'AE-associated discontinuation','unique count reconstructed from rounded percentage'),('adjudicated_ild',8.7,11.9,'adjudicated treatment-related ILD','explicit count; percentage checked')]
    for endpoint,low,high,definition,provenance in specs:
        for dose,n,percent in [(8,46,low),(12,42,high)]:
            data.append(dict(endpoint=endpoint,dose_mg_kg=dose,n=n,events=unique_count(percent,n),reported_percent=percent,cutoff='2024-04-25',population='Part 1 treated randomized',definition=definition,source='interim-release.html',locator='response table or safety paragraph',provenance=provenance))
    (ROOT/'data').mkdir(exist_ok=True)
    with (ROOT/'data/aggregate-counts.csv').open('w',newline='',encoding='utf-8') as f:
        writer=csv.DictWriter(f,fieldnames=list(data[0])); writer.writeheader(); writer.writerows(data)
    result={'randomized_treated_n':88,'extension_n_excluded':95,'primary_cutoff':'2024-04-25','later_cutoff':'2025-03-03','interim_followup_months':{'8':14.6,'12':15.3},'interim_treatment_months':{'8':3.5,'12':4.7},'later_followup_months':{'8':24.6,'12_part1':26.4,'12_part2':12.2},'later_low_grade3_teae_count':21,'later_high_safety_n':137,'sources_verified':[]}
    for item in json.loads((ROOT/'sources/manifest.json').read_text()):
        assert hashlib.sha256((ROOT/'sources'/item['file']).read_bytes()).hexdigest()==item['sha256']
        result['sources_verified'].append(item['file'])
    (ROOT/'results').mkdir(exist_ok=True)
    (ROOT/'results/audit.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result,indent=2))
    return data
if __name__=='__main__': audit()
