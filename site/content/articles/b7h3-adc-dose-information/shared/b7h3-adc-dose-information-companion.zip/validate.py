from pathlib import Path
import csv,json,unittest,re,hashlib
import test_analysis

ROOT=Path(__file__).resolve().parent
def validate():
    suite=unittest.defaultTestLoader.loadTestsFromTestCase(test_analysis.Verification)
    result=unittest.TextTestRunner(verbosity=1).run(suite)
    assert result.wasSuccessful()
    rows=list(csv.DictReader((ROOT/'data/aggregate-counts.csv').open(encoding='utf-8')))
    assert len(rows)==8 and set(r['cutoff'] for r in rows)=={'2024-04-25'}
    assert all(r['population']=='Part 1 treated randomized' for r in rows)
    values={(r['endpoint'],int(r['dose_mg_kg'])):(int(r['events']),int(r['n'])) for r in rows}
    for key,expected in {('response',8):(12,46),('response',12):(23,42),('grade3_teae',8):(20,46),('grade3_teae',12):(21,42)}.items(): assert values[key]==expected
    assert abs(23/42-12/46-.2867494824016563)<1e-12
    assert abs(21/42-20/46-.06521739130434784)<1e-12
    source_checks=[]
    if (ROOT/'sources/manifest.json').exists():
        from pypdf import PdfReader
        text=PdfReader(ROOT/'sources/supplement.pdf').pages[5].extract_text()
        assert '21 (45.7)' in text and '6 (13.0)' in text
        for entry in json.loads((ROOT/'sources/manifest.json').read_text()):
            assert hashlib.sha256((ROOT/'sources'/entry['file']).read_bytes()).hexdigest()==entry['sha256']
            source_checks.append(entry['file'])
    article=(ROOT/'article.md').read_text(encoding='utf-8')
    figures=re.findall(r'!\[[^\]]+\]\((figures/[^)]+)\)',article)
    assert len(figures)==4 and all((ROOT/p).is_file() for p in figures)
    exact=list(csv.DictReader((ROOT/'results/information-value.csv').open()))
    for w,expected in [(1,.00074341099033),(2,.01618340573768),(4,.11020926299060)]:
        row=next(r for r in exact if int(r['extra_per_arm'])==50 and float(r['weight'])==w)
        assert abs(float(row['evsi_exact'])-expected)<1e-10
    assert '| 0 | 0.010 | <0.001 | 0.001 |' in article
    joint=list(csv.DictReader((ROOT/'results/joint-sensitivity.csv').open()))
    for row in joint:
        assert float(row['evsi_mc'])>=0
        assert float(row['evsi_mc'])<=float(row['evpi_mc'])+6*float(row['evsi_mcse'])+.0003
    report={'status':'pass','tests':result.testsRun,'source_hashes_and_pdf_columns':source_checks or 'Source re-audit requires acquire.py + pypdf; aggregate numerical checks passed','counts':'independently checked','exact_evsi':'enumeration and martingale verified','evpi':'independent quadrature checked','simulation':'MC error checked','joint_tables':'feasible assumed tables, not observed IPD','article_numeric_spot_checks':'pass','figure_links':'pass','private_content':'excluded'}
    (ROOT/'results/validation.json').write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps(report,indent=2))
    return report
if __name__=='__main__':validate()
