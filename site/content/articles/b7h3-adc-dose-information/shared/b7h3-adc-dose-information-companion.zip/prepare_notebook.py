from pathlib import Path
import os,sys,json,tempfile
import nbformat
from nbclient import NotebookClient
from jupyter_client.kernelspec import KernelSpecManager

ROOT=Path(__file__).resolve().parent
nb=nbformat.v4.new_notebook(cells=[
 nbformat.v4.new_markdown_cell('# Additional dose-comparison information value\n\n## tl;dr\nAt +50 participants/arm, conditional EVSI per 100 future subjects is 0.074, 1.618 and 11.021 at hypothetical severe-harm weights 1, 2 and 4. Unknown response/harm overlap changes the result. This does not establish an optimal trial, financial return or clinical dose.'),
 nbformat.v4.new_markdown_cell('## Context & Methods\nQOI: when could more randomized binary endpoint evidence improve a response–harm judgment? COU: research prioritization from aggregate evidence. Read article.md for definitions, timing and limitations.\n\n### Key assumptions\nOnly 46 low-dose and 42 high-dose treated randomized participants at cutoff 2024-04-25 are used. No 95-person extension pooling. Primary model: independent Beta(1,1)-binomial margins and exchangeable future observations. Utility U=p(response)-w*p(severe TEAE) is hypothetical. Exact beta-binomial EVSI is checked by enumeration, quadrature and simulated trial regret. Joint-table and late-harm assumptions are sensitivities, not estimates.'),
 nbformat.v4.new_markdown_cell('## Data\nThe small aggregate table is supplied with endpoint definitions, source locations and reconstruction flags. Publisher documents and private participant data are not displayed or redistributed.'),
 nbformat.v4.new_code_cell("from pathlib import Path\nimport csv,json,sys,subprocess\nR=Path.cwd()\nwith (R/'data/aggregate-counts.csv').open(encoding='utf-8') as f:\n rows=list(csv.DictReader(f))\nfor row in rows:\n print(row['endpoint'],row['dose_mg_kg'],row['events']+'/'+row['n'],row['cutoff'],row['provenance'])"),
 nbformat.v4.new_markdown_cell('## Results\nRecompute the complete primary design curve and planned sensitivities. Random seeds and Monte Carlo sizes are fixed.'),
 nbformat.v4.new_code_cell("result=subprocess.run([sys.executable,'analysis.py'],capture_output=True,text=True,encoding='utf-8',check=True)\nprint(result.stdout)\nwith (R/'results/information-value.csv').open() as f:\n for row in csv.DictReader(f):\n  if float(row['weight']) in [1,2,4] and int(row['extra_per_arm']) in [50,100]:\n   print(row)"),
 nbformat.v4.new_markdown_cell('### Independent verification\nFull source-byte/PDF-column checks run if source documents are available locally. Release users can verify every numerical check from the aggregate table without those documents.'),
 nbformat.v4.new_code_cell("result=subprocess.run([sys.executable,'validate.py'],capture_output=True,text=True,encoding='utf-8',check=True)\nprint(result.stdout)\nprint(result.stderr)"),
 nbformat.v4.new_markdown_cell('### Original figures\nEVSI/EVPI figures use response-equivalent units per future decision subject. Error bars for joint assumptions are Monte Carlo precision only.'),
 nbformat.v4.new_code_cell("result=subprocess.run([sys.executable,'figures.py'],capture_output=True,text=True,encoding='utf-8',check=True)\nprint(result.stdout)\nfrom IPython.display import display,Image\nfor name in ['endpoint-evidence','tradeoff-uncertainty','information-value','assumption-sensitivity']:\n display(Image(filename=str(R/'figures'/f'{name}.png')))"),
 nbformat.v4.new_markdown_cell('## Takeaways\nMore evidence is valuable when it can change a consequential decision under an explicit criterion. Sample size cannot resolve missing utility preferences or qualify late-event/survival effects. At weight two and +50/arm, compatible unknown joint tables give EVSI about 0.32–2.77 per 100 future subjects. These are assumption-indexed calculations, not a statistical interval for the true table. See article.md and README.md for full limits and reproduction.')])
nb.metadata['kernelspec']={'name':'python3','display_name':'Python 3','language':'python'}
with tempfile.TemporaryDirectory() as tmp:
    path=Path(tmp)/'kernels/python3';path.mkdir(parents=True)
    (path/'kernel.json').write_text(json.dumps({'argv':[sys.executable,'-m','ipykernel_launcher','-f','{connection_file}'],'display_name':'Python 3','language':'python','env':{'PYTHONPATH':os.environ.get('PYTHONPATH',''),'PYTHONIOENCODING':'utf-8'}}))
    NotebookClient(nb,timeout=240,kernel_name='python3',resources={'metadata':{'path':str(ROOT)}},kernel_spec_manager=KernelSpecManager(kernel_dirs=[str(Path(tmp)/'kernels')])).execute()
nbformat.validate(nb);nbformat.write(nb,ROOT/'analysis.ipynb')
print('Notebook executed: four code cells, no errors.')
