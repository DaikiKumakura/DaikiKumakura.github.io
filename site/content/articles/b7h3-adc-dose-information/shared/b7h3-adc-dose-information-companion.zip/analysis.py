"""Conjugate marginal evidence, exact EVSI, and hypothetical paired trials."""
from pathlib import Path
import csv,json,platform,sys
import numpy as np
from scipy.stats import beta,betabinom

ROOT=Path(__file__).resolve().parent
SEED=20261004
WEIGHTS=np.round(np.arange(0,6.01,.1),2)
SIZES=[0,10,25,50,100,200]
def parameters(harm='grade3_teae',prior=1.,response_override=None):
    with (ROOT/'data/aggregate-counts.csv').open(encoding='utf-8') as f: rows=list(csv.DictReader(f))
    selected=[]
    for endpoint in ['response',harm]:
        for dose in [8,12]:
            row=next(r for r in rows if r['endpoint']==endpoint and int(r['dose_mg_kg'])==dose)
            k=int(row['events']); n=int(row['n'])
            if endpoint=='response' and response_override is not None: k=response_override[dose]
            selected.append([k+prior,n-k+prior])
    return np.asarray(selected,float)
def utility(draws,w,penalty=0.):
    return draws[:,1]-draws[:,0]-w*(draws[:,3]-draws[:,2]+penalty)
def current_mean(ab,w,penalty=0.):
    mean=ab[:,0]/ab.sum(axis=1)
    return mean[1]-mean[0]-w*(mean[3]-mean[2]+penalty)
def draw_posterior(ab,size=200000,seed=SEED):
    rng=np.random.default_rng(seed)
    return rng.beta(ab[:,0],ab[:,1],size=(size,4))
def difference_distribution(ab,n):
    # Four endpoint count streams have exact beta-binomial predictive laws.
    x=np.arange(n+1)
    mass=[betabinom.pmf(x,n,a,b) for a,b in ab]
    means=[(a+x)/(a+b+n) for a,b in ab]
    def diff(low,high):
        values=(means[high][:,None]-means[low][None,:]).ravel()
        probs=(mass[high][:,None]*mass[low][None,:]).ravel()
        assert abs(probs.sum()-1)<1e-9
        order=np.argsort(values)
        return values[order],probs[order]
    return diff(0,1),diff(2,3)
def positive_sum(a,pa,b,pb):
    """E max(0,a+b) using sorted discrete b, including exact ties."""
    order=np.argsort(b); b=b[order]; pb=pb[order]
    prob=np.r_[0.,np.cumsum(pb)]; first=np.r_[0.,np.cumsum(pb*b)]
    pos=np.searchsorted(b,-a,side='right')
    return float(np.sum(pa*(a*(prob[-1]-prob[pos])+first[-1]-first[pos])))
def exact_evsi(ab,n,w,penalty=0.,distributions=None):
    if n==0: return 0.
    (r,pr),(t,pt)=distributions or difference_distribution(ab,n)
    if current_mean(ab,w,penalty)>0:
        value=positive_sum(-r+w*penalty,pr,w*t,pt)
    else:
        value=positive_sum(r-w*penalty,pr,-w*t,pt)
    assert value>-1e-10
    return max(0.,value)
def summarize_posterior(ab,weights=WEIGHTS,penalty=0.):
    draws=draw_posterior(ab); rows=[]
    for w in weights:
        delta=utility(draws,w,penalty); mean=current_mean(ab,w,penalty)
        positive=np.maximum(delta,0)
        loss=np.maximum(-delta,0) if mean>0 else positive
        evpi=float(loss.mean())
        probability=float(np.mean(delta>0))
        rows.append(dict(weight=float(w),mean_delta=mean,ci_low=float(np.quantile(delta,.025)),ci_high=float(np.quantile(delta,.975)),p_high_better=probability,expected_utility_choice='12' if mean>0 else '8',certainty80='12' if probability>=.8 else ('8' if probability<=.2 else 'uncertain'),certainty90='12' if probability>=.9 else ('8' if probability<=.1 else 'uncertain'),evpi_mc=evpi,evpi_mcse=float(loss.std(ddof=1)/np.sqrt(len(delta)))))
    return rows
def simulate_design(ab,n,weights=(0,1,2,4),size=60000,seed=SEED):
    rng=np.random.default_rng(seed); theta=rng.beta(ab[:,0],ab[:,1],size=(size,4))
    x=rng.binomial(n,theta)
    updated=(ab[:,0]+x)/(ab.sum(axis=1)+n)
    rows=[]
    for w in weights:
        truth=utility(theta,w); estimate=utility(updated,w); mean=current_mean(ab,w)
        choose=estimate>0
        regret=np.where(choose,np.maximum(-truth,0),np.maximum(truth,0))
        current_loss=np.maximum(-truth,0) if mean>0 else np.maximum(truth,0)
        evsi_sample=current_loss-regret
        improvement=np.maximum(-estimate,0) if mean>0 else np.maximum(estimate,0)
        rows.append(dict(extra_per_arm=n,weight=w,p_choose_high=float(choose.mean()),oracle_discordance=float(np.mean(choose!=(truth>0))),expected_regret=float(regret.mean()),regret_mcse=float(regret.std(ddof=1)/np.sqrt(size)),evsi_regret_reduction_mc=float(evsi_sample.mean()),evsi_regret_mcse=float(evsi_sample.std(ddof=1)/np.sqrt(size)),evsi_preposterior_mc=float(improvement.mean()),evsi_preposterior_mcse=float(improvement.std(ddof=1)/np.sqrt(size)),trials=size))
    return rows
def joint_sensitivity(size=60000):
    # Counts are reconstructed joint tables, NOT observed individual records.
    out=[]; narm=[46,42]; responses=[12,23]; harms=[20,21]
    for mode in ['minimum_overlap','independence_nearest','maximum_overlap']:
        alphas=[]; overlaps=[]
        for n,r,t in zip(narm,responses,harms):
            both=max(0,r+t-n) if mode=='minimum_overlap' else (min(r,t) if mode=='maximum_overlap' else round(r*t/n))
            overlaps.append(both); alphas.append(np.array([n-r-t+both,r-both,t-both,both],float)+.5)
        rng=np.random.default_rng(SEED+{'minimum_overlap':10,'independence_nearest':20,'maximum_overlap':30}[mode])
        probs=[rng.dirichlet(a,size=size) for a in alphas]
        theta=np.column_stack([probs[0][:,1]+probs[0][:,3],probs[1][:,1]+probs[1][:,3],probs[0][:,2]+probs[0][:,3],probs[1][:,2]+probs[1][:,3]])
        ab=parameters()
        for n in [0,25,50,100]:
            counts=[rng.multinomial(n,p) for p in probs]
            post=[(a+x)/(a.sum()+n) for a,x in zip(alphas,counts)]
            estimate=np.column_stack([post[0][:,1]+post[0][:,3],post[1][:,1]+post[1][:,3],post[0][:,2]+post[0][:,3],post[1][:,2]+post[1][:,3]])
            for w in [0,1,2,4]:
                delta=utility(theta,w); mu=current_mean(ab,w); evpi_sample=np.maximum(-delta,0) if mu>0 else np.maximum(delta,0)
                post_delta=utility(estimate,w)
                inc=np.maximum(-post_delta,0) if mu>0 else np.maximum(post_delta,0)
                choose=utility(estimate,w)>0
                regret=np.where(choose,np.maximum(-delta,0),np.maximum(delta,0))
                out.append(dict(joint_assumption=mode,overlap8=overlaps[0],overlap12=overlaps[1],extra_per_arm=n,weight=w,evsi_mc=0. if n==0 else float(inc.mean()),evsi_mcse=float(inc.std(ddof=1)/np.sqrt(size)),evpi_mc=float(evpi_sample.mean()),expected_regret=float(regret.mean()),p_high_better=float(np.mean(delta>0)),trials=size))
    return out
def write_csv(name,rows):
    with (ROOT/'results'/name).open('w',encoding='utf-8',newline='') as f:
        writer=csv.DictWriter(f,fieldnames=list(rows[0])); writer.writeheader(); writer.writerows(rows)
def main():
    (ROOT/'results').mkdir(exist_ok=True); ab=parameters(); curve=summarize_posterior(ab); write_csv('decision-curve.csv',curve)
    endpoint_rows=[]
    for endpoint in ['response','grade3_teae','ae_discontinuation','adjudicated_ild']:
        parm=parameters(harm=endpoint) if endpoint!='response' else ab
        indices=[0,1] if endpoint=='response' else [2,3]
        for dose,i in zip([8,12],indices):
            a,b=parm[i]; lo,hi=beta.ppf([.025,.975],a,b)
            endpoint_rows.append(dict(endpoint=endpoint,dose=dose,posterior_mean=a/(a+b),ci_low=lo,ci_high=hi))
    write_csv('endpoint-posteriors.csv',endpoint_rows)
    designs=[]
    for n in SIZES:
        distributions=difference_distribution(ab,n)
        for row in curve:
            designs.append(dict(extra_per_arm=n,weight=row['weight'],evsi_exact=exact_evsi(ab,n,row['weight'],distributions=distributions),evpi_mc=row['evpi_mc']))
    write_csv('information-value.csv',designs)
    simulation=[]
    for n in SIZES: simulation.extend(simulate_design(ab,n,seed=SEED+n))
    write_csv('trial-simulation.csv',simulation)
    sensitivity=[]
    for name,harm,prior,penalty,override in [('primary','grade3_teae',1.,0.,None),('jeffreys','grade3_teae',.5,0.,None),('regularizing','grade3_teae',4.,0.,None),('discontinuation','ae_discontinuation',1.,0.,None),('ild_allgrade','adjudicated_ild',1.,0.,None),('late_harm_5pt','grade3_teae',1.,.05,None),('late_harm_10pt','grade3_teae',1.,.10,None),('low_residual_response','grade3_teae',1.,0.,{8:16,12:23}),('high_residual_response','grade3_teae',1.,0.,{8:12,12:25})]:
        par=parameters(harm,prior,override); d=difference_distribution(par,50)
        for row in summarize_posterior(par,[0,1,2,4],penalty):
            sensitivity.append(dict(scenario=name,**row,evsi_n50=exact_evsi(par,50,row['weight'],penalty,distributions=d)))
    write_csv('sensitivity.csv',sensitivity)
    dropout=[]
    for loss in [0,.2,.4]:
        for n in [25,50,100]:
            effective=int(np.floor(n*(1-loss))); d=difference_distribution(ab,effective)
            for w in [1,2,4]: dropout.append(dict(planned_per_arm=n,independent_loss=loss,effective_per_arm=effective,weight=w,evsi_exact=exact_evsi(ab,effective,w,distributions=d)))
    write_csv('future-evaluability.csv',dropout)
    write_csv('joint-sensitivity.csv',joint_sensitivity())
    draws=draw_posterior(ab)
    differences={}
    for name,delta in [('response',draws[:,1]-draws[:,0]),('grade3_teae',draws[:,3]-draws[:,2])]:
        differences[name]={'mean':float(delta.mean()),'ci':np.quantile(delta,[.025,.975]).tolist(),'p_positive':float(np.mean(delta>0))}
    summary={'seed':SEED,'posterior_draws':len(draws),'primary_cutoff':'2024-04-25','differences':differences,'current_switch_weight':float(current_mean(ab,0)/(ab[3,0]/ab[3].sum()-ab[2,0]/ab[2].sum())),'selected_weights':[r for r in curve if r['weight'] in [0,1,2,4]],'limitations':['Marginal endpoint independence is assumed; joint outcomes are not public.','Observed severe TEAE risk is not a common-horizon toxicity hazard.','EVSI units are hypothetical response-equivalent benefit, not money.','No PK/E-R, survival benefit, new-drug RP2D or clinical dose is qualified.']}
    (ROOT/'results/summary.json').write_text(json.dumps(summary,indent=2)+'\n')
    import scipy
    (ROOT/'results/environment.json').write_text(json.dumps({'python':platform.python_version(),'numpy':np.__version__,'scipy':scipy.__version__},indent=2)+'\n')
    print(json.dumps(summary,indent=2))
if __name__=='__main__': main()
