"""Meaningful independent verification of the preposterior algorithm."""
import unittest,itertools,json,csv
import numpy as np
from scipy.stats import betabinom,beta
from scipy.special import roots_jacobi
from analysis import parameters,current_mean,exact_evsi,positive_sum,difference_distribution,draw_posterior
from audit import unique_count,ROOT

def brute_evsi(ab,n,w):
    total=0.
    for xs in itertools.product(range(n+1),repeat=4):
        probability=np.prod([betabinom.pmf(x,n,a,b) for x,(a,b) in zip(xs,ab)])
        p=[(a+x)/(a+b+n) for x,(a,b) in zip(xs,ab)]
        delta=p[1]-p[0]-w*(p[3]-p[2])
        total+=probability*max(0,delta)
    return total-max(0,current_mean(ab,w))

def quadrature_evpi(ab,w,nodes=80):
    points=[]; weights=[]
    for a,b in ab:
        x,weight=roots_jacobi(nodes,b-1,a-1); points.append((x+1)/2); weights.append(weight/weight.sum())
    r=(points[1][:,None]-points[0][None,:]).ravel(); pr=(weights[1][:,None]*weights[0][None,:]).ravel()
    t=(points[3][:,None]-points[2][None,:]).ravel(); pt=(weights[3][:,None]*weights[2][None,:]).ravel()
    # Current Bayes loss avoids cancellation near a well-resolved choice.
    return positive_sum(-r,pr,w*t,pt) if current_mean(ab,w)>0 else positive_sum(r,pr,-w*t,pt)

class Verification(unittest.TestCase):
    def test_unique_rounding_reconstruction(self):
        self.assertEqual(unique_count(43.5,46),20)
        self.assertEqual(unique_count(50.,42),21)
        with self.assertRaises(AssertionError): unique_count(43.5,100)
    def test_endpoint_counts(self):
        ab=parameters(); np.testing.assert_array_equal(ab,[[13,35],[24,20],[21,27],[22,22]])
        self.assertAlmostEqual(current_mean(ab,1),.2121212121212121)
    def test_positive_sum_against_independent_enumeration(self):
        a=np.array([-2.,0.,1.,3.]); b=np.array([1.,-1.,0.]); pa=np.array([.1,.2,.3,.4]); pb=np.array([.2,.5,.3])
        expected=sum(x*y*max(0,v+u) for v,x in zip(a,pa) for u,y in zip(b,pb))
        self.assertAlmostEqual(positive_sum(a,pa,b,pb),expected,places=13)
    def test_exact_evsi_against_four_dimensional_enumeration(self):
        for ab in [parameters(),np.array([[1.,1.]]*4)]:
            for n in [1,2]:
                for w in [0.,1.,2.,4.]: self.assertAlmostEqual(exact_evsi(ab,n,w),max(0,brute_evsi(ab,n,w)),places=11)
    def test_no_data_information(self):
        self.assertEqual(exact_evsi(parameters(),0,4),0)
    def test_probability_and_martingale(self):
        ab=parameters();(r,pr),(t,pt)=difference_distribution(ab,50)
        self.assertAlmostEqual(pr.sum(),1,places=10);self.assertAlmostEqual(pt.sum(),1,places=10)
        self.assertAlmostEqual(np.dot(r,pr),current_mean(ab,0),places=10)
        self.assertAlmostEqual(np.dot(t,pt),.0625,places=10)
    def test_monotonicity_and_perfect_information_bound(self):
        ab=parameters()
        for w in [0,1,2,4,6]:
            values=[exact_evsi(ab,n,w) for n in [0,10,25,50,100,200]]
            self.assertTrue(all(b>=a-1e-10 for a,b in zip(values,values[1:])))
            self.assertLessEqual(values[-1],quadrature_evpi(ab,w,100)+.0001)
    def test_monte_carlo_against_exact_information_value(self):
        with (ROOT/'results/trial-simulation.csv').open() as f: rows=list(csv.DictReader(f))
        for row in rows:
            n=int(row['extra_per_arm']);w=float(row['weight']);expected=exact_evsi(parameters(),n,w)
            for estimate,se in [('evsi_preposterior_mc','evsi_preposterior_mcse'),('evsi_regret_reduction_mc','evsi_regret_mcse')]:
                self.assertLessEqual(abs(float(row[estimate])-expected),6*float(row[se])+1e-8)
    def test_dirichlet_margins_and_feasibility(self):
        for n,r,t in [(46,12,20),(42,23,21)]:
            for both in [max(0,r+t-n),round(r*t/n),min(r,t)]:
                cells=np.array([n-r-t+both,r-both,t-both,both])
                self.assertTrue(np.all(cells>=0));self.assertEqual(cells.sum(),n)
                a=cells+.5
                self.assertEqual(a[1]+a[3],r+1);self.assertEqual(a[2]+a[3],t+1)
    def test_beta_interval_and_quadrature_evpi(self):
        self.assertAlmostEqual(beta.mean(13,35),13/48)
        with (ROOT/'results/decision-curve.csv').open() as f: rows=list(csv.DictReader(f))
        for row in rows:
            if float(row['weight']) not in [0,1,2,4,6]:continue
            low=quadrature_evpi(parameters(),float(row['weight']),80);high=quadrature_evpi(parameters(),float(row['weight']),120)
            self.assertLess(abs(low-high),.0001)
            self.assertLessEqual(abs(high-float(row['evpi_mc'])),6*float(row['evpi_mcse'])+.0001)

if __name__=='__main__':unittest.main(verbosity=2)
