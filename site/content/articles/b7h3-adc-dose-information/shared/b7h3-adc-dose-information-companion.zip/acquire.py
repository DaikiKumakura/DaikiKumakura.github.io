"""Acquire primary open-access evidence; never bundle publisher documents."""
from pathlib import Path
from urllib.request import urlopen, Request
import hashlib,json,xml.etree.ElementTree as ET,zipfile

ROOT=Path(__file__).resolve().parent
EXPECTED={'primary.xml':'80efbcfc40da7cb17fed3c2dfc002147cd0fcc8be2443cef57b3c6f4670494e7','supplementary.zip':'16d287c745d6202106559cfff9609a1377597548a37d26fe93732d82befbd637','interim-release.html':'411055a2f2e11335360895142d8bab5862b31e0c78486bd6559872ef9b2cb93b'}
def retrieve(url,name):
    target=ROOT/'sources'/name; target.parent.mkdir(exist_ok=True)
    if not target.exists():
        with urlopen(Request(url,headers={'User-Agent':'Open evidence research'}),timeout=90) as r: data=r.read()
        target.write_bytes(data)
    data=target.read_bytes()
    assert hashlib.sha256(data).hexdigest()==EXPECTED[name], 'Source changed: '+name+'. Audit a new snapshot before using it.'
    if name.endswith('.xml'): ET.fromstring(data)
    return {'file':name,'url':url,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()}
if __name__=='__main__':
    records=[retrieve('https://www.ebi.ac.uk/europepmc/webservices/rest/PMC12834294/fullTextXML','primary.xml'),retrieve('https://www.ebi.ac.uk/europepmc/webservices/rest/PMC12834294/supplementaryFiles','supplementary.zip'),retrieve('https://www.merck.com/news/ifinatamab-deruxtecan-continues-to-demonstrate-promising-objective-response-rates-in-patients-with-extensive-stage-small-cell-lung-cancer-in-ideate-lung01-phase-2-trial/','interim-release.html')]
    with zipfile.ZipFile(ROOT/'sources/supplementary.zip') as z:
        name=next(n for n in z.namelist() if n.endswith('s002.pdf'))
        (ROOT/'sources/supplement.pdf').write_bytes(z.read(name))
    (ROOT/'sources/manifest.json').write_text(json.dumps(records,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(records,indent=2))
    tree=ET.parse(ROOT/'sources/primary.xml')
    for tag in ['permissions','supplementary-material']:
        for e in tree.findall('.//'+tag): print(ET.tostring(e,encoding='unicode')[:3500])
