# M02: B7-H3 ADC dose-comparison information value

This is an aggregate Bayesian research analysis, not an individual PK/E-R study or clinical dose recommendation.

## Reproduction

Python 3.12.14, numpy 2.3.5, scipy 1.18.1, matplotlib 3.11.2. `requirements.txt` records the actual versions. Base seed 20261004; 200,000 posterior draws; 60,000 simulated trials per primary/joint design.

From this directory:

```sh
python -m pip install -r requirements.txt
python analysis.py
python test_analysis.py
python figures.py
python validate.py
```

The release contains the audited small aggregate table, so reproduction of analysis does not require source document downloads. For source re-audit, run `acquire.py`, install pypdf, and run `audit.py`. `acquire.py` pins source-byte hashes and refuses changed documents. The public interim webpage is dynamic; future changes may require an explicitly documented new snapshot rather than silent substitution.

`analysis.ipynb` is an executed companion. To recreate/execute it install `nbformat`, `nbclient`, `ipykernel`, and run `prepare_notebook.py`. Kernel runs with the actual Python interpreter; no source documents are displayed in the notebook.

| File | Purpose |
| --- | --- |
| `data-audit.md` | Source/cohort/timing/usage audit |
| `analysis-plan.md` | Fixed pre-calculation plan |
| `data/aggregate-counts.csv` | Eight endpoint/arm rows with provenance |
| `analysis.py` | Marginal posterior, exact EVSI, hypothetical trials, sensitivity |
| `test_analysis.py` | Independent enumeration, quadrature and model-invariant checks |
| `validate.py` | Source, numerical, narrative and release checks |
| `results/` | Aggregate results and environment |
| `figures/` | Four original PNG/SVG figures |
| `article.md` | Editorial source |
| `publication/` | Draft candidate; not the live site |

## Interpretation

The primary harm is all-cause Grade >=3 TEAE, not TRAE and not fixed-horizon toxicity. Mean utility needs margins; uncertainty/learning need unknown joint outcomes. The primary endpoint-independence assumption is stress-tested with compatible reconstructed joint tables. A large EVSI near a preference boundary does not establish cost effectiveness, ethics, sample-size optimality, late toxicity or survival benefit. Original publisher figures, full tables and source PDFs/HTML/XML are not redistributed.
