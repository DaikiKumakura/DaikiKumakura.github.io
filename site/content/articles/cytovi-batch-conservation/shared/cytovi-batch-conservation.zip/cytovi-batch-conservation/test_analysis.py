import unittest
import numpy as np
from analysis import design_rank,center_batch,contrasts,contrast_diagnostics

class DiagnosticsTests(unittest.TestCase):
    def test_crossed_rank(self):self.assertEqual(design_rank([1,1,2,2],[0,1,0,1]),3)
    def test_confounded_rank(self):self.assertEqual(design_rank([1,1,2,2],[0,0,1,1]),2)
    def test_indistinguishable_coefficients(self):
        d=np.array([0,0,1,1]);b=d.copy()
        np.testing.assert_array_equal(2*d+3*b,4*d+b)
    def test_center_means_equal(self):
        x=np.array([[1.,2.],[2.,3.],[7.,9.],[9.,10.]])
        z=center_batch(x,[0,0,1,1]);np.testing.assert_allclose(z[:2].mean(0),z[2:].mean(0))
    def test_missing_batch(self):
        with self.assertRaises(ValueError):center_batch(np.ones((2,2)),[0,0])
    def test_exact_projection(self):
        x=np.array([[1.,2.],[-1.,3.]]);m=contrast_diagnostics(x,x);self.assertEqual(m['projection_coefficient'],1);self.assertEqual(m['contrast_rmse'],0)
    def test_projection_not_fraction(self):
        x=np.array([[1.,2.]]);self.assertEqual(contrast_diagnostics(x,2*x)['projection_coefficient'],2);self.assertEqual(contrast_diagnostics(x,-x)['projection_coefficient'],-1)
    def test_zero_reference(self):
        with self.assertRaises(ValueError):contrast_diagnostics(np.zeros((2,2)),np.zeros((2,2)))
    def test_contrast_order(self):
        x=np.array([[1.],[3.],[5.],[10.]])
        np.testing.assert_array_equal(contrasts(x,np.array([1,2,1,2]),np.array([2,2,1,1])),[[5.],[2.]])
    def test_missing_donor(self):
        with self.assertRaises(ValueError):contrasts(np.ones((2,1)),np.array([1,1]),np.array([1,1]))

if __name__=='__main__':unittest.main()
