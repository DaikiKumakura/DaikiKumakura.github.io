"""Small, prespecified semi-synthetic CytoVI experiment; not the paper benchmark."""
from pathlib import Path
import json,time,importlib.metadata
import numpy as np
import pandas as pd
import torch
import anndata as ad
import scvi
from scvi.external import CYTOVI
P=Path(__file__).resolve().parent

def main():
    if scvi.__version__!='1.4.2':raise RuntimeError('This experiment pins scvi-tools 1.4.2')
    torch.set_num_threads(4)
    a=np.load(P/'reference-input.npz',allow_pickle=False);base=a['x'];donor=a['donor']
    out=P/'model-outputs';out.mkdir(exist_ok=True)
    history=[]
    for scenario in ('balanced','confounded'):
        batch=a['balanced_batch'] if scenario=='balanced' else donor-1
        observed=base+batch[:,None]*a['shift'][None,:]
        for seed in (0,1):
            name=f'{scenario}-seed{seed}';scvi.settings.seed=seed
            obs=pd.DataFrame({'batch':pd.Categorical(batch.astype(str))},index=[f'c{i}' for i in range(len(base))])
            data=ad.AnnData(observed.astype(np.float32),obs=obs,var=pd.DataFrame(index=a['markers']))
            CYTOVI.setup_anndata(data,batch_key='batch')
            model=CYTOVI(data,n_hidden=64,n_latent=10,n_layers=1,protein_likelihood='normal',latent_distribution='normal',prior_mixture=False)
            start=time.monotonic()
            model.train(max_epochs=120,accelerator='cpu',devices=1,train_size=.9,batch_size=256,early_stopping=False,n_epochs_kl_warmup=60,check_val_every_n_epoch=10,enable_progress_bar=False,enable_model_summary=False,logger=False)
            decoded=model.get_normalized_expression(transform_batch="0",n_samples=20,return_mean=True,return_numpy=True,batch_size=512)
            latent=model.get_latent_representation()
            assert decoded.shape==base.shape and latent.shape==(len(base),10)
            assert np.isfinite(decoded).all() and np.isfinite(latent).all()
            np.savez_compressed(out/f'{name}.npz',decoded=decoded,latent=latent)
            model.save(P/'models'/name,overwrite=True)
            hist={k:{'first':float(v.iloc[0,0]),'last':float(v.iloc[-1,0]),'n':len(v)} for k,v in model.history.items() if len(v)}
            history.append(dict(scenario=scenario,seed=seed,seconds=time.monotonic()-start,history=hist,train_cells=len(model.train_indices),validation_cells=len(model.validation_indices),all_output_cells=len(base)))
            print(name,'completed',flush=True)
    versions={n:importlib.metadata.version(n) for n in ('scvi-tools','torch','numpy','pandas','anndata','lightning')}
    (out/'training-record.json').write_text(json.dumps(dict(versions=versions,runs=history,config=dict(n_hidden=64,n_latent=10,n_layers=1,prior_mixture=False,max_epochs=120,kl_warmup=60,train_size=.9,normal_likelihood=True,cpu_threads=4,decoder_batch="0",posterior_samples=20)),indent=2)+'\n',encoding='utf-8')
if __name__=='__main__':main()
