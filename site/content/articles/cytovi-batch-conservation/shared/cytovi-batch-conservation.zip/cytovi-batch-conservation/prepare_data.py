"""Own restricted FCS reader for this pinned, float32 list-mode dataset."""
from pathlib import Path
import csv,json,hashlib
import numpy as np
P=Path(__file__).resolve().parent

def read_fcs(path):
    b=Path(path).read_bytes()
    if b[:6] not in (b'FCS3.0',b'FCS3.1'):raise ValueError('unsupported FCS')
    a,z=int(b[10:18]),int(b[18:26]);text=b[a:z+1].decode('ascii')
    delim=text[0];tokens=text[1:].split(delim)
    if tokens[-1]=='':tokens.pop()
    if len(tokens)%2:raise ValueError('unsupported escaped/empty metadata')
    meta=dict(zip(tokens[::2],tokens[1::2]));n=int(meta['$TOT']);g=int(meta['$PAR'])
    if meta['$DATATYPE']!='F' or meta['$MODE']!='L':raise ValueError('unsupported data mode')
    if any(meta[f'$P{i}B']!='32' for i in range(1,g+1)):raise ValueError('not float32')
    endian={'4,3,2,1':'>','1,2,3,4':'<'}.get(meta['$BYTEORD'])
    if endian is None:raise ValueError('unsupported byte order')
    start,end=int(meta['$BEGINDATA']),int(meta['$ENDDATA'])
    if end-start+1!=4*n*g:raise ValueError('data length mismatch')
    x=np.frombuffer(b[start:end+1],dtype=endian+'f4').astype(np.float32).reshape(n,g)
    return x,[meta[f'$P{i}N'] for i in range(1,g+1)]

def main():
    raw,names=read_fcs(P/'sources/levine.fcs')
    assert raw.shape==(265627,41)
    markers=names[4:36];assert len(markers)==32
    labels=raw[:,names.index('label')];donor=raw[:,names.index('individual')].astype(int)
    assert set(donor)=={1,2}
    assigned=np.isfinite(labels);assert assigned.sum()==104184
    rng=np.random.default_rng(1729);idx=[];counts=[]
    for d in (1,2):
        for t in range(1,15):
            a=np.flatnonzero(assigned & (labels==t)&(donor==d));take=rng.choice(a,min(150,len(a)),replace=False);idx.extend(take)
            counts.append(dict(donor=d,label=t,original_cells=len(a),sampled_cells=len(take)))
    idx=np.sort(idx);x=raw[idx,4:36].astype(np.float64);assert np.isfinite(x).all()
    center=x.mean(0);scale=x.std(0,ddof=0);assert (scale>0).all();x=(x-center)/scale
    y=labels[idx].astype(int);d=donor[idx]
    balanced=np.zeros(len(idx),dtype=int)
    for donor_id in (1,2):
        for t in range(1,15):
            a=np.flatnonzero((d==donor_id)&(y==t));rng.shuffle(a);balanced[a[::2]]=1
    shift=np.array([.8 if m in ['CD4','CD8','CD19','CD20','CD34','CD38','CD14','HLA-DR'] else 0 for m in markers])
    np.savez_compressed(P/'reference-input.npz',x=x.astype(np.float32),donor=d,label=y,balanced_batch=balanced,shift=shift.astype(np.float32),markers=np.array(markers),source_row=idx)
    with (P/'sampling-counts.csv').open('w',newline='',encoding='utf-8') as f:
        w=csv.DictWriter(f,fieldnames=list(counts[0]));w.writeheader();w.writerows(counts)
    summary=dict(source_cells=len(raw),assigned_cells=int(assigned.sum()),unassigned_cells=int((~assigned).sum()),sampled_cells=len(idx),markers=markers,donor_totals={str(k):int((donor==k).sum()) for k in (1,2)},sample_donor_totals={str(k):int((d==k).sum()) for k in (1,2)},sample_seed=1729,scope='Two healthy donors; transformed public measurements, artificial batches and known injected shifts; not a disease validation.')
    (P/'data-summary.json').write_text(json.dumps(summary,indent=2)+'\n',encoding='utf-8');print(json.dumps(summary,indent=2))
if __name__=='__main__':main()
