# Public source and attribution

Levine et al. (2015). Data-Driven Phenotypic Dissection of AML Reveals Progenitor-like Cells that Correlate with Prognosis. Cell 162:184–197. https://doi.org/10.1016/j.cell.2015.05.047 . The benchmark subset is healthy bone marrow, not the AML patient cohort.

Public preprocessing and repository: Lukas M. Weber, https://github.com/lmweber/benchmark-data-Levine-32-dim , revision c6737786dcff3a50145993efed451a2af55e0a00. The distributed reference input is an extracted standardized subset; the repository license notice follows.

MIT License

Copyright (c) 2016 Lukas M. Weber

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.

CytoVI: Ingelfinger F, Levy N, Ergen C et al. (2026), Nature Methods 23:2054–2065. https://doi.org/10.1038/s41592-026-03224-5 . scvi-tools is a separate third-party library; no library source, checkpoints or manuscript figures are distributed. Our LICENSE does not relicense third-party materials.
