"""Diagnostics against a preserved public reference, not disease ground truth."""
from pathlib import Path
import json,csv
import numpy as np
P=Path(__file__).resolve().parent

def design_rank(donor,batch):
    return int(np.linalg.matrix_rank(np.column_stack([np.ones(len(donor)),np.asarray(donor)==2,batch])))

def center_batch(x,batch):
    x=np.asarray(x);batch=np.asarray(batch)
    if set(batch)!={0,1}:raise ValueError('both batches required')
    out=x.copy();out[batch==1]-=x[batch==1].mean(0)-x[batch==0].mean(0)
    return out

def contrasts(x,donor,labels):
    rows=[]
    for t in sorted(set(labels)):
        if not all(np.any((donor==d)&(labels==t)) for d in (1,2)):raise ValueError('donor missing in cell type')
        rows.append(x[(donor==2)&(labels==t)].mean(0)-x[(donor==1)&(labels==t)].mean(0))
    return np.stack(rows)

def contrast_diagnostics(reference,estimated):
    reference=np.asarray(reference,dtype=float);estimated=np.asarray(estimated,dtype=float)
    if reference.shape!=estimated.shape or not np.isfinite(reference).all() or not np.isfinite(estimated).all():raise ValueError('invalid arrays')
    den=np.sum(reference**2)
    if den==0:raise ValueError('zero reference contrasts')
    return dict(contrast_rmse=float(np.sqrt(np.mean((estimated-reference)**2))),projection_coefficient=float(np.sum(reference*estimated)/den),reference_contrast_rms=float(np.sqrt(np.mean(reference**2))))

def csv_write(path,rows):
    with path.open('w',newline='',encoding='utf-8') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)

def main():
    a=np.load(P/'reference-input.npz',allow_pickle=False)
    x=a['x'].astype(float);d=a['donor'];y=a['label'];shift=a['shift'].astype(float)
    truth=contrasts(x,d,y);metrics=[];detail=[];design=[]
    from sklearn.model_selection import StratifiedKFold,cross_val_predict
    from sklearn.neighbors import KNeighborsClassifier
    from sklearn.metrics import balanced_accuracy_score
    cv=StratifiedKFold(n_splits=5,shuffle=True,random_state=23)
    for scenario in ('balanced','confounded'):
        b=a['balanced_batch'] if scenario=='balanced' else d-1
        observed=x+b[:,None]*shift
        rank=design_rank(d,b);assert rank==(3 if scenario=='balanced' else 2)
        for donor_id in (1,2):
            for batch in (0,1):design.append(dict(scenario=scenario,donor=int(donor_id),batch=batch,cells=int(((d==donor_id)&(b==batch)).sum())))
        methods={'uncorrected':observed,'batch_mean':center_batch(observed,b),'oracle':observed-b[:,None]*shift}
        for seed in (0,1):methods[f'CytoVI_seed{seed}']=np.load(P/f'model-outputs/{scenario}-seed{seed}.npz',allow_pickle=False)['decoded'].astype(float)
        for method,z in methods.items():
            c=contrasts(z,d,y);diag=contrast_diagnostics(truth,c)
            label_rep=z
            if method.startswith('CytoVI_seed'):
                seed=int(method[-1]);label_rep=np.load(P/f'model-outputs/{scenario}-seed{seed}.npz',allow_pickle=False)['latent']
            predictions=cross_val_predict(KNeighborsClassifier(n_neighbors=15),label_rep,y,cv=cv,n_jobs=1)
            coarse=float(balanced_accuracy_score(y,predictions))
            metrics.append(dict(scenario=scenario,method=method,design_rank=rank,**diag,cellwise_reference_rmse=float(np.sqrt(np.mean((z-x)**2))),coarse_label_macro_recall=coarse))
            for j,t in enumerate(sorted(set(y))):
                for k,m in enumerate(a['markers']):detail.append(dict(scenario=scenario,method=method,label=int(t),marker=str(m),reference_contrast=float(truth[j,k]),estimated_contrast=float(c[j,k]),difference=float(c[j,k]-truth[j,k])))
    out=P/'results';out.mkdir(exist_ok=True)
    csv_write(out/'diagnostics.csv',metrics);csv_write(out/'marker-contrasts.csv',detail);csv_write(out/'design-counts.csv',design)
    result=dict(cells=len(x),cell_types=len(set(y)),markers=x.shape[1],metrics=metrics,scope='Preserved two-healthy-donor reference; semi-synthetic additive batches; same cells used for training/output; projection is not disease preservation, calibrated success or a bounded fraction. Two optimization seeds are not biological replication.')
    (out/'summary.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8');print(json.dumps(result,indent=2))
if __name__=='__main__':main()
