# CytoVI：人工バッチと参照対比の診断

原著：Ingelfinger F, Levy N, Ergen C et al. CytoVI: deep generative modeling of antibody-based single cell data. Nature Methods 23, 2054–2065 (2026). https://doi.org/10.1038/s41592-026-03224-5 . 原著性能の再現ではなく、独自の半合成実験。

入力：Levine et al. (2015), Cell 162:184–197, https://doi.org/10.1016/j.cell.2015.05.047 の健康骨髄ベンチマーク。Lukas M. Weberの公開前処理リポジトリ、revision c6737786dcff3a50145993efed451a2af55e0a00。元FCSは同梱せず約44 MBを任意取得する。引用・ライセンス通知はTHIRD_PARTY_NOTICES.mdを参照。

## 保存した出力から再計算

Python 3.12、numpy 1.26.4、scikit-learn 1.8.0で検証。図にmatplotlibが必要。

```sh
python analysis.py
python -m unittest test_analysis.py
python plot.py
```

reference-input.npzは4,109細胞×32変換済み・標準化済みマーカー、匿名ドナー1/2、手動gatingラベル1〜14、人工割付、注入シフト、元FCS行番号を含む。個人の名前や連絡先は含まない。model-outputsには4適合の復号値と10次元潜在表現、学習設定記録がある。保存済みの数値を再集計して4つの結果ファイルと独自2図を作る。npzはallow_pickle=Falseで読む。

## 公開FCSから入力を作り直す

```sh
python fetch_data.py
python prepare_data.py
```

fetch_data.pyは固定URL取得とSHA-256照合のみ行い、取得した第三者Rコードは実行しない。prepare_data.pyのFCS readerは、この固定ファイルのFCS3.0/3.1、list mode、全32-bit浮動小数点、明確なbyte orderとmetadataを対象にする限定実装であり、一般のFCSを全形式で読むライブラリではない。headerの範囲とDATA長、全数265627×41を検査する。

マーカーはFCSのP5〜P36の32列で、時刻、DNA、viability、ラベル、donor等を特徴にしない。既にasinh(raw/5)が適用されているため再適用しない。手動ラベルが非NaNの104184細胞から、donor×14細胞型につきseed1729で最大150を非復元抽出。150細胞未満の層では全てを保持し、総数4109。ソース全数・各層の原数と抽出数はsampling-counts.csvに記録した。抽出集合内のmarker平均と母標準偏差（ddof=0）でz標準化する。この抽出から元の細胞割合は推定しない。

入力3ファイルのSHA-256はinput-provenance.jsonのinput_hashesと照合する。公開元のバイト、利用版、実装hashも同ファイルに収録。

## CytoVIを再適合する

オプション。保存出力の集計には不要。モデルの再適合は保存出力を上書きするので、保存版を検査する工程を先に行う。

```sh
python train_models.py
python analysis.py
```

検証環境：scvi-tools1.4.2、torch2.11.0、numpy1.26.4、pandas2.2.2、anndata0.12.10、lightning2.6.1。n_hidden64/n_latent10/n_layers1、normal likelihood/latent、prior_mixture=False、ドナーと手動ラベルは非入力。seed0/1、max_epochs120、KL warmup60、train_size0.9、batch_size256、CPU4threads、early_stopping=False。decode条件はカテゴリ文字列`"0"`（人工バッチ0）、n_samples20、return_mean=True。潜在表現はget_latent_representationの平均表現。

全4適合を記録し、都合のよいseedを選別していない。固定epochまでの実行を確認したが、十分な収束やハイパーパラメータ最適化は確認していない。logger=Falseのため学習履歴のhistoryは空であり、損失の推移を検証したとは扱わない。ランダムcell splitの3699学習細胞と410検証細胞を含む同じ4109細胞を評価しており、独立ドナーのgeneralization試験ではない。保存重みはmodelsに出るが配布しない。別環境で再適合した数値やPNGのバイト一致は保証しない。

## 主診断と追加の補助診断

各手動ラベル内でdonor2−donor1の32marker平均差を計算。14×32要素を等しく重み付けする。参照との差のRMSEと、sum(reference*estimate)/sum(reference^2)の射影係数を併記。係数は負・1超も取り得るので保存率と呼ばない。1でも参照に直交する誤差があり得る。cellwise_reference_rmseも保存するが、生成モデルのdenoising誤差をすべてバッチ補正の誤りと解釈しない。

単純補正はbatch1の平均をbatch0の平均へ揃える。oracleは注入したshiftを知って引く、通常にはない情報を持つ対照。交差条件では、同じ型・ドナー内にほぼ半分ずつバッチを作るため未補正でもドナー対比からシフトがほぼ打ち消される。対比が保たれることだけでは、バッチを消せた証拠にならない。

主解析を適合前に固定した。追加の粗いラベル診断は主結果を見た後に設定した探索的指標：15近傍分類器、StratifiedKFold5、shuffle=True、random_state23、macro recall（balanced_accuracy_score）。CytoVIは10D latent、それ以外は32protein表現。表現の次元が異なるので公正なモデル性能順位として使わない。分類器は分割内でラベルを評価するが、CytoVIは評価細胞の発現も利用するtransductiveな診断。ラベルは測定マーカーの手動gating由来で臨床的な外部正解ではない。

半合成参照にも元のノイズが含まれる。残したいドナー差を実験の参照として指定したのであり、病態差・生物学的真値とは認定していない。疾患診断、未注釈細胞、外部患者、CLLの申請データ、原著の全性能は範囲外。二つのseedは最適化の反復であり、生物学的なNを増やさない。
