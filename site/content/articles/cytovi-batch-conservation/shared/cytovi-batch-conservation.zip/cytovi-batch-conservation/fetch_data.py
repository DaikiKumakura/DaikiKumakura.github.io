"""Fetch pinned public source inputs only; no downloaded code is executed."""
from pathlib import Path
import json,hashlib,urllib.request
P=Path(__file__).resolve().parent
def main():
    d=json.loads((P/'input-provenance.json').read_text(encoding='utf-8'));root=P/'sources';root.mkdir(exist_ok=True)
    for r in d['source_files']:
        out=(root/r['file']).resolve()
        if not out.is_relative_to(root.resolve()):raise ValueError('unsafe path')
        if not out.exists():
            with urllib.request.urlopen(r['url'],timeout=90) as f:out.write_bytes(f.read())
        if out.stat().st_size!=r['bytes'] or hashlib.sha256(out.read_bytes()).hexdigest()!=r['sha256']:raise ValueError('source hash mismatch')
        print('verified',r['file'])
if __name__=='__main__':main()
