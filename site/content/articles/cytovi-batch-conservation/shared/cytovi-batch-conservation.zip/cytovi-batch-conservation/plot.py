"""Original figures for a semi-synthetic design diagnostic."""
from pathlib import Path
import json,csv
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
P=Path(__file__).resolve().parent;F=P/'figures';F.mkdir(exist_ok=True)
design=list(csv.DictReader((P/'results/design-counts.csv').open()))
fig,axs=plt.subplots(1,2,figsize=(8,4.3))
for ax,s,title in zip(axs,['balanced','confounded'],['Crossed design (rank 3)','Donor = batch (rank 2)']):
    m=np.array([[int(next(r['cells'] for r in design if r['scenario']==s and int(r['donor'])==d and int(r['batch'])==b)) for b in (0,1)] for d in (1,2)])
    ax.imshow(m,cmap='Blues',vmin=0,vmax=2100)
    for i in range(2):
        for j in range(2):ax.text(j,i,str(m[i,j]),ha='center',va='center',fontsize=15,color='white' if m[i,j]>1500 else 'black')
    ax.set_xticks([0,1],['Artificial batch 0','Artificial batch 1']);ax.set_yticks([0,1],['Donor 1','Donor 2']);ax.set_title(title)
fig.text(.5,.02,'Same 4,109 reference cells in both scenarios. Known shift added only in artificial batch 1.',ha='center',fontsize=9)
fig.tight_layout(rect=(0,.06,1,1));fig.savefig(F/'01-crossed-and-confounded-design.png',dpi=160);plt.close(fig)
res=json.loads((P/'results/summary.json').read_text())['metrics']
methods=['uncorrected','batch_mean','oracle','CytoVI_seed0','CytoVI_seed1'];labels=['Uncorrected','Batch mean','Oracle','CytoVI\nseed 0','CytoVI\nseed 1']
fig,axs=plt.subplots(2,1,figsize=(7.5,7),sharex=True)
for scenario,color,marker,off in [('balanced','#337e89','o',-.08),('confounded','#b87742','D',.08)]:
    rows=[next(r for r in res if r['scenario']==scenario and r['method']==m) for m in methods]
    for ax,key in zip(axs,['projection_coefficient','coarse_label_macro_recall']):ax.scatter(np.arange(5)+off,[r[key] for r in rows],s=55,c=color,marker=marker,label=scenario,zorder=3)
axs[0].axhline(1,c='gray',ls='--',lw=1);axs[0].axhline(0,c='gray',ls=':',lw=1)
axs[0].set_ylabel('Projection onto reference\ndonor contrasts (not a fraction)');axs[0].set_ylim(-.05,1.13);axs[0].legend(loc='lower left')
axs[1].set_ylabel('Coarse-label macro recall\n(transductive kNN diagnostic)');axs[1].set_ylim(.75,1)
axs[1].set_xticks(range(5),labels)
for ax in axs:ax.grid(axis='y',alpha=.2);ax.spines[['top','right']].set_visible(False)
fig.text(.5,.025,'Preserved two-healthy-donor reference; semi-synthetic additive shifts.\nDifferent representations for kNN: CytoVI latent (10D), other methods (32 proteins).',ha='center',fontsize=8)
fig.tight_layout(rect=(0,.08,1,1));fig.savefig(F/'02-coarse-labels-and-within-type-contrasts.png',dpi=160);plt.close(fig)
