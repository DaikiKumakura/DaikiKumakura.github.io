"""Closed-form relations for flat versus weight-based dosing under a power-model clearance.

Notation (all dimensionless unless stated):
  x      = BW / BWref, body weight relative to the reference weight
  b      = exponent of weight on clearance, CL = CLref * x**b
  c      = exponent of weight on volume, V = Vref * x**c
  delta  = fractional deviation of exposure from the reference, exposure ratio r = 1 +/- delta
  AUC (or Cavg) at steady state = dose per interval / CL, so exposure scales as dose / CL.
  Flat dose:   exposure ratio = x**(-b)
  mg/kg dose:  exposure ratio = x**(1 - b)
  s      = D / (d * BWref): flat dose D divided by the mg/kg dose d times the reference weight
           (s = 1 when the flat dose equals the mg/kg dose at the reference weight).
"""
from __future__ import annotations

import numpy as np
from scipy import stats


def exposure_ratio_flat(x, b, s: float = 1.0):
    """Steady-state AUC (or Cavg) of a flat dose relative to the mg/kg exposure at x = 1."""
    return s * np.power(x, -b)


def exposure_ratio_mgkg(x, b):
    """Steady-state AUC (or Cavg) of a mg/kg dose relative to the exposure at x = 1."""
    return np.power(x, 1.0 - b)


def weight_at_ratio_flat(r, b, s: float = 1.0):
    """Relative weight x at which the flat-dose exposure ratio equals r: s * x**(-b) = r."""
    return np.power(s / r, 1.0 / b)


def weight_at_ratio_mgkg(r, b):
    """Relative weight x at which the mg/kg exposure ratio equals r: x**(1-b) = r."""
    return np.power(r, 1.0 / (1.0 - b))


def band_flat(delta, b, s: float = 1.0):
    """(low, high) relative weights between which the flat-dose exposure stays within 1 +/- delta."""
    lo = weight_at_ratio_flat(1.0 + delta, b, s)
    hi = weight_at_ratio_flat(1.0 - delta, b, s)
    return lo, hi


def band_mgkg(delta, b):
    """(low, high) relative weights between which the mg/kg exposure stays within 1 +/- delta."""
    lo = weight_at_ratio_mgkg(1.0 - delta, b)
    hi = weight_at_ratio_mgkg(1.0 + delta, b)
    return lo, hi


def sd_log_exposure(b, sigma, regimen: str):
    """SD of ln(exposure) caused by weight alone, sigma = SD of ln(weight)."""
    if regimen == "flat":
        return abs(b) * sigma
    if regimen == "mgkg":
        return abs(1.0 - b) * sigma
    raise ValueError(regimen)


def lognormal_sigma_from_cv(cv):
    """SD of ln(X) for a log-normal X with coefficient of variation cv."""
    return float(np.sqrt(np.log1p(np.asarray(cv) ** 2)))


def cv_from_sigma(sigma):
    """Coefficient of variation of a log-normal variable with SD(ln X) = sigma."""
    return float(np.sqrt(np.expm1(np.asarray(sigma) ** 2)))


def fraction_outside_band(b, regimen, median_kg, sigma, ref_kg, delta=0.2, s: float = 1.0):
    """Probability that the exposure ratio is outside 1 +/- delta when ln(BW) ~ N(ln median, sigma^2).

    ln(ratio) is normal with mean m and SD v, so the probability is exact.
    """
    shift = np.log(median_kg / ref_kg)
    if regimen == "flat":
        m = np.log(s) - b * shift
        v = abs(b) * sigma
    elif regimen == "mgkg":
        m = (1.0 - b) * shift
        v = abs(1.0 - b) * sigma
    else:
        raise ValueError(regimen)
    lo, hi = np.log(1.0 - delta), np.log(1.0 + delta)
    p_in = stats.norm.cdf(hi, m, v) - stats.norm.cdf(lo, m, v)
    return float(1.0 - p_in)


# ---- delta method for threshold weights ------------------------------------

def threshold_weight_flat(ref_kg, b, r, s: float = 1.0):
    return ref_kg * weight_at_ratio_flat(r, b, s)


def threshold_weight_mgkg(ref_kg, b, r):
    return ref_kg * weight_at_ratio_mgkg(r, b)


def delta_method_log_weight_flat(b, se_b, r, s: float = 1.0):
    """SE of ln(weight threshold) for flat dosing: ln x = ln(s/r)/b, d/db = -ln(s/r)/b^2."""
    return abs(np.log(s / r)) / b ** 2 * se_b


def delta_method_log_weight_mgkg(b, se_b, r):
    """SE of ln(weight threshold) for mg/kg dosing: ln x = ln(r)/(1-b), d/db = ln(r)/(1-b)^2."""
    return abs(np.log(r)) / (1.0 - b) ** 2 * se_b


# ---- trough, one-compartment steady state (approximation) --------------------

def trough_ss_flat_or_mgkg(dose_mg, cl_l_per_day, v_l, tau_day):
    """Steady-state trough of repeated IV bolus doses in a one-compartment model.

    Ctrough = (D / V) * exp(-k tau) / (1 - exp(-k tau)), k = CL / V.
    """
    k = cl_l_per_day / v_l
    e = np.exp(-k * tau_day)
    return dose_mg / v_l * e / (1.0 - e)


def auc_ss_one_comp(dose_mg, cl_l_per_day):
    """Steady-state AUC over one interval = dose / CL."""
    return dose_mg / cl_l_per_day


# ---- log-symmetric band ------------------------------------------------------

def band_flat_log(delta, b, s: float = 1.0):
    """Limits for a log-symmetric band exp(+/- delta) of the exposure ratio (flat dosing)."""
    return weight_at_ratio_flat(np.exp(delta), b, s), weight_at_ratio_flat(np.exp(-delta), b, s)


def band_mgkg_log(delta, b):
    """Limits for a log-symmetric band exp(+/- delta) of the exposure ratio (mg/kg dosing)."""
    return weight_at_ratio_mgkg(np.exp(-delta), b), weight_at_ratio_mgkg(np.exp(delta), b)


# ---- multi-compartment trough (linear, IV bolus, steady state) -----------------

def rate_matrix(cl, vc, peripherals):
    """Rate matrix of amounts for a central compartment and peripherals [(Q, Vp), ...] (units L/day, L)."""
    n = 1 + len(peripherals)
    m = np.zeros((n, n))
    m[0, 0] = -(cl + sum(q for q, _ in peripherals)) / vc
    for i, (q, vp) in enumerate(peripherals, start=1):
        m[0, i] = q / vp
        m[i, 0] = q / vc
        m[i, i] = -q / vp
    return m


def trough_ss_multicomp(dose_mg, cl, vc, peripherals, tau_day):
    """Pre-dose central concentration at steady state: y- = (I - E)^-1 E e1 D, E = expm(M tau)."""
    from scipy.linalg import expm
    m = rate_matrix(cl, vc, peripherals)
    e = expm(m * tau_day)
    n = m.shape[0]
    e1 = np.zeros(n)
    e1[0] = 1.0
    y = np.linalg.solve(np.eye(n) - e, e @ e1) * dose_mg
    return float(y[0] / vc)
