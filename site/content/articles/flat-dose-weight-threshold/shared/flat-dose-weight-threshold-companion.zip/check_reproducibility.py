"""Run the analysis twice into temporary directories and compare file hashes with each other and with results/."""
from __future__ import annotations

import json
import tempfile
from pathlib import Path

import analysis as an

ROOT = Path(__file__).resolve().parent


def main() -> int:
    with tempfile.TemporaryDirectory() as a, tempfile.TemporaryDirectory() as b:
        an.run(Path(a))
        an.run(Path(b))
        ha = json.loads((Path(a) / "sha256.json").read_text())
        hb = json.loads((Path(b) / "sha256.json").read_text())
        hr = json.loads((ROOT / "results" / "sha256.json").read_text())
    same_runs, same_saved = ha == hb, ha == hr
    print(f"run1 == run2: {same_runs}; run1 == results/sha256.json: {same_saved}; files compared: {len(ha)}")
    return 0 if same_runs and same_saved else 1


if __name__ == "__main__":
    raise SystemExit(main())
