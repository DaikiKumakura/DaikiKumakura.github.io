"""Numerical (ODE) check of the closed-form steady-state exposure of repeated IV bolus doses.

One-compartment model: dA/dt = -(CL/V) A, with a bolus of D added to A every tau days.
The AUC over the last interval is accumulated as a second state, dAUC/dt = A / V.
"""
from __future__ import annotations

import numpy as np
from scipy.integrate import solve_ivp


def simulate_repeated_bolus(dose_mg: float, cl: float, v: float, tau: float, n_doses: int | None = None):
    """Return (trough, auc_last_interval, cmax_last_interval) after repeated bolus dosing.

    Units: dose in mg, cl in L/day, v in L, tau in days, concentrations in mg/L.
    """
    k = cl / v
    if n_doses is None:
        # at least 60 half-lives so that the residual accumulation error is far below 1e-12
        n_doses = int(np.ceil(60.0 * np.log(2.0) / (k * tau))) + 2
    amount = 0.0
    trough = auc = cmax = np.nan
    for i in range(n_doses):
        amount += dose_mg
        y0 = [amount, 0.0]
        sol = solve_ivp(
            lambda t, y: [-k * y[0], y[0] / v],
            (0.0, tau),
            y0,
            method="LSODA",
            rtol=1e-11,
            atol=1e-14,
        )
        amount = sol.y[0, -1]
        if i == n_doses - 1:
            trough = amount / v
            auc = sol.y[1, -1]
            cmax = dose_mg / v + trough
    return float(trough), float(auc), float(cmax)


def simulate_repeated_bolus_multicomp(dose_mg: float, cl: float, vc: float, peripherals, tau: float, n_doses: int = 400):
    """Pre-dose central concentration after repeated bolus doses, by ODE integration (any number of peripherals)."""
    from powermodel import rate_matrix
    m = rate_matrix(cl, vc, peripherals)
    y = np.zeros(m.shape[0])
    pre = np.nan
    for _ in range(n_doses):
        y[0] += dose_mg
        sol = solve_ivp(lambda t, a: m @ a, (0.0, tau), y, method="LSODA", rtol=1e-11, atol=1e-14)
        y = sol.y[:, -1]
        pre = y[0] / vc
    return float(pre)
