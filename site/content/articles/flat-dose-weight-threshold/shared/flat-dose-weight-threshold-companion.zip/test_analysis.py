"""Checks for the flat-dose weight-threshold analysis. Run: python -X utf8 -m pytest test_analysis.py -q"""
from __future__ import annotations

import tempfile
from pathlib import Path

import numpy as np
import pandas as pd
import pytest

import analysis as an
import powermodel as pm
from odecheck import simulate_repeated_bolus

ROOT = Path(__file__).resolve().parent
DRUGS = an.load_drugs(ROOT / "inputs" / "parameter_table.csv")
MAIN = DRUGS[DRUGS["role"] == "main"]


def test_closed_form_vs_ode_auc_and_trough():
    for cl, v, tau in ((0.22, 7.5, 21.0), (0.74, 4.3, 14.0), (0.15, 6.4, 21.0)):
        for dose in (1.0, 2.5):
            tr, auc, _ = simulate_repeated_bolus(dose, cl, v, tau)
            assert auc == pytest.approx(dose / cl, rel=1e-8)
            assert tr == pytest.approx(pm.trough_ss_flat_or_mgkg(dose, cl, v, tau), rel=1e-8)


def test_flat_and_mgkg_exposure_from_ode_with_power_clearance():
    b, cl0, v0, tau = 0.6, 0.22, 7.5, 21.0
    for x in (0.5, 1.5):
        auc_ref = simulate_repeated_bolus(1.0, cl0, v0, tau)[1]
        auc_flat = simulate_repeated_bolus(1.0, cl0 * x ** b, v0 * x ** 0.5, tau)[1]
        auc_mgkg = simulate_repeated_bolus(x, cl0 * x ** b, v0 * x ** 0.5, tau)[1]
        assert auc_flat / auc_ref == pytest.approx(pm.exposure_ratio_flat(x, b), rel=1e-8)
        assert auc_mgkg / auc_ref == pytest.approx(pm.exposure_ratio_mgkg(x, b), rel=1e-8)


def test_unit_and_ratio_identities():
    x = np.linspace(0.4, 2.5, 50)
    for b in (0.3, 0.5, 0.7):
        # flat / mg/kg exposure = 1 / x, independent of b
        assert np.allclose(pm.exposure_ratio_flat(x, b) / pm.exposure_ratio_mgkg(x, b), 1.0 / x)
        assert pm.exposure_ratio_flat(1.0, b) == 1.0 and pm.exposure_ratio_mgkg(1.0, b) == 1.0
    assert an.unit_to_l_per_day(9.4, "mL/h") == pytest.approx(0.2256)
    assert an.unit_to_l_per_day(0.0308, "L/h") == pytest.approx(0.7392)


def test_thresholds_invert_the_exposure_functions():
    for b in (0.32, 0.47, 0.69):
        for delta in (0.1, 0.2, 0.3):
            lo, hi = pm.band_flat(delta, b)
            assert pm.exposure_ratio_flat(lo, b) == pytest.approx(1 + delta)
            assert pm.exposure_ratio_flat(hi, b) == pytest.approx(1 - delta)
            lo, hi = pm.band_mgkg(delta, b)
            assert pm.exposure_ratio_mgkg(lo, b) == pytest.approx(1 - delta)
            assert pm.exposure_ratio_mgkg(hi, b) == pytest.approx(1 + delta)


def test_variance_equal_at_b_half():
    sigma = 0.25
    assert pm.sd_log_exposure(0.5, sigma, "flat") == pytest.approx(pm.sd_log_exposure(0.5, sigma, "mgkg"))
    assert pm.sd_log_exposure(0.4, sigma, "flat") < pm.sd_log_exposure(0.4, sigma, "mgkg")
    assert pm.sd_log_exposure(0.6, sigma, "flat") > pm.sd_log_exposure(0.6, sigma, "mgkg")
    # Monte Carlo with a log-normal weight distribution
    rng = np.random.default_rng(1)
    sg = pm.lognormal_sigma_from_cv(0.25)
    lw = rng.normal(np.log(75), sg, 1_000_000)
    for b in (0.5, 0.3):
        v_flat = np.var(-b * lw)
        v_mgkg = np.var((1 - b) * lw)
        assert v_flat == pytest.approx(b ** 2 * sg ** 2, rel=5e-3)
        assert v_mgkg == pytest.approx((1 - b) ** 2 * sg ** 2, rel=5e-3)
    assert np.var(-0.5 * lw) == pytest.approx(np.var(0.5 * lw), rel=1e-12)


def test_monotonicity():
    b = np.linspace(0.1, 0.9, 17)
    # heavier weight limit of flat dosing falls as b rises; mg/kg heavy limit rises with b
    assert np.all(np.diff(pm.band_flat(0.2, b)[1]) < 0)
    assert np.all(np.diff(pm.band_mgkg(0.2, b)[1]) > 0)
    x = np.linspace(0.4, 2.5, 40)
    assert np.all(np.diff(pm.exposure_ratio_flat(x, 0.5)) < 0)
    assert np.all(np.diff(pm.exposure_ratio_mgkg(x, 0.5)) > 0)
    d = (0.1, 0.2, 0.3)
    highs = [pm.band_flat(q, 0.6)[1] for q in d]
    assert highs == sorted(highs)


def test_fraction_outside_exact_vs_simulation():
    rng = np.random.default_rng(2)
    med, cv, ref, b = 70.0, 0.25, 77.0, 0.6
    sg = pm.lognormal_sigma_from_cv(cv)
    lw = rng.normal(np.log(med), sg, 600_000)
    for regimen, ratio in (("flat", np.exp(-b * (lw - np.log(ref)))), ("mgkg", np.exp((1 - b) * (lw - np.log(ref))))):
        mc = np.mean((ratio < 0.8) | (ratio > 1.2))
        assert pm.fraction_outside_band(b, regimen, med, sg, ref) == pytest.approx(mc, abs=2e-3)


def test_delta_method_vs_simulation():
    rng = np.random.default_rng(3)
    b, se, ref = 0.566, 0.046, 80.0
    draws = rng.normal(b, se, 400_000)
    for r in (0.8, 0.9, 1.2):
        sim = np.log(ref * pm.weight_at_ratio_flat(r, draws))
        assert np.std(sim) == pytest.approx(pm.delta_method_log_weight_flat(b, se, r), rel=0.05)
    sim = np.log(ref * pm.weight_at_ratio_mgkg(1.2, draws))
    assert np.std(sim) == pytest.approx(pm.delta_method_log_weight_mgkg(b, se, 1.2), rel=0.05)


def test_seed_reproducibility():
    with tempfile.TemporaryDirectory() as a, tempfile.TemporaryDirectory() as b:
        an.run(Path(a))
        an.run(Path(b))
        ha = (Path(a) / "sha256.json").read_text()
        hb = (Path(b) / "sha256.json").read_text()
        assert ha == hb


def test_input_table_completeness():
    t = pd.read_csv(ROOT / "inputs" / "parameter_table.csv")
    required = ["source_doi", "source_location", "drug", "parameter", "value", "unit", "population",
                "covariate_model_form", "data_origin", "reference_weight_kg", "model_form_status"]
    assert not t[["source_doi", "source_location", "drug", "parameter", "value", "unit", "population",
                  "data_origin", "reference_weight_kg", "model_form_status"]].isna().any().any()
    assert set(required) <= set(t.columns)
    main = t[t.role == "main"]
    for drug, g in main.groupby("drug"):
        assert {"CL_wt_exponent", "Vc_wt_exponent", "Vp_wt_exponent", "CL_typical", "Vc_typical", "Vp_typical"} <= set(g["parameter"]), drug
    assert main["drug"].nunique() >= 5
    for d in ("pembrolizumab", "nivolumab", "atezolizumab", "durvalumab", "avelumab"):
        assert d in set(main["drug"])
    exps = main[main.parameter == "CL_wt_exponent"]
    assert ((exps["value"] > 0) & (exps["value"] < 1)).all()
    nv = pd.read_csv(ROOT / "inputs" / "not_verified.csv")
    assert not set(nv["drug"]) & set(main["drug"])


def test_uncertainty_inputs_present_for_all_main_drugs():
    assert MAIN["se"].notna().all() and (MAIN["se"] > 0).all()


def test_multicompartment_matrix_vs_ode():
    from odecheck import simulate_repeated_bolus_multicomp
    for per in ([(0.8, 4.0)], [(0.74, 1.27), (0.092, 2.10)]):
        tr_mat = pm.trough_ss_multicomp(1.0, 0.2, 3.0, per, 21.0)
        tr_ode = simulate_repeated_bolus_multicomp(1.0, 0.2, 3.0, per, 21.0, n_doses=300)
        assert tr_mat == pytest.approx(tr_ode, rel=1e-8)
    # with no exchange the multi-compartment trough reduces to the one-compartment formula
    assert pm.trough_ss_multicomp(1.0, 0.2, 3.0, [(1e-12, 4.0)], 21.0) == pytest.approx(
        pm.trough_ss_flat_or_mgkg(1.0, 0.2, 3.0, 21.0), rel=1e-6)


def test_log_symmetric_band_and_linear_band_relation():
    for b in (0.324, 0.595):
        lo, hi = pm.band_flat_log(0.2, b)
        assert pm.exposure_ratio_flat(lo, b) == pytest.approx(np.exp(0.2))
        assert pm.exposure_ratio_flat(hi, b) == pytest.approx(np.exp(-0.2))
        lin_lo, lin_hi = pm.band_flat(0.2, b)
        assert lo < lin_lo and hi < lin_hi  # exp(0.2) = 1.221 > 1.2 and exp(-0.2) = 0.819 > 0.8


def test_label_dose_ratio_uses_interval_and_cemiplimab_net_exponent():
    lab = an.label_dose_table(DRUGS)
    s = dict(zip(lab["drug"], lab["s"]))
    assert s["nivolumab"] == pytest.approx(1.0)
    assert s["pembrolizumab"] == pytest.approx(200 / (2 * 76.8))
    assert s["durvalumab"] == pytest.approx((1500 / 28) / (10 * 69.8 / 14))
    cemi = MAIN[MAIN["drug"] == "cemiplimab"].iloc[0]
    assert cemi["c_vc_tr"] == pytest.approx(0.970 - 0.560)
    assert cemi["c_vc"] == pytest.approx(0.970)


def test_source_range_flags_and_extrapolation_labels():
    thr = an.thresholds_table(DRUGS)
    rng = an.source_range_table(DRUGS, thr)
    assert set(rng["flag"]) <= {"source range not available", "inside source min-max",
                                "outside source range (extrapolation)"}
    assert (rng[rng["drug"] == "pembrolizumab"]["flag"] == "source range not available").all()
    assert (rng[rng["drug"] == "durvalumab"]["flag"] != "source range not available").all()
