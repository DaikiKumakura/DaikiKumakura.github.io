"""Figures for the flat-dose weight-threshold note. Reads results/ and inputs/, writes figures/."""
from __future__ import annotations

from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

import powermodel as pm

ROOT = Path(__file__).resolve().parent
RES, FIG = ROOT / "results", ROOT / "figures"
FIG.mkdir(exist_ok=True)

# Okabe-Ito
BLACK, ORANGE, SKY, GREEN, YELLOW, BLUE, VERM, PURPLE = (
    "#000000", "#E69F00", "#56B4E9", "#009E73", "#F0E442", "#0072B2", "#D55E00", "#CC79A7")
plt.rcParams.update({"font.size": 12, "axes.titlesize": 12, "axes.labelsize": 12, "legend.fontsize": 10.5,
                     "xtick.labelsize": 11, "ytick.labelsize": 11, "figure.dpi": 100, "savefig.dpi": 200,
                     "axes.spines.top": False, "axes.spines.right": False})
BAND = 0.20


def save(fig, name):
    fig.savefig(FIG / name, bbox_inches="tight", facecolor="white")
    plt.close(fig)


def fig1_schematic():
    x = np.linspace(0.5, 2.0, 300)
    fig, ax = plt.subplots(1, 2, figsize=(10, 4.4))
    for b, col, ls in ((0.3, SKY, "-"), (0.6, BLUE, "--"), (1.0, VERM, ":")):
        ax[0].plot(x, x ** b, color=col, ls=ls, lw=2.4, label=f"b = {b}")
    ax[0].set(xlabel="Relative weight, BW / BWref", ylabel="Relative clearance, CL / CLref",
              title="(a) Power model: CL = CLref (BW / BWref)^b")
    ax[0].legend(frameon=False, loc="upper left")
    b = 0.6
    ax[1].axhspan(1 - BAND, 1 + BAND, color="0.88", label="Band: ratio 0.8 to 1.2")
    ax[1].plot(x, pm.exposure_ratio_flat(x, b), color=BLUE, lw=2.4, label="Flat dose: x^(-b)")
    ax[1].plot(x, pm.exposure_ratio_mgkg(x, b), color=VERM, lw=2.4, ls="--", label="mg/kg dose: x^(1-b)")
    ax[1].set_yscale("log")
    ax[1].set_yticks([0.6, 0.8, 1.0, 1.25, 1.6]); ax[1].set_yticklabels(["0.6", "0.8", "1.0", "1.25", "1.6"])
    lo, hi = pm.band_flat(BAND, b)
    for v in (lo, hi):
        ax[1].axvline(v, color=BLUE, lw=1, ls=":")
    ax[1].set(xlabel="Relative weight, BW / BWref", ylabel="Exposure relative to reference",
              title="(b) Exposure at b = 0.6 (illustrative)")
    ax[1].legend(frameon=False, loc="upper right")
    fig.tight_layout()
    save(fig, "fig1_power_model_schematic.png")


def drugs_main():
    d = pd.read_csv(RES / "drug_inputs_used.csv")
    return d[d["role"] == "main"].reset_index(drop=True)


def fig2_exposure_curves():
    d = drugs_main()
    w = np.linspace(40, 160, 300)
    fig, axs = plt.subplots(3, 3, figsize=(10, 11), sharex=True, sharey=True)
    for ax, (_, r) in zip(axs.ravel(), d.iterrows()):
        x = w / r["wref"]
        ax.axhspan(1 - BAND, 1 + BAND, color="0.88")
        ax.plot(w, pm.exposure_ratio_flat(x, r["b"]), color=BLUE, lw=2.2, label="Flat dose")
        ax.plot(w, pm.exposure_ratio_mgkg(x, r["b"]), color=VERM, lw=2.2, ls="--", label="mg/kg dose")
        ax.axvline(r["wref"], color="k", lw=0.8, ls=":")
        ax.set_yscale("log"); ax.set_ylim(0.5, 2.0)
        ax.set_yticks([0.5, 0.8, 1.0, 1.25, 2.0]); ax.set_yticklabels(["0.5", "0.8", "1.0", "1.25", "2.0"])
        ax.set_title(f"{r['drug']}\nb = {r['b']:.3f}, BWref = {r['wref']:g} kg", fontsize=11)
    for ax in axs[-1]:
        ax.set_xlabel("Body weight (kg)")
    for ax in axs[:, 0]:
        ax.set_ylabel("Relative exposure")
    axs[0, 0].legend(frameon=False, loc="lower left", fontsize=9.5)
    fig.tight_layout()
    save(fig, "fig3_relative_exposure_by_drug.png")


def fig3_forest():
    d = drugs_main().sort_values("b").reset_index(drop=True)
    u = pd.read_csv(RES / "thresholds_uncertainty.csv")
    fig, axs = plt.subplots(1, 2, figsize=(11, 5.6), sharey=True)
    for ax, regimen, title in ((axs[0], "flat", "(a) Flat dose"), (axs[1], "mgkg", "(b) mg/kg dose")):
        for i, r in d.iterrows():
            for side, col, mk in (("light", SKY, "^"), ("heavy", VERM, "s")):
                q = u[(u.drug == r["drug"]) & (u.regimen == regimen) & (u.delta == BAND) & (u.side == side)].iloc[0]
                ax.errorbar(q["sim_median"], i, xerr=[[q["sim_median"] - q["sim_low"]], [q["sim_high"] - q["sim_median"]]],
                            fmt=mk, color=col, ms=7, capsize=3, lw=1.8,
                            label=("Light-side limit" if side == "light" else "Heavy-side limit") if i == 0 else None)
            ax.plot(r["wref"], i, "D", color="k", ms=5, label="Reference weight" if i == 0 else None)
        ax.set_yticks(range(len(d))); ax.set_yticklabels([f"{n} (b={b:.3f})" for n, b in zip(d["drug"], d["b"])])
        ax.set_xlabel("Body weight (kg)"); ax.set_title(title)
        ax.grid(axis="x", color="0.9")
    h, l = axs[0].get_legend_handles_labels()
    fig.tight_layout(rect=(0, 0.07, 1, 1))
    fig.legend(h, l, loc="lower center", ncol=3, frameon=False)
    save(fig, "fig4_threshold_weights_forest.png")


def fig4_variance():
    d = drugs_main().sort_values("b").reset_index(drop=True)
    bb = np.linspace(0, 1, 201)
    fig = plt.figure(figsize=(9, 7.5))
    gs = fig.add_gridspec(2, 1, height_ratios=[2.2, 1.6], hspace=0.12)
    ax = fig.add_subplot(gs[0]); ax2 = fig.add_subplot(gs[1], sharex=ax)
    ax.plot(bb, np.abs(bb), color=BLUE, lw=2.4, label="Flat dose: |b|")
    ax.plot(bb, np.abs(1 - bb), color=VERM, lw=2.4, ls="--", label="mg/kg dose: |1 - b|")
    ax.axvline(0.5, color="k", lw=1, ls=":")
    ax.annotate("b = 0.5: equal variance", (0.5, 0.48), xytext=(0.6, 0.12), fontsize=11,
                arrowprops=dict(arrowstyle="->", color="k"))
    ax.set_ylabel("SD of ln(exposure) / SD of ln(BW)"); ax.legend(frameon=False, loc="upper center")
    plt.setp(ax.get_xticklabels(), visible=False)
    for i, r in d.iterrows():
        lo, hi = r["b"] - 1.96 * r["se"], r["b"] + 1.96 * r["se"]
        ax2.errorbar(r["b"], i, xerr=[[r["b"] - lo], [hi - r["b"]]], fmt="o", color=GREEN, ms=6, capsize=3, lw=1.8)
    ax2.axvline(0.5, color="k", lw=1, ls=":")
    ax2.set_yticks(range(len(d))); ax2.set_yticklabels(d["drug"]); ax2.set_ylim(-0.7, len(d) - 0.3)
    ax2.set_xlabel("Clearance weight exponent b (95% interval = estimate +/- 1.96 SE)")
    ax2.set_xlim(0, 1)
    fig.subplots_adjust(left=0.2)
    save(fig, "fig5_variance_crossover.png")


def fig5_distribution():
    t = pd.read_csv(RES / "distribution_sensitivity.csv")
    d = drugs_main().sort_values("b").reset_index(drop=True)
    scs = list(t["scenario"].unique())
    cols = [BLUE, ORANGE, GREEN, PURPLE]; mks = ["o", "s", "^", "D"]
    fig, axs = plt.subplots(1, 2, figsize=(11, 5.6), sharey=True, sharex=True)
    for ax, regimen, title in ((axs[0], "flat", "(a) Flat dose"), (axs[1], "mgkg", "(b) mg/kg dose")):
        for k, sc in enumerate(scs):
            vals = [t[(t.scenario == sc) & (t.drug == n) & (t.regimen == regimen)]["frac_outside_pm20"].iloc[0] for n in d["drug"]]
            ax.plot(vals, range(len(d)), mks[k], color=cols[k], ms=7, label=sc)
        ax.set_yticks(range(len(d))); ax.set_yticklabels([f"{n} (b={b:.3f})" for n, b in zip(d["drug"], d["b"])])
        ax.set_xlabel("Fraction outside exposure ratio 0.8 to 1.2"); ax.set_title(title); ax.grid(axis="x", color="0.9")
    h, l = axs[0].get_legend_handles_labels()
    fig.tight_layout(rect=(0, 0.09, 1, 1))
    fig.legend(h, l, loc="lower center", ncol=2, frameon=False)
    save(fig, "fig6_weight_distribution_sensitivity.png")


def fig6_matrix():
    p = pd.read_csv(ROOT / "inputs" / "parameter_table.csv")
    nv = pd.read_csv(ROOT / "inputs" / "not_verified.csv")
    cols = ["CL exponent", "Uncertainty", "Reference weight", "Explicit equation", "V exponent", "Used in analysis"]
    rows = []
    for drug in p[p.role == "main"]["drug"].unique():
        g = p[(p.drug == drug) & (p.role == "main")].set_index("parameter")
        cl = g.loc["CL_wt_exponent"]
        unc = "CI" if pd.notna(cl["ci_low"]) else ("RSE" if pd.notna(cl["rse_percent"]) else "None")
        rows.append((drug, ["Yes", unc, "Yes", "Yes" if cl["model_form_status"] == "explicit" else "Partial", "Yes", "Yes"]))
    manual = {"camrelizumab": ["No", "No", "No", "No", "No", "No"],
              "adebrelimab": ["No", "No", "No", "No", "No", "No"],
              "panitumumab": ["No", "No", "No", "No", "No", "No"],
              "cetuximab": ["No", "No", "No", "No", "No", "No"],
              "trastuzumab": ["Yes", "RSE", "No", "No", "No", "No"],
              "bevacizumab": ["No", "No", "No", "No", "No", "No"],
              "rituximab": ["No", "No", "No", "No", "No", "No"]}
    for drug in nv["drug"]:
        rows.append((drug, manual[drug]))
    color = {"Yes": SKY, "CI": SKY, "RSE": "#B7DDF5", "Partial": YELLOW, "No": "#F4B39A", "None": "#F4B39A"}
    fig, ax = plt.subplots(figsize=(9.5, 7.2))
    for i, (drug, vals) in enumerate(rows):
        for j, v in enumerate(vals):
            ax.add_patch(plt.Rectangle((j, i), 1, 1, facecolor=color[v], edgecolor="white", lw=2))
            ax.text(j + 0.5, i + 0.5, v, ha="center", va="center", fontsize=10.5)
    ax.set_xlim(0, len(cols)); ax.set_ylim(len(rows), 0)
    ax.set_xticks(np.arange(len(cols)) + 0.5); ax.set_xticklabels(cols, rotation=30, ha="left")
    ax.xaxis.tick_top(); ax.set_yticks(np.arange(len(rows)) + 0.5); ax.set_yticklabels([r[0] for r in rows])
    for s in ax.spines.values():
        s.set_visible(False)
    ax.tick_params(length=0)
    save(fig, "fig2_data_provenance_matrix.png")


if __name__ == "__main__":
    fig1_schematic(); fig2_exposure_curves(); fig3_forest(); fig4_variance(); fig5_distribution(); fig6_matrix()
    print("figures written to", FIG)
