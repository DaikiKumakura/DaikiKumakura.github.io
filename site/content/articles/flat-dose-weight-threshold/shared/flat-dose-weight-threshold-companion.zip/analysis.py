"""Weight thresholds for flat dosing computed from published clearance weight exponents.

Usage: python -X utf8 analysis.py [output_dir]
Reads inputs/parameter_table.csv and inputs/not_verified.csv; writes CSV/JSON to results/ (default).
All analysis parameters are collected below. Random seed: 20261105.
"""
from __future__ import annotations

import hashlib
import json
import sys
from pathlib import Path

import numpy as np
import pandas as pd
from scipy import optimize, stats

import powermodel as pm
from odecheck import simulate_repeated_bolus, simulate_repeated_bolus_multicomp

ROOT = Path(__file__).resolve().parent

# ---- analysis parameters ------------------------------------------------------
SEED = 20261105
N_SIM = 200_000                       # parametric draws of the exponent
DELTAS = (0.10, 0.20, 0.30)           # exposure deviations defining a weight threshold
BAND_DELTA = 0.20                     # +/- band used for the weight band and the scenario analysis
Z95 = 1.959963984540054
# Assumed log-normal weight scenarios (median kg, CV). These are scenarios, not population claims.
WEIGHT_SCENARIOS = {
    "S1 median 75 kg CV 20%": (75.0, 0.20),
    "S2 median 70 kg CV 25%": (70.0, 0.25),
    "S3 median 80 kg CV 30%": (80.0, 0.30),
    "S4 median 65 kg CV 25%": (65.0, 0.25),
}
VARIANCE_SCENARIO = "S1 median 75 kg CV 20%"
OMEGA_CL_SCENARIO = 0.30              # assumed residual SD of ln(CL) (scenario) for the total-variance table
MC_N = 400_000                        # Monte Carlo size for the variance verification
S_VALUES = (0.8, 1.0, 1.25)           # dose-matching ratio s = D / (d * BWref)
# dose pairing stated in the existing site article: 200 mg = 2 mg/kg at 100 kg; 240 mg = 3 mg/kg at 80 kg
SITE_PAIRING_KG = {"pembrolizumab": 100.0, "nivolumab": 80.0}
TAU_DAYS = (14.0, 21.0)               # dosing intervals for the one-compartment trough approximation
TROUGH_DELTA = 0.20
ODE_X = (0.5, 0.75, 1.0, 1.5, 2.0)
# dosing interval (days) of the regimen studied in each source; used for the source-interval trough limits
SOURCE_TAU = {"pembrolizumab": 21.0, "nivolumab": 14.0, "atezolizumab": 21.0, "durvalumab": 14.0, "avelumab": 14.0,
              "tislelizumab": 21.0, "cemiplimab": 21.0, "dostarlimab": 21.0, "ipilimumab": 21.0}
# regimens for the dose-matching ratio s = (D / tau_flat) / (d * BWref / tau_mgkg): (flat mg, flat tau, mg/kg dose, mg/kg tau, basis)
LABEL_REGIMENS = {
    "pembrolizumab": (200.0, 21.0, 2.0, 21.0, "200 mg Q3W vs 2 mg/kg Q3W as stated in the existing article"),
    "nivolumab": (240.0, 14.0, 3.0, 14.0, "240 mg Q2W vs 3 mg/kg Q2W as stated in the existing article"),
    "atezolizumab": (1200.0, 21.0, 15.0, 21.0, "1200 mg Q3W vs 15 mg/kg Q3W in the FDA review"),
    "durvalumab": (1500.0, 28.0, 10.0, 14.0, "1500 mg Q4W (flat) vs 10 mg/kg Q2W in the source"),
    "avelumab": (800.0, 14.0, 10.0, 14.0, "800 mg Q2W vs 10 mg/kg Q2W in the source"),
    "tislelizumab": (200.0, 21.0, 3.0, 21.0, "200 mg Q3W vs 3 mg/kg Q3W in the source"),
}
CEMI_V_GRID = (0.41, 0.50, 0.70, 0.82, 0.97, 1.12)   # weight exponent of V for the cemiplimab trough sensitivity
SHIFT_MEDIANS = (65.0, 70.0, 75.0, 80.0)               # scenario medians (kg) for the location-shift analysis
SPREAD_CVS = (0.20, 0.25, 0.30)                        # CVs for the spread analysis


def unit_to_l_per_day(value: float, unit: str) -> float:
    return {"L/day": 1.0, "L/h": 24.0, "mL/h": 24.0 / 1000.0}[unit] * value


def load_drugs(path: Path) -> pd.DataFrame:
    t = pd.read_csv(path, dtype={"reference_weight_kg": float})
    rows = []
    for (drug, role), g in t.groupby(["drug", "role"], sort=False):
        g = g.set_index("parameter")
        cl = g.loc["CL_wt_exponent"]
        value = float(cl["value"])
        if pd.notna(cl["rse_percent"]):
            se, basis = value * float(cl["rse_percent"]) / 100.0, "RSE x estimate"
        elif pd.notna(cl["ci_low"]) and pd.notna(cl["ci_high"]):
            se, basis = (float(cl["ci_high"]) - float(cl["ci_low"])) / (2 * Z95), "(CI upper - CI lower)/(2 x 1.96)"
        else:
            se, basis = np.nan, "none reported"
        rec = {
            "drug": drug, "role": role, "b": value, "se": se, "se_basis": basis,
            "ci_low": cl["ci_low"], "ci_high": cl["ci_high"], "ci_type": cl["ci_type"],
            "wref": float(cl["reference_weight_kg"]),
            "model_form_status": cl["model_form_status"], "source_doi": cl["source_doi"],
        }
        if role == "main":
            rec["c_vc"] = float(g.loc["Vc_wt_exponent", "value"])
            rec["c_vp"] = float(g.loc["Vp_wt_exponent", "value"])
            rec["cl_l_day"] = unit_to_l_per_day(float(g.loc["CL_typical", "value"]), g.loc["CL_typical", "unit"])
            rec["vc_l"] = float(g.loc["Vc_typical", "value"])
            rec["vp_l"] = float(g.loc["Vp_typical", "value"])
            q = unit_to_l_per_day(float(g.loc["Q_typical", "value"]), g.loc["Q_typical", "unit"])
            if "Q3_typical" in g.index:
                rec["peripherals"] = [(q, float(g.loc["V2_typical", "value"])),
                                      (float(g.loc["Q3_typical", "value"]), float(g.loc["V3_typical", "value"]))]
            else:
                rec["peripherals"] = [(q, rec["vp_l"])]
            bmi = float(g.loc["Vss_BMI_exponent", "value"]) if "Vss_BMI_exponent" in g.index else 0.0
            rec["bmi_exp"] = bmi
            # BMI is proportional to weight at fixed height, so its exponent adds to the weight exponent of V
            rec["c_vc_tr"] = rec["c_vc"] + bmi
            rec["c_vp_tr"] = rec["c_vp"] + bmi
        rows.append(rec)
    return pd.DataFrame(rows)


def thresholds_table(d: pd.DataFrame) -> pd.DataFrame:
    rows = []
    for _, r in d.iterrows():
        b, w = r["b"], r["wref"]
        for delta in DELTAS:
            lo_f, hi_f = pm.band_flat(delta, b)
            lo_m, hi_m = pm.band_mgkg(delta, b)
            rows.append({
                "drug": r["drug"], "role": r["role"], "b": b, "wref_kg": w, "delta": delta,
                "flat_low_kg": w * lo_f, "flat_high_kg": w * hi_f,
                "flat_low_rel": lo_f, "flat_high_rel": hi_f,
                "mgkg_low_kg": w * lo_m, "mgkg_high_kg": w * hi_m,
                "mgkg_low_rel": lo_m, "mgkg_high_rel": hi_m,
                "flat_band_width_kg": w * (hi_f - lo_f), "mgkg_band_width_kg": w * (hi_m - lo_m),
            })
    return pd.DataFrame(rows)


def uncertainty_table(d: pd.DataFrame, rng: np.random.Generator) -> pd.DataFrame:
    """Threshold weights with 95% intervals: delta method, parametric simulation, CI-endpoint transform."""
    rows = []
    main = d[d["role"] == "main"]
    for _, r in main.iterrows():
        b, se, w = r["b"], r["se"], r["wref"]
        draws = rng.normal(b, se, N_SIM)
        n_bad = int(np.sum(draws <= 0.05))
        draws = draws[draws > 0.05]
        for regimen in ("flat", "mgkg"):
            for delta in (0.10, 0.20, 0.30):
                # flat: exposure falls below 1-delta at heavy weights, rises above 1+delta at light weights
                # mgkg: exposure rises above 1+delta at heavy weights, falls below 1-delta at light weights
                sides = ({"light": 1.0 + delta, "heavy": 1.0 - delta} if regimen == "flat"
                         else {"light": 1.0 - delta, "heavy": 1.0 + delta})
                for side, rr in sides.items():
                    if regimen == "flat":
                        f = lambda bb: pm.threshold_weight_flat(w, bb, rr)
                        se_log = pm.delta_method_log_weight_flat(b, se, rr)
                    else:
                        f = lambda bb: pm.threshold_weight_mgkg(w, bb, rr)
                        se_log = pm.delta_method_log_weight_mgkg(b, se, rr)
                    est = float(f(b))
                    d_lo, d_hi = est * np.exp(-Z95 * se_log), est * np.exp(Z95 * se_log)
                    sim = f(draws)
                    s_lo, s_hi = np.percentile(sim, [2.5, 97.5])
                    if pd.notna(r["ci_low"]) and pd.notna(r["ci_high"]):
                        e1, e2 = float(f(r["ci_low"])), float(f(r["ci_high"]))
                        c_lo, c_hi = min(e1, e2), max(e1, e2)
                    else:
                        c_lo = c_hi = np.nan
                    rows.append({
                        "drug": r["drug"], "regimen": regimen, "delta": delta, "side": side,
                        "threshold_kg": est, "delta_low": d_lo, "delta_high": d_hi,
                        "sim_median": float(np.median(sim)), "sim_low": float(s_lo), "sim_high": float(s_hi),
                        "ci_endpoint_low": c_lo, "ci_endpoint_high": c_hi,
                        "se_b": se, "se_basis": r["se_basis"], "n_draws_dropped": n_bad,
                    })
    return pd.DataFrame(rows)


def variance_table(d: pd.DataFrame, rng: np.random.Generator) -> tuple[pd.DataFrame, pd.DataFrame]:
    med, cv = WEIGHT_SCENARIOS[VARIANCE_SCENARIO]
    sigma = pm.lognormal_sigma_from_cv(cv)
    rows = []
    main = d[d["role"] == "main"]
    ln_w = rng.normal(np.log(med), sigma, MC_N)
    for _, r in main.iterrows():
        b, se = r["b"], r["se"]
        ln_e_flat = -b * (ln_w - np.log(r["wref"]))
        ln_e_mgkg = (1 - b) * (ln_w - np.log(r["wref"]))
        sd_f_th, sd_m_th = pm.sd_log_exposure(b, sigma, "flat"), pm.sd_log_exposure(b, sigma, "mgkg")
        rows.append({
            "drug": r["drug"], "b": b, "se_b": se, "scenario": VARIANCE_SCENARIO, "sigma_lnW": sigma,
            "sd_ratio_flat": abs(b), "sd_ratio_mgkg": abs(1 - b),
            "sd_lnE_flat_theory": sd_f_th, "sd_lnE_mgkg_theory": sd_m_th,
            "sd_lnE_flat_mc": float(np.std(ln_e_flat, ddof=1)), "sd_lnE_mgkg_mc": float(np.std(ln_e_mgkg, ddof=1)),
            "cv_E_flat_exact": pm.cv_from_sigma(sd_f_th), "cv_E_mgkg_exact": pm.cv_from_sigma(sd_m_th),
            "cv_E_flat_mc": float(np.std(np.exp(ln_e_flat), ddof=1) / np.mean(np.exp(ln_e_flat))),
            "cv_E_mgkg_mc": float(np.std(np.exp(ln_e_mgkg), ddof=1) / np.mean(np.exp(ln_e_mgkg))),
            "lower_variance_regimen": "flat" if abs(b) < abs(1 - b) else "mgkg",
            "p_b_below_0.5": float(stats.norm.cdf((0.5 - b) / se)),
            "total_sd_flat_with_omega": float(np.hypot(sd_f_th, OMEGA_CL_SCENARIO)),
            "total_sd_mgkg_with_omega": float(np.hypot(sd_m_th, OMEGA_CL_SCENARIO)),
        })
    vt = pd.DataFrame(rows)
    # generic crossover check on a grid of b (weight-only variance)
    grid = []
    for bb in np.round(np.arange(0.0, 1.0001, 0.05), 2):
        grid.append({"b": bb, "var_flat_over_sigma2": bb ** 2, "var_mgkg_over_sigma2": (1 - bb) ** 2,
                     "equal": bool(np.isclose(bb ** 2, (1 - bb) ** 2))})
    return vt, pd.DataFrame(grid)


def distribution_table(d: pd.DataFrame, rng: np.random.Generator) -> pd.DataFrame:
    rows = []
    main = d[d["role"] == "main"]
    for sc, (med, cv) in WEIGHT_SCENARIOS.items():
        sigma = pm.lognormal_sigma_from_cv(cv)
        ln_w = rng.normal(np.log(med), sigma, MC_N)
        for _, r in main.iterrows():
            b, w = r["b"], r["wref"]
            for regimen in ("flat", "mgkg"):
                p = pm.fraction_outside_band(b, regimen, med, sigma, w, BAND_DELTA)
                ratio = np.exp(-b * (ln_w - np.log(w))) if regimen == "flat" else np.exp((1 - b) * (ln_w - np.log(w)))
                p_mc = float(np.mean((ratio < 1 - BAND_DELTA) | (ratio > 1 + BAND_DELTA)))
                rows.append({"scenario": sc, "median_kg": med, "cv": cv, "sigma_lnW": sigma, "drug": r["drug"],
                             "regimen": regimen, "frac_outside_pm20": p, "frac_outside_pm20_mc": p_mc,
                             "median_exposure_ratio": float((med / w) ** (-b if regimen == "flat" else 1 - b))})
    return pd.DataFrame(rows)


def dose_matching_table(d: pd.DataFrame) -> pd.DataFrame:
    rows = []
    main = d[d["role"] == "main"]
    for _, r in main.iterrows():
        b, w = r["b"], r["wref"]
        s_list = [("s=%.2f" % s, s) for s in S_VALUES]
        if r["drug"] in SITE_PAIRING_KG:
            s_list.append(("site article pairing %.0f kg" % SITE_PAIRING_KG[r["drug"]], SITE_PAIRING_KG[r["drug"]] / w))
        for label, s in s_list:
            lo, hi = pm.band_flat(BAND_DELTA, b, s)
            _, hi10 = pm.band_flat(0.10, b, s)
            rows.append({"drug": r["drug"], "case": label, "s": s, "match_weight_kg": s * w, "wref_kg": w,
                         "flat_band20_low_kg": w * lo, "flat_band20_high_kg": w * hi,
                         "flat_heavy10_kg": w * hi10,
                         "equal_exposure_weight_kg": s * w})
    return pd.DataFrame(rows)


def trough_functions(r: pd.Series, tau: float, c_override: float | None = None):
    c_c = r["c_vc_tr"] if c_override is None else c_override
    c_p = r["c_vp_tr"] if c_override is None else c_override

    def vss(x):
        return r["vc_l"] * np.power(x, c_c) + r["vp_l"] * np.power(x, c_p)

    def cl(x):
        return r["cl_l_day"] * np.power(x, r["b"])

    def trough_flat(x):
        return pm.trough_ss_flat_or_mgkg(1.0, cl(x), vss(x), tau)

    def trough_mgkg(x):
        return pm.trough_ss_flat_or_mgkg(x, cl(x), vss(x), tau)

    return vss, cl, trough_flat, trough_mgkg


def solve_limit(fun, ref, level):
    """Relative weight in [0.2, 8] at which fun(x) / ref = level; NaN if it is not reached."""
    try:
        return optimize.brentq(lambda x: fun(x) / ref - level, 0.2, 8.0, xtol=1e-12)
    except ValueError:
        return np.nan


def trough_table(d: pd.DataFrame) -> pd.DataFrame:
    """One-compartment trough limits for the common 21-day and 14-day intervals and the source interval."""
    rows = []
    main = d[d["role"] == "main"]
    for _, r in main.iterrows():
        taus = [("common 21 d", 21.0), ("common 14 d", 14.0), ("source interval", SOURCE_TAU[r["drug"]])]
        for label, tau in taus:
            vss, cl, tf, tm = trough_functions(r, tau)
            t12 = float(np.log(2) * vss(1.0) / cl(1.0))
            ref_f, ref_m = tf(1.0), tm(1.0)
            out = {"drug": r["drug"], "interval_basis": label, "tau_day": tau, "t_half_1comp_day": t12,
                   "k_tau": float(cl(1.0) / vss(1.0) * tau), "b": r["b"],
                   "c_eff": float(np.log(vss(2.0) / vss(1.0)) / np.log(2.0))}
            for regimen, fun, ref in (("flat", tf, ref_f), ("mgkg", tm, ref_m)):
                for side, level in (("heavy" if regimen == "flat" else "light", 1 - TROUGH_DELTA),
                                    ("light" if regimen == "flat" else "heavy", 1 + TROUGH_DELTA)):
                    out[f"{regimen}_trough_{side}_kg"] = r["wref"] * solve_limit(fun, ref, level)
            lo, hi = pm.band_flat(TROUGH_DELTA, r["b"])
            out["flat_auc_light_kg"], out["flat_auc_heavy_kg"] = r["wref"] * lo, r["wref"] * hi
            lo, hi = pm.band_mgkg(TROUGH_DELTA, r["b"])
            out["mgkg_auc_light_kg"], out["mgkg_auc_heavy_kg"] = r["wref"] * lo, r["wref"] * hi
            out["flat_trough_ratio_at_auc_heavy"] = float(tf(pm.band_flat(TROUGH_DELTA, r["b"])[1]) / ref_f)
            out["shift_auc_minus_trough_kg"] = out["flat_auc_heavy_kg"] - out["flat_trough_heavy_kg"]
            rows.append(out)
    return pd.DataFrame(rows)


def multicomp_flat_trough(r: pd.Series, tau: float, qmode: str):
    """Flat-dose trough as a function of x for a 2- or 3-compartment bolus model (Q scaled by x^b or not scaled)."""
    def f(x):
        cl = r["cl_l_day"] * x ** r["b"]
        vc = r["vc_l"] * x ** r["c_vc_tr"]
        qs = 1.0 if qmode == "none" else x ** r["b"]
        per = [(q * qs, vp * x ** r["c_vp_tr"]) for q, vp in r["peripherals"]]
        return pm.trough_ss_multicomp(1.0, cl, vc, per, tau)
    return f


def two_compartment_table(d: pd.DataFrame) -> pd.DataFrame:
    """Heavy-side flat trough limit in a 2- (3-) compartment bolus model versus the 1-compartment value."""
    rows = []
    main = d[d["role"] == "main"]
    for _, r in main.iterrows():
        for label, tau in (("common 21 d", 21.0), ("source interval", SOURCE_TAU[r["drug"]])):
            _, _, tf, _ = trough_functions(r, tau)
            lim1 = r["wref"] * solve_limit(tf, tf(1.0), 1 - TROUGH_DELTA)
            row = {"drug": r["drug"], "interval_basis": label, "tau_day": tau, "limit_1comp_kg": lim1,
                   "auc_limit_kg": r["wref"] * pm.band_flat(TROUGH_DELTA, r["b"])[1]}
            for qmode in ("none", "b"):
                f = multicomp_flat_trough(r, tau, qmode)
                lim = r["wref"] * solve_limit(f, f(1.0), 1 - TROUGH_DELTA)
                row[f"limit_multicomp_Q{qmode}_kg"] = lim
                row[f"diff_vs_1comp_Q{qmode}_kg"] = lim - lim1
                row[f"shift_auc_minus_trough_Q{qmode}_kg"] = row["auc_limit_kg"] - lim
            rows.append(row)
    return pd.DataFrame(rows)


def cemiplimab_sensitivity(d: pd.DataFrame) -> pd.DataFrame:
    """Heavy-side flat trough limit for cemiplimab over the V exponent and b (tau 21 d and 14 d)."""
    r = d[(d["role"] == "main") & (d["drug"] == "cemiplimab")].iloc[0]
    rows = []
    for tau in (21.0, 14.0):
        for b_label, bb in (("b - 1.96 SE", r["b"] - Z95 * r["se"]), ("b", r["b"]), ("b + 1.96 SE", r["b"] + Z95 * r["se"])):
            rr = r.copy()
            rr["b"] = bb
            for c in CEMI_V_GRID:
                _, _, tf, _ = trough_functions(rr, tau, c_override=c)
                rows.append({"tau_day": tau, "b_case": b_label, "b": bb, "c_V": c,
                             "trough_heavy_limit_kg": rr["wref"] * solve_limit(tf, tf(1.0), 1 - TROUGH_DELTA),
                             "auc_heavy_limit_kg": rr["wref"] * pm.band_flat(TROUGH_DELTA, bb)[1]})
    return pd.DataFrame(rows)


def log_symmetric_table(d: pd.DataFrame) -> pd.DataFrame:
    """Limits for a log-symmetric band, exposure ratio between exp(-0.2) and exp(+0.2)."""
    rows = []
    for _, r in d[d["role"] == "main"].iterrows():
        lo_f, hi_f = pm.band_flat_log(BAND_DELTA, r["b"])
        lo_m, hi_m = pm.band_mgkg_log(BAND_DELTA, r["b"])
        lin_lo, lin_hi = pm.band_flat(BAND_DELTA, r["b"])
        rows.append({"drug": r["drug"], "b": r["b"], "wref_kg": r["wref"],
                     "flat_log_low_kg": r["wref"] * lo_f, "flat_log_high_kg": r["wref"] * hi_f,
                     "mgkg_log_low_kg": r["wref"] * lo_m, "mgkg_log_high_kg": r["wref"] * hi_m,
                     "flat_linear_low_kg": r["wref"] * lin_lo, "flat_linear_high_kg": r["wref"] * lin_hi})
    return pd.DataFrame(rows)


def label_dose_table(d: pd.DataFrame) -> pd.DataFrame:
    rows = []
    for _, r in d[d["role"] == "main"].iterrows():
        if r["drug"] not in LABEL_REGIMENS:
            continue
        flat_mg, tau_f, mgkg, tau_m, basis = LABEL_REGIMENS[r["drug"]]
        s = (flat_mg / tau_f) / (mgkg * r["wref"] / tau_m)
        lo, hi = pm.band_flat(BAND_DELTA, r["b"], s)
        _, hi10 = pm.band_flat(0.10, r["b"], s)
        rows.append({"drug": r["drug"], "flat_dose_mg": flat_mg, "flat_tau_day": tau_f, "mgkg_dose": mgkg,
                     "mgkg_tau_day": tau_m, "wref_kg": r["wref"], "s": s,
                     "s_per_dose_ignoring_interval": flat_mg / (mgkg * r["wref"]),
                     "flat_band20_low_kg": r["wref"] * lo, "flat_band20_high_kg": r["wref"] * hi,
                     "flat_heavy10_kg": r["wref"] * hi10, "basis": basis})
    return pd.DataFrame(rows)


def source_range_table(d: pd.DataFrame, thr: pd.DataFrame) -> pd.DataFrame:
    """Compare the +/-20% limits with the weight range of each source population (min and max as reported)."""
    rng_ = pd.read_csv(ROOT / "inputs" / "source_weight_ranges.csv")
    rows = []
    for _, r in thr[(thr["role"] == "main") & (thr["delta"].isin([BAND_DELTA, 0.30]))].iterrows():
        s = rng_[rng_["drug"] == r["drug"]].iloc[0]
        lo, hi = pd.to_numeric(s["min_kg"], errors="coerce"), pd.to_numeric(s["max_kg"], errors="coerce")
        for regimen in ("flat", "mgkg"):
            for side, col in (("light", f"{regimen}_low_kg"), ("heavy", f"{regimen}_high_kg")):
                w = r[col]
                if pd.isna(lo):
                    flag = "source range not available"
                elif w < lo or w > hi:
                    flag = "outside source range (extrapolation)"
                else:
                    flag = "inside source min-max"
                rows.append({"drug": r["drug"], "delta": r["delta"], "regimen": regimen, "side": side, "limit_kg": w,
                             "source_min_kg": lo, "source_max_kg": hi, "flag": flag})
    return pd.DataFrame(rows)


def shift_spread_table(d: pd.DataFrame) -> pd.DataFrame:
    """Fraction outside the 0.8-1.2 band: spread only (median = BWref) and location shift only (CV 25%)."""
    rows = []
    for _, r in d[d["role"] == "main"].iterrows():
        for regimen in ("flat", "mgkg"):
            for cv in SPREAD_CVS:
                sg = pm.lognormal_sigma_from_cv(cv)
                rows.append({"drug": r["drug"], "regimen": regimen, "analysis": "spread only (median = BWref)",
                             "median_kg": r["wref"], "cv": cv,
                             "frac_outside_pm20": pm.fraction_outside_band(r["b"], regimen, r["wref"], sg, r["wref"])})
            sg = pm.lognormal_sigma_from_cv(0.25)
            for med in SHIFT_MEDIANS:
                rows.append({"drug": r["drug"], "regimen": regimen, "analysis": "location shift (CV 25%)",
                             "median_kg": med, "cv": 0.25,
                             "frac_outside_pm20": pm.fraction_outside_band(r["b"], regimen, med, sg, r["wref"])})
    return pd.DataFrame(rows)


def ode_check_table(d: pd.DataFrame) -> pd.DataFrame:
    rows = []
    main = d[d["role"] == "main"]
    tau = 21.0
    for _, r in main.iterrows():
        vss, cl, tf, tm = trough_functions(r, tau)
        for x in ODE_X:
            for regimen in ("flat", "mgkg"):
                dose = 1.0 if regimen == "flat" else x
                tr, auc, _ = simulate_repeated_bolus(dose, float(cl(x)), float(vss(x)), tau)
                tr_cf = float((tf if regimen == "flat" else tm)(x))
                auc_cf = float(pm.auc_ss_one_comp(dose, cl(x)))
                rows.append({"drug": r["drug"], "x": x, "regimen": regimen,
                             "trough_ode": tr, "trough_closed": tr_cf, "trough_rel_err": abs(tr - tr_cf) / tr_cf,
                             "auc_ode": auc, "auc_closed": auc_cf, "auc_rel_err": abs(auc - auc_cf) / auc_cf})
    return pd.DataFrame(rows)


def excluded_checks() -> dict:
    """Implied power exponents from the percent changes quoted for trastuzumab (Quartino et al.)."""
    e = 0.967
    return {
        "trastuzumab_linear_CL_reported_exponent": e,
        "implied_exponent_from_minus27pct_at_46kg_vs_66kg": float(np.log(0.73) / np.log(46 / 66)),
        "implied_exponent_from_plus43pct_at_98kg_vs_66kg": float(np.log(1.43) / np.log(98 / 66)),
        "change_predicted_by_reported_exponent_at_46kg_pct": float(((46 / 66) ** e - 1) * 100),
        "change_predicted_by_reported_exponent_at_98kg_pct": float(((98 / 66) ** e - 1) * 100),
        "note": ("The reported exponent predicts about -29% and +46% against the quoted -27% and +43%; the covariate "
                 "form and reference weight are not in the main text, so the form could not be confirmed."),
    }


def multicomp_ode_check(d: pd.DataFrame) -> pd.DataFrame:
    """Matrix-exponential steady-state trough versus repeated-dose ODE integration for the multi-compartment model."""
    rows = []
    for _, r in d[d["role"] == "main"].iterrows():
        tau = SOURCE_TAU[r["drug"]]
        for x in (0.6, 1.8):
            cl = r["cl_l_day"] * x ** r["b"]
            vc = r["vc_l"] * x ** r["c_vc_tr"]
            per = [(q * x ** r["b"], vp * x ** r["c_vp_tr"]) for q, vp in r["peripherals"]]
            tr_ode = simulate_repeated_bolus_multicomp(1.0, cl, vc, per, tau, n_doses=300)
            tr_mat = pm.trough_ss_multicomp(1.0, cl, vc, per, tau)
            rows.append({"drug": r["drug"], "x": x, "tau_day": tau, "trough_ode": tr_ode, "trough_matrix": tr_mat,
                         "rel_err": abs(tr_ode - tr_mat) / tr_mat})
    return pd.DataFrame(rows)


def run(outdir: Path) -> dict:
    outdir.mkdir(parents=True, exist_ok=True)
    rng = np.random.default_rng(SEED)
    d = load_drugs(ROOT / "inputs" / "parameter_table.csv")
    d.drop(columns=["peripherals"]).to_csv(outdir / "drug_inputs_used.csv", index=False, float_format="%.6g")
    thr = thresholds_table(d)
    unc = uncertainty_table(d, rng)
    var, grid = variance_table(d, rng)
    dist = distribution_table(d, rng)
    dm = dose_matching_table(d)
    tro = trough_table(d)
    ode = ode_check_table(d)
    two = two_compartment_table(d)
    cemi = cemiplimab_sensitivity(d)
    logsym = log_symmetric_table(d)
    lab = label_dose_table(d)
    srng = source_range_table(d, thr)
    shsp = shift_spread_table(d)
    mc_ode = multicomp_ode_check(d)
    for name, df in (("thresholds", thr), ("thresholds_uncertainty", unc), ("variance_crossover", var),
                     ("variance_grid", grid), ("distribution_sensitivity", dist),
                     ("dose_matching_sensitivity", dm), ("trough_approximation", tro), ("ode_check", ode),
                     ("trough_two_compartment", two), ("cemiplimab_trough_sensitivity", cemi),
                     ("thresholds_log_symmetric", logsym), ("label_dose_matching", lab),
                     ("threshold_vs_source_range", srng), ("distribution_shift_spread", shsp),
                     ("multicomp_ode_check", mc_ode)):
        df.to_csv(outdir / f"{name}.csv", index=False, float_format="%.6g")
    main = d[d["role"] == "main"]
    summary = {
        "seed": SEED, "n_sim": N_SIM, "mc_n": MC_N,
        "n_drugs_main": int(len(main)),
        "drugs_main": main["drug"].tolist(),
        "max_ode_rel_err_trough": float(ode["trough_rel_err"].max()),
        "max_ode_rel_err_auc": float(ode["auc_rel_err"].max()),
        "max_abs_diff_sd_theory_vs_mc": float(max((var["sd_lnE_flat_theory"] - var["sd_lnE_flat_mc"]).abs().max(),
                                                  (var["sd_lnE_mgkg_theory"] - var["sd_lnE_mgkg_mc"]).abs().max())),
        "max_abs_diff_fraction_outside_exact_vs_mc": float((dist["frac_outside_pm20"] - dist["frac_outside_pm20_mc"]).abs().max()),
        "max_rel_diff_delta_vs_sim_width": float(
            (((unc["delta_high"] - unc["delta_low"]) - (unc["sim_high"] - unc["sim_low"])).abs()
             / (unc["delta_high"] - unc["delta_low"])).max()),
        "max_rel_err_multicomp_matrix_vs_ode": float(mc_ode["rel_err"].max()),
        "b_range_main": [float(main["b"].min()), float(main["b"].max())],
        "n_drugs_b_below_0.5": int((main["b"] < 0.5).sum()),
        "excluded_trastuzumab_check": excluded_checks(),
    }
    (outdir / "summary.json").write_text(json.dumps(summary, indent=2, ensure_ascii=False), encoding="utf-8")
    hashes = {p.name: hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(outdir.glob("*.csv"))}
    hashes["summary.json"] = hashlib.sha256((outdir / "summary.json").read_bytes()).hexdigest()
    (outdir / "sha256.json").write_text(json.dumps(hashes, indent=2), encoding="utf-8")
    return summary


if __name__ == "__main__":
    out = Path(sys.argv[1]) if len(sys.argv) > 1 else ROOT / "results"
    s = run(out)
    print(json.dumps(s, indent=2))
