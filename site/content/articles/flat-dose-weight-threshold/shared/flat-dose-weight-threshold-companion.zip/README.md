# Flat-dose weight thresholds from published clearance weight exponents

Companion code for the note "Is there a body-weight threshold for flat dosing? Computed from published clearance weight exponents of nine antibodies" (Japanese and English).

## What is here

| File | Role |
| --- | --- |
| `inputs/parameter_table.csv` | Exponents and typical values transcribed from published tables (fields: entry_id, drug, role, source_doi, source_location, parameter, value, unit, rse_percent, ci_low, ci_high, ci_type, population, covariate_model_form, reference_weight_kg, reference_weight_basis, model_form_status, data_origin, notes) |
| `inputs/source_weight_ranges.csv` | Weight range (min, max) of each source population, with NOT AVAILABLE where the main text gives none |
| `inputs/not_verified.csv` | Antibodies excluded or not verified, with the reason and what was read |
| `powermodel.py` | Closed forms: exposure ratios, threshold weights, delta-method SE, variance, fraction outside a band, one-compartment and multi-compartment trough, log-symmetric band |
| `odecheck.py` | ODE simulation of repeated IV bolus dosing (one- and multi-compartment) used to check the implementation of the closed forms |
| `analysis.py` | Computes thresholds, uncertainty (delta method, parametric simulation, CI endpoints), variance crossover, weight-distribution scenarios (including location-shift and spread analyses), dose-matching sensitivity and label-dose s, source weight-range flags, trough approximation (1- and 2/3-compartment, cemiplimab BMI sensitivity); writes `results/` |
| `figures.py` | Figures (`figures/`) |
| `test_analysis.py` | 15 checks: closed forms vs ODE, multi-compartment matrix vs ODE, log-symmetric band, label-dose s, source-range flags, ratio identities, threshold inversion, b = 0.5 variance equality, monotonicity, exact vs simulated proportions, delta method vs simulation, seed reproducibility, input completeness |
| `check_reproducibility.py` | Runs the analysis twice and compares SHA-256 hashes of the result files |

## Run

```bash
pip install -r requirements.txt
python -X utf8 analysis.py
python -X utf8 figures.py
python -X utf8 -m pytest test_analysis.py -q
python -X utf8 check_reproducibility.py
```

Random seed: 20261105 (set in `analysis.py`). Python 3.12; NumPy 2.2; SciPy 1.14; pandas 2.2; matplotlib 3.9; pytest 9. Run time is about two minutes.

## Scope

Exposure calculations under a power model of clearance, the reported exponents and assumed log-normal weight scenarios. A weight threshold is a definition (percent deviation in exposure), not a clinical cut-off. Exposure differences are not efficacy differences. No dose is recommended. The log-normal weight scenarios are assumptions, not population measurements.

## Licence

Code: MIT License. Result files and figures: CC BY 4.0. The input tables contain only transcribed values and table locations; the source papers keep their own licences (see `LICENSE` and the article). Licence choices are as written in `LICENSE`.
