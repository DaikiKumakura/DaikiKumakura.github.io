# Macrophage expression panels

An independent descriptive reanalysis of GSE199378 (Modak et al., JCI Insight 2022,
https://doi.org/10.1172/jci.insight.155022; article CC BY 4.0).

## Reproduce with the bundled fixed-panel excerpt

Python 3.12. Install requirements.txt, then:

```text
python analysis.py
python -m unittest test_analysis.py
python plot.py
```

The excerpt contains all 21,229 source-provided cells and 26 predeclared genes.
inputs/cells.csv records original row order, anonymized donor, stimulation-condition
label, and sample identifier. inputs/expression.npz contains the corresponding X
values from the processed object; it is not raw UMI counts. No cells were added or
removed, and no batch integration or new normalization was performed.

GEO states that X is scran-normalized log1p expression. The layer named `counts`
is identical to X and has noninteger values. We do not use it as raw counts, do
count-model differential expression, or infer library sizes from it. Original QC,
normalization, and gene filtering are accepted, not independently reproduced.

## Optional full-source verification

```text
python fetch_data.py
python extract.py
```

This downloads about 300 MB of compressed data from NCBI and verifies SHA-256.
Decompression and processing require additional disk and memory. Check inputs/provenance.json
for the exact source URL and hash. Re-extraction yields the same numerical arrays;
ZIP-container timestamps in NPZ files need not have identical bytes.

## Analysis definition

panels.json contains six small, author-chosen illustrative panels, fixed before
reading the expression matrix. They are not the complete program definitions from
the 2026 Immunity perspective, learned regulatory programs, calibrated functional
readouts, or independent biological axes. Panel members can co-regulate.

1. Calculate the mean log1p expression of each gene within each of six donor-condition
   samples (two donors, M1 / M2a / M2c stimulation conditions).
2. Center and scale each gene across these six means, giving each sample equal
   weight; use population SD (ddof=0).
3. Average gene z scores within each panel. A score of zero refers to this dataset's
   average, not inactivity. Scale parameters include all six samples, so this is
   descriptive visualization, not held-out prediction or validation.
4. Report M2a minus M2c separately for each donor. Check every leave-one-gene-out
   panel, keeping the original gene scaling. Also compare gene contrast signs using
   mean log1p vs mean expm1(X), without equating their numerical units.
5. Plot p times the M2a panel mean plus (1-p) times the M2c mean, for 0 <= p <= 1.
   This is static reweighting of observed conditional means, not a temporal model,
   measured mixture experiment, treatment response, depletion, or reprogramming.

Two donors are the biological units. Cell counts characterize the sampled
distributions; they do not turn this into a 21,229-donor study. No cell-level
p-values, population confidence intervals, treatment efficacy estimates, or claim
of generalizable donor prediction is made. M0 and tissue context are absent.

## Attribution and panel rationale

The data and experimental definitions come from Modak et al. (2022),
https://www.ncbi.nlm.nih.gov/geo/query/acc.cgi?acc=GSE199378.
Selected receptor genes connect to the source paper's Fig. 7; the additional small
panels summarize IFN-associated, antigen-processing and type-2-associated transcripts.
They were selected for illustration and have no externally validated score threshold.
The 2026 perspective https://doi.org/10.1016/j.immuni.2026.09.015 motivates a modular
view; this analysis does not reproduce its proposed complete program catalogue.

This archive includes a small expression-data excerpt and original code and figures.
It does not redistribute the source manuscript or claim ownership of its data.
