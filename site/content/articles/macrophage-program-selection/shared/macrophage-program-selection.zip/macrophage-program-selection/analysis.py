"""Describe donor-paired expression panels; cells are not biological replicates."""
import json
from pathlib import Path
import numpy as np
import pandas as pd

HERE = Path(__file__).resolve().parent
CONDITIONS = ['M1', 'M2a', 'M2c']


def standardize_groups(group_means):
    """Equal weight for each donor-condition mean, population SD (ddof=0)."""
    center = group_means.mean(axis=0)
    scale = group_means.std(axis=0, ddof=0)
    if np.any(scale <= 0):
        raise ValueError('Constant gene across groups')
    return (group_means - center) / scale, center, scale


def mixture(a, c, fraction_a):
    """Static weighted average on the specified expression-score scale."""
    return fraction_a * a + (1 - fraction_a) * c


def main():
    archive = np.load(HERE / 'inputs/expression.npz', allow_pickle=False)
    x, genes = archive['values'].astype(float), archive['genes'].tolist()
    cells = pd.read_csv(HERE / 'inputs/cells.csv', dtype={'donor': str, 'sample': str})
    panels = json.loads((HERE / 'panels.json').read_text())
    assert x.shape == (len(cells), len(genes)) and np.isfinite(x).all()
    assert np.array_equal(cells.row, np.arange(len(cells)))
    groups = [(d, c) for d in sorted(cells.donor.unique()) for c in CONDITIONS]
    means, sizes = [], []
    for d, c in groups:
        mask = ((cells.donor == d) & (cells.condition == c)).to_numpy()
        assert mask.any() and cells.loc[mask, 'sample'].nunique() == 1
        means.append(x[mask].mean(axis=0))
        sizes.append(int(mask.sum()))
    means = np.asarray(means)
    z, center, scale = standardize_groups(means)
    score_rows, contrast_rows, gene_rows, sensitivity = [], [], [], []
    for i, (d, c) in enumerate(groups):
        for j, gene in enumerate(genes):
            mask = ((cells.donor == d) & (cells.condition == c)).to_numpy()
            gene_rows.append(dict(donor=d, condition=c, gene=gene,
                                  mean_log_expression=means[i, j],
                                  detected_fraction=float((x[mask, j] > 0).mean())))
        for panel, members in panels.items():
            js = [genes.index(g) for g in members]
            score_rows.append(dict(donor=d, condition=c, panel=panel,
                                   score=float(z[i, js].mean()), cells=sizes[i]))
    for d in sorted(cells.donor.unique()):
        ia, ic = groups.index((d, 'M2a')), groups.index((d, 'M2c'))
        for panel, members in panels.items():
            js = [genes.index(g) for g in members]
            diff = float((z[ia, js] - z[ic, js]).mean())
            linear_diff = np.expm1(x[((cells.donor == d) & (cells.condition == 'M2a')).to_numpy()][:, js]).mean(axis=0) - np.expm1(x[((cells.donor == d) & (cells.condition == 'M2c')).to_numpy()][:, js]).mean(axis=0)
            # Compare signs for each gene on log-mean vs linear-mean scales, not units.
            signs = np.sign(means[ia, js] - means[ic, js]) == np.sign(linear_diff)
            contrast_rows.append(dict(donor=d, panel=panel, m2a_minus_m2c=diff,
                                      linear_log_gene_sign_agreement=float(signs.mean())))
            for drop in members:
                keep = [j for j in js if genes[j] != drop]
                reduced = float((z[ia, keep] - z[ic, keep]).mean())
                sensitivity.append(dict(donor=d, panel=panel, omitted_gene=drop,
                                        contrast=reduced, same_sign=bool(np.sign(reduced) == np.sign(diff))))
    out = HERE / 'results'
    out.mkdir(exist_ok=True)
    pd.DataFrame(score_rows).to_csv(out / 'panel_scores.csv', index=False, float_format='%.9g')
    pd.DataFrame(contrast_rows).to_csv(out / 'contrasts.csv', index=False, float_format='%.9g')
    pd.DataFrame(gene_rows).to_csv(out / 'gene_summary.csv', index=False, float_format='%.9g')
    pd.DataFrame(sensitivity).to_csv(out / 'leave_one_gene_out.csv', index=False, float_format='%.9g')
    summary = dict(cells=len(cells), genes=len(genes), donors=len(set(cells.donor)),
                   groups=[dict(donor=d, condition=c, cells=n) for (d,c),n in zip(groups,sizes)],
                   primary_contrast='M2a minus M2c',
                   panels=[dict(panel=p, contrasts=[r['m2a_minus_m2c'] for r in contrast_rows if r['panel']==p],
                                leave_one_gene_out_sign_agreement=float(np.mean([r['same_sign'] for r in sensitivity if r['panel']==p]))) for p in panels],
                   scale='Mean of gene z scores; center/SD estimated from six equally weighted sample means',
                   inference='Descriptive only; two donors, no cell-based p-values or population confidence intervals')
    (out / 'summary.json').write_text(json.dumps(summary, indent=2) + '\n')
    print(json.dumps(summary, indent=2))


if __name__ == '__main__':
    main()
