"""Fetch the public processed object for optional re-extraction; no credentials."""
import hashlib
import json
from pathlib import Path
from urllib.request import urlretrieve

HERE = Path(__file__).resolve().parent


def main():
    p = json.loads((HERE / 'inputs/provenance.json').read_text())
    dest = HERE / 'sources/all_samples_processed.h5ad.gz'
    dest.parent.mkdir(exist_ok=True)
    if not dest.exists():
        urlretrieve(p['source_url'], dest)
    if hashlib.sha256(dest.read_bytes()).hexdigest() != p['source_sha256']:
        raise ValueError('Source digest mismatch; preserve file and check source version')
    print('Source digest verified')


if __name__ == '__main__':
    main()
