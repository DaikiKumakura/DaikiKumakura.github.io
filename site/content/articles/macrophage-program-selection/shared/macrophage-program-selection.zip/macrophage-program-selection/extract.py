"""Extract a fixed gene panel from the public GSE199378 processed object."""
from pathlib import Path
import gzip
import hashlib
import json
import shutil
import csv
import h5py
import numpy as np
from scipy.sparse import csr_matrix

HERE = Path(__file__).resolve().parent


def read_sparse(group):
    return csr_matrix((group['data'][:], group['indices'][:], group['indptr'][:]),
                      shape=tuple(group.attrs['shape']))


def categorical(h, name):
    codes = h['obs'][name][:]
    cats = h['obs/__categories'][name].asstr()[:]
    assert (codes >= 0).all()
    return cats[codes]


def main():
    source = HERE / 'sources/all_samples_processed.h5ad.gz'
    decompressed = source.with_suffix('')
    if not decompressed.exists():
        with gzip.open(source, 'rb') as src, decompressed.open('wb') as dst:
            shutil.copyfileobj(src, dst)
    panels = json.loads((HERE / 'panels.json').read_text())
    genes = sorted({g for v in panels.values() for g in v})
    target = HERE / 'inputs'
    target.mkdir(exist_ok=True)
    with h5py.File(decompressed) as h:
        names = h['var/index'].asstr()[:].tolist()
        assert len(set(names)) == len(names)
        missing = sorted(set(genes) - set(names))
        if missing:
            raise ValueError(f'Predeclared genes missing: {missing}')
        x = read_sparse(h['X'])
        assert x.shape[0] == len(h['obs/donor'])
        values = x[:, [names.index(g) for g in genes]].toarray()
        assert np.isfinite(values).all() and values.min() >= 0
        np.savez_compressed(target / 'expression.npz', values=values,
                            genes=np.asarray(genes, dtype='U'))
        donors = categorical(h, 'donor')
        conditions = categorical(h, 'mac_name')
        samples = categorical(h, 'Sample_Name')
        with (target / 'cells.csv').open('w', newline='', encoding='utf-8') as f:
            writer = csv.writer(f, lineterminator='\n')
            writer.writerow(['row', 'donor', 'condition', 'sample'])
            writer.writerows(zip(range(len(donors)), donors, conditions, samples))
        counts = read_sparse(h['layers/counts'])
        mislabeled_same = (x != counts).nnz == 0
    record = {
        'accession': 'GSE199378',
        'source_url': 'https://ftp.ncbi.nlm.nih.gov/geo/series/GSE199nnn/GSE199378/suppl/GSE199378_all_samples_processed.h5ad.gz',
        'source_sha256': hashlib.sha256(source.read_bytes()).hexdigest(),
        'source_shape': list(x.shape), 'selected_genes': genes,
        'layer': 'X', 'scale': 'Source-provided scran-normalized log1p expression',
        'counts_layer_identical_to_X': mislabeled_same,
        'warning': 'The layer named counts is identical to X and noninteger; not used as raw UMI counts.',
        'article': 'https://doi.org/10.1172/jci.insight.155022',
        'attribution': 'Modak et al., JCI Insight 2022;7(11):e155022, CC BY 4.0',
        'scope': 'Fixed-panel excerpt of all source-provided cells; no new QC or normalization.'
    }
    (target / 'provenance.json').write_text(json.dumps(record, indent=2) + '\n')
    print(json.dumps({'shape': list(values.shape), 'counts_layer_identical_to_X': mislabeled_same}))


if __name__ == '__main__':
    main()
