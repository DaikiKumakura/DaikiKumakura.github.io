"""Original plots from the fixed-panel reanalysis, not source-paper figures."""
import json
from pathlib import Path
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from analysis import mixture

HERE = Path(__file__).resolve().parent
SCORES = pd.read_csv(HERE/'results/panel_scores.csv', dtype={'donor': str})
PANELS = list(json.loads((HERE/'panels.json').read_text()))
LABELS = ['IFN-associated', 'Antigen processing', 'Co-stimulatory ligands',
          'Checkpoint ligands', 'Type-2-associated', 'Uptake receptors']
out = HERE/'figures'
out.mkdir(exist_ok=True)
rows = [(str(d), c) for d in [1,2] for c in ['M1','M2a','M2c']]
values = np.array([[SCORES.loc[(SCORES.donor==d)&(SCORES.condition==c)&(SCORES.panel==p),'score'].item()
                    for p in PANELS] for d,c in rows])
fig, ax = plt.subplots(figsize=(10,4.8), layout='constrained')
im = ax.imshow(values, cmap='RdBu_r', vmin=-1.8, vmax=1.8, aspect='auto')
ax.set(xticks=range(6), xticklabels=LABELS,
       yticks=range(6), yticklabels=[f'Donor {d} / {c}' for d,c in rows],
       title='Same M2 label, different expression profiles')
plt.setp(ax.get_xticklabels(), rotation=25, ha='right', fontsize=9)
for i in range(6):
    for j in range(6):
        ax.text(j,i,f'{values[i,j]:.2f}',ha='center',va='center',fontsize=9,
                color='white' if abs(values[i,j])>1.05 else 'black')
ax.axhline(2.5,color='black',linewidth=1)
fig.colorbar(im,ax=ax,label='Mean gene z score across six sample means')
fig.savefig(out/'program-panels.png',dpi=180,metadata={'Software':'Matplotlib'})

fig, axes = plt.subplots(1,2,figsize=(10.8,4.7),layout='constrained')
pgrid=np.linspace(0,1,101)
colors=['#227c9d','#c3652e']
for donor,color in zip(['1','2'],colors):
    sub=SCORES[(SCORES.donor==donor)&(SCORES.panel=='costimulation')].set_index('condition').score
    axes[0].plot(100*pgrid,mixture(sub['M2a'],sub['M2c'],pgrid),label=f'Donor {donor}',color=color)
axes[0].set(xlabel='M2a fraction within a hypothetical M2 pool (%)',ylabel='Pooled co-stimulation panel score',
            title='Changing the mixture changes the score')
axes[0].legend(frameon=False)
genes=pd.read_csv(HERE/'results/gene_summary.csv',dtype={'donor':str})
markers=['MRC1','CD163','CD86','ICOSLG','CD274','PDCD1LG2']
for donor,color,offset in zip(['1','2'],colors,[-.12,.12]):
    diffs=[]
    for gene in markers:
        sub=genes[(genes.donor==donor)&(genes.gene==gene)].set_index('condition').mean_log_expression
        diffs.append(sub['M2a']-sub['M2c'])
    axes[1].scatter(diffs,np.arange(len(markers))+offset,label=f'Donor {donor}',color=color,s=34)
axes[1].axvline(0,color='gray',linewidth=.8)
axes[1].set(yticks=range(len(markers)),yticklabels=markers,xlabel='M2a minus M2c: mean log1p expression',
            title='Markers do not move as a single block')
axes[1].invert_yaxis()
for ax in axes:
    ax.spines[['top','right']].set_visible(False)
fig.suptitle('GSE199378: descriptive reanalysis, 2 donors / 21,229 cells',fontsize=12)
fig.savefig(out/'mixture-and-markers.png',dpi=180,metadata={'Software':'Matplotlib'})
