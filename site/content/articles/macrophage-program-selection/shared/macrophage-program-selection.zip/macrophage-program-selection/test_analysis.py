import unittest
import numpy as np
from analysis import standardize_groups, mixture


class AnalysisTests(unittest.TestCase):
    def test_equal_sample_weight(self):
        a = np.array([[1., 3.], [2., 8.], [7., 1.]])
        z, _, _ = standardize_groups(a)
        np.testing.assert_allclose(z.mean(axis=0), 0, atol=1e-14)
        np.testing.assert_allclose(z.std(axis=0), 1)

    def test_mixture_is_static_convex_combination(self):
        for p in [0., .1, .5, .9, 1.]:
            self.assertAlmostEqual(mixture(2., -1., p), 3*p-1)
        self.assertEqual(mixture(2., -1., 0), -1.)
        self.assertEqual(mixture(2., -1., 1), 2.)

    def test_constant_gene_rejected(self):
        with self.assertRaises(ValueError):
            standardize_groups(np.ones((3, 2)))


if __name__ == '__main__':
    unittest.main()
