from math import expm1

for name, ae, death in [("A",.10,.30),("B",.08,.02)]:
    net = -expm1(-6*ae)
    observed = -ae/(ae+death)*expm1(-6*(ae+death))
    print(f"{name} net={net:.6f} observed={observed:.6f}")
