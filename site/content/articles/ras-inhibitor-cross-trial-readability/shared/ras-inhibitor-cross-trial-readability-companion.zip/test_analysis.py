import numpy as np
import pandas as pd
from scipy.stats import binomtest

import analysis as an


def test_clopper_pearson_matches_scipy_exact_interval():
    for k, n in [(10, 24), (14, 27), (48, 171), (0, 20), (20, 20)]:
        ref = binomtest(k, n).proportion_ci(confidence_level=0.95, method="exact")
        lo, hi = an.clopper_pearson(k, n)
        assert abs(lo - ref.low) < 1e-9 and abs(hi - ref.high) < 1e-9


def test_reconstructed_intervals_reproduce_reported_ones_within_one_point():
    tab = pd.read_csv(an.OUT / "orr-intervals.csv").dropna(subset=["max_abs_gap_to_reported_pt"])
    assert (tab.max_abs_gap_to_reported_pt < 1.0).all()


def test_newcombe_difference_contains_point_estimate_and_is_symmetric_in_sign():
    d, lo, hi = an.newcombe_difference(48, 171, 23, 174)
    assert lo < d < hi
    d2, lo2, hi2 = an.newcombe_difference(23, 174, 48, 171)
    assert abs(d + d2) < 1e-12 and abs(lo + hi2) < 1e-9 and abs(hi + lo2) < 1e-9
