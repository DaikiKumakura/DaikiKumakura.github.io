"""How far can RAS-inhibitor trial results shown side by side be compared? Exact intervals, reconstructed counts, and a control-arm anchor.

Inputs (inputs/arms.csv) are values reported in the sources named in the file. Counts of responders are reconstructed as round(percent * n);
an exact (Clopper-Pearson) interval is computed from the reconstructed count and compared with the reported interval.
Krascendo 1 reports ORR in a response-evaluable set (161 divarasib and 167 control patients after excluding 6 and 4 without measurable disease).
"""
from pathlib import Path

import numpy as np
import pandas as pd
from scipy.stats import beta

ROOT = Path(__file__).resolve().parent
OUT = ROOT / "results"
OUT.mkdir(exist_ok=True)


def clopper_pearson(k: int, n: int, level: float = 0.95) -> tuple[float, float]:
    a = (1 - level) / 2
    lo = 0.0 if k == 0 else beta.ppf(a, k, n - k + 1)
    hi = 1.0 if k == n else beta.ppf(1 - a, k + 1, n - k)
    return float(lo), float(hi)


def newcombe_difference(k1: int, n1: int, k2: int, n2: int, level: float = 0.95) -> tuple[float, float, float]:
    """Newcombe hybrid score interval for p1 - p2 (Wilson intervals for each proportion)."""
    from scipy.stats import norm
    z = norm.ppf(1 - (1 - level) / 2)

    def wilson(k, n):
        p = k / n
        d = 1 + z * z / n
        c = (p + z * z / (2 * n)) / d
        h = z * np.sqrt(p * (1 - p) / n + z * z / (4 * n * n)) / d
        return c - h, c + h

    l1, u1 = wilson(k1, n1)
    l2, u2 = wilson(k2, n2)
    p1, p2 = k1 / n1, k2 / n2
    d = p1 - p2
    return d, d - np.sqrt((p1 - l1) ** 2 + (u2 - p2) ** 2), d + np.sqrt((u1 - p1) ** 2 + (p2 - l2) ** 2)


def main() -> None:
    arms = pd.read_csv(ROOT / "inputs" / "arms.csv")
    rows = []
    for r in arms.itertuples():
        k = int(round(r.orr_reported_pct / 100 * r.orr_n))
        lo, hi = clopper_pearson(k, int(r.orr_n))
        recon_ok = (not np.isnan(r.ci_lo_reported))
        rows.append(dict(trial=r.trial, arm=r.arm, n=int(r.orr_n), randomized_n=int(r.randomized_n), orr_reported_pct=r.orr_reported_pct, responders_reconstructed=k,
                         orr_from_counts_pct=100 * k / r.orr_n, ci_lo_exact=100 * lo, ci_hi_exact=100 * hi,
                         ci_lo_reported=r.ci_lo_reported, ci_hi_reported=r.ci_hi_reported,
                         max_abs_gap_to_reported_pt=(max(abs(100 * lo - r.ci_lo_reported), abs(100 * hi - r.ci_hi_reported)) if recon_ok else np.nan),
                         denominator_is_randomized_n=bool(r.orr_n == r.randomized_n)))
    tab = pd.DataFrame(rows)
    tab.round(2).to_csv(OUT / "orr-intervals.csv", index=False, lineterminator=chr(10))
    pd.set_option("display.width", 250)
    print(tab.round(1).to_string())

    # randomized pairs: difference in ORR with a Newcombe interval (only where counts are reconstructible)
    pairs = []
    for trial, (a, b) in {"CodeBreaK 200": ("sotorasib", "docetaxel"), "RASolute 302 (overall population)": ("daraxonrasib", "chemotherapy")}.items():
        x = tab[(tab.trial == trial) & (tab.arm == a)].iloc[0]
        y = tab[(tab.trial == trial) & (tab.arm == b)].iloc[0]
        d, lo, hi = newcombe_difference(int(x.responders_reconstructed), int(x.n), int(y.responders_reconstructed), int(y.n))
        pairs.append(dict(trial=trial, experimental=a, control=b, diff_pt=100 * d, lo=100 * lo, hi=100 * hi))
    pd.DataFrame(pairs).round(2).to_csv(OUT / "orr-differences.csv", index=False, lineterminator=chr(10))
    print(pd.DataFrame(pairs).round(1).to_string())

    # control-arm anchor: sotorasib in CodeBreaK 200 versus the sotorasib-or-adagrasib arm of Krascendo 1
    cb = tab[(tab.trial == "CodeBreaK 200") & (tab.arm == "sotorasib")].iloc[0]
    kr = arms[(arms.trial == "Krascendo 1") & (arms.arm == "sotorasib or adagrasib")].iloc[0]
    anchor = dict(orr_codebreak_pct=cb.orr_reported_pct, orr_codebreak_ci_lo=cb.ci_lo_exact, orr_codebreak_ci_hi=cb.ci_hi_exact, orr_krascendo_control_pct=kr.orr_reported_pct,
                  krascendo_control_orr_inside_codebreak_interval=bool(cb.ci_lo_exact <= kr.orr_reported_pct <= cb.ci_hi_exact),
                  pfs_codebreak=5.6, pfs_codebreak_ci="4.3-7.8", pfs_krascendo_control=kr.median_pfs_months)
    kc = tab[(tab.trial == "Krascendo 1") & (tab.arm == "sotorasib or adagrasib")].iloc[0]
    d, lo, hi = newcombe_difference(int(kc.responders_reconstructed), int(kc.n), int(cb.responders_reconstructed), int(cb.n))
    anchor.update(orr_difference_krascendo_control_minus_codebreak_pt=100 * d, orr_difference_lo=100 * lo, orr_difference_hi=100 * hi)
    pd.DataFrame([anchor]).round(2).to_csv(OUT / "control-arm-anchor.csv", index=False, lineterminator=chr(10))
    print(anchor)


if __name__ == "__main__":
    main()
