"""Figure 1: objective response rate with exact 95% intervals (reconstructed counts) for arms shown in the infographic."""
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parent
(ROOT / "figures").mkdir(exist_ok=True)
t = pd.read_csv(ROOT / "results" / "orr-intervals.csv")
order = [
    ("CodeBreaK 200", "sotorasib"), ("CodeBreaK 200", "docetaxel"),
    ("Krascendo 1", "divarasib"), ("Krascendo 1", "sotorasib or adagrasib"),
    ("RASolute 302 (overall population)", "daraxonrasib"), ("RASolute 302 (overall population)", "chemotherapy"),
    ("Elironrasib phase 1", "elironrasib 200 mg twice daily"), ("Zoldonrasib phase 1", "zoldonrasib 1200 mg once daily"),
]
labels = ["CodeBreaK 200: sotorasib (NSCLC)", "CodeBreaK 200: docetaxel", "Krascendo 1: divarasib (NSCLC)*", "Krascendo 1: sotorasib or adagrasib*",
          "RASolute 302: daraxonrasib (PDAC)", "RASolute 302: chemotherapy", "Phase 1: elironrasib (NSCLC, n = 24)", "Phase 1: zoldonrasib (NSCLC, n = 27)"]
colors = ["#0072B2", "#999999", "#0072B2", "#999999", "#0072B2", "#999999", "#D55E00", "#D55E00"]
fig, ax = plt.subplots(figsize=(7.6, 4.4), dpi=150)
for i, ((tr, arm), lab, c) in enumerate(zip(order, labels, colors)):
    r = t[(t.trial == tr) & (t.arm == arm)].iloc[0]
    y = len(order) - i
    star = "Krascendo" in tr
    ax.hlines(y, r.ci_lo_exact, r.ci_hi_exact, color=c, lw=3, alpha=0.5 if star else 1.0)
    ax.plot(r.orr_reported_pct, y, "o", color=c, ms=7, mfc="white" if star else c)
ax.set_yticks(range(len(order), 0, -1))
ax.set_yticklabels(labels, fontsize=8)
ax.set_xlabel("Objective response rate (%) with exact 95% interval")
ax.set_xlim(0, 80)
ax.set_title("Arms shown side by side in the infographic (blue: experimental, grey: control, orange: single arm)", fontsize=8)
fig.text(0.01, 0.01, "* Krascendo 1: ORR from the response-evaluable set (161 and 167 patients); the interval is computed from the reconstructed count.", fontsize=6.5)
fig.tight_layout(rect=(0, 0.03, 1, 1))
fig.savefig(ROOT / "figures" / "01-orr-intervals.png")
