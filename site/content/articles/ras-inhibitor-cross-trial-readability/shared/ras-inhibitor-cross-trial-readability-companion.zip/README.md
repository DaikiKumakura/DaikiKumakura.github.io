# RAS inhibitor cross-trial readability: companion code

Exact (Clopper-Pearson) intervals from reconstructed responder counts, Newcombe intervals for randomized differences, and a control-arm anchor check, for arms shown in a RAS-inhibitor results figure.

- `inputs/arms.csv`: reported values with source level.
- `analysis.py`: intervals, differences, anchor check.
- `figures.py`: Figure 1.
- `test_analysis.py`: checks (`python -m pytest test_analysis.py`).
- `results/`: CSV outputs.

Inputs are values from published reports. No patient data. Requires Python 3 with numpy, scipy, pandas, matplotlib.
