from pathlib import Path
import json,hashlib,zipfile
import numpy as np,pandas as pd
from scipy.stats import mannwhitneyu
from scipy.special import expit
R=Path(__file__).resolve().parent;O=R/'results'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def run():
 m=json.loads((O/'model-frozen.json').read_text());assert sha(O/'model-frozen.json')==(O/'model-frozen.sha256').read_text().strip()
 assert sha(R/'analysis-plan.md')==m['plan_sha256'];assert sha(R/'analyze.py')==m['code_sha256'];assert sha(O/'gene-universe.json')==m['universe_sha256']
 from analyze import data
 ext=data('validation').dropna(subset=['response','ecog_high','male']);y=ext.response.to_numpy();perf=pd.read_csv(O/'performance.csv');checks=[]
 for name,model in m['models'].items():
  x=ext[model['columns']].to_numpy();z=(x-np.asarray(model['mean']))/np.asarray(model['sd']);p=expit(model['coef'][0]+z@np.asarray(model['coef'][1:]))
  auc=mannwhitneyu(p[y==1],p[y==0]).statistic/((y==1).sum()*(y==0).sum());ll=-(y*np.log(p)+(1-y)*np.log1p(-p)).mean()
  vals={'AUC':auc,'Brier':np.mean((p-y)**2),'Log loss':ll};q=perf[(perf.cohort=='External')&(perf.model==name)].set_index('metric').value
  for k,v in vals.items():assert np.isclose(v,q[k],rtol=1e-10);checks.append({'check':f'independent external {name} {k}','passed':True})
 folds=pd.read_csv(O/'cv-folds-private.csv');assert folds.groupby(['repeat','patient']).size().eq(1).all();assert folds.groupby('patient').size().eq(10).all();assert len(folds)==2980
 for e in json.loads((R/'sources.json').read_text()):assert sha(R/'raw'/e['file'])==e['sha256']
 key=pd.read_csv(R/'raw/GSE176307_sample_key.csv.gz'); keys=[s.strip() for ss in key.iloc[:,1] for s in ss.split(',')];assert len(keys)==len(set(keys))
 q=json.loads((O/'analysis-qc.json').read_text());assert q['development_n']==298 and q['external_n']==72 and q['external_events']==11
 release=R/'release/writings/immune-outcome-validation'
 if release.exists():
  manifest=json.loads((release/'release-manifest.json').read_text())
  for name,h in manifest.items():assert sha(release/name)==h,name
  assert not list(release.rglob('raw'));assert not list(release.rglob('*private*'))
  import sys;sys.path.insert(0,str(R.parent/'nimotuzumab-poppk/.notebook-deps'));import nbformat
  nb=nbformat.read(release/'analysis.ipynb',as_version=4)
  for c in nb.cells:
   if c.cell_type=='code':assert c.execution_count is not None;assert all(o.output_type!='error'for o in c.outputs)
  with zipfile.ZipFile(R/'release/immune-outcome-validation.zip')as z:assert z.testzip()is None
 pd.DataFrame(checks).to_csv(O/'independent-qc.csv',index=False)
 print('PASS: source checksums, frozen coefficients, independent external metrics, patient CV, release integrity, executed notebook')
if __name__=='__main__':run()
