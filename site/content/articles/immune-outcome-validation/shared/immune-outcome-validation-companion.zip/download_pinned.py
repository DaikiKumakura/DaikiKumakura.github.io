from pathlib import Path
import json,hashlib,urllib.request
R=Path(__file__).resolve().parent
if __name__=='__main__':
 raw=R/'raw';raw.mkdir(exist_ok=True)
 for e in json.loads((R/'sources.json').read_text()):
  p=raw/e['file']
  if not p.exists():p.write_bytes(urllib.request.urlopen(e['url'],timeout=120).read())
  assert hashlib.sha256(p.read_bytes()).hexdigest()==e['sha256'],f"Source changed: {e['file']}"
  print(e['file'],'verified')
