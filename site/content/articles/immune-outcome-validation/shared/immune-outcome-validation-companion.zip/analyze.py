from pathlib import Path
import json,hashlib
import numpy as np,pandas as pd
from scipy.special import expit
from scipy.stats import rankdata
from scipy.optimize import minimize
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
R=Path(__file__).resolve().parent;O=R/'results';F=R/'figures';F.mkdir(exist_ok=True)
SEED=20261004
MODELS={'Clinical':['ecog_high','male'],'Clinical + immune':['ecog_high','male','Teff','Stroma']}
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def data(label):
 d=pd.read_csv(R/'raw'/f'{label}-features.csv',index_col=0);d['ecog_high']=np.where(d.ecog.isna(),np.nan,(d.ecog>=1).astype(float));return d

def fit(x,y):
 mu=x.mean(0);sd=x.std(0);sd=np.where(sd==0,1,sd);z=np.c_[np.ones(len(x)),(x-mu)/sd];pen=np.r_[0,np.ones(x.shape[1])]
 def fun(b):return np.logaddexp(0,z@b).sum()-y@(z@b)+.5*(pen*b*b).sum()
 def jac(b):return z.T@(expit(z@b)-y)+pen*b
 def hess(b):
  p=expit(z@b);return z.T@((p*(1-p))[:,None]*z)+np.diag(pen)
 res=minimize(fun,np.zeros(z.shape[1]),jac=jac,hess=hess,method='trust-exact',options={'gtol':1e-7,'maxiter':100})
 assert np.max(np.abs(jac(res.x)))<1e-5,(res.message,jac(res.x))
 return {'mean':mu.tolist(),'sd':sd.tolist(),'coef':res.x.tolist(),'gradient_max':float(abs(jac(res.x)).max())}
def predict(m,x):return expit(np.c_[np.ones(len(x)),(x-np.array(m['mean']))/np.array(m['sd'])]@np.array(m['coef']))
def metrics(y,p):
 n1=y.sum();n0=len(y)-n1;auc=(rankdata(p)[y==1].sum()-n1*(n1+1)/2)/(n1*n0) if n1*n0 else np.nan
 return {'AUC':float(auc),'Brier':float(np.mean((p-y)**2)),'Log loss':float(np.mean(np.logaddexp(0,np.log(p/(1-p)))-y*np.log(p/(1-p))))}
def calibration(y,p):
 lp=np.log(p/(1-p));a=minimize(lambda b:np.logaddexp(0,lp+b[0]).sum()-y@(lp+b[0]),[0],method='BFGS')
 z=np.c_[np.ones(len(p)),lp]
 b=minimize(lambda b:np.logaddexp(0,z@b).sum()-y@(z@b),[0,1],jac=lambda b:z.T@(expit(z@b)-y),method='BFGS')
 return {'offset_intercept':float(a.x[0]),'joint_intercept':float(b.x[0]),'slope':float(b.x[1])}
def run():
 dev=data('development').dropna(subset=['response','ecog_high','male']);y=dev.response.to_numpy();assert dev.index.is_unique
 rng=np.random.default_rng(SEED);pred={k:np.zeros(len(dev)) for k in MODELS};folds=[]
 for rep in range(10):
  fold=np.zeros(len(dev),int)
  for outcome in [0,1]:
   idx=np.where(y==outcome)[0];rng.shuffle(idx);fold[idx]=np.arange(len(idx))%5
  for f in range(5):
   test=fold==f;train=~test;assert not set(dev.index[test])&set(dev.index[train])
   for name,cols in MODELS.items():pred[name][test]+=predict(fit(dev[cols].to_numpy()[train],y[train]),dev[cols].to_numpy()[test])/10
  folds.extend({'patient':str(p),'repeat':rep,'fold':int(f)}for p,f in zip(dev.index,fold))
 pd.DataFrame(folds).to_csv(O/'cv-folds-private.csv',index=False)
 frozen={'seed':SEED,'plan_sha256':sha(R/'analysis-plan.md'),'code_sha256':sha(Path(__file__)),'universe_sha256':sha(O/'gene-universe.json'),'development_sha256':sha(R/'raw/development-features.csv'),'signatures':json.loads((O/'audit-summary.json').read_text())['signatures'],'models':{}}
 for name,cols in MODELS.items():frozen['models'][name]={'columns':cols,**fit(dev[cols].to_numpy(),y)}
 livercols=MODELS['Clinical + immune']+['liver'];dl=dev.dropna(subset=['liver']);frozen['liver_sensitivity']={'columns':livercols,**fit(dl[livercols].to_numpy(),dl.response.to_numpy())}
 lock=O/'model-frozen.json';lock.write_text(json.dumps(frozen,indent=2));lockedhash=sha(lock);(O/'model-frozen.sha256').write_text(lockedhash)
 # External performance is computed only after development model artifact is written.
 ext=data('validation').dropna(subset=['response','ecog_high','male']);ye=ext.response.to_numpy();pe={k:predict(m,ext[m['columns']].to_numpy())for k,m in frozen['models'].items()}
 rows=[];bootrows=[];cal=[]
 for cohort,yy,pp in [('Repeated CV',y,pred),('External',ye,pe)]:
  samples=rng.integers(0,len(yy),size=(2000,len(yy)));bm={}
  for name,p in pp.items():
   point=metrics(yy,p);values=np.array([list(metrics(yy[ix],p[ix]).values()) for ix in samples]);bm[name]=values
   for j,(metric,value) in enumerate(point.items()):
    lo,hi=np.nanpercentile(values[:,j],[2.5,97.5]);rows.append(dict(cohort=cohort,model=name,metric=metric,value=value,lower=lo,upper=hi,n=len(yy),events=int(yy.sum())))
   if cohort=='External':cal.append({'model':name,**calibration(yy,p)})
  delta=bm['Clinical + immune']-bm['Clinical'];point=np.array(list(metrics(yy,pp['Clinical + immune']).values()))-np.array(list(metrics(yy,pp['Clinical']).values()))
  for j,metric in enumerate(['AUC','Brier','Log loss']):
   lo,hi=np.nanpercentile(delta[:,j],[2.5,97.5]);bootrows.append(dict(cohort=cohort,metric=metric,delta=point[j],lower=lo,upper=hi,valid_bootstraps=int(np.isfinite(delta[:,j]).sum())))
 pd.DataFrame(rows).to_csv(O/'performance.csv',index=False);pd.DataFrame(bootrows).to_csv(O/'added-value.csv',index=False);pd.DataFrame(cal).to_csv(O/'calibration.csv',index=False)
 sens=metrics(ye,predict(frozen['liver_sensitivity'],ext[livercols].to_numpy()));(O/'liver-sensitivity.json').write_text(json.dumps({'development_n':len(dl),'external_n':len(ext),**sens},indent=2))
 pop=[]
 for cohort,d in [('Development',dev),('External',ext)]:
  pop.append({'cohort':cohort,'n':len(d),'responders':int(d.response.sum()),'response_fraction':d.response.mean(),'ecog_ge1_fraction':d.ecog_high.mean(),'male_fraction':d.male.mean(),'Teff_mean':d.Teff.mean(),'Stroma_mean':d.Stroma.mean()})
 pd.DataFrame(pop).to_csv(O/'population.csv',index=False)
 plt.rcParams.update({'font.size':11,'axes.spines.top':False,'axes.spines.right':False,'figure.dpi':130})
 fig,ax=plt.subplots(1,2,figsize=(10,4))
 df=pd.DataFrame(rows)
 for a,cohort in zip(ax,['Repeated CV','External']):
  q=df[(df.cohort==cohort)&(df.metric=='AUC')];a.errorbar(q.value,[0,1],xerr=[q.value-q.lower,q.upper-q.value],fmt='o',capsize=4,color='#24687a');a.set_yticks([0,1],['Clinical','Clinical + immune']);a.set_xlim(.3,1);a.axvline(.5,color='gray',ls=':');a.set_title(f'{cohort}: n={int(q.n.iloc[0])}, responses={int(q.events.iloc[0])}');a.set_xlabel('AUC (conditional bootstrap 95% interval)')
 fig.tight_layout();fig.savefig(F/'discrimination.png');plt.close(fig)
 fig,ax=plt.subplots(1,2,figsize=(10,4));bins=[]
 for a,(name,p) in zip(ax,pe.items()):
  cuts=np.quantile(predict(frozen['models'][name],dev[MODELS[name]].to_numpy()),[0,1/3,2/3,1]);cuts[0]=-np.inf;cuts[-1]=np.inf
  group=np.digitize(p,cuts[1:-1])
  for g in range(3):
   idx=group==g;n=idx.sum()
   if not n:continue
   obs=ye[idx].mean();z=1.96;den=1+z*z/n;center=(obs+z*z/(2*n))/den;half=z*np.sqrt(obs*(1-obs)/n+z*z/(4*n*n))/den
   a.errorbar(p[idx].mean(),obs,yerr=[[obs-max(0,center-half)],[min(1,center+half)-obs]],fmt='o',capsize=3,color='#24687a');a.annotate(f'n={n}',(p[idx].mean(),obs),xytext=(5,5),textcoords='offset points');bins.append({'model':name,'bin':g,'n':int(n),'predicted':p[idx].mean(),'observed':obs})
  a.plot([0,1],[0,1],ls=':',color='gray');a.set(xlim=(0,1),ylim=(0,1),xlabel='Frozen predicted probability',ylabel='Observed response fraction',title=name)
 fig.tight_layout();fig.savefig(F/'calibration.png');plt.close(fig);pd.DataFrame(bins).to_csv(O/'calibration-bins.csv',index=False)
 fig,ax=plt.subplots(1,2,figsize=(9,4))
 for a,col in zip(ax,['Teff','Stroma']):
  a.boxplot([dev[col],ext[col]],tick_labels=['Development','External'],showfliers=False);a.set(title=col,ylabel='Mean within-sample gene percentile')
 fig.tight_layout();fig.savefig(F/'score-shift.png');plt.close(fig)
 fig,ax=plt.subplots(figsize=(9,4));ax.axis('off')
 for x,label in [(.25,'Development'),(.75,'External')]:
  texts=([f'{label}: 348 RNA samples','347 unique patients','298 response-evaluable','298 primary complete cases','68 responses'] if label=='Development' else [f'{label}: 92 TPM columns','90 mapped RNA samples / 89 patients','88 response-evaluable','72 primary complete cases',f'{int(ye.sum())} responses'])
  for i,t in enumerate(texts):
   ax.text(x,.9-i*.19,t,ha='center',va='center',bbox={'boxstyle':'round,pad=.4','fc':'#eef5f6','ec':'#24687a'})
   if i<4:ax.annotate('',xy=(x,.78-i*.19),xytext=(x,.85-i*.19),arrowprops={'arrowstyle':'->'})
 fig.tight_layout();fig.savefig(F/'cohort-flow.png');plt.close(fig)
 assert sha(lock)==lockedhash
 (O/'analysis-qc.json').write_text(json.dumps({'development_n':len(dev),'external_n':len(ext),'development_events':int(y.sum()),'external_events':int(ye.sum()),'lock_unchanged':True,'model_sha256':lockedhash,'folds':50,'bootstrap_resamples':2000,'all_probabilities_finite':all(np.isfinite(p).all()for p in pe.values())},indent=2))
 print(pd.DataFrame(rows).to_string(index=False));print(pd.DataFrame(bootrows).to_string(index=False));print(pd.DataFrame(cal).to_string(index=False))
if __name__=='__main__':run()
