# Data dictionary and source audit

Audit completed 2026-10-04. See sources.json for pinned URLs, bytes and SHA-256. No patient identifiers belong in the public release.

| Quantity | Development source | External source | Decision |
|---|---|---|---|
| Patient identity | ANONPT_ID | BACI patient key joined to GEO RNA_ID | Collapse repeats within source; cannot prove no cross-source overlap |
| Response | Best Confirmed Overall Response | io.response | CR/PR=1, SD/PD=0, unknown/NE excluded; confirmation and ascertainment differ |
| ECOG | Baseline ECOG Score | ecog | >=1 binary; external measurement time not explicitly verified; complete cases |
| Sex | Sex M/F | gender M/F | male=1; source-recorded field, no inferred identity |
| Liver | Met Disease Status Liver/Visceral/LN Only | met.liver.cumul Y/N | Sensitivity only; cumulative vs category not interchangeable |
| TMB | FMOne mutation burden per MB | tmb | Excluded: targeted-panel harmonization not established |
| RNA | counts and feature length, duplicate symbols summed in TPM | distributed Salmon TPM | Common symbol availability, fixed within-sample ranks; assay comparability limited |
| OS / PFS | os,censOS and related fields | overall survival,alive,pfs,progressed | Excluded: shared endpoint/unit/censor definitions not qualified |
| Biopsy time | aggregate pretreatment study description | archival tumor RNA study description | No patient-level biopsy-to-treatment audit possible; temporal qualification incomplete |

Development: 348 RNA samples, 347 unique patients, 298 response-evaluable and primary complete cases (68 responses). Liver complete cases: 271. The original acquisition server is unavailable; pinned third-party mirror is not verified against original publisher bytes. DESCRIPTION credits Dorothee Nickles and Richard Bourgon; license PDF and source manuscript identify CC BY 3.0 for processed bundle. Acquired data only: no third-party analysis code executed.

External: reported clinical series 103; matrix 92 columns; key maps 90 samples to 89 patients; 2 unmapped columns excluded; 88 response-evaluable; 72 primary complete cases, 11 responses. ECOG missing in 17/89; one missing-response patient also lacks ECOG, so 16 evaluable patients excluded. RNA repeat from one patient collapsed by mean TPM; not an independent outcome. Missingness by original unique RNA cohort is in results/missingness.csv. cohort-flow.csv clinical_complete column includes liver; primary cases are shown separately in results/population.csv.

All 27 fixed genes available across 24,296 shared symbols; no zero-length features, negative TPM/counts, or missing numeric RNA values detected. Repeated clinical fields checked for agreement. Distribution shift, incomplete metadata, outcome selection and uncertain participant independence remain material limitations. Public availability is not a blanket redistribution license: distribute scripts/aggregate tables only, not downloaded clinical/RNA records.
