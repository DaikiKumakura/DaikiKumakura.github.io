from pathlib import Path
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
R=Path(__file__).resolve().parent
# Presentation-only update: do not refit frozen models.
df=pd.read_csv(R/'results/performance.csv');plt.rcParams.update({'font.size':11,'axes.spines.top':False,'axes.spines.right':False,'figure.dpi':130})
fig,ax=plt.subplots(1,2,figsize=(10,3.3))
for a,cohort in zip(ax,['Repeated CV','External']):
 q=df[(df.cohort==cohort)&(df.metric=='AUC')];a.errorbar(q.value,[0,1],xerr=[q.value-q.lower,q.upper-q.value],fmt='o',capsize=4,color='#24687a');a.set_yticks([0,1],['Clinical','Clinical + immune']);a.set_ylim(-.4,1.4);a.set_xlim(.2,1);a.axvline(.5,color='gray',ls=':');a.set_title(f'{cohort}: n={int(q.n.iloc[0])}, responses={int(q.events.iloc[0])}');a.set_xlabel('AUC (conditional bootstrap 95% interval)')
fig.tight_layout();fig.savefig(R/'figures/discrimination.png');plt.close(fig)
# Mathematical model rendered locally, no browser script dependency.
fig,ax=plt.subplots(figsize=(9,1.6));ax.axis('off');ax.text(.03,.70,r'$p_i=\mathrm{logit}^{-1}(\beta_0+\sum_j\beta_j z_{ij})$',fontsize=19);ax.text(.03,.20,r'$z_{ij}=(x_{ij}-\mu_{j,train})/s_{j,train}$',fontsize=19);fig.tight_layout();fig.savefig(R/'figures/model-equation.png');plt.close(fig)
