from pathlib import Path
import pandas as pd,numpy as np,gzip,re,json,hashlib
R=Path(__file__).resolve().parent;raw=R/'raw';O=R/'results'
def soft_records():
 text=gzip.open(raw/'GSE176307_family.soft.gz','rt',encoding='utf-8').read();records=[]
 for chunk in text.split('^SAMPLE = ')[1:]:
  lines=chunk.splitlines();rec={'GSM':lines[0]}
  for line in lines[1:]:
   if line.startswith('!Sample_title = '):rec['title']=line.split(' = ',1)[1];rec['patient']=re.search(r'BACI\d+',rec['title']).group()
   if line.startswith('!Sample_description = '):rec['RNA_ID']=line.split(' = ',1)[1]
   if line.startswith('!Sample_characteristics_ch1 = '):
    k,v=line.split(' = ',1)[1].split(': ',1);rec[k]=v
  records.append(rec)
 return pd.DataFrame(records)
def run():
 dev=pd.read_csv(raw/'imvigor-clinical.csv',index_col=0);ext=soft_records();ext.to_csv(raw/'geo-clinical.csv',index=False)
 f=pd.read_csv(raw/'imvigor-features.csv',index_col=0);ct=pd.read_csv(raw/'imvigor-counts.tsv.gz',sep='\t',index_col=0);ex=pd.read_csv(raw/'GSE176307_tpm.tsv.gz',sep='\t',index_col=0)
 assert list(ct.columns)==list(dev.index);assert (ct.index.astype(str)==f.index.astype(str)).all();assert not ct.isna().any().any();assert not ex.isna().any().any();assert (ex.to_numpy()>=0).all();assert (ct.to_numpy()>=0).all();assert (f.length>0).all()
 # TPM from gene-length-corrected counts; duplicate symbols are summed, no outcome-based selection.
 rates=ct.div(f.length.to_numpy(),axis=0);tpm=rates.div(rates.sum(axis=0),axis=1)*1e6;tpm.index=f.Symbol.astype(str);tpm=tpm.groupby(level=0).sum();assert ex.index.is_unique
 common=sorted(set(tpm.index)&set(ex.index));(O/'gene-universe.json').write_text(json.dumps(common))
 signatures=pd.read_csv(raw/'signatures.tsv',sep='\t').set_index('signature').genes
 genes={'Teff':signatures['CD 8 T effector'].split(';'),'Stroma':signatures['gene19'].split(';')};coverage={k:{'genes':v,'available':[g for g in v if g in common],'missing':[g for g in v if g not in common]}for k,v in genes.items()};print('Gene coverage',coverage)
 # Freeze explicit aliases only when annotation names require them, never use outcome to pick.
 assert all(len(v['missing'])==0 for v in coverage.values()),'Gene mapping requires audit before fitting'
 # Clinical metadata must agree across replicate samples. Drop repeated patient only after verifying.
 for pid,g in dev.groupby('ANONPT_ID'):
  assert g['Best Confirmed Overall Response'].nunique()==1;assert g['Baseline ECOG Score'].nunique()==1;assert g.Sex.nunique()==1
 for pid,g in ext.groupby('patient'):
  for c in ['io.response','ecog','gender','met.liver.cumul']:assert g[c].nunique()==1,(pid,c)
 key=pd.read_csv(raw/'GSE176307_sample_key.csv.gz');mapping={s.strip():p for p,ss in zip(key.iloc[:,0],key.iloc[:,1])for s in ss.split(',')};assert len(mapping)==len(set(mapping));assert set(ext.RNA_ID)<=set(mapping)
 tpmdev=tpm.T.assign(patient=dev.ANONPT_ID.values).groupby('patient').mean().T
 matched=[c for c in ex if c in mapping];tx=ex[matched].T;tx['patient']=[mapping[c]for c in matched];tpmext=tx.groupby('patient').mean().T
 devuniq=dev.reset_index().drop_duplicates('ANONPT_ID').set_index('ANONPT_ID');extuniq=ext.drop_duplicates('patient').set_index('patient')
 assert set(tpmext.columns)==set(extuniq.index);assert tpmext.shape[1]==89
 for label,e,cl in [('development',tpmdev,devuniq),('validation',tpmext,extuniq)]:
  ranks=e.loc[common].rank(axis=0,method='average',pct=True);scores=pd.DataFrame({k:ranks.loc[v].mean(axis=0)for k,v in genes.items()});scores.index.name='patient'
  if label=='development':response=cl['Best Confirmed Overall Response'];ecog=pd.to_numeric(cl['Baseline ECOG Score'],errors='coerce');sex=cl.Sex;liver=cl['Met Disease Status'].map({'Liver':1,'Visceral':0,'LN Only':0});tmb=cl['FMOne mutation burden per MB']
  else:response=cl['io.response'];ecog=pd.to_numeric(cl.ecog,errors='coerce');sex=cl.gender;liver=cl['met.liver.cumul'].map({'Y':1,'N':0});tmb=pd.to_numeric(cl.tmb,errors='coerce')
  scores['response']=response.map({'CR':1,'PR':1,'SD':0,'PD':0});scores['response_label']=response;scores['ecog']=ecog;scores['male']=sex.map({'M':1,'F':0});scores['liver']=liver;scores['TMB']=tmb
  scores.to_csv(raw/f'{label}-features.csv')
  if label=='development':devscores=scores
  else:extscores=scores
 flows=[dict(cohort='development',reported_clinical='not re-enumerated from trial database',RNA_samples=348,unique_RNA_patients=len(devuniq),response_available=int(devscores.response.notna().sum()),clinical_complete=int(devscores[['response','ecog','male','liver']].notna().all(axis=1).sum())),dict(cohort='validation',reported_clinical=103,RNA_samples=90,TPM_columns=ex.shape[1],mapped_TPM_columns=len(matched),unique_RNA_patients=len(extuniq),response_available=int(extscores.response.notna().sum()),clinical_complete=int(extscores[['response','ecog','male','liver']].notna().all(axis=1).sum()))]
 pd.DataFrame(flows).to_csv(O/'cohort-flow.csv',index=False)
 missing=pd.concat([devscores.isna().sum().rename('development'),extscores.isna().sum().rename('validation')],axis=1);missing.to_csv(O/'missingness.csv')
 duplicates={'development':dev[dev.ANONPT_ID.duplicated(False)].index.tolist(),'validation':ext[ext.patient.duplicated(False)][['GSM','patient','RNA_ID']].to_dict('records'),'unmapped_TPM_columns':[c for c in ex if c not in mapping]}
 sourcefiles=[p for p in raw.iterdir()if p.is_file()];manifest={p.name:hashlib.sha256(p.read_bytes()).hexdigest()for p in sourcefiles};(O/'input-hashes.json').write_text(json.dumps(manifest,indent=2))
 summary={'common_gene_universe':len(common),'signatures':coverage,'flow':flows,'duplicates':duplicates,'endpoint':'reported CR/PR vs SD/PD; NE/unknown excluded','development_mirror_commit':'26b8d2b9e6e91f7412646db111c9e567172ed87f','original_source_server':'unavailable; original publisher byte identity not verified','validation_timing':'patient-level biopsy-to-ICI timing absent in GEO metadata','cross_cohort_identity':'different studies/sites; original patient IDs cannot be matched across anonymous sources','survival':'OS/PFS fields retained in audit; not modeled because development endpoint/event metadata require further confirmation'}
 (O/'audit-summary.json').write_text(json.dumps(summary,indent=2));print(pd.DataFrame(flows).to_string(index=False));print(missing);print(ext['io.therapy'].value_counts());print(ext['io.response'].value_counts())
if __name__=='__main__':run()
