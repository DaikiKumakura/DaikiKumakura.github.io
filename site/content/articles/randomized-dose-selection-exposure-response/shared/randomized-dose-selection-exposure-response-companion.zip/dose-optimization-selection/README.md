# Companion: selecting a dose in a randomized two-dose trial with and without exposure information

Simulation code and aggregate results for the article "Does exposure information help a randomized two-dose trial select the better dose? Simulated trials with and without severity-driven clearance". No patient data are used.

## Files

- `simulate.R`: simulates randomized two-dose trials (relative doses 1 and 2, 1:1) for three response and toxicity scenarios, with and without confounding of exposure by severity, and applies three selection rules (`Rscript simulate.R 2000`; seed 20261117; writes `results/summary.csv` and `results/session-info.txt`). Base R only.
- `simulate_extra.R`: diagnostic runs (fitted exposure slope and estimated gain of R1, R2, R3 and an oracle that uses the true severity; `Rscript simulate_extra.R 1000`; seed 20261118; writes `results/diagnostics.csv`).
- `figure1.R`: draws Figure 1 from `results/summary.csv` (requires ggplot2).
- `results/summary.csv`: aggregate results for every scenario, sample size and rule (the numbers in Tables 1 and 2 and the text).
- `results/diagnostics.csv`: the diagnostic results (Table 3).
- `results/session-info.txt`: R 4.5.3 session information.

## Reproduce

```
Rscript simulate.R 2000
Rscript simulate_extra.R 1000
Rscript figure1.R
```

The scripts find their own folder, so they can be run from any directory. The output of `summary.csv` depends on the random-number stream of the R version used.
