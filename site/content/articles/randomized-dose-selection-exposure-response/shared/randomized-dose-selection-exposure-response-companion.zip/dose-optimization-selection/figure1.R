# Figure 1: probability of selecting the correct dose by rule, scenario and sample size (from results/summary.csv).
suppressPackageStartupMessages(library(ggplot2))
script_dir <- dirname(normalizePath(sub("^--file=", "", grep("^--file=", commandArgs(FALSE), value = TRUE)[1]), winslash = "/"))
d <- read.csv(file.path(script_dir, "results/summary.csv"))
d$rule <- factor(d$rule, c("R1_empirical", "R2_exposure", "R3_exposure_marker"),
  c("R1 response-rate difference", "R2 exposure-response model", "R3 exposure-response model + noisy severity marker"))
d$scenario <- factor(d$scenario, c("S1_gain", "S2_flat", "S3_toxic"),
  c("S1: high dose better\n(true response +0.17 to +0.19)", "S2: near plateau\n(true response +0.03)", "S3: high-dose toxicity\nabove the 25% cap"))
d$config <- factor(d$config, c("clean", "confounded"), c("Exposure not confounded", "Severity raises clearance (confounded)"))
cols <- c("#E69F00", "#0072B2", "#D55E00")
g <- ggplot(d, aes(n_per_arm, pcs, colour = rule, shape = rule, linetype = rule)) +
  geom_hline(yintercept = 0.8, colour = "grey70", linewidth = 0.3) +
  geom_errorbar(aes(ymin = pcs - 1.96 * pcs_se, ymax = pcs + 1.96 * pcs_se), width = 0, linewidth = 0.4, alpha = 0.7) +
  geom_line(linewidth = 0.7) + geom_point(size = 2) +
  facet_grid(config ~ scenario) +
  scale_colour_manual(values = cols, name = NULL) + scale_shape_manual(values = c(16, 17, 15), name = NULL) +
  scale_linetype_manual(values = c("solid", "dashed", "dotdash"), name = NULL) +
  scale_x_continuous(breaks = c(20, 40, 60, 100)) + scale_y_continuous(limits = c(0, 1), breaks = seq(0, 1, 0.2)) +
  labs(x = "Patients per arm", y = "Probability of selecting the correct dose",
       caption = "2,000 simulated trials per point; bars are 95% intervals (±1.96 binomial SE). Grey line: 0.8.") +
  theme_bw(base_size = 10) + theme(legend.position = "bottom", legend.direction = "vertical", strip.text = element_text(size = 8.5))
dir.create(file.path(script_dir, "figures"), showWarnings = FALSE)
ggsave(file.path(script_dir, "figures/figure-1-selection.png"), g, width = 8.2, height = 6.4, dpi = 200)
