# Diagnostics for simulate.R: why does the exposure-response rule fail near a plateau under confounding?
# Saves, for the response model only, the fitted exposure slope and the estimated high-versus-low response gain of
# R2 (exposure only), R3 (exposure + noisy marker) and RO (exposure + true severity, an oracle that is not available in practice).
# Run: Rscript simulate_extra.R 1000   (trials per cell; seed 20261118). Reuses the data-generating code of simulate.R.
script_dir <- dirname(normalizePath(sub("^--file=", "", grep("^--file=", commandArgs(FALSE), value = TRUE)[1]), winslash = "/"))
src <- readLines(file.path(script_dir, "simulate.R"))
stop_at <- grep("^set.seed", src)[1] - 1
eval(parse(text = src[seq_len(stop_at)]))   # definitions only (draw, calib, truth, SCEN, constants)
args <- commandArgs(trailingOnly = TRUE); NREP2 <- if (length(args) >= 1) as.integer(args[1]) else 1000L
set.seed(20261118L); rows <- list()
fit_gain <- function(form, d) {
  f <- suppressWarnings(glm(form, binomial, d))
  base <- d$lc - ifelse(d$dose == 2, log(2), 0)
  at <- function(sh) { nd <- d; nd$lc <- base + sh; nd$dose <- if (sh == 0) 1 else 2; mean(predict(f, nd, type = "response")) }
  c(slope = unname(coef(f)["lc"]), gain = at(log(2)) - at(0))
}
for (cn in c("clean", "confounded")) {
  kappa <- if (cn == "clean") 0 else 0.4
  for (sn in c("S1_gain", "S2_flat")) {
    sc <- SCEN[[sn]]; cal <- calib(sc, kappa); tr <- truth(sc, cal, kappa)
    for (n in c(40, 100)) {
      res <- t(vapply(seq_len(NREP2), function(i) {
        dose <- rep(DOSES, each = n); p <- draw(2 * n, dose, kappa)
        y <- rbinom(2 * n, 1, expit(cal$a_r + sc$b_r * p$lc - SEV_RESP * p$s))
        d <- data.frame(dose = dose, y = y, lc = p$lc, m = p$marker, s = p$s)
        c(R1 = mean(y[dose == 2]) - mean(y[dose == 1]),
          fit_gain(y ~ lc, d), fit_gain(y ~ lc + m, d), fit_gain(y ~ lc + s, d))
      }, numeric(7)))
      colnames(res) <- c("R1_gain", "R2_slope", "R2_gain", "R3_slope", "R3_gain", "RO_slope", "RO_gain")
      truegain <- tr$orr[2] - tr$orr[1]
      for (m in c("R1", "R2", "R3", "RO")) {
        g <- res[, paste0(m, "_gain")]
        sl <- if (m == "R1") NA else res[, paste0(m, "_slope")]
        rows[[length(rows) + 1]] <- data.frame(config = cn, scenario = sn, n_per_arm = n, method = m, trials = NREP2,
          true_slope = sc$b_r, true_gain = truegain, slope_mean = mean(sl), slope_sd = sd(sl),
          gain_mean = mean(g), gain_q05 = quantile(g, 0.05), gain_q95 = quantile(g, 0.95),
          share_gain_ge_008 = mean(g >= GAIN))
      }
    }
  }
}
out <- do.call(rbind, rows); rownames(out) <- NULL
write.csv(out, file.path(script_dir, "results/diagnostics.csv"), row.names = FALSE)
options(width = 220); o <- out; o[6:13] <- round(o[6:13], 3); print(o, row.names = FALSE)
