"""Reproduce source-summary reanalysis without raw patient data or network."""
from pathlib import Path
import json
import platform
import hashlib
import numpy as np
import pandas as pd
import scipy
from scipy.stats import norm, t as student_t
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from model import (log_effect, paired, ratio_quantiles, onecomp,
                   absorption_from_tmax, mixture_log_variance, precision_pairing)

ROOT = Path(__file__).resolve().parents[1]


def main():
    cfg = json.loads((ROOT/'analysis/inputs.json').read_text())
    out=ROOT/'outputs'; tab=out/'tables'; fig=out/'figures'
    tab.mkdir(parents=True,exist_ok=True);fig.mkdir(parents=True,exist_ok=True)
    src=pd.DataFrame(cfg['single75']).T.rename_axis('condition').reset_index()
    src.to_csv(tab/'source-summary.csv',index=False)
    rows=[]
    for c in cfg['comparisons']:
        for ep in ['auc','cmax']:
            theta,se=log_effect(c[ep])
            rows.append(dict(comparison=c['comparison'],dose=c['dose'],endpoint=ep,
                             gmr=c[ep][0],low90=c[ep][1],high90=c[ep][2],
                             theta=theta,approx_se=se))
    effects=pd.DataFrame(rows);effects.to_csv(tab/'adjusted-effects.csv',index=False)
    rows=[]
    for name,ref,test,j in [('Phase3 / Phase1, 75 mg','phase1','phase3_fasted',0),
                             ('Phase3 / solution, 75 mg','solution','phase3_fasted',1),
                             ('Fed / fasted, 75 mg','phase3_fasted','phase3_fed',3)]:
        for ep in ['auc','cmax']:
            raw=cfg['single75'][test][ep]/cfg['single75'][ref][ep]
            rows.append(dict(comparison=name,endpoint=ep,raw_gm_ratio=raw,adjusted_gmr=cfg['comparisons'][j][ep][0]))
    pd.DataFrame(rows).to_csv(tab/'raw-versus-adjusted.csv',index=False)
    checks=[]
    for name,s in cfg['single75'].items():
        k=np.log(2)/s['half'];ka=absorption_from_tmax(k,s['tmax'])
        peak=float(onecomp(s['tmax'],s['auc'],k,ka))
        checks.append(dict(condition=name,k=k,ka_from_tmax=ka,
                           auc_anchor=s['auc'],cmax_observed=s['cmax'],
                           cmax_calculated=peak,bolus_ceiling=k*s['auc'],
                           relative_error=peak/s['cmax']-1))
    ck=pd.DataFrame(checks);ck.to_csv(tab/'onecomp-adequacy.csv',index=False)
    # Empirical endpoints only. AUC and Cmax generated separately; no joint PK trajectory.
    z=np.random.default_rng(cfg['seed']).standard_normal((cfg['n'],2))
    pairs=[];mixtures=[];precision=[]
    base=cfg['single75']['phase3_fasted']; fed=cfg['single75']['phase3_fed']
    for ep in ['auc','cmax']:
        ratio=cfg['comparisons'][3][ep][0]
        for method,crit in [('normal',norm.ppf(.95)),('t14',student_t.ppf(.95,14))]:
            low,high=cfg['comparisons'][3][ep][1:]
            se,var,rho=precision_pairing(base[ep+'_cv'],fed[ep+'_cv'],low,high,15,crit)
            assert -1 < rho < 1
            q=ratio_quantiles(ratio,base[ep+'_cv'],fed[ep+'_cv'],rho)
            precision.append(dict(endpoint=ep,method=method,assumed_complete_pairs=15,se=se,logratio_variance=var,rho=rho,p05=q[0],median=q[1],p95=q[2]))
        for rho in cfg['rho']:
            a,b=paired(base[ep],ratio,base[ep+'_cv'],fed[ep+'_cv'],rho,z)
            q=np.quantile(b/a,[.05,.5,.95]);theory=ratio_quantiles(ratio,base[ep+'_cv'],fed[ep+'_cv'],rho)
            pairs.append(dict(endpoint=ep,rho=rho,n=cfg['n'],p05=q[0],median=q[1],p95=q[2],analytic_p05=theory[0],analytic_median=theory[1],analytic_p95=theory[2]))
        for p in [0,.5,1]:
            w,b=mixture_log_variance(p,ratio,base[ep+'_cv'],fed[ep+'_cv'])
            mixtures.append(dict(endpoint=ep,p_fed=p,within_log_variance=w,condition_log_variance=b,total_log_variance=w+b))
    pd.DataFrame(precision).to_csv(tab/'ci-pairing-approximation.csv',index=False)
    sim=pd.DataFrame(pairs);sim.to_csv(tab/'conditional-pairs.csv',index=False)
    mix=pd.DataFrame(mixtures);mix.to_csv(tab/'mixture-log-variance.csv',index=False)
    plt.rcParams.update({'font.size':11,'axes.spines.top':False,'axes.spines.right':False})
    colors=['#0072B2','#D55E00']
    f,ax=plt.subplots(figsize=(10.8,5.4),layout='constrained')
    for off,(ep,col) in enumerate(zip(['auc','cmax'],colors)):
        d=effects[effects.endpoint==ep];y=np.arange(len(d))+(off-.5)*.18
        ax.errorbar(d.gmr,y,xerr=[d.gmr-d.low90,d.high90-d.gmr],fmt='o',color=col,label=ep.upper()+'; adjusted 90% CI',capsize=3)
    ax.set_yticks(np.arange(5),[c['comparison'] for c in cfg['comparisons']]);ax.invert_yaxis()
    ax.axvline(1,color='.5',ls='--');ax.set_xlim(.8,1.32);ax.set_xlabel('Test / reference geometric mean ratio')
    ax.set_title('Formulation and food contrasts in the crossover study');ax.legend(loc='upper center',bbox_to_anchor=(.5,-.14),ncol=2)
    f.savefig(fig/'adjusted-contrasts.png',dpi=160);plt.close(f)
    f,axs=plt.subplots(1,2,figsize=(11,4.5),layout='constrained')
    x=np.arange(4);axs[0].bar(x-.2,ck.cmax_observed,.4,label='Reported geometric Cmax',color=colors[0]);axs[0].bar(x+.2,ck.cmax_calculated,.4,label='1-comp: AUC + half-life + Tmax',color=colors[1])
    axs[0].plot(x,ck.bolus_ceiling,'kx',label='1-comp bolus ceiling k x AUC');axs[0].set_xticks(x,['Phase 1','Solution','Phase 3\nfasted','Phase 3\nfed']);axs[0].set_ylabel('Single-dose Cmax (ng/mL)');axs[0].set_ylim(0,49);axs[0].legend(fontsize=8,loc='upper left')
    t=np.linspace(0,72,721);s=base;k=np.log(2)/s['half'];ka=absorption_from_tmax(k,s['tmax'])
    axs[1].plot(t,onecomp(t,s['auc'],k,ka),label='Illustrative 1-comp calculation');axs[1].scatter([s['tmax']],[s['cmax']],color=colors[1],marker='x',label='Reported median Tmax / geometric Cmax')
    axs[1].set(xlabel='Hours after dose',ylabel='Concentration (ng/mL)',ylim=(0,36));axs[1].legend(fontsize=8)
    f.suptitle('Aggregate summaries do not qualify a one-compartment trajectory')
    f.savefig(fig/'absorption-gate.png',dpi=160);plt.close(f)
    f,axs=plt.subplots(1,2,figsize=(10.5,4.4),layout='constrained')
    for ax,ep in zip(axs,['auc','cmax']):
        d=sim[sim.endpoint==ep]
        ax.errorbar(d.rho,d['median'],yerr=[d['median']-d.p05,d.p95-d['median']],fmt='o',capsize=5,color=colors[0],label='2,048 conditional pairs; P5-P95')
        ax.scatter(d.rho,d.analytic_p05,marker='_',color=colors[1],label='Analytic P5/P95');ax.scatter(d.rho,d.analytic_p95,marker='_',color=colors[1])
        approx=[v for v in precision if v['endpoint']==ep and v['method']=='normal'][0]
        ax.errorbar([approx['rho']],[approx['median']],yerr=[[approx['median']-approx['p05']],[approx['p95']-approx['median']]],fmt='s',color='#009E73',capsize=4,label='Simple paired-CI approximation')
        ax.axhline(1,color='.5',ls='--');ax.set(xlabel='Assumed between-condition log correlation',ylabel='Fed / fasted individual endpoint ratio',title=ep.upper(),xticks=cfg['rho'],ylim=(0,3));ax.legend(fontsize=8)
    f.suptitle('Illustrative correlations versus a simple paired-CI approximation')
    f.savefig(fig/'pairing-sensitivity.png',dpi=160);plt.close(f)
    results={'n':cfg['n'],'seed':cfg['seed'],'onecomp':checks,'conditional_pairs':pairs,'mixture_log_variance':mixtures,'ci_pairing_approximation':precision,'clinical_trajectory_qualified':False}
    (out/'results.json').write_text(json.dumps(results,indent=2)+'\n')
    (out/'environment.json').write_text(json.dumps(dict(python=platform.python_version(),numpy=np.__version__,pandas=pd.__version__,scipy=scipy.__version__,matplotlib=matplotlib.__version__),indent=2)+'\n')
    if (ROOT/'data/raw/article.xml').exists():
        (out/'source-hashes.json').write_text(json.dumps({'article.xml':hashlib.sha256((ROOT/'data/raw/article.xml').read_bytes()).hexdigest()},indent=2)+'\n')
    print(ck.to_string(index=False));print(sim.to_string(index=False));print(mix.to_string(index=False))


if __name__=='__main__':main()
