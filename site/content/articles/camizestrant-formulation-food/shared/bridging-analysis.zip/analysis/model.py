"""Conditional endpoint model; not a fitted individual PK model."""
import numpy as np
from scipy.optimize import brentq
from scipy.stats import norm


def log_sigma(cv):
    return np.sqrt(np.log1p(np.asarray(cv)**2))


def log_effect(values):
    estimate, low, high = values
    return np.log(estimate), (np.log(high)-np.log(low))/(2*norm.ppf(.95))


def paired(mu0, ratio, cv0, cv1, rho, z):
    """Marginal scales anchored to reference GM and adjusted contrast."""
    assert -1 < rho < 1 and z.shape[1] == 2
    a = np.log(mu0) + log_sigma(cv0)*z[:, 0]
    b = np.log(mu0*ratio)+log_sigma(cv1)*(rho*z[:, 0]+np.sqrt(1-rho*rho)*z[:, 1])
    return np.exp(a), np.exp(b)


def ratio_quantiles(ratio, cv0, cv1, rho):
    s0, s1 = log_sigma(cv0), log_sigma(cv1)
    sd = np.sqrt(s0*s0+s1*s1-2*rho*s0*s1)
    return np.exp(np.log(ratio)+norm.ppf([.05,.5,.95])*sd)


def onecomp(t, auc, k, ka):
    t = np.asarray(t)
    return auc*k*ka/(ka-k)*(np.exp(-k*t)-np.exp(-ka*t))


def absorption_from_tmax(k, tmax):
    # Conventional ka>k branch, no absorption flip-flop assumed.
    assert tmax*k < 1
    return brentq(lambda ka: np.log(ka/k)/(ka-k)-tmax,k*(1+1e-5),100)


def mixture_log_variance(p, ratio, cv0, cv1):
    within = (1-p)*log_sigma(cv0)**2 + p*log_sigma(cv1)**2
    between = p*(1-p)*np.log(ratio)**2
    return within, between


def precision_pairing(cv0, cv1, low, high, n, critical):
    """Simple complete-pair approximation, not the source mixed model."""
    se=(np.log(high)-np.log(low))/(2*critical)
    variance=n*se*se
    s0,s1=log_sigma(cv0),log_sigma(cv1)
    rho=(s0*s0+s1*s1-variance)/(2*s0*s1)
    return se,variance,rho
