import unittest
import numpy as np
from scipy.integrate import quad, solve_ivp
from scipy.stats import norm
from model import (onecomp, absorption_from_tmax, log_sigma, log_effect,
                   paired, ratio_quantiles, mixture_log_variance, precision_pairing)


class Checks(unittest.TestCase):
    def test_ode(self):
        k=np.log(2)/23.3;ka=.8;auc=636
        s=solve_ivp(lambda t,y:[-ka*y[0],ka*y[0]-k*y[1]],(0,120),[auc*k,0],t_eval=np.linspace(0,120,301),rtol=1e-10,atol=1e-11)
        np.testing.assert_allclose(s.y[1],onecomp(s.t,auc,k,ka),rtol=2e-8,atol=2e-8)

    def test_integral(self):
        self.assertAlmostEqual(quad(lambda t:onecomp(t,636,.03,.8),0,np.inf)[0],636,places=7)

    def test_peak_and_ceiling(self):
        k=np.log(2)/23.3;ka=absorption_from_tmax(k,4)
        t=np.linspace(0,72,72001);c=onecomp(t,636,k,ka)
        self.assertAlmostEqual(t[np.argmax(c)],4,places=3)
        self.assertLess(c.max(),636*k);self.assertLess(636*k,30.6)

    def test_ci(self):
        theta,se=log_effect([1.098,1.044,1.155])
        self.assertAlmostEqual(theta,np.log(1.098))
        self.assertAlmostEqual(2*norm.ppf(.95)*se,np.log(1.155/1.044))

    def test_population_moments(self):
        z=np.random.default_rng(13).standard_normal((200000,2))
        a,b=paired(636,1.098,.351,.351,.5,z)
        self.assertAlmostEqual(np.log(b/a).mean(),np.log(1.098),delta=.004)
        self.assertAlmostEqual(np.corrcoef(np.log(a),np.log(b))[0,1],.5,delta=.01)
        q=ratio_quantiles(1.098,.351,.351,.5)
        np.testing.assert_allclose(np.quantile(b/a,[.05,.5,.95]),q,rtol=.01)

    def test_identity_pair(self):
        # Limit rho ->1 and identical marginal variances approaches fixed ratio.
        q=ratio_quantiles(1.098,.351,.351,1)
        np.testing.assert_allclose(q,[1.098]*3)

    def test_mixture(self):
        z=np.random.default_rng(2);n=200000;p=.5
        a=z.normal(0,log_sigma(.351),n)+z.binomial(1,p,n)*np.log(1.098)
        within,between=mixture_log_variance(p,1.098,.351,.351)
        self.assertAlmostEqual(a.var(),within+between,delta=.0015)
        self.assertEqual(mixture_log_variance(0,1.098,.351,.351)[1],0)

    def test_precision_approximation(self):
        se,v,rho=precision_pairing(.351,.351,1.044,1.155,15,norm.ppf(.95))
        self.assertAlmostEqual(v,15*se*se)
        self.assertAlmostEqual(v,2*log_sigma(.351)**2*(1-rho))
        self.assertGreater(rho,.9);self.assertLess(rho,1)

    def test_seed_and_shapes(self):
        z=np.random.default_rng(20261024).standard_normal((2048,2))
        a,b=paired(30.6,1.062,.441,.396,.9,z)
        self.assertEqual(a.shape,(2048,));self.assertTrue(np.all(a>0))
        a2,b2=paired(30.6,1.062,.441,.396,.9,z)
        np.testing.assert_array_equal(b,b2)


if __name__=='__main__':unittest.main()
