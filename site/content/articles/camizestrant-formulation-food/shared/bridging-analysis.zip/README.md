# Camizestrant formulation and food: public-summary reanalysis

Research and PK assessment planning only. No individual treatment advice.
Existing Python matching requirements.txt:
  python analysis/run_analysis.py
  python -m unittest discover -s analysis -p "test_model.py" -q
No network, source XML/PDF or original patient data needed.

Source: Sykes et al., Clinical and Translational Science 2026;19:e70475.
https://doi.org/10.1111/cts.70475
https://pmc.ncbi.nlm.nih.gov/articles/PMC12820339/
Tables 3/4 and section 2.8. AUC means single-dose AUCinf (ng*h/mL), not AUC0-t.
Cmax ng/mL, half-life/Tmax h. 32 healthy postmenopausal volunteers total.
75mg: n15 per major comparison, food Cmax16 and AUC15; no duplicate table rows.
Adjusted crossover GMR and 90% CI are not unadjusted marginal GM ratios.
Original regimen/period/sequence mixed model is not refitted without IPD.
No current oncology population, partner DDI or repeated-dose simulation.

Endpoint lognormal models use reported GCV converted by sqrt(log(1+CV^2)).
Fasted GM anchors the scale; adjusted GMR sets the log shift. Generated fed GM
need not equal the unadjusted table GM. Seed20261024, 2048 conditional pairs.
AUC/Cmax analyzed separately, no joint endpoint patient probability.
Rho0/.5/.9 illustrations fit marginal CVs and GMR point only, NOT published
GMR CI precision; not equally supported clinical population candidates.
Simple complete15-pair normal and t14 CI approximations constrain logratio
variance=n*SE^2 and rho, but do not reconstruct original mixed-model df,
unbalanced pairs, period effects or the original covariance. Normal/t14 are
explicit sensitivity assumptions. CI width not assigned directly as IIV.
Mixture log variance is cross-sectional, not daily meal switching PK.

One-compartment adequacy gate uses k=ln2/half, AUC scale, ka>k from medianTmax.
Cmax held out; 75mg prototype fasted predicted16.8 versus reported30.6.
Even fixed-k bolus ceiling18.9 fails. Geometric summaries/medianTmax are not
one individual curve. No conclusion proving actual structure, no qualified
absorption rates or repeated-dose trajectory, no efficacy/safety prediction.

7 aggregate CSV,3 original figures, results/environment/source hashes.
9 implementation tests versus independent ODE, quadrature, moments and
variance identities. Not clinical validation. Code MIT; source facts cited.
Source article XML and original figures not redistributed.
