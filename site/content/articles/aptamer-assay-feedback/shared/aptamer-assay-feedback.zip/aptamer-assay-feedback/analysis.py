"""Recalculate published aggregate counts; never reconstruct unavailable raw data."""
from pathlib import Path
import csv
import json

HERE = Path(__file__).resolve().parent


def read(name):
    with (HERE/'inputs'/name).open(encoding='utf-8', newline='') as f:
        return list(csv.DictReader(f))


def rate(k, n):
    if not 0 <= k <= n or n <= 0:
        raise ValueError('Counts must satisfy 0 <= k <= n, n > 0')
    return k/n


def compare(k2, n2, k3, n3):
    r2, r3 = rate(k2, n2), rate(k3, n3)
    return {'round2_percent': 100*r2, 'round3_percent': 100*r3,
            'change_percentage_points': 100*(r3-r2),
            'rate_ratio': r3/r2 if r2 else None,
            'hit_count_ratio': k3/k2 if k2 else None,
            'design_count_ratio': n3/n2}


def nesting(before, after):
    """Necessary count constraint only; not a validation of source annotations."""
    return {'compatible_with_subset_counts': after <= before,
            'excess_after_count': max(0, after-before)}


def background_residual(y, x, intercept=-0.454, slope=0.430):
    """Published R3 myoglobin regression; inputs may be hypothetical examples."""
    return y-(intercept+slope*x)


def main():
    rates = []
    for r in read('cohorts.csv'):
        rates.append({'target': r['target'], 'round': int(r['round']),
                      'hits': int(r['hits']), 'new_designs': int(r['new_designs']),
                      'percent': 100*rate(int(r['hits']), int(r['new_designs']))})
    scenarios = {}
    for r in read('thresholds.csv'):
        scenarios[r['threshold']] = compare(*[int(r[k]) for k in
            ('round2_hits', 'round2_n', 'round3_hits', 'round3_n')])
    audits = []
    for r in read('nesting.csv'):
        audits.append({**r, **nesting(int(r['raw_enriched_new']), int(r['corrected_hits_new']))})
    result = {'scope': 'published aggregate arithmetic; no raw sequence-activity reanalysis',
              'rates': rates, 'threshold_scenarios': scenarios, 'nesting_audit': audits,
              'hypothetical_gate_counterexample': {
                  'not_an_observed_candidate': True,
                  'target_log2fc_y': 0.8, 'bead_log2fc_x': 0.0,
                  'raw_ge_1': False, 'positive_raw': True,
                  'residual': background_residual(0.8,0.0),
                  'residual_gt_1': background_residual(0.8,0.0)>1,
                  'fdr_assumed_pass_for_example': True,
                  'interpretation': 'Positive-raw plus residual gate need not be a subset of raw>=1.'},
              'myoglobin_round1_with_reported_log2fc_gate_percent': 100*18/196,
              'myoglobin_round3_strict_de_novo_percent': 100*184/547,
              'thrombin_round3_strict_de_novo_percent': 100*106/286,
              'independent_candidate_sampling_assumed': False,
              'confidence_intervals_computed': False,
              'agent_causal_effect_estimated': False}
    (HERE/'results').mkdir(exist_ok=True)
    (HERE/'results/summary.json').write_text(json.dumps(result, indent=2)+'\n', encoding='utf-8')
    print(json.dumps(result, indent=2))


if __name__ == '__main__':
    main()
