import unittest
from analysis import rate, compare, nesting, read, background_residual


class AuditTests(unittest.TestCase):
    def test_invalid_counts(self):
        for k,n in [(1,0),(-1,3),(4,3)]:
            with self.assertRaises(ValueError): rate(k,n)

    def test_zero_baseline_is_not_infinite_gain(self):
        self.assertIsNone(compare(0,10,3,20)['rate_ratio'])

    def test_rate_and_count_ratios_differ(self):
        r = compare(9,244,184,549)
        self.assertAlmostEqual(r['hit_count_ratio']/r['design_count_ratio'], r['rate_ratio'])
        self.assertAlmostEqual(r['rate_ratio'], 9.08641975308642)

    def test_non_nested_counts_are_flagged(self):
        self.assertFalse(nesting(164,184)['compatible_with_subset_counts'])
        self.assertEqual(nesting(164,184)['excess_after_count'],20)
        self.assertTrue(nesting(251,131)['compatible_with_subset_counts'])

    def test_residual_gate_can_pass_below_raw_threshold(self):
        self.assertLess(0.8,1)
        self.assertAlmostEqual(background_residual(0.8,0),1.254)
        self.assertGreater(background_residual(0.8,0),1)

    def test_all_reported_thresholds_increase(self):
        for r in read('thresholds.csv'):
            self.assertGreater(rate(int(r['round3_hits']),int(r['round3_n'])),
                               rate(int(r['round2_hits']),int(r['round2_n'])))

    def test_new_design_denominators_are_constant_across_thresholds(self):
        self.assertEqual({(r['round2_n'],r['round3_n']) for r in read('thresholds.csv')}, {('244','549')})


if __name__ == '__main__': unittest.main()
