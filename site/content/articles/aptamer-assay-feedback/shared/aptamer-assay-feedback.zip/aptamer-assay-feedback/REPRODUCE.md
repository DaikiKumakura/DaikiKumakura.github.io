# Aggregate-count audit of an aptamer discovery report

Run with Python 3.12: `python analysis.py`, `python -m unittest test_analysis.py`,
then `python plot.py`. Only plotting needs matplotlib (requirements.txt).
The analysis has no network dependency. JSON is deterministic.

## Source

Cutts et al., *Aptamers as a sandbox for lab-in-the-loop agentic molecular discovery*,
report dated 2026-10-12, accessed 2026-10-19:
https://www.gstatic.com/science-ai/agentic_aptamer_sandbox.pdf

`cohorts.csv`: Supplementary Table S3, PDF pages 25-26. `thresholds.csv`: Methods,
PDF page 17. `nesting.csv`: Supplementary Table S3, PDF page 26, new-design cohorts.
Only aggregate numerical facts are transcribed. Source PDF, sequences and traces
are not redistributed. Full sequence-activity tables are promised upon peer-reviewed
publication, according to Data availability (page 18).

## Limits

This recalculates reported fractions and necessary count constraints; it is not
a reanalysis of raw reads, OLS residuals, DESeq2 or affinity measurements. A failed
subset-count constraint requires checking the source cohorts and definitions;
it does not demonstrate fabricated data or invalidate all experiments.
Passing the constraint is necessary, not sufficient, for coherent hit sets.

The subset check applies only if raw log2FC>=1 remains mandatory in the final
hit rule. Methods can instead be read as requiring positive raw enrichment and
residual>1, with raw>=1 applying only to volcano pre-hits. The result includes
a hypothetical point (y=0.8, x=0, residual=1.254 under the published R3 myoglobin
regression) demonstrating why that different gate need not produce a subset.
This point is not an observed candidate; FDR pass is assumed only for illustration.

Round 1 myoglobin headline uses 20/196 but S3 also reports 18 with log2FC>=1;
do not describe the entire three-round trajectory as identically thresholded.
Reported specificity uses counter-screened binder cohorts and must not be multiplied
by newly designed candidate hit rates as if both denominators were the same.
Round 2 and 3 have different candidate pools and agent configurations; no causal
advantage over conventional optimization or no-feedback agents is estimated.
No independence-based confidence intervals or new p-values are generated from
sequence-family-related aggregate counts.
