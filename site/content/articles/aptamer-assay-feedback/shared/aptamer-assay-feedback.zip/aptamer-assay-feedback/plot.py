from pathlib import Path
import json
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

HERE = Path(__file__).resolve().parent
data = json.loads((HERE/'results/summary.json').read_text())
plt.rcParams.update({'font.size':11,'axes.spines.top':False,'axes.spines.right':False})
(HERE/'figures').mkdir(exist_ok=True)
fig, axes = plt.subplots(1,2,figsize=(9,4.4),layout='constrained',sharey=True)
for ax,target,label in zip(axes,['myoglobin','thrombin'],['Myoglobin','Alpha-thrombin']):
    rows = [r for r in data['rates'] if r['target']==target]
    for r in rows:
        caveat = r['round']==1 and target=='myoglobin'
        ax.bar(r['round'],r['percent'],color='#087f8c',alpha=.5 if caveat else 1,
               hatch='//' if caveat else None,width=.55)
        ax.annotate(f"{r['hits']}/{r['new_designs']}\n{r['percent']:.1f}%",(r['round'],r['percent']),
                    xytext=(0,5),textcoords='offset points',ha='center',fontsize=10)
    ax.set(title=label,xlabel='Design round',xticks=[1,2,3],ylim=(0,55))
    ax.grid(axis='y',alpha=.15)
axes[0].set_ylabel('Reported hits / new target-designed candidates (%)')
fig.suptitle('Reported cohorts are not a matched intervention trial',fontsize=13)
fig.supxlabel('Hatched R1: myoglobin threshold annotation differs within the report',fontsize=9)
fig.savefig(HERE/'figures/reported-rates.png',dpi=180,metadata={'Software':'matplotlib'})
plt.close(fig)

fig,ax=plt.subplots(figsize=(8,4.8),layout='constrained')
for key,label,color in [('relaxed','Relaxed','#6c757d'),('default','Default','#087f8c'),('stringent','Stringent','#cc6633')]:
    r=data['threshold_scenarios'][key]
    vals=[r['round2_percent'],r['round3_percent']]
    ax.plot([2,3],vals,'o-',label=label,color=color)
    for x,y in zip([2,3],vals):
        dx = -8 if x==2 else 8
        ax.annotate(f'{y:.1f}%',(x,y),xytext=(dx,0),textcoords='offset points',
                    ha='right' if x==2 else 'left',va='center',fontsize=10)
ax.set(xlim=(1.7,3.3),ylim=(0,44),xticks=[2,3],xlabel='Design round',
       ylabel='Reported myoglobin hit rate (%)',title='Direction persists; size depends on the threshold')
ax.legend(loc='upper left'); ax.grid(alpha=.15)
fig.savefig(HERE/'figures/threshold-sensitivity.png',dpi=180,metadata={'Software':'matplotlib'})
plt.close(fig)
