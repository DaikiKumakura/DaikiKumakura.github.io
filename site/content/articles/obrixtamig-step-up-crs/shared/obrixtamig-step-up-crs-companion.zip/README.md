# Companion materials: obrixtamig step-up dosing and CRS

Scripts, inputs, tables, figures and logs for the article "Does starting obrixtamig at a low dose reduce CRS?".

- `inputs/crs_regimen.csv`, `inputs/baseline_table1.csv`: counts transcribed from Tables 1 and 2 of Wermke et al., J Clin Oncol 2025;43(27):3021-3031 (doi:10.1200/JCO-25-00363).
- `inputs/crs_by_administration.csv`: percentages and numbers at risk READ FROM the image of Figure 1 of that article; counts are reconstructed (see `inputs/PROVENANCE.md`).
- Run (Python 3.12, numpy, pandas, scipy, matplotlib; seed 20261107): `python analysis/01_regimen_crs.py && python analysis/02_by_administration.py && python analysis/03_conditional_pk.py && python analysis/04_figures.py`.

Exploratory, summary-level analysis of sequentially opened, non-randomized cohorts; the results are not causal effects of the starting dose. The conditional PK calculation uses assumed doses and half-lives and is a schematic, not a fit.
