"""CRS proportions by regimen (Beta-binomial), B2 vs B3 comparison, and a bias-sensitivity analysis.

Input : inputs/crs_regimen.csv (Table 2 of Wermke et al. 2025: patients with CRS by regimen, any grade and grade >= 3)
Model : events_r ~ Binomial(n_r, p_r), p_r ~ Beta(0.5, 0.5) independent across regimens. Unit = patient (one count per patient).
        Draws: 200,000, seed 20261107. Frequentist reference: Fisher exact test, Newcombe (Wilson-score) 95% interval.
Output: outputs/tables/crs_regimen_posterior.csv, crs_b2_vs_b3.csv, crs_bias_sensitivity.csv
Run   : python -X utf8 analysis/01_regimen_crs.py
Regimens were opened sequentially and switched on the basis of CRS in earlier cohorts; B2 vs B3 is observational and descriptive.
"""
import sys
from pathlib import Path

import numpy as np
import pandas as pd
from scipy import stats
from scipy.special import expit, logit

sys.stdout.reconfigure(encoding="utf-8")
SEED, N = 20261107, 200000
ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "outputs/tables"
d = pd.read_csv(ROOT / "inputs/crs_regimen.csv").set_index("regimen")
assert d.n.sum() == 168 and d.crs_any.sum() == 96 and d.crs_g3plus.sum() == 5
rng = np.random.default_rng(SEED)


def wilson(x, n, z=1.959964):
    p = x / n
    c = (p + z * z / (2 * n)) / (1 + z * z / n)
    h = z * np.sqrt(p * (1 - p) / n + z * z / (4 * n * n)) / (1 + z * z / n)
    return c - h, c + h


def newcombe(x1, n1, x2, n2):
    p1, p2 = x1 / n1, x2 / n2
    l1, u1 = wilson(x1, n1)
    l2, u2 = wilson(x2, n2)
    return (p2 - p1) - np.sqrt((p2 - l2) ** 2 + (u1 - p1) ** 2), (p2 - p1) + np.sqrt((u2 - p2) ** 2 + (p1 - l1) ** 2)


rows, dr = [], {}
for col, label in (("crs_any", "CRS any grade"), ("crs_g3plus", "CRS grade >=3")):
    for r, g in d.iterrows():
        p = rng.beta(0.5 + g[col], 0.5 + g.n - g[col], N)
        dr[(label, r)] = p
        rows.append(dict(endpoint=label, regimen=r, events=int(g[col]), n=int(g.n), observed=g[col] / g.n, median=np.median(p), lo=np.percentile(p, 2.5), hi=np.percentile(p, 97.5)))
# pooled groups
for label, col in (("CRS any grade", "crs_any"), ("CRS grade >=3", "crs_g3plus")):
    for name, regs in (("A+B1 (no step-up)", ["A", "B1"]), ("B2+B3 (step-up)", ["B2", "B3"])):
        x, n = int(d.loc[regs, col].sum()), int(d.loc[regs, "n"].sum())
        p = rng.beta(0.5 + x, 0.5 + n - x, N)
        rows.append(dict(endpoint=label, regimen=name, events=x, n=n, observed=x / n, median=np.median(p), lo=np.percentile(p, 2.5), hi=np.percentile(p, 97.5)))
post = pd.DataFrame(rows)
post.to_csv(OUT / "crs_regimen_posterior.csv", index=False)
print(post.round(3).to_string(index=False))

cmp_rows = []
for col, label in (("crs_any", "CRS any grade"), ("crs_g3plus", "CRS grade >=3")):
    x2, n2, x3, n3 = int(d.loc["B2", col]), int(d.loc["B2", "n"]), int(d.loc["B3", col]), int(d.loc["B3", "n"])
    diff = dr[(label, "B3")] - dr[(label, "B2")]
    lo, hi = newcombe(x2, n2, x3, n3)
    cmp_rows.append(dict(endpoint=label, b2=f"{x2}/{n2}", b3=f"{x3}/{n3}", rd_median=np.median(diff), rd_lo=np.percentile(diff, 2.5), rd_hi=np.percentile(diff, 97.5), p_b3_lower=float((diff < 0).mean()),
                         newcombe_lo=lo, newcombe_hi=hi, fisher_p=stats.fisher_exact([[x3, n3 - x3], [x2, n2 - x2]])[1]))
cmp_ = pd.DataFrame(cmp_rows)
cmp_.to_csv(OUT / "crs_b2_vs_b3.csv", index=False)
print("\n== B3 - B2 (negative = fewer CRS with B3)")
print(cmp_.round(3).to_string(index=False))

# bias sensitivity for any-grade CRS: logit shift b applied to B3 (b > 0 means B3's CRS looks lower than it truly is)
p2, p3 = dr[("CRS any grade", "B2")], dr[("CRS any grade", "B3")]
brow = []
for b in np.round(np.arange(-1.0, 1.01, 0.25), 2):
    p3a = expit(logit(np.clip(p3, 1e-9, 1 - 1e-9)) + b)
    brow.append(dict(bias_logit=b, p_b3_lower=float((p3a < p2).mean()), rd_median=float(np.median(p3a - p2))))
bias = pd.DataFrame(brow)
bias.to_csv(OUT / "crs_bias_sensitivity.csv", index=False)
print("\n== bias sensitivity: P(true B3 CRS rate < true B2 rate) after adding logit shift b to B3 (b > 0: B3 looked better than it is)")
print(bias.round(3).to_string(index=False))
