"""Conditional (schematic) PK for the step-up regimens: dose-proportional one-compartment kinetics, concentration in units of dose/V.

Assumptions (from the paper's text, not fitted here): IV infusion over 2 h; Cmax and AUC dose-proportional; terminal half-life about 7 days
(range 5-10) (Wermke et al. 2025, PK paragraph; 138 patients). Volume and individual concentrations are not available, so the
concentration is expressed as C * V in ug/kg ("ug/kg-equivalents"); a distribution phase is ignored.
B2 step-up doses 30 and 90 ug/kg (Appendix 2). B3 added a 10 ug/kg step (Appendix 2); here B3 is taken as 10, 30, 90 ug/kg, an ASSUMPTION
(the remaining B3 step levels were not read from the source). The target dose is ILLUSTRATIVE (360 ug/kg), not a reported value.
Output: outputs/tables/conditional_pk_peaks.csv, conditional_pk_curves.csv
Run   : python -X utf8 analysis/03_conditional_pk.py
"""
import sys
from pathlib import Path

import numpy as np
import pandas as pd

sys.stdout.reconfigure(encoding="utf-8")
ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "outputs/tables"
TARGET = 360.0
INF_H = 2.0
SCHED = {
    "B2": [(0, 30), (7, 90)] + [(14 + 7 * i, TARGET) for i in range(6)],
    "B3": [(0, 10), (7, 30), (14, 90)] + [(21 + 7 * i, TARGET) for i in range(3)] + [(42 + 21 * i, TARGET) for i in range(3)],
}
LABELS = {"B2": ["step-up 1", "step-up 2"] + [f"target {i}" for i in range(1, 7)], "B3": ["step-up 1", "step-up 2", "step-up 3"] + [f"target {i}" for i in range(1, 4)] + [f"Q3W target {i}" for i in range(1, 4)]}


def conc(t_days, doses, half_life_d):
    k = np.log(2) / half_life_d
    inf = INF_H / 24.0
    c = np.zeros_like(t_days, dtype=float)
    for t0, dose in doses:
        rate = dose / inf
        tt = t_days - t0
        during = (tt >= 0) & (tt < inf)
        after = tt >= inf
        c[during] += rate / k * (1 - np.exp(-k * tt[during]))
        c[after] += rate / k * (1 - np.exp(-k * inf)) * np.exp(-k * (tt[after] - inf))
    return c


t = np.linspace(0, 70, 7001)
curve_rows, peak_rows = [], []
for reg, doses in SCHED.items():
    for hl in (5.0, 7.0, 10.0):
        c = conc(t, doses, hl)
        for tt, cc in zip(t[::10], c[::10]):
            curve_rows.append(dict(regimen=reg, half_life_d=hl, day=tt, conc_dose_units=cc))
        for lab, (t0, dose) in zip(LABELS[reg], doses):
            end = conc(np.array([t0 + INF_H / 24.0]), doses, hl)[0]
            peak_rows.append(dict(regimen=reg, half_life_d=hl, administration=lab, day=t0, dose_ugkg=dose, conc_end_infusion=end, ratio_to_first=end / conc(np.array([INF_H / 24.0]), doses[:1], hl)[0]))
pd.DataFrame(curve_rows).to_csv(OUT / "conditional_pk_curves.csv", index=False)
pk = pd.DataFrame(peak_rows)
pk.to_csv(OUT / "conditional_pk_peaks.csv", index=False)
pd.set_option("display.width", 200)
print(pk[pk.half_life_d == 7.0].round(2).to_string(index=False))
for reg in ("B2", "B3"):
    g = pk[(pk.regimen == reg) & (pk.administration.isin(["step-up 1", "step-up 2", "target 1"]))]
    print(reg, "end-of-infusion concentration relative to the first administration (t1/2 5, 7, 10 d):",
          {a: [round(float(v), 2) for v in g[g.administration == a].sort_values("half_life_d").ratio_to_first] for a in ("step-up 2", "target 1")})
