"""CRS by dose administration for regimens B2 and B3, reconstructed from the percentage labels of the original Figure 1.

Input : inputs/crs_by_administration.csv (percent of patients at risk with CRS of grade 1, 2, >=3 at each administration; n at risk)
        The percentages are integers read from the figure; counts are reconstructed as round(pct*n/100) per grade, and the
        rounding range [ceil((pct-0.5)n/100), floor((pct+0.5)n/100)] is kept. These are NOT author-supplied counts.
Unit  : an administration in a patient. The same patient contributes to several administrations, so per-administration
        proportions are not independent of each other. Comparisons ACROSS regimens at the SAME administration use disjoint patients.
Checks: grade >= 3 counts summed over administrations vs Table 2 totals (B2: 3, B3: 2); maximum count at one administration
        must not exceed the number of patients with CRS in Table 2 (B2: 54, B3: 28).
Output: outputs/tables/crs_by_administration.csv, first_administration_b2_vs_b3.csv
Run   : python -X utf8 analysis/02_by_administration.py     (seed 20261107)
"""
import math
import sys
from pathlib import Path

import numpy as np
import pandas as pd

sys.stdout.reconfigure(encoding="utf-8")
SEED, N = 20261107, 200000
ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "outputs/tables"
d = pd.read_csv(ROOT / "inputs/crs_by_administration.csv")
rng = np.random.default_rng(SEED)


def rng_counts(pct, n):
    lo = math.ceil(round((pct - 0.5) * n / 100, 9))
    hi = math.floor(round((pct + 0.5) * n / 100, 9))
    return max(lo, 0), max(hi, 0), int(round(pct * n / 100))


rows = []
for _, r in d.iterrows():
    c = {g: rng_counts(r[f"pct_{g}"], r.n_at_risk) for g in ("g1", "g2", "g3_4")}
    pt = sum(v[2] for v in c.values())
    lo = sum(v[0] for v in c.values())
    hi = sum(v[1] for v in c.values())
    a, b = 0.5 + pt, 0.5 + r.n_at_risk - pt
    s = rng.beta(a, b, N)
    rows.append(dict(regimen=r.regimen, administration=r.administration, n_at_risk=r.n_at_risk, pct_any_label_sum=r.pct_g1 + r.pct_g2 + r.pct_g3_4,
                     count_g1=c["g1"][2], count_g2=c["g2"][2], count_g3_4=c["g3_4"][2], count_any=pt, count_any_min=lo, count_any_max=hi,
                     prop_any=pt / r.n_at_risk, post_lo=np.percentile(s, 2.5), post_hi=np.percentile(s, 97.5)))
t = pd.DataFrame(rows)
t.to_csv(OUT / "crs_by_administration.csv", index=False)
pd.set_option("display.width", 250)
print(t.round(3).to_string(index=False))

reg = pd.read_csv(ROOT / "inputs/crs_regimen.csv").set_index("regimen")
for r_, g in t.groupby("regimen"):
    assert g.count_g3_4.sum() == reg.loc[r_, "crs_g3plus"], (r_, g.count_g3_4.sum())
    assert g.count_any.max() <= reg.loc[r_, "crs_any"] <= g.count_any.sum() + 2, r_
    print(f"check {r_}: grade>=3 events over administrations = {g.count_g3_4.sum()} (Table 2: {reg.loc[r_, 'crs_g3plus']}); "
          f"max at one administration = {g.count_any.max()}, patients with CRS (Table 2) = {reg.loc[r_, 'crs_any']}, events summed = {g.count_any.sum()}")

# first administration, B2 (first step-up dose 30 ug/kg) vs B3 (first step-up dose 10 ug/kg): disjoint patients
f2 = t[(t.regimen == "B2") & (t.administration == "step-up 1")].iloc[0]
f3 = t[(t.regimen == "B3") & (t.administration == "step-up 1")].iloc[0]
rows = []
# "label sum": count implied by the printed all-grade total label (sum of the grade labels), rounded; differs from the sum of per-grade rounded counts
lab2 = int(round(f2.pct_any_label_sum * f2.n_at_risk / 100))
lab3 = int(round(f3.pct_any_label_sum * f3.n_at_risk / 100))
print(f"label-sum counts at the first administration: B2 {lab2} (per-grade rounded {int(f2.count_any)}), B3 {lab3} (per-grade rounded {int(f3.count_any)})")
for name, x2, x3 in (("point (round)", f2.count_any, f3.count_any), ("B2 low / B3 high", f2.count_any_min, f3.count_any_max), ("B2 high / B3 low", f2.count_any_max, f3.count_any_min), ("label-sum total", lab2, lab3)):
    p2 = rng.beta(0.5 + x2, 0.5 + f2.n_at_risk - x2, N)
    p3 = rng.beta(0.5 + x3, 0.5 + f3.n_at_risk - x3, N)
    diff = p3 - p2
    rows.append(dict(scenario=name, b2=f"{int(x2)}/{int(f2.n_at_risk)}", b3=f"{int(x3)}/{int(f3.n_at_risk)}", rd_median=np.median(diff), lo=np.percentile(diff, 2.5), hi=np.percentile(diff, 97.5), p_b3_lower=float((diff < 0).mean())))
fa = pd.DataFrame(rows)
fa.to_csv(OUT / "first_administration_b2_vs_b3.csv", index=False)
print("\n== CRS at the first administration, B3 - B2 (reconstructed counts, with rounding extremes)")
print(fa.round(3).to_string(index=False))

# dose escalation vs CRS risk within B2: step-up 1 (30 ug/kg) -> step-up 2 (90 ug/kg): 3-fold dose increase, same patients still at risk
b2 = t[t.regimen == "B2"].set_index("administration")
print(f"\nB2: CRS at step-up 1 (30 ug/kg) {b2.loc['step-up 1','prop_any']:.2f} -> step-up 2 (90 ug/kg) {b2.loc['step-up 2','prop_any']:.2f} -> target 1 {b2.loc['target 1','prop_any']:.2f}")
