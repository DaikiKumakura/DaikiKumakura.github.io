"""Figures (English text). Requires outputs/tables from scripts 01-03. Run: python -X utf8 analysis/04_figures.py"""
import sys
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

sys.stdout.reconfigure(encoding="utf-8")
ROOT = Path(__file__).resolve().parents[1]
T, F = ROOT / "outputs/tables", ROOT / "outputs/figures"
OI = dict(blue="#0072B2", orange="#E69F00", green="#009E73", verm="#D55E00", sky="#56B4E9", grey="#555555")
plt.rcParams.update({"font.size": 9.5, "axes.spines.top": False, "axes.spines.right": False, "figure.dpi": 150})

# Fig 1: schedules (days 0-63)
fig, ax = plt.subplots(figsize=(8.4, 3.3))
rows = [("A: fixed dose Q3W", [(d, "t") for d in (0, 21, 42, 63)]),
        ("B1: fixed dose QW", [(d, "t") for d in range(0, 64, 7)]),
        ("B2: 2 step-ups, then QW", [(0, "s"), (7, "s")] + [(d, "t") for d in range(14, 64, 7)]),
        ("B3: 3 step-ups, QW x3, then Q3W", [(0, "s"), (7, "s"), (14, "s")] + [(d, "t") for d in (21, 28, 35, 42, 63)])]
for i, (lab, ev) in enumerate(rows[::-1]):
    for d, k in ev:
        ax.scatter(d, i, marker="v" if k == "s" else "o", s=55, color=OI["verm"] if k == "s" else OI["blue"], zorder=3)
ax.set_yticks(range(4))
ax.set_yticklabels([r[0] for r in rows[::-1]])
ax.set_xlabel("Day")
ax.scatter([], [], marker="v", color=OI["verm"], label="step-up dose")
ax.scatter([], [], marker="o", color=OI["blue"], label="fixed or target dose")
ax.legend(frameon=False, fontsize=8, loc="upper right", bbox_to_anchor=(1.0, 1.18), ncol=2)
ax.set_title("Dosing schedules of the four regimens (timing only; dose levels differ and are not shown)", fontsize=9, y=1.12)
fig.tight_layout()
fig.savefig(F / "fig1_schedules.png")
plt.close(fig)

# Fig 2: regimen CRS posteriors
p = pd.read_csv(T / "crs_regimen_posterior.csv")
fig, axes = plt.subplots(1, 2, figsize=(9.2, 3.5), sharey=True)
order = ["A", "B1", "B2", "B3", "A+B1 (no step-up)", "B2+B3 (step-up)"]
for ax, ep, ttl in zip(axes, ["CRS any grade", "CRS grade >=3"], ["CRS, any grade", "CRS, grade ≥3"]):
    g = p[p.endpoint == ep].set_index("regimen").loc[order].iloc[::-1]
    y = np.arange(len(g))
    ax.hlines(y, g.lo, g.hi, color="#888")
    ax.scatter(g["median"], y, color=OI["orange"], zorder=3)
    ax.scatter(g.observed, y, marker="x", color="black", zorder=4, s=25)
    ax.set_yticks(y)
    ax.set_yticklabels([f"{r} ({int(e)}/{int(n)})" for r, e, n in zip(g.index, g.events, g.n)])
    ax.set_xlabel("Probability of CRS per patient")
    ax.set_title(ttl, fontsize=9)
axes[0].scatter([], [], color=OI["orange"], label="posterior median and 95% credible interval")
axes[0].scatter([], [], marker="x", color="black", label="observed proportion")
axes[0].legend(frameon=False, fontsize=7.5, loc="lower right")
fig.tight_layout()
fig.savefig(F / "fig2_regimen_crs.png")
plt.close(fig)

# Fig 3: per-administration CRS (reconstructed from percent labels of the original Figure 1)
t = pd.read_csv(T / "crs_by_administration.csv")
fig, axes = plt.subplots(1, 2, figsize=(10.5, 3.7), sharey=True)
for ax, reg in zip(axes, ["B2", "B3"]):
    g = t[t.regimen == reg].reset_index(drop=True)
    x = np.arange(len(g))
    pc = lambda c: g[c] / g.n_at_risk * 100
    ax.bar(x, pc("count_g1"), color=OI["sky"], label="Grade 1")
    ax.bar(x, pc("count_g2"), bottom=pc("count_g1"), color=OI["orange"], label="Grade 2")
    ax.bar(x, pc("count_g3_4"), bottom=pc("count_g1") + pc("count_g2"), color=OI["verm"], label="Grade ≥3")
    ax.errorbar(x, g.prop_any * 100, yerr=[np.clip((g.prop_any - g.post_lo) * 100, 0, None), np.clip((g.post_hi - g.prop_any) * 100, 0, None)], fmt="none", ecolor="black", capsize=2, lw=0.8)
    ax.set_xticks(x)
    ax.set_xticklabels([f"{a}\n(n={n})" for a, n in zip(g.administration.str.replace("continuous target", "continuous"), g.n_at_risk)], fontsize=7)
    ax.set_title(f"Regimen {reg}", fontsize=9)
axes[0].set_ylabel("Patients with CRS at the administration (%)")
axes[0].legend(frameon=False, fontsize=8)
fig.suptitle("CRS by dose administration (counts reconstructed from the percentage labels of the original Figure 1; bars with 95% credible intervals)", fontsize=8.5)
fig.tight_layout()
fig.savefig(F / "fig3_crs_by_administration.png")
plt.close(fig)

# Fig 4: differences and bias
c = pd.read_csv(T / "crs_b2_vs_b3.csv")
fa = pd.read_csv(T / "first_administration_b2_vs_b3.csv").iloc[0]
b = pd.read_csv(T / "crs_bias_sensitivity.csv")
fig, axes = plt.subplots(1, 2, figsize=(9.6, 3.5))
labels = ["CRS, any grade (patients)", "CRS, grade ≥3 (patients)", "CRS at first administration"]
vals = [(c.rd_median[0], c.rd_lo[0], c.rd_hi[0]), (c.rd_median[1], c.rd_lo[1], c.rd_hi[1]), (fa.rd_median, fa.lo, fa.hi)]
ax = axes[0]
for i, (m, lo, hi) in enumerate(vals[::-1]):
    ax.hlines(i, lo * 100, hi * 100, color="#888")
    ax.scatter(m * 100, i, color=OI["orange"], zorder=3)
ax.axvline(0, color=OI["grey"], lw=0.8)
ax.set_yticks(range(3))
ax.set_yticklabels(labels[::-1])
ax.set_xlabel("B3 − B2 (percentage points; posterior median, 95% credible interval)")
ax.set_title("Observed difference between regimens", fontsize=9)
ax = axes[1]
ax.plot(b.bias_logit, b.p_b3_lower, color=OI["blue"], lw=2)
ax.axhline(0.5, color=OI["grey"], lw=0.8, ls=":")
ax.set_xlabel("Assumed bias (logit; > 0 means B3 looked better than it is)")
ax.set_ylabel("P(true B3 CRS rate < true B2 rate)")
ax.set_title("Sensitivity to non-exchangeability (any-grade CRS)", fontsize=9)
fig.tight_layout()
fig.savefig(F / "fig4_b2_vs_b3.png")
plt.close(fig)

# Fig 5: conditional PK vs CRS risk by administration
pk = pd.read_csv(T / "conditional_pk_peaks.csv")
fig, axes = plt.subplots(1, 2, figsize=(10.0, 3.6), sharey=False)
for ax, reg in zip(axes, ["B2", "B3"]):
    g = t[t.regimen == reg].reset_index(drop=True)
    n = len(g) - 1  # exclude the "continuous target" bar (no matching schedule point)
    x = np.arange(n)
    ax.bar(x, g.prop_any[:n] * 100, color=OI["sky"], width=0.6)
    ax.set_ylabel("Patients with CRS (%)")
    ax.set_xticks(x)
    ax.set_xticklabels(g.administration[:n].str.replace("step-up", "step").str.replace("target", "tgt"), fontsize=7.5)
    ax2 = ax.twinx()
    ax2.spines["right"].set_visible(True)
    for hl, ls in ((5.0, ":"), (7.0, "-"), (10.0, "--")):
        s = pk[(pk.regimen == reg) & (pk.half_life_d == hl)].reset_index(drop=True)
        ax2.plot(x, s.conc_end_infusion[:n], color=OI["verm"], ls=ls, marker="o", ms=3, label=f"t½ {hl:g} d" if reg == "B2" else None)
    ax2.set_yscale("log")
    ax2.set_ylabel("Illustrative concentration at end of infusion\n(dose/V units, µg/kg)")
    ax.set_title(f"Regimen {reg}", fontsize=9)
axes[0].figure.axes[2].legend(frameon=False, fontsize=7.5, loc="lower right")
fig.suptitle("CRS per administration against an illustrative dose-proportional concentration (assumed doses; not measured)", fontsize=8.5)
fig.tight_layout()
fig.savefig(F / "fig5_crs_vs_conditional_pk.png")
plt.close(fig)
print("figures written")
