from pathlib import Path
import json,numpy as np,pandas as pd
from scipy.optimize import minimize
from scipy.integrate import solve_ivp
import matplotlib;matplotlib.use('Agg')
import matplotlib.pyplot as plt
R=Path(__file__).resolve().parent;O=R/'results';F=R/'figures';rng=np.random.default_rng(20261004)
FIT='fits-hill' # v1.2 Hill exponent estimated; v1.1 (gamma = 1) in fits-lag, v1.0 (no lag) in fits-primary
def load(label):
 p=R/FIT/label;t=pd.read_csv(p/'theta.csv').set_index('parameter').estimate.to_dict();om=pd.read_csv(p/'omega.csv',index_col=0);return t,np.diag(om).copy()
def cp(t,dose,pars):
 cl,v,ka,tlag=np.asarray(pars).T;ke=cl/v;t=np.maximum(np.asarray(t)-tlag,0) # absorption lag: no input before tlag
 rate_gap=np.abs(ka-ke)
 gap_integral=np.divide(-np.expm1(-rate_gap*t),rate_gap,out=np.array(t,dtype=float),where=rate_gap!=0)
 return np.asarray(dose)/v*ka*np.exp(-t*np.minimum(ka,ke))*gap_integral
def trajectory(times,dose,pk,ic,kout,dt=.25,gam=1.0):
 times=np.asarray(times);pk=np.atleast_2d(pk);n=len(pk);dose=np.broadcast_to(dose,n);ic=np.broadcast_to(ic,n);kout=np.broadcast_to(kout,n);y=np.ones(n);grid=np.arange(0,max(times)+dt/2,dt);z=np.empty((len(grid),n));z[0]=y
 forcing=1/(1+(cp((grid[1:]-.5*dt)[:,None],dose,pk)/ic)**gam);e=np.exp(-kout*dt)
 for j in range(1,len(grid)):
  y=y*e+(1-e)*forcing[j-1];z[j]=y
 if np.allclose(times/dt,np.round(times/dt)):return z[np.round(times/dt).astype(int)]
 return np.array([np.array([np.interp(t,grid,z[:,i])for t in times])for i in range(n)]).T
def map_pk(t,om,g,dose,w=70,weight=False,diagnostics=None):
 pop=np.exp([t['tcl'],t['tv'],t['tka'],t['ttlag']])*([ (w/70)**.75,w/70,1,1]if weight else [1,1,1,1]);om=np.maximum(om,1e-5)
 if not len(g):return pop
 def fun(e):
  pred=cp(g.time.to_numpy(),dose,(pop*np.exp(e))[None,:]);sd=np.sqrt(t['add']**2+(t['prop']*pred)**2)
  return np.sum(np.log(sd)+.5*((g.dv-pred)/sd)**2)+.5*np.sum(e*e/om)
 z=minimize(fun,np.zeros(4),method='L-BFGS-B',bounds=[(-3,3)]*4)
 info=dict(success=bool(z.success),finite=bool(np.isfinite(z.fun) and np.isfinite(z.x).all()),
           at_boundary=bool(np.any(np.isclose(np.abs(z.x),3,rtol=0,atol=1e-8))),message=str(z.message))
 if diagnostics is not None:diagnostics.update(info)
 if not info['finite']:raise ValueError('Non-finite Warfarin MAP estimate')
 return pop*np.exp(z.x)
def run():
 d=pd.read_csv(R/'raw/warfarin.csv');pkd=d.query('evid==0 and dvid=="cp"');base=d.query('evid==0 and dvid=="pca" and time==0').set_index('id').dv
 models=[];status=[];warning_audit=[]
 for p in sorted((R/FIT).iterdir()):
  if p.name.startswith('boot-'):continue # superseded pilot; RNG-reset audit invalidated these resamples
  if not(p/'theta.csv').exists():status.append(dict(run=p.name,finite=False,warning=True));continue
  t,_=load(p.name);txt=(p/'run-info.txt').read_text()+' '+(p/'warnings.txt').read_text();bad=any(s in txt.lower()for s in ['not at minimum','convergence','maximum number','failed'])
  status.append(dict(run=p.name,finite=all(np.isfinite(list(t.values()))),warning=bad))
  warning_audit.append(dict(run=p.name,screen_failed=bad,run_info=(p/'run-info.txt').read_text(),warnings=(p/'warnings.txt').read_text()))
  if p.name in ['pk-constant','pk-refined','pk-allometry','weight-refined','pd-direct','pd-turnover','turn-refined','direct-refined','weight-turn']:
   z=pd.read_csv(p/'objectives.csv');models.append(dict(model=p.name,AIC=z.AIC.iloc[0],objective=z.OBJF.iloc[0],warning=bad))
 # v1.1: every refit must move from both its generic start and the full-data estimates (v1 had 20 PK refits that never moved)
 init={'pk':{'tcl':np.log(.13),'tv':np.log(8),'tka':np.log(1.3),'ttlag':np.log(.8)},'turn':{'tic':np.log(4),'tkout':np.log(.025),'tgam':0.0},'direct':{'tic':np.log(4),'tgam':0.0},'weight':{'tcl':np.log(.13),'tv':np.log(8),'tka':np.log(1.3),'ttlag':np.log(.8)}}
 full={'pk':'pk-refined','turn':'turn-refined','direct':'direct-refined','weight':'weight-refined','weight-turn':'weight-turn'}
 mv=[]
 for p in sorted((R/FIT).iterdir()):
  if not(p.name.startswith(('fold-','resample-','sensitivity-'))and(p/'theta.csv').exists()):continue
  kind='pk' if p.name.startswith('sensitivity') else p.name.split('-',2)[2]
  t,_=load(p.name);f,_=load(full[kind]);keys=[k for k in t if k in f]
  same_full=np.allclose([t[k]for k in keys],[f[k]for k in keys],rtol=1e-6,atol=1e-9)
  ik=init.get(kind,init['turn']);same_init=np.allclose([t[k]for k in ik],[ik[k]for k in ik],rtol=1e-6,atol=1e-9)
  mv.append(dict(run=p.name,kind=kind,equals_full_data_estimate=same_full,equals_generic_start=same_init))
 mv=pd.DataFrame(mv);mv.to_csv(O/'refit-movement.csv',index=False);print('refits',len(mv),'stuck at full-data estimate',int(mv.equals_full_data_estimate.sum()),'stuck at start',int(mv.equals_generic_start.sum()))
 pd.DataFrame(status).to_csv(O/'run-status.csv',index=False);pd.DataFrame(models).to_csv(O/'model-comparison.csv',index=False)
 pd.DataFrame(warning_audit).to_csv(O/'run-warning-audit.csv',index=False)
 # Check independent formulas against R conditional predictions.
 qa=[]
 for label in ['pk-refined','turn-refined','direct-refined']:
  x=pd.read_csv(R/FIT/label/'predictions.csv');err=[]
  for pid,g in x.groupby('ID'):
   dose=d.query('id==@pid and evid==1').amt.iloc[0]
   if label=='pk-refined':
    t,_=load(label);a=g.iloc[0];pars=np.exp([t['tcl']+a['eta.cl'],t['tv']+a['eta.v'],t['tka']+a['eta.ka'],t['ttlag']+a['eta.tlag']]);pred=cp(g.TIME.to_numpy(),dose,pars[None,:])
   else:
    a=g.iloc[0];pars=np.array([a.ICL,a.IV,a.IKA,a.ITLAG]);pred=trajectory(g.TIME,dose,pars,a.ic,a.kout,dt=.05,gam=a.gam).ravel()if label=='turn-refined' else 1/(1+(cp(g.TIME.to_numpy(),dose,pars[None,:])/a.ic)**a.gam)
   err.extend(abs(pred-g.IPRED))
  qa.append(dict(check=label,max_absolute_error=max(err)))
 pd.DataFrame(qa).to_csv(O/'independent-QA.csv',index=False);assert max(q['max_absolute_error']for q in qa)<.001
 # Baseline-complete held-out patients; population parameters refit in each fold.
 folds=pd.read_csv(O/'folds.csv').set_index('ID').fold;rows=[];map_audit=[]
 for pid,b in base.items():
  k=folds.loc[pid];pt,po=load(f'fold-{k}-pk');wt,wo=load(f'fold-{k}-weight');tt,to=load(f'fold-{k}-turn');dt,do=load(f'fold-{k}-direct');gg=d.query('id==@pid');dose=gg.query('evid==1').amt.iloc[0];w=gg.wt.iloc[0]
  for cutoff in [24,48]:
   past=gg.query('dvid=="cp" and evid==0 and time<=@cutoff');future=gg.query('dvid=="pca" and evid==0 and time>@cutoff')
   if not len(future):continue
   for strategy in ['population','weight','PK-informed']:
    info=dict(id=pid,fold=k,cutoff=cutoff,n_pk=len(past))
    if strategy=='PK-informed':
     try:pars=map_pk(pt,po,past,dose,diagnostics=info)
     finally:
      map_audit.append(info)
      pd.DataFrame(map_audit).to_csv(O/'map-diagnostics.csv',index=False)
    elif strategy=='weight':pars=map_pk(wt,wo,past.iloc[:0],dose,w,True)
    else:pars=map_pk(pt,po,past.iloc[:0],dose)
    turntheta=load(f'fold-{k}-weight-turn')[0]if strategy=='weight'else tt
    pred=trajectory(future.time,dose,pars,np.exp(turntheta['tic']),np.exp(turntheta['tkout']),gam=np.exp(turntheta['tgam'])).ravel();dp=np.full(len(future),np.nan)if strategy=='weight'else 1/(1+(cp(future.time.to_numpy(),dose,pars[None,:])/np.exp(dt['tic']))**np.exp(dt['tgam']))
    for ti,obs,pr,dr in zip(future.time,future.dv/b,pred,dp):rows.append(dict(id=pid,fold=k,cutoff=cutoff,strategy=strategy,time=ti,observed=obs,predicted=pr,direct_predicted=dr,n_pk=len(past)if strategy=='PK-informed'else 0))
 cv=pd.DataFrame(rows);cv['squared_error']=(cv.observed-cv.predicted)**2;cv['direct_squared_error']=(cv.observed-cv.direct_predicted)**2;cv.to_csv(O/'held-out-predictions.csv',index=False)
 subject=cv.groupby(['id','cutoff','strategy']).agg(mse=('squared_error','mean'),direct_mse=('direct_squared_error','mean'),n_pk=('n_pk','first')).reset_index();subject.to_csv(O/'held-out-subject-errors.csv',index=False)
 summ=[]
 for (cut,strat),g in subject.groupby(['cutoff','strategy']):
  samples=rng.choice(g.mse.to_numpy(),(2000,len(g)),replace=True).mean(axis=1)**.5;summ.append(dict(cutoff=cut,strategy=strat,subjects=len(g),RMSE=np.sqrt(g.mse.mean()),bootstrap_low=np.quantile(samples,.025),bootstrap_high=np.quantile(samples,.975),direct_RMSE=np.sqrt(g.direct_mse.mean()),mean_PK_measurements=g.n_pk.mean()))
 pd.DataFrame(summ).to_csv(O/'prediction-summary.csv',index=False)
 dif=[]
 for cut in [24,48]:
  a=subject[subject.cutoff==cut].pivot(index='id',columns='strategy',values='mse');v=a['PK-informed']-a.population;s=rng.choice(v,(2000,len(v)),replace=True).mean(axis=1);dif.append(dict(cutoff=cut,subjects=len(v),mean_MSE_difference=v.mean(),low=np.quantile(s,.025),high=np.quantile(s,.975)))
 pd.DataFrame(dif).to_csv(O/'paired-validation.csv',index=False)
 # Bootstrap: retain all warning flags; intervals only from converged sequences, with failure fraction disclosed.
 bt=[]
 for k in range(1,61):
  paths=[R/FIT/f'resample-{k}-{x}'for x in ['pk','turn']]
  if not all((x/'theta.csv').exists()for x in paths):continue
  if mv.set_index('run').loc[[f'resample-{k}-pk',f'resample-{k}-turn'],['equals_full_data_estimate','equals_generic_start']].any(axis=None):continue # refit did not move
  pts,po=load(f'resample-{k}-pk');ts,to=load(f'resample-{k}-turn');bad=any(pd.DataFrame(status).set_index('run').loc[f'resample-{k}-{x}','warning']for x in ['pk','turn']);bt.append(dict(replicate=k,warning=bad,CL=np.exp(pts['tcl']),V=np.exp(pts['tv']),ka=np.exp(pts['tka']),tlag=np.exp(pts['ttlag']),IC50=np.exp(ts['tic']),gamma=np.exp(ts['tgam']),kout=np.exp(ts['tkout'])))
 pd.DataFrame(bt).to_csv(O/'bootstrap-estimates.csv',index=False)
 sens=[]
 for label in ['pk-refined','sensitivity-zero-excluded','sensitivity-replicates-averaged']:
  t,_=load(label);sens.append(dict(run=label,CL=np.exp(t['tcl']),V=np.exp(t['tv']),ka=np.exp(t['tka']),tlag=np.exp(t['ttlag']),PK_records=len(pd.read_csv(R/FIT/label/'predictions.csv'))))
 pd.DataFrame(sens).to_csv(O/'input-sensitivity.csv',index=False)
 # GOF and delay: observed / conditional predictions, not held-out evidence.
 fig,ax=plt.subplots(2,2,figsize=(10,7))
 for a,label,title in zip(ax.ravel(),['pk-refined','turn-refined','direct-refined','turn-refined'],['PK conditional fit','Turnover conditional fit','Direct conditional fit','Turnover residual vs time']):
  x=pd.read_csv(R/FIT/label/'predictions.csv')
  if title.startswith('Turnover residual'):a.scatter(x.TIME,x.DV-x.IPRED,s=9,alpha=.5);a.axhline(0,c='k',lw=1);a.set(xlabel='Time (h)',ylabel='Normalized PCA residual')
  else:a.scatter(x.IPRED,x.DV,s=9,alpha=.5);lim=max(x.DV.max(),x.IPRED.max());a.plot([0,lim],[0,lim],c='k',lw=1);a.set(xlabel='Conditional prediction',ylabel='Observation')
  if label=='pk-refined':a.set(xlabel='Predicted concentration (mg/L)',ylabel='Observed concentration (mg/L)')
  elif not title.startswith('Turnover residual'):a.set(xlabel='Predicted PCA / baseline',ylabel='Observed PCA / baseline')
  a.set_title(title)
 fig.tight_layout();fig.savefig(F/'02-model-diagnostics.png',dpi=180);plt.close(fig)
 fig,ax=plt.subplots(1,2,figsize=(10,4))
 for a,cut in zip(ax,[24,48]):
  g=pd.DataFrame(summ).query('cutoff==@cut');a.errorbar(np.arange(len(g)),g.RMSE,yerr=[g.RMSE-g.bootstrap_low,g.bootstrap_high-g.RMSE],fmt='o',capsize=4);a.set_xticks(np.arange(len(g)),g.strategy,rotation=15);a.set(title=f'Future PCA after {cut} h',ylabel='Subject-balanced normalized PCA RMSE',ylim=(0,None))
 fig.tight_layout();fig.savefig(F/'03-held-out-predictions.png',dpi=180);plt.close(fig)
 shrink=[]
 for label in ['pk-refined','turn-refined']:
  t,om=load(label);eta=pd.read_csv(R/FIT/label/'eta.csv')
  for nm,var in zip(eta.columns[1:],om):shrink.append(dict(model=label,parameter=nm,variance_shrinkage=1-eta[nm].var()/var))
 pd.DataFrame(shrink).to_csv(O/'shrinkage.csv',index=False)
 # Parametric predictive check at actual times. Whole subject random effects are shared across samples.
 pt,po=load('pk-refined');tt,to=load('turn-refined');vrows=[]
 for pid,b in base.items():
  gg=d.query('id==@pid and dvid=="pca" and evid==0 and time>0');dose=d.query('id==@pid and evid==1').amt.iloc[0];pars=np.exp(np.array([pt['tcl'],pt['tv'],pt['tka'],pt['ttlag']])+rng.normal(size=(500,4))*np.sqrt(po));ic=np.exp(tt['tic']+rng.normal(size=500)*np.sqrt(to[0]));ko=np.exp(tt['tkout']+rng.normal(size=500)*np.sqrt(to[1]));sim=trajectory(gg.time,dose,pars,ic,ko,gam=np.exp(tt['tgam']))+rng.normal(size=(len(gg),500))*tt['err']
  for j,(_,r) in enumerate(gg.iterrows()):vrows.append(dict(id=pid,time=r.time,observed=r.dv/b,q05=np.quantile(sim[j],.05),median=np.median(sim[j]),q95=np.quantile(sim[j],.95)))
 vpc=pd.DataFrame(vrows);vpc.to_csv(O/'predictive-check.csv',index=False)
 # Not confidence bands: uncertainty in fitted parameters is excluded.
 fig,ax=plt.subplots(figsize=(8,4));a=vpc.groupby('time')[['q05','median','q95','observed']].median();ax.fill_between(a.index,a.q05,a.q95,alpha=.2,label='Median pointwise 90% predictive limits');ax.plot(a.index,a['median'],label='Median prediction');ax.scatter(vpc.time,vpc.observed,s=8,alpha=.35,label='Observed normalized PCA');ax.set(xlabel='Time (h)',ylabel='PCA / measured baseline',title='In-sample predictive check; fixed fitted parameters');ax.legend(fontsize=8);fig.tight_layout();fig.savefig(F/'05-predictive-check.png',dpi=180);plt.close(fig)
 print(pd.DataFrame(models).to_string(index=False));print(pd.DataFrame(summ).to_string(index=False));print('QA',qa)
if __name__=='__main__':run()


