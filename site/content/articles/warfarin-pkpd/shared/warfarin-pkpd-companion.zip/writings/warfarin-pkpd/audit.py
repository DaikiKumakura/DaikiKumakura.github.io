from pathlib import Path
import numpy as np,pandas as pd,json,hashlib,urllib.request
R=Path(__file__).resolve().parent;O=R/'results';O.mkdir(exist_ok=True);F=R/'figures';F.mkdir(exist_ok=True)
d=pd.read_csv(R/'raw/warfarin.csv');pk=d[(d.evid==0)&(d.dvid=='cp')];pdv=d[(d.evid==0)&(d.dvid=='pca')];dose=d[d.evid==1]
assert len(dose)==32 and dose.groupby('id').size().eq(1).all();assert set(pk.id)==set(pdv.id)==set(dose.id)
assert not d.duplicated().any();assert not d.isna().any().any()
assert d.groupby('id')[['wt','age','sex']].nunique().max().max()==1
summary=dict(rows=len(d),subjects=d.id.nunique(),PK_observations=len(pk),PCA_observations=len(pdv),dose_events=len(dose),PK_zero=len(pk[pk.dv==0]),PCA_baseline_observations=int((pdv.time==0).sum()),WGT_range=[float(d.wt.min()),float(d.wt.max())],AGE_range=[int(d.age.min()),int(d.age.max())],PK_range=[float(pk.dv.min()),float(pk.dv.max())],PCA_range=[float(pdv.dv.min()),float(pdv.dv.max())],dose_range=[float(dose.amt.min()),float(dose.amt.max())],max_dose_per_kg_deviation=float(abs(dose.amt/dose.wt-1.5).max()),CSV_SHA256=hashlib.sha256((R/'raw/warfarin.csv').read_bytes()).hexdigest())
(O/'audit-summary.json').write_text(json.dumps(summary,indent=2))
pd.concat([pk.groupby('id').agg(n_pk=('dv','size'),pk_last=('time','max')),pdv.groupby('id').agg(n_pd=('dv','size'),pd_first=('time','min'),pd_last=('time','max')),dose.set_index('id')[['amt','wt','age','sex']]],axis=1).to_csv(O/'subject-audit.csv')
url='https://holford.fmhs.auckland.ac.nz/research/nlmixr/warfarin/warfarin_dat.csv';p=R/'raw/holford-original.csv'
if not p.exists():p.write_bytes(urllib.request.urlopen(url,timeout=60).read())
original=pd.read_csv(p);original.columns=original.columns.str.lower();original.to_csv(O/'upstream-comparison-input.csv',index=False)
checks={c:bool(np.array_equal(d[c].to_numpy(),original[c].to_numpy()))for c in ['id','time','amt','dv','evid','wt','age']}
checks['dvid']=bool(np.array_equal(d.dvid.map({'cp':1,'pca':2}),original.dvid));checks['sex']=bool(np.array_equal(d.sex.map({'female':0,'male':1}),original.sex));assert all(checks.values())
summary.update(original_numeric_match=checks,original_url=url,original_SHA256=hashlib.sha256(p.read_bytes()).hexdigest(),PD_missing_baseline_ids=[1,7],duplicate_PK_time_keys=4,duplicate_PK_records=8,PD_primary_subjects=30,PD_primary_observations=int(len(pdv[~pdv.id.isin([1,7])])),baseline_PCA_values=pdv[pdv.time==0].dv.value_counts().to_dict())
(O/'audit-summary.json').write_text(json.dumps(summary,indent=2))
(O/'data-dictionary.md').write_text('# Data dictionary\n\n| Field | Meaning / units |\n|---|---|\n|id|Subject ID; 32 subjects, ID11 absent|\n|time|Hours since single oral dose|\n|amt|Dose in mg on evid=1 records; zero otherwise|\n|dv|cp: mg/L; pca: percent activity|\n|dvid|Endpoint: cp or pca|\n|evid|1 dose, 0 observation|\n|wt|Weight, kg|\n|age|Years|\n|sex|female/male, upstream 0/1|\n\nNo LLOQ, INR, genotype, interoccasion or bleeding information is supplied. PK duplicates have distinct values and are retained. PCA baseline normalization creates correlated measurement error; sensitivity and prediction limitations must acknowledge it. University input is numerically identical, including endpoint and sex recoding.\n',encoding='utf-8')
print(json.dumps(summary,indent=2));print('Holford original columns/shape:',list(original.columns),original.shape);print(original.head(6).to_string(index=False))
import matplotlib;matplotlib.use('Agg');import matplotlib.pyplot as plt
fig,axs=plt.subplots(2,2,figsize=(10,7))
for _,g in pk.groupby('id'):axs[0,0].plot(g.time,g.dv,alpha=.35,lw=1)
for _,g in pdv.groupby('id'):axs[0,1].plot(g.time,g.dv,alpha=.35,lw=1)
axs[0,0].set(xlabel='Time (h)',ylabel='Concentration (mg/L)',title='32 subjects: observed PK')
axs[0,1].set(xlabel='Time (h)',ylabel='PCA (%)',title='Same subjects: observed PD')
axs[1,0].scatter(dose.wt,dose.amt);axs[1,0].set(xlabel='Weight (kg)',ylabel='Dose (mg)',title='Dose already scales with weight')
for pid,g in d[d.evid==0].groupby('id'):
 for label,offset,color in [('cp',0,'#2563a5'),('pca',.25,'#d17b22')]:
  x=g[g.dvid==label];axs[1,1].scatter(x.time,np.full(len(x),pid+offset),s=5,c=color)
axs[1,1].set(xlabel='Time (h)',ylabel='Subject ID',title='PK (blue) / PCA (orange) sampling')
fig.tight_layout();fig.savefig(F/'01-data-audit.png',dpi=180);plt.close(fig)
