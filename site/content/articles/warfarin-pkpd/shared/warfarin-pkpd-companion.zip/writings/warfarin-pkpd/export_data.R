p <- 'writings/warfarin-pkpd'
load(file.path(p,'raw/data__warfarin.rda'))
write.csv(warfarin,file.path(p,'raw/warfarin.csv'),row.names=FALSE)
capture.output(str(warfarin),summary(warfarin),file=file.path(p,'raw/export-summary.txt'))
capture.output(sessionInfo(),file=file.path(p,'raw/sessionInfo.txt'))
print(head(warfarin,15));print(table(warfarin$dvid,warfarin$evid))
