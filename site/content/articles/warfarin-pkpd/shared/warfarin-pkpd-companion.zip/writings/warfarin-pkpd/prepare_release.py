from pathlib import Path
import os,sys,json,hashlib,shutil,zipfile,tempfile
R=Path(__file__).resolve().parent;deps=R.parent/'nimotuzumab-poppk/.notebook-deps'
if not deps.exists():deps=R/'.notebook-runtime'
sys.path.insert(0,str(deps));os.environ['PYTHONPATH']=str(deps)+os.pathsep+os.environ.get('PYTHONPATH','');os.environ['JUPYTER_PATH']=str(deps/'share/jupyter');os.environ['OPENBLAS_NUM_THREADS']='1'
import pandas as pd,numpy as np,markdown,nbformat
from nbclient import NotebookClient
from jupyter_client.kernelspec import KernelSpecManager
O=R/'results';F=R/'figures';rel=R/'release';pub=rel/'writings/warfarin-pkpd';pub.mkdir(parents=True,exist_ok=True)
def table(df):
 def fmt(v):
  if pd.isna(v):return '—'
  if isinstance(v,(float,np.floating)):return f'{v:.2e}'if 0<abs(v)<.0001 else f'{v:.4f}'
  return str(v).replace('|','/')
 return '\n'.join(['| '+' | '.join(df.columns)+' |','| '+' | '.join(['---']*len(df.columns))+' |']+['| '+' | '.join(fmt(v)for v in row)+' |'for row in df.itertuples(index=False,name=None)])
def th(name):return pd.read_csv(R/'fits-lag'/name/'theta.csv').set_index('parameter').estimate
audit=json.loads((O/'audit-summary.json').read_text());pk=th('pk-refined');pdth=th('turn-refined');cv=pd.read_csv(O/'prediction-summary.csv');paired=pd.read_csv(O/'paired-validation.csv');s=pd.read_csv(O/'scenario-summary.csv');base=s[s.replicate==0];struct=pd.read_csv(O/'scenario-structural-sensitivity.csv');bs=pd.read_csv(O/'bootstrap-estimates.csv');status=pd.read_csv(O/'run-status.csv');models=pd.read_csv(O/'model-comparison.csv');qa=pd.read_csv(O/'independent-QA.csv')
# v1.1: article.md is maintained by hand (synced from the published en.md); it is no longer generated from a template
article=(R/'article.md').read_text(encoding='utf-8')
files=['acquire.py','export_data.R','audit.py','fit.R','weight_pd.R','analyze.py','scenarios.py','prepare_release.py','validate.py','analysis-plan.md','README.md','article.md','fit-v1-nolag.R','analyze-v1-nolag.py','scenarios-v1-nolag.py','article-v1-nolag.md']
tables=['audit-summary.json','data-dictionary.md','model-comparison.csv','prediction-summary.csv','paired-validation.csv','run-status.csv','run-warning-audit.csv','bootstrap-estimates.csv','shrinkage.csv','independent-QA.csv','input-sensitivity.csv','scenario-grid-QA.csv','scenario-summary.csv','scenario-paired-gains.csv','scenario-structural-sensitivity.csv','refit-movement.csv','sessionInfo.txt']
for f in files:shutil.copy2(R/f,pub/f)
(pub/'results').mkdir(exist_ok=True)
for f in tables:shutil.copy2(O/f,pub/'results'/f)
(pub/'results-v1-nolag').mkdir(exist_ok=True)
for f in tables:
 if (R/'results-v1-nolag'/f).exists():shutil.copy2(R/'results-v1-nolag'/f,pub/'results-v1-nolag'/f)
(pub/'figures').mkdir(exist_ok=True)
for f in F.glob('*.png'):shutil.copy2(f,pub/'figures'/f.name)
(pub/'source-provenance.json').write_text((R/'raw/source-manifest.json').read_text(),encoding='utf-8')
md=nbformat.v4.new_markdown_cell;code=nbformat.v4.new_code_cell
nb=nbformat.v4.new_notebook(cells=[md('# Warfarin: when does individual information improve PK/PD prediction?\n\nExecuted review of completed estimation results. Read article.md for methods and limitations. This notebook does not rerun the long R fits; README gives full commands. No raw patient data is distributed.'),code("from pathlib import Path\nimport json,pandas as pd,numpy as np\nfrom IPython.display import Image,display\nR=Path('.')\na=json.loads((R/'results/audit-summary.json').read_text())\nassert a['rows']==515 and a['subjects']==32 and a['PD_primary_subjects']==30\nassert all(a['original_numeric_match'].values())\nprint('Acquired original-data match and audit verified')\ndisplay(pd.read_csv('results/model-comparison.csv'))"),md('## Subject-separated validation\nOnly prior PK is used, never future concentrations or postbaseline PCA. Confidence intervals here resample subjects conditional on existing trained folds; model uncertainty remains.'),code("p=pd.read_csv('results/prediction-summary.csv')\nassert set(p.subjects)=={29,30}\nassert len(p)==6\ndisplay(p)\ndisplay(pd.read_csv('results/paired-validation.csv'))\ns=pd.read_csv('results/run-status.csv')\nprint('Final runs:',len(s),'finite:',s.finite.sum(),'optimization warnings:',s.warning.sum())\nb=pd.read_csv('results/bootstrap-estimates.csv')\nassert len(b)==59\nprint('Bootstrap sequences used (one PK refit that did not move excluded):',len(b),'warning-free:',(~b.warning).sum())"),md('## Implementation checks and simulated dose comparison\nNumerical agreement does not qualify the model. Dose targets are arbitrary. An oracle is a separate unimplementable bound.'),code("q=pd.read_csv('results/independent-QA.csv')\nassert q.max_absolute_error.max()<.001\ndisplay(q)\ndisplay(pd.read_csv('results/shrinkage.csv'))\nx=pd.read_csv('results/scenario-summary.csv')\nassert (x.target_fraction.between(0,1)).all()\ndisplay(x[x.replicate==0])\ndisplay(pd.read_csv('results/scenario-structural-sensitivity.csv'))"),code("for p in sorted(Path('figures').glob('*.png')):\n    display(Image(filename=str(p)))"),md('## Interpretation\nNo improvement in held-out PCA prediction from limited PK was established (version 1.1, absorption lag). Optimizer warnings and conditional sequential fitting preclude strong model qualification or formal parameter confidence intervals. Simulation is exploratory and unvalidated.')])
spec=Path(tempfile.mkdtemp(prefix='warfarin-kernel-'));(spec/'kernel.json').write_text(json.dumps({'argv':[sys.executable,'-m','ipykernel_launcher','-f','{connection_file}'],'display_name':'Warfarin review','language':'python','env':{'PYTHONPATH':str(deps),'OPENBLAS_NUM_THREADS':'1'}}));KernelSpecManager().install_kernel_spec(str(spec),kernel_name='warfarin-review',user=False,prefix=str(deps));nb.metadata['kernelspec']={'name':'warfarin-review','display_name':'Warfarin review','language':'python'};NotebookClient(nb,timeout=120,kernel_name='warfarin-review',resources={'metadata':{'path':str(pub)}}).execute();nbformat.validate(nb);nbformat.write(nb,pub/'analysis.ipynb');shutil.copy2(pub/'analysis.ipynb',R/'analysis.ipynb')
html='<!doctype html><html lang="en"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>When does individual information improve PK/PD prediction?</title><style>body{font:17px/1.65 system-ui;color:#23313d;background:#fafbfd;margin:0}main{max-width:900px;margin:auto;padding:24px}h1{font-size:1.9rem;line-height:1.25}h2{font-size:1.35rem;margin-top:2rem}img{max-width:100%;height:auto}table{border-collapse:collapse;font-size:.88rem}td,th{padding:7px;border-bottom:1px solid #ccd4da;text-align:left}.table-wrap,pre{overflow-x:auto}a{color:#196298}code{overflow-wrap:anywhere}pre{background:#eef2f5;padding:12px}</style><main>'+markdown.markdown(article,extensions=['tables','fenced_code'])+'</main></html>';html=html.replace('<table>','<div class="table-wrap"><table>').replace('</table>','</table></div>');(pub/'index.html').write_text(html,encoding='utf-8')
manifest={str(p.relative_to(pub)).replace('\\','/'):hashlib.sha256(p.read_bytes()).hexdigest()for p in pub.rglob('*')if p.is_file()and p.name not in ['manifest.json','warfarin-reproduction.zip']};(pub/'manifest.json').write_text(json.dumps(manifest,indent=2),encoding='utf-8')
with zipfile.ZipFile(pub/'warfarin-reproduction.zip','w',zipfile.ZIP_DEFLATED)as z:
 for name in [*manifest,'manifest.json']:z.write(pub/name,'writings/warfarin-pkpd/'+name)
# v1.1: publication status is maintained separately (article already published)
print('Article, executed notebook and public whitelist staged:',pub)

