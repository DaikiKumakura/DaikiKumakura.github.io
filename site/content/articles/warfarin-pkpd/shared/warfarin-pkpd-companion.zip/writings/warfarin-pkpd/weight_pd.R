# Reestimate the same turnover structure after allometric PK; no shared PD theta shortcut.
source('writings/warfarin-pkpd/fit.R')
weightedpd<-function(raw,pf){x<-makepd(raw,pf);x$ICL<-x$ICL*(x$WT/70)^.75;x$IV<-x$IV*x$WT/70;x}
wf<-run(warm(turn,t1),weightedpd(d,w1),'weight-turn')
for(k in 1:5){tr<-d[fold[as.character(d$ID)]!=k,];pf<-readRDS(file.path(p,fitdir,paste0('fold-',k,'-weight'),'fit.rds'));run(warm(turn,wf),weightedpd(tr,pf),paste0('fold-',k,'-weight-turn'))}
