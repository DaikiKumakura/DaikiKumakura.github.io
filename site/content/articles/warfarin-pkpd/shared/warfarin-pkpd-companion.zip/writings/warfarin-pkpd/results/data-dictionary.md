# Data dictionary

| Field | Meaning / units |
|---|---|
|id|Subject ID; 32 subjects, ID11 absent|
|time|Hours since single oral dose|
|amt|Dose in mg on evid=1 records; zero otherwise|
|dv|cp: mg/L; pca: percent activity|
|dvid|Endpoint: cp or pca|
|evid|1 dose, 0 observation|
|wt|Weight, kg|
|age|Years|
|sex|female/male, upstream 0/1|

No LLOQ, INR, genotype, interoccasion or bleeding information is supplied. PK duplicates have distinct values and are retained. PCA baseline normalization creates correlated measurement error; sensitivity and prediction limitations must acknowledge it. University input is numerically identical, including endpoint and sex recoding.
