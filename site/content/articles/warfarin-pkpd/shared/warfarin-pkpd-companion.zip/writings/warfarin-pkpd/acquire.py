"""Acquire the pinned upstream data and keep a source/hash manifest."""
from pathlib import Path
import urllib.request,json,hashlib
R=Path(__file__).resolve().parent;RAW=R/'raw';RAW.mkdir(exist_ok=True)
COMMIT='f2cfb01ade88d4d30e66f56b19efce2a2c6e26bd'
paths=['DESCRIPTION','LICENSE.md','R/data_warfarin.R','man/warfarin.Rd','data/warfarin.rda']
items=[]
old=json.loads((RAW/'source-manifest.json').read_text())if(RAW/'source-manifest.json').exists()else None
for p in paths:
 url=f'https://raw.githubusercontent.com/nlmixr2/nlmixr2data/{COMMIT}/{p}'
 data=urllib.request.urlopen(url,timeout=60).read();h=hashlib.sha256(data).hexdigest();name=p.replace('/','__')
 if old:assert h==next(x['sha256']for x in old['files']if x['path']==p),p
 target=RAW/name
 if target.exists():assert target.read_bytes()==data,p
 else:target.write_bytes(data)
 items.append(dict(path=p,file=name,url=url,bytes=len(data),sha256=h))
(RAW/'source-manifest.json').write_text(json.dumps(dict(commit=COMMIT,package='nlmixr2data',files=items),indent=2),encoding='utf-8')
print('Pinned source files acquired:',len(items))
