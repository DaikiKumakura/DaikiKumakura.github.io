from pathlib import Path
import json,hashlib,zipfile,re,numpy as np,pandas as pd
R=Path(__file__).resolve().parent;O=R/'results';pub=R/'release/writings/warfarin-pkpd'
a=json.loads((O/'audit-summary.json').read_text());assert a['rows']==515 and a['PD_primary_observations']==218;assert all(a['original_numeric_match'].values())
sampling=pd.read_csv(O/'bootstrap-sampling.csv');assert len(sampling)==60*32;assert sampling.groupby('replicate').source_ID.apply(tuple).nunique()==60
b=pd.read_csv(O/'bootstrap-estimates.csv');assert len(b)==60;assert b.CL.nunique()>30,'RNG reset or identical bootstrap fits'
status=pd.read_csv(O/'run-status.csv');assert len(status)==156 and status.finite.all();assert not status.run.str.startswith('boot-').any()
fold=pd.read_csv(O/'folds.csv').set_index('ID').fold
for k in range(1,6):
 train=pd.read_csv(R/'fits-primary'/f'fold-{k}-pk/predictions.csv');assert all(fold.loc[train.ID.unique()]!=k)
pred=pd.read_csv(O/'held-out-predictions.csv');assert (pred.time>pred.cutoff).all();assert (pred.fold==pred.id.map(fold)).all()
for label in ['turn-refined','direct-refined','weight-turn']:
 x=pd.read_csv(R/'fits-primary'/label/'predictions.csv');assert len(x)==188 and (x.TIME>0).all();assert x.ID.nunique()==30
assert pd.read_csv(O/'independent-QA.csv').max_absolute_error.max()<.001
grid=pd.read_csv(O/'scenario-grid-QA.csv');assert grid.max_nadir_difference.max()<.003
s=pd.read_csv(O/'scenario-summary.csv');assert len(s)==105 and s.target_fraction.between(0,1).all();assert (s[s.replicate==0].n==300).all()
for f in ['paired-scenarios.csv','allometry-paired-scenarios.csv']:
 x=pd.read_csv(O/f);assert len(x)==1500;assert x.groupby('patient').strategy.nunique().eq(5).all();assert x.dose.between(60,153).all();assert x.nadir.between(0,1).all()
manifest=json.loads((pub/'manifest.json').read_text())
for name,h in manifest.items():assert hashlib.sha256((pub/name).read_bytes()).hexdigest()==h,name
with zipfile.ZipFile(pub/'warfarin-reproduction.zip')as z:
 assert z.testzip()is None
 for name in z.namelist():assert not any(s in name for s in ['raw/','fits/','fits-primary/','.rds'])
nb=json.loads((pub/'analysis.ipynb').read_text());cells=[c for c in nb['cells']if c['cell_type']=='code'];assert len(cells)==4;assert all(c['execution_count']is not None for c in cells);assert not any(o['output_type']=='error'for c in cells for o in c['outputs'])
assert (R/'article.md').read_bytes()==(pub/'article.md').read_bytes()
article=(pub/'article.md').read_text(encoding='utf-8')
for path in re.findall(r'!\[[^\]]*\]\(([^)]+)\)',article):assert (pub/path).exists(),path
result={'status':'passed','primary_runs':len(status),'finite_bootstrap_sequences':len(b),'distinct_resamples':60,'executed_notebook_cells':len(cells),'figure_files':len(list((pub/'figures').glob('*.png'))),'public_files_verified':len(manifest),'clinical_qualification':False,'publication':'not published'}
(O/'validation-report.json').write_text(json.dumps(result,indent=2));print(json.dumps(result,indent=2))
