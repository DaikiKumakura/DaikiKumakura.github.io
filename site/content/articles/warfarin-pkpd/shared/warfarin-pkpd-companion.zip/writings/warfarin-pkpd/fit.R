p <- 'writings/warfarin-pkpd'
fitdir <- 'fits-hill'  # v1.2: Hill exponent estimated in both PD models. Earlier: v1.1: absorption lag with IIV, PK as ODE (linCmt()+alag without covariates stalled near OFV 383); v1 fits kept in fits-primary
localLib <- 'writings/nimotuzumab-poppk/.r-library'
if(dir.exists(localLib)) .libPaths(c(normalizePath(localLib),.libPaths()))
library(nlmixr2est);library(rxode2)
d<-read.csv(file.path(p,'raw/warfarin.csv')); names(d)<-toupper(names(d));d$CMT<-1
pk<-d[d$EVID==1|d$DVID=='cp',];pk$WGT<-pk$WT
pk0<-function(){ini({tcl<-log(.13);tv<-log(8);tka<-log(1.3);ttlag<-log(.8);eta.cl~.08;eta.v~.02;eta.ka~.5;eta.tlag~.4;add<-0.3;prop<-0.1});model({cl<-exp(tcl+eta.cl);v<-exp(tv+eta.v);ka<-exp(tka+eta.ka);tlag<-exp(ttlag+eta.tlag);d/dt(depot)<- -ka*depot;d/dt(central)<-ka*depot-cl/v*central;alag(depot)<-tlag;cp<-central/v;cp~add(add)+prop(prop)})}
pkw<-function(){ini({tcl<-log(.13);tv<-log(8);tka<-log(1.3);ttlag<-log(.8);eta.cl~.08;eta.v~.02;eta.ka~.5;eta.tlag~.4;add<-0.3;prop<-0.1});model({cl<-exp(tcl+eta.cl)*(WGT/70)^.75;v<-exp(tv+eta.v)*(WGT/70);ka<-exp(tka+eta.ka);tlag<-exp(ttlag+eta.tlag);d/dt(depot)<- -ka*depot;d/dt(central)<-ka*depot-cl/v*central;alag(depot)<-tlag;cp<-central/v;cp~add(add)+prop(prop)})}
turn<-function(){ini({tic<-log(4);tkout<-log(.025);tgam<-log(1);eta.ic~.2;eta.kout~.1;err<-.1});model({ic<-exp(tic+eta.ic);kout<-exp(tkout+eta.kout);gam<-exp(tgam);depot(0)<-0;central(0)<-0;response(0)<-1;alag(depot)<-ITLAG;d/dt(depot)<- -IKA*depot;d/dt(central)<-IKA*depot-ICL/IV*central;cp<-central/IV;d/dt(response)<-kout*(1/(1+(cp/ic)^gam)-response);response~add(err)})}
direct<-function(){ini({tic<-log(4);tgam<-log(1);eta.ic~.2;err<-.15});model({ic<-exp(tic+eta.ic);gam<-exp(tgam);depot(0)<-0;central(0)<-0;alag(depot)<-ITLAG;d/dt(depot)<- -IKA*depot;d/dt(central)<-IKA*depot-ICL/IV*central;cp<-central/IV;response<-1/(1+(cp/ic)^gam);response~add(err)})}
ctl<-foceiControl(seed=20261004,outerOpt='bobyqa',maxOuterIterations=500,maxInnerIterations=150,print=0,covMethod='',rxControl=rxControl(cores=1,atol=1e-8,rtol=1e-6))
run <- function(fn, input, label) {
  o <- file.path(p, fitdir, label)
  dir.create(o, recursive=TRUE, showWarnings=FALSE)
  fit_path <- file.path(o, 'fit.rds')
  spec_path <- file.path(o, 'specification.rds')
  outputs <- file.path(o, c('warnings.txt','theta.csv','omega.csv','predictions.csv',
                            'objectives.csv','run-info.txt','eta.csv'))
  spec <- list(input=input, model=fn, control=ctl)
  if (file.exists(fit_path) && all(file.exists(c(spec_path, outputs)))) {
    saved <- tryCatch(readRDS(spec_path), error=function(e) NULL)
    if (is.function(saved$model) && identical(body(saved$model),body(fn)) &&
        identical(formals(saved$model),formals(fn)) && identical(saved$input,input) &&
        identical(saved$control,ctl)) {
      cached <- tryCatch(readRDS(fit_path), error=function(e) NULL)
      if (!is.null(cached)) return(cached)
    }
  }
  if (file.exists(fit_path) && !file.remove(fit_path))
    stop('Could not invalidate fit cache: ', label)
  ws <- character()
  saveRDS(spec,spec_path)
  f <- tryCatch(withCallingHandlers(nlmixr2(fn,input,est='focei',control=ctl),
      warning=function(w) {ws <<- c(ws,conditionMessage(w)); invokeRestart('muffleWarning')}),
      error=function(e) e)
  writeLines(ws,file.path(o,'warnings.txt'))
  if (inherits(f,'error')) {
    writeLines(conditionMessage(f),file.path(o,'error.txt'))
    stop(f)
  }
  write.csv(data.frame(parameter=names(fixef(f)),estimate=fixef(f)),file.path(o,'theta.csv'),row.names=FALSE)
  write.csv(f$omega,file.path(o,'omega.csv'))
  write.csv(as.data.frame(f),file.path(o,'predictions.csv'),row.names=FALSE)
  write.csv(f$objDf,file.path(o,'objectives.csv'))
  writeLines(as.character(f$runInfo),file.path(o,'run-info.txt'))
  write.csv(f$eta,file.path(o,'eta.csv'),row.names=FALSE)
  pending <- tempfile(tmpdir=o)
  saveRDS(f,pending)
  if (!file.rename(pending,fit_path)) stop('Could not finalize fit cache: ',label)
  cat('DONE',label,'\n')
  flush.console()
  f
}
runwith<-function(fn,input,label,cc){old<-ctl;ctl<<-cc;on.exit(ctl<<-old);run(fn,input,label)}
makepd<-function(raw,fit){eta<-fit$eta;th<-fixef(fit);base<-raw[raw$DVID=='pca'&raw$TIME==0&raw$EVID==0,c('ID','DV')];x<-raw[raw$ID%in%base$ID&(raw$EVID==1|raw$DVID=='pca'),];x$DV[x$EVID==0]<-x$DV[x$EVID==0]/base$DV[match(x$ID[x$EVID==0],base$ID)];e<-eta[match(x$ID,eta$ID),];x$ICL<-exp(th['tcl']+e$eta.cl);x$IV<-exp(th['tv']+e$eta.v);x$IKA<-exp(th['tka']+e$eta.ka);x$ITLAG<-exp(th['ttlag']+e$eta.tlag);x$CMT<-ifelse(x$EVID==1,1,3);x[x$EVID==1|x$TIME>0,]}
ctl0<-ctl # generic-start control, reused for every refit so that no fold or resample starts from full-data estimates (v1.1)
f0<-run(pk0,pk,'pk-constant');fw<-run(pkw,pk,'pk-allometry')
pd<-makepd(d,f0);fd<-run(direct,transform(pd,CMT=ifelse(EVID==1,1,2)),'pd-direct');ft<-run(turn,pd,'pd-turnover')
capture.output(sessionInfo(),file=file.path(p,'results/sessionInfo.txt'))
warm<-function(fn,fit){b<-body(fn);ie<-b[[2]][[2]];th<-fixef(fit);om<-fit$omega;for(j in seq_along(ie)[-1]){a<-ie[[j]];if(is.call(a)&&identical(a[[1]],as.name('<-'))&&as.character(a[[2]])%in%names(th))ie[[j]][[3]]<-unname(th[as.character(a[[2]])]);if(is.call(a)&&identical(a[[1]],as.name('~'))&&as.character(a[[2]])%in%rownames(om))ie[[j]][[3]]<-max(.001,om[as.character(a[[2]]),as.character(a[[2]])])};b[[2]][[2]]<-ie;body(fn)<-b;fn}
ctl<-foceiControl(seed=20261004,outerOpt='nlminb',maxOuterIterations=1000,maxInnerIterations=300,print=0,covMethod='',rxControl=rxControl(cores=1,atol=1e-8,rtol=1e-6))
f1<-run(warm(pk0,f0),pk,'pk-refined');w1<-run(warm(pkw,fw),pk,'weight-refined');pd<-makepd(d,f1);t1<-run(warm(turn,ft),pd,'turn-refined');d1<-run(warm(direct,fd),transform(pd,CMT=ifelse(EVID==1,1,2)),'direct-refined')
ids<-sort(unique(d$ID));fold<-setNames((seq_along(ids)-1)%%5+1,ids);write.csv(data.frame(ID=ids,fold=fold),file.path(p,'results/folds.csv'),row.names=FALSE)
for(k in 1:5){tr<-d[fold[as.character(d$ID)]!=k,];kp<-pk[fold[as.character(pk$ID)]!=k,];pf<-runwith(pk0,kp,paste0('fold-',k,'-pk'),ctl0);pdf<-makepd(tr,pf);runwith(turn,pdf,paste0('fold-',k,'-turn'),ctl0);runwith(direct,transform(pdf,CMT=ifelse(EVID==1,1,2)),paste0('fold-',k,'-direct'),ctl0);runwith(pkw,kp,paste0('fold-',k,'-weight'),ctl0)}
set.seed(20261004);samples<-lapply(1:60,function(k)sample(ids,length(ids),replace=TRUE));write.csv(do.call(rbind,lapply(1:60,function(k)data.frame(replicate=k,new_ID=1:length(ids),source_ID=samples[[k]]))),file.path(p,'results/bootstrap-sampling.csv'),row.names=FALSE)
for(k in 1:60){sampleids<-samples[[k]];b<-do.call(rbind,lapply(seq_along(sampleids),function(j){x<-d[d$ID==sampleids[j],];x$ID<-j;x}));bp<-b[b$EVID==1|b$DVID=='cp',];bp$WGT<-bp$WT;tryCatch({bf<-runwith(pk0,bp,paste0('resample-',k,'-pk'),ctl0);runwith(turn,makepd(b,bf),paste0('resample-',k,'-turn'),ctl0)},error=function(e)cat('BOOT FAILED',k,conditionMessage(e),'\n'))}
runwith(pk0,pk[pk$EVID==1|pk$DV>0,],'sensitivity-zero-excluded',ctl0)
av<-aggregate(DV~ID+TIME,pk[pk$EVID==0,],mean);xx<-pk[!duplicated(pk[c('ID','TIME','EVID')]),];xx$DV[xx$EVID==0]<-av$DV[match(paste(xx$ID[xx$EVID==0],xx$TIME[xx$EVID==0]),paste(av$ID,av$TIME))];runwith(pk0,xx,'sensitivity-replicates-averaged',ctl0)
writeLines('All planned runs attempted. Warnings remain part of interpretation.',file.path(p,'results/estimation-completed.txt'))

