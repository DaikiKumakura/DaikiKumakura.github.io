"""Paired repeat-challenge experiment; explicitly not observed clinical outcomes."""
from analyze import *
def experiment(pt,po,tt,to,seed,n=300,allometry=False):
 r=np.random.default_rng(seed);w=r.choice(pd.read_csv(R/'raw/warfarin.csv').groupby('id').wt.first().to_numpy(),n);typ=np.exp([pt['tcl'],pt['tv'],pt['tka']]);true=typ*np.exp(r.normal(size=(n,3))*np.sqrt(po));ic=np.exp(tt['tic']+r.normal(size=n)*np.sqrt(to[0]));ko=np.exp(tt['tkout']+r.normal(size=n)*np.sqrt(to[1]));times=np.arange(0,144.01,.5)
 if allometry:true*=np.column_stack(((w/70)**.75,w/70,np.ones(n)))
 def choose(pars,ci,ki):
  lo=np.full(n,60.);hi=np.full(n,153.)
  for _ in range(13):
   mid=(lo+hi)/2;nad=trajectory(times,mid,pars,ci,ki,dt=.5).min(axis=0);lo=np.where(nad>.25,mid,lo);hi=np.where(nad<=.25,mid,hi)
  return (lo+hi)/2
 fixed=choose(np.tile(typ,(n,1)),np.exp(tt['tic']),np.exp(tt['tkout']))
 info={}
 for label,timesPK in [('PK24',[24]),('PK24+48',[24,48])]:
  obs=cp(np.array(timesPK)[:,None],1.5*w,true);sd=np.sqrt(pt['add']**2+(pt['prop']*obs)**2);obs=obs+r.normal(size=obs.shape)*sd
  est=np.array([map_pk(pt,po,pd.DataFrame({'time':timesPK,'dv':obs[:,i]}),1.5*w[i],w[i],allometry)for i in range(n)]);info[label]=choose(est,np.exp(tt['tic']),np.exp(tt['tkout']))
 doses={'fixed':fixed,'weight':np.clip(fixed*w/70,60,153),**info,'oracle':choose(true,ic,ko)};rows=[]
 for name,dose in doses.items():
  nad=trajectory(times,dose,true,ic,ko,dt=.5).min(axis=0);rows.extend(dict(patient=i,strategy=name,weight=w[i],dose=dose[i],nadir=nad[i],target=bool(.2<=nad[i]<=.3),at_bound=bool(dose[i]<60.1 or dose[i]>152.9))for i in range(n))
 return pd.DataFrame(rows)
def run_scenarios():
 pt,po=load('pk-refined');tt,to=load('turn-refined');x=experiment(pt,po,tt,to,20261004);x.to_csv(O/'paired-scenarios.csv',index=False)
 summaries=[]
 def summarize(x,rep):
  for name,g in x.groupby('strategy'):summaries.append(dict(replicate=rep,strategy=name,n=len(g),nadir_median=g.nadir.median(),nadir_SD=g.nadir.std(),target_fraction=g.target.mean(),dose_bound_fraction=g.at_bound.mean()))
 summarize(x,0);b=pd.read_csv(O/'bootstrap-estimates.csv');valid=b.replicate.to_list()[::3][:20]
 for k in valid:
  p1,o1=load(f'resample-{k}-pk');t1,o2=load(f'resample-{k}-turn');summarize(experiment(p1,o1,t1,o2,20261004,n=150),k)
 pd.DataFrame(summaries).to_csv(O/'scenario-summary.csv',index=False)
 wp,wo=load('weight-refined');wtt,wto=load('weight-turn');alt=experiment(wp,wo,wtt,wto,20261004,allometry=True);alt.to_csv(O/'allometry-paired-scenarios.csv',index=False)
 structural=[]
 for model,table in [('constant',x),('allometry',alt)]:
  for name,g in table.groupby('strategy'):structural.append(dict(PK_structure=model,strategy=name,target_fraction=g.target.mean(),nadir_SD=g.nadir.std(),dose_bound_fraction=g.at_bound.mean()))
 pd.DataFrame(structural).to_csv(O/'scenario-structural-sensitivity.csv',index=False)
 # Correlation-sensitive paired differences; scenarios share individuals and true parameters.
 z=x.pivot(index='patient',columns='strategy',values='target').astype(float);rows=[]
 for name in z.columns:
  delta=z[name]-z.fixed;ss=rng.choice(delta,(2000,len(delta)),replace=True).mean(axis=1);rows.append(dict(strategy=name,target_gain=delta.mean(),low=np.quantile(ss,.025),high=np.quantile(ss,.975)))
 pd.DataFrame(rows).to_csv(O/'scenario-paired-gains.csv',index=False)
 # Numerical convergence check at paired doses, independent of target success.
 r=np.random.default_rng(713);pars=np.exp(np.array([pt['tcl'],pt['tv'],pt['tka']])+r.normal(size=(40,3))*np.sqrt(po));ci=np.exp(tt['tic']+r.normal(size=40)*np.sqrt(to[0]));ki=np.exp(tt['tkout']+r.normal(size=40)*np.sqrt(to[1]));ts=np.arange(0,144.01,.5);a=trajectory(ts,100,pars,ci,ki,dt=.5).min(axis=0);b=trajectory(ts,100,pars,ci,ki,dt=.25).min(axis=0);c=trajectory(ts,100,pars,ci,ki,dt=.125).min(axis=0)
 pd.DataFrame([dict(comparison='0.5 versus 0.25 h',max_nadir_difference=np.max(abs(a-b))),dict(comparison='0.25 versus 0.125 h',max_nadir_difference=np.max(abs(b-c)))]).to_csv(O/'scenario-grid-QA.csv',index=False)
 fig,ax=plt.subplots(1,2,figsize=(10,4));names=list(doses)if False else ['fixed','weight','PK24','PK24+48','oracle'];ax[0].boxplot([x[x.strategy==s].nadir for s in names],tick_labels=names,showfliers=False);ax[0].axhspan(.2,.3,color='#cadcc8',alpha=.5);ax[0].set(ylabel='Normalized PCA nadir',title='Simulated repeat challenge');g=pd.DataFrame(summaries);a=g[g.replicate==0].set_index('strategy').loc[names];ax[1].bar(names,a.target_fraction,color=['#52718b']*4+['#999999']);ax[1].set(ylim=(0,1),ylabel='Within assumed 20–30% target',title='Not a clinical therapeutic range');[v.tick_params(axis='x',rotation=20)for v in ax];fig.tight_layout();fig.savefig(F/'04-paired-dose-scenarios.png',dpi=180);plt.close(fig)
 print(a.to_string());print('Finite bootstrap scenario parameter sets (warning-dependent sensitivity, not CI):',len(valid))
if __name__=='__main__':run_scenarios()

