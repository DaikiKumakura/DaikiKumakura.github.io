from pathlib import Path
import json,platform,hashlib
import numpy as np,pandas as pd,scipy,matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from scipy.stats import norm,beta,chi2
from model import periodic,population,DEFAULT,OMEGA,integrated_check
ROOT=Path(__file__).resolve().parents[1]
SCHEDULES=[('200 QD',200,24),('250 QD',250,24),('300 QD',300,24),('100 BID',100,12),('150 BID',150,12)]
def power_fit(x,y,cv,n):
    X=np.column_stack([np.ones(len(x)),np.log(np.array(x)/200)])
    se=np.sqrt(np.log1p((np.array(cv)/100)**2)/np.array(n));w=1/se**2
    cov=np.linalg.inv((X.T*w)@X);b=cov@((X.T*w)@np.log(y));res=np.log(y)-X@b
    return dict(log_a=float(b[0]),b=float(b[1]),a=float(np.exp(b[0])),b_low=float(b[1]-1.96*np.sqrt(cov[1,1])),b_high=float(b[1]+1.96*np.sqrt(cov[1,1])),cov=cov.tolist(),lack_of_fit_q=float(np.sum(w*res**2)),df=len(x)-2,p_lack_of_fit=float(chi2.sf(np.sum(w*res**2),len(x)-2)))
def main():
    data=json.loads((ROOT/'analysis/inputs.json').read_text());pk=data['phase1'];fits={}
    for endpoint in ['auc','cmax']:fits[endpoint]=power_fit(pk['dose'],pk[endpoint],pk[endpoint+'_cv'],pk['n'])
    # Robustness of group-aggregate slope to weights and one-dose omission.
    fit_sensitivity=[]
    for ep in ['auc','cmax']:
        x=np.log(np.array(pk['dose'])/200);y=np.log(pk[ep]);b=np.polyfit(x,y,1)[0]
        fit_sensitivity.append(dict(endpoint=ep,analysis='unweighted',slope=b))
        for k in range(5):
            ix=[j for j in range(5) if j!=k]
            f=power_fit(np.array(pk['dose'])[ix],np.array(pk[ep])[ix],np.array(pk[ep+'_cv'])[ix],np.array(pk['n'])[ix])
            fit_sensitivity.append(dict(endpoint=ep,analysis='omit'+str(pk['dose'][k]),slope=f['b']))
    pd.DataFrame(fit_sensitivity).to_csv(ROOT/'outputs/tables/fit-sensitivity.csv',index=False)
    (ROOT/'outputs/fit.json').write_text(json.dumps(fits,indent=2)+'\n')
    pd.DataFrame(pk).to_csv(ROOT/'outputs/tables/observed-pk.csv',index=False)
    counts=[];rng=np.random.default_rng(20261019);draws={};diffs=[]
    for x in data['counts']:
        a=x['r']+.5;b=x['n']-x['r']+.5;draws[x['endpoint'],x['dose']]=rng.beta(a,b,200000)
        counts.append(dict(**x,estimate=x['r']/x['n'],posterior_mean=a/(a+b),low=beta.ppf(.025,a,b),high=beta.ppf(.975,a,b)))
    for ep in ['ORR','Grade3-4 diarrhea']:
        diff=draws[ep,300]-draws[ep,200];diffs.append(dict(endpoint=ep,mean=diff.mean(),low=np.quantile(diff,.025),high=np.quantile(diff,.975),prob_positive=(diff>0).mean()))
    pd.DataFrame(counts).to_csv(ROOT/'outputs/tables/clinical-estimates.csv',index=False);pd.DataFrame(diffs).to_csv(ROOT/'outputs/tables/clinical-differences.csv',index=False)
    results=[];paired=[];profiles={};virtual=population();raw={}
    # Linear dose scaling permits computing only one200mg curve per interval and person.
    for i,p in enumerate(virtual):
        m24,_=periodic(200,24,p);m12,_=periodic(100,12,p)
        for name,dose,tau in SCHEDULES:
            base=m24 if tau==24 else m12;scale=dose/(200 if tau==24 else 100)
            raw.setdefault(name,[]).append({k:v*scale for k,v in base.items()})
    for name,dose,tau in SCHEDULES:
        a=pd.DataFrame(raw[name]);ref=pd.DataFrame(raw['200 QD'])
        for key in ['auc24','cmax','ctrough']:
            z=a[key]/ref[key]
            results.append(dict(schedule=name,endpoint=key,p05=a[key].quantile(.05),median=a[key].median(),p95=a[key].quantile(.95)))
            paired.append(dict(schedule=name,endpoint=key,p05=z.quantile(.05),median=z.median(),p95=z.quantile(.95)))
        m,c=periodic(dose,tau);profiles[name]=c
    structural=[]
    for label,mult in [('3steps_same_ka',1.),('3steps_same_mean_absorption',1.5)]:
        ratios=[]
        for p in virtual:
            pp=dict(p,ka=p['ka']*mult)
            aa,_=periodic(200,24,pp,n_transit=3);bb,_=periodic(100,12,pp,n_transit=3)
            ratios.append([bb[k]/aa[k] for k in ['auc24','cmax','ctrough']])
        for k,key in enumerate(['auc24','cmax','ctrough']):
            z=np.array(ratios)[:,k];structural.append(dict(structure=label,endpoint=key,p05=np.quantile(z,.05),median=np.median(z),p95=np.quantile(z,.95)))
    pd.DataFrame(structural).to_csv(ROOT/'outputs/tables/structural-sensitivity.csv',index=False)
    comparison=[]
    for dose in [200,300]:
        mm,_=periodic(dose,24);j=pk['dose'].index(dose)
        comparison.append(dict(dose=dose,reference_auc=mm['auc24'],early_group_gm_auc=pk['auc'][j],ratio=mm['auc24']/pk['auc'][j]))
    pd.DataFrame(comparison).to_csv(ROOT/'outputs/tables/source-comparison.csv',index=False)
    pd.DataFrame(results).to_csv(ROOT/'outputs/tables/virtual-exposure.csv',index=False);pd.DataFrame(paired).to_csv(ROOT/'outputs/tables/paired-ratios.csv',index=False)
    sens=[]
    for key,low,high in [('cl',21.4,23.1),('vc',905,1010),('ka',1.43,1.65),('q',12.5,18.8),('vp',506,650),('fpre',.109,.145)]:
        for value in [low,high]:
            p=dict(DEFAULT,**{key:value});a,_=periodic(200,24,p);b,_=periodic(100,12,p)
            sens.append(dict(parameter=key,value=value,auc_ratio=b['auc24']/a['auc24'],cmax_ratio=b['cmax']/a['cmax'],trough_ratio=b['ctrough']/a['ctrough']))
    pd.DataFrame(sens).to_csv(ROOT/'outputs/tables/parameter-sensitivity.csv',index=False)
    _,curve=periodic(200,24);a=curve['a'];mass=200000-(a[-1].sum()-a[0].sum())
    # At periodicity all input leaves via parent elimination and presystemic bypass.
    endpoint_diff=np.max(abs(a[-1]-a[0]+np.array([200000,0,0,0])))
    coarse,_=periodic(200,24,step=.125);fine,_=periodic(200,24,step=.03125)
    extreme=np.unique(np.r_[np.argsort([p['ka'] for p in virtual])[:8],np.argsort([p['ka'] for p in virtual])[-8:],np.argsort([p['cl']/p['vc'] for p in virtual])[-8:]])
    grid_errors=[]
    for idx in extreme:
        for dose,tau in [(200,24),(100,12)]:
            aa,_=periodic(dose,tau,virtual[idx]);bb,_=periodic(dose,tau,virtual[idx],step=.03125)
            grid_errors.append(abs(aa['cmax']/bb['cmax']-1))
    qa=dict(extreme_grid_checks=len(grid_errors),extreme_cmax_grid_relative_difference=max(grid_errors),n_virtual=len(virtual),seed=20261019,omega_eigenvalues=np.linalg.eigvalsh(OMEGA).tolist(),periodic_state_error=float(endpoint_diff),auc_ode_relative_error=integrated_check(),cmax_grid_relative_difference=abs(coarse['cmax']/fine['cmax']-1),new_individual_pk_fit=False,new_individual_er_fit=False)
    assert qa['periodic_state_error']<1e-6 and qa['auc_ode_relative_error']<1e-7
    (ROOT/'outputs/verification.json').write_text(json.dumps(qa,indent=2)+'\n')
    (ROOT/'outputs/environment.json').write_text(json.dumps(dict(python=platform.python_version(),numpy=np.__version__,pandas=pd.__version__,scipy=scipy.__version__,matplotlib=matplotlib.__version__),indent=2)+'\n')
    sources={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in (ROOT/'data/raw').glob('*') if p.is_file()}
    if sources:(ROOT/'outputs/source-hashes.json').write_text(json.dumps(sources,indent=2)+'\n')
    plt.rcParams.update({'font.size':10,'axes.spines.top':False,'axes.spines.right':False})
    fig,ax=plt.subplots(1,2,figsize=(10,4))
    xx=np.linspace(50,400,150)
    for a,ep,label in zip(ax,['auc','cmax'],['AUC24 (ng h/mL)','Cmax (ng/mL)']):
        fit=fits[ep];y=np.array(pk[ep]);se=np.sqrt(np.log1p((np.array(pk[ep+'_cv'])/100)**2)/np.array(pk['n']))
        a.errorbar(pk['dose'],y,yerr=[y-y*np.exp(-1.96*se),y*np.exp(1.96*se)-y],fmt='o',color='#0072B2',label='Group GM + approximate95%CI')
        a.plot(xx,fit['a']*(xx/200)**fit['b'],color='#D55E00',label='Fitted power relationship');a.set(xlabel='Daily dose (mg)',ylabel=label);a.legend(fontsize=7,loc='upper left')
    fig.tight_layout();fig.savefig(ROOT/'outputs/figures/01-fit.png',dpi=180);plt.close(fig)
    fig,ax=plt.subplots(1,2,figsize=(10,4))
    cs=pd.DataFrame(counts)
    for a,ep in zip(ax,['ORR','Grade3-4 diarrhea']):
        g=cs[cs.endpoint==ep];a.errorbar(g.dose,g.posterior_mean*100,yerr=[(g.posterior_mean-g.low)*100,(g.high-g.posterior_mean)*100],fmt='o',capsize=4,color='#0072B2');a.set(xlabel='Daily dose (mg)',ylabel='Probability (%)',title=ep,xticks=[200,300],xlim=(150,350),ylim=(0,100 if ep=='ORR' else 40))
    fig.text(.5,.01,'ORR: randomized evaluable | Safety: all-treated 300 mg includes nonrandomized patients',ha='center',fontsize=9);fig.tight_layout(rect=(0,.05,1,1));fig.savefig(ROOT/'outputs/figures/02-clinical.png',dpi=180);plt.close(fig)
    fig,ax=plt.subplots(1,2,figsize=(10,4))
    for name,color in [('200 QD','#0072B2'),('100 BID','#009E73'),('300 QD','#D55E00')]:
        c=profiles[name];tau=c['t'][-1];ts=np.r_[c['t'],c['t'][1:]+tau] if tau==12 else c['t'];cc=np.r_[c['c'],c['c'][1:]] if tau==12 else c['c'];ax[0].plot(ts,cc,label=name.replace(' ',' mg ',1),color=color)
    ax[0].set(xlabel='Hour within repeated 24 h',ylabel='Parent concentration (ng/mL)',title='Reference patient, steady state');ax[0].legend()
    pr=pd.DataFrame(paired)
    for i,key in enumerate(['auc24','cmax','ctrough']):
        g=pr[(pr.schedule=='100 BID')&(pr.endpoint==key)].iloc[0];ax[1].errorbar(i,g['median'],yerr=[[g['median']-g.p05],[g.p95-g['median']]],fmt='o',capsize=4,color='#0072B2')
    ax[1].axhline(1,color='gray',ls=':');ax[1].set(xticks=[0,1,2],xticklabels=['AUC24','Cmax','Trough'],ylabel='100 mg BID /200 mg QD (paired)',title='4096 conditional virtual patients')
    fig.tight_layout();fig.savefig(ROOT/'outputs/figures/03-regimens.png',dpi=180);plt.close(fig)
    print(json.dumps(fits));print(pd.DataFrame(diffs).to_string(index=False));print(pr[pr.schedule=='100 BID'].to_string(index=False));print(json.dumps(qa))
if __name__=='__main__':main()
