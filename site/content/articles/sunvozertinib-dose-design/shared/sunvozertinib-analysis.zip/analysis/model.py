"""Parent marginal of public sunvozertinib joint PopPK, hour/microgram/liter."""
import numpy as np
from scipy.linalg import expm
from scipy.integrate import solve_ivp
OMEGA=np.array([[.133,.151,0],[.151,.324,0],[0,0,.357]])
DEFAULT=dict(cl=22.1,vc=954.,q=15.,vp=569.,ka=1.53,fpre=.125)
def matrix(cl=22.1,vc=954.,q=15.,vp=569.,ka=1.53,fpre=.125,n_transit=2):
    m=np.zeros((n_transit+2,n_transit+2));c=n_transit;p=c+1
    for k in range(n_transit):
        m[k,k]=-ka
        if k>0:m[k,k-1]=ka
    m[c,c-1]=(1-fpre)*ka;m[c,c]=-(cl+q)/vc;m[c,p]=q/vp
    m[p,c]=q/vc;m[p,p]=-q/vp
    return m
def periodic(dose,tau,params=None,step=.125,n_transit=2):
    p=DEFAULT if params is None else params;m=matrix(**p,n_transit=n_transit);n=int(round(tau/step));dt=tau/n
    e=expm(m*tau);d=np.zeros(n_transit+2);d[0]=dose*1000;post=np.linalg.solve(np.eye(n_transit+2)-e,d)
    states=[post];ed=expm(m*dt)
    for k in range(n):states.append(ed@states[-1])
    a=np.array(states);t=np.linspace(0,tau,n+1);c=a[:,n_transit]/p['vc']
    auc=(1-p['fpre'])*dose*1000/p['cl']
    return dict(auc24=auc*24/tau,cmax=float(c.max()),ctrough=float(c[-1]),cavg=auc/tau),dict(t=t,c=c,a=a,post=post,m=m)
def population(n=4096,seed=20261019):
    eta=np.random.default_rng(seed).multivariate_normal(np.zeros(3),OMEGA,size=n)
    return [dict(DEFAULT,cl=DEFAULT['cl']*np.exp(x[0]),vc=DEFAULT['vc']*np.exp(x[1]),ka=DEFAULT['ka']*np.exp(x[2])) for x in eta]
def integrated_check(dose=200,tau=24):
    metrics,curve=periodic(dose,tau);m=curve['m'];y0=np.r_[curve['post'],0.]
    def f(t,y):return np.r_[m@y[:4],y[2]/DEFAULT['vc']]
    sol=solve_ivp(f,(0,tau),y0,rtol=1e-10,atol=1e-8)
    return abs(sol.y[4,-1]/metrics['auc24']-1)
