import unittest
import numpy as np
from model import periodic,DEFAULT,OMEGA,matrix,integrated_check,population
class ModelChecks(unittest.TestCase):
    def test_omega(self):self.assertGreater(np.linalg.eigvalsh(OMEGA).min(),0)
    def test_periodic(self):
        _,c=periodic(200,24);np.testing.assert_allclose(c['a'][-1]+np.array([200000,0,0,0]),c['a'][0],atol=1e-7)
    def test_auc(self):self.assertLess(integrated_check(),1e-7)
    def test_equal_daily_total(self):
        a,_=periodic(200,24);b,_=periodic(100,12);self.assertAlmostEqual(a['auc24'],b['auc24'],places=8)
    def test_three_steps(self):
        a,c=periodic(200,24,n_transit=3);b,_=periodic(100,12,n_transit=3)
        np.testing.assert_allclose(c['a'][-1]+np.array([200000,0,0,0,0]),c['a'][0],atol=1e-6)
        self.assertAlmostEqual(a['auc24'],b['auc24'],places=8)
    def test_linearity(self):
        a,_=periodic(200,24);b,_=periodic(300,24)
        for key in a:self.assertAlmostEqual(b[key]/a[key],1.5,places=8)
    def test_mass_instantaneous(self):
        a=np.array([1000.,2000.,3000.,4000.]);d=matrix()@a
        self.assertAlmostEqual(d.sum(),-DEFAULT['ka']*DEFAULT['fpre']*a[1]-DEFAULT['cl']*a[2]/DEFAULT['vc'],places=8)
    def test_sampling(self):
        self.assertEqual(population(3),population(3));self.assertTrue(all(p['cl']>0 for p in population(3)))
    def test_power_recovery(self):
        from run_analysis import power_fit
        x=[50,100,200,300,400];f=power_fit(x,[12*(v/200)**1.2 for v in x],[40]*5,[10]*5)
        self.assertAlmostEqual(f['b'],1.2,places=9)
if __name__=='__main__':unittest.main()
