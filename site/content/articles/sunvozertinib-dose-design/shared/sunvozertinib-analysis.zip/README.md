# Sunvozertinib dose and schedule comparisons
Observed aggregate inputs: Wang et al.Cancer Discov2022;12:1676-1689,
DOI10.1158/2159-8290.CD-21-1615, SupplementTableS6.
Original TableS6 says preliminary, unvalidated and subject to change.
Public PK coefficients/covariance: FDA NDA219839 multidisciplinary review,
PDFpages229-230. Safety:Table62, PDFpage180,120dayupdate.
Randomized efficacy-evaluable ORR39/85 vs42/89, WU-KONG1B,
DOI10.1200/JCO-25-00788. Safety2/91 vs23/111 is mixed all-treated300mg,
not a randomized causal safety comparison. Do not substitute TRAE or other cuts.

Uses Python numeric packages only. Install requirements.txt in your environment.
Run: python analysis/run_analysis.py
Test: python -m unittest discover -s analysis -p "test_*.py" -q
No downloads/accounts required; inputs.json contains transcribed numeric facts only.
Outputs are aggregate. Original papers/figures/patient rows are not redistributed.
Source-hashes.json documents original consulted files; without raw files, rerunning
retains the saved hash snapshot and is not new source verification.

New estimation is weighted dose-exposure power fitting to group geometric means
and Jeffreys beta-binomial group rates. It is NOT a new individual NLME or E-R fit.
Lognormal CV-to-SE conversion and independent-group approximation limit fit intervals.
Public parent two-compartment PK is reconstructed from a verbal model description,
not an exact replay of original NONMEM code. Two transit steps and fraction.125
presystemic bypass are explicit choices;3step sameka/sameMAT alternatives are saved.
Active metabolite DZ0753 is not simulated. No total-active or CNS predictions.
Units: hour,microgram,liter; concentrationmicrogram/L equalsng/mL.
4096 eta draws, seed20261019, reference65.7kg cancer patient; no new body-size
or clinical-background joint distribution. Published parentCL/Vc covariance retained,
unlisted Ka covariance set0. Residual assay error not added to true exposure.
Same eta per regimen, same24h AUC. Ratios are patient variability, not confidence bounds.
Absolute predictions differ from early aggregate values; no external clinical validation.
BID extrapolates absorption, food/formulation and relativeF assumptions fromQD.
AUC equality follows the linear model; lowerCmax is not reduced diarrhea risk.
No clinical efficacy/toxicity prediction for untested regimens or dose recommendation.
Original implementation, figures and aggregate analyses; cite the sources above.
