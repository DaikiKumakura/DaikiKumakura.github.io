"""Aggregate exposure audit; no individual-level fitting or population simulation."""
from pathlib import Path
import json
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

ROOT = Path(__file__).resolve().parents[1]
RATIOS = {'parent': (3.25, 2.87, 3.68), 'M2': (0.37, 0.33, 0.41), 'M3': (3.27, 2.85, 3.74)}

def matched_exposure(parent_ratio: float, metabolite_ratio: float) -> float:
    """Normalized metabolite AUC after exact parent-AUC matching."""
    return metabolite_ratio / parent_ratio

def weighted_ratio(fraction: np.ndarray, parent: float, metabolite: float) -> np.ndarray:
    """Baseline metabolite contribution is a scenario, not a fitted potency."""
    return (1-fraction)*parent + fraction*metabolite

def run() -> dict:
    tables, figs = ROOT/'outputs/tables', ROOT/'outputs/figures'
    tables.mkdir(parents=True, exist_ok=True); figs.mkdir(parents=True, exist_ok=True)
    dose_fraction = 1/RATIOS['parent'][0]
    rows=[]
    for name,(ratio,lo,hi) in RATIOS.items():
        rows.append(dict(analyte=name, reported_auc_ratio=ratio, reported_90ci_low=lo,
                         reported_90ci_high=hi, parent_matched_ratio=ratio*dose_fraction,
                         same_dose_gmean_baseline={'parent':5553,'M2':2284,'M3':684}[name],
                         same_dose_gmean_inhibited={'parent':18020,'M2':838,'M3':2234}[name]))
    df=pd.DataFrame(rows); df.to_csv(tables/'exposure-ratios.csv',index=False)
    # Endpoints of marginal confidence intervals are not a joint confidence region.
    bounds=[RATIOS['M2'][i]/RATIOS['parent'][j] for i in (1,2) for j in (1,2)]
    fractions=np.linspace(0,1,101)
    weighted=weighted_ratio(fractions,1,matched_exposure(3.25,.37))
    pd.DataFrame({'assumed_baseline_M2_effective_exposure_fraction':fractions,
                  'parent_matched_weighted_exposure_ratio':weighted}).to_csv(tables/'weight-sensitivity.csv',index=False)
    # Parameter identity from dose/AUC = CL/F, not unique CL or F.
    decompositions=[]
    for f0 in [.1,.2,.3]:
        for f_fold in [1,2,3]:
            f1=f0*f_fold
            cl_ratio=f_fold/3.25
            decompositions.append(dict(F_baseline_assumed=f0,F_inhibited_assumed=f1,
                                       CL_inhibited_over_baseline=cl_ratio,AUC_ratio=f_fold/cl_ratio))
    pd.DataFrame(decompositions).to_csv(tables/'nonidentifiability.csv',index=False)
    plt.rcParams.update({'font.size':10,'svg.fonttype':'none'})
    fig,ax=plt.subplots(figsize=(7,4))
    x=np.arange(3); width=.34
    ax.bar(x-width/2,df.reported_auc_ratio,width,label='Observed AUCinf ratio (90% CI)',color='#0072B2',
           yerr=np.vstack([df.reported_auc_ratio-df.reported_90ci_low,df.reported_90ci_high-df.reported_auc_ratio]),capsize=4)
    ax.bar(x+width/2,df.parent_matched_ratio,width,label='Calculated after parent matching',color='#E69F00')
    ax.axhline(1,color='black',lw=1); ax.set_xticks(x,df.analyte)
    ax.set_ylabel('AUCinf relative to baseline (dimensionless)')
    ax.set_title('Savolitinib + fluvoxamine: aggregate n = 16')
    ax.legend(fontsize=8); fig.tight_layout()
    for ext in ['png','svg']: fig.savefig(figs/f'exposure-matching.{ext}',dpi=180)
    plt.close(fig)
    fig,ax=plt.subplots(figsize=(7,4)); ax.plot(fractions,weighted,color='#0072B2')
    ax.axhline(1,color='black',lw=1); ax.set_ylim(0,1.05)
    ax.set_xlabel('Assumed baseline contribution of M2 (not estimated)')
    ax.set_ylabel('Normalized parent + M2 exposure index')
    ax.set_title('Weight sensitivity after exact parent-AUC matching')
    fig.tight_layout()
    for ext in ['png','svg']: fig.savefig(figs/f'weight-sensitivity.{ext}',dpi=180)
    plt.close(fig)
    results={'dose_fraction_parent_match':dose_fraction,'arithmetic_single_dose_mg':300*dose_fraction,
             'M2_parent_matched_ratio':matched_exposure(3.25,.37),
             'M3_parent_matched_ratio':matched_exposure(3.25,3.27),
             'M2_ci_corner_sensitivity_not_confidence_interval':[min(bounds),max(bounds)],
             'weighted_ratio_if_M2_baseline_fraction_0_1':float(weighted_ratio(np.array(.1),1,.37/3.25)),
             'weighted_ratio_if_M2_baseline_fraction_0_25':float(weighted_ratio(np.array(.25),1,.37/3.25)),
             'half_life_ratio_parent':8/8.9,'apparent_clearance_ratio':16.6/54,
             'apparent_volume_ratio':191.6/693.1,'n':16}
    (ROOT/'outputs/results.json').write_text(json.dumps(results,indent=2)+'\n',encoding='utf-8')
    return results

if __name__=='__main__': print(json.dumps(run(),indent=2))
