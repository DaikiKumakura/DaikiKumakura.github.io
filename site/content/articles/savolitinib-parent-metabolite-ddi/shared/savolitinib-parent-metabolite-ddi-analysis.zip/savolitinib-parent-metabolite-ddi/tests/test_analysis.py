import importlib.util
from pathlib import Path
import unittest
import numpy as np
spec=importlib.util.spec_from_file_location('analysis',Path(__file__).resolve().parents[1]/'analysis/run.py')
m=importlib.util.module_from_spec(spec); spec.loader.exec_module(m)

class ExposureTests(unittest.TestCase):
    def test_matching_invariant(self):
        self.assertAlmostEqual(m.matched_exposure(3.25,3.25),1)
        self.assertAlmostEqual(m.matched_exposure(3.25,.37),.11384615384615385)
    def test_weight_endpoints(self):
        np.testing.assert_allclose(m.weighted_ratio(np.array([0,1]),1,.2),[1,.2])
    def test_no_common_dose_can_match_both(self):
        self.assertNotAlmostEqual(1/3.25,1/.37)
        self.assertLess(.41/2.87,1)
    def test_F_CL_nonidentifiability(self):
        for fold in (1,2,3): self.assertAlmostEqual(fold/(fold/3.25),3.25)

if __name__=='__main__': unittest.main()
