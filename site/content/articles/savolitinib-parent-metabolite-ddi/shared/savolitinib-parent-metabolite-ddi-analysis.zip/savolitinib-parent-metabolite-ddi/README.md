# Savolitinib parent–metabolite exposure matching

An aggregate-data calculation using the observed savolitinib–fluvoxamine AUC ratios from DOI 10.1002/prp2.70321, Table 2. No individual-level fit, virtual population or clinical dosing recommendation is made.

Run with existing Python 3.12 dependencies listed in requirements.txt:

```
python analysis/run.py
python -m unittest discover -s tests -v
```

Outputs are deterministic and regenerate without downloading the article. The original XML is retained privately for provenance, excluded from the public archive. CC BY-NC-ND source figures and text are not redistributed. The public package contains original code and newly calculated aggregate results and figures. Marginal-CI endpoint combinations are sensitivity bounds, not joint confidence intervals. Assumed effective M2 weights are not measured potency or patient probabilities.
