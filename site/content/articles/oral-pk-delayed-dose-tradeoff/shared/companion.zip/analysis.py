from math import exp, log

k = log(2)/8
ka = 1
factor = ka/(ka-k)

def dose(t):
    return factor*(exp(-k*t)-exp(-ka*t)) if t >= 0 else 0

def baseline(t):
    phase = t % 12
    return factor*(exp(-k*phase)/(1-exp(-12*k))-exp(-ka*phase)/(1-exp(-12*ka)))

for name, removed, added in [
    ("planned", (), ()), ("skip", (0,), ()), ("delay_keep", (0,), (9,)),
    ("delay_shift", (0,12,24), (9,21)),
]:
    values = [baseline(t/1000)-sum(dose(t/1000-d) for d in removed)
              +sum(dose(t/1000-d) for d in added) for t in range(24001)]
    print(f"{name} min={min(values[:12000]):.6f} max={max(values[12000:]):.6f}")
