from math import exp, log

INTERVAL = 24
TMAX = 2.2
STEP = 0.01

def steady(t, k, ka):
    phase = t % INTERVAL
    return ka/(ka-k)*(exp(-k*phase)/(1-exp(-k*INTERVAL))
                      -exp(-ka*phase)/(1-exp(-ka*INTERVAL)))

def steady_tmax(k, ka):
    return log(ka*(1-exp(-k*INTERVAL))/(k*(1-exp(-ka*INTERVAL))))/(ka-k)

def absorption_rate(k):
    low, high = 2*k, 10.0
    assert steady_tmax(k, low) > TMAX > steady_tmax(k, high)
    for _ in range(70):
        middle = (low+high)/2
        if steady_tmax(k, middle) > TMAX:
            low = middle
        else:
            high = middle
    return (low+high)/2

def single(t, k, ka):
    return ka/(ka-k)*(exp(-k*t)-exp(-ka*t)) if t >= 0 else 0.0

for half_life in (6.5, 9.2, 11.9):
    k = log(2)/half_life
    ka = absorption_rate(k)
    planned_peak = steady(TMAX,k,ka)
    planned_trough = steady(0,k,ka)
    print(f"half-life {half_life} h, ka={ka:.4f}, peak/AUC0-24={planned_peak*k:.5f}")
    for scenario, delay in [('on time',0),('4 h',4),('8 h counterfactual',8),('omission',None)]:
        values = [steady(t*STEP,k,ka)-single(t*STEP,k,ka)
                  +(single(t*STEP-delay,k,ka) if delay is not None else 0.0)
                  for t in range(4801)]
        print(f"{scenario}: early minimum={min(values[:2401])/planned_trough:.4f}; "
              f"next-day maximum={max(values[2400:])/planned_peak:.4f}")
