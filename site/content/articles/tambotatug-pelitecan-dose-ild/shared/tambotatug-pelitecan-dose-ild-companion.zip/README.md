# Companion materials: tambotatug pelitecan 2.0 vs 2.4 mg/kg

Scripts, inputs, tables, figures and logs for the article "Is escalation of tambotatug pelitecan to 2.4 mg/kg necessary?".

- `inputs/`: counts and summary values transcribed from Ma et al., Nat Med 2025;31(6):1949-1957 (doi:10.1038/s41591-025-03600-2) and its Supplementary Information (Tables 4, 5, 7), and from the ESMO 2026 e-poster on ILD (Fu et al.). See `inputs/PROVENANCE.md`; the "Other" stratum is derived by subtraction.
- Run (Python 3.12, numpy, pandas, scipy, matplotlib; seed 20261107): `python analysis/01_pk_exposure.py && python analysis/02_efficacy_safety.py && python analysis/03_ild.py && python analysis/04_figures.py`.

Exploratory, summary-level analysis of non-randomized dose cohorts; the results are not causal effects of the dose increase. The ILD follow-up analysis is a sensitivity analysis under assumed onset-time distributions, not an estimate.

Added in the reviewed version: `outputs/tables/std_weight_sensitivity.csv` (standardized difference under the pooled, 2.0 mg/kg and 2.4 mg/kg tumor mixes). The crude Grade >= 3 TRAE difference appears as 12.6 (`orr_tox_crude_vs_standardised.csv`) and 12.5 (`ae_comparison.csv`) because of independent Monte Carlo draws.
