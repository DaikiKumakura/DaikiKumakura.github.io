# Input provenance

Sources (all read on 2026-11-07):
- Ma Y, et al. A B7H3-targeting antibody-drug conjugate in advanced solid tumors: a phase 1/1b trial. Nat Med 2025;31(6):1949-1957, doi:10.1038/s41591-025-03600-2 (open access, PMC12176648): main text, Table 2 (TRAEs by dose), Extended Data Table 1 (efficacy by dose; an image, values read from it), text on dose groups.
- Supplementary Information of the same article (PDF, 3.2 MB, text layer): Supplementary Table 4 (PopPK estimates), Table 5 (cycle 1 PK, dose escalation), Table 7 (safety and efficacy by dose in SCLC, NPC and all patients).
- Fu S, et al. Tambotatug pelitecan (YL201): Analyses of interstitial lung disease in patients with advanced solid tumors from phase 1/2 studies. ESMO 2026 e-poster (23 Oct 2026), Roche Medically page; data cutoff 2026-03-16 (the page text layer of the e-poster): Tables 1-4 and text.

Files:
- `pk_cycle1_tableS5.csv`: Supplementary Table 5 (geometric mean and geometric CV%), transcribed from the text layer (raw extraction order), n per dose group as printed.
- `strata_s7.csv`: Supplementary Table 7 counts (SCLC, NPC, all patients); the "Other" stratum is derived by subtraction (all - SCLC - NPC) and labeled as derived.
- `ae_table2.csv`: Nat Med Table 2 (Grade >= 3 hematologic TRAEs, discontinuation, etc., by dose).
- `ild_pooled_esmo2026.csv`: ESMO 2026 poster Tables 1-4 (ILD events by dose and grade, follow-up, onset times, mCRPC count).
Notes: the pooled ILD analysis (723 patients; INT-101-01 177 + CN-101-01 464 + CN-201-01 82, per the poster) and the Nat Med trial (312 patients) are not independent; the exact overlap per study was not verified (the Nat Med supplement says its exposure-response analysis used INT-101-01 and CN-101-01 dose-escalation data), so the overlap is stated only as 'overlapping'. The poster is sponsor-funded (Roche, MediLink Therapeutics). Nat Med supplementary Figure 7 (exposure-response) is an image and was not used.

Values read from the supplement and recorded here (not in a CSV, or used only in the text):
- Supplementary Table 4 (PopPK): ADC nonlinear elimination Vmax 2.31 nmol/h, Km 5.1 nM. Supplementary Methods and Results: the nonlinear term was added "to define the target saturation above 2 mg/kg"; no statement on linearity ranges was used.
- Supplementary Table 7: mPFS (95% CI) in all patients, 7.6 (6.0-7.8) months at 2.0 mg/kg and 5.6 (4.9-7.2) months at 2.4 mg/kg; median follow-up of the efficacy population 6.5 (6.2-7.6) and 7.4 (6.4-8.6) months; confirmed CR+PR 42/87 and 69/184 (cross-checks the ORR counts).
- Supplementary Table 1 (dose-expansion baseline): 86 patients at 2.0 mg/kg and 177 at 2.4 mg/kg (263 in total), whereas Supplementary Table 7 safety uses 96 and 195. The differences (10 and 18) are plausibly dose-escalation patients treated at those doses, but the tables do not say so; this is an inference, not a verified fact.
- Supplementary Figure 7 (exposure-response logistic regressions, dose-escalation data) is an image; its direction of effect was not read and no statement about it is made in the article.
- Poster values with no CSV locator: see the notes column of `ild_pooled_esmo2026.csv`.
- Rounding: the crude Grade >= 3 TRAE difference is 12.6 in `orr_tox_crude_vs_standardised.csv` and 12.5 in `ae_comparison.csv` (independent Monte Carlo draws); the article uses 12.6.

