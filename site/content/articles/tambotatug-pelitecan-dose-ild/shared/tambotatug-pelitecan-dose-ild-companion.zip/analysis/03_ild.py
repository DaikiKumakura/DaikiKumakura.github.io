"""ILD/pneumonitis at 2.0 vs 2.4 mg/kg: crude comparison, follow-up scenarios, and an allocation sensitivity for mCRPC.

Input : inputs/ild_pooled_esmo2026.csv (ESMO 2026 e-poster; pooled phase 1/2, data cutoff 2026-03-16)
Facts used: ILD 11/324 (2.0) and 11/335 (2.4); median follow-up 9.2 and 16.8 months; median onset of all-grade ILD 94.5 d (range 17-549, n = 22) and of grade 3
            ILD 67 d (range 21-144, n = 9); mCRPC n = 99 with 0 ILD events (dose split NOT reported); individual event/censoring times NOT reported.
(a) Crude: Beta(0.5, 0.5) posteriors, risk difference and ratio (200,000 draws, seed 20261107), Newcombe interval, Fisher exact test.
(b) Follow-up scenarios. Onset time ~ lognormal with median 94.5 d and sigma in {0.8, 1.0, 1.3} (sigma 1.0 is consistent with the reported range 17-549 for n = 22
    if the extremes sit near the 4th and 96th percentiles). Follow-up per patient is (i) fixed at the arm's median follow-up, (ii) exponential with that median,
    (iii) uniform on [0, 2 x median]. F_eff = mean over patients of P(onset <= follow-up). The scenario-adjusted lifetime risk is observed risk / F_eff and the
    ratio 2.4/2.0 compares them. This ignores treatment discontinuation and risk windows; it is a sensitivity analysis, not an estimate.
(c) mCRPC: if m4 of the 99 mCRPC patients (0 ILD) received 2.4 mg/kg and 99 - m4 received 2.0 mg/kg, ILD risk among the other patients is 11/(324 - (99 - m4)) and
    11/(335 - m4).
Output: outputs/tables/ild_crude.csv, ild_followup_scenarios.csv, ild_mcrpc_allocation.csv
Run   : python -X utf8 analysis/03_ild.py
"""
import sys
from pathlib import Path

import numpy as np
import pandas as pd
from scipy import stats

sys.stdout.reconfigure(encoding="utf-8")
SEED, N = 20261107, 200000
ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "outputs/tables"
rng = np.random.default_rng(SEED)
x20, n20, x24, n24 = 11, 324, 11, 335
FU20, FU24 = 9.2 * 30.4375, 16.8 * 30.4375  # days
MED_ONSET = 94.5


def wilson(x, n, z=1.959964):
    p = x / n
    c = (p + z * z / (2 * n)) / (1 + z * z / n)
    h = z * np.sqrt(p * (1 - p) / n + z * z / (4 * n * n)) / (1 + z * z / n)
    return c - h, c + h


# (a) crude
p20 = rng.beta(0.5 + x20, 0.5 + n20 - x20, N)
p24 = rng.beta(0.5 + x24, 0.5 + n24 - x24, N)
d, r = p24 - p20, p24 / p20
l1, u1 = wilson(x20, n20)
l2, u2 = wilson(x24, n24)
p1, p2 = x20 / n20, x24 / n24
nc = ((p2 - p1) - np.sqrt((p2 - l2) ** 2 + (u1 - p1) ** 2), (p2 - p1) + np.sqrt((u2 - p2) ** 2 + (p1 - l1) ** 2))
crude = pd.DataFrame([dict(p20_median=np.median(p20), p20_lo=np.percentile(p20, 2.5), p20_hi=np.percentile(p20, 97.5), p24_median=np.median(p24), p24_lo=np.percentile(p24, 2.5), p24_hi=np.percentile(p24, 97.5),
                           rd_median=np.median(d), rd_lo=np.percentile(d, 2.5), rd_hi=np.percentile(d, 97.5), ratio_median=np.median(r), ratio_lo=np.percentile(r, 2.5), ratio_hi=np.percentile(r, 97.5),
                           p_rd_gt0=float((d > 0).mean()), p_ratio_gt_1_5=float((r > 1.5).mean()), newcombe_lo=nc[0], newcombe_hi=nc[1], fisher_p=stats.fisher_exact([[x24, n24 - x24], [x20, n20 - x20]])[1])])
crude.to_csv(OUT / "ild_crude.csv", index=False)
print("== (a) crude ILD, 2.0 vs 2.4 mg/kg")
print(crude.round(4).T.to_string(header=False))

# (b) follow-up scenarios
z = np.linspace(0, 1, 4001)[1:-1]


def f_eff(median_fu, sigma, mode):
    mu = np.log(MED_ONSET)
    cdf = lambda t: stats.norm.cdf((np.log(t) - mu) / sigma)
    if mode == "fixed":
        return float(cdf(median_fu))
    if mode == "exponential":  # follow-up quantiles of an exponential with the given median
        t = -np.log(1 - z) * median_fu / np.log(2)
        return float(cdf(t).mean())
    t = z * 2 * median_fu  # uniform on [0, 2 median]
    return float(cdf(t).mean())


rows = []
for sigma in (0.8, 1.0, 1.3):
    for mode in ("fixed", "exponential", "uniform"):
        f20, f24 = f_eff(FU20, sigma, mode), f_eff(FU24, sigma, mode)
        s20 = p20 / f20
        s24 = p24 / f24
        rr = s24 / s20
        rows.append(dict(sigma=sigma, followup_model=mode, F_eff_20=f20, F_eff_24=f24, F_ratio_24_over_20=f24 / f20, lifetime_risk_20=np.median(s20), lifetime_risk_24=np.median(s24),
                         ratio_median=np.median(rr), ratio_lo=np.percentile(rr, 2.5), ratio_hi=np.percentile(rr, 97.5)))
sc = pd.DataFrame(rows)
sc.to_csv(OUT / "ild_followup_scenarios.csv", index=False)
print("\n== (b) follow-up scenarios: adjusted lifetime-risk ratio 2.4/2.0")
print(sc.round(3).to_string(index=False))
print(f"fraction of onsets later than 9.2 months (sigma 1.0): {1 - stats.norm.cdf((np.log(FU20) - np.log(MED_ONSET)) / 1.0):.3f}; later than 16.8 months: {1 - stats.norm.cdf((np.log(FU24) - np.log(MED_ONSET)) / 1.0):.3f}")

# (c) mCRPC allocation
rows = []
for m4 in range(0, 100, 11):
    m20 = 99 - m4
    a20, a24 = x20 / (n20 - m20), x24 / (n24 - m4)
    rows.append(dict(mcrpc_at_24=m4, mcrpc_at_20=m20, risk_other_20=a20, risk_other_24=a24, ratio_24_over_20=a24 / a20))
rows.append(dict(mcrpc_at_24=99, mcrpc_at_20=0, risk_other_20=x20 / n20, risk_other_24=x24 / (n24 - 99), ratio_24_over_20=(x24 / (n24 - 99)) / (x20 / n20)))
al = pd.DataFrame(rows).drop_duplicates("mcrpc_at_24")
al.to_csv(OUT / "ild_mcrpc_allocation.csv", index=False)
print("\n== (c) ILD risk outside mCRPC under different (unreported) allocations of the 99 mCRPC patients")
print(al.round(3).to_string(index=False))
