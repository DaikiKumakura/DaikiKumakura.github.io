"""Figures (English text). Requires outputs/tables from scripts 01-03. Run: python -X utf8 analysis/04_figures.py"""
import sys
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from scipy import stats

sys.stdout.reconfigure(encoding="utf-8")
ROOT = Path(__file__).resolve().parents[1]
T, F = ROOT / "outputs/tables", ROOT / "outputs/figures"
C20, C24 = "#0072B2", "#E69F00"
plt.rcParams.update({"font.size": 9.5, "axes.spines.top": False, "axes.spines.right": False, "figure.dpi": 150})

# Fig 1: exposure
d = pd.read_csv(ROOT / "inputs/pk_cycle1_tableS5.csv")
s = lambda cv: np.sqrt(np.log(1 + (cv / 100) ** 2))
fig, axes = plt.subplots(1, 3, figsize=(10.5, 3.5))
for ax, (an, gm, cv, ttl, unit) in zip(axes, [("YL201-ADC", "cmax_gm", "cmax_gcv_pct", "ADC Cmax", "µg/mL"), ("YL201-ADC", "auc21d_gm", "auc21d_gcv_pct", "ADC AUC0–21d", "µg·h/mL"), ("YL0010014 (free payload)", "auc21d_gm", "auc21d_gcv_pct", "Free payload YL0010014 AUC0–21d", "ng·h/mL")]):
    g = d[d.analyte == an].sort_values("dose_mgkg")
    lo = g[gm] * np.exp(-1.96 * s(g[cv]) / np.sqrt(g.n))
    hi = g[gm] * np.exp(1.96 * s(g[cv]) / np.sqrt(g.n))
    cols = [C20 if x == 2.0 else C24 if x == 2.4 else "#555" for x in g.dose_mgkg]
    ax.errorbar(g.dose_mgkg, g[gm], yerr=[g[gm] - lo, hi - g[gm]], fmt="none", ecolor="#888", capsize=3)
    ax.scatter(g.dose_mgkg, g[gm], c=cols, s=45, zorder=3)
    for x, y, n in zip(g.dose_mgkg, g[gm], g.n):
        ax.annotate(f"n={n}", (x, y), textcoords="offset points", xytext=(0, 8), ha="center", fontsize=7)
    ax.set_title(ttl, fontsize=9)
    ax.set_xlabel("Dose (mg/kg)")
    ax.set_ylabel(f"Geometric mean ({unit})")
    ax.set_ylim(0, None)
fig.suptitle("Cycle 1 exposure, dose-escalation patients (geometric mean, 95% interval from the geometric CV; blue = 2.0, orange = 2.4 mg/kg)", fontsize=8.5)
fig.tight_layout()
fig.savefig(F / "fig1_exposure.png")
plt.close(fig)

# Fig 2 and 3: crude vs standardized, by stratum
sp = pd.read_csv(T / "strata_posterior.csv")
cs = pd.read_csv(T / "orr_tox_crude_vs_standardised.csv")


def forest(ax, ep, title):
    g = sp[sp.endpoint == ep]
    rows = [(f"{r.stratum} ({r.x20}/{r.n20} vs {r.x24}/{r.n24})", r.rd_median, r.rd_lo, r.rd_hi, "#888") for r in g.itertuples()]
    c = cs[cs.endpoint == ep].iloc[0]
    rows.append((f"Crude, arm totals ({c.crude_20} vs {c.crude_24})", c.crude_rd_median, c.crude_lo, c.crude_hi, C24))
    rows.append(("Standardized to the pooled tumor mix", c.std_rd_median, c.std_lo, c.std_hi, C20))
    for i, (lab, m, lo, hi, col) in enumerate(rows[::-1]):
        ax.hlines(i, lo * 100, hi * 100, color=col, lw=2)
        ax.scatter(m * 100, i, color=col, zorder=3)
    ax.axvline(0, color="#444", lw=0.8)
    ax.set_yticks(range(len(rows)))
    ax.set_yticklabels([r[0] for r in rows[::-1]], fontsize=8)
    ax.set_xlabel("2.4 − 2.0 mg/kg, percentage points (posterior median, 95% credible interval)")
    ax.set_title(title, fontsize=9)


fig, ax = plt.subplots(figsize=(7.4, 3.6))
forest(ax, "ORR confirmed", "Confirmed ORR: crude versus tumor-type-standardized difference")
fig.tight_layout()
fig.savefig(F / "fig2_orr_strata.png")
plt.close(fig)
fig, ax = plt.subplots(figsize=(7.4, 3.6))
forest(ax, "Grade>=3 TRAE", "Grade ≥3 TRAE: positive in every stratum, each interval includes 0")
fig.tight_layout()
fig.savefig(F / "fig3_g3_trae_strata.png")
plt.close(fig)

# Fig 4: ILD posteriors and grades
fig, axes = plt.subplots(1, 2, figsize=(9.2, 3.4))
grid = np.linspace(0, 0.12, 600)
for dose, x, n, col in ((2.0, 11, 324, C20), (2.4, 11, 335, C24)):
    dens = stats.beta.pdf(grid, 0.5 + x, 0.5 + n - x)
    axes[0].plot(grid * 100, dens, color=col, lw=2, label=f"{dose} mg/kg: {x}/{n}")
    axes[0].fill_between(grid * 100, dens, color=col, alpha=0.12)
axes[0].set_xlabel("ILD/pneumonitis probability per patient (%)")
axes[0].set_yticks([])
axes[0].set_ylabel("Posterior density")
axes[0].legend(frameon=False, fontsize=8)
axes[0].set_title("Beta-binomial posterior (Jeffreys prior)", fontsize=9)
gr = {"2.0 mg/kg": (3, 4, 4), "2.4 mg/kg": (2, 4, 5)}
bottom = np.zeros(2)
for k, (lab, col) in enumerate((("Grade 1", "#56B4E9"), ("Grade 2", C24), ("Grade 3", "#D55E00"))):
    vals = np.array([gr["2.0 mg/kg"][k], gr["2.4 mg/kg"][k]])
    axes[1].bar(["2.0 mg/kg\n(n=324)", "2.4 mg/kg\n(n=335)"], vals, bottom=bottom, color=col, label=lab)
    bottom += vals
axes[1].set_ylabel("Patients with ILD/pneumonitis")
axes[1].set_title("By grade (no grade 4 or 5)", fontsize=9)
axes[1].legend(frameon=False, fontsize=8)
fig.tight_layout()
fig.savefig(F / "fig4_ild.png")
plt.close(fig)

# Fig 5: follow-up scenarios and mCRPC allocation
sc = pd.read_csv(T / "ild_followup_scenarios.csv")
al = pd.read_csv(T / "ild_mcrpc_allocation.csv")
fig, axes = plt.subplots(1, 2, figsize=(10.2, 3.8))
ax = axes[0]
sc["lab"] = "σ=" + sc.sigma.astype(str) + ", " + sc.followup_model
y = np.arange(len(sc))[::-1]
ax.hlines(y, sc.ratio_lo, sc.ratio_hi, color="#888")
ax.scatter(sc.ratio_median, y, color=C24, zorder=3)
ax.axvline(1, color="#444", lw=0.8)
ax.set_yticks(y)
ax.set_yticklabels(sc.lab, fontsize=7.5)
ax.set_xscale("log")
ax.set_xticks([0.4, 0.7, 1, 1.5, 2])
ax.get_xaxis().set_major_formatter(matplotlib.ticker.ScalarFormatter())
ax.get_xaxis().set_minor_formatter(matplotlib.ticker.NullFormatter())
ax.set_xlabel("Follow-up-adjusted lifetime ILD risk, 2.4 / 2.0 mg/kg")
ax.set_title("Follow-up scenarios (onset time lognormal; median 94.5 d)", fontsize=9)
ax = axes[1]
ax.plot(al.mcrpc_at_24, al.ratio_24_over_20, color=C20, lw=2, marker="o", ms=3)
ax.axhline(1, color="#444", lw=0.8)
ax.set_xlabel("mCRPC patients (of 99; 0 ILD) assumed to be at 2.4 mg/kg")
ax.set_ylabel("ILD risk ratio 2.4 / 2.0 among other patients")
ax.set_title("Unreported allocation of mCRPC patients", fontsize=9)
fig.tight_layout()
fig.savefig(F / "fig5_ild_sensitivity.png")
plt.close(fig)

# Fig 6: benefit and harms side by side (not combined)
ae = pd.read_csv(T / "ae_comparison.csv").set_index("endpoint")
ild = pd.read_csv(T / "ild_crude.csv").iloc[0]
rows = [("Confirmed ORR, standardized (benefit)", cs[cs.endpoint == "ORR confirmed"].iloc[0][["std_rd_median", "std_lo", "std_hi"]].values.astype(float), C20),
        ("Grade ≥3 TRAE, standardized", cs[cs.endpoint == "Grade>=3 TRAE"].iloc[0][["std_rd_median", "std_lo", "std_hi"]].values.astype(float), C24),
        ("Grade ≥3 neutropenia, crude", ae.loc["Grade>=3 neutropenia", ["rd_median", "rd_lo", "rd_hi"]].values.astype(float), C24),
        ("Grade ≥3 anemia, crude", ae.loc["Grade>=3 anemia", ["rd_median", "rd_lo", "rd_hi"]].values.astype(float), C24),
        ("TRAE with death, crude", ae.loc["TRAE with death", ["rd_median", "rd_lo", "rd_hi"]].values.astype(float), C24),
        ("TRAE led to discontinuation, crude", ae.loc["TRAE led to discontinuation", ["rd_median", "rd_lo", "rd_hi"]].values.astype(float), C24),
        ("ILD/pneumonitis, crude (pooled data)", np.array([ild.rd_median, ild.rd_lo, ild.rd_hi]), "#009E73")]
fig, ax = plt.subplots(figsize=(7.8, 3.8))
for i, (lab, v, col) in enumerate(rows[::-1]):
    ax.hlines(i, v[1] * 100, v[2] * 100, color=col, lw=2)
    ax.scatter(v[0] * 100, i, color=col, zorder=3)
ax.axvline(0, color="#444", lw=0.8)
ax.set_yticks(range(len(rows)))
ax.set_yticklabels([r[0] for r in rows[::-1]], fontsize=8)
ax.set_xlabel("2.4 − 2.0 mg/kg, percentage points (posterior median, 95% credible interval)")
ax.set_title("Benefit and harms side by side (not combined; different data sets)", fontsize=9)
fig.tight_layout()
fig.savefig(F / "fig6_benefit_harm.png")
plt.close(fig)
print("figures written")
