"""Exposure ratios 2.4 vs 2.0 mg/kg and dose-proportionality from Supplementary Table 5 (cycle 1, dose escalation, geometric mean and geometric CV%).

Model: ln(GM_hat) ~ Normal(ln GM, s^2/n) with s = sqrt(ln(1 + CV^2)) from the published geometric CV (lognormal assumption).
Ratio 2.4/2.0 : parametric bootstrap on the log scale (200,000 draws, seed 20261107), percentile 95% interval; compared with the dose ratio 1.2.
Slope (ADC, 1.6-2.8 mg/kg): weighted regression of ln(GM) on ln(dose), weights n/s^2 (delta method), t interval, df = 2. Slope 1 = dose proportional.
Output: outputs/tables/pk_ratio_24_vs_20.csv, pk_power_slope.csv
Run   : python -X utf8 analysis/01_pk_exposure.py
Summary-level; dose-escalation patients (9 at 2.0 and 16 at 2.4 mg/kg), not the expansion cohorts. Not a PopPK fit.
P(ratio > 1.2) is the share of bootstrap draws above 1.2 (variance treated as known), not a posterior probability.
"""
import sys
from pathlib import Path

import numpy as np
import pandas as pd
from scipy import stats

sys.stdout.reconfigure(encoding="utf-8")
SEED = 20261107
ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "outputs/tables"
d = pd.read_csv(ROOT / "inputs/pk_cycle1_tableS5.csv")
rng = np.random.default_rng(SEED)
s = lambda cv: np.sqrt(np.log(1 + (cv / 100) ** 2))
rows = []
for an, g in d.groupby("analyte", sort=False):
    g = g.set_index("dose_mgkg")
    for par, gm, cv in (("Cmax", "cmax_gm", "cmax_gcv_pct"), ("AUC0-21d", "auc21d_gm", "auc21d_gcv_pct")):
        if 2.0 in g.index and 2.4 in g.index:
            l20 = rng.normal(np.log(g.loc[2.0, gm]), s(g.loc[2.0, cv]) / np.sqrt(g.loc[2.0, "n"]), 200000)
            l24 = rng.normal(np.log(g.loc[2.4, gm]), s(g.loc[2.4, cv]) / np.sqrt(g.loc[2.4, "n"]), 200000)
            r = np.exp(l24 - l20)
            rows.append(dict(analyte=an, parameter=par, gm_20=g.loc[2.0, gm], n_20=int(g.loc[2.0, "n"]), gm_24=g.loc[2.4, gm], n_24=int(g.loc[2.4, "n"]),
                             ratio=g.loc[2.4, gm] / g.loc[2.0, gm], lo=np.percentile(r, 2.5), hi=np.percentile(r, 97.5), dose_ratio=1.2,
                             p_ratio_gt_1_2=float((r > 1.2).mean())))
ratio = pd.DataFrame(rows)
ratio.to_csv(OUT / "pk_ratio_24_vs_20.csv", index=False)
print("== exposure ratio 2.4 / 2.0 mg/kg (dose ratio 1.2)")
print(ratio.round(3).to_string(index=False))

rows = []
for an, g in d.groupby("analyte", sort=False):
    for par, gm, cv in (("Cmax", "cmax_gm", "cmax_gcv_pct"), ("AUC0-21d", "auc21d_gm", "auc21d_gcv_pct")):
        h = g.dropna(subset=[gm, cv])
        if len(h) < 4:
            continue
        x, y = np.log(h.dose_mgkg.values), np.log(h[gm].values)
        w = h.n.values / s(h[cv].values) ** 2
        X = np.c_[np.ones_like(x), x]
        W = np.diag(w)
        cov = np.linalg.inv(X.T @ W @ X)
        beta = cov @ X.T @ W @ y
        resid = y - X @ beta
        dfree = len(x) - 2
        s2 = float((w * resid ** 2).sum() / dfree)
        se = np.sqrt(np.diag(cov) * max(s2, 1.0))
        t = stats.t.ppf(0.975, dfree)
        rows.append(dict(analyte=an, parameter=par, doses=",".join(map(str, h.dose_mgkg)), slope=beta[1], lo=beta[1] - t * se[1], hi=beta[1] + t * se[1], df=dfree, includes_1=bool(beta[1] - t * se[1] <= 1 <= beta[1] + t * se[1])))
slope = pd.DataFrame(rows)
slope.to_csv(OUT / "pk_power_slope.csv", index=False)
print("\n== power-model slope over the available dose levels (1 = dose proportional)")
print(slope.round(3).to_string(index=False))
