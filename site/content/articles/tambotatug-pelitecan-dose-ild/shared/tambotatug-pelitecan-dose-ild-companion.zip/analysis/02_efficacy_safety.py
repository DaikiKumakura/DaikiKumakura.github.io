"""Crude vs tumour-type-standardised comparison of 2.4 vs 2.0 mg/kg: confirmed ORR and Grade >=3 TRAE, plus Grade >=3 haematological and other TRAEs.

Input : inputs/strata_s7.csv (SCLC, NPC from Supplementary Table 7; 'Other' derived by subtraction), inputs/ae_table2.csv (Nat Med Table 2)
Model : events ~ Binomial(n, p), p ~ Beta(0.5, 0.5) per arm and stratum (independent; no borrowing). 200,000 draws, seed 20261107.
        Crude RD = difference of arm totals (ignores tumour mix). Standardised RD = sum_s w_s (p24_s - p20_s), w_s = (n20_s + n24_s) / total.
        Mantel-Haenszel OR (Robins-Breslow-Greenland variance) for the same strata. Newcombe interval and Fisher test for crude arm comparisons.
Output: outputs/tables/strata_posterior.csv, orr_tox_crude_vs_standardised.csv, std_weight_sensitivity.csv, ae_comparison.csv
Note  : the crude Grade>=3 TRAE difference appears in both orr_tox_crude_vs_standardised.csv (12.6) and ae_comparison.csv (12.5) with independent Monte Carlo draws.
Run   : python -X utf8 analysis/02_efficacy_safety.py
Non-randomised dose cohorts; strata are tumour types only (no other adjustment). 'Other' mixes many tumour types.
"""
import sys
from pathlib import Path

import numpy as np
import pandas as pd
from scipy import stats

sys.stdout.reconfigure(encoding="utf-8")
SEED, N = 20261107, 200000
ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "outputs/tables"
rng = np.random.default_rng(SEED)
st = pd.read_csv(ROOT / "inputs/strata_s7.csv")


def wilson(x, n, z=1.959964):
    p = x / n
    c = (p + z * z / (2 * n)) / (1 + z * z / n)
    h = z * np.sqrt(p * (1 - p) / n + z * z / (4 * n * n)) / (1 + z * z / n)
    return c - h, c + h


def newcombe(x1, n1, x2, n2):
    p1, p2 = x1 / n1, x2 / n2
    l1, u1 = wilson(x1, n1)
    l2, u2 = wilson(x2, n2)
    return (p2 - p1) - np.sqrt((p2 - l2) ** 2 + (u1 - p1) ** 2), (p2 - p1) + np.sqrt((u2 - p2) ** 2 + (p1 - l1) ** 2)


post_rows, res_rows, wsens_rows = [], [], []
for ep, g in st.groupby("endpoint", sort=False):
    draws, w, wn20, wn24 = {}, {}, {}, {}
    tot = {2.0: [0, 0], 2.4: [0, 0]}
    mh_num = mh_den = 0.0
    sv_r = sv_s = sv_rs = sv_ps = sv_qr = 0.0  # RBG sums
    for s_, h in g.groupby("stratum", sort=False):
        h = h.set_index("dose_mgkg")
        x20, n20, x24, n24 = int(h.loc[2.0, "events"]), int(h.loc[2.0, "n"]), int(h.loc[2.4, "events"]), int(h.loc[2.4, "n"])
        p20 = rng.beta(0.5 + x20, 0.5 + n20 - x20, N)
        p24 = rng.beta(0.5 + x24, 0.5 + n24 - x24, N)
        draws[s_] = (p20, p24)
        w[s_] = (n20 + n24)
        wn20[s_], wn24[s_] = n20, n24
        tot[2.0][0] += x20; tot[2.0][1] += n20; tot[2.4][0] += x24; tot[2.4][1] += n24
        d = p24 - p20
        post_rows.append(dict(endpoint=ep, stratum=s_, x20=x20, n20=n20, x24=x24, n24=n24, p20=x20 / n20, p24=x24 / n24, rd_median=np.median(d), rd_lo=np.percentile(d, 2.5), rd_hi=np.percentile(d, 97.5)))
        # Mantel-Haenszel: exposed = 2.4, a = events at 2.4, b = non-events at 2.4, c = events at 2.0, d_ = non-events at 2.0
        a, b, c, d_ = x24, n24 - x24, x20, n20 - x20
        T = a + b + c + d_
        R, S = a * d_ / T, b * c / T
        P, Q = (a + d_) / T, (b + c) / T
        sv_r += R; sv_s += S; sv_rs += P * R; sv_ps += P * S + Q * R; sv_qr += Q * S
    tw = sum(w.values())
    std = sum(w[s_] / tw * (draws[s_][1] - draws[s_][0]) for s_ in draws)
    # weight sensitivity: standardise to the 2.0 mg/kg mix, the 2.4 mg/kg mix, or the pooled mix (no new random draws)
    for wname, wd in (("pooled mix (main)", w), ("2.0 mg/kg arm mix", wn20), ("2.4 mg/kg arm mix", wn24)):
        wt = sum(wd.values())
        sd = sum(wd[s_] / wt * (draws[s_][1] - draws[s_][0]) for s_ in draws)
        wsens_rows.append(dict(endpoint=ep, weights=wname, std_rd_median=np.median(sd), std_lo=np.percentile(sd, 2.5), std_hi=np.percentile(sd, 97.5)))
    x20, n20, x24, n24 = tot[2.0][0], tot[2.0][1], tot[2.4][0], tot[2.4][1]
    c20 = rng.beta(0.5 + x20, 0.5 + n20 - x20, N)
    c24 = rng.beta(0.5 + x24, 0.5 + n24 - x24, N)
    crude = c24 - c20
    lo, hi = newcombe(x20, n20, x24, n24)
    or_mh = sv_r / sv_s
    se = np.sqrt(sv_rs / (2 * sv_r ** 2) + sv_ps / (2 * sv_r * sv_s) + sv_qr / (2 * sv_s ** 2))
    res_rows.append(dict(endpoint=ep, crude_20=f"{x20}/{n20}", crude_24=f"{x24}/{n24}", crude_rd_median=np.median(crude), crude_lo=np.percentile(crude, 2.5), crude_hi=np.percentile(crude, 97.5),
                         crude_newcombe_lo=lo, crude_newcombe_hi=hi, crude_fisher_p=stats.fisher_exact([[x24, n24 - x24], [x20, n20 - x20]])[1],
                         std_rd_median=np.median(std), std_lo=np.percentile(std, 2.5), std_hi=np.percentile(std, 97.5), p_std_rd_gt0=float((std > 0).mean()),
                         mh_or=or_mh, mh_or_lo=np.exp(np.log(or_mh) - 1.96 * se), mh_or_hi=np.exp(np.log(or_mh) + 1.96 * se),
                         share_sclc_npc_20=sum(h2.loc[h2.dose_mgkg == 2.0, "n"].iloc[0] for k, h2 in g.groupby("stratum") if k in ("SCLC", "NPC")) / n20,
                         share_sclc_npc_24=sum(h2.loc[h2.dose_mgkg == 2.4, "n"].iloc[0] for k, h2 in g.groupby("stratum") if k in ("SCLC", "NPC")) / n24))
sp = pd.DataFrame(post_rows)
rs = pd.DataFrame(res_rows)
sp.to_csv(OUT / "strata_posterior.csv", index=False)
rs.to_csv(OUT / "orr_tox_crude_vs_standardised.csv", index=False)
ws = pd.DataFrame(wsens_rows)
ws.to_csv(OUT / "std_weight_sensitivity.csv", index=False)
pd.set_option("display.width", 250)
print("== by stratum: proportions and RD (2.4 - 2.0)")
print(sp.round(3).to_string(index=False))
print("\n== crude vs standardised (2.4 - 2.0)")
print(rs.round(3).to_string(index=False))

# adverse events (Nat Med Table 2)
ae = pd.read_csv(ROOT / "inputs/ae_table2.csv")
rows = []
for _, r in ae.iterrows():
    p20 = rng.beta(0.5 + r["events_2.0"], 0.5 + r["n_2.0"] - r["events_2.0"], N)
    p24 = rng.beta(0.5 + r["events_2.4"], 0.5 + r["n_2.4"] - r["events_2.4"], N)
    d = p24 - p20
    lo, hi = newcombe(r["events_2.0"], r["n_2.0"], r["events_2.4"], r["n_2.4"])
    rows.append(dict(endpoint=r.endpoint, e20=f"{r['events_2.0']}/{r['n_2.0']}", e24=f"{r['events_2.4']}/{r['n_2.4']}", obs20=r["events_2.0"] / r["n_2.0"], obs24=r["events_2.4"] / r["n_2.4"],
                     rd_median=np.median(d), rd_lo=np.percentile(d, 2.5), rd_hi=np.percentile(d, 97.5), p_rd_gt0=float((d > 0).mean()),
                     fisher_p=stats.fisher_exact([[r["events_2.4"], r["n_2.4"] - r["events_2.4"]], [r["events_2.0"], r["n_2.0"] - r["events_2.0"]]])[1]))
aec = pd.DataFrame(rows)
aec.to_csv(OUT / "ae_comparison.csv", index=False)
print("\n== adverse events, 2.4 - 2.0 (crude; Nat Med Table 2)")
print(aec.round(3).to_string(index=False))
