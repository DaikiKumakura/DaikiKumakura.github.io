"""Conditional aggregate calibration and nonidentified combination PK scenarios."""
import numpy as np
from scipy.stats import t as student_t,norm
from pk_model import parameters,metrics,profile

def calibration(cfg: dict, convention: str) -> dict:
    s=cfg['combo'];var=np.log1p(s['cv']**2);se=np.sqrt(var/s['n'])
    gm=s['summary'] if convention=='GM' else s['summary']/np.sqrt(1+s['cv']**2)
    reference=s['dara_mg']*(1-cfg['pk']['em'])*1000/cfg['pk']['cl']
    k=gm/reference;delta=student_t.ppf(.975,s['n']-1)*se
    return dict(convention=convention,assumed_combo_gm=gm,log_sd=np.sqrt(var),log_se=se,
                k=k,k_low=k*np.exp(-delta),k_high=k*np.exp(delta),
                match_mg=300/k,match_low=300/(k*np.exp(delta)),match_high=300/(k*np.exp(-delta)))

def regimen(dose: float) -> dict:return dict(times=[0],doses=[dose])

def combo_parameters(cfg: dict,eta: np.ndarray | None,k: float,mechanism: str) -> dict:
    p=parameters(cfg,eta)
    if mechanism=='CL':p['cl']/=k
    elif mechanism!='input':raise ValueError(mechanism)
    return p

def combo_metrics(cfg: dict,eta: np.ndarray | None,dose: float,k: float,mechanism: str,branch: str='per_dose',step: float | None=None) -> dict:
    p=combo_parameters(cfg,eta,k,mechanism);m=metrics(cfg,p,regimen(dose),branch,step)
    return {key:v*(k if mechanism=='input' else 1) for key,v in m.items()}

def combo_profile(cfg: dict,eta: np.ndarray | None,t: np.ndarray,dose: float,k: float,mechanism: str,branch: str='per_dose') -> np.ndarray:
    p=combo_parameters(cfg,eta,k,mechanism)
    return profile(cfg,p,t,regimen(dose),branch)*(k if mechanism=='input' else 1)

def analytic_tail(scale: float,sigma: float) -> tuple[float,float]:
    q=norm.ppf(.95)
    return norm.cdf(-q-np.log(scale)/sigma),1-norm.cdf(q-np.log(scale)/sigma)
