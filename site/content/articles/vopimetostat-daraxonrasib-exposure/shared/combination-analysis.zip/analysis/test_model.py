"""Independent numerical and analytical checks, not clinical validation."""
from pathlib import Path
import json,unittest
import numpy as np
from scipy.integrate import solve_ivp
from scipy.stats import norm
from pk_model import parameters,response,metrics
from model import calibration,combo_metrics,combo_profile,combo_parameters,regimen,analytic_tail
C=json.loads((Path(__file__).parent/'inputs.json').read_text())

class Tests(unittest.TestCase):
    def test_summary_conversion(self):
        a=calibration(C,'AM');g=calibration(C,'GM')
        self.assertAlmostEqual(a['assumed_combo_gm']*np.exp(a['log_sd']**2/2),4106)
        self.assertAlmostEqual(g['assumed_combo_gm'],4106)
        self.assertLess(a['k'],g['k'])
        self.assertAlmostEqual(np.log(g['k_high']/g['k']),np.log(g['k']/g['k_low']))

    def test_ode(self):
        eta=np.random.default_rng(32).multivariate_normal(np.zeros(3),C['omega'],size=4)
        p=combo_parameters(C,eta,3.4,'CL')
        for i in range(4):
            cl,vc,q,vp,ka=(p[k][i] for k in ['cl','vc','q','vp','ka']);ka*=2.49
            matrix=np.array([[-ka,0,0],[ka,-(cl+q)/vc,q/vp],[0,q/vc,-q/vp]])
            t=np.linspace(0,96,193);s=solve_ivp(lambda t,y:matrix@y,[0,96],[1,0,0],t_eval=t,rtol=1e-10,atol=1e-12)
            pi={key:v[i:i+1] for key,v in p.items()}
            np.testing.assert_allclose(response(pi,t+p['lag'][i],2.49)[0],s.y[1]*1000/vc,rtol=1e-6,atol=1e-8)

    def test_mass_balance_both_scenarios(self):
        t=np.linspace(0,24,24001)
        for mechanism in ['input','CL']:
            for dose in [50,100,150]:
                m=combo_metrics(C,None,dose,3.4,mechanism)
                q=np.trapz(combo_profile(C,None,t,dose,3.4,mechanism)[0],t)
                self.assertAlmostEqual(q,m['auc24'][0],places=3)

    def test_same_auc_different_shape(self):
        a=combo_metrics(C,None,100,3.4,'input');b=combo_metrics(C,None,100,3.4,'CL')
        self.assertAlmostEqual(a['auc24'][0],b['auc24'][0])
        self.assertGreater(a['cmax'][0],b['cmax'][0]);self.assertLess(a['cmin'][0],b['cmin'][0])

    def test_match_dose_and_pairing(self):
        eta=np.random.default_rng(77).multivariate_normal(np.zeros(3),C['omega'],size=50)
        ref=metrics(C,parameters(C,eta),regimen(300))
        for cal in [calibration(C,c) for c in ['GM','AM']]:
            for mechanism in ['input','CL']:
                alt=combo_metrics(C,eta,cal['match_mg'],cal['k'],mechanism)
                np.testing.assert_allclose(alt['auc24'],ref['auc24'],rtol=1e-12)

    def test_lognormal_tails(self):
        sigma=np.sqrt(C['omega'][0][0]);rng=np.random.default_rng(18);x=np.exp(rng.normal(0,sigma,100000))
        for scale in [.6,1,1.5]:
            lo,hi=analytic_tail(scale,sigma);q=np.exp(norm.ppf([.05,.95])*sigma)
            self.assertLess(abs(np.mean(scale*x<q[0])-lo),.004)
            self.assertLess(abs(np.mean(scale*x>q[1])-hi),.004)

    def test_grid(self):
        eta=np.random.default_rng(202).multivariate_normal(np.zeros(3),C['omega'],size=24)
        for mechanism in ['input','CL']:
            for dose in [50,100,150]:
                a=combo_metrics(C,eta,dose,3.4,mechanism);b=combo_metrics(C,eta,dose,3.4,mechanism,step=.0025)
                for key in ['cmax','cmin']:np.testing.assert_allclose(a[key],b[key],rtol=.001)

    def test_steady_periodicity(self):
        for mechanism in ['input','CL']:
            a=combo_profile(C,None,np.array([0,1,3,12]),100,3.4,mechanism)
            b=combo_profile(C,None,np.array([24,25,27,36]),100,3.4,mechanism)
            np.testing.assert_allclose(a,b,rtol=1e-12)

if __name__=='__main__':unittest.main()
