"""Execute all conditional analyses; source ambiguity is not a fitted DDI."""
from pathlib import Path
import json,platform,hashlib
import numpy as np
import pandas as pd
import scipy
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from pk_model import parameters,metrics,profile
from model import calibration,combo_metrics,combo_profile,regimen,analytic_tail

ROOT=Path(__file__).resolve().parents[1]
COLORS=['#0072B2','#D55E00','#009E73','#8a6996']
def quantiles(v):
    q=np.quantile(v,[.05,.5,.95]);return dict(p05=q[0],median=q[1],p95=q[2])

def main():
    cfg=json.loads((ROOT/'analysis/inputs.json').read_text());out=ROOT/'outputs';tab=out/'tables';figs=out/'figures'
    tab.mkdir(parents=True,exist_ok=True);figs.mkdir(exist_ok=True)
    plt.rcParams.update({'font.family':'DejaVu Sans','font.size':11,'axes.spines.top':False,'axes.spines.right':False,'savefig.dpi':160})
    rng=np.random.default_rng(cfg['seed']);eta=rng.multivariate_normal(np.zeros(3),cfg['omega'],size=cfg['n'])
    base=metrics(cfg,parameters(cfg,eta),regimen(300));typbase=metrics(cfg,parameters(cfg),regimen(300))
    refq=np.quantile(base['auc24'],[.05,.95]);cals=[calibration(cfg,c) for c in ['GM','AM']]
    pd.DataFrame(cals).to_csv(tab/'conditional-calibration.csv',index=False)
    absolute=[];ratios=[];tails=[];scenario=[];saved={}
    for cal in cals:
        conv=cal['convention'];saved[conv]={}
        for mechanism in ['input','CL']:
            saved[conv][mechanism]={}
            for dose in cfg['doses']:
                m=combo_metrics(cfg,eta,dose,cal['k'],mechanism);tm=combo_metrics(cfg,None,dose,cal['k'],mechanism)
                saved[conv][mechanism][dose]=m
                for key,v in m.items():
                    assert np.isfinite(v).all() and (v>0).all()
                    absolute.append(dict(convention=conv,mechanism=mechanism,dose_mg=dose,metric=key,typical=tm[key][0],geomean=np.exp(np.log(v).mean()),**quantiles(v)))
                    ratios.append(dict(convention=conv,mechanism=mechanism,dose_mg=dose,metric=key,**quantiles(v/base[key])))
                lower,upper=analytic_tail(dose*cal['k']/300,np.sqrt(cfg['omega'][0][0]))
                tails.append(dict(convention=conv,mechanism=mechanism,dose_mg=dose,below_reference_p05=np.mean(m['auc24']<refq[0]),above_reference_p95=np.mean(m['auc24']>refq[1]),analytic_below=lower,analytic_above=upper))
                for bound in ['k_low','k','k_high']:
                    scenario.append(dict(convention=conv,mechanism=mechanism,dose_mg=dose,k_bound=bound,k=cal[bound],auc_ratio=dose*cal[bound]/300))
    aa=pd.DataFrame(absolute);rr=pd.DataFrame(ratios);tt=pd.DataFrame(tails)
    aa.to_csv(tab/'steady-metrics.csv',index=False);rr.to_csv(tab/'paired-ratios.csv',index=False);tt.to_csv(tab/'reference-tails.csv',index=False)
    pd.DataFrame(scenario).to_csv(tab/'summary-location-scenarios.csv',index=False)
    sens=[]
    for exponent in [.8,1,1.2]:
        for cal in cals:
            for dose in cfg['doses']:
                # analyst-selected dose-AUC slope sensitivity, anchored at observed100mg
                ratio=100*cal['k']/300*(dose/100)**exponent
                sens.append(dict(convention=cal['convention'],exponent=exponent,dose_mg=dose,auc_ratio=ratio))
    pd.DataFrame(sens).to_csv(tab/'dose-slope-sensitivity.csv',index=False)
    branches=[]
    for mechanism in ['input','CL']:
        for dose in cfg['doses']:
            m=combo_metrics(cfg,eta,dose,cals[0]['k'],mechanism,'daily_dose')
            # QD daily branch equals per-dose; alternative turns lowdose effect off explicitly
            cc=json.loads(json.dumps(cfg));cc['covariates']['low_dose_ka_effect']=0
            alt=combo_metrics(cc,eta,dose,cals[0]['k'],mechanism)
            for key in ['cmax','cmin','auc24']:
                branches.append(dict(mechanism=mechanism,dose_mg=dose,metric=key,nominal_median=np.median(m[key]/base[key]),no_lowdose_ka_median=np.median(alt[key]/base[key])))
    pd.DataFrame(branches).to_csv(tab/'absorption-sensitivity.csv',index=False)
    times=np.linspace(0,24,1201);curve={'hours':times,'300QD_reference':profile(cfg,parameters(cfg),times,regimen(300))[0]}
    for mech in ['input','CL']:curve['100QD_combo_'+mech]=combo_profile(cfg,None,times,100,cals[0]['k'],mech)[0]
    pd.DataFrame(curve).to_csv(tab/'typical-curves.csv',index=False)
    fig,ax=plt.subplots(figsize=(8,3.8),layout='constrained')
    for i,cal in enumerate(cals):
        ax.errorbar(cal['k'],i,xerr=[[cal['k']-cal['k_low']],[cal['k_high']-cal['k']]],fmt='o',capsize=5,color=COLORS[i])
    ax.axvline(1,ls='--',color='.6');ax.set(xlabel='Conditional aggregate scale K (not an identified DDI)',yticks=[0,1],yticklabels=['Assume GM + geometric CV','Assume AM + SD/mean CV'],xlim=(0,5.5),ylim=(-.6,1.6),title='Assuming source AUC is comparable steady 24 h exposure')
    fig.savefig(figs/'conditional-scale.png');plt.close(fig)
    fig,axes=plt.subplots(1,3,figsize=(11,4),layout='constrained')
    for ax,key,title in zip(axes,['cmax','cmin','auc24'],['Cmax','24 h minimum','AUC24']):
        for j,mech in enumerate(['input','CL']):
            sub=rr[(rr.convention=='GM')&(rr.mechanism==mech)&(rr.metric==key)]
            for i,(_,r) in enumerate(sub.iterrows()):
                x=i+(-.12 if j==0 else .12)
                ax.errorbar(x,r['median'],yerr=[[r['median']-r['p05']],[r['p95']-r['median']]],fmt='o' if j==0 else 's',capsize=3,color=COLORS[j],label=mech if i==0 else None)
        ax.axhline(1,color='.6',ls='--');ax.set_xticks(range(4),['50QD','75QD','100QD','150QD'],rotation=25);ax.set(ylabel='Paired ratio vs 300QD monotherapy',title=title,ylim=(0,None))
    axes[0].legend(fontsize=9);fig.suptitle('Conditional GM convention, n=4096; median and 5th-95th percentiles',fontsize=12)
    fig.savefig(figs/'paired-exposure.png');plt.close(fig)
    fig,axes=plt.subplots(1,2,figsize=(10,4),layout='constrained')
    for key,col in zip(list(curve)[1:],COLORS):axes[0].plot(times,curve[key],label=key.replace('_',' '),color=col)
    axes[0].set(xlabel='Hours in a steady 24-hour day',ylabel='Whole-blood concentration (ng/mL)',title='Two combo models, same assumed AUC');axes[0].legend(fontsize=8)
    for i,conv in enumerate(['GM','AM']):
        sub=tt[(tt.convention==conv)&(tt.mechanism=='input')]
        axes[1].plot(sub.dose_mg,100*sub.below_reference_p05,'o-',color=COLORS[i],label=conv+': below reference P05')
        axes[1].plot(sub.dose_mg,100*sub.above_reference_p95,'s--',color=COLORS[i],label=conv+': above reference P95')
    axes[1].axhline(5,color='.6',ls=':');axes[1].set(xlabel='Hypothetical combo daraxonrasib dose (mg QD)',ylabel='Conditional individuals (%)',ylim=(0,100),title='Reference tails, not therapeutic limits');axes[1].legend(fontsize=8)
    fig.savefig(figs/'shape-and-tails.png');plt.close(fig)
    result=dict(n=cfg['n'],seed=cfg['seed'],calibration=cals,typical_reference={k:float(v[0]) for k,v in typbase.items()},reference_auc_p05_p95=refq.tolist(),paired=rr.to_dict('records'),tails=tt.to_dict('records'))
    (out/'results.json').write_text(json.dumps(result,indent=2)+'\n')
    (out/'environment.json').write_text(json.dumps(dict(python=platform.python_version(),numpy=np.__version__,pandas=pd.__version__,scipy=scipy.__version__,matplotlib=matplotlib.__version__),indent=2)+'\n')
    source=ROOT.parent/'oncology-trend-ideas-2026-10-22/data/daraxonrasib-fda.pdf'
    if source.exists():(out/'source-hashes.json').write_text(json.dumps({'FDA-NDA220910.pdf':hashlib.sha256(source.read_bytes()).hexdigest()},indent=2)+'\n')
    print(pd.DataFrame(cals).to_string(index=False));print(rr[(rr.convention=='GM')&(rr.metric.isin(['cmax','cmin','auc24']))].to_string(index=False));print(tt.to_string(index=False))

if __name__=='__main__':main()
