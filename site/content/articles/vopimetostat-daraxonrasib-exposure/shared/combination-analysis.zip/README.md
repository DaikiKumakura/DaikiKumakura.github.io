# Vopimetostat and daraxonrasib: conditional exposure comparison

Research and learning only, not clinical dose or treatment instructions.
With an existing Python environment matching requirements.txt:
  python analysis/run_analysis.py
  python -m unittest discover -s analysis -p "test_model.py" -q
No network, account, download or original PDF needed.

Source June8,2026 SEC Exhibit99.2 slide20, May28data:
https://www.sec.gov/Archives/edgar/data/1819133/000119312526260679/d158334dex992.htm
Vopimetostat200mg+dara100mgQD, mixedPDAC/lung heading; daraAUC4106ng*h/mL,
n13,CV40.5%. AUCwindow,samplingday,measurementmatrix,mean/CVdefinition and13subject composition
UNREPORTED. Separate vopi250PK unavailable. Thus no identifiedDDI or200vs250
comparison. Source labelAUC3760 also has unspecified integrationwindow and is
not used as a quantitative calibration denominator.

Conditional assumption: unverified combo measurementmatrix is same wholeblood analyte.
Combo summary represents comparable steady24h wholeblood
AUC, either GM/geometricCV or AM/SD-to-meanCV underlognormal. Sigma2=ln(1+CV2),
AM-toGM=AM/sqrt(1+CV2). Loglocation scenario using t12*sqrt(sigma2/13).
This is a plug-in approximation, not originaltrialCI, posterior or proof of
endpoint compatibility. Unreported definitions cannot be covered by this interval.

Public human model FDA NDA220910 Table59 PDF242:
https://www.accessdata.fda.gov/drugsatfda_docs/nda/2026/220910Orig1s000MultidisciplineR.pdf
ApparentCL53.8L/h,Vc516L,Q26.1L/h,Vp255L,ka.735/h,lag.305h,steadyrelativeF.643.
Reference65y70kgPDAC,totalbilirubin8micromol/L,prior metastatictherapy. Variances
etaCL.139,Vc.168,ka.847,covCLVc.0949;others0assumed. n4096pairedseed20261023.
No new IPDNLME fit, representative combo covariates, residualerror, K-IIV,
fixedparameter jointuncertainty, vopiPK or dynamicDDImodel.

K=assumedGM/(100*.643*1000/53.8); corresponding dose300/K. Hypothetical50/75/100/
150mgQD with constantK; analystdoseexponents.8/1/1.2 sensitivity. These are not
available formulations or tablet splitting instructions. Source lowdoseka<=160
effect1.49 means2.49fold via1+theta*indicator; no-effect alternative included.
50mg outside labeldoseproportional80-300 evidence. Cmin24hminimum includeslag
cusps. Wholeblood is not plasma, unbound or tumor concentration.

Compare inputK scaling versus CL/K with otherwise same apparentcoefficients.
Both shareAUC, different shape. Not identified F/CYPmechanisms, bounds on true
profile, or clinicalDDIparameterestimates. RelativeF is not absoluteF. Constant
pairedAUCratio is constructed linearbalance, not evidence of preciseprediction.
ReferenceP05/P95 are sourceconditionalpopulationquantiles, not efficacy/safety
thresholds. IIVpercentiles separate from aggregate-location scenarios.

Sourceconditionaltypical300QDCmax296.7 vs labelGM365ng/mL; population/timing
differences unresolved. Shapes not qualified absolute-exposure predictions.
Label https://www.accessdata.fda.gov/drugsatfda_docs/nda/2026/220910Orig1s000Lbl.pdf
No efficacy equivalence, improvedtolerability, clinicalsynergy or safeoptimum
inferred. Vopi200/250PK separation and timecourse information still needed.

Outputs8CSV,3originalPNG,results/environmentJSON. SourceSHA records consulted
FDA snapshot, not verification of currentlyonlineoriginal. Originalsourcefigures
and patientdata not redistributed. CodeMIT; sourcefacts attributed above.
