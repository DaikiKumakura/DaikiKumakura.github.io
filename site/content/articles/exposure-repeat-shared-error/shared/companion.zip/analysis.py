for m in (1,4,16):
    factors = [1 / (1 + shared + 1/m) for shared in (0, .25)]
    print(m, *(f"{v:.6f}" for v in factors))
repeat_correlation = 1.25 / 2.25
print(f"correlation={repeat_correlation:.6f}, corrected={(1/2.25)/repeat_correlation:.6f}")
