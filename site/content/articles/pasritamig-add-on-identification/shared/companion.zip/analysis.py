from math import sqrt

n,x,z=15,11,1.959963984540054
p=x/n
center=(p+z*z/(2*n))/(1+z*z/n)
half=z*sqrt(p*(1-p)/n+z*z/(4*n*n))/(1+z*z/n)
print(f"Combination PSA50 = {p:.6f}; Wilson = {center-half:.6f}, {center+half:.6f}")
for q in (0,.4,.6,.8,1):
    print(f"Single-agent counterfactual = {q:.1f}; difference = {p-q:.6f}")
