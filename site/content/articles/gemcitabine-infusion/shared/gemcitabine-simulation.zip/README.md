# Gemcitabine infusion: plasma and PBMC

Independent fixed-effect implementation of the parent two-compartment and
PBMC dFdCTP three-compartment subsystem in Khatri et al. (2014),
DOI10.1038/bjc.2013.738, Tables2/4. Not full PBPK, patient refitting,
original NONMEM equivalence or independently validated clinical predictions.
Typical BSA1.76 m2, age70, NT5C2minor allele CC/CT; SLC28A3 reference nonCC.
Single dose1000 mg/m2, total1760 mg, from zero. Durations30/60/100min.
CLf is included in total parentCL, not an extra parentelimination route.
Amounts are parent-equivalentmg, a consistent molar scaling; metabolite
amount is not dFdCTP chemical mass. Public PBMC figures/metrics are relative.
For fixedCL, plasma AUCinf=dose/CL. PBMC AUCinf=CLf/CLe*parentAUCinf.
The categorical CLf change predetermines the infinite-AUC ratio.
The equality ROI25 is assigned to the high-rate group by convention.
Constant CLf is a sensitivity scenario, not a clinically validated model.
Marginal bootstrap bound scenarios and rectangular CLf corners are not
joint confidence intervals or patient prediction intervals.
AUC0-72 uses hours from infusion start, not hours after infusion end.
The post-window tail is extrapolated by the assumed model.
PBMC is not tumor. No efficacy/safety/risk/optimal regimen prediction.
Long infusion simulations do not override official toxicity warnings.

Use the recorded Python/library versions in outputs/environment.json.
Run python analysis/run_analysis.py to regenerate CSVs and figures.
Run python -m unittest discover -s analysis -q for independent checks.
Raw original articles, patient data, source figures and supplements are not
included. This example is for research/learning, not treatment or trial doses.
