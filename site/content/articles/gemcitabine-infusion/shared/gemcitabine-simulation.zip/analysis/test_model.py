import unittest
import numpy as np
from scipy.integrate import solve_ivp
from model import Parameters,matrix,parameters,curves,exact_state,integrated,infinite_auc,formation

class ModelTests(unittest.TestCase):
    def test_independent_ode(self):
        for minutes in [30,60,100]:
            p=parameters(minutes);m=matrix(p);T=minutes/60
            first=solve_ivp(lambda t,y:m@y+np.array([1760/T,0,0,0,0]),[0,T],np.zeros(5),method='Radau',rtol=1e-10,atol=1e-11,dense_output=True)
            after=solve_ivp(lambda t,y:m@y,[T,72],first.y[:,-1],method='Radau',rtol=1e-10,atol=1e-11,dense_output=True)
            ts=np.array([T/2,T,2,6,24,72])
            ys=np.column_stack([first.sol(t) if t<=T else after.sol(t) for t in ts])
            np.testing.assert_allclose(curves(ts,minutes,p),ys,rtol=1e-7,atol=1e-9)

    def test_matrix_exponential(self):
        p=parameters(60);ts=np.array([.1,1,6,24,72])
        np.testing.assert_allclose(curves(ts,60,p),np.column_stack([exact_state(t,60,p) for t in ts]),rtol=1e-10,atol=1e-10)

    def test_finite_plus_tail_equals_infinite(self):
        for minutes in [30,60,100]:
            p=parameters(minutes);y=exact_state(72,minutes,p)
            total=integrated(72,minutes,p)-np.linalg.solve(matrix(p),y)
            pa,ma=infinite_auc(p)
            np.testing.assert_allclose([total[0]/p.vc,total[2]/p.vm],[pa,ma],rtol=1e-10)

    def test_fixed_formation_auc_invariance(self):
        vals=[infinite_auc(parameters(t,False)) for t in [30,60,100]]
        self.assertEqual(vals[0],vals[1]);self.assertEqual(vals[0],vals[2])
        self.assertAlmostEqual(infinite_auc(parameters(100))[1]/vals[0][1],.118/.061,places=12)

    def test_event_and_domain(self):
        self.assertEqual(formation(40),.061);self.assertEqual(formation(40.0001),.118)
        self.assertEqual(formation(100,False),.061)
        np.testing.assert_allclose(curves([0],30,Parameters()),np.zeros((5,1)),atol=1e-12)
        with self.assertRaises(ValueError):formation(0)
        for t in [30,60,100]: self.assertLess(np.max(np.abs(curves([t/60-1e-7],t,parameters(t))-curves([t/60+1e-7],t,parameters(t)))),.001)

    def test_parent_not_double_counted(self):
        fast=parameters(30);slow=parameters(60)
        self.assertEqual(matrix(fast)[0,0],matrix(slow)[0,0])
        self.assertAlmostEqual(infinite_auc(fast)[0],1760/425,places=12)

if __name__=='__main__':unittest.main()
