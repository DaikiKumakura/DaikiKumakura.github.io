from pathlib import Path
from dataclasses import replace
import csv,json,platform
import numpy as np,scipy,matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from model import parameters,curves,metrics,infinite_auc
ROOT=Path(__file__).resolve().parents[1]
DURATIONS=[30,60,100]
COLORS=['#176B91','#5A93B2','#B0781B']
STYLES=['-','--',':']

def save(name,rows):
    path=ROOT/'outputs/tables'/name;path.parent.mkdir(parents=True,exist_ok=True)
    with path.open('w',newline='',encoding='utf8') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)

def clean(ax):
    ax.spines[['top','right']].set_visible(False);ax.grid(axis='y',color='#e6e6e6',lw=.6);ax.set_axisbelow(True)

def main():
    figs=ROOT/'outputs/figures';figs.mkdir(parents=True,exist_ok=True)
    plt.rcParams.update({'font.size':11,'axes.titlesize':12,'savefig.dpi':170})
    reference=metrics(30,parameters(30))
    rows=[]
    for mode in ['published_category','fixed_formation']:
        for minutes in DURATIONS:
            p=parameters(minutes,mode=='published_category');m=metrics(minutes,p)
            r={'mode':mode,'duration_min':minutes,'dose_mg_m2':1000,'dose_mg':1760,'rate_mg_m2_min':1000/minutes,'formation_cl_l_h':p.cf,**m}
            for key in ['plasma_auc_inf','plasma_cmax','pbmc_auc_inf','pbmc_cmax','pbmc_auc_72']:r[key+'_ratio']=m[key]/reference[key]
            rows.append(r)
    save('main.csv',rows)
    # Parameter bounds are marginal bootstrap bounds, not a joint CI.
    bounds={'cl':(361.8,485.8),'vc':(102.1,127.3),'q':(6.2,23.4),'vp':(39.5,447.4),
            'ce':(.0007,.0023),'qm1':(.077,.774),'qm2':(.0008,.0023),'vmp1':(.017,.048),'vmp2':(.017,.221)}
    sensitivity=[]
    for key,(lo,hi) in bounds.items():
        for side,val in [('lower',lo),('upper',hi)]:
            for minutes in DURATIONS:
                m=metrics(minutes,replace(parameters(minutes),**{key:val}))
                sensitivity.append({'parameter':key,'marginal_bound':side,'value':val,'duration_min':minutes,**m})
    save('marginal_sensitivity.csv',sensitivity)
    cfrows=[]
    for slow in [.071,.118,.235]:
        for fast in [.041,.061,.101]:cfrows.append({'slow_cf':slow,'fast_cf':fast,'infinite_auc_ratio':slow/fast})
    save('formation_corners.csv',cfrows)
    genotype=[]
    for multiplier in [1,1.77]:
        baseline=infinite_auc(replace(parameters(30),cf=parameters(30).cf*multiplier))[1]
        for minutes in DURATIONS:
            p=replace(parameters(minutes),cf=parameters(minutes).cf*multiplier)
            genotype.append({'formation_multiplier':multiplier,'duration_min':minutes,'pbmc_auc_inf_ratio':infinite_auc(p)[1]/baseline})
    save('genotype_multiplier.csv',genotype)
    scan=[]
    for minutes in np.unique(np.r_[np.linspace(21,120,100),39.99,40,40.01]):
        for mode in ['published_category','fixed_formation']:
            p=parameters(minutes,mode=='published_category');pa,ma=infinite_auc(p)
            scan.append({'duration_min':float(minutes),'rate_mg_m2_min':float(1000/minutes),'mode':mode,'pbmc_auc_inf_ratio':ma/reference['pbmc_auc_inf']})
    save('duration_scan.csv',scan)
    # Figure 1 uses separate plasma and PBMC axes, not interchangeable units.
    fig,axes=plt.subplots(1,2,figsize=(10.5,4.5))
    times=np.unique(np.r_[np.linspace(0,8,801),np.linspace(8,72,641)])
    curve_rows=[]
    for minutes,c,ls in zip(DURATIONS,COLORS,STYLES):
        p=parameters(minutes);y=curves(times,minutes,p)
        axes[0].plot(times,y[0]/p.vc,color=c,ls=ls,lw=2,label=f'{minutes} min')
        axes[1].plot(times,y[2]/p.vm/reference['pbmc_cmax'],color=c,ls=ls,lw=2,label=f'{minutes} min')
        curve_rows.extend({'duration_min':minutes,'hours_from_infusion_start':float(t),'plasma_mg_l':float(a/p.vc),'pbmc_relative_to_30min_peak':float(b/p.vm/reference['pbmc_cmax'])} for t,a,b in zip(times,y[0],y[2]))
    save('curves.csv',curve_rows)
    axes[0].set(xlim=(0,6),ylim=(0,None),xlabel='Hours from infusion start',ylabel='Plasma gemcitabine (mg/L)',title='Plasma parent drug')
    axes[1].set(xlim=(0,72),ylim=(0,None),xlabel='Hours from infusion start',ylabel='PBMC dFdCTP / 30-min peak',title='Intracellular metabolite (normalized)')
    for ax in axes:clean(ax);ax.legend(frameon=False)
    fig.suptitle('Same 1,000 mg/m² dose; published categorical formation',fontsize=13)
    fig.text(.5,.01,'Typical fixed effects; PBMC is not tumor. No clinical outcome prediction.',ha='center',fontsize=10)
    fig.tight_layout(rect=(0,.05,1,.94));fig.savefig(figs/'01-timecourse.png');plt.close(fig)
    # Figure 2 makes the structural source of the AUC ratio visible.
    fig,ax=plt.subplots(figsize=(8.2,4.8))
    x=np.arange(3)
    for offset,mode,color,label in [(-.18,'published_category','#176B91','Published ROI category'),(.18,'fixed_formation','#B0781B','Fixed formation clearance')]:
        rr=[r for r in rows if r['mode']==mode];ax.bar(x+offset,[r['pbmc_auc_inf_ratio'] for r in rr],width=.32,color=color,edgecolor='#444444',lw=.6,label=label)
    ax.axhline(1,color='#444444',lw=1);ax.set(xticks=x,xticklabels=['30 min','60 min','100 min'],ylabel='PBMC dFdCTP AUC∞ / 30-min AUC∞',ylim=(0,2.25),title='Formation-clearance assumptions and PBMC AUC')
    clean(ax);ax.legend(frameon=False)
    fig.text(.5,.01,'AUC∞ is analytic; category change supplies the 0.118/0.061 ratio.',ha='center',fontsize=10)
    fig.tight_layout(rect=(0,.05,1,1));fig.savefig(figs/'02-formation-comparison.png');plt.close(fig)
    # Figure 3 scans a discontinuity; the equality assignment is a stated convention.
    fig,axes=plt.subplots(1,2,figsize=(10.5,4.6))
    for mode,c,ls,label in [('published_category','#176B91','-','Published ROI category'),('fixed_formation','#B0781B','--','Fixed formation')]:
        rs=[r for r in scan if r['mode']==mode]
        axes[0].plot([r['duration_min'] for r in rs],[r['pbmc_auc_inf_ratio'] for r in rs],color=c,ls=ls,lw=2,label=label)
    axes[0].axvline(40,color='#777777',ls=':',lw=1)
    axes[0].plot(40,1,marker='o',ms=6,color='#176B91',ls='none')
    axes[0].plot(40,.118/.061,marker='o',ms=6,mfc='white',mec='#176B91',ls='none')
    axes[0].set(xlim=(21,120),ylim=(0,2.25),xlabel='Infusion duration (min)',ylabel='PBMC AUC∞ ratio',title='Duration boundary in the categorical model')
    axes[0].legend(frameon=False,fontsize=9)
    from model import integrated
    tail=[]
    for ce,c,ls,label in zip([.0007,.00131,.0023],COLORS,STYLES,['Lower CLe bound','Typical CLe','Upper CLe bound']):
        p=replace(parameters(30),ce=ce);ma=infinite_auc(p)[1]
        ts=np.arange(0,169,2);points=[float(integrated(float(t),30,p)[2]/p.vm/ma) for t in ts]
        axes[1].plot(ts,points,color=c,ls=ls,lw=1.8,label=label)
        tail.extend({'pbmc_elimination_cl_l_h':ce,'hours_from_start':int(t),'fraction_auc_inf':v} for t,v in zip(ts,points))
    save('tail_sensitivity.csv',tail)
    for t in [24,72]:axes[1].axvline(t,color='#777777',ls=':',lw=.8)
    axes[1].set(xlim=(0,168),ylim=(0,1),xlabel='Cutoff after infusion start (h)',ylabel='Fraction of PBMC AUC∞ captured',title='PBMC elimination and extrapolated tail')
    axes[1].legend(frameon=False,fontsize=9)
    for ax in axes:clean(ax)
    fig.text(.5,.01,'40 min = 25 mg/m²/min at this dose. Long infusions are research scenarios only.',ha='center',fontsize=10)
    fig.tight_layout(rect=(0,.05,1,1));fig.savefig(figs/'03-boundary-and-tail.png');plt.close(fig)
    env={'python':platform.python_version(),'numpy':np.__version__,'scipy':scipy.__version__,'matplotlib':matplotlib.__version__}
    (ROOT/'outputs/environment.json').write_text(json.dumps(env,indent=2)+'\n',encoding='utf8')
    (ROOT/'outputs/verification.json').write_text(json.dumps({'source':'Khatri2014 Tables2/4','clinical_revalidation':False,'full_PBPK_reproduced':False,'dose_mg':1760,'main_rows':len(rows),'marginal_sensitivity_rows':len(sensitivity),'parent_auc_identity_mg_h_l':1760/425},indent=2)+'\n',encoding='utf8')
    print(json.dumps(rows[:3],indent=2));print('Marginal scenarios:',len(sensitivity))

if __name__=='__main__':main()
