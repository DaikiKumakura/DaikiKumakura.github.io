"""Fixed-effect plasma/PBMC subsystem; amounts are gemcitabine equivalents."""
from dataclasses import dataclass,replace
import numpy as np
from scipy.linalg import expm

@dataclass(frozen=True)
class Parameters:
    cl:float=425.0
    vc:float=114.0
    q:float=10.1
    vp:float=101.0
    cf:float=.061
    ce:float=.00131
    vm:float=.005
    qm1:float=.206
    qm2:float=.00126
    vmp1:float=.0288
    vmp2:float=.0877

def matrix(p:Parameters)->np.ndarray:
    if any(v<=0 for v in vars(p).values()):raise ValueError('Positive parameters required')
    m=np.zeros((5,5))
    m[0,0]=-(p.cl+p.q)/p.vc;m[0,1]=p.q/p.vp
    m[1,0]=p.q/p.vc;m[1,1]=-p.q/p.vp
    # Formation is included in the reported total parent clearance, not added.
    m[2,0]=p.cf/p.vc
    m[2,2]=-(p.ce+p.qm1+p.qm2)/p.vm
    m[2,3]=p.qm1/p.vmp1;m[2,4]=p.qm2/p.vmp2
    m[3,2]=p.qm1/p.vm;m[3,3]=-p.qm1/p.vmp1
    m[4,2]=p.qm2/p.vm;m[4,4]=-p.qm2/p.vmp2
    return m

def formation(minutes:float,published:bool=True)->float:
    if minutes<=0:raise ValueError('Positive infusion duration')
    return .118 if published and 1000/minutes<25 else .061

def parameters(minutes:float,published:bool=True)->Parameters:
    return Parameters(cf=formation(minutes,published))

def exact_state(t:float,minutes:float,p:Parameters,dose:float=1760)->np.ndarray:
    if t<0 or minutes<=0 or dose<=0:raise ValueError('Invalid time/dose')
    m=matrix(p);duration=minutes/60
    u=np.array([dose/duration,0,0,0,0])
    end=min(t,duration)
    y=np.linalg.solve(m,(expm(m*end)-np.eye(5))@u)
    return expm(m*max(0,t-duration))@y

def curves(t,minutes:float,p:Parameters,dose:float=1760)->np.ndarray:
    """Diagonalized matrix exponential, cross-checked against independent solvers."""
    t=np.asarray(t,dtype=float)
    if np.any(t<0) or minutes<=0 or dose<=0:raise ValueError('Invalid time/dose')
    m=matrix(p);duration=minutes/60
    eig,v=np.linalg.eig(m);vi=np.linalg.inv(v)
    u=np.array([dose/duration,0,0,0,0]);coef=vi@u
    capped=np.minimum(t,duration)
    during=v@((np.exp(eig[:,None]*capped)-1)/eig[:,None]*coef[:,None])
    end=v@((np.exp(eig*duration)-1)/eig*coef)
    after=v@(np.exp(eig[:,None]*np.maximum(0,t-duration))*(vi@end)[:,None])
    y=np.where((t<=duration)[None,:],during,after).real
    if np.min(y)<-1e-8:raise AssertionError('Unexpected negative amount')
    return y

def integrated(t:float,minutes:float,p:Parameters,dose:float=1760)->np.ndarray:
    """Exact finite integral of all five amounts by augmented matrix exponential."""
    if t<0 or minutes<=0 or dose<=0:raise ValueError('Invalid time/dose')
    m=matrix(p);duration=minutes/60
    aug=np.zeros((11,11));aug[:5,:5]=m;aug[5:10,:5]=np.eye(5)
    aug[0,10]=dose/duration
    y=np.zeros(11);y[-1]=1
    y=expm(aug*min(t,duration))@y
    if t>duration:
        aug[0,10]=0;y=expm(aug*(t-duration))@y
    return y[5:10]

def infinite_auc(p:Parameters,dose:float=1760)->tuple[float,float]:
    return dose/p.cl,p.cf/p.ce*dose/p.cl

def metrics(minutes:float,p:Parameters)->dict:
    t=np.unique(np.r_[np.linspace(0,8,8001),np.linspace(8,72,641),minutes/60])
    y=curves(t,minutes,p);a72=integrated(72,minutes,p);a24=integrated(24,minutes,p)
    pa,ma=infinite_auc(p)
    return {'plasma_auc_inf':pa,'plasma_cmax':float(y[0].max()/p.vc),
            'pbmc_auc_inf':ma,'pbmc_cmax':float(y[2].max()/p.vm),
            'pbmc_auc_72':float(a72[2]/p.vm),'pbmc_fraction_24':float(a24[2]/p.vm/ma),
            'pbmc_fraction_72':float(a72[2]/p.vm/ma)}
