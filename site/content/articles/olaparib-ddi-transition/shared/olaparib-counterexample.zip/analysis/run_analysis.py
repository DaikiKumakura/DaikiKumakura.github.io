"""Generate original figures and tables for a conditional DDI counterexample."""
from pathlib import Path
import csv,json,platform
import numpy as np
import scipy
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from model import ratio,initial_inhibition,crossing,dose_index

ROOT=Path(__file__).resolve().parents[1]
F_VALUES=[.75,.85,.95]
COLORS=['#176B91','#598FB0','#B4C9D5']
STYLES=['-','--',':']

def save_table(name,rows):
    p=ROOT/'outputs/tables'/name;p.parent.mkdir(parents=True,exist_ok=True)
    with p.open('w',newline='',encoding='utf8') as out:
        w=csv.DictWriter(out,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)

def decorate(ax):
    ax.spines[['top','right']].set_visible(False)
    ax.grid(axis='y',color='#e8e8e8',linewidth=.6)
    ax.set_axisbelow(True)

def main():
    figs=ROOT/'outputs/figures';figs.mkdir(parents=True,exist_ok=True)
    plt.rcParams.update({'font.size':11,'axes.titlesize':12,'figure.facecolor':'white','savefig.dpi':170})
    rows=[]
    for f in F_VALUES:
        rows.append({'f_scenario':f,'x0_calibrated':initial_inhibition(f,2.7),
                     'R_at_0':float(ratio(0,f)),'R_at_3':float(ratio(3,f)),'R_at_5':float(ratio(5,f)),
                     'n_to_R_1_10':crossing(f,2.7,1.1)})
    save_table('matched_anchors.csv',rows)
    n=np.linspace(0,10,1001)
    save_table('curves.csv',[{'n_assumed_half_lives':float(t),'f_scenario':f,'R':float(ratio(t,f))} for f in F_VALUES for t in n])
    label=[{'n_parent_half_lives':h,'parent_half_life_hours':p,'elapsed_hours':h*p,'elapsed_days':h*p/24} for h in [3,5] for p in [34,42]]
    save_table('label_arithmetic.csv',label)
    anchors=[('observed_interval_lower',2.44),('observed_point_anchor',2.7),('observed_interval_upper',2.97),('published_PBPK_prediction',3.55)]
    sens=[{'anchor_class':cl,'R0_anchor':a,'f_scenario':float(f),'diagnostic_threshold':th,'n_crossing':crossing(float(f),a,th)}
          for cl,a in anchors for f in np.linspace(.75,.95,21) for th in [1.05,1.1,1.25]]
    save_table('sensitivity.csv',sens)
    # Figure 1: continuous mathematical off-transient, not clinical time.
    fig,ax=plt.subplots(figsize=(8.2,4.7))
    for f,c,style in zip(F_VALUES,COLORS,STYLES):
        ax.plot(n,ratio(n,f),color=c,ls=style,lw=2.2,label=f'f = {f:.2f}')
    ax.axhline(1,color='#444444',lw=1);ax.axhline(1.1,color='#777777',ls='--',lw=1,label='Diagnostic R = 1.10')
    ax.set(xlim=(0,10),ylim=(.95,2.85),xlabel='Time after cessation / assumed effect-site half-life (n)',ylabel='Conditional disposition ratio R(n)',title='Same initial ratio, different post-cessation curves')
    ax.legend(frameon=False,ncol=2);decorate(ax)
    fig.text(.5,.01,'All curves calibrated to R(0) = 2.7; f values are analyst scenarios, not estimates.',ha='center',fontsize=9)
    fig.tight_layout(rect=(0,.045,1,1));fig.savefig(figs/'01-matched-anchors.png');plt.close(fig)
    # Figure 2: instantaneous discontinuity deliberately illustrates index, not concentration.
    fig,axes=plt.subplots(1,3,figsize=(12,4.1),sharey=True)
    dose_rows=[]
    for ax,restore in zip(axes,[0,3,5]):
        for f,c,style in zip(F_VALUES,COLORS,STYLES):
            y=dose_index(n,f,restore)
            ax.plot(n,y,color=c,ls=style,lw=2,label=f'f = {f:.2f}')
            for at in [0,3,5,8]: dose_rows.append({'restore_at_n':restore,'f_scenario':f,'assessment_n':at,'B_index':float(dose_index(at,f,restore))})
        ax.axhline(1,color='#444444',lw=1)
        if restore: ax.axvline(restore,color='#777777',ls=':',lw=1)
        ax.set(xlim=(0,8),ylim=(0,2.85),xlabel='Assumed half-lives (n)',title=f'Restore at n = {restore}')
        decorate(ax)
    axes[0].set_ylabel('Algebraic index B = dose fraction × R')
    axes[0].legend(frameon=False,fontsize=9)
    fig.suptitle('Hypothetical 100/300 to 300/300 dose fractions',fontsize=13)
    fig.text(.5,.01,'Index only: not daily AUC, concentration, toxicity or dose advice. Jumps are algebraic.',ha='center',fontsize=10)
    fig.tight_layout(rect=(0,.065,1,.94));fig.savefig(figs/'02-dose-index.png');plt.close(fig)
    save_table('dose_index.csv',dose_rows)
    # Figure 3: sensitivity geometry; no probabilistic uncertainty band.
    fig,ax=plt.subplots(figsize=(8.2,4.7))
    xs=np.linspace(.75,.95,101)
    for a,c,style in [(2.44,'#176B91',':'),(2.7,'#176B91','-'),(2.97,'#176B91','--'),(3.55,'#B07719','-.')]:
        ax.plot(xs,[crossing(float(f),a,1.1) for f in xs],color=c,ls=style,lw=2,label=f'R(0) = {a:.2f}')
    ax.set(xlabel='Analyst scenario f (not an estimated biological fraction)',ylabel='Assumed half-lives to R = 1.10',ylim=(0,9),title='A crossing time depends on more than the initial ratio')
    ax.legend(frameon=False,ncol=2);decorate(ax)
    fig.text(.5,.01,'Blue: observed anchor/interval; gold: published PBPK prediction. R = 1.10 is diagnostic.',ha='center',fontsize=9)
    fig.tight_layout(rect=(0,.045,1,1));fig.savefig(figs/'03-sensitivity.png');plt.close(fig)
    env={'python':platform.python_version(),'numpy':np.__version__,'scipy':scipy.__version__,'matplotlib':matplotlib.__version__}
    (ROOT/'outputs/environment.json').write_text(json.dumps(env,indent=2)+'\n',encoding='utf8')
    (ROOT/'outputs/verification.json').write_text(json.dumps({'anchor_calibration_not_validation':True,'maximum_anchor_error':max(abs(row['R_at_0']-2.7) for row in rows),'sensitivity_rows':len(sens),'clinical_transition_validation':False,'full_PBPK_reconstructed':False},indent=2)+'\n',encoding='utf8')
    print(json.dumps(rows,indent=2));print('Sensitivity rows:',len(sens))

if __name__=='__main__':main()
