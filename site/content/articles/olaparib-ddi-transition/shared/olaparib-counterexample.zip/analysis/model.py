"""Structural DDI counterexample. Not PBPK or clinical exposure prediction."""
import numpy as np

def initial_inhibition(f: float, anchor: float) -> float:
    if not 0 < f <= 1 or anchor <= 1:
        raise ValueError('Require 0 < f <= 1 and anchor > 1')
    suppression = 1 - 1 / anchor
    if f <= suppression:
        raise ValueError('The anchor cannot be reached at finite positive inhibition')
    return suppression / (f - suppression)

def ratio(n, f: float, anchor: float = 2.7):
    n = np.asarray(n, dtype=float)
    if np.any(n < 0):
        raise ValueError('Only post-cessation times are defined')
    x = initial_inhibition(f, anchor) * np.exp2(-n)
    return 1 / (1 - f + f / (1 + x))

def crossing(f: float, anchor: float, threshold: float) -> float:
    if not 1 < threshold < anchor:
        raise ValueError('Require 1 < threshold < anchor')
    s = 1 - 1 / threshold
    x_threshold = s / (f - s)
    return float(np.log2(initial_inhibition(f, anchor) / x_threshold))

def dose_index(n, f: float, restore: float, anchor: float = 2.7):
    """A quasi-static algebraic index, not interval AUC or concentration."""
    n = np.asarray(n, dtype=float)
    if restore < 0:
        raise ValueError('Negative restoration time')
    fraction = np.where(n < restore, 1 / 3, 1.0)
    return fraction * ratio(n, f, anchor)
