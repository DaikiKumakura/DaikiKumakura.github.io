import unittest
import numpy as np
from scipy.integrate import solve_ivp
from scipy.optimize import brentq
from model import initial_inhibition, ratio, crossing, dose_index

class CounterexampleTests(unittest.TestCase):
    def test_anchor_and_asymptote(self):
        for f in [.75,.85,.95]:
            self.assertAlmostEqual(float(ratio(0,f)),2.7,places=12)
            self.assertAlmostEqual(float(ratio(100,f)),1,places=12)

    def test_independent_ode_decay(self):
        for f in [.75,.85,.95]:
            n=np.linspace(0,10,101)
            sol=solve_ivp(lambda t,y:-np.log(2)*y,(0,10),[initial_inhibition(f,2.7)],t_eval=n,rtol=1e-11,atol=1e-13)
            np.testing.assert_allclose(1/(1-f+f/(1+sol.y[0])),ratio(n,f),rtol=1e-10)

    def test_crossing_with_independent_root(self):
        for f in [.75,.85,.95]:
            for a in [2.44,2.7,2.97,3.55]:
                for threshold in [1.05,1.1,1.25]:
                    root=brentq(lambda n:float(ratio(n,f,a))-threshold,0,20)
                    self.assertAlmostEqual(root,crossing(f,a,threshold),places=10)

    def test_monotonic_and_distinct(self):
        for f in [.75,.85,.95]: self.assertTrue(np.all(np.diff(ratio(np.linspace(0,10,1001),f))<0))
        self.assertGreater(float(ratio(3,.75)),float(ratio(3,.95)))

    def test_input_domain(self):
        for f,a in [(0,2.7),(.5,2.7),(1.1,2.7),(.9,1)]:
            with self.assertRaises(ValueError): initial_inhibition(f,a)
        with self.assertRaises(ValueError): ratio(-1,.85)
        with self.assertRaises(ValueError): crossing(.85,2.7,1)

    def test_dose_index_is_algebraic(self):
        n=np.array([2.9,3,4])
        np.testing.assert_allclose(dose_index(n,.85,3),ratio(n,.85)*np.array([1/3,1,1]))
        self.assertAlmostEqual(float(dose_index(0,.85,3)),.9,places=12)

if __name__=='__main__': unittest.main()
