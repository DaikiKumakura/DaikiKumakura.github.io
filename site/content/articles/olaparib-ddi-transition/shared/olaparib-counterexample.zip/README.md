# Olaparib DDI transition: a structural counterexample

Independent algebraic example, not PBPK, PopPK, clinical AUC or concentration
prediction. The scalar 2.70 anchor is the observed 100 mg single-dose tablet
DDI reported in Pilla Reddy et al. (2019), DOI 10.1002/cpt.1103, Table 2.
Matching that value is calibration, not validation of a washout trajectory.
f values and effect-site half-lives are analyst assumptions, not estimates.
R is a frozen-condition disposition ratio; B=dose fraction*R is an algebraic
index, not time-integrated exposure. Hypothetical timing and diagnostic
thresholds are not dose advice, clinical limits, or label verification.
Original full PBPK reconstruction and resumption prediction were not achieved.

Use versions in outputs/environment.json (Python and requirements.txt).
Run python analysis/run_analysis.py to regenerate tables and figures.
Run python -m unittest discover -s analysis -q for independent checks.
Official-label arithmetic and conditional model outputs are separate tables.
No raw source documents, patient data, or reproduced source figures included.
Do not use this example for treatment or trial dose selection.
