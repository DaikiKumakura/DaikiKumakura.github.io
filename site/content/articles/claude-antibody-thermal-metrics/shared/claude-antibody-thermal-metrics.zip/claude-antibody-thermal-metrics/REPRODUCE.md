# Reproduce the synthetic example

Python 3.12.4 was used. Install `requirements.txt`, then run `python analysis.py`. The script writes results/ and figures/. Inputs are fixed synthetic constants, not experimental data. No random numbers are used.

Original article code and generated illustrations: copyright Daiki Kumakura, 2026. Released under the MIT license in LICENSE. Third-party data and figures are not included.
