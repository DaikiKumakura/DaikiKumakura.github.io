"""Synthetic fast-equilibrium unfolding coupled to irreversible aggregation.

This is not a fit to BigHat measurements and does not simulate a DSF ratio.
Run from any directory: python analysis.py
"""
from pathlib import Path
import csv, json, platform
import numpy as np
import scipy
from scipy.integrate import solve_ivp
from scipy.optimize import brentq
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

HERE = Path(__file__).resolve().parent
OUT = HERE/'results'
FIG = HERE/'figures'
VARIANTS = {'A': {'tm': 65., 'k65': .003}, 'B': {'tm': 69., 'k65': .08}}

def unfolded(temp, tm):
    return 1/(1+np.exp(-(np.asarray(temp)-tm)/2.))

def simulate(variant, concentration=1., ramp=1., rtol=1e-10):
    p=VARIANTS[variant]
    # A is fraction of initial monomer units irreversibly lost; concentration
    # is a dimensionless multiple of a reference concentration.
    def rhs(temp, state):
        a=state[0]
        return [p['k65']*np.exp((temp-65.)/5.)*concentration*
                float(unfolded(temp,p['tm']))**2*(1-a)**2/ramp]
    sol=solve_ivp(rhs,(25.,85.),[0.],dense_output=True,rtol=rtol,atol=rtol/100,max_step=.1)
    assert sol.success
    def native(t): return (1-sol.sol(t)[0])*(1-unfolded(t,p['tm']))
    crossing=brentq(lambda t:float(native(t))-.5,25.,85.)
    grid=np.linspace(25.,85.,1201)
    agg=sol.sol(grid)[0];u=unfolded(grid,p['tm'])
    assert np.all((agg>=-1e-12)&(agg<=1+1e-12))
    assert np.max(np.abs((1-agg)*(1-u)+(1-agg)*u+agg-1))<1e-12
    return crossing, grid, native(grid), agg

def main():
    OUT.mkdir(exist_ok=True);FIG.mkdir(exist_ok=True)
    rows=[]
    for concentration in [1.,5.]:
        for ramp in [.5,2.]:
            for variant in VARIANTS:
                crossing,*_=simulate(variant,concentration,ramp)
                rows.append(dict(variant=variant,concentration_multiple=concentration,
                                 ramp_C_per_min=ramp,equilibrium_midpoint_C=VARIANTS[variant]['tm'],
                                 native_half_temperature_C=round(crossing,6)))
    with (OUT/'summary.csv').open('w',newline='',encoding='utf-8') as f:
        writer=csv.DictWriter(f,fieldnames=list(rows[0]));writer.writeheader();writer.writerows(rows)
    fig,axs=plt.subplots(1,2,figsize=(10,4),layout='constrained')
    for variant,color in [('A','#226c8c'),('B','#b15432')]:
        for c,ls in [(1.,'-'),(5.,'--')]:
            _,t,n,a=simulate(variant,c,.5)
            axs[0].plot(t,n,color=color,ls=ls,label=f'{variant}; c/c0={c:g}')
            axs[1].plot(t,a,color=color,ls=ls,label=f'{variant}; c/c0={c:g}')
    axs[0].set(ylabel='Native monomer fraction',xlabel='Temperature (°C)',xlim=(50,78),ylim=(0,1))
    axs[1].set(ylabel='Irreversibly lost fraction',xlabel='Temperature (°C)',xlim=(50,78),ylim=(0,1))
    axs[0].axhline(.5,color='.65',lw=.8);axs[0].legend(frameon=False)
    fig.suptitle('Synthetic illustration; heating at 0.5 °C/min')
    fig.savefig(FIG/'thermal-aggregation.png',dpi=180);plt.close(fig)
    delta=max(abs(simulate(v,c,r)[0]-simulate(v,c,r,1e-8)[0]) for v in VARIANTS for c in [1.,5.] for r in [.5,2.])
    (OUT/'checks.json').write_text(json.dumps({'synthetic':True,'maximum_tolerance_change_C':delta,
        'mass_balance':'passed','python':platform.python_version(),'numpy':np.__version__,
        'scipy':scipy.__version__,'matplotlib':matplotlib.__version__},indent=2)+'\n',encoding='utf-8')
    print(json.dumps(rows,indent=2))

if __name__=='__main__':main()
