from math import exp

def rhs(y,h,feed,mu,f):
    n,r,m=y
    p=r/(r+m+h)
    growth=.5*r*n*p
    detox=.5*r*n*(1-p)
    capacity=1+19*exp(-f*m)
    return (mu*growth*(1-n/capacity)-.1*n,
            feed-growth-detox,
            .1*r*n-.4*m*n*(1-p))

def path(y,params):
    f=lambda y: rhs(y,*params)
    def step(y,k,s): return tuple(a+s*b for a,b in zip(y,k))
    out=[y]
    for _ in range(2000):
        a=f(y); b=f(step(y,a,.005)); c=f(step(y,b,.005)); d=f(step(y,c,.01))
        y=tuple(x+.01*(i+2*j+2*k+l)/6 for x,i,j,k,l in zip(y,a,b,c,d))
        out.append(y)
    return out

x=path((.2,2,.4),(1,1,1,.5))
y=path((.2,6,1.2),(3,3,1/3,1/6))
errors=[max(abs(b[i]-(1 if i==0 else 3)*a[i]) for a,b in zip(x,y)) for i in range(3)]
assert max(errors)<1e-11
print("Maximum discrepancies N, R', M':",errors)
print("Final states:",x[-1],y[-1])
