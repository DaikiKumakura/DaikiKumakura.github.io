# Mithril Medicine 買収 リサーチノート（アクセス日: 2026-10-30）

凡例: P=一次, S=二次。引用は短縮。

## A. 買収の事実
1. 発表日 2026-10-27。Anthropic が Mithril Medicine（従業員1名、希少筋ジストロフィー2病型）を買収と発表。[P] https://www.anthropic.com/research/early-progress-drug-development （同ページは6組織との共同研究も記載: BigHat, BMS, Divergence Labs, Enveda, Generate Biomedicines, The Column Group）。runtimewire(S)も10/27付で一致 https://runtimewire.com/article/anthropic-acquires-mithril-medicine-cody-tranbarger
2. 創業者 Cody Tranbarger は現在 Anthropic 所属で研究継続。[P] 同上Anthropic記事／技術報告書の所属欄。
3. 取引条件（価格・株式等）: **非開示**（Anthropic記事・runtimewire・Neuron記事とも記載なし）。
4. 取引時期「2026年7月」: Neuron記事(S) https://theneuron.ai/news/inside-mithril-one-employee-biotech-anthropic-acquired は7月とするが、Anthropic記事・技術報告書(grep)・runtimewireに記載なし。**一次で未確認**。Atlas Venture出資の記述もNeuronのみ（一次で未確認、runtimewireは投資家に言及なし）。

## B. Mithril の資産・段階・主張タイムライン
5. 段階: 前臨床（Anthropic記事で「mostly preclinical」旨）。[P]
6. 資産: LAMA2関連先天性筋ジストロフィー(LAMA2-CMD)とα-ジストログリカノパチー向け、laminin-α4とα-ジストログリカンを橋渡しする二重特異性抗体。技術報告書は査読前、2026-10-26付。[P] https://www-cdn.anthropic.com/52e1f5d50c47ca3818f56704c27cf19e59b62e77.pdf （Anthropic記事本文は病型・標的名を明記せず、報告書で確認）
7. 主張タイムライン: 「アイデアからマウスでの有望な結果まで18か月未満」。[P] Anthropic記事。臨床試験開始は「早ければ2020年代の終わり近く」（候補が持ちこたえる場合の条件付き予測）。[P] 同記事。
8. マウスデータ（dyWマウス、パイロット）: 2+2 IgG-scFvで最大力1.95倍(95%CI 1.51-2.51; n=7 vs 4)、握力(体重当たり)1.94倍。ただし litter単位の正確順位検定は P=0.057、マウス単位Welch検定 P=0.0001(未調整)。[P] 技術報告書 Fig.11/本文。
9. 報告書自身の限界: 群は順次登録、litter単位で1処置・無作為化なし、vehicleは別レジメン、6群・11以上のエンドポイントで偶然の可能性、2+2の筋内曝露は未測定、盲検・同時対照での再現が必要。[P] 同報告書 Limitations。
10. 試験分子は「公開されている可変領域に基づく2つのツール分子」であり、新規最適化候補は113構築体パネルの評価段階。[P] 同報告書。つまり「IND候補」ではない。
11. 外部ラボ11か所をClaudeで調整（契約・ロジスティクス・実験）。[P] Anthropic記事。

## C. プロセス: AI対人間（報告書 "Working with Claude", Fig.12, 1週間の事例）[P]
- 341ページの製造データを Claude が読み、113構築体の視覚的要約を7分53秒で作成（最初の回答2分40秒）。Claude: 82を現状のままスクリーニング、7を追加精製、24を保留と提案。
- 人間が113→89構築体への絞り込みを決定（Claudeの全件速度論提案を却下）。Claudeは約4分で文書・日程・下書きを修正。
- メール: Claude起案17通、人間が編集して12通送信。Claudeは自分では送信せず。41点を「書面に根拠なし」と列挙。
- エラー: 詳細検討6件。Claudeが自力発見5件。うち少なくとも3件は人間が編集・送信したメールにも到達、1件は材料量の誤り（充填前に訂正）、2件は4日超未発見、1件未解決。
- 速度は応答中央値: Claude 96秒/10分、CRO 8.5時間。判断は人間に残ると報告書自身が記述。
- 注意: これは事前選択された1週間の事例。Neuronは「有利な週」と評するが、報告書自体にその旨の語があるかは未確認（S）。確認時間の総コストは未計測と同記事(S)。
- 臨床試験・IND提出・コストに関する数値は報告書・記事にいずれも**見当たらず**（費用: 非開示）。

## D. 公開ベンチマーク（前臨床→IND）
12. Insilico Medicine（自社報告、プレス発表2025-02-11）: 22件の開発候補(DC)指名(2021-24)、プロジェクト開始→DC まで平均約12-18か月/最短9か月/最長18か月、合成60-200分子。比較として従来2.5-4年（出典なし）。DCからINDまでの期間は報告なし。中央値報告なし。[S, 企業の自己申告] https://www.eurekalert.org/news-releases/1073344 , https://www.brightsurf.com/news/8X5QVXE1/insilico-medicine-announces-developmental-candidate-benchmarks-and-timelines-for-novel-therapeutics-discovered-using-generative-ai.html （注意: 2サイトで「average約13か月」と「12-18か月」の表現差あり）
13. Tufts CSDD: 初回合成→初回投与(FIH)まで中央値133週(IQR 89.6週)、平均151.4週(n=17)。[S, 検索スニペット経由、原典未確認] https://fdanews.com/articles/185903-clinical-trial-startup-process-takes-longer-than-10-years-ago-tufts-csdd-reports に対応か（URL対応は未確認）。
14. Evotec（ベンダー）: 規制毒性試験開始まで約$75M(失敗分含む)、標的→IND約5.5年。[S, ベンダー自己申告, ページは今回404で再取得不可] https://www.evotec.com/sciencepool/reaching-ind-stage-how-to-achieve-this-key-corporate-milestone-fast
15. ContractPharma: mAbのIND向けCMCのみ約$6.8M（年不明）。[S, CMC限定] https://www.contractpharma.com/?p=10239
16. WuXi AppTec: 候補選択→IND準備8-12週（ベンダーのマーケティング、裏付けなし）。[S] https://sta.wuxiapptec.com/resources/from-candidate-selection-to-ind-ready-in-8-12-weeks/

## E. 未検証・矛盾・注意
- FDA公式ガイダンスや業界調査（Paul et al. 2010, BIO等）の数値は今回取得できず（Natureは認証リダイレクト）。**ベンチマークの一次数値は未取得**。次の一手: Paul 2010 (Nat Rev Drug Discov)、FDA ICH S6(R1)/M3(R2)、Tufts原典を直接確認。
- 取引時期（7月）とAtlas Venture出資はNeuronのみ。他資料（runtimewire等）にない。
- 「18か月未満」は「アイデア→マウスの有望結果」であり、IND-enabling試験完了ではない。Insilicoの「DC到達」とも定義が異なるため直接比較不可。
- マウス結果は P=0.057(litter) と P=0.0001(mouse) で統計的結論が分かれる。
- 検索要約ツール経由の抽出が多く、Anthropic記事本文は全文を直接読んでいない（要点のみ）。技術報告書はpdftotextで原文確認。


## 追記（2026-10-30、記事の修正時）
- Anthropicの記事は、取得ツールの要約で再確認した（全文通読ではない）。確認した点：発表日、1人の会社、価格の非開示、「18か月未満」、11の外部の研究機関との調整、ヒト試験は「早ければ2028年末」という条件つきの見通し。
- 技術報告書（PDF原文）で確認した点：誤り6件を詳しく調べ、Claudeが5件を発見（1件はCROの質問後、2件はメール送信前）。少なくとも3件は人間が編集して送ったメールでCROに届き、うち1件は1日以内に訂正、2件は4日超見逃され1件が未解決。限界の節に「litter平均でP = 0.057、litter 7つで取りうる最小値」とある。
