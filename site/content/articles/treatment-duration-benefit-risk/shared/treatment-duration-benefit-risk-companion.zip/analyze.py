from pathlib import Path
import xml.etree.ElementTree as E
import re,json,math,csv
import numpy as np
import matplotlib;matplotlib.use('Agg')
import matplotlib.pyplot as plt
R=Path(__file__).resolve().parent
for name in ['results','figures']:(R/name).mkdir(exist_ok=True)
x=E.parse(R/'raw/scot-2018.xml');table=x.find('.//table-wrap[@id="tbl2"]');rows=table.findall('.//tbody/tr')
row=next(r for r in rows if ''.join(r.find('td').itertext()).strip()=='Sensory neuropathy')
cells=[''.join(c.itertext()).strip() for c in row.findall('td')];counts=[int(re.match(r'\d+',c).group()) for c in cells[1:13]]
assert counts==[37,365,18,0,0,14,28,314,65,2,0,25],counts
text=' '.join(x.getroot().itertext());assert '103 [25%] of 420' in text and '237 [58%] of 409' in text
source={'trial':'SCOT','randomized_per_arm':3044,'DFS_ITT_3':3035,'DFS_ITT_6':3030,'DFS_3y_3':.767,'DFS_3y_6':.771,'DFS_difference_3_minus_6':-.004,'DFS_diff_lower':-.026,'DFS_diff_upper':.018,'DFS_HR':1.006,'DFS_HR_lower':.909,'DFS_HR_upper':1.114,'NI_margin':1.13,'safety_cohort_per_arm':434,'neuro_G2_3':103,'neuro_G2_6':237,'neuro_obs_3':420,'neuro_obs_6':409,'neuro_G3_3':sum(counts[2:5]),'neuro_G3_6':sum(counts[8:11]),'missing_3':counts[5],'missing_6':counts[11]}
(R/'results/extracted-inputs.json').write_text(json.dumps(source,indent=2))
def wilson(k,n):
 p=k/n;z=1.959963984540054;d=1+z*z/n;c=(p+z*z/(2*n))/d;h=z*math.sqrt(p*(1-p)/n+z*z/(4*n*n))/d;return c-h,c+h
def difference(k6,n6,k3,n3):
 p6=k6/n6;p3=k3/n3;l6,u6=wilson(k6,n6);l3,u3=wilson(k3,n3);d=p6-p3
 return {'risk_3':p3,'risk_6':p6,'reduction_with_3':d,'lower':d-math.sqrt((p6-l6)**2+(u3-p3)**2),'upper':d+math.sqrt((u6-p6)**2+(p3-l3)**2)}
g2=difference(237,409,103,420);g3=difference(source['neuro_G3_6'],409,source['neuro_G3_3'],420)
bounds={'lower':237/434-(103+14)/434,'upper':(237+25)/434-103/434}
out={'grade_ge_2':g2,'grade_ge_3':g3,'missing_grade_bounds':bounds,'hypothetical_preference_threshold_point':.004/g2['reduction_with_3'],'hypothetical_threshold_worst_reported_DFS_loss':.026/g2['reduction_with_3'],'limitations':['Aggregate data only','Different efficacy and safety populations','No joint survival–toxicity data','No clinical utility qualification']}
(R/'results/analysis.json').write_text(json.dumps(out,indent=2))
plt.rcParams.update({'font.size':11,'axes.spines.top':False,'axes.spines.right':False})
fig,ax=plt.subplots(1,2,figsize=(10,4));ax[0].errorbar([-.4],[0],xerr=[[2.2],[2.2]],fmt='o',color='#246b80',capsize=4);ax[0].axvline(0,color='grey',ls='--');ax[0].set(xlabel='Three-year DFS difference: 3 − 6 months\n(percentage points)',yticks=[],title='Published survival estimate');ax[0].set_xlim(-3.5,3)
for i,(label,result) in enumerate([('Grade ≥2',g2),('Grade ≥3',g3)]):
 d=result['reduction_with_3'];ax[1].errorbar([100*d],[i],xerr=[[100*(d-result['lower'])],[100*(result['upper']-d)]],fmt='o',color='#246b80',capsize=4)
ax[1].axvline(0,color='grey',ls='--');ax[1].set(xlabel='Neuropathy reduction: 6 − 3 months\n(percentage points)',yticks=[0,1],yticklabels=['Grade ≥2','Grade ≥3'],title='Observed safety subset: 420 vs 409');fig.tight_layout();fig.savefig(R/'figures/benefit-risk-evidence.png',dpi=180);plt.close(fig)
fig,ax=plt.subplots(figsize=(7,3));ax.errorbar([1.006],[0],xerr=[[1.006-.909],[1.114-1.006]],fmt='o',color='#246b80',capsize=4);ax.axvline(1,color='grey',ls='--',label='HR = 1');ax.axvline(1.13,color='#9c553d',label='Trial noninferiority margin');ax.set(xlim=(.85,1.18),yticks=[],xlabel='Adjusted DFS HR: 3 vs 6 months',title='Noninferiority does not establish equivalence');ax.legend(loc='upper left',fontsize=9);fig.tight_layout();fig.savefig(R/'figures/noninferiority-margin.png',dpi=180);plt.close(fig)
fig,ax=plt.subplots(figsize=(7,3.5));names=['Observed complete cases','Missing-grade worst-case bounds'];ds=[g2['reduction_with_3'],sum(bounds.values())/2];lo=[g2['lower'],bounds['lower']];hi=[g2['upper'],bounds['upper']]
for i in range(2):ax.errorbar([100*ds[i]],[i],xerr=[[100*(ds[i]-lo[i])],[100*(hi[i]-ds[i])]],fmt='o',capsize=4,color='#246b80')
ax.set(yticks=[0,1],yticklabels=names,xlabel='Grade ≥2 neuropathy reduction (percentage points)',title='Missingness sensitivity within the safety cohort');ax.axvline(0,color='grey',ls='--');fig.tight_layout();fig.savefig(R/'figures/missingness-bounds.png',dpi=180);plt.close(fig)
print(json.dumps(out,indent=2))
