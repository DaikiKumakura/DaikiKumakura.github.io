from pathlib import Path
import urllib.request,json,hashlib
R=Path(__file__).resolve().parent;raw=R/'raw';raw.mkdir(parents=True,exist_ok=True)
url='https://www.ebi.ac.uk/europepmc/webservices/rest/PMC5883334/fullTextXML';p=raw/'scot-2018.xml'
if not p.exists():p.write_bytes(urllib.request.urlopen(url,timeout=60).read())
sha=hashlib.sha256(p.read_bytes()).hexdigest();m=raw/'source-manifest.json'
if m.exists():assert json.loads(m.read_text())['sha256']==sha,'Source changed: inspect before replacing pinned data'
m.write_text(json.dumps({'url':url,'sha256':sha,'license':'CC BY 4.0 as declared in article','doi':'10.1016/S1470-2045(18)30093-7'},indent=2),encoding='utf-8')
print('Official open-access trial XML acquired and hashed')

url2="https://www.ebi.ac.uk/europepmc/webservices/rest/PMC12931879/fullTextXML";p2=raw/"scot-2026.xml"
if not p2.exists():p2.write_bytes(urllib.request.urlopen(url2,timeout=60).read())
sha2=hashlib.sha256(p2.read_bytes()).hexdigest();m2=raw/"source-2026-manifest.json"
if m2.exists():assert json.loads(m2.read_text())["sha256"]==sha2
m2.write_text(json.dumps({"url":url2,"doi":"10.1200/JCO-25-00621","sha256":sha2,"discrepancy":"Abstract lower overall OS HR limit 0.8; main text 0.86; no correction invented"},indent=2))
