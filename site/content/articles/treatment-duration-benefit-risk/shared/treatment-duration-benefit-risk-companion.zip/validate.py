from pathlib import Path
import json,hashlib,math,xml.etree.ElementTree as E,re
R=Path(__file__).resolve().parent;s=json.loads((R/'results/extracted-inputs.json').read_text());a=json.loads((R/'results/analysis.json').read_text())
assert s['neuro_obs_3']+s['missing_3']==434 and s['neuro_obs_6']+s['missing_6']==434
assert s['neuro_G3_3']==18 and s['neuro_G3_6']==67
for grade in [2,3]:
 expected=s['neuro_G'+str(grade)+'_6']/s['neuro_obs_6']-s['neuro_G'+str(grade)+'_3']/s['neuro_obs_3'];assert abs(expected-a['grade_ge_'+str(grade)]['reduction_with_3'])<1e-12
assert abs(a['missing_grade_bounds']['lower']-120/434)<1e-12 and abs(a['missing_grade_bounds']['upper']-159/434)<1e-12
assert s['DFS_HR_upper']<s['NI_margin'] and s['DFS_diff_lower']<0<s['DFS_diff_upper']
assert abs((s['DFS_3y_3']-s['DFS_3y_6'])-s['DFS_difference_3_minus_6'])<1e-12
for name in ['source-manifest.json','source-2026-manifest.json']:
 manifest=json.loads((R/'raw'/name).read_text());file='scot-2018.xml' if name=='source-manifest.json' else 'scot-2026.xml';assert hashlib.sha256((R/'raw'/file).read_bytes()).hexdigest()==manifest['sha256']
summary={'status':'passed','checks':['original table extraction','endpoint-specific denominators','risk difference arithmetic','missingness identification bounds','source SHA-256'],'scope':'Aggregate evidence analysis; joint utility not qualified'}
(R/'results/validation.json').write_text(json.dumps(summary,indent=2));print(json.dumps(summary,indent=2))
