"""Checks of the PDS and alignment implementation on synthetic data."""
import numpy as np

import analysis as A


def test_identity_prediction_scores_one():
    rng = np.random.default_rng(0)
    real = rng.normal(size=(20, 300))
    v = A.midrank_pds(1 - A.cosine_matrix(real, real))
    assert np.allclose(v, 1.0)


def test_all_tied_scores_half():
    assert np.allclose(A.midrank_pds(np.ones((12, 12))), 0.5)


def test_zero_norm_rows_give_cosine_zero():
    c = A.cosine_matrix(np.zeros((2, 5)), np.ones((3, 5)))
    assert np.all(c == 0)


def test_panel_exclusion_removes_own_target_signal():
    rng = np.random.default_rng(1)
    n, d = 15, 120
    real = rng.normal(0, 0.1, (n, d))
    tc = np.arange(n)
    real[np.arange(n), tc] = 5.0                      # a strong own-target effect
    pred = np.zeros((n, d))
    pred[np.arange(n), tc] = 1.0                      # predict only the target gene
    assert A.pds(pred, real, "none", tc).mean() > 0.95
    assert abs(A.pds(pred, real, "panel", tc).mean() - 0.5) < 1e-9
    assert abs(A.pds(pred, real, "row", list(tc)).mean() - 0.5) < 1e-9


def test_pds_more_forgiving_than_alignment():
    rng = np.random.default_rng(2)
    n, d = 60, 4000
    base = rng.normal(size=(n, d))
    pred = base + rng.normal(0, 12, (n, d))           # heavy noise: cosine with truth is small
    a = A.alignment(pred, base, np.array([], dtype=int), "none").mean()
    v = A.pds(pred, base, "none", np.array([], dtype=int)).mean()
    assert a < 0.15 and v > 0.85


def test_midrank_counts_ties_halfway():
    d = np.array([[0.2, 0.2, 0.9], [0.5, 0.1, 0.7], [0.3, 0.3, 0.3]])
    v = A.midrank_pds(d)
    assert abs(v[0] - (1 - 0.5 / 2)) < 1e-12 and v[1] == 1.0 and abs(v[2] - 0.5) < 1e-12


if __name__ == "__main__":
    for name, fn in list(globals().items()):
        if name.startswith("test_"):
            fn()
    print("all tests passed")
