"""Discrimination (PDS) versus alignment (cosine) on public single-gene perturbation data (Norman et al. 2019).

PDS follows the cell-eval2 'vcc2026' definition: cosine distance between the predicted and the real signed
effect (perturbation mean minus control mean, log1p CP10k); for each perturbation the rank of its own real effect
among all n real effects; score = 1 - rank / (n - 1); ties take the mid-rank. Target-gene exclusion has three
scopes: 'panel' (every panel target gene removed once; the competition default), 'row' (only the row's own target
removed; the legacy rule) and 'none'. Alignment is the cosine between predicted and real effect for the same
perturbation, over the genes left after panel exclusion.
"""
from pathlib import Path
import json

import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parent
OUT = ROOT / "results"
OUT.mkdir(exist_ok=True)
SEED = 20261030
KS = [1, 2, 3, 5, 10, 20, 40, 60]


def cosine_matrix(a, b):
    na = np.linalg.norm(a, axis=1, keepdims=True)
    nb = np.linalg.norm(b, axis=1, keepdims=True)
    dots = a @ b.T
    with np.errstate(invalid="ignore", divide="ignore"):
        c = dots / (na * nb.T)
    return np.where((na == 0) | (nb.T == 0), 0.0, c)


def midrank_pds(dist):
    """dist[i, j]: distance of prediction i to real j. PDS_i = 1 - midrank(d_ii) / (n - 1)."""
    n = dist.shape[0]
    d_self = np.diag(dist)
    less = (dist < d_self[:, None] - 1e-12).sum(axis=1)
    tied = (np.abs(dist - d_self[:, None]) <= 1e-12).sum(axis=1)          # includes the row itself
    rank = less + (tied - 1) / 2
    return 1 - rank / (n - 1)


def pds(pred, real, scope, target_cols):
    n = pred.shape[0]
    if scope == "panel":
        keep = np.ones(pred.shape[1], bool)
        keep[target_cols] = False
        return midrank_pds(1 - cosine_matrix(pred[:, keep], real[:, keep]))
    if scope == "none":
        return midrank_pds(1 - cosine_matrix(pred, real))
    if scope == "row":
        d = np.zeros((n, n))
        for i in range(n):
            keep = np.ones(pred.shape[1], bool)
            keep[target_cols[i]] = False
            d[i] = 1 - cosine_matrix(pred[i:i + 1, keep], real[:, keep])[0]
        return midrank_pds(d)
    raise ValueError(scope)


def alignment(pred, real, target_cols, scope="panel"):
    keep = np.ones(pred.shape[1], bool)
    if scope == "panel":
        keep[target_cols] = False
    p, r = pred[:, keep], real[:, keep]
    num = (p * r).sum(1)
    den = np.linalg.norm(p, axis=1) * np.linalg.norm(r, axis=1)
    return np.where(den == 0, 0.0, num / np.where(den == 0, 1, den))


def boot_ci(x, rng, n=2000):
    x = np.asarray(x)
    m = [x[rng.integers(0, len(x), len(x))].mean() for _ in range(n)]
    return float(np.quantile(m, 0.025)), float(np.quantile(m, 0.975))


def main():
    z = np.load(ROOT / "cache/norman-pseudobulk.npz", allow_pickle=True)
    names, genes = list(z["names"]), list(z["genes"])
    ctrl, h2, h1 = z["ctrl_mean"], z["h2_mean"], z["h1_full"]
    cells, counts = z["cells"].astype(np.float64), z["cell_counts"]
    n, d = len(names), len(genes)
    gi = {g: i for i, g in enumerate(genes)}
    target_cols = np.array([gi[p] for p in names])
    real = h2 - ctrl
    ref = h1 - ctrl
    rng = np.random.default_rng(SEED)
    offsets = np.r_[0, np.cumsum(counts)[:-1]]

    preds = {}
    preds["control (zero effect)"] = np.zeros((n, d))
    others = ref.sum(axis=0, keepdims=True) - ref
    preds["average effect of the other perturbations"] = others / (n - 1)
    spike = np.zeros((n, d))
    spike[:, target_cols] = -1.0           # CRISPRa raises the target: the content-free spike goes the other way
    preds["content-free: -1 on every panel target gene"] = spike
    own = np.zeros((n, d))
    own[np.arange(n), target_cols] = 1.0
    preds["own target gene only"] = own
    preds["half-1 cells, all (replicate)"] = ref
    rows, per_pert = [], {}
    for name, pr in preds.items():
        for scope in ("none", "row", "panel"):
            v = pds(pr, real, scope, target_cols if scope != "row" else list(target_cols))
            per_pert[(name, scope)] = v
            a = alignment(pr, real, target_cols, "panel")
            lo, hi = boot_ci(v, rng)
            alo, ahi = boot_ci(a, rng)
            rows.append(dict(prediction=name, exclusion=scope, pds=float(v.mean()), pds_lo=lo, pds_hi=hi, alignment=float(a.mean()),
                             alignment_lo=alo, alignment_hi=ahi))
    summary = pd.DataFrame(rows)
    summary.round(5).to_csv(OUT / "predictions-summary.csv", index=False, lineterminator="\n")

    # replicate predictions built from k cells of half 1
    curve = []
    for k in KS:
        pr = np.vstack([cells[o:o + min(k, c)].mean(axis=0) for o, c in zip(offsets, counts)]) - ctrl
        for scope in ("none", "row", "panel"):
            v = pds(pr, real, scope, target_cols if scope != "row" else list(target_cols))
            a = alignment(pr, real, target_cols, "panel")
            vlo, vhi = boot_ci(v, rng)
            alo, ahi = boot_ci(a, rng)
            keep_p = np.ones(d, bool)
            keep_p[target_cols] = False
            cm = cosine_matrix(pr[:, keep_p], real[:, keep_p])
            offd = cm[~np.eye(n, dtype=bool)]
            curve.append(dict(cells_per_prediction=k, exclusion=scope, pds=float(v.mean()), alignment=float(a.mean()),
                              pds_lo=vlo, pds_hi=vhi, alignment_lo=alo, alignment_hi=ahi,
                              wrong_candidate_cosine_mean=float(offd.mean()), wrong_candidate_cosine_p95=float(np.quantile(offd, 0.95))))
    curve.append(dict(cells_per_prediction=int(np.mean(z["n_h1"])), exclusion="panel", pds=float(per_pert[("half-1 cells, all (replicate)", "panel")].mean()),
                      alignment=float(alignment(ref, real, target_cols).mean()), pds_lo=np.nan, pds_hi=np.nan, alignment_lo=np.nan, alignment_hi=np.nan,
                      wrong_candidate_cosine_mean=float(cosine_matrix(ref[:, ~np.isin(np.arange(d), target_cols)], real[:, ~np.isin(np.arange(d), target_cols)])[~np.eye(n, dtype=bool)].mean()),
                      wrong_candidate_cosine_p95=np.nan))
    curve = pd.DataFrame(curve)
    curve.round(5).to_csv(OUT / "replicate-curve.csv", index=False, lineterminator="\n")

    # small public subset for the independent R re-implementation (all perturbations; targets + 1,400 other genes)
    vrng = np.random.default_rng(SEED + 7)
    others_idx = np.setdiff1d(np.arange(d), target_cols)
    vcols = np.r_[target_cols, np.sort(vrng.choice(others_idx, 1400, replace=False))]
    vdir = ROOT / "validation-data"
    vdir.mkdir(exist_ok=True)
    for nm, mat in (("real", real), ("ref", ref)):
        pd.DataFrame(mat[:, vcols].round(6), index=names, columns=[genes[c] for c in vcols]).to_csv(vdir / f"{nm}-effects-subset.csv.gz", lineterminator=chr(10))
    vt = np.arange(len(names))                               # target columns are the first n columns of the subset
    vpreds = {"average of others": (ref[:, vcols].sum(0, keepdims=True) - ref[:, vcols]) / (n - 1), "replicate": ref[:, vcols],
              "own target only": np.eye(len(names), len(vcols))}
    vrows = []
    for nm, pr in vpreds.items():
        for scope in ("none", "row", "panel"):
            v = pds(pr, real[:, vcols], scope, vt if scope != "row" else list(vt))
            vrows.append(dict(prediction=nm, exclusion=scope, pds=float(v.mean()),
                              alignment=float(alignment(pr, real[:, vcols], vt).mean())))
    pd.DataFrame(vrows).round(6).to_csv(OUT / "validation-subset-python.csv", index=False, lineterminator=chr(10))

    # cross-perturbation cosine of real effects (what a wrong candidate scores)
    keep = np.ones(d, bool)
    keep[target_cols] = False
    cc = cosine_matrix(real[:, keep], real[:, keep])
    off = cc[~np.eye(n, dtype=bool)]
    cross = dict(median=float(np.median(off)), q05=float(np.quantile(off, 0.05)), q95=float(np.quantile(off, 0.95)), mean=float(off.mean()),
                 sd_random_cosine_expected=float(1 / np.sqrt(keep.sum())))
    summary_json = dict(n_perturbations=n, n_features=d, n_features_after_panel_exclusion=int(keep.sum()), cross_perturbation_cosine=cross,
                        replicate_alignment=float(alignment(ref, real, target_cols).mean()),
                        mean_cells_half=float(np.mean(z["n_h1"])), control_cells=int(z["n_ctrl"][0]))
    (OUT / "summary.json").write_text(json.dumps(summary_json, indent=2) + "\n", encoding="utf-8")
    pd.set_option("display.width", 200)
    print(summary.round(3).to_string())
    print(curve.round(3).to_string())
    print(json.dumps(summary_json, indent=1))


if __name__ == "__main__":
    main()
