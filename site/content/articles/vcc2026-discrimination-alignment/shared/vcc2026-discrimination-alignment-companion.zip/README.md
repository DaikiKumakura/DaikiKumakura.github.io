# VCCの識別と整合：配布資料

記事「識別0.86と整合0.08は両立しうるか：Virtual Cell Challenge参加者の振り返りを公開データで考える」の再実行用資料。

## 含むもの

- `prepare.py`：Norman 2019（scPerturb、CC BY 4.0）から、単独摂動102種の擬似バルク（半分ずつの細胞、対照、一部の細胞）を作る
- `analysis.py`：識別（PDS）と整合（コサイン）の計算。PDSの定義は、cell-eval2の `vcc2026` の設定に合わせた
- `acquire.py`, `input-provenance.json`：入力の取得とSHA-256
- `validate.R`：Rによる独立の再実装（公開の部分集合で、PDSの3つの除外規則と整合を計算）
- `test_analysis.py`, `figures.py`
- `validation-data/`：検証に使う部分集合（102摂動 × 1,502遺伝子）
- `results/`, `figures/`

入力のh5adファイル（約700 MB）は同梱しない。`acquire.py` で取得し、SHA-256で照合する。

## 実行

`validate.R` は同梱の `validation-data/` だけで実行できる。全体の再実行：`python acquire.py && python prepare.py && python test_analysis.py && python analysis.py && python figures.py && Rscript validate.R`（Python 3.12、anndata、numpy、pandas、matplotlib、requests；R 4.5.3、jsonlite。メモリは約3 GBで動くよう、行列を分割して読む）

本資料は、評価指標の振る舞いを公開データで確かめるもので、VCCの採点そのものを再現するものではない。評価指標の定義は、公式cell-evalの再実装であるcell-eval2（公式採点との一致は未確認）に合わせた。
