"""Figures from results/ (run analysis.py first)."""
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parent
R = ROOT / "results"
(ROOT / "figures").mkdir(exist_ok=True)
BLUE, ORANGE, GREEN, RED, GREY = "#0072B2", "#E69F00", "#009E73", "#D55E00", "#666666"

c = pd.read_csv(R / "replicate-curve.csv")
p = pd.read_csv(R / "predictions-summary.csv")
cp = c[c.exclusion == "panel"].sort_values("alignment")
fig, ax = plt.subplots(figsize=(7.6, 5.2), constrained_layout=True)
ax.plot(cp.alignment, cp.pds, "-o", color=BLUE, label="Prediction = mean of k real cells (same perturbation)", zorder=3)
for _, r in cp.iterrows():
    ax.annotate(f"k={int(r.cells_per_prediction)}" if r.cells_per_prediction < 100 else "all", (r.alignment, r.pds), xytext=(5, -10), textcoords="offset points", fontsize=7.5)
sel = lambda name, scope: p[(p.prediction == name) & (p.exclusion == scope)].iloc[0]
m = sel("average effect of the other perturbations", "panel")
ax.scatter(m.alignment, m.pds, color=ORANGE, s=60, zorder=4, label="Average effect of the other perturbations")
o = sel("own target gene only", "none")
ax.scatter(o.alignment, o.pds, color=RED, s=60, marker="s", zorder=4, label="Own target gene only, no gene exclusion")
o2 = sel("own target gene only", "panel")
ax.scatter(o2.alignment, o2.pds, color=RED, s=60, marker="s", facecolors="none", zorder=4, label="Same, competition rule (all target genes excluded)")
ax.scatter([0.084], [0.86], marker="*", s=170, color=GREEN, zorder=5, label="Reported by one VCC entrant (different data, not comparable)")
ax.axhline(0.5, color=GREY, linestyle=":", linewidth=1)
ax.set_xlabel("Alignment: cosine between predicted and real effect")
ax.set_ylabel("Discrimination (PDS): rank of the correct perturbation")
ax.set_xlim(-0.03, 0.85)
ax.set_ylim(0.45, 1.02)
ax.set_title("Norman 2019, 102 single-gene CRISPRa perturbations: PDS saturates before alignment does", fontsize=9)
ax.legend(fontsize=7, loc="center right")
fig.savefig(ROOT / "figures/01-pds-vs-alignment.png", dpi=150)

fig, ax = plt.subplots(figsize=(7.6, 4.0), constrained_layout=True)
names = ["own target gene only", "content-free: -1 on every panel target gene", "average effect of the other perturbations"]
labels = ["Own target gene only", "Content-free spike on\nthe other target genes", "Average effect of the\nother perturbations"]
w = 0.26
for i, (sc, col) in enumerate(zip(("none", "row", "panel"), (RED, ORANGE, BLUE))):
    v = [sel(n, sc) for n in names]
    ax.bar(np.arange(3) + (i - 1) * w, [x.pds for x in v], w, color=col, label={"none": "no exclusion", "row": "own target only excluded (legacy)", "panel": "all target genes excluded (competition)"}[sc],
           yerr=[[x.pds - x.pds_lo for x in v], [x.pds_hi - x.pds for x in v]], capsize=2)
ax.axhline(0.5, color=GREY, linestyle=":")
ax.set_xticks(range(3), labels)
ax.set_ylabel("PDS")
ax.set_ylim(0, 1.1)
ax.legend(fontsize=7.5, loc="upper right")
ax.set_title("Predictions that carry no perturbation-specific response, scored under three exclusion rules (95% bootstrap interval)", fontsize=8.5)
fig.savefig(ROOT / "figures/02-exclusion-scope.png", dpi=150)
print("figures written")
