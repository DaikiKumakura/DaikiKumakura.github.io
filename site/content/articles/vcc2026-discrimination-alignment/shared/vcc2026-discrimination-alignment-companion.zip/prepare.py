"""Prepare pseudobulk inputs from Norman et al. 2019 (single-gene CRISPRa perturbations).

For each single-gene perturbation (>= MIN_CELLS cells) cells are split at random into two halves (seed fixed).
Outputs (cache/): control mean, half-2 mean per perturbation, and up to K_MAX randomly ordered half-1 cells per
perturbation (for predictions built from few cells). Expression = log1p(CP10k) over genes detected in at least
MIN_DETECT of cells plus every panel target gene.
"""
from pathlib import Path
import json

import anndata as ad
import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parent
H5 = ROOT / "inputs/NormanWeissman2019_filtered.h5ad"
SEED = 20261030
MIN_CELLS = 60
MIN_DETECT = 0.05
K_MAX = 60
CHUNK = 500


def main():
    a = ad.read_h5ad(H5, backed="r")
    obs = a.obs[["perturbation", "nperts"]].copy()
    pert = obs.perturbation.astype(str).to_numpy()
    singles = obs[(obs.nperts == 1) & (~obs.perturbation.astype(str).str.contains("_"))].perturbation.astype(str).value_counts()
    singles = singles[singles >= MIN_CELLS]
    names = sorted(singles.index)
    genes = np.asarray(a.var_names)
    gene_idx = {g: i for i, g in enumerate(genes)}
    targets = [p for p in names if p in gene_idx]
    print("single perturbations:", len(names), "with target gene in var:", len(targets))
    names = targets
    keep = (a.var.ncells.to_numpy() >= MIN_DETECT * a.n_obs)
    for p in names:
        keep[gene_idx[p]] = True
    feat = np.flatnonzero(keep)
    print("features:", len(feat))

    rng = np.random.default_rng(SEED)
    ctrl_idx = np.flatnonzero(pert == "control")
    half1, half2, sel = {}, {}, {}
    for p in names:
        idx = np.flatnonzero(pert == p)
        idx = rng.permutation(idx)
        h = len(idx) // 2
        half1[p], half2[p] = idx[:h], idx[h:]
        sel[p] = half1[p][:K_MAX]
    all_sel = np.concatenate([sel[p] for p in names])
    sel_pos = {p: np.arange(o, o + len(sel[p])) for p, o in zip(names, np.r_[0, np.cumsum([len(sel[p]) for p in names])[:-1]])}

    totals = np.zeros(a.n_obs)
    for s in range(0, a.n_vars, 2000):
        totals += np.asarray(a.X[:, s:s + 2000].sum(axis=1)).ravel()
    scale = 1e4 / totals

    ctrl_mean = np.zeros(len(feat), dtype=np.float64)
    h2_mean = np.zeros((len(names), len(feat)), dtype=np.float64)
    h1_full = np.zeros((len(names), len(feat)), dtype=np.float64)
    cells = np.zeros((len(all_sel), len(feat)), dtype=np.float32)
    for s in range(0, len(feat), CHUNK):
        cols = feat[s:s + CHUNK]
        x = a.X[:, cols[0]:cols[-1] + 1]
        x = x.toarray()[:, cols - cols[0]] if hasattr(x, "toarray") else np.asarray(x)[:, cols - cols[0]]
        x = np.log1p(x * scale[:, None]).astype(np.float32)
        ctrl_mean[s:s + len(cols)] = x[ctrl_idx].mean(axis=0)
        for i, p in enumerate(names):
            h2_mean[i, s:s + len(cols)] = x[half2[p]].mean(axis=0)
            h1_full[i, s:s + len(cols)] = x[half1[p]].mean(axis=0)
        cells[:, s:s + len(cols)] = x[all_sel]
        print("chunk", s // CHUNK + 1, "of", -(-len(feat) // CHUNK), flush=True)
    out = ROOT / "cache"
    out.mkdir(exist_ok=True)
    cell_counts = np.array([len(sel[p]) for p in names])
    np.savez_compressed(out / "norman-pseudobulk.npz", ctrl_mean=ctrl_mean, h2_mean=h2_mean, h1_full=h1_full,
                        cells=cells, cell_counts=cell_counts, names=np.array(names), genes=genes[feat],
                        n_h1=np.array([len(half1[p]) for p in names]), n_h2=np.array([len(half2[p]) for p in names]),
                        n_ctrl=np.array([len(ctrl_idx)]))
    json.dump({"seed": SEED, "min_cells": MIN_CELLS, "min_detect": MIN_DETECT, "k_max": K_MAX, "n_perturbations": len(names),
               "n_features": int(len(feat)), "n_control_cells": int(len(ctrl_idx))}, open(out / "prepare-meta.json", "w"), indent=2)
    print("saved")


if __name__ == "__main__":
    main()
