# Independent re-implementation (base R) of PDS (three exclusion scopes) and alignment on the public subset in
# validation-data/ (all 102 perturbations; the target genes are the first 102 columns). Compares with
# results/validation-subset-python.csv and writes results/validation.json.
# Run from this folder: Rscript validate.R
real <- as.matrix(read.csv(gzfile("validation-data/real-effects-subset.csv.gz"), row.names = 1, check.names = FALSE))
ref <- as.matrix(read.csv(gzfile("validation-data/ref-effects-subset.csv.gz"), row.names = 1, check.names = FALSE))
n <- nrow(real); tc <- seq_len(n)
cosm <- function(a, b) {
  na <- sqrt(rowSums(a^2)); nb <- sqrt(rowSums(b^2))
  m <- (a %*% t(b)) / outer(na, nb)
  m[is.na(m) | is.nan(m)] <- 0
  m
}
pds_from <- function(dist) {
  s <- numeric(n)
  for (i in seq_len(n)) {
    dself <- dist[i, i]
    less <- sum(dist[i, ] < dself - 1e-12)
    tied <- sum(abs(dist[i, ] - dself) <= 1e-12)
    s[i] <- 1 - (less + (tied - 1) / 2) / (n - 1)
  }
  mean(s)
}
pds <- function(pred, scope) {
  if (scope == "none") return(pds_from(1 - cosm(pred, real)))
  if (scope == "panel") return(pds_from(1 - cosm(pred[, -tc, drop = FALSE], real[, -tc, drop = FALSE])))
  d <- matrix(0, n, n)
  for (i in seq_len(n)) d[i, ] <- 1 - cosm(pred[i, -tc[i], drop = FALSE], real[, -tc[i], drop = FALSE])[1, ]
  pds_from(d)
}
align <- function(pred) {
  p <- pred[, -tc, drop = FALSE]; r <- real[, -tc, drop = FALSE]
  v <- rowSums(p * r) / (sqrt(rowSums(p^2)) * sqrt(rowSums(r^2)))
  v[is.na(v)] <- 0; mean(v)
}
preds <- list(
  "average of others" = (matrix(colSums(ref), n, ncol(ref), byrow = TRUE) - ref) / (n - 1),
  "replicate" = ref,
  "own target only" = { m <- matrix(0, n, ncol(ref)); for (i in seq_len(n)) m[i, i] <- 1; m })
rows <- list()
for (nm in names(preds)) for (sc in c("none", "row", "panel"))
  rows[[length(rows) + 1]] <- data.frame(prediction = nm, exclusion = sc, pds = pds(preds[[nm]], sc), alignment = align(preds[[nm]]))
mine <- do.call(rbind, rows)
ref_py <- read.csv("results/validation-subset-python.csv")
m <- merge(mine, ref_py, by = c("prediction", "exclusion"), suffixes = c("_r", "_py"))
m$d_pds <- abs(m$pds_r - m$pds_py); m$d_align <- abs(m$alignment_r - m$alignment_py)
print(m[, c("prediction", "exclusion", "pds_r", "pds_py", "alignment_r", "alignment_py")])
ok <- nrow(m) == 9 && all(m$d_pds < 1e-4) && all(m$d_align < 1e-4)
jsonlite::write_json(list(status = if (ok) "pass" else "fail", method = "base R PDS (three scopes) and alignment on a public subset",
                          max_abs_diff = max(c(m$d_pds, m$d_align))), "results/validation.json", auto_unbox = TRUE, pretty = TRUE)
cat("validation:", if (ok) "pass" else "fail", "\n")
