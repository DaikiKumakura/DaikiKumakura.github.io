"""Reproduce tables and figures from the public S3 transcription."""
from pathlib import Path
import csv
import json
import sys
import platform
import hashlib
import numpy as np
import scipy
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT/'src'))
from precision import compatible_pairs, interval_envelope, binomial_interval, discordance

THRESHOLD = .25
N_GRID = [4, 10, 20, 50, 100, 200, 500, 1000]
P_GRID = [.10, .20, .24, .26, .30, .40]
COLORS = ['#0072B2', '#D55E00', '#009E73', '#CC79A7']
OUT = ROOT/'outputs'
TABLES, FIGURES = OUT/'tables', OUT/'figures'
TABLES.mkdir(parents=True, exist_ok=True)
FIGURES.mkdir(parents=True, exist_ok=True)
plt.rcParams.update({'font.family':'DejaVu Sans', 'font.size':11, 'axes.spines.top':False,
                     'axes.spines.right':False, 'svg.fonttype':'none', 'figure.dpi':150})


def write_table(name: str, rows: list[dict]) -> None:
    with (TABLES/name).open('w', newline='', encoding='utf-8') as f:
        writer = csv.DictWriter(f, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def save(fig, name: str) -> None:
    fig.savefig(FIGURES/(name+'.png'), dpi=180, bbox_inches='tight', facecolor='white')
    fig.savefig(FIGURES/(name+'.svg'), bbox_inches='tight', facecolor='white')
    svg=FIGURES/(name+'.svg')
    svg.write_text('\n'.join(line.rstrip() for line in svg.read_text(encoding='utf-8').splitlines())+'\n',encoding='utf-8')
    plt.close(fig)


def footer(fig, text: str) -> None:
    fig.get_layout_engine().set(rect=(0, .10, 1, .90))
    fig.text(.02, .02, text, fontsize=9, va='bottom')


with (ROOT/'data/processed/table_s3_transcription.csv').open(encoding='utf-8', newline='') as f:
    source = list(csv.DictReader(f))
assert len(source) == len({r['patient_id'] for r in source}) == 20
patients = []
all_pairs = []
for r in source:
    c, p = int(r['count_per_20ml']), int(r['dll3_percent'])
    assert abs(float(r['count_per_ml'])*20-c) < 1e-8
    pairs = compatible_pairs(c, p)
    env = interval_envelope(pairs)
    patients.append(dict(patient_id=r['patient_id'], count_per_20ml=c,
                         printed_percent=p, **env))
    all_pairs.extend(dict(patient_id=r['patient_id'], k=k, n=n) for k, n in pairs)
write_table('patient_interval_envelopes.csv', patients)
write_table('compatible_integer_pairs.csv', all_pairs)

sensitivity = []
for tol in [.5, 1.0]:
    for vmin in [10, 20]:
        rows = [interval_envelope(compatible_pairs(int(r['count_per_20ml']),
                int(r['dll3_percent']), percent_tolerance=tol, min_volume=vmin)) for r in source]
        sensitivity.append(dict(percent_tolerance_points=tol, min_volume_ml=vmin,
                                max_volume_ml=20, crossing_count=sum(x['crosses'] for x in rows)))
write_table('rounding_volume_sensitivity.csv', sensitivity)

design = [dict(n=n, true_assay_fraction=p, rho=rho,
               discordance_probability=discordance(n,p,rho=rho))
          for rho in [0,.01,.05] for p in P_GRID for n in N_GRID]
write_table('fixed_n_design.csv', design)

# Reproduce only the published aggregate benefit definition (PR + SD).
clinical = []
for name, k, n in [('sensitivity',11,13),('specificity',7,7),
                    ('positive_predictive_value',11,11),('negative_predictive_value',7,9)]:
    lo, hi = binomial_interval(k,n)
    clinical.append(dict(metric=name, numerator=k, denominator=n, estimate=k/n,
                         lower95=lo, upper95=hi))
write_table('published_aggregate_metrics.csv', clinical)

order = sorted(patients, key=lambda r:(r['printed_percent'],r['patient_id']))
fig, ax = plt.subplots(figsize=(9,7.2), layout='constrained')
for y, r in enumerate(order):
    color = COLORS[1] if r['crosses'] else COLORS[0]
    ax.plot([100*r['lower'],100*r['upper']],[y,y],color=color,lw=2)
    ax.scatter(r['printed_percent'],y,color=color,s=27,zorder=3)
    ax.text(102,y,str(r['count_per_20ml']),va='center',fontsize=9)
ax.axvline(25,color='#555555',ls='--',lw=1)
ax.set(yticks=range(20),yticklabels=['P'+r['patient_id'] for r in order],
       xlabel='DLL3-positive fraction among assay-defined CTCs (%)',ylabel='Published patient ID',
       xlim=(-2,116),ylim=(-.8,20.3),title='Conditional interval envelopes for 20 patients')
ax.text(102,19.9,'CTC/20 mL',fontsize=9,va='bottom')
footer(fig,'Lines: envelopes over compatible (k,n), not validated patient confidence intervals.\nOrange crosses 25%; dots are printed S3 percentages. Counts at right are standardized.')
save(fig,'patient-envelopes')

fig, axes = plt.subplots(1,2,figsize=(10,4.6),layout='constrained')
ns = np.arange(4,501)
for ax, ps in zip(axes, [[.20,.30],[.24,.26]]):
    for p,color in zip(ps,COLORS):
        ax.plot(ns,[100*discordance(int(n),p) for n in ns],color=color,lw=1,label=f'p = {p:.2f}')
    ax.axhline(5,color='#555555',ls='--',lw=1,label='5% reference')
    ax.set(xlabel='Raw cells scored (n)',ylabel='Threshold-side mismatch (%)',xlim=(4,500),ylim=(0,65))
    ax.legend(frameon=False,fontsize=9)
axes[0].set_title('Five percentage points from 25%')
axes[1].set_title('One percentage point from 25%')
footer(fig,'Exact binomial fixed-n calculations. Sawtooth patterns reflect integer thresholds.\nThese are design scenarios, not observed patient error rates.')
save(fig,'fixed-count-design')

fig, ax = plt.subplots(figsize=(8,4.6),layout='constrained')
for rho,color in zip([0,.01,.05],COLORS):
    ax.plot(ns,[100*discordance(int(n),.30,rho=rho) for n in ns],color=color,
            label=f'rho = {rho:.2f}',lw=1.5)
ax.axhline(5,color='#555555',ls='--',lw=1)
ax.set(xlabel='Raw cells scored (n)',ylabel='Threshold-side mismatch (%)',xlim=(4,500),ylim=(0,65),
       title='Sensitivity to overdispersion at p = 0.30')
ax.legend(frameon=False)
footer(fig,'Beta-binomial exchangeable correlation is stipulated, not estimated from the patients.')
save(fig,'overdispersion-sensitivity')

result = dict(patients=len(patients), standardized_count_total=sum(r['count_per_20ml'] for r in patients),
              standardized_count_median=float(np.median([r['count_per_20ml'] for r in patients])),
              positive_count=sum(r['printed_percent']>=25 for r in patients),
              positive_percent_median=float(np.median([r['printed_percent'] for r in patients if r['printed_percent']>=25])),
              low_percent_median=float(np.median([r['printed_percent'] for r in patients if r['printed_percent']<25])),
              envelope_crossing_count=sum(r['crosses'] for r in patients),
              crossing_patient_ids=[r['patient_id'] for r in patients if r['crosses']],
              standardized_count_below10=sum(r['count_per_20ml']<10 for r in patients),
              known_raw_denominators=False, threshold=THRESHOLD, random_simulation=False,
              assumptions=dict(volume_ml=[10,20],count20_tolerance=.5,percent_tolerance_points=.5,
                               same_scored_set=True,independent_cells_for_binomial=True),
              source_input_sha256=hashlib.sha256((ROOT/'data/processed/table_s3_transcription.csv').read_bytes()).hexdigest(),
              environment=dict(python=platform.python_version(),numpy=np.__version__,scipy=scipy.__version__,matplotlib=matplotlib.__version__))
(OUT/'results.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
print(json.dumps(result,indent=2))
