# DLL3-positive CTC measurement precision

STCE-01. Research reanalysis of the public pretreatment CTC table in Mishra et al., Cancer Discovery (2026), DOI 10.1158/2159-8290.CD-25-1483.

The public table reports counts standardized to 20 mL, not necessarily the raw number of cells scored. No raw denominator is imputed. The analysis enumerates integer numerator/denominator pairs compatible with explicit volume/rounding assumptions, reports an envelope of conditional binomial intervals, and separately calculates fixed-sample-size design scenarios. These scenarios are not clinical validation.

## Run

Use the existing workspace Python environment (NumPy 2.2.6, SciPy 1.14.0, Matplotlib 3.9.1). No installation is needed in this workspace.

```sh
python analysis/run.py
python -m unittest discover -s tests -v
```

Inputs: `data/processed/table_s3_transcription.csv`. Source PDFs and public metadata are preserved in `data/raw/`; they are not needed to execute the analysis. Outputs: `outputs/tables/`, `outputs/figures/`, and `outputs/results.json`.

The analysis does not estimate treatment benefit, optimize a clinical threshold, recommend patient eligibility, or compare dosing schedules. The accompanying website article explains interpretation and scope. Source attribution and download locations are in `source-provenance.json`; the transcribed table is adapted from Mishra et al., Supplementary Table S3, DOI 10.1158/2159-8290.32728723 (CC BY 4.0).
