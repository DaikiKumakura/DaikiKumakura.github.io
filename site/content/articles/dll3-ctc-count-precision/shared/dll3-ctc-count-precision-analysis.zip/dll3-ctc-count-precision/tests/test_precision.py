from pathlib import Path
import sys
import unittest
from math import comb
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'src'))
from precision import binomial_interval, compatible_pairs, interval_envelope, discordance


class PrecisionTests(unittest.TestCase):
    def test_known_exact_interval(self):
        lo,hi=binomial_interval(1,2)
        self.assertAlmostEqual(lo,0.0125791171,places=9)
        self.assertAlmostEqual(hi,0.9874208829,places=9)

    def test_extreme_samples(self):
        self.assertEqual(binomial_interval(0,5)[0],0)
        self.assertEqual(binomial_interval(5,5)[1],1)

    def test_normalized_count_is_not_raw_denominator(self):
        self.assertEqual(compatible_pairs(9,33),[(2,6),(3,9)])
        self.assertEqual(compatible_pairs(2,50),[(1,2)])

    def test_volume_compatibility(self):
        for k,n in compatible_pairs(209,97):
            self.assertGreaterEqual(n,105)
            self.assertLessEqual(n,209)
            self.assertLessEqual(abs(100*k/n-97),.500000001)

    def test_independent_exact_sum(self):
        n,p=20,.3
        expected=sum(comb(n,k)*p**k*(1-p)**(n-k) for k in range(5))
        self.assertAlmostEqual(discordance(n,p),expected,places=12)

    def test_envelope_contains_each_interval(self):
        pairs=compatible_pairs(9,33)
        env=interval_envelope(pairs)
        for k,n in pairs:
            lo,hi=binomial_interval(k,n)
            self.assertLessEqual(env['lower'],lo)
            self.assertGreaterEqual(env['upper'],hi)

    def test_threshold_tie_and_empty_set(self):
        with self.assertRaises(ValueError): discordance(20,.25)
        with self.assertRaises(ValueError): interval_envelope([])

    def test_beta_binomial_limit(self):
        self.assertAlmostEqual(discordance(100,.3),discordance(100,.3,rho=1e-6),places=4)


if __name__=='__main__': unittest.main()
