"""Finite-count precision calculations; all probabilities are assay-specific."""
from math import ceil, floor
import numpy as np
from scipy.stats import beta, binom, betabinom


def binomial_interval(k: int, n: int, alpha: float = 0.05) -> tuple[float, float]:
    """Two-sided Clopper-Pearson interval for a known raw denominator."""
    if n < 1 or not 0 <= k <= n:
        raise ValueError("Expected 0 <= k <= n and n >= 1")
    return (0.0 if k == 0 else float(beta.ppf(alpha / 2, k, n-k+1)),
            1.0 if k == n else float(beta.ppf(1-alpha/2, k+1, n-k)))


def compatible_pairs(count20: int, percent: float,
                     percent_tolerance: float = 0.5,
                     count_tolerance: float = 0.5,
                     min_volume: float = 10.0,
                     max_volume: float = 20.0) -> list[tuple[int, int]]:
    """Enumerate possibilities, not estimates of the unavailable raw counts.

    Requires the count and percentage to describe the same scored cell set.
    Tolerances are assumptions, not documented properties of the assay.
    Endpoints are included to avoid assuming a tie-rounding convention.
    """
    lower = max(0, percent-percent_tolerance) / 100
    upper = min(100, percent+percent_tolerance) / 100
    nlo = max(1, ceil((count20-count_tolerance)*min_volume/20-1e-10))
    nhi = floor((count20+count_tolerance)*max_volume/20+1e-10)
    pairs = []
    for n in range(nlo, nhi+1):
        klo = max(0, ceil(lower*n-1e-10))
        khi = min(n, floor(upper*n+1e-10))
        pairs.extend((k, n) for k in range(klo, khi+1))
    return pairs


def interval_envelope(pairs: list[tuple[int, int]], threshold: float = 0.25) -> dict:
    """Envelope over conditional intervals; not an assay-validated patient CI."""
    if not pairs:
        raise ValueError("No compatible integer pair")
    ks = np.array([p[0] for p in pairs])
    ns = np.array([p[1] for p in pairs])
    los = np.where(ks == 0, 0, beta.ppf(.025, np.maximum(ks, 1), ns-ks+1))
    his = np.where(ks == ns, 1, beta.ppf(.975, ks+1, np.maximum(ns-ks, 1)))
    lo, hi = float(los.min()), float(his.max())
    return dict(pair_count=len(pairs), n_min=int(ns.min()), n_max=int(ns.max()),
                lower=lo, upper=hi, crosses=bool(lo <= threshold <= hi))


def below_threshold_probability(n: int, p: float, threshold: float = 0.25,
                                rho: float = 0.0) -> float:
    """Fixed-n probability that the observed fraction is below the threshold."""
    boundary = ceil(n*threshold-1e-12)-1
    if rho == 0:
        return float(binom.cdf(boundary, n, p))
    if not 0 < rho < 1 or not 0 < p < 1:
        raise ValueError("Beta-binomial requires interior p and rho")
    concentration = 1/rho-1
    return float(betabinom.cdf(boundary, n, p*concentration, (1-p)*concentration))


def discordance(n: int, p: float, threshold: float = .25, rho: float = 0) -> float:
    """Mismatch with the stipulated p-side; undefined at p == threshold."""
    if p == threshold:
        raise ValueError("No true side is assigned at the threshold")
    q = below_threshold_probability(n, p, threshold, rho)
    return q if p > threshold else 1-q
