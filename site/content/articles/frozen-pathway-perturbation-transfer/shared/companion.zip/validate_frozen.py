"""Evaluate frozen footprints on preprocessed human bulk RNA-seq."""

import argparse
import csv
import hashlib
import json
from pathlib import Path
import re

import numpy as np
import pandas as pd

from cross_study import score


ROOT = Path(__file__).resolve().parent
VERSION = "tumor-footprints-validation-v1"
WEIGHTS_SHA256 = "075e4b4130a7c0ca628202d8a8d03ff0128f1f9517eacdb1e35e4c33232a68fa"
NAMESPACE = {"MAPK": "symbol", "IFN_I": "ensembl", "IFN_II": "ensembl"}
DEVELOPMENT = {
    "GSE312195", "GSE87419", "GSE110397", "GSE185200", "GSE236156",
    "GSE158434", "CPTACLUAD", "GSE91061", "GSE168204",
}
ARMS = ("target", "control", "competitor")
BOOTSTRAP_SEED = 20261117
BOOTSTRAP_REPLICATES = 2000


def digest(path):
    with path.open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def cohort_key(name):
    return re.sub(r"[^A-Z0-9]", "", name.upper())


def frozen_weights(axis):
    path = ROOT / "validation-weights-v1.tsv"
    if digest(path) != WEIGHTS_SHA256:
        raise ValueError("Frozen weights do not match the validation protocol")
    frame = pd.read_csv(path, sep="\t", float_precision="round_trip")
    selected = frame[frame.axis == axis]
    if len(selected) != 50 or not selected.gene.is_unique:
        raise ValueError(f"Invalid weight set: {axis}")
    return selected.set_index("gene").weight


def read_expression(path, namespace):
    with path.open(encoding="utf-8-sig", newline="") as stream:
        header = next(csv.reader(stream, delimiter="\t"), [])
    if len(header) < 2 or header[0] != "gene" or len(set(header)) != len(header):
        raise ValueError("Expression header must contain gene and unique sample columns")
    if any(not value.strip() or value != value.strip() for value in header):
        raise ValueError("Missing or untrimmed expression column name")
    x = pd.read_csv(path, sep="\t", dtype={"gene": "string"}).set_index("gene")
    if len(x) < 2 or not x.index.is_unique or x.index.isna().any():
        raise ValueError("Expression must contain two or more uniquely named genes")
    if any(gene != gene.strip() for gene in x.index):
        raise ValueError("Untrimmed gene identifier")
    if namespace == "ensembl" and not x.index.str.fullmatch(r"ENSG\d{11}").all():
        raise ValueError("Use unversioned human Ensembl gene identifiers")
    if namespace == "symbol" and x.index.str.fullmatch(r"ENSG\d{11}(\.\d+)?").any():
        raise ValueError("Use human gene symbols for MAPK")
    x = x.apply(pd.to_numeric, errors="raise")
    if not np.isfinite(x.to_numpy()).all():
        raise ValueError("Expression values must be finite across the measured gene universe")
    return x


def perturbation(frame, axis):
    if frame[["contrast", "arm"]].isna().any().any() or set(frame.arm) != set(ARMS):
        raise ValueError("Use named contrasts and target, control and competitor arms")
    direction = -1 if axis == "MAPK" else 1
    results = []
    for contrast, group in frame.groupby("contrast", sort=True):
        summary = group.groupby("arm").score.agg(["mean", "size"]).reindex(ARMS)
        if summary["size"].isna().any() or (summary["size"] < 2).any():
            raise ValueError(f"Need at least two samples per arm: {contrast}")
        control = float(summary.loc["target", "mean"] - summary.loc["control", "mean"])
        competitor = float(summary.loc["target", "mean"] - summary.loc["competitor", "mean"])
        results.append({
            "contrast": contrast,
            "target_minus_control": control,
            "target_minus_competitor": competitor,
            "expected_direction": direction,
            "direction_agrees_for_both": direction * control > 0 and direction * competitor > 0,
            "sample_counts": {arm: int(summary.loc[arm, "size"]) for arm in ARMS},
        })
    return results


def orthogonal(frame):
    baselines = sorted(name for name in frame if name.startswith("baseline_"))
    if not baselines:
        raise ValueError("Provide one or more baseline_<method> columns")
    columns = ["endpoint", "score", *baselines]
    values = frame[columns].apply(pd.to_numeric, errors="raise")
    values = values.loc[np.isfinite(values).all(axis=1)]
    if len(values) < 10 or (values.nunique() < 2).any():
        raise ValueError("Need ten or more complete tumors and nonconstant scores and endpoint")
    patients = frame.loc[values.index, "unit"]
    if patients.isna().any() or not patients.is_unique:
        raise ValueError("Provide one unique patient identifier per complete tumor")

    def correlations(table):
        return table.rank(method="average").corr()["endpoint"].drop("endpoint")

    observed = correlations(values)
    rng = np.random.default_rng(BOOTSTRAP_SEED)
    replicates = np.array([
        correlations(values.iloc[rng.integers(len(values), size=len(values))]).to_numpy()
        for _ in range(BOOTSTRAP_REPLICATES)
    ])
    comparisons = []
    for index, name in enumerate(baselines, start=1):
        differences = replicates[:, 0] - replicates[:, index]
        valid = differences[np.isfinite(differences)]
        interval = np.quantile(valid, [0.025, 0.975]).tolist() if len(valid) else None
        comparisons.append({
            "baseline": name.removeprefix("baseline_"),
            "baseline_spearman": float(observed[name]),
            "difference": float(observed["score"] - observed[name]),
            "percentile_interval_95": interval,
            "valid_bootstrap_replicates": len(valid),
        })
    return {
        "complete_patients": len(values),
        "excluded_samples": len(frame) - len(values),
        "candidate_spearman": float(observed["score"]),
        "comparisons": comparisons,
    }


def analyze(args):
    identifiers = {cohort_key(name) for name in [args.study, *args.parent_study]}
    if "" in identifiers:
        raise ValueError("Study and parent-study identifiers must be nonempty")
    hashes = {name: digest(getattr(args, name)) for name in ("expression", "metadata")}
    known = pd.read_csv(ROOT / "sources.tsv", sep="\t")
    if not args.development_replay and (
        DEVELOPMENT & identifiers or set(known.sha256) & set(hashes.values())
    ):
        raise ValueError("Known development cohort/input; use --development-replay for a labelled replay")
    expression = read_expression(args.expression, args.namespace)
    with args.metadata.open(encoding="utf-8-sig", newline="") as stream:
        header = next(csv.reader(stream, delimiter="\t"), [])
    if len(set(header)) != len(header):
        raise ValueError("Duplicate metadata column")
    meta = pd.read_csv(args.metadata, sep="\t", dtype={"sample": "string", "unit": "string"})
    required = {"sample", "contrast", "arm"} if args.mode == "perturbation" else {"sample", "unit", "endpoint"}
    if not required <= set(meta.columns):
        raise ValueError(f"Missing metadata columns: {', '.join(sorted(required - set(meta.columns)))}")
    if meta["sample"].isna().any() or not meta["sample"].is_unique or set(meta["sample"]) != set(expression.columns):
        raise ValueError("Metadata samples must match expression columns one to one")
    scores, coverage = score(expression, frozen_weights(args.axis))
    frame = meta.set_index("sample").assign(score=scores)
    metrics = perturbation(frame, args.axis) if args.mode == "perturbation" else orthogonal(frame)
    return {
        "version": VERSION, "axis": args.axis, "mode": args.mode,
        "namespace": args.namespace, "study": args.study, "parent_study": args.parent_study,
        "evidence": "development replay" if args.development_replay else "declared independent cohort",
        "input_sha256": hashes, "weights_sha256": WEIGHTS_SHA256,
        "weight_coverage": float(coverage), "measured_genes": len(expression),
        "metrics": metrics,
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--axis", choices=NAMESPACE, required=True)
    parser.add_argument("--namespace", choices=set(NAMESPACE.values()), required=True)
    parser.add_argument("--mode", choices=("perturbation", "orthogonal"), required=True)
    parser.add_argument("--study", required=True)
    parser.add_argument("--parent-study", required=True, action="append")
    parser.add_argument("--expression", required=True, type=Path)
    parser.add_argument("--metadata", required=True, type=Path)
    parser.add_argument("--development-replay", action="store_true")
    args = parser.parse_args()
    if args.namespace != NAMESPACE[args.axis]:
        parser.error(f"{args.axis} requires namespace {NAMESPACE[args.axis]}")
    try:
        result = analyze(args)
    except (KeyError, ValueError, OSError) as error:
        parser.error(str(error))
    print(json.dumps(result, indent=2, allow_nan=False))


if __name__ == "__main__":
    main()
