"""Build and evaluate experimental footprints using whole-study splits."""
import gzip
import re
from pathlib import Path

import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parent
RAW = ROOT / "data/raw"
RESULTS = ROOT / "results"


def soft_blocks(study):
    with gzip.open(RAW / f"{study}.soft.gz", "rt", encoding="utf8", errors="replace") as file:
        return re.split(r"(?m)^\^SAMPLE = ", file.read())[1:]


def fit(effects):
    """Select genes with reproducible directions after equal study weighting."""
    ranks = [np.sign(effect) * effect.abs().rank(pct=True, method="average") for effect in effects]
    common = pd.concat(ranks, axis=1, join="inner").dropna()
    agreed = common[(common.gt(0).all(axis=1)) | (common.lt(0).all(axis=1))]
    weights = agreed.mean(axis=1).sort_index()
    weights = weights.loc[weights.abs().sort_values(ascending=False, kind="stable").head(50).index]
    if len(weights) != 50:
        raise ValueError("Insufficient common directionally consistent genes")
    return weights


def score(expression, weights):
    present = weights.index.intersection(expression.index)
    covered = weights.loc[present]
    coverage = covered.abs().sum() / weights.abs().sum()
    if coverage < 0.8:
        raise ValueError(f"Insufficient weight coverage: {coverage:.3f}")
    ranks = (expression.rank(axis=0) - 1) / (len(expression) - 1) - 0.5
    return ranks.loc[present].mul(covered, axis=0).sum() / covered.abs().sum(), coverage


def ifn_expression(row):
    study = row.study
    counts = pd.read_csv(RAW / row.source, sep="," if study == "GSE236156" else "\t", index_col=0)
    counts.index = counts.index.str.replace(r"\.\d+$", "", regex=True)
    counts = counts.groupby(level=0).sum()
    if counts.isna().any().any() or (counts < 0).any().any() or (counts.sum() <= 0).any():
        raise ValueError(f"Invalid counts: {study}")
    expression = np.log2(1 + counts.div(counts.sum(), axis=1) * 1e6)
    groups = {arm: {} for arm in ("IFN_I", "IFN_II", "control")}
    for block in soft_blocks(study):
        title = re.search(r"(?m)^!Sample_title = (.+)$", block)[1]
        if study == "GSE185200":
            donor, sample = re.search(r"Donor (\d+) \[([^]]+)\]", title).groups()
            arm = {"IFNa": "IFN_I", "IFNg": "IFN_II", "UT": "control"}.get(sample.split("_")[0])
        elif study == "GSE236156":
            match = re.fullmatch(r"(.+)_MDM_(IFNA8|IFNg|untreated)", title)
            if not match:
                continue
            donor, treatment = match.groups()
            sample = title
            arm = {"IFNA8": "IFN_I", "IFNg": "IFN_II", "untreated": "control"}[treatment]
        else:
            sample, treatment = title.split(" ", 1)
            donor = sample
            arm = {"Interferon-alpha": "IFN_I", "Interferon-gamma": "IFN_II", "Mock": "control"}.get(treatment)
        if arm:
            if donor in groups[arm] or sample not in expression:
                raise ValueError(f"Invalid sample mapping: {study} {title}")
            groups[arm][donor] = sample
    return expression, groups


def ifn_effect(expression, groups, axis):
    other = "IFN_II" if axis == "IFN_I" else "IFN_I"
    target, comparison = groups[axis], groups[other]
    donors = sorted(target)
    if set(target) != set(comparison) or set(target) != set(groups["control"]):
        raise ValueError("Training donors do not match across IFN arms")
    treatment = expression[[target[d] for d in donors]].to_numpy()
    competing = expression[[comparison[d] for d in donors]].to_numpy()
    control = expression[[groups["control"][d] for d in donors]].to_numpy()
    activation = np.mean(treatment - control, axis=1)
    specificity = np.mean(treatment - competing, axis=1)
    agreed = np.sign(activation) == np.sign(specificity)
    effect = np.where(agreed, np.sign(activation) * np.minimum(abs(activation), abs(specificity)), 0)
    return pd.Series(effect, index=expression.index)


def mapk_expression(row):
    table = pd.read_csv(RAW / row.source, sep="\t")
    samples = [column for column in table if re.match(r"^A\d{2}_", column)]
    values = table.dropna(subset=["external_gene_name"]).groupby("external_gene_name")[samples].sum()
    groups = {}
    for block in soft_blocks(row.study):
        descriptions = re.findall(r"(?m)^!Sample_description = (.+)$", block)
        matched = set(descriptions).intersection(samples)
        if matched:
            title = re.search(r"(?m)^!Sample_title = (.+)$", block)[1]
            line, treatment, _ = title.split()
            sample = matched.pop()
            if matched or sample in groups:
                raise ValueError(f"Ambiguous GEO mapping: {title}")
            groups[sample] = (line, {"Vehicle": "DMSO", "Tramet": "trametinib",
                                    "Trametb": "trametinib", "Palbo": "palbociclib",
                                    "Combo": "combination"}[treatment])
    if set(groups) != set(samples):
        raise ValueError("Incomplete lung cancer sample mapping")
    return np.log2(values + 1), groups


def mapk_effect(row):
    if row.study == "GSE312195":
        table = pd.read_csv(RAW / row.source, sep=";", decimal=",").set_index("gene")
        effect = table["Tram_8h_DESeq2log2FC"]
    else:
        table = pd.read_excel(RAW / row.source, sheet_name="Tramet_DMSO-out").set_index("Gene")
        effect = table["log2FoldChange"]
    effect = effect.dropna().groupby(level=0).median()
    return effect * row.direction


def main():
    ledger = pd.read_csv(ROOT / "contrasts.tsv", sep="\t")
    axes = pd.read_csv(ROOT / "axes.tsv", sep="\t")
    if axes.axis.duplicated().any() or not set(ledger.axis) <= set(axes.axis):
        raise ValueError("Duplicate or unregistered axis")
    if ledger.contrast_id.duplicated().any() or ledger.isna().any().any():
        raise ValueError("Missing metadata or duplicate contrast")
    if ledger.groupby("study").parent_study.nunique().max() != 1:
        raise ValueError("Inconsistent parent study")
    for source in ledger.source.unique():
        if not (RAW / source).is_file():
            raise FileNotFoundError(source)

    weights_out, results = [], []

    def evaluate(axis, train, test, weights, expression, selected):
        if test.parent_study in set(train.parent_study):
            raise ValueError("Train/test parent-study overlap")
        if set(train.namespace) != {test.namespace}:
            raise ValueError("Incompatible gene namespaces")
        scores, coverage = score(expression, weights)
        train_ids = ",".join(sorted(set(train.study)))
        if len(selected[0]) != test.n_treated or len(selected[1]) != test.n_control:
            raise ValueError(f"Sample count mismatch: {test.contrast_id}")
        sample_ids = [sample for arm in selected for sample in arm]
        if not selected[2] or len(sample_ids) != len(set(sample_ids)) or not set(sample_ids) <= set(scores.index):
            raise ValueError(f"Invalid samples: {test.contrast_id}")
        delta = scores[selected[0]].mean() - scores[selected[1]].mean()
        specificity = scores[selected[0]].mean() - scores[selected[2]].mean()
        paired = test.pairing == "donor matched"
        favorable = (scores[selected[0]].to_numpy() > scores[selected[2]].to_numpy()).sum() if paired else np.nan
        results.append(dict(axis=axis, train_studies=train_ids, test_study=test.study,
                            contrast=test.contrast_id, context=test.context, coverage=coverage,
                            target_minus_control=delta, target_minus_competitor=specificity,
                            paired_target_above_competitor=favorable,
                            n_treated=test.n_treated, n_control=test.n_control))
        weights_out.extend(dict(axis=axis, train_studies=train_ids, namespace=test.namespace, gene=gene,
                                weight=weight) for gene, weight in weights.items())

    mapk = ledger[ledger.axis == "MAPK"]
    train = mapk[mapk.role == "train"]
    weights = fit([mapk_effect(row) for row in train.itertuples()])
    test_mapk = mapk[(mapk.role == "test") & (mapk.direction == -1)]
    expression, groups = mapk_expression(next(test_mapk.itertuples()))
    for row in test_mapk.itertuples():
        competitor = mapk[(mapk.context == row.context) & (mapk.direction == 0)].iloc[0]
        selected = [[sample for sample, pair in groups.items() if pair == (row.context.split()[0], arm)]
                    for arm in (row.treatment, row.control, competitor.treatment)]
        evaluate("MAPK", train, row, weights, expression, selected)

    for axis in ("IFN_I", "IFN_II"):
        frame = ledger[ledger.axis == axis]
        datasets = {row.study: ifn_expression(row) for row in frame.itertuples()}
        for test in frame.itertuples():
            train = frame[(frame.role == "cross_validation") & (frame.parent_study != test.parent_study)]
            weights = fit([ifn_effect(*datasets[study], axis) for study in train.study])
            expression, groups = datasets[test.study]
            other = "IFN_II" if axis == "IFN_I" else "IFN_I"
            if test.pairing == "donor matched" and len({frozenset(x) for x in groups.values()}) != 1:
                raise ValueError(f"Donor mismatch: {test.study}")
            selected = [[groups[arm][key] for key in sorted(groups[arm])]
                        for arm in (axis, "control", other)]
            evaluate(axis, train, test, weights, expression, selected)

    RESULTS.mkdir(exist_ok=True)
    pd.DataFrame(weights_out).drop_duplicates().to_csv(RESULTS / "cross-study-weights.tsv", sep="\t", index=False)
    output = pd.DataFrame(results)
    output.to_csv(RESULTS / "cross-study-evaluation.tsv", sep="\t", index=False, na_rep="NA")
    print(output.to_string(index=False))


if __name__ == "__main__":
    main()
