# Reproduction

Use Python 3.12 with pandas, NumPy and SciPy. Download the following inputs into this directory.

- [GSE103363 matrix](https://ftp.ncbi.nlm.nih.gov/geo/series/GSE103nnn/GSE103363/matrix/GSE103363_series_matrix.txt.gz)
- [GPL6244 annotation](https://ftp.ncbi.nlm.nih.gov/geo/platforms/GPL6nnn/GPL6244/annot/GPL6244.annot.gz)
- [GSE301146 matrix](https://ftp.ncbi.nlm.nih.gov/geo/series/GSE301nnn/GSE301146/matrix/GSE301146_series_matrix.txt.gz)
- [GSE301146 normalized counts](https://ftp.ncbi.nlm.nih.gov/geo/series/GSE301nnn/GSE301146/suppl/GSE301146_51T-2D_Normcounts.txt.gz)

Run python prepare_gse103363.py, python prepare_gse301146.py, then python analysis.py.

The included gene identifier mapping is derived from the HGNC complete set, [CC0](https://hgnc.genenames.org/about/license/).
