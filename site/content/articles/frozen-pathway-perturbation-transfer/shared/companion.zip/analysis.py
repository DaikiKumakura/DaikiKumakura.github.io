"""Stress-test frozen pathway scores by deleting one specimen per arm."""
from itertools import product
from pathlib import Path
import sys

import pandas as pd

HERE = Path(__file__).resolve().parent
from validate_frozen import frozen_weights, read_expression, score


def evaluate(expression, metadata, axis, namespace, direction):
    values = read_expression(expression, namespace)
    scores, coverage = score(values, frozen_weights(axis))
    annotations = pd.read_csv(metadata, sep="\t").set_index("sample")
    annotations["score"] = scores
    arms = [annotations.loc[annotations.arm.eq(arm), "score"].tolist()
            for arm in ("target", "control", "competitor")]
    assert all(len(arm) == 3 for arm in arms)
    full = [sum(arm) / 3 for arm in arms]
    pairs = [[(sum(arm) - score) / 2 for score in arm] for arm in arms]
    differences = [(direction * (t - c), direction * (t - a)) for t, c, a in product(*pairs)]
    return {
        "axis": axis, "coverage": coverage,
        "target_minus_control": full[0] - full[1], "target_minus_competitor": full[0] - full[2],
        "direction_preserved": sum(a > 0 and b > 0 for a, b in differences), "omissions": len(differences),
        "oriented_min_vs_control": min(a for a, b in differences),
        "oriented_min_vs_competitor": min(b for a, b in differences),
    }


if __name__ == "__main__":
    data = HERE
    results = [
        evaluate(data / f"{study}-expression.tsv", data / f"{study}-{axis}.tsv", axis, namespace, sign)
        for axis, study, namespace, sign in [
            ("IFN_I", "gse103363", "ensembl", 1),
            ("IFN_II", "gse103363", "ensembl", 1),
            ("MAPK", "gse301146", "symbol", -1),
        ]
    ]
    table = pd.DataFrame(results)
    table.to_csv(HERE / "results.csv", index=False)
    print(table.to_string(index=False))
