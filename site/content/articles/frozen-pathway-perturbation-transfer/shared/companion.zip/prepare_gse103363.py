"""Prepare the independent HeLa IFN contrasts for the frozen footprint scorer."""
from pathlib import Path
import csv
import gzip
import hashlib
import json

import pandas as pd


HERE = Path(__file__).resolve().parent
RAW = HERE
MATRIX = HERE / "GSE103363_series_matrix.txt.gz"
PLATFORM = HERE / "GPL6244.annot.gz"
HGNC = RAW / "hgnc-min.tsv"

with gzip.open(MATRIX, "rt") as handle:
    for line in handle:
        if line.startswith("!Sample_title\t"):
            titles = next(csv.reader([line], delimiter="\t"))[1:]
        if line.startswith("!Sample_geo_accession\t"):
            samples = next(csv.reader([line], delimiter="\t"))[1:]
        if line.startswith("!Series_platform_id\t"):
            assert "GPL6244" in line
        if line.startswith('"ID_REF"'):
            break
    genes = pd.read_csv(handle, sep="\t", names=["probe", *samples], dtype={"probe": str})
genes = genes.loc[genes["probe"].str.fullmatch(r"\d+")].copy()
genes[samples] = genes[samples].apply(pd.to_numeric, errors="raise")
assert len(samples) == len(titles) == 9

with gzip.open(PLATFORM, "rt", errors="replace") as handle:
    for line in handle:
        if line.startswith("ID\t"):
            header = line.strip().split("\t")
            break
    probes = pd.read_csv(handle, sep="\t", names=header, usecols=["ID", "Gene ID"], dtype=str)
probes = probes.loc[probes["Gene ID"].fillna("").str.fullmatch(r"\d+")]
probes = probes.drop_duplicates().drop_duplicates("ID", keep=False)
mapping = pd.read_csv(HGNC, sep="\t", dtype=str, usecols=["entrez_id", "ensembl_gene_id", "status"])
mapping = mapping.loc[mapping["status"].eq("Approved")].dropna().drop_duplicates()
mapping = mapping.drop_duplicates("entrez_id", keep=False).drop_duplicates("ensembl_gene_id", keep=False)
mapped = genes.merge(probes, left_on="probe", right_on="ID", validate="one_to_one")
mapped = mapped.merge(mapping, left_on="Gene ID", right_on="entrez_id", validate="many_to_one")
expression = mapped.groupby("ensembl_gene_id")[samples].median()
expression.to_csv(HERE / "gse103363-expression.tsv", sep="\t", index_label="gene")

labels = [title.split(",")[0] for title in titles]
assert sorted(labels) == sorted(["interferon-beta", "control", "interferon-gamma"] * 3)
for axis, target, comparator in [
    ("IFN_I", "interferon-beta", "interferon-gamma"),
    ("IFN_II", "interferon-gamma", "interferon-beta"),
]:
    roles = {target: "target", comparator: "competitor", "control": "control"}
    pd.DataFrame({"sample": samples, "contrast": axis, "arm": [roles[label] for label in labels]}).to_csv(
        HERE / f"gse103363-{axis}.tsv", sep="\t", index=False
    )
print(json.dumps({
    "samples": samples,
    "probe_rows": len(genes),
    "mapped_probe_rows": len(mapped),
    "genes": len(expression),
    "sha256": {p.name: hashlib.sha256(p.read_bytes()).hexdigest() for p in (MATRIX, PLATFORM, HGNC)},
}, indent=2))
