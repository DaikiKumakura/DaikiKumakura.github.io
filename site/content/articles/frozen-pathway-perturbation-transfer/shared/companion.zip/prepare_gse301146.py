"""Prepare the on-treatment MAPK contrast for the frozen footprint scorer."""
from pathlib import Path
import csv
import gzip
import hashlib
import json

import pandas as pd


HERE = Path(__file__).resolve().parent
MATRIX = HERE / "GSE301146_series_matrix.txt.gz"
COUNTS = HERE / "GSE301146_51T-2D_Normcounts.txt.gz"
design = {
    "DMSO": ("DMSO3", "control"),
    "Palbociclib": ("Palbo3", "competitor"),
    "Sotorasib": ("Soto3", "target"),
}
with gzip.open(MATRIX, "rt") as handle:
    for line in handle:
        if line.startswith("!Sample_title\t"):
            titles = next(csv.reader([line], delimiter="\t"))[1:]
        if line.startswith("!Sample_geo_accession\t"):
            samples = next(csv.reader([line], delimiter="\t"))[1:]
            break

metadata = []
rename = {}
for title, accession in zip(titles, samples, strict=True):
    cell, treatment, day, replicate = title.split(", ")
    assert cell == "51T-2D cells"
    if day == "day3" and treatment in design:
        prefix, arm = design[treatment]
        assert replicate in {"rep1", "rep2", "rep3"}
        rename[f"{prefix}.{replicate[-1]}"] = accession
        metadata.append({"sample": accession, "contrast": "51T-2D at 48 h", "arm": arm})
assert len(rename) == len(metadata) == 9
frame = pd.read_csv(COUNTS, sep="\t", usecols=["GENE_ID", *rename], dtype={"GENE_ID": str}).dropna(subset=["GENE_ID"])
expression = frame.groupby("GENE_ID")[list(rename)].median().rename(columns=rename)
expression.to_csv(HERE / "gse301146-expression.tsv", sep="\t", index_label="gene")
pd.DataFrame(metadata).to_csv(HERE / "gse301146-MAPK.tsv", sep="\t", index=False)
print(json.dumps({
    "genes": len(expression),
    "samples": list(rename.values()),
    "sha256": {p.name: hashlib.sha256(p.read_bytes()).hexdigest() for p in (MATRIX, COUNTS)},
}, indent=2))
