"""Linear ADC disposition plus empirical payload forcing, units mg/L/day."""
import numpy as np


def parameters(cfg: dict, weight: float, eta: np.ndarray | None = None,
               covariates: dict | None = None, slopes: dict | None = None) -> dict:
    eta = np.zeros((1, 8)) if eta is None else np.atleast_2d(eta)
    ref = cfg['reference'];c = dict(ref, weight=weight)
    if covariates:c.update(covariates)
    b = dict(cfg['slopes'])
    if slopes:b.update(slopes)
    w = c['weight']/ref['weight'];a=c['age']/ref['age'];alb=c['albumin']/ref['albumin'];s=c['sod']/ref['sod'];ast=c['ast']/ref['ast']
    factor=dict(cl=w**b['cl_bw']*s**b['cl_sod'],v1=w**b['v1_bw']*a**b['v1_age']*alb**b['v1_alb'],q=1,
                v2=alb**b['v2_alb'],rat=w**b['rat_bw']*s**b['rat_sod'],alpha=1,
                cl3=ast**b['cl3_ast'],v3=a**b['v3_age'])
    return {k:cfg['pk'][k]*factor[k]*np.exp(eta[:,j]) for j,k in enumerate(cfg['omega_order'])}


def dose(cfg: dict, weight: float, policy: str) -> float:
    dref=cfg['reference']['weight']*cfg['dose']['reference_mg_per_kg']
    if policy=='mgkg':return weight*cfg['dose']['reference_mg_per_kg']
    if policy=='fixed':return dref
    if policy=='cap70':return min(weight,cfg['dose']['cap_kg'])*cfg['dose']['reference_mg_per_kg']
    if policy=='power':return dref*(weight/cfg['reference']['weight'])**design_exponent(cfg)
    raise ValueError(policy)


def design_exponent(cfg: dict) -> float:
    b=cfg['slopes'];adc=b['cl_bw'];pay=b['cl_bw']-b['v1_bw']-b['rat_bw']
    return (adc+pay)/2


def matrix(p: dict, later: bool = True) -> np.ndarray:
    n=len(p['cl']);k=np.zeros((n,3,3))
    k[:,0,0]=-(p['cl']+p['q'])/p['v1'];k[:,0,1]=p['q']/p['v2']
    k[:,1,0]=p['q']/p['v1'];k[:,1,1]=-p['q']/p['v2']
    k[:,2,0]=p['rat']*(p['alpha'] if later else 1)
    k[:,2,2]=-p['cl3']/p['v3']
    return k


def components(p: dict, later: bool = True) -> tuple:
    vals,vec=np.linalg.eig(matrix(p,later));assert np.max(np.abs(vals.imag))<1e-10
    # response of each state to unit mass entering the central ADC compartment
    coef=vec*np.linalg.inv(vec)[:,None,:,0]
    return vals.real,coef.real


def steady_profile(p: dict, amount: float, times: np.ndarray, tau: float,
                   infusion_day: float, scale: float) -> np.ndarray:
    """Periodic concentrations; ADC ug/mL and conditional payload ng/mL."""
    vals,coef=components(p);t=np.atleast_1d(times)
    coeff=coef*amount/infusion_day
    # Integration of all prior infusions and of the current partial/full infusion.
    h=infusion_day
    prior=np.expm1(vals*h)/vals*np.exp(vals*(tau-h))/(-np.expm1(vals*tau))
    result=np.empty((len(p['cl']),len(t),2))
    for state,vol,mult in [(0,p['v1'],1),(2,p['v3'],scale)]:
        out=np.zeros((len(p['cl']),len(t)))
        for j in range(3):
            v=vals[:,j,None];tt=t[None,:]
            current=np.where(tt<=h,np.expm1(v*np.minimum(tt,h))/v,
                             np.exp(v*np.maximum(tt-h,0))*np.expm1(v*h)/v)
            kernel=prior[:,j,None]*np.exp(v*tt)+current
            out+=coeff[:,state,j,None]*kernel
        result[:,:,0 if state==0 else 1]=out/vol[:,None]*mult
    assert result.min()>-1e-7
    return np.maximum(result,0)


def auc(p: dict, amount: float, scale: float, later: bool = True) -> np.ndarray:
    adc=amount/p['cl']
    pay=scale*p['rat']*(p['alpha'] if later else 1)*p['v1']*amount/(p['cl']*p['cl3'])
    return np.column_stack([adc,pay])


def metrics(p: dict, amount: float, tau: float, infusion_day: float, scale: float) -> dict:
    t=np.unique(np.r_[np.linspace(0,1,201),np.linspace(1,tau,401),infusion_day])
    c=steady_profile(p,amount,t,tau,infusion_day,scale)
    return dict(auc=auc(p,amount,scale),cmax=c.max(axis=1),cmin=c.min(axis=1))
