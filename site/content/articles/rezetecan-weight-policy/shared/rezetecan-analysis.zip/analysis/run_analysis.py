"""Regenerate original figures and aggregate exposure comparisons."""
from pathlib import Path
import hashlib,itertools,json,platform,time
import numpy as np
import pandas as pd
import scipy
from scipy.integrate import solve_ivp
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from model import parameters,dose,design_exponent,matrix,steady_profile,auc,metrics

ROOT=Path(__file__).resolve().parents[1]
CFG=json.loads((ROOT/'analysis/inputs.json').read_text(encoding='utf-8'))
POLICIES=['mgkg','fixed','power','cap70']
LABELS={'mgkg':'4.8 mg/kg','fixed':'Fixed 290.88 mg','power':'Power 0.526 (hypothetical)','cap70':'4.8 mg/kg, cap 70 kg'}
COLORS={'mgkg':'#2463A6','fixed':'#C36B24','power':'#2463A6','cap70':'#4B5563'}
STYLES={'mgkg':'-','fixed':'--','power':':','cap70':'-.'}
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':10,'axes.spines.top':False,'axes.spines.right':False,'axes.grid':True,'grid.alpha':.15})


def quantiles(a: np.ndarray) -> dict:
    q=np.percentile(a,[5,50,95]);return dict(p05=float(q[0]),median=float(q[1]),p95=float(q[2]))


def cycles(p: dict, amount: float, scale: float, constant_release: bool = False) -> pd.DataFrame:
    """Three cycles from no prior dose; split infusion and cycle discontinuities."""
    tau=CFG['tau_day'];h=CFG['infusion_h']/24
    state=np.zeros(3);frames=[]
    for cycle in range(3):
        k=matrix(p,later=cycle>0 and not constant_release)[0]
        for a,b,rate in [(0,h,amount/h),(h,tau,0)]:
            t=np.linspace(a,b,41 if a==0 else 301)
            sol=solve_ivp(lambda tt,x:k@x+np.array([rate,0,0]),(a,b),state,
                          t_eval=t,rtol=1e-10,atol=1e-10)
            assert sol.success;state=sol.y[:,-1]
            frames.append(pd.DataFrame(dict(day=t+cycle*tau,cycle=cycle+1,
                adc=sol.y[0]/p['v1'][0],payload=sol.y[2]/p['v3'][0]*scale)))
    return pd.concat(frames,ignore_index=True)


def main() -> None:
    start=time.perf_counter();out=ROOT/'outputs'
    for d in ['tables','figures']:(out/d).mkdir(parents=True,exist_ok=True)
    scale=CFG['scale']['payload_source']/CFG['scale']['adc_source']
    rng=np.random.default_rng(CFG['seed']);eta=rng.normal(size=(CFG['n'],8))*np.sqrt(CFG['omega_diagonal'])
    n=CFG['n'];refw=CFG['reference']['weight'];dref=dose(CFG,refw,'mgkg');a=design_exponent(CFG)
    refp=parameters(CFG,refw,eta);refauc=auc(refp,dref,scale)
    rows=[];paired=[];typical=[]
    for w in CFG['anchors']:
        p=parameters(CFG,w,eta);p0=parameters(CFG,w)
        unit=metrics(p,1,CFG['tau_day'],CFG['infusion_h']/24,scale)
        for policy in POLICIES:
            d=dose(CFG,w,policy);m0=metrics(p0,d,CFG['tau_day'],CFG['infusion_h']/24,scale)
            typical.append(dict(weight=w,policy=policy,dose_mg=d,adc_auc=float(m0['auc'][0,0]),payload_auc=float(m0['auc'][0,1]),adc_cmax=float(m0['cmax'][0,0]),payload_cmax=float(m0['cmax'][0,1])))
            for j,analyte in enumerate(['adc','payload']):
                for endpoint in ['auc','cmax','cmin']:
                    value=unit[endpoint][:,j]*d
                    rows.append(dict(weight=w,policy=policy,dose_mg=d,analyte=analyte,endpoint=endpoint,n=n,**quantiles(value)))
                ratio=unit['auc'][:,j]*d/refauc[:,j]
                paired.append(dict(weight=w,policy=policy,analyte=analyte,endpoint='auc',**quantiles(ratio)))
    pd.DataFrame(rows).to_csv(out/'tables/conditional-exposures.csv',index=False)
    pd.DataFrame(paired).to_csv(out/'tables/paired-auc-ratios.csv',index=False)
    pd.DataFrame(typical).to_csv(out/'tables/typical.csv',index=False)

    # Nominal slope identity, plus finite marginal-bootstrap corner sensitivity.
    combinations=[dict(zip(CFG['weight_slope_ci95'],x)) for x in itertools.product(*CFG['weight_slope_ci95'].values())]
    combinations.append({k:CFG['slopes'][k] for k in CFG['weight_slope_ci95']})
    sens=[]
    for i,b in enumerate(combinations):
        target_adc=b['cl_bw'];target_pay=b['cl_bw']-b['v1_bw']-b['rat_bw']
        for policy in POLICIES:
            ratio=[]
            for w in CFG['anchors']:
                wr=w/refw;dr=dose(CFG,w,policy)/dref
                ratio.extend([dr*wr**(-target_adc),dr*wr**(-target_pay)])
            sens.append(dict(scenario=i,nominal=i==8,policy=policy,**b,
                 adc_flatten_exponent=target_adc,payload_flatten_exponent=target_pay,
                 maximum_absolute_log_ratio=max(abs(np.log(ratio))),
                 minimum_ratio=min(ratio),maximum_ratio=max(ratio)))
    pd.DataFrame(sens).to_csv(out/'tables/coefficient-corners.csv',index=False)

    cov_rows=[];ref0=parameters(CFG,refw);refa=auc(ref0,dref,scale)[0]
    for name,cov in [('reference',{}),('albumin32',{'albumin':32}),('AST75',{'ast':75}),('SOD149',{'sod':149})]:
        p=parameters(CFG,refw,covariates=cov);v=auc(p,dref,scale)[0]
        cov_rows.append(dict(scenario=name,adc_auc_ratio=v[0]/refa[0],payload_auc_ratio=v[1]/refa[1]))
    pd.DataFrame(cov_rows).to_csv(out/'tables/other-covariates.csv',index=False)
    benchmarks=[]
    for w,source in [(45,CFG['source_weight_benchmark']['low_adc_auc_ratio']),(82,CFG['source_weight_benchmark']['high_adc_auc_ratio'])]:
        calculated=(w/refw)**(1-CFG['slopes']['cl_bw'])
        benchmarks.append(dict(weight=w,source_reported_adc_auc_ratio=source,equation_ratio=calculated,difference_pp=(calculated-source)*100))
    pd.DataFrame(benchmarks).to_csv(out/'tables/source-benchmark.csv',index=False)

    # Cycle1 vs established later-cycle steady state: different estimands.
    traj=cycles(ref0,dref,scale);traj_constant=cycles(ref0,dref,scale,constant_release=True)
    traj['payload_if_no_release_shift']=traj_constant.payload
    traj.to_csv(out/'tables/three-cycle-profiles.csv',index=False)
    cycle_rows=[]
    for cy in [1,2,3]:
        df=traj[traj.cycle==cy]
        cycle_rows.append(dict(cycle=cy,adc_auc=float(np.trapz(df.adc,df.day)),payload_auc=float(np.trapz(df.payload,df.day)),payload_auc_no_shift=float(np.trapz(df.payload_if_no_release_shift,df.day))))
    pd.DataFrame(cycle_rows).to_csv(out/'tables/finite-cycle-aucs.csv',index=False)
    inf=[]
    for h in [.5,1.5,3]:
        m=metrics(ref0,dref,21,h/24,scale)
        inf.append(dict(infusion_h=h,adc_auc=float(m['auc'][0,0]),payload_auc=float(m['auc'][0,1]),adc_cmax=float(m['cmax'][0,0]),payload_cmax=float(m['cmax'][0,1])))
    pd.DataFrame(inf).to_csv(out/'tables/infusion-sensitivity.csv',index=False)

    # Original figure1: paired normalized AUC, same covariates and eta.
    weights=np.linspace(45,82,200);fig,axs=plt.subplots(1,2,figsize=(10,4.1),sharex=True,sharey=True)
    targets=[CFG['slopes']['cl_bw'],CFG['slopes']['cl_bw']-CFG['slopes']['v1_bw']-CFG['slopes']['rat_bw']]
    for ax,target,title in zip(axs,targets,['Intact ADC','Released payload']):
        for policy in POLICIES:
            ratios=np.array([dose(CFG,w,policy)/dref*(w/refw)**(-target) for w in weights])
            ax.plot(weights,ratios,label=LABELS[policy],color=COLORS[policy],ls=STYLES[policy],lw=2)
        ax.axhline(1,color='#4B5563',lw=.8);ax.set(xlabel='Weight (kg)',title=title,ylim=(.75,1.3),ylabel='AUC ratio vs same model at 60.6 kg')
    axs[1].legend(fontsize=8,loc='upper right');fig.suptitle('Weight-policy AUC comparisons, Q3W (reference 290.88 mg)',fontsize=12)
    fig.text(.08,.01,'Fixed covariates; paired eta cancels in these ratios. All alternatives are hypothetical.',fontsize=9)
    fig.tight_layout(rect=(0,.06,1,.94));fig.savefig(out/'figures/01-weight-policies.png',dpi=150);plt.close(fig)

    # Figure2: finite scenario ranges plus uncorrected covariates.
    sdf=pd.DataFrame(sens);fig,axs=plt.subplots(1,2,figsize=(10,4.6),gridspec_kw={'width_ratios':[1.2,1]})
    for i,policy in enumerate(POLICIES):
        sub=sdf[sdf.policy==policy];v=sub[sub.nominal].iloc[0].maximum_absolute_log_ratio
        axs[0].hlines(3-i,sub.maximum_absolute_log_ratio.min(),sub.maximum_absolute_log_ratio.max(),color=COLORS[policy],lw=2)
        axs[0].plot(v,3-i,'o',color=COLORS[policy])
    axs[0].set(yticks=[3,2,1,0],yticklabels=[LABELS[p] for p in POLICIES],xlabel='Max |log(AUC ratio)|, 2 analytes, 45-82 kg',title='Marginal-coefficient corner sensitivity',xlim=(0,.4))
    for i,row in enumerate(cov_rows[1:]):
        axs[1].plot(row['adc_auc_ratio'],2-i,'o',color='#2463A6',label='ADC' if i==0 else None)
        axs[1].plot(row['payload_auc_ratio'],2-i,'s',mfc='none',mec='#C36B24',label='Payload' if i==0 else None)
    axs[1].axvline(1,color='#4B5563',ls=':');axs[1].set(yticks=[2,1,0],yticklabels=['Albumin 32 g/L','AST 75 U/L','SOD 149 mm'],xlabel='AUC ratio at reference weight',xlim=(.85,1.3),title='One covariate varied at a time');axs[1].legend(fontsize=9)
    fig.text(.08,.01,'Left: dots nominal, lines finite-grid extrema, NOT confidence intervals. Right: no joint patient distribution.',fontsize=8.5)
    fig.tight_layout(rect=(0,.06,1,1));fig.savefig(out/'figures/02-uncertainty-covariates.png',dpi=150);plt.close(fig)

    # Figure3: source-defined step change applies to total remaining central ADC.
    fig,axs=plt.subplots(2,1,figsize=(9,6),sharex=True)
    axs[0].plot(traj.day,traj.adc,color='#2463A6');axs[0].set(ylabel='ADC (ug/mL)',title='Reference 4.8 mg/kg Q3W: no prior dose at day 0',ylim=(0,None))
    axs[1].plot(traj.day,traj.payload,color='#2463A6',label='Published release factor: 1 then 0.693')
    axs[1].plot(traj.day,traj.payload_if_no_release_shift,color='#C36B24',ls='--',label='Hypothetical: no release-factor change')
    axs[1].set(ylabel='Payload (ng/mL)\nconditional source-scale reconstruction',xlabel='Time since first dose (day)',ylim=(0,None))
    axs[1].legend(fontsize=8.5,loc='lower left',bbox_to_anchor=(0,1.02),frameon=False)
    for ax in axs:
        for t in [21,42]:ax.axvline(t,color='#4B5563',ls=':',lw=.8)
    fig.text(.09,.01,'Fixed reference covariates, 90-min infusion assumed. Payload absolute scale reconstructed from supplement S1/S3.',fontsize=8)
    fig.tight_layout(rect=(0,.04,1,1),h_pad=3.8);fig.savefig(out/'figures/03-cycle-release.png',dpi=150);plt.close(fig)

    results=dict(n=n,seed=CFG['seed'],design_exponent=a,payload_output_factor=scale,
                 typical=typical,conditional=rows,paired=paired,other_covariates=cov_rows,
                 source_benchmark=benchmarks,finite_cycles=cycle_rows)
    results['sensitivity_summary']={p:dict(min=float(sdf[sdf.policy==p].maximum_absolute_log_ratio.min()),max=float(sdf[sdf.policy==p].maximum_absolute_log_ratio.max()),nominal=float(sdf[(sdf.policy==p)&sdf.nominal].maximum_absolute_log_ratio.iloc[0])) for p in POLICIES}
    (out/'results.json').write_text(json.dumps(results,indent=2)+'\n',encoding='utf-8')
    env=dict(python=platform.python_version(),numpy=np.__version__,pandas=pd.__version__,scipy=scipy.__version__,matplotlib=matplotlib.__version__)
    (out/'environment.json').write_text(json.dumps(env,indent=2)+'\n',encoding='utf-8')
    raw=ROOT/'data/raw'
    if raw.exists():(out/'source-hashes.json').write_text(json.dumps({f.name:hashlib.sha256(f.read_bytes()).hexdigest() for f in raw.iterdir() if f.is_file()},indent=2)+'\n',encoding='utf-8')
    print(json.dumps(dict(n=n,runtime_s=round(time.perf_counter()-start,2),tables=len(list((out/'tables').glob('*.csv'))),design_exponent=a,reference=typical[4:8],covariates=cov_rows,sensitivity=results['sensitivity_summary']),indent=2))


if __name__=='__main__':main()
