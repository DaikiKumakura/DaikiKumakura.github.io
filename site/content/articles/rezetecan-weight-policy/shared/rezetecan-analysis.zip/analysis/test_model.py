"""Independent checks of forcing, infusion, units and dose-policy algebra."""
import json
from pathlib import Path
import unittest
import numpy as np
from scipy.integrate import quad,solve_ivp
from scipy.linalg import expm
from model import parameters,dose,design_exponent,matrix,auc,steady_profile,metrics

CFG=json.loads((Path(__file__).parent/'inputs.json').read_text())
SCALE=CFG['scale']['payload_source']/CFG['scale']['adc_source']


class ModelTests(unittest.TestCase):
    def setUp(self):
        self.p=parameters(CFG,60.6);self.d=290.88;self.tau=21;self.h=1.5/24

    def test_steady_expm(self):
        k=matrix(self.p)[0];b=np.array([self.d/self.h,0,0])
        end=np.linalg.solve(k,(expm(k*self.h)-np.eye(3))@b)
        before=np.linalg.solve(np.eye(3)-expm(k*self.tau),expm(k*(self.tau-self.h))@end)
        for t in [0,.02,self.h,.2,4,21]:
            x=expm(k*t)@before
            if t<=self.h:x+=np.linalg.solve(k,(expm(k*t)-np.eye(3))@b)
            else:x+=expm(k*(t-self.h))@end
            c=np.array([x[0]/2.86,x[2]/30*SCALE])
            np.testing.assert_allclose(steady_profile(self.p,self.d,np.array([t]),21,self.h,SCALE)[0,0],c,rtol=1e-8,atol=1e-8)

    def test_steady_ode(self):
        k=matrix(self.p)[0];b=np.array([self.d/self.h,0,0]);end=np.linalg.solve(k,(expm(k*self.h)-np.eye(3))@b)
        before=np.linalg.solve(np.eye(3)-expm(k*21),expm(k*(21-self.h))@end)
        def independent(rate):
            def rhs(t,x):
                ac,ap,y=x;cl=.36;v1=2.86;q=.162;v2=2.88;flow=q*(ac/v1-ap/v2)
                return [rate-cl/v1*ac-flow,flow,.814*.693*ac-392/30*y]
            return rhs
        first=solve_ivp(independent(self.d/self.h),(0,self.h),before,rtol=1e-10,atol=1e-10)
        t=np.array([self.h,.25,1,5,21]);last=solve_ivp(independent(0),(self.h,21),first.y[:,-1],t_eval=t,rtol=1e-10,atol=1e-10)
        c=np.column_stack([last.y[0]/2.86,last.y[2]/30*SCALE])
        np.testing.assert_allclose(steady_profile(self.p,self.d,t,21,self.h,SCALE)[0],c,rtol=1e-7,atol=1e-7)

    def test_steady_integral(self):
        expected=auc(self.p,self.d,SCALE)[0]
        for j in [0,1]:
            val=quad(lambda t:steady_profile(self.p,self.d,np.array([t]),21,self.h,SCALE)[0,0,j],0,21,points=[self.h],epsabs=1e-7)[0]
            self.assertAlmostEqual(val,expected[j],places=5)

    def test_no_payload_depletion_of_adc(self):
        a=steady_profile(self.p,self.d,np.array([0,1,21]),21,self.h,SCALE)
        changed={k:v.copy() for k,v in self.p.items()};changed['rat']*=2
        b=steady_profile(changed,self.d,np.array([0,1,21]),21,self.h,SCALE)
        np.testing.assert_allclose(a[:,:,0],b[:,:,0]);np.testing.assert_allclose(2*a[:,:,1],b[:,:,1])

    def test_dose_linearity(self):
        t=np.linspace(0,21,100)
        a=steady_profile(self.p,100,t,21,self.h,SCALE);b=steady_profile(self.p,200,t,21,self.h,SCALE)
        np.testing.assert_allclose(b,2*a)

    def test_periodicity(self):
        a=steady_profile(self.p,self.d,np.array([0,21]),21,self.h,SCALE)[0]
        np.testing.assert_allclose(a[0],a[1],rtol=1e-10)

    def test_weight_identity(self):
        rng=np.random.default_rng(8);eta=rng.normal(size=(32,8))*np.sqrt(CFG['omega_diagonal'])
        ref=auc(parameters(CFG,60.6,eta),self.d,SCALE)
        for w in [45,82]:
            r=auc(parameters(CFG,w,eta),dose(CFG,w,'power'),SCALE)/ref
            np.testing.assert_allclose(r[:,0],(w/60.6)**.001)
            np.testing.assert_allclose(r[:,1],(w/60.6)**(-.001))
        self.assertAlmostEqual(design_exponent(CFG),.526)

    def test_source_units(self):
        # mmol state inferred to match ADC mg/L; source S1 and S3 transformations.
        normalized=np.array([15,3,2.0]);molar=normalized/151000
        self.assertAlmostEqual(normalized[0]/2.86,molar[0]/(2.86/151000))
        self.assertAlmostEqual(normalized[2]/30*SCALE,molar[2]/(30/533560))

    def test_cycle_release_factor(self):
        x=auc(self.p,self.d,SCALE,later=False);y=auc(self.p,self.d,SCALE,later=True)
        self.assertAlmostEqual(y[0,0]/x[0,0],1)
        self.assertAlmostEqual(y[0,1]/x[0,1],.693)

    def test_peak_grid(self):
        # Independent dense grid for conditional peak qualification.
        t=np.unique(np.r_[np.linspace(0,1,2001),np.linspace(1,21,1001),self.h])
        dense=steady_profile(self.p,self.d,t,21,self.h,SCALE).max(axis=1)
        approx=metrics(self.p,self.d,21,self.h,SCALE)['cmax']
        self.assertLess(np.max(abs(approx/dense-1)),.001)


if __name__=='__main__':unittest.main()
