# Trastuzumab rezetecan weight-policy analysis

Public research, not treatment or clinical-trial dose advice.
Use an existing Python environment with requirements.txt packages:
  python analysis/run_analysis.py
  python -m unittest discover -s analysis -p "test_*.py" -q
No downloads/accounts required. Numeric facts in analysis/inputs.json.

Primary Gao et al.2026 DOI10.1002/psp4.70259, finalTable1, sections3.2-3.5,
supplementTablesS1-S3 and Final model code. These are same-drug public estimated
coefficients reused, NOT a new individual NLME fit. Supplement THETA entries
are initial estimates, not substituted for mainTable1 final estimates.
Source publication/source figures/control stream/data are not redistributed.

ADC linear2comp plus empirical payload forcing krel*Acentral. No extra CL or
DAR multiplier; no additional loss ofADC for payload formation. Not stoichiometric
mass balance. Krel=RAT forCycle1 andRAT*ALPHA afterCycle1, applied to remaining
ADC too. The source outputscales S1=V1/151000 andS3=V3/533560 imply
ADCmg/L=ug/mL and conditionalpayloadng/mL factor533560/151000 with our ADCmg
states. The input AMTpreprocessing is not public: this is a unit reconstruction
consistent with the source ADCscale, not direct inspection of the original
modeling data. Normalized policy ratios are independent of the commonfactor.

Reference60.6kg,56years,ALB42.5g/L,SOD52mm,AST25U/L,NSCLC.8independent
lognormaletas, source diagonalOmega(.0591,.0408,.0798,.546,.0419,.0692,.140,.146),
4096paired draws seed20261021. No covariatejointdistribution, individualrecords,
residualobservationerror, time-varyingweight or doseinterruption reproduced.
IIVvariances are not the RSEpercentages in Table1. V3typical fixed30L still
has source IIV. Referencecovariates do not define a representative population.

Q3W4.8mg/kg source comparison versus hypotheticalfixed290.88mg,
powerDref*(W/60.6)^.526, and70kgcap. No rounding/compounding feasibility assumed.
90min constant infusion is standardized analyst assumption, with30/180min
sensitivity. SteadyAUC independent of infusion. Weights45-82kg are published
5th-95thpercentiles, not the full36.4-138kgdataset. Bodyweightflattening is
not improvement in clinical outcomes; source authors recommend no covariate
dose change for their studiedpopulation. Nominal .526 is the midpoint of
two algebraic flatteningtargets .525/.527, NOT a fitted clinical optimum.

8corners of marginalbootstrap95%weightcoefficient intervals plus centralpoint
are scenarios, not joint95%CI or a probabilitydistribution. No probability
that a policy is clinicallybest. IIVpercentiles are not confidenceintervals.
Paired AUC ratios cancel etas by construction; apparent precision does not
mean actual patientmatching. ALB32,AST75,SOD149 varied separately atfixedweight,
not jointpatientstrata or causal effects of changing biomarkers.

Publishedweightforest ratios .858/1.168 vs our fixed-covariate equation
.868/1.154 differ1.02/-1.35percentagepoints. No parameters tuned to closegap;
cause unresolved without originalpopulation/simulationrecords. This is not
exact externalvalidation. OriginalhighpayloadCmaxunderprediction remains
relevant. No exposure-risk or tumorresponse coefficient imported or fitted.
No ORR/ILD/hematologictoxicity, intratumoral delivery or efficacy preservation
prediction; lowered bloodstream payload does not prove a better regimen.

Scripts regenerate9CSV,3originalPNG andresults.json. Rawsourcehashes record
the consulted snapshot, not new sourceverification; raworiginals absent inZIP.
Original code MIT, source numericfacts attributed. Private planning/reviews
are not included. See article for interpretation and full source links.
