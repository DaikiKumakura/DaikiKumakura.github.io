import sys
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))
from exposure_audit import auc_to_ng_hour, dar_conversion_ratio, percent_difference, window_average


class ExposureAuditTests(unittest.TestCase):
    def test_mass_and_time_conversion(self):
        self.assertEqual(auc_to_ng_hour(671, "ug*day/mL"), 16104000)
        self.assertEqual(auc_to_ng_hour(18, "ng*day/mL"), 432)

    def test_current_sg_week_average(self):
        self.assertAlmostEqual(window_average(3510, 168), 20.892857142857)

    def test_missing_window_is_rejected(self):
        with self.assertRaises(ValueError):
            window_average(432, None)

    def test_invalid_units_are_rejected(self):
        with self.assertRaises(ValueError):
            auc_to_ng_hour(1, "mg/kg")

    def test_invalid_reference_is_rejected(self):
        with self.assertRaises(ValueError):
            percent_difference(1, 0)

    def test_constant_dar_equality(self):
        self.assertEqual(dar_conversion_ratio([8, 8], [.5, .5]), 1)

    def test_weighted_inverse_not_inverse_mean(self):
        result = dar_conversion_ratio([8, 2], [.5, .5])
        self.assertEqual(result, 2.5)
        self.assertNotEqual(result, 8 / 5)

    def test_dar_and_weights_limits(self):
        self.assertEqual(dar_conversion_ratio([1], [1]), 8)
        for dar, weights in [([0], [1]), ([8], [.5]), ([8], [-1])]:
            with self.assertRaises(ValueError):
                dar_conversion_ratio(dar, weights)

    def test_nonfinite_dar_reference_rejected(self):
        for reference in [float("nan"), float("inf")]:
            with self.assertRaises(ValueError):
                dar_conversion_ratio([8], [1], reference)


if __name__ == "__main__":
    unittest.main()
