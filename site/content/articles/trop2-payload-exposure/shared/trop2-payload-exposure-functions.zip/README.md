# Before comparing TROP2 ADC exposure: why a reported AUC changed

Analysis functions and unit checks accompanying the cited article.
This is a compact function companion, not the full raw-data analysis. No patient data or source PDFs are included.
The article identifies the public data and the limits of each calculation.

From this extracted directory, with Python and numpy/scipy/pandas installed:

```sh
python -m unittest discover -s tests -p "test_*.py"
```

Tests use constructed fixtures and numerical checks; they do not establish clinical validity.
