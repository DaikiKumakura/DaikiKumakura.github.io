"""Definition-aware audit; no efficacy or pharmacokinetic fitting."""
from __future__ import annotations

import math
from typing import Sequence


def auc_to_ng_hour(value: float, unit: str) -> float:
    """Convert dimensions, without assuming an integration interval."""
    factors = {"ng*h/mL": 1.0, "ng*day/mL": 24.0, "ug*day/mL": 24000.0}
    if unit not in factors or not math.isfinite(value) or value < 0:
        raise ValueError("Invalid AUC value or unit")
    return value * factors[unit]


def percent_difference(new: float, old: float) -> float:
    if not math.isfinite(new) or not math.isfinite(old) or old <= 0 or new < 0:
        raise ValueError("Finite nonnegative values and a positive reference required")
    return 100.0 * (new / old - 1.0)


def window_average(auc: float, interval_hours: float | None) -> float:
    if interval_hours is None or not math.isfinite(interval_hours) or interval_hours <= 0:
        raise ValueError("An explicitly documented integration interval is required")
    if not math.isfinite(auc) or auc < 0:
        raise ValueError("Invalid AUC")
    return auc / interval_hours


def dar_conversion_ratio(dar: Sequence[float], weights: Sequence[float], reference: float = 8.0) -> float:
    """Algebraic concentration-weighted ratio, not a fitted patient AUC ratio.

    weights represent fractions of conjugated payload integrated exposure.
    C_old = C_conj/reference; C_new = C_conj/DAR(t), in molar units.
    """
    if len(dar) != len(weights) or not dar or not math.isfinite(reference) or reference <= 0:
        raise ValueError("Matched nonempty vectors and positive reference required")
    if any(not math.isfinite(x) or x < 1 for x in dar):
        raise ValueError("DAR must be finite and at least one")
    if any(not math.isfinite(x) or x < 0 for x in weights):
        raise ValueError("Weights must be finite and nonnegative")
    if not math.isclose(sum(weights), 1.0, abs_tol=1e-10):
        raise ValueError("Weights must sum to one")
    return reference * sum(w / d for d, w in zip(dar, weights))
