"""Figures for M01. Run after analysis.py: python figures.py"""
from pathlib import Path

import matplotlib
import matplotlib.ticker
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parent
R, F = ROOT / "results", ROOT / "figures"
C960, C240, CHOLD, GREY = "#1f5aa6", "#c2571a", "#9aa0a6", "#4d4d4d"
plt.rcParams.update({"font.size": 10, "axes.spines.top": False, "axes.spines.right": False})


def fig1():
    s = pd.read_csv(R / "posterior_summary.csv")
    h = pd.read_csv(R / "hazard_ratio_context.csv")
    fig, (a, b) = plt.subplots(1, 2, figsize=(9.2, 3.8), gridspec_kw={"width_ratios": [1.5, 1]})
    order = ["dORR (2023-06-23)", "dORR (2023-01-18)", "dTox G3+ TRAE", "dTox G3+ TEAE",
             "dHepatotox G3+", "dTRAE discontinuation"]
    labels = ["ORR (BICR), Jun 2023", "ORR (BICR), Jan 2023", "Grade≥3 TRAE", "Grade≥3 TEAE",
              "Grade≥3 hepatotoxicity", "TRAE → discontinuation"]
    main = {"dORR (2023-06-23)", "dTox G3+ TRAE"}
    for i, (k, lab) in enumerate(zip(order, labels)):
        r = s[s.estimand == k].iloc[0]
        y = len(order) - 1 - i
        col = C960 if k.startswith("dORR") else C240
        lw, ms = (2.4, 7) if k in main else (1.2, 4.5)
        a.plot([100 * r.post_lo, 100 * r.post_hi], [y, y], color=col, lw=lw)
        a.plot(100 * r.post_mean, y, "o", color=col, ms=ms)
        a.text(31, y, f"{100*r.post_mean:+.1f} ({100*r.post_lo:+.1f}, {100*r.post_hi:+.1f})",
               va="center", fontsize=8.5, color=GREY)
    a.axvline(0, color=GREY, lw=0.8)
    a.set_yticks(range(len(order)), labels[::-1])
    a.set_xlim(-15, 52)
    a.set_xlabel("960 mg − 240 mg (percentage points)\nposterior mean and 95% interval")
    a.set_title("A. Group differences (blue = benefit, orange = harm)", loc="left", fontsize=10)
    hh = h.iloc[::-1].reset_index(drop=True)
    for y, r in hh.iterrows():
        a2 = b
        a2.plot([r.lo, r.hi], [y, y], color=GREY, lw=1.8)
        a2.plot(r.hr, y, "s", color=GREY, ms=6)
    b.axvline(1, color=GREY, lw=0.8, ls="--")
    b.set_xscale("log")
    b.set_xticks([0.5, 0.75, 1, 1.5], ["0.5", "0.75", "1", "1.5"])
    b.xaxis.set_minor_formatter(matplotlib.ticker.NullFormatter())
    b.set_yticks(range(len(hh)), [f"{e.replace('_BICR','')} ({c[:7]})" for e, c in zip(hh.endpoint, hh.cutoff)])
    b.set_xlabel("Hazard ratio, 960 vs 240 mg\n(reported stratified Cox, 95% CI)")
    b.set_title("B. Time-to-event (context only)", loc="left", fontsize=10)
    fig.tight_layout()
    fig.savefig(F / "fig1_group_differences.png", dpi=200)


def fig2():
    sc = pd.read_csv(R / "decision_by_weight.csv")
    g = sc[sc.scenario == "Main"]
    fig, ax = plt.subplots(figsize=(7.2, 3.9))
    col = {"960": C960, "hold": CHOLD, "240": C240}
    for lab in ("960", "hold", "240"):
        m = g.label == lab
        if m.any():
            ax.axvspan(g.w[m].min() - 0.025, g.w[m].max() + 0.025, color=col[lab], alpha=0.12, lw=0)
    ax.plot(g.w, g.p_u_pos, color="black", lw=2)
    ax.axhline(0.8, color=C960, lw=0.9, ls="--")
    ax.axhline(0.2, color=C240, lw=0.9, ls="--")
    ax.text(0.02, 0.83, "P ≥ 0.80 → 960 mg", color=C960, fontsize=8.5)
    ax.text(2.3, 0.23, "P ≤ 0.20 → 240 mg", color=C240, fontsize=8.5)
    ax.text(0.55, 0.55, "hold", color=GREY, fontsize=10)
    ax.set_xlabel("w: extra responses demanded per extra Grade≥3 TRAE")
    ax.set_ylabel("P(ΔORR − w·ΔTox > 0)")
    ax.set_ylim(0, 1)
    ax.set_xlim(0, 3)
    ax.set_title("Decision regions by benefit–harm weight (main analysis)", loc="left", fontsize=10)
    fig.tight_layout()
    fig.savefig(F / "fig2_decision_by_weight.png", dpi=200)


def fig3():
    sc = pd.read_csv(R / "decision_by_weight.csv")
    names = list(dict.fromkeys(sc.scenario))
    fig, ax = plt.subplots(figsize=(7.6, 4.6))
    col = {"960": C960, "hold": CHOLD, "240": C240}
    for i, n in enumerate(names):
        g = sc[sc.scenario == n]
        y = len(names) - 1 - i
        for w, lab in zip(g.w, g.label):
            ax.barh(y, 0.05, left=w - 0.025, color=col[lab], height=0.7, lw=0)
    ax.set_yticks(range(len(names)), names[::-1])
    ax.set_xlim(0, 3)
    ax.set_xlabel("w: extra responses demanded per extra harm event")
    from matplotlib.patches import Patch
    ax.legend(handles=[Patch(color=C960, label="favour 960 mg"), Patch(color=CHOLD, label="hold"),
                       Patch(color=C240, label="favour 240 mg")], loc="upper center", bbox_to_anchor=(0.5, -0.16), ncol=3, fontsize=8, frameon=False)
    ax.set_title("Sensitivity of decision regions", loc="left", fontsize=10)
    fig.tight_layout()
    fig.savefig(F / "fig3_sensitivity.png", dpi=200)


if __name__ == "__main__":
    F.mkdir(exist_ok=True)
    fig1(); fig2(); fig3()
    print("figures written")
