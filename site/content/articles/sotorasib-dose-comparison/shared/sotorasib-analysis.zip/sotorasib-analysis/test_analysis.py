"""Unit checks for analysis.py. Run: python -m pytest -q  (or python test_analysis.py)"""
import numpy as np

import analysis as A


def test_summary_percentages_match():
    A.load_summary()  # raises on mismatch


def test_newcombe_known_value():
    # Newcombe (1998) example: 56/70 vs 48/80 -> 0.0524 to 0.3339
    lo, hi = A.newcombe_diff(56, 70, 48, 80)
    assert abs(lo - 0.0524) < 5e-4 and abs(hi - 0.3339) < 5e-4


def test_joint_table_margins_and_bounds():
    for rho in (-0.3, 0.0, 0.3, 0.99, -0.99):
        c = A.joint_table(34, 37, 104, rho)
        assert c.sum() == 104 and c[0] + c[1] == 34 and c[0] + c[2] == 37 and (c >= 0).all()


def test_joint_table_independence():
    c = A.joint_table(34, 37, 104, 0.0)
    assert c[0] == round(34 * 37 / 104)


def test_beta_draws_center():
    rng = np.random.default_rng(1)
    x = A.beta_draws(34, 104, rng)
    assert abs(x.mean() - 35 / 106) < 2e-3


def test_decision_rule():
    lab = A.decision(np.array([0.85, 0.5, 0.15]))
    assert list(lab) == ["960", "hold", "240"]


def test_scenario_monotone_in_w():
    rng = np.random.default_rng(2)
    d_orr = rng.normal(0.08, 0.06, 50_000)
    d_tox = rng.normal(0.16, 0.06, 50_000)
    p = A.scenario("t", d_orr, d_tox).p_u_pos.values
    assert np.all(np.diff(p) <= 1e-12)


def test_hr_probs_symmetric_at_one():
    r = A.hr_probs(1.0, 0.5, 2.0)
    assert abs(r["p_hr_lt_1"] - 0.5) < 1e-9


def test_schoenfeld_reference():
    # HR 0.75, 1:1, alpha 0.05 two-sided, 80% power -> about 379-380 events
    assert 378 < A.schoenfeld_events(0.75) < 381


if __name__ == "__main__":
    for k, f in list(globals().items()):
        if k.startswith("test_"):
            f()
            print("ok", k)
