"""M01: Sotorasib 960 mg vs 240 mg (CodeBreaK 100 Part B) group-level benefit-risk.

Inputs are published group summaries (data/*.csv). No patient-level data.
Run: python analysis.py  ->  results/*.csv, figures/*.png
"""
from pathlib import Path

import numpy as np
import pandas as pd
from scipy import stats

ROOT = Path(__file__).resolve().parent
DATA, RESULTS, FIGURES = ROOT / "data", ROOT / "results", ROOT / "figures"
SEED = 20261004
N_DRAWS = 200_000
W_GRID = np.round(np.arange(0, 3.0001, 0.05), 2)
THRESHOLD = 0.80


def load_summary():
    d = pd.read_csv(DATA / "group_summary.csv")
    for arm in ("960", "240"):
        recomputed = (100 * d[f"n_{arm}"] / d[f"N_{arm}"]).round(1)
        bad = d.loc[(recomputed - d[f"pct_{arm}"]).abs() > 0.05, "endpoint"]
        if len(bad):
            raise ValueError(f"percent mismatch ({arm} mg): {list(bad)}")
    return d


def row(d, endpoint, cutoff):
    r = d[(d.endpoint == endpoint) & (d.cutoff == cutoff)]
    if len(r) != 1:
        raise KeyError((endpoint, cutoff))
    r = r.iloc[0]
    return (int(r.n_960), int(r.N_960)), (int(r.n_240), int(r.N_240))


def beta_draws(x, n, rng, a0=1.0, b0=1.0, size=N_DRAWS):
    return rng.beta(x + a0, n - x + b0, size)


def newcombe_diff(x1, n1, x2, n2, z=1.959964):
    """Newcombe hybrid score interval for p1 - p2 (method 10)."""
    def wilson(x, n):
        p = x / n
        c = z * np.sqrt(p * (1 - p) / n + z**2 / (4 * n**2))
        m = (p + z**2 / (2 * n))
        return (m - c) / (1 + z**2 / n), (m + c) / (1 + z**2 / n)
    p1, p2 = x1 / n1, x2 / n2
    l1, u1 = wilson(x1, n1)
    l2, u2 = wilson(x2, n2)
    d = p1 - p2
    return d - np.sqrt((p1 - l1) ** 2 + (u2 - p2) ** 2), d + np.sqrt((u1 - p1) ** 2 + (p2 - l2) ** 2)


def joint_table(resp, tox, n, rho):
    """2x2 counts (R&T, R&notT, notR&T, neither) matching margins with correlation rho,
    clipped to Frechet bounds."""
    p, q = resp / n, tox / n
    pi11 = p * q + rho * np.sqrt(p * (1 - p) * q * (1 - q))
    pi11 = min(max(pi11, max(0.0, p + q - 1)), min(p, q))
    n11 = int(round(pi11 * n))
    cells = np.array([n11, resp - n11, tox - n11, n - resp - tox + n11])
    if (cells < 0).any() or cells.sum() != n:
        raise ValueError("invalid joint table")
    return cells


def joint_draws(cells, rng, size=N_DRAWS):
    pi = rng.dirichlet(cells + 0.5, size)
    return pi[:, 0] + pi[:, 1], pi[:, 0] + pi[:, 2]  # P(response), P(toxicity)


def decision(p_pos, threshold=THRESHOLD):
    return np.where(p_pos >= threshold, "960", np.where(1 - p_pos >= threshold, "240", "hold"))


def boundaries(w, labels):
    """w values where the decision label changes."""
    out = []
    for i in range(1, len(w)):
        if labels[i] != labels[i - 1]:
            out.append((float(w[i]), f"{labels[i-1]}->{labels[i]}"))
    return out


def scenario(name, d_orr, d_tox, threshold=THRESHOLD):
    u = d_orr[None, :] - W_GRID[:, None] * d_tox[None, :]
    p_pos = (u > 0).mean(axis=1)
    labels = decision(p_pos, threshold)
    return pd.DataFrame({"scenario": name, "w": W_GRID, "p_u_pos": p_pos,
                         "label": labels, "threshold": threshold})


def hr_probs(hr, lo, hi):
    se = (np.log(hi) - np.log(lo)) / (2 * 1.959964)
    m = np.log(hr)
    return {"se_log": se,
            "p_hr_lt_1": stats.norm.cdf((0 - m) / se),
            "p_hr_lt_0.8": stats.norm.cdf((np.log(0.8) - m) / se)}


def schoenfeld_events(hr, alpha=0.05, power=0.80, ratio=0.5):
    """Events needed to detect hr with a two-sided log-rank test (Schoenfeld)."""
    za, zb = stats.norm.ppf(1 - alpha / 2), stats.norm.ppf(power)
    return (za + zb) ** 2 / (ratio * (1 - ratio) * np.log(hr) ** 2)


def run():
    RESULTS.mkdir(exist_ok=True)
    FIGURES.mkdir(exist_ok=True)
    d = load_summary()
    tte = pd.read_csv(DATA / "time_to_event.csv")

    (r9, n9), (r2, n2) = row(d, "ORR_BICR", "2023-06-23")
    (t9, m9), (t2, m2) = row(d, "TRAE_grade3plus", "2023-01-18")

    def draws_pair(x9, N9, x2, N2, seed, a0=1.0):
        rng = np.random.default_rng(seed)
        return beta_draws(x9, N9, rng, a0, a0) - beta_draws(x2, N2, rng, a0, a0)

    d_orr = draws_pair(r9, n9, r2, n2, SEED)
    d_tox = draws_pair(t9, m9, t2, m2, SEED + 1)

    # posterior summaries vs Newcombe
    summ = []
    specs = [("dORR (2023-06-23)", "ORR_BICR", "2023-06-23"),
             ("dORR (2023-01-18)", "ORR_BICR", "2023-01-18"),
             ("dTox G3+ TRAE", "TRAE_grade3plus", "2023-01-18"),
             ("dTox G3+ TEAE", "TEAE_grade3plus", "2023-01-18"),
             ("dTRAE discontinuation", "TRAE_discontinuation", "2023-01-18"),
             ("dHepatotox G3+", "hepatotoxicity_grade3plus", "2023-01-18")]
    for i, (lab, ep, cut) in enumerate(specs):
        (x9, N9), (x2, N2) = row(d, ep, cut)
        dr = draws_pair(x9, N9, x2, N2, SEED + 10 + i)
        lo, hi = newcombe_diff(x9, N9, x2, N2)
        summ.append(dict(estimand=lab, obs_diff=x9 / N9 - x2 / N2,
                         post_mean=dr.mean(), post_lo=np.quantile(dr, .025),
                         post_hi=np.quantile(dr, .975), p_gt0=(dr > 0).mean(),
                         newcombe_lo=lo, newcombe_hi=hi))
    summ = pd.DataFrame(summ)

    # scenarios
    sc = [scenario("Main", d_orr, d_tox)]
    sc.append(scenario("SA1 Jeffreys prior", draws_pair(r9, n9, r2, n2, SEED, .5),
                       draws_pair(t9, m9, t2, m2, SEED + 1, .5)))
    (a9, an9), _ = row(d, "ORR_BICR", "2023-01-18")
    sc.append(scenario("SA2 ORR 2023-01-18", draws_pair(a9, an9, r2, n2, SEED + 2), d_tox))
    (e9, en9), (e2, en2) = row(d, "TEAE_grade3plus", "2023-01-18")
    sc.append(scenario("SA3 harm = G3+ TEAE", d_orr, draws_pair(e9, en9, e2, en2, SEED + 3)))
    (c9, cn9), (c2, cn2) = row(d, "TRAE_discontinuation", "2023-01-18")
    sc.append(scenario("SA4 harm = TRAE discontinuation", d_orr, draws_pair(c9, cn9, c2, cn2, SEED + 4)))
    # SA5: within-arm correlation; common denominator = safety set (240 mg: the undosed
    # randomized patient is treated as a non-responder, so 26 responders among 104).
    for rho in (-0.3, 0.0, 0.3):
        rng = np.random.default_rng(SEED + 5)
        o9, x9 = joint_draws(joint_table(r9, t9, m9, rho), rng)
        o2, x2 = joint_draws(joint_table(r2, t2, m2, rho), rng)
        sc.append(scenario(f"SA5 rho={rho:+.1f}", o9 - o2, x9 - x2))
    sc.append(scenario("SA6 threshold 0.90", d_orr, d_tox, threshold=0.90))
    sc = pd.concat(sc, ignore_index=True)

    bnd = []
    for name, g in sc.groupby("scenario", sort=False):
        b = boundaries(g.w.values, g.label.values)
        bnd.append(dict(scenario=name, boundaries="; ".join(f"w={w:.2f} {t}" for w, t in b) or "none",
                        label_at_w0=g.label.iloc[0], label_at_w1=g[g.w == 1].label.iloc[0],
                        p_u_pos_w1=float(g[g.w == 1].p_u_pos.iloc[0])))
    bnd = pd.DataFrame(bnd)

    hr = []
    for _, r in tte.iterrows():
        hr.append(dict(endpoint=r.endpoint, cutoff=r.cutoff, hr=r.hr_960_vs_240,
                       lo=r.hr_lo, hi=r.hr_hi, **hr_probs(r.hr_960_vs_240, r.hr_lo, r.hr_hi)))
    hr = pd.DataFrame(hr)
    hr["events_observed_approx"] = 4 / hr.se_log ** 2
    hr["events_for_80pct_power_at_this_hr"] = [schoenfeld_events(x) for x in hr.hr]

    summ.to_csv(RESULTS / "posterior_summary.csv", index=False, float_format="%.4f")
    sc.to_csv(RESULTS / "decision_by_weight.csv", index=False, float_format="%.4f")
    bnd.to_csv(RESULTS / "decision_boundaries.csv", index=False, float_format="%.4f")
    hr.to_csv(RESULTS / "hazard_ratio_context.csv", index=False, float_format="%.4f")
    return summ, sc, bnd, hr


if __name__ == "__main__":
    s, sc, b, h = run()
    with pd.option_context("display.width", 200, "display.max_columns", 20):
        print(s.round(3).to_string(index=False))
        print(b.to_string(index=False))
        print(h.round(3).to_string(index=False))
