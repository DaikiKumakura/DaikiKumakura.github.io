# Sotorasib 960 mg vs 240 mg: group-level benefit-risk

Inputs: published group summaries of CodeBreaK 100 phase 2 Part B (data/*.csv), with source and page in each row.
No patient-level data. Source PDFs are not redistributed; see the URLs in the article.

    pip install numpy scipy pandas matplotlib
    python test_analysis.py   # 9 checks
    python analysis.py        # results/*.csv
    python figures.py         # figures/*.png

Tested with Python 3.12.4, numpy 1.26.4, scipy 1.14.0, pandas 2.2.2, matplotlib 3.9.1. Seed 20261004.
For research and education. Not a dosing recommendation.
