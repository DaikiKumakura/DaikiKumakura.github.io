"""Download IC50 activities with a pChEMBL value for 15 targets from the ChEMBL REST API.

Files are written once to inputs/ and pinned by SHA-256 in input-provenance.json.
"""
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
import gzip
import hashlib
import json
import time

import pandas as pd
import requests

ROOT = Path(__file__).resolve().parent
API = "https://www.ebi.ac.uk/chembl/api/data"
TARGETS = {
    "CHEMBL203": "EGFR", "CHEMBL1862": "ABL1", "CHEMBL2971": "JAK2", "CHEMBL301": "CDK2",
    "CHEMBL5145": "BRAF", "CHEMBL4822": "BACE1", "CHEMBL204": "thrombin", "CHEMBL244": "FXa",
    "CHEMBL325": "HDAC1", "CHEMBL3105": "PARP1", "CHEMBL284": "DPP4", "CHEMBL240": "hERG",
    "CHEMBL279": "VEGFR2", "CHEMBL1824": "HER2", "CHEMBL4005": "PI3Ka",
}
FIELDS = ["activity_id", "molecule_chembl_id", "document_chembl_id", "assay_chembl_id", "src_id",
          "document_year", "standard_type", "standard_relation", "standard_value", "standard_units",
          "pchembl_value", "data_validity_comment", "potential_duplicate"]


def get(url, params):
    for attempt in range(6):
        try:
            r = requests.get(url, params=params, timeout=120)
            r.raise_for_status()
            return r.json()
        except requests.RequestException:
            time.sleep(5 * (attempt + 1))
    raise RuntimeError(f"failed: {url} {params}")


def fetch(target):
    dest = ROOT / "inputs" / f"{target}.csv.gz"
    if not dest.exists():
        rows, offset = [], 0
        while True:
            page = get(f"{API}/activity.json", {
                "target_chembl_id": target, "standard_type": "IC50", "pchembl_value__isnull": "false",
                "only": ",".join(FIELDS), "limit": 1000, "offset": offset, "order_by": "activity_id"})
            rows += page["activities"]
            total = page["page_meta"]["total_count"]
            offset += 1000
            if offset >= total:
                break
        df = pd.DataFrame(rows, columns=FIELDS)
        assert len(df) == total and df.activity_id.is_unique, target
        with gzip.GzipFile(dest, "wb", mtime=0) as fh:
            fh.write(df.to_csv(index=False, lineterminator="\n").encode("utf-8"))
    return {"target": target, "path": f"inputs/{target}.csv.gz",
            "sha256": hashlib.sha256(dest.read_bytes()).hexdigest()}


def main():
    (ROOT / "inputs").mkdir(exist_ok=True)
    prov_path = ROOT / "input-provenance.json"
    pinned = json.loads(prov_path.read_text(encoding="utf-8")) if prov_path.exists() else None
    with ThreadPoolExecutor(max_workers=4) as pool:
        records = list(pool.map(fetch, TARGETS))
    if pinned:
        expected = {r["target"]: r["sha256"] for r in pinned["files"]}
        for r in records:
            assert r["sha256"] == expected[r["target"]], f"checksum mismatch: {r['target']}"
        print("inputs match pinned checksums")
        return
    status = get(f"{API}/status.json", {})
    prov_path.write_text(json.dumps({
        "source": API, "chembl_db_version": status["chembl_db_version"],
        "chembl_release_date": status["chembl_release_date"], "retrieved": time.strftime("%Y-%m-%d"),
        "licence": "CC BY-SA 3.0 (ChEMBL)", "query": "standard_type=IC50, pchembl_value not null",
        "files": records}, indent=2) + "\n", encoding="utf-8")
    print(f"downloaded {len(records)} targets")


if __name__ == "__main__":
    main()
