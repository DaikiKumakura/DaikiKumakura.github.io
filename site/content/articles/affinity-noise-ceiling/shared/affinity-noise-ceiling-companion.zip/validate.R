# Independent re-implementation (base R) of the deterministic all-pairs summary.
# Compares with results/noise-summary.csv and writes results/validation.json.
# Run from this folder: Rscript validate.R
prov <- jsonlite::fromJSON("input-provenance.json")
raw <- do.call(rbind, lapply(seq_len(nrow(prov$files)), function(i) {
  d <- read.csv(gzfile(prov$files$path[i]), stringsAsFactors = FALSE)
  d$target <- prov$files$target[i]
  d[, c("target", "molecule_chembl_id", "document_chembl_id", "pchembl_value")]
}))
stopifnot(!anyNA(raw$pchembl_value))

key <- paste(raw$target, raw$molecule_chembl_id, raw$document_chembl_id, sep = "|")
med <- tapply(raw$pchembl_value, key, median)
parts <- do.call(rbind, strsplit(names(med), "|", fixed = TRUE))
doc <- data.frame(tm = paste(parts[, 1], parts[, 2]), p = as.numeric(med))

deltas <- unlist(lapply(split(doc$p, doc$tm), function(p) {
  if (length(p) < 2) return(NULL)
  cmb <- utils::combn(length(p), 2)
  p[cmb[1, ]] - p[cmb[2, ]]
}), use.names = FALSE)

mine <- c(n_pairs = length(deltas), sigma2 = var(deltas) / 2,
          frac_ge1 = mean(round(abs(deltas), 2) >= 1), frac_exact = mean(round(abs(deltas), 2) == 0))
ref <- read.csv("results/noise-summary.csv", check.names = FALSE)
ref <- ref[ref$variant == "all document pairs", ]
theirs <- c(n_pairs = ref$n_pairs, sigma2 = ref$sigma2, frac_ge1 = ref$frac_ge1, frac_exact = ref$frac_exact)
diff <- abs(mine - theirs)
ok <- diff["n_pairs"] == 0 && all(diff[-1] < 1e-5)
print(rbind(R = mine, Python = theirs))
jsonlite::write_json(list(status = if (ok) "pass" else "fail", method = "base R all-pairs recomputation",
                          r = as.list(mine), python = as.list(theirs), max_abs_diff = max(diff[-1])),
                     "results/validation.json", auto_unbox = TRUE, pretty = TRUE, digits = 10)
cat("validation:", if (ok) "pass" else "fail", "\n")
