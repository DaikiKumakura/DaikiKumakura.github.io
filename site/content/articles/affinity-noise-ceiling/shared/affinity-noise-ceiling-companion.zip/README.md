# 親和性予測ベンチマークのノイズの床：配布資料

記事「AI親和性予測の「R² 0.43」を測定ノイズの上限から読む」の再実行用資料。

## 含むもの

- `analysis-plan.md`：問い・使いみち・処理・感度・判断の規則（計算前に固定）
- `acquire.py`：ChEMBL REST APIからの取得（15標的のIC50、pChEMBL値あり）
- `input-provenance.json`：ChEMBLのリリース、取得日、各入力ファイルのSHA-256
- `analysis.py`, `test_analysis.py`, `figures.py`：集計、検査、図
- `validate.R`：base Rによる独立の再計算（全文献ペア）
- `results/`：ノイズの要約、標的別、上限のブートストラップ区間、差の分布と山、報告値の換算、検証結果
- `figures/`：記事の図

入力のIC50データ本体（`inputs/`）は同梱しない。`acquire.py` で取得し、SHA-256で照合する。ChEMBLのデータはCC BY-SA 3.0。

## 実行

1. `python acquire.py`（Python 3.12、requests、pandas）
2. `python test_analysis.py && python analysis.py && python figures.py`（numpy、pandas、matplotlib）
3. `Rscript validate.R`（R 4.5、jsonlite）→ `results/validation.json`

Atomwell・Nesso-1・Boltz-2の値は、Bindwellのブログ（2026-10-18）の記載値を使った。これらのモデルは実行していない。
