"""Cross-document agreement of ChEMBL IC50 values and the implied ceiling for paper-split benchmarks."""
from pathlib import Path
import json

import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parent
SEED = 20261020
# pChEMBL values carry two decimals, so differences are rounded to 0.01 before any threshold.
# Identical: rounded |delta| = 0. "At least 10-fold": rounded |delta| >= 1.
UNIT_BAND = (2.7, 3.3)            # about 1,000-fold apart
SIDE_BANDS = ((2.1, 2.7), (3.3, 3.9))
# Reported in the Bindwell post (2026-10-18), 1,885 held-out IC50 values
BENCH = {"Atomwell": dict(r=0.681, r2=0.434, mse=0.885),
         "Nesso-1": dict(r=0.554, r2=0.237, mse=1.194),
         "Boltz-2": dict(r=0.429, r2=0.034, mse=1.512)}
SCALING_E = 0.104
N_BOOT = 2000
FVU_9B = 0.272


def load(target):
    df = pd.read_csv(ROOT / "inputs" / f"{target}.csv.gz", dtype={"data_validity_comment": "string"})
    df["target"] = target
    return df


def per_document(df):
    """Median pChEMBL per (target, molecule, document)."""
    g = df.groupby(["target", "molecule_chembl_id", "document_chembl_id"], as_index=False)
    return g.agg(p=("pchembl_value", "median"), n=("pchembl_value", "size"))


def pairs(doc, rng=None):
    """Document pairs per (target, molecule). With rng, one random pair per compound; else all pairs."""
    out = []
    for (t, m), g in doc.groupby(["target", "molecule_chembl_id"], sort=True):
        if len(g) < 2:
            continue
        p = g.p.to_numpy()
        if rng is None:
            i, j = np.triu_indices(len(p), 1)
        else:
            i, j = rng.choice(len(p), 2, replace=False)
            i, j = np.array([i]), np.array([j])
        out.append(pd.DataFrame({"target": t, "molecule": m, "pa": p[i], "pb": p[j]}))
    return pd.concat(out, ignore_index=True)


def abs_delta(pr):
    return np.round(np.abs((pr.pa - pr.pb).to_numpy()), 2)


def summarise(pr):
    d = (pr.pa - pr.pb).to_numpy()
    a = abs_delta(pr)
    band = ((a >= UNIT_BAND[0]) & (a <= UNIT_BAND[1])).mean()
    side = np.mean([((a >= lo) & (a < hi)).mean() for lo, hi in SIDE_BANDS])
    both = np.concatenate([pr.pa, pr.pb])
    sigma2 = d.var(ddof=1) / 2
    return dict(n_pairs=len(d), sd_delta=d.std(ddof=1), sigma2=sigma2, mad_delta=float(np.median(a)),
                frac_ge1=float((a >= 1).mean()), frac_ge2=float((a >= 2).mean()),
                frac_exact=float((a == 0).mean()), frac_unit_band=float(band),
                unit_band_excess=float(band - side), var_p=float(both.var(ddof=1)),
                r2_pairs=float(1 - np.mean(d ** 2) / pr.pb.var(ddof=0)),
                pearson=float(np.corrcoef(pr.pa, pr.pb)[0, 1]))


def bench_total_var(b):
    return b["mse"] / (1 - b["r2"])


def ceiling(sigma2, total_var):
    """R^2 of a predictor equal to the true value, scored against one noisy measurement."""
    return 1 - sigma2 / total_var


def main():
    prov = json.loads((ROOT / "input-provenance.json").read_text(encoding="utf-8"))
    raw = pd.concat([load(r["target"]) for r in prov["files"]], ignore_index=True)
    print("activities:", len(raw), "targets:", raw.target.nunique())
    assert raw.activity_id.is_unique
    assert raw.pchembl_value.between(1, 15).all()
    flagged = raw.data_validity_comment.notna()
    print("with data_validity_comment:", int(flagged.sum()))

    doc = per_document(raw)
    print("compound-document values:", len(doc))
    multi = doc.groupby(["target", "molecule_chembl_id"]).size()
    print("compound-target pairs with >=2 documents:", int((multi >= 2).sum()), "of", len(multi))

    rng = np.random.default_rng(SEED)
    main_pairs = pairs(doc, rng)
    all_pairs = pairs(doc)
    doc_clean = per_document(raw[~flagged])
    a = pd.Series(abs_delta(main_pairs), index=main_pairs.index)
    variants = {
        "main (one random pair per compound)": main_pairs,
        "all document pairs": all_pairs,
        "exclude identical values": main_pairs[a > 0],
        "exclude ~1000-fold pairs": main_pairs[~a.between(*UNIT_BAND)],
        "exclude ChEMBL validity flags": pairs(doc_clean, np.random.default_rng(SEED)),
        # post hoc (added after the first run): ChEMBL's own re-citation flag
        "exclude ChEMBL potential duplicates (post hoc)": pairs(per_document(raw[raw.potential_duplicate == 0]),
                                                                 np.random.default_rng(SEED)),
    }
    tv = bench_total_var(BENCH["Atomwell"])
    rows = []
    for name, pr in variants.items():
        s = summarise(pr)
        s.update(variant=name, bench_total_var=tv, bench_r2_ceiling=ceiling(s["sigma2"], tv),
                 bench_fvu_floor=s["sigma2"] / tv)
        rows.append(s)
    res = pd.DataFrame(rows).set_index("variant")
    indep = main_pairs[a > 0]
    by_target = pd.concat({
        "main": pd.DataFrame({t: summarise(g) for t, g in main_pairs.groupby("target")}).T,
        "exclude identical": pd.DataFrame({t: summarise(g) for t, g in indep.groupby("target")}).T}, names=["variant", "target"])
    by_target["bench_r2_ceiling"] = ceiling(by_target.sigma2, tv)
    by_target["within_target_r2_ceiling"] = ceiling(by_target.sigma2, by_target.var_p)
    # compound-level bootstrap of the ceiling (pairs are one per compound, so resample rows)
    boot_rng = np.random.default_rng(SEED + 1)
    ci = []
    for name in ["main (one random pair per compound)", "exclude identical values",
                 "exclude ChEMBL potential duplicates (post hoc)"]:
        d = (variants[name].pa - variants[name].pb).to_numpy()
        reps = [ceiling(d[boot_rng.integers(0, len(d), len(d))].var(ddof=1) / 2, tv) for _ in range(N_BOOT)]
        ci.append(dict(variant=name, ceiling=ceiling(d.var(ddof=1) / 2, tv),
                       lo=np.quantile(reps, 0.025), hi=np.quantile(reps, 0.975)))
    for t, g in indep.groupby("target"):
        d = (g.pa - g.pb).to_numpy()
        reps = [ceiling(d[boot_rng.integers(0, len(d), len(d))].var(ddof=1) / 2, tv) for _ in range(N_BOOT)]
        ci.append(dict(variant=f"exclude identical: {t}", ceiling=ceiling(d.var(ddof=1) / 2, tv),
                       lo=np.quantile(reps, 0.025), hi=np.quantile(reps, 0.975)))
    ci = pd.DataFrame(ci)

    out = ROOT / "results"
    out.mkdir(exist_ok=True)
    res.round(6).to_csv(out / "noise-summary.csv", lineterminator="\n")
    by_target.round(6).to_csv(out / "noise-by-target.csv", index_label=["variant", "target"], lineterminator="\n")
    ci.round(4).to_csv(out / "ceiling-bootstrap.csv", index=False, lineterminator="\n")
    # integer bins of 0.1 on the rounded differences avoid floating-point edges
    k = np.floor(np.round(abs_delta(main_pairs) * 10, 6)).astype(int)
    counts = np.bincount(k, minlength=61)[:61]
    hist = (counts, np.arange(62) / 10)
    pd.DataFrame({"abs_delta_lo": hist[1][:-1].round(1), "count": hist[0]}).to_csv(
        out / "abs-delta-histogram.csv", index=False, lineterminator="\n")
    # post hoc: narrow spikes in the histogram, counted above the mean of the two neighbouring bins
    c = hist[0]
    spikes = pd.DataFrame([{"bin_lo": k / 10, "count": int(c[k]), "neighbour_mean": (c[k - 1] + c[k + 1]) / 2,
                            "excess": c[k] - (c[k - 1] + c[k + 1]) / 2,
                            "excess_share_of_pairs": (c[k] - (c[k - 1] + c[k + 1]) / 2) / c.sum()}
                           for k in (10, 23, 30)])
    spikes.round(5).to_csv(out / "histogram-spikes.csv", index=False, lineterminator="\n")
    print(spikes.round(4))
    bench = pd.DataFrame(BENCH).T
    bench["r_squared"] = bench.r ** 2
    bench["recoverable_by_linear_recalibration"] = bench.r_squared - bench.r2
    bench["implied_total_var"] = bench.mse / (1 - bench.r2)   # holds if R^2 = 1 - MSE / Var(y)
    bench.round(4).to_csv(out / "reported-benchmark.csv", index_label="model", lineterminator="\n")
    summary = {"chembl": prov["chembl_db_version"], "activities": len(raw), "flagged": int(flagged.sum()),
               "doc_values": len(doc), "multi_doc_compounds": int((multi >= 2).sum()),
               "bench_total_var": tv, "scaling_E": SCALING_E, "fvu_9b": FVU_9B,
               "main": res.loc["main (one random pair per compound)"].to_dict()}
    (out / "summary.json").write_text(json.dumps(summary, indent=2) + "\n", encoding="utf-8")
    pd.set_option("display.width", 200)
    print(res[["n_pairs", "sd_delta", "sigma2", "frac_ge1", "frac_exact", "unit_band_excess",
               "r2_pairs", "bench_r2_ceiling", "bench_fvu_floor"]].round(3))
    print(by_target[["n_pairs", "sigma2", "frac_ge1", "var_p", "bench_r2_ceiling", "within_target_r2_ceiling"]].round(3))
    print(ci.round(3))
    print(bench.round(3))


if __name__ == "__main__":
    main()
