"""Figures from results/ (run analysis.py first)."""
from pathlib import Path
import json

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import pandas as pd

ROOT = Path(__file__).resolve().parent
res = ROOT / "results"
fig_dir = ROOT / "figures"
fig_dir.mkdir(exist_ok=True)
s = json.loads((res / "summary.json").read_text(encoding="utf-8"))
m = s["main"]

# Figure 1: distribution of cross-document differences
h = pd.read_csv(res / "abs-delta-histogram.csv")
fig, ax = plt.subplots(figsize=(7, 3.6), constrained_layout=True)
ax.bar(h.abs_delta_lo + 0.05, h["count"], width=0.1, color="#0072B2")
ax.axvspan(2.7, 3.3, color="#D55E00", alpha=0.15, label="about 1,000-fold (2.7-3.3)")
ax.axvline(1, color="k", linestyle=":", label="10-fold")
ax.set_yscale("log")
ax.set_xlabel("|pIC50 difference| between two documents, same compound and target")
ax.set_ylabel("Compound-target pairs (log scale)")
ax.set_title(f"ChEMBL IC50, 15 targets, one random document pair per compound (n = {int(m['n_pairs']):,})", fontsize=9)
ax.legend(fontsize=8)
fig.savefig(fig_dir / "01-cross-document-difference.png", dpi=150)

# Figure 2: reported benchmark R^2 against the noise ceiling under different handling of repeats
b = pd.read_csv(res / "reported-benchmark.csv", index_col="model")
v = pd.read_csv(res / "noise-summary.csv", index_col="variant")
fig, ax = plt.subplots(figsize=(7.2, 4), constrained_layout=True)
y = list(range(len(b)))
ax.barh([i + 0.18 for i in y], b.r2, height=0.35, color="#0072B2", label="Reported R²")
ax.barh([i - 0.18 for i in y], b.r_squared, height=0.35, color="#56B4E9", label="r² from reported Pearson r (linear recalibration)")
ax.set_yticks(y, b.index)
lines = [("main (one random pair per compound)", "Ceiling, all repeats (incl. identical values)", "-"),
         ("exclude identical values", "Ceiling, identical values removed", "--"),
         ("exclude ChEMBL potential duplicates (post hoc)", "Ceiling, ChEMBL duplicate flag removed", ":")]
for key, lab, ls in lines:
    c = v.loc[key, "bench_r2_ceiling"]
    ax.axvline(c, color="#D55E00", linestyle=ls, linewidth=1.8, label=f"{lab} ({c:.2f})")
ax.set_xlim(0, 1)
ax.set_xlabel("R² on 1,885 held-out IC50 values (model values as reported by Bindwell)")
ax.set_title("Ceiling = 1 - ChEMBL cross-document noise variance / benchmark total variance (%.2f)" % s["bench_total_var"], fontsize=8)
ax.legend(fontsize=7, loc="lower right")
fig.savefig(fig_dir / "02-benchmark-vs-ceiling.png", dpi=150)
print("figures written")
