"""Checks for the pairing and noise calculations (synthetic data only)."""
import numpy as np
import pandas as pd

import analysis as A


def test_per_document_median():
    df = pd.DataFrame({"target": "T", "molecule_chembl_id": ["m"] * 3, "document_chembl_id": ["d1", "d1", "d2"],
                       "pchembl_value": [6.0, 8.0, 5.0]})
    d = A.per_document(df)
    assert d.set_index("document_chembl_id").p.to_dict() == {"d1": 7.0, "d2": 5.0}


def test_pairs_counts():
    doc = pd.DataFrame({"target": "T", "molecule_chembl_id": ["a"] * 3 + ["b"] * 2 + ["c"],
                        "document_chembl_id": list("xyzxyx"), "p": [5, 6, 7, 5, 5, 9.0]})
    assert len(A.pairs(doc)) == 3 + 1                     # C(3,2) + C(2,2); c has one document
    assert len(A.pairs(doc, np.random.default_rng(1))) == 2


def test_noise_variance_recovered():
    rng = np.random.default_rng(0)
    truth = rng.normal(6.5, 1.2, 200_000)
    pr = pd.DataFrame({"pa": truth + rng.normal(0, 0.5, truth.size), "pb": truth + rng.normal(0, 0.5, truth.size)})
    s = A.summarise(pr)
    assert abs(s["sigma2"] - 0.25) < 0.005
    # pairwise R^2 equals 1 - 2 sigma^2 / var(p); the ceiling with truth as predictor is 1 - sigma^2 / var(p)
    var_p = 1.2 ** 2 + 0.25
    assert abs(s["r2_pairs"] - (1 - 0.5 / var_p)) < 0.01
    assert abs(A.ceiling(s["sigma2"], var_p) - (1 - 0.25 / var_p)) < 0.01


def test_unit_band_excess_detects_thousandfold_errors():
    rng = np.random.default_rng(2)
    n = 100_000
    truth = rng.normal(7, 1, n)
    pb = truth + rng.normal(0, 0.4, n)
    pa = truth + rng.normal(0, 0.4, n)
    clean = A.summarise(pd.DataFrame({"pa": pa, "pb": pb}))
    bad = pa.copy()
    bad[: n // 50] -= 3                                   # 2% of values reported 1,000-fold too weak
    dirty = A.summarise(pd.DataFrame({"pa": bad, "pb": pb}))
    assert abs(clean["unit_band_excess"]) < 0.002
    # a lower-bound indicator: the shifted values spread into the side bands too
    assert 0.001 < dirty["unit_band_excess"] < 0.02


def test_exact_fraction():
    pr = pd.DataFrame({"pa": [5.0, 6.0, 7.0, 8.0], "pb": [5.0, 6.004, 7.5, 9.0]})
    assert A.summarise(pr)["frac_exact"] == 0.5


def test_benchmark_arithmetic():
    b = A.BENCH["Atomwell"]
    tv = A.bench_total_var(b)
    assert abs(1 - b["mse"] / tv - b["r2"]) < 1e-12


if __name__ == "__main__":
    for name, fn in list(globals().items()):
        if name.startswith("test_"):
            fn()
    print("all tests passed")
