"""Check the analysis unit, exclusion rules, and within-patient estimand."""
from pathlib import Path
import sys
import unittest
import numpy as np
import pandas as pd
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'src'))
from lesions import select_primary, patient_summary, discordance, organ_model


def fixture() -> pd.DataFrame:
    return pd.DataFrame({
        'patient_id': ['a', 'a', 'b', 'b'], 'lesion_id': [1, 2, 1, 2],
        'lesion_type': ['Lung', 'Liver', 'Lung', 'Liver'],
        'volume_bl': [100., 1., 100., 1.], 'volume_fu': [50., 2., 200., 2.],
        'TimeDiff_BL_FU1_Days': [90.] * 4, 'topology_class': ['UNCHANGED'] * 4,
        'linking_unclear': [False] * 4})


class LesionTests(unittest.TestCase):
    def test_aggregation_can_hide_growth(self):
        p = patient_summary(select_primary(fixture()))
        self.assertLess(p.loc['a', 'aggregate_log_ratio'], 0)
        self.assertGreater(p.loc['a', 'max_log_ratio'], 0)

    def test_patient_denominator(self):
        result = discordance(select_primary(fixture()), (0., .2, 1.), replicates=100)
        self.assertEqual(result.patients.tolist(), [2, 2, 2])
        self.assertEqual(result.discordant_patients.tolist(), [1, 1, 0])

    def test_zero_or_unknown_time_excluded(self):
        d = fixture(); d.loc[0, 'TimeDiff_BL_FU1_Days'] = 0
        d.loc[1, 'TimeDiff_BL_FU1_Days'] = np.nan
        self.assertEqual(len(select_primary(d)), 2)

    def test_merge_and_unclear_links_excluded(self):
        d = fixture(); d.loc[0, 'topology_class'] = 'MERGING'
        d.loc[1, 'linking_unclear'] = True
        self.assertEqual(len(select_primary(d)), 2)

    def test_zero_volume_not_pseudocounted(self):
        d = fixture(); d.loc[0, 'volume_fu'] = 0
        self.assertEqual(len(select_primary(d)), 3)

    def test_fe_removes_patient_intercepts(self):
        rows = []
        for i in range(20):
            for j, organ in enumerate(['Lung', 'Liver']):
                x = 1 + i * .1 + j * (1 + (i % 3) * .2)
                y = i * .4 + j * .5 + .2 * x
                rows.append({'patient_id': str(i), 'lesion_type': organ,
                             'log_baseline': x, 'log_ratio': y})
        out, info = organ_model(pd.DataFrame(rows), ('Lung', 'Liver'), replicates=100)
        self.assertAlmostEqual(out.coefficient.iloc[0], .5)
        self.assertAlmostEqual(out.coefficient.iloc[1], .2)
        self.assertEqual(info['patients'], 20)


if __name__ == '__main__':
    unittest.main()
