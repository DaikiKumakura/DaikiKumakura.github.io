"""Audited paired-volume summaries; not RECIST or causal drug effects."""
from pathlib import Path
import hashlib
import json
import numpy as np
import pandas as pd
import statsmodels.api as sm


def load(root: Path) -> tuple[pd.DataFrame, pd.DataFrame]:
    manifest = json.loads((root / "data/processed/csv-manifest.json").read_text())
    rows = []
    for entry in manifest:
        path = root / entry["local_file"]
        assert hashlib.sha256(path.read_bytes()).hexdigest() == entry["sha256"]
        frame = pd.read_csv(path, encoding="utf8")
        if "demographics" in path.name:
            demographics = frame.rename(columns={"ID": "patient_id"})
        else:
            frame["patient_id"] = path.stem
            rows.append(frame)
    lesions = pd.concat(rows, ignore_index=True)
    assert not lesions.duplicated(["patient_id", "lesion_id"]).any()
    assert not demographics["patient_id"].duplicated().any()
    joined = lesions.merge(demographics, on="patient_id", how="left", validate="many_to_one")
    assert len(joined) == len(lesions)
    # Unmatched IDs and zero intervals are retained in the audit, never repaired by guessing.
    assert not (joined["TimeDiff_BL_FU1_Days"].dropna() < 0).any()
    assert (joined[["volume_bl", "volume_fu"]].stack() >= 0).all()
    return joined, demographics


def select_primary(data: pd.DataFrame) -> pd.DataFrame:
    keep = (data["topology_class"].eq("UNCHANGED") & data["linking_unclear"].eq(False)
            & data["volume_bl"].gt(0) & data["volume_fu"].gt(0)
            & data["TimeDiff_BL_FU1_Days"].gt(0))
    selected = data.loc[keep].copy()
    selected["log_ratio"] = np.log(selected["volume_fu"] / selected["volume_bl"])
    selected["log_baseline"] = np.log(selected["volume_bl"])
    return selected


def patient_summary(data: pd.DataFrame) -> pd.DataFrame:
    """Sum only the supplied lesion subset and preserve its maximum change."""
    result = data.groupby("patient_id", observed=True).agg(
        n_lesions=("lesion_id", "size"), n_organs=("lesion_type", "nunique"),
        baseline=("volume_bl", "sum"), followup=("volume_fu", "sum"),
        max_log_ratio=("log_ratio", "max"),
        interval_days=("TimeDiff_BL_FU1_Days", "first"))
    result["aggregate_log_ratio"] = np.log(result["followup"] / result["baseline"])
    return result


def discordance(data: pd.DataFrame, thresholds: tuple[float, ...], seed: int = 20261008,
                replicates: int = 2000) -> pd.DataFrame:
    """Patient-cluster bootstrap of an unconditional proportion among eligible patients."""
    patients = patient_summary(data)
    if patients.empty:
        raise ValueError("No eligible patients")
    rng = np.random.default_rng(seed)
    sample = rng.integers(0, len(patients), size=(replicates, len(patients)))
    output = []
    for threshold in thresholds:
        event = ((patients["aggregate_log_ratio"] < 0)
                 & (patients["max_log_ratio"] > np.log1p(threshold))).to_numpy()
        proportions = event[sample].mean(axis=1)
        lo, hi = np.quantile(proportions, [.025, .975])
        output.append({"increase_threshold": threshold, "patients": len(event),
                       "discordant_patients": int(event.sum()), "fraction": float(event.mean()),
                       "low": float(lo), "high": float(hi),
                       "aggregate_decrease_patients": int((patients["aggregate_log_ratio"] < 0).sum())})
    return pd.DataFrame(output)


def organ_model(data: pd.DataFrame, organs: tuple[str, ...], replicates: int = 1000,
                seed: int = 20261008) -> tuple[pd.DataFrame, dict]:
    """Within-patient FE; resample whole patients for percentile intervals."""
    group = data.loc[data["lesion_type"].isin(organs)].groupby(
        ["patient_id", "lesion_type"], observed=True).agg(
        y=("log_ratio", "mean"), x=("log_baseline", "mean")).reset_index()
    counts = group.groupby("patient_id")["lesion_type"].transform("size")
    group = group.loc[counts >= 2].copy()
    design = pd.DataFrame({organ: group["lesion_type"].eq(organ).astype(float)
                           for organ in organs[1:]}, index=group.index)
    design["baseline_log_volume"] = group["x"]
    design = design - design.groupby(group["patient_id"]).transform("mean")
    response = group["y"] - group.groupby("patient_id")["y"].transform("mean")
    assert np.linalg.matrix_rank(design) == design.shape[1]
    model = sm.OLS(response, design).fit(cov_type="cluster", cov_kwds={"groups": group["patient_id"]})
    ci = model.conf_int()
    result = pd.DataFrame({"term": design.columns, "coefficient": model.params,
                           "low": ci[0], "high": ci[1]}).reset_index(drop=True)
    # Within transforms are unchanged when whole clusters are resampled.
    # Sufficient statistics avoid refitting hundreds of patient dummy columns.
    xx, xy = [], []
    for patient in group.patient_id.unique():
        mask = group.patient_id.eq(patient)
        x = design.loc[mask].to_numpy()
        y = response.loc[mask].to_numpy()
        xx.append(x.T @ x)
        xy.append(x.T @ y)
    xx, xy = np.array(xx), np.array(xy)
    rng = np.random.default_rng(seed)
    estimates = []
    for _ in range(replicates):
        weights = rng.multinomial(len(xx), np.full(len(xx), 1 / len(xx)))
        a = np.einsum('i,ijk->jk', weights, xx)
        b = np.einsum('i,ij->j', weights, xy)
        if np.linalg.matrix_rank(a) == a.shape[0]:
            estimates.append(np.linalg.solve(a, b))
    assert len(estimates) >= 0.95 * replicates, 'Too many rank-deficient resamples'
    result['sandwich_low'], result['sandwich_high'] = result.low, result.high
    result['low'], result['high'] = np.quantile(estimates, [.025, .975], axis=0)
    info = {"patients": int(group["patient_id"].nunique()), "patient_organ_rows": len(group),
            "reference_organ": organs[0], "rank": int(np.linalg.matrix_rank(design)),
            "covariance": "whole-patient bootstrap percentile intervals",
            "bootstrap_replicates": replicates, "bootstrap_success": len(estimates), "seed": seed}
    return result, info
