"""Fit fixed-endpoint models and test omitted mixture conditions."""
from pathlib import Path
import csv
import json
import sys
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))
from model import fit_beta, response, holdout, rmse

SEED = 2026102608
READING_SCENARIOS = 512


def save_table(name, rows):
    with (ROOT / "outputs/tables" / name).open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=rows[0]); writer.writeheader(); writer.writerows(rows)


def main():
    for folder in ["outputs/tables", "outputs/figures"]:
        (ROOT / folder).mkdir(parents=True, exist_ok=True)
    with (ROOT / "data/processed/bar-means.csv").open(encoding="utf-8", newline="") as f:
        rows = list(csv.DictReader(f))
    assert len(rows) == 24
    def find(group, fraction, population="negative"):
        return next(r for r in rows if r["group"]==group and r["population"]==population
                    and (float(r["nominal_positive_fraction"])==fraction if group!="spatial" else
                         (float(r["distance_um"]) if r["distance_um"] else 0)==fraction))
    def val(row): return float(row["mean_fold"])
    def bound(row): return 2*float(row["fold_per_pixel"])
    fractions = np.array([.2, .5, .8])
    treated = np.array([val(find("treated", f)) for f in fractions])
    controls = np.array([val(find("control", f)) for f in fractions])
    relative = treated / controls
    beta = fit_beta(fractions, relative)
    beta_log = fit_beta(fractions, relative, "log")
    predictions = holdout(fractions, relative)
    log_predictions = holdout(fractions, relative, "log")
    pure = val(find("treated",0)) / val(find("control",0))
    pure_relative = treated / val(find("treated",0))
    pure_predictions = holdout(fractions, pure_relative)
    primary_rows = [dict(nominal_positive_fraction=float(f),treated_day5_day0=float(t),
        tcell_only_day5_day0=float(g),treated_control_ratio=float(r),
        no_bystander_prediction=1.,heldout_prediction=float(p),heldout_log_prediction=float(l),
        pure_negative_anchor_ratio=float(s),pure_anchor_heldout_prediction=float(q))
        for f,t,g,r,p,l,s,q in zip(fractions,treated,controls,relative,predictions,log_predictions,pure_relative,pure_predictions)]
    save_table("mixture-endpoints.csv",primary_rows)
    beta_rows=[dict(model="raw-scale exponential",beta=beta,loo_rmse=rmse(relative,predictions),endpoint_scale="T-cell-only relative"),
               dict(model="log-scale exponential",beta=beta_log,loo_rmse=rmse(relative,log_predictions),endpoint_scale="T-cell-only relative"),
               dict(model="no-bystander constant",beta=0,loo_rmse=rmse(relative,np.ones(3)),endpoint_scale="T-cell-only relative"),
               dict(model="pure-negative anchor exponential",beta=fit_beta(fractions,pure_relative),loo_rmse=rmse(pure_relative,pure_predictions),endpoint_scale="Same-Figure2 pure-negative relative; not directly comparable RMSE")]
    save_table("model-comparison.csv",beta_rows)
    # Bounded reading perturbations are not bootstrap samples or confidence limits.
    rng = np.random.default_rng(SEED)
    grid = np.linspace(0, .8, 161)
    curves, sensitivity, spatial_readings = [], [], []
    for i in range(READING_SCENARIOS):
        read = {}
        for row in rows:
            key=(row["group"],row["nominal_positive_fraction"],row["distance_um"],row["population"])
            read[key]=max(1e-8,val(row)+rng.uniform(-bound(row),bound(row)))
        def rv(group,f): return read[(group,str(f),"","negative")]
        # Read CSV serializes nominal x values through Python's float spellings.
        rt=np.array([rv("treated",f) for f in fractions])
        rc=np.array([rv("control",f) for f in fractions])
        rr=rt/rc
        b=fit_beta(fractions,rr)
        curves.append(response(grid,b))
        sensitivity.append(dict(scenario=i,beta=b,loo_rmse=rmse(rr,holdout(fractions,rr))))
    save_table("reading-sensitivity.csv",sensitivity)
    curves=np.array(curves)
    save_table("curve-grid.csv",[dict(nominal_positive_fraction=float(f),raw_scale=float(response(f,beta)),
        log_scale=float(response(f,beta_log)),reading_min=float(curves[:,i].min()),reading_max=float(curves[:,i].max())) for i,f in enumerate(grid)])
    # Explicit nominal-fraction uncertainty scenarios, not measured calibration.
    fraction_sensitivity=[]
    for delta in [-.05,0,.05]:
        xf=fractions+delta
        fraction_sensitivity.append(dict(fraction_offset=delta,beta=fit_beta(xf,relative),
            loo_rmse=rmse(relative,holdout(xf,relative))))
    save_table("fraction-sensitivity.csv",fraction_sensitivity)
    spatial=[]
    for distance in [200,250,300,0]:
        row=find("spatial",distance)
        spatial.append(dict(center_distance_um=distance if distance else "reference",negative_day5_day0=val(row),
            reading_lower=max(0,val(row)-bound(row)),reading_upper=val(row)+bound(row),
            condition="T cells and bsAb" if distance else "T cells only at 200 um",
            independent_experiments=4 if distance else 3))
    save_table("spatial-challenge.csv",spatial)
    results=dict(seed=SEED,mean_bars=len(rows),mixture_conditions=3,beta_raw=beta,beta_log=beta_log,
        loo_rmse=rmse(relative,predictions),no_bystander_rmse=rmse(relative,np.ones(3)),
        log_loo_rmse=rmse(relative,log_predictions),pure_negative_treated_control_ratio=pure,
        relative_endpoints=primary_rows,reading_scenarios=READING_SCENARIOS,
        reading_beta_min=min(r["beta"] for r in sensitivity),reading_beta_max=max(r["beta"] for r in sensitivity),
        reading_loo_rmse_min=min(r["loo_rmse"] for r in sensitivity),reading_loo_rmse_max=max(r["loo_rmse"] for r in sensitivity),
        spatial=spatial,fraction_sensitivity=fraction_sensitivity,
        interpretation="Exploratory aggregate condition holdout, not independent biological validation; no kinetic or clinical parameter estimated")
    (ROOT/"outputs/results.json").write_text(json.dumps(results,indent=2)+"\n")
    plt.rcParams.update({"font.family":"DejaVu Sans","font.size":11,"axes.spines.top":False,"axes.spines.right":False})
    blue,orange,green="#0072B2","#D55E00","#009E73"
    def finish(fig,name):
        for suffix in ["png","svg"]:
            path=ROOT/"outputs/figures"/(name+"."+suffix)
            fig.savefig(path,dpi=180,bbox_inches="tight")
            if suffix=="svg": path.write_text("\n".join(line.rstrip() for line in path.read_text().splitlines())+"\n")
        plt.close(fig)
    fig,axs=plt.subplots(1,2,figsize=(11.5,4.3),layout="constrained")
    for ax,pop,title in zip(axs,["positive","negative"],["HER2-positive cells","HER2-negative cells"]):
        fs=np.array([.2,.5,.8,1] if pop=="positive" else [0,.2,.5,.8])
        for group,offset,color,label in [("control",-.016,blue,"T cells only"),("treated",.016,orange,"T cells + bsAb")]:
            obs=[find(group,f,pop) for f in fs]
            ax.errorbar(fs+offset,[val(r) for r in obs],yerr=[bound(r) for r in obs],fmt="o",color=color,capsize=3,label=label)
        ax.axhline(1,color=".65",lw=1);ax.set(xlabel="Nominal initial HER2-positive fraction",ylabel="Cell count day 5 / day 0",title=title,ylim=(0,3.5),xlim=(-.06,1.06),xticks=[0,.2,.5,.8,1])
    axs[0].legend(loc="upper right",frameon=False)
    fig.supxlabel("n = 3 independent experiments per condition; bars show ±2-pixel reading bounds, not SEM",fontsize=10)
    finish(fig,"01-cell-abundance")
    fig,axs=plt.subplots(1,2,figsize=(11.5,4.5),layout="constrained")
    ax=axs[0];ax.fill_between(grid,curves.min(axis=0),curves.max(axis=0),color=blue,alpha=.16,label="512 bounded reading scenarios")
    ax.plot(grid,response(grid,beta),color=blue,label="Raw-scale fit (all three conditions)")
    ax.plot(grid,response(grid,beta_log),color=green,ls="--",label="Log-scale sensitivity")
    ax.scatter(fractions,relative,color=orange,zorder=4,label="Published means / control means")
    ax.scatter([0],[pure],facecolors="none",edgecolors=orange,zorder=4,label="Pure-negative check (not fitted)")
    ax.axhline(1,color=".5",ls=":",label="No-bystander reference")
    ax.set(xlabel="Nominal initial HER2-positive fraction",ylabel="Negative-cell treated / control ratio",ylim=(0,1.25),title="Fixed five-day endpoint")
    ax.legend(fontsize=8,frameon=False)
    ax=axs[1];ix=np.arange(3)
    ax.scatter(ix,relative,color=orange,label="Held-out observed ratio",s=55)
    ax.scatter(ix,predictions,color=blue,marker="x",label="Raw-scale held-out prediction",s=65)
    ax.scatter(ix,log_predictions,color=green,marker="+",label="Log-scale held-out prediction",s=70)
    ax.axhline(1,color=".5",ls=":");ax.set(xticks=ix,xticklabels=["20%","50%","80%"],xlabel="Excluded mixture condition",ylabel="Negative-cell treated / control ratio",ylim=(0,1.25),title="Two conditions fitted; one predicted")
    ax.legend(frameon=False,fontsize=8)
    fig.supxlabel("Condition holdout is exploratory; the shaded range is not a biological confidence interval",fontsize=10)
    finish(fig,"02-mixture-prediction")
    fig,ax=plt.subplots(figsize=(8.5,4.8),layout="constrained")
    for i,row in enumerate(spatial):
        y=row["negative_day5_day0"]
        ax.errorbar(i,y,yerr=[[y-row["reading_lower"]],[row["reading_upper"]-y]],fmt="o",color=blue if i<3 else ".4",capsize=4,markersize=8)
    ax.axhline(1,color=".65",lw=1)
    ax.set(xticks=[0,1,2,3],xticklabels=["200 µm\nn = 4","250 µm\nn = 4","300 µm\nn = 4","T cells only\n200 µm; n = 3"],ylabel="HER2-negative cell count day 5 / day 0",ylim=(0,1.9),title="Separated clusters challenge a fraction-only explanation")
    fig.supxlabel("Center-to-center distances; ±2-pixel reading bounds. A different assay geometry, not external validation.",fontsize=9)
    finish(fig,"03-spatial-challenge")
    print(json.dumps({k:results[k] for k in ["beta_raw","beta_log","loo_rmse","no_bystander_rmse","reading_beta_min","reading_beta_max"]}))


if __name__=="__main__": main()
