"""Reconstruct published bar means, not individual experimental replicates."""
from pathlib import Path
from io import BytesIO
import csv
import json
import numpy as np
import pymupdf
from PIL import Image, ImageDraw

ROOT = Path(__file__).resolve().parents[1]
# Coordinates refer to native official raster images. Means are bar top edges.
# Source image filenames were matched to figure labels in the official XML.
PANELS = {
    "treated": dict(source="Figure2D", file="EJI-55-e202451589-g007.jpg", y0=907, y1=863.5,
        values=[(1,"positive",369,899),(.8,"positive",387,899),(.8,"negative",412,897),
                (.5,"positive",444,902),(.5,"negative",469,891),
                (.2,"positive",501,902),(.2,"negative",526,848),(0,"negative",565,818)],
        n=3, wells="2 per independent experiment"),
    "control": dict(source="SupplementaryFigure3C", file="supplement-image", y0=1170.5, y1=1114,
        values=[(1,"positive",802,1028),(.8,"positive",851,1046),(.8,"negative",876,1068),
                (.5,"positive",924,1012),(.5,"negative",947,1044),
                (.2,"positive",996,1001),(.2,"negative",1019,1066),(0,"negative",1067,1069)],
        n=3, wells="1 per independent experiment"),
    "spatial": dict(source="Figure3D", file="EJI-55-e202451589-g008.jpg", y0=454.5, y1=427,
        values=[(200,"positive",382,452),(200,"negative",396,453.5),
                (250,"positive",426,454),(250,"negative",442,443),
                (300,"positive",469,452),(300,"negative",485,420),
                (0,"positive",514,393),(0,"negative",529,411)],
        n=4, wells="1 per independent experiment; T-cell-only reference n=3"),
}


def main():
    processed, checks = ROOT / "data/processed", ROOT / "verification"
    processed.mkdir(parents=True, exist_ok=True)
    checks.mkdir(exist_ok=True)
    raw = ROOT / "data/raw/supplementary"
    pdf = pymupdf.open(raw / "EJI-55-e202451589-s001.pdf")
    original = pdf.extract_image(pdf[3].get_images()[0][0])["image"]
    rows = []
    for group, cfg in PANELS.items():
        im = Image.open(BytesIO(original) if group == "control" else raw / cfg["file"]).convert("RGB")
        draw = ImageDraw.Draw(im)
        for xvalue, population, x, y in cfg["values"]:
            value = (cfg["y0"] - y) / (cfg["y0"] - cfg["y1"])
            rows.append(dict(group=group, source=cfg["source"], nominal_positive_fraction=xvalue if group != "spatial" else "",
                distance_um=xvalue if group == "spatial" and xvalue else "", population=population,
                mean_fold=max(0, value), x_px=x, y_px=y,
                fold_per_pixel=1/(cfg["y0"]-cfg["y1"]), reading_bound_px=2,
                independent_experiments=3 if group == "spatial" and xvalue==0 else cfg["n"],
                within_experiment_cultures=cfg["wells"],
                treatment="T cells only" if group=="control" or (group=="spatial" and xvalue==0) else "T cells and CD3xHER2 bsAb",
                reading_quality="near_plot_floor" if value<.08 else "bar_mean_edge"))
            draw.line((x-6,y,x+6,y), fill="red", width=1)
        im.save(checks / f"{group}-readback.png")
    with (processed / "bar-means.csv").open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=rows[0]); writer.writeheader(); writer.writerows(rows)
    (processed / "digitization.json").write_text(json.dumps(dict(
        mean_bars=len(rows), original_units="day5 cell count / same-population day0 cell count",
        missing_population="Not applicable, never zero-filled", biological_replicates_recovered=False,
        sem_digitized=False, reading_bound_native_pixels=2,
        uncertainty="Pixel-reading sensitivity, not biological confidence interval"), indent=2)+"\n")
    print("Reconstructed bar means:", len(rows))


if __name__ == "__main__":
    main()
