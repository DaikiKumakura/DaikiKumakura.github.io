"""Download the official open-access archive; preserve existing source bytes."""
from pathlib import Path
import hashlib
import json
import urllib.request
import zipfile

ROOT = Path(__file__).resolve().parents[1]


def main():
    provenance = json.loads((ROOT / "source-provenance.json").read_text())
    raw = ROOT / "data/raw"
    raw.mkdir(parents=True, exist_ok=True)
    source = raw / "supplementary-files.zip"
    if not source.exists():
        request = urllib.request.Request(provenance["archive_url"], headers={"User-Agent": "OpenResearchAnalysis/1.0"})
        with urllib.request.urlopen(request, timeout=120) as response:
            data = response.read()
        assert hashlib.sha256(data).hexdigest() == provenance["archive_sha256"]
        source.write_bytes(data)
    assert hashlib.sha256(source.read_bytes()).hexdigest() == provenance["archive_sha256"]
    target = raw / "supplementary"
    target.mkdir(exist_ok=True)
    with zipfile.ZipFile(source) as archive:
        for name in archive.namelist():
            assert not Path(name).is_absolute() and ".." not in Path(name).parts
            path = target / name
            if not path.exists():
                path.parent.mkdir(parents=True, exist_ok=True)
                path.write_bytes(archive.read(name))
    print("Official archive verified")


if __name__ == "__main__":
    main()
