"""Endpoint models for a fixed five-day experimental assay."""
import numpy as np
from scipy.optimize import minimize_scalar


def response(fraction, beta):
    """Control-relative negative-cell abundance; beta has no kinetic meaning."""
    return np.exp(-beta * np.asarray(fraction, dtype=float))


def fit_beta(fraction, observed, scale="raw"):
    x, y = np.asarray(fraction, float), np.asarray(observed, float)
    if x.shape != y.shape or np.any(x <= 0) or np.any(y <= 0):
        raise ValueError("Positive fractions and endpoints of equal shape required")
    if scale == "log":
        return float(max(0, -np.dot(x, np.log(y)) / np.dot(x, x)))
    if scale != "raw":
        raise ValueError(scale)
    fit = minimize_scalar(lambda b: np.sum((response(x, b) - y) ** 2),
                          bounds=(0, 100), method="bounded",
                          options={"xatol": 1e-11})
    if not fit.success:
        raise RuntimeError(fit.message)
    return float(fit.x)


def holdout(fraction, observed, scale="raw"):
    x, y = np.asarray(fraction, float), np.asarray(observed, float)
    predictions = []
    for i in range(len(x)):
        keep = np.arange(len(x)) != i
        predictions.append(float(response(x[i], fit_beta(x[keep], y[keep], scale))))
    return np.asarray(predictions)


def rmse(observed, predicted):
    return float(np.sqrt(np.mean((np.asarray(observed) - predicted) ** 2)))
