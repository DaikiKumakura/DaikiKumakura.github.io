# HER2-negative residual cells after a T-cell engager

Endpoint reanalysis of Liao et al. (2025), DOI:10.1002/eji.202451589.
The reconstructed bar means are approximate aggregate values, not individual
experimental replicates. The source is available under CC BY 4.0. Attribution,
source URLs and archive hash are in source-provenance.json. This work transforms
published bar means into endpoint ratios, fits and plots. It does not reproduce
the original statistical tests or infer a clinical treatment schedule.

Use the packages listed in requirements.txt in an existing Python environment.
From this directory run:

```sh
python analysis/download_sources.py
python analysis/digitize.py
python analysis/run.py
python -m unittest discover -s tests
```

The official open-access archive is downloaded only when absent and verified
against the recorded SHA-256. Existing source files are preserved. Reading bounds
of two native image pixels are sensitivity assumptions, not biological confidence
intervals. Mixture-condition holdout uses two aggregate conditions to predict one;
it is not independent-donor validation. The spatial experiment changes the assay
geometry and is a challenge to a fraction-only description, not a calibrated
external prediction test. A five-day coefficient is not a death rate.
