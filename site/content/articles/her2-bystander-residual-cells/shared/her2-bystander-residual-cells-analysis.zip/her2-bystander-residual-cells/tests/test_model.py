from pathlib import Path
import sys
import unittest
import numpy as np
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/"src"))
from model import response, fit_beta, holdout, rmse


class EndpointTests(unittest.TestCase):
    def test_no_bystander(self):
        np.testing.assert_allclose(response([0,.2,.8],0),1)

    def test_recover_known_parameter(self):
        x=np.array([.2,.5,.8]);y=response(x,3)
        self.assertAlmostEqual(fit_beta(x,y),3,places=5)
        self.assertAlmostEqual(fit_beta(x,y,"log"),3,places=8)

    def test_no_heldout_leak(self):
        x=np.array([.2,.5,.8]);y=np.array([.7,.2,.1]);z=y.copy();z[0]=.99
        self.assertEqual(holdout(x,y)[0],holdout(x,z)[0])

    def test_fixed_initial_endpoint(self):
        self.assertEqual(response(0,10),1)

    def test_invalid_input(self):
        with self.assertRaises(ValueError):fit_beta([.2,.5],[0,.2],"log")

    def test_error_units(self):
        self.assertEqual(rmse([1,2],np.array([0,1])),1)


if __name__=="__main__":unittest.main()
