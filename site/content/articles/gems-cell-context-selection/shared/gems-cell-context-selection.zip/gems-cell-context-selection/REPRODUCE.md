# GEMS Table 2 denominator audit

Source: Xie et al., GEMS v1, posted 16 October 2026, Table 2 (PDF page 18).
https://doi.org/10.64898/2026.10.14.759213

The CSV contains four manually transcribed numerical records, not individual variants.
`both` is the number with at least one significant association in each modality in the
multimodal model, after excluding the mononuclear-cell RNA feature as specified in
Table 2. It does not require a biologically matched pair. `top` is the count
for the most shared RNA-tissue / ATAC-cell-type pair. T2D has a three-way RNA tissue
tie (pancreas, colon, colonic mucosa), each with delta+gamma ATAC and three variants.
These counts must not be added because overlap is unknown.

Python 3.12, Matplotlib 3.9.1:

```text
python -m pip install -r requirements.txt
python analysis.py
python -m unittest test_analysis.py
python plot.py
```

Outputs are deterministic ratios and an original plot. This does not reproduce the
GEMS model, establish causal cell types, estimate out-of-sample accuracy, or measure
agreement between separately trained unimodal models. There are no sampling intervals:
the four reported sets are described, not sampled to infer a population proportion.
No manuscript PDF, original figure, or unpublished variant data are redistributed.
