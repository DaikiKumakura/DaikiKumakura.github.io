import json
from pathlib import Path
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

HERE = Path(__file__).resolve().parent
rows = json.loads((HERE / 'results/summary.json').read_text())
fig, ax = plt.subplots(figsize=(9, 5.3), layout='constrained')
colors = ['#227c9d', '#82b6c8', '#e4e8eb']
for i, r in enumerate(rows):
    values = [r['top'], r['both_other'], r['without_both']]
    left = 0
    for j, v in enumerate(values):
        width = 100 * v / r['total']
        ax.barh(i, width, left=left, color=colors[j], height=.58)
        left += width
    ax.text(101, i, f"{r['top']}/{r['total']} = {100*r['top_fraction']:.1f}%", va='center', fontsize=10)
ax.set(yticks=range(4), yticklabels=[r['trait'] for r in rows], xlim=(0, 127),
       xticks=[0, 20, 40, 60, 80, 100], xlabel='Percent of fine-mapped variants (PIP > 0.1)',
       title='Same table, different denominators')
ax.invert_yaxis()
for label, color in zip(['Top RNA/ATAC pair', 'Both modalities, outside top pair', 'Missing significant support in at least one modality'], colors):
    ax.barh(-2, 0, color=color, label=label)
ax.set_ylim(3.6, -.6)
ax.spines[['top', 'right']].set_visible(False)
ax.legend(loc='upper center', bbox_to_anchor=(.5, -.19), frameon=False, fontsize=9, ncol=1,
          title='GEMS v1 Table 2: descriptive counts, not accuracy', title_fontsize=9)
(HERE / 'figures').mkdir(exist_ok=True)
fig.savefig(HERE / 'figures/denominators.png', dpi=180, metadata={'Software': 'Matplotlib'})
