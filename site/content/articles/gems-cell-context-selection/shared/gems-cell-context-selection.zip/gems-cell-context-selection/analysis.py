"""Recalculate denominators in GEMS v1 Table 2; no variant-level inference."""
import csv
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent


def decompose(total, both, top):
    if not (0 <= top <= both <= total) or total <= 0 or both == 0:
        raise ValueError('Require 0 <= top <= both <= total and positive denominators')
    return dict(both_fraction=both / total, top_given_both=top / both,
                top_fraction=top / total, both_other=both - top,
                without_both=total - both)


def main():
    rows = []
    with (HERE / 'inputs/table2.csv').open(encoding='utf-8', newline='') as f:
        for row in csv.DictReader(f):
            n, b, k = (int(row[x]) for x in ('total', 'both', 'top'))
            rows.append(dict(trait=row['trait'], total=n, both=b, top=k,
                             **decompose(n, b, k)))
    (HERE / 'results').mkdir(exist_ok=True)
    (HERE / 'results/summary.json').write_text(
        json.dumps(rows, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')


if __name__ == '__main__':
    main()
