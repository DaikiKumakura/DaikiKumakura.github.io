import unittest
from analysis import decompose


class DenominatorTests(unittest.TestCase):
    def test_partition_and_identity(self):
        for n in range(1, 31):
            for b in range(1, n + 1):
                for k in range(b + 1):
                    d = decompose(n, b, k)
                    self.assertEqual(k + d['both_other'] + d['without_both'], n)
                    self.assertAlmostEqual(d['both_fraction'] * d['top_given_both'], d['top_fraction'])

    def test_invalid(self):
        for x in [(0, 0, 0), (5, 0, 0), (5, 6, 2), (5, 3, 4), (5, 3, -1)]:
            with self.assertRaises(ValueError):
                decompose(*x)


if __name__ == '__main__':
    unittest.main()
