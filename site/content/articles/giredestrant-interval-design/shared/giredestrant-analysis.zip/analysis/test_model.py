"""Independent numerical checks for the public oral PK implementation."""
import unittest
import numpy as np
from scipy.integrate import solve_ivp, quad
from model import concentration, single_metrics, steady_metrics

P=dict(cl=5.893909626719058,vc=117.51119519702235,q=15.396192453563113,vp=196.9567594415722,ka=1.)


class ModelChecks(unittest.TestCase):
    def test_ode(self):
        def rhs(t,a):
            gut,central,peripheral=a
            exchange=P['q']*(central/P['vc']-peripheral/P['vp'])
            return [-P['ka']*gut,P['ka']*gut-P['cl']*central/P['vc']-exchange,exchange]
        ts=np.array([0,.5,1,2,4,12,24,48,96])
        sol=solve_ivp(rhs,(0,96),[30,0,0],t_eval=ts,rtol=1e-10,atol=1e-12)
        np.testing.assert_allclose(concentration(ts,30,P),sol.y[1]/P['vc']*1000,rtol=1e-8,atol=1e-7)

    def test_auc_infinite(self):
        area=quad(lambda t:concentration(t,30,P)[0],0,np.inf)[0]
        self.assertAlmostEqual(area,30*1000/P['cl'],places=6)

    def test_periodic_superposition(self):
        ts=np.array([0,1,12,23.9])
        explicit=sum(concentration(ts+24*j,30,P) for j in range(100))
        np.testing.assert_allclose(explicit,concentration(ts,30,P,24),rtol=1e-12)

    def test_periodic_auc(self):
        for dose,tau in [(15,12),(30,24),(60,48)]:
            area=quad(lambda t:concentration(t,dose,P,tau)[0],0,tau)[0]*48/tau
            self.assertAlmostEqual(area,steady_metrics(P,dose,tau)[2],places=6)

    def test_dose_linearity(self):
        np.testing.assert_allclose(concentration([1,4,24],60,P),2*concentration([1,4,24],30,P))

    def test_nonnegative_and_periodic_endpoints(self):
        for tau in [12,24,48]:
            c=concentration(np.linspace(0,tau,301),30,P,tau)
            self.assertTrue(np.all(c>0))
            self.assertAlmostEqual(c[0],c[-1],places=8)

    def test_single_auc_window(self):
        numeric=quad(lambda t:concentration(t,30,P)[0],0,24)[0]
        self.assertAlmostEqual(numeric,single_metrics(P)[1],places=7)

    def test_long_interval_limit(self):
        np.testing.assert_allclose(concentration([1,12,24],30,P,3000),concentration([1,12,24],30,P),rtol=1e-12)

    def test_unit_conversion(self):
        p=dict(cl=1.,vc=1.,q=0.,vp=0.,ka=2.)
        self.assertAlmostEqual(concentration(1,1,p)[0],2000*(np.exp(-1)-np.exp(-2)),places=9)


if __name__=='__main__':unittest.main()
