"""Fit observed summaries, then inspect unused repeat-dose summaries."""
from pathlib import Path
import json, hashlib, platform
import numpy as np
import pandas as pd
import scipy
from scipy.optimize import least_squares, minimize_scalar
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from model import concentration, single_metrics, steady_metrics

ROOT=Path(__file__).resolve().parents[1]
INPUT=json.loads((ROOT/'analysis/inputs.json').read_text(encoding='utf8'))
OUT=ROOT/'outputs'
for d in ['figures','tables']:(OUT/d).mkdir(parents=True,exist_ok=True)
plt.rcParams.update({'font.size':11,'axes.spines.top':False,'axes.spines.right':False,'figure.dpi':130})
COLORS=['#0072B2','#009E73','#D55E00']


def fit(two: bool, ka: float) -> dict:
    row=INPUT['single'][1]
    observed=np.array([row[k] for k in ['cmax','auc24','aucinf','half']])
    # Diagonal working weights only: within-person summary covariance is unavailable.
    se=np.sqrt(np.log1p((np.array(row['cv'])/100)**2)/row['n'])
    def unpack(x):
        a=np.exp(x);return dict(cl=a[0],vc=a[1],q=a[2] if two else 0.,vp=a[3] if two else 0.,ka=ka)
    def residual(x):return np.log(single_metrics(unpack(x))/observed)/se
    starts=([6,50,5,250],[6,80,20,300],[6,30,50,200]) if two else ([6,300],)
    solutions=[]
    for s in starts:
        r=least_squares(residual,np.log(s),bounds=(np.log([.1,1,.05,1] if two else [.1,1]),np.log([100,3000,300,5000] if two else [100,3000])),max_nfev=1200)
        solutions.append(r)
    r=min(solutions,key=lambda r:np.sum(r.fun**2))
    return dict(parameters=unpack(r.x),working_objective=float(sum(r.fun**2)),single_prediction=single_metrics(unpack(r.x)).tolist(),jacobian_condition=float(np.linalg.cond(r.jac)),success=bool(r.success))


def main():
    fits={'one':fit(False,1.),**{str(k):fit(True,k) for k in INPUT['absorption_rates_per_hour']}}
    p=fits[str(INPUT['main_absorption_rate_per_hour'])]['parameters']
    (OUT/'fit.json').write_text(json.dumps(fits,indent=2)+'\n')
    validations=[]
    for r in INPUT['repeat']:
        peak,trough,auc48=steady_metrics(p,r['dose'],24)
        for key,pred in zip(['cmax','auc','cmin'],[peak,auc48/2,trough]):
            validations.append(dict(dose=r['dose'],endpoint=key,observed=r[key],predicted=pred,ratio=pred/r[key],n=r['n']))
    pd.DataFrame(validations).to_csv(OUT/'tables/heldout.csv',index=False)
    single_checks=[]
    for r in INPUT['single']:
        pred=single_metrics(p,r['dose'])
        for key,value in zip(['cmax','auc24','aucinf','half'],pred):single_checks.append(dict(dose=r['dose'],endpoint=key,observed=r[key],predicted=value))
    pd.DataFrame(single_checks).to_csv(OUT/'tables/single_checks.csv',index=False)
    # Structural sensitivity: absorption is fixed at four plausible values, not estimated.
    sens=[]
    for k in INPUT['absorption_rates_per_hour']:
        fp=fits[str(k)]['parameters']
        tmax=minimize_scalar(lambda t:-concentration(t,30,fp)[0],bounds=(0,24),method='bounded').x
        for regimen in INPUT['regimens']:
            metrics=steady_metrics(fp,regimen['dose'],regimen['tau'])
            sens.append(dict(tmax=tmax,regimen=regimen['label'],cmax=metrics[0],cmin=metrics[1],auc48=metrics[2],**fp))
    pd.DataFrame(sens).to_csv(OUT/'tables/structural.csv',index=False)
    rng=np.random.default_rng(INPUT['seed']);z=rng.normal(size=INPUT['virtual_n'])
    virtual=[];paired=[]
    for cv in INPUT['conditional_cl_cv']:
        subjects=[dict(p,cl=p['cl']*np.exp(np.sqrt(np.log1p(cv**2))*zi)) for zi in z]
        arrays={r['label']:np.array([steady_metrics(sp,r['dose'],r['tau']) for sp in subjects]) for r in INPUT['regimens']}
        base=arrays['30 mg Q24h']
        for label,arr in arrays.items():
            for j,endpoint in enumerate(['cmax','cmin','auc48']):
                quant=np.quantile(arr[:,j],[.05,.5,.95]);ratios=np.quantile(arr[:,j]/base[:,j],[.05,.5,.95])
                virtual.append(dict(cl_cv=cv,regimen=label,endpoint=endpoint,p05=quant[0],median=quant[1],p95=quant[2]))
                paired.append(dict(cl_cv=cv,regimen=label,endpoint=endpoint,p05=ratios[0],median=ratios[1],p95=ratios[2]))
        assert np.max(np.abs(arrays['60 mg Q48h'][:,2]/base[:,2]-1))<1e-12
    pd.DataFrame(virtual).to_csv(OUT/'tables/virtual.csv',index=False)
    pd.DataFrame(paired).to_csv(OUT/'tables/paired.csv',index=False)
    # Model checking figure. The training and holdout sets are visibly separated.
    fig,axes=plt.subplots(1,3,figsize=(13,4.2))
    names=['Cmax (ng/mL)','AUC0-24 (ng h/mL)','Terminal half-life (h)']
    indices=[0,1,3]
    for ax,name,j in zip(axes,names,indices):
        obs=INPUT['single'][1][['cmax','auc24','aucinf','half'][j]]
        ax.bar([0,1,2],[obs,fits['one']['single_prediction'][j],fits['1.0']['single_prediction'][j]],color=['#888888',COLORS[2],COLORS[0]])
        ax.set_xticks([0,1,2],['Observed','1-comp','2-comp']);ax.set_ylabel(name);ax.set_title('Single 30 mg, n=6')
    fig.tight_layout();fig.savefig(OUT/'figures/01-fit.png');plt.close(fig)
    fig,axes=plt.subplots(1,3,figsize=(13,4.2))
    df=pd.DataFrame(validations)
    for ax,key,label in zip(axes,['cmax','auc','cmin'],['Cmax','AUC0-24','Predose']):
        rows=df[df.endpoint==key];ax.plot(rows.dose,rows.ratio,'o-',color=COLORS[0]);ax.axhline(1,color='#666',ls='--')
        ax.set_xscale('log');ax.set_xticks([10,30,90,250],[10,30,90,250]);ax.set_xlabel('Daily dose (mg)');ax.set_ylabel('Model / observed geometric mean');ax.set_title(label);ax.set_ylim(0,2)
    fig.suptitle('Unused repeated-dose data: descriptive model check (n=5,10,10,3)',y=1.02)
    fig.tight_layout();fig.savefig(OUT/'figures/02-holdout.png',bbox_inches='tight');plt.close(fig)
    fig,axes=plt.subplots(1,2,figsize=(11.5,4.3))
    t=np.linspace(0,48,961)
    for c,r in zip(COLORS,INPUT['regimens']):
        axes[0].plot(t,concentration(t%r['tau'],r['dose'],p,r['tau']),label=r['label'],color=c)
    axes[0].set(xlabel='Time in common 48-hour window (h)',ylabel='Concentration (ng/mL)',ylim=(0,None));axes[0].legend(fontsize=9)
    rows=pd.DataFrame(paired);rows=rows[(rows.cl_cv==.6)&(rows.endpoint!='auc48')]
    for j,endpoint in enumerate(['cmax','cmin']):
        sub=rows[rows.endpoint==endpoint];x=np.arange(3)+(j-.5)*.13
        axes[1].errorbar(x,sub['median'],yerr=[sub['median']-sub.p05,sub.p95-sub['median']],fmt='o',capsize=4,label=endpoint,color=COLORS[j])
    axes[1].axhline(1,color='#777',ls='--');axes[1].set_xticks(range(3),['15 mg Q12h','30 mg Q24h','60 mg Q48h'],rotation=10)
    axes[1].set(ylabel='Within-person ratio to 30 mg Q24h',ylim=(0,2));axes[1].legend();axes[1].set_title('Assumed CL CV=60%; n=2048; 5-95% range',fontsize=10)
    fig.tight_layout();fig.savefig(OUT/'figures/03-regimens.png');plt.close(fig)
    env=dict(python=platform.python_version(),numpy=np.__version__,pandas=pd.__version__,scipy=scipy.__version__,matplotlib=matplotlib.__version__)
    (OUT/'environment.json').write_text(json.dumps(env,indent=2)+'\n')
    hashes={f.name:hashlib.sha256(f.read_bytes()).hexdigest() for f in (ROOT/'data/raw').glob('*') if f.is_file()}
    if hashes:(OUT/'source-hashes.json').write_text(json.dumps(hashes,indent=2)+'\n')
    print(json.dumps({'fit':fits,'heldout30':[r for r in validations if r['dose']==30],'paired':paired},indent=2))


if __name__=='__main__':main()
