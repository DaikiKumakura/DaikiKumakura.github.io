"""Apparent oral PK. No absolute bioavailability is applied twice."""
import numpy as np
from scipy.optimize import minimize_scalar


def terms(p: dict) -> tuple:
    """Return exponential coefficients and rates; concentrations in ng/mL."""
    cl, vc, ka = p['cl'], p['vc'], p['ka']
    if p.get('q', 0) == 0:
        k = cl / vc
        rates = np.array([k, ka])
        co = np.array([1., -1.]) * ka / (ka-k) / vc * 1000
    else:
        k10, k12, k21 = cl/vc, p['q']/vc, p['q']/p['vp']
        s = k10+k12+k21
        alpha, beta = (s+np.sqrt(s*s-4*k10*k21))/2, (s-np.sqrt(s*s-4*k10*k21))/2
        a, b = (alpha-k21)/(alpha-beta), (k21-beta)/(alpha-beta)
        ca, cb = ka*a/(ka-alpha), ka*b/(ka-beta)
        co = np.array([ca, cb, -ca-cb]) / vc * 1000
        rates = np.array([alpha, beta, ka])
    return co, rates


def concentration(t, dose: float, p: dict, tau: float | None = None):
    co, rates = terms(p)
    factors = np.ones_like(rates) if tau is None else -np.expm1(-rates*tau)
    return dose * (np.exp(-np.outer(np.asarray(t).reshape(-1), rates)) @ (co/factors))


def single_metrics(p: dict, dose: float = 30.) -> np.ndarray:
    co, rates = terms(p)
    peak = minimize_scalar(lambda t: -concentration(t, dose, p)[0], bounds=(0,24), method='bounded')
    auc24 = dose*np.sum(co*(-np.expm1(-rates*24))/rates)
    return np.array([-peak.fun, auc24, dose*1000/p['cl'], np.log(2)/min(rates)])


def steady_metrics(p: dict, dose: float, tau: float) -> np.ndarray:
    peak = minimize_scalar(lambda t: -concentration(t, dose, p, tau)[0], bounds=(0,tau), method='bounded')
    # Always compare a common 48-hour window (not unequal per-dose AUCs).
    return np.array([-peak.fun, concentration(tau,dose,p,tau)[0], 48/tau*dose*1000/p['cl']])
