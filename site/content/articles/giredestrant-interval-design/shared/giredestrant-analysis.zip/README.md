# Giredestrant interval design

Public aggregate-data research, not treatment or clinical-trial dose advice.
Use a Python environment containing requirements.txt packages.
Run: python analysis/run_analysis.py
Test: python -m unittest discover -s analysis -p "test_*.py" -q
No account or downloads required. Numeric inputs and source locations: analysis/inputs.json.

Fit four observed single-dose 30-mg summary endpoints (n=6) from Malhi et al.,
Cancer Research Communications 2023, DOI10.1158/2767-9764.CRC-23-0324 Tables1/2.
This estimates an aggregate surrogate, NOT individual NLME or the original PopPK.
Fixed ka=1/h; CL/F,Vc/F,Q/F,Vp/F fitted. Four summaries/four unknowns means zero
residual degrees of freedom. Exact in-sample matching is NOT validation. Diagonal
working weights ignore unknown endpoint covariance; no likelihood-based CIs or AIC.
Absorption alternatives 0.5,2,4/h are assumptions, not a confidence interval.

Repeat-dose summaries never enter fitting. They are a descriptive check within the
same trial, potentially overlapping participants, NOT external validation. The
model overpredicts them, including 16-21% at 30mg and larger errors at other doses.
No post-hoc refit. Geometric summaries need not describe one coherent typical person.

Oral apparent coefficients: do not multiply absolute F again. Concentrations ng/mL,
amount mg, time h, volume L. Central/peripheral amounts are parameterized surrogates.
Equal daily-average 15Q12h,30Q24h,60Q48h schedules have equal periodic common-48h AUC
by linear-model algebra. Relative comparisons assume unchanged formulation/F,
time-invariant clearance, adherence and linearity. No clinical schedule validation,
tablet-divisibility assessment, benefit or safety equivalence is claimed.

2048 identical normal draws across schedules, seed20261019. ONLY CL varies, with
assumed CV30% or60%, median CL equals fitted CL. No estimated Omega, joint covariate
distribution or residual assay error. Percentiles are hypothetical patient ranges,
NOT clinical prediction intervals or parameter confidence intervals. No PET EC50,
HR E-R, efficacy or bradycardia prediction. QTc coefficients are never used as HR.

Tables and figures regenerate from code. Original source-hashes.json preserves the
consulted raw-file snapshot and is not renewed source validation. pk.html,qt.html,
clinical.html in that snapshot are failed browser-check responses, NOT analyzed
source data; numeric PK facts were transcribed from publicly rendered PMC tables.
Clinical-original.pdf is a public accepted manuscript from the ICR repository.
No raw papers or original source graphics are redistributed. Original code is MIT;
numerical source facts remain attributed. Clinical evidence audit is in the article.
