# Companion: exponential-growth versus Gompertz-growth models in simulated xenograft studies

Simulation code and aggregate results for the article "Does the growth model for vehicle tumours change what a xenograft study says about potency and efficacy? Simulated studies with Gompertz vehicle growth and an exponential-growth model". No animal data are used.

## Files

- `simulate.R`: simulates xenograft studies (5 arms, 8 animals per arm, Gompertz vehicle growth, constant-concentration kill rate), fits an exponential-growth model and the Gompertz model by least squares to the log volume, and records the estimates of the maximal kill rate and half-maximal concentration, the predicted treated-to-vehicle volume ratio, and the AIC comparison (`Rscript simulate.R 2000`; seed 20261122; writes `results/summary.csv` and `results/session-info.txt`). Base R only.
- `check_kmax_approximation.R`: compares the closed-form approximation of the exponential model's maximal kill rate with the simulated medians (`Rscript check_kmax_approximation.R`).
- `figures.R`: draws Figures 1 and 2 from `results/summary.csv` (requires ggplot2).
- `results/summary.csv`: aggregate results for every Gompertz rate, duration and model (Tables 2 and 3 and the text).
- `results/session-info.txt`: R 4.5.3 session information.

## Reproduce

```
Rscript simulate.R 2000
Rscript figures.R
```

The scripts find their own folder, so they can be run from any directory. The output depends on the random-number stream of the R version used.
