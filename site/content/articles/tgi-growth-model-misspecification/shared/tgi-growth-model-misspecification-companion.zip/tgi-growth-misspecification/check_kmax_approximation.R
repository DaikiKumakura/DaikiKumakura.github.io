# Closed-form approximation of the exponential model's maximal kill rate: kmax * sum(g(t) * t) / sum(t^2), g(t) = (1 - exp(-beta t)) / beta,
# compared with the median estimate in results/summary.csv. Run: Rscript check_kmax_approximation.R (after simulate.R)
script_dir <- dirname(normalizePath(sub("^--file=", "", grep("^--file=", commandArgs(FALSE), value = TRUE)[1]), winslash = "/"))
o <- read.csv(file.path(script_dir, "results/summary.csv")); o <- o[o$model == "exp", ]
D <- c(0,3,7,10,14,18,21,25,28)
for(i in seq_len(nrow(o))){b<-o$beta[i];d<-o$duration_days[i];t<-D[D<=d];g<-(1-exp(-b*t))/b
 cat(b,d,round(0.2*sum(g*t)/sum(t^2),3),round(o$kmax_median[i],3),"\n")}
