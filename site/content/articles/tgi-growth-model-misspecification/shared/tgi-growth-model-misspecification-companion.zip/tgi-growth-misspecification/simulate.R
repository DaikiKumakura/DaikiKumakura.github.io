# Xenograft tumour growth inhibition: what happens to the estimated potency when the control tumours grow in a Gompertz way
# but the model assumes exponential growth? Compares an exponential-growth model with the correct Gompertz model. R 4.5.3, base R only.
# Run: Rscript simulate.R 1000      (studies per setting; seed 20261122)
script_dir <- dirname(normalizePath(sub("^--file=", "", grep("^--file=", commandArgs(FALSE), value = TRUE)[1]), winslash = "/"))
args <- commandArgs(trailingOnly = TRUE)
SEED <- 20261122L; NREP <- if (length(args) >= 1) as.integer(args[1]) else 1000L
X0 <- log(150)            # log initial volume (mm^3)
X21 <- log(1470)          # log volume of the vehicle tumours at day 21 (kept equal across growth settings)
BETA_GRID <- c(0.05, 0.02, 0.10)   # Gompertz rate (per day); the plateau is set so that the vehicle volume at day 21 equals X21
KMAX <- 0.20              # maximal kill rate (per day)
EC50 <- 3                 # concentration of half-maximal kill (arbitrary units; concentration held constant over the study)
CONC <- c(0, 1, 3, 10, 30)    # vehicle and four treatment arms
N_ANIMALS <- 8            # animals per arm
SD_X0 <- 0.10             # between-animal SD of the initial log volume
SD_OBS <- 0.15            # SD of log measurement error
ALL_DAYS <- c(0, 3, 7, 10, 14, 18, 21, 25, 28)
DURATIONS <- c(14, 21, 28)
C_PRED <- 5; T_PRED <- 28 # held-out question: tumour volume ratio treated / vehicle at day 28 for concentration 5

kill <- function(conc, kmax, ec50) kmax * conc / (ec50 + conc)
# Gompertz with constant kill: dx/dt = BETA (xinf - x) - k, x = log volume
xg <- function(t, x0, xinf, beta, k) { xss <- xinf - k / beta; xss + (x0 - xss) * exp(-beta * t) }
xe <- function(t, x0, kg, k) x0 + (kg - k) * t
true_ratio <- function() { xg(T_PRED, X0, XINF, BETA, kill(C_PRED, KMAX, EC50)) - xg(T_PRED, X0, XINF, BETA, 0) }

simulate_study <- function(days) {
  d <- expand.grid(animal = seq_len(N_ANIMALS * length(CONC)), day = days)
  d$conc <- rep(rep(CONC, each = N_ANIMALS), times = length(days))
  x0i <- rnorm(N_ANIMALS * length(CONC), X0, SD_X0)[d$animal]
  d$x <- xg(d$day, x0i, XINF, BETA, kill(d$conc, KMAX, EC50)) + rnorm(nrow(d), 0, SD_OBS)
  d
}
fit_exp <- function(d, tin) {
  # parameters: x0, kg, log kmax, log ec50
  f <- function(p) sum((d$x - xe(d$day, p[1], p[2], kill(d$conc, exp(p[3]), exp(p[4]))))^2)
  best <- NULL
  for (s in list(c(5, 0.1, log(0.2), log(3)), c(5, 0.05, log(0.1), log(10)), c(5, 0.15, log(0.5), log(1)))) {
    o <- try(optim(s, f, method = "BFGS", control = list(maxit = 500)), silent = TRUE)
    if (!inherits(o, "try-error") && (is.null(best) || o$value < best$value)) best <- o
  }
  if (is.null(best)) return(rep(NA_real_, 6)); p <- best$par
  c(kmax = exp(p[3]), ec50 = exp(p[4]), pred = xe(T_PRED, p[1], p[2], kill(C_PRED, exp(p[3]), exp(p[4]))) - xe(T_PRED, p[1], p[2], 0), sse = best$value,
    pin = xe(tin, p[1], p[2], kill(C_PRED, exp(p[3]), exp(p[4]))) - xe(tin, p[1], p[2], 0))
}
fit_gomp <- function(d, tin) {
  # parameters: x0, log(xinf - x0), log beta, log kmax, log ec50
  f <- function(p) { xinf <- p[1] + exp(p[2]); sum((d$x - xg(d$day, p[1], xinf, exp(p[3]), kill(d$conc, exp(p[4]), exp(p[5]))))^2) }
  best <- NULL
  for (s in list(c(5, log(3), log(0.05), log(0.2), log(3)), c(5, log(2), log(0.1), log(0.1), log(10)), c(5, log(4), log(0.03), log(0.5), log(1)))) {
    o <- try(optim(s, f, method = "BFGS", control = list(maxit = 800)), silent = TRUE)
    if (!inherits(o, "try-error") && (is.null(best) || o$value < best$value)) best <- o
  }
  if (is.null(best)) return(rep(NA_real_, 6)); p <- best$par; xinf <- p[1] + exp(p[2])
  c(kmax = exp(p[4]), ec50 = exp(p[5]),
    pred = xg(T_PRED, p[1], xinf, exp(p[3]), kill(C_PRED, exp(p[4]), exp(p[5]))) - xg(T_PRED, p[1], xinf, exp(p[3]), 0), sse = best$value,
    pin = xg(tin, p[1], xinf, exp(p[3]), kill(C_PRED, exp(p[4]), exp(p[5]))) - xg(tin, p[1], xinf, exp(p[3]), 0))
}

set.seed(SEED); rows <- list()
for (BETA in BETA_GRID) {
XINF <- (X21 - X0 * exp(-21 * BETA)) / (1 - exp(-21 * BETA)); truth <- true_ratio()
for (dur in DURATIONS) {
  days <- ALL_DAYS[ALL_DAYS <= dur]
  res <- lapply(seq_len(NREP), function(i) { d <- simulate_study(days); list(e = fit_exp(d, dur), g = fit_gomp(d, dur)) })
  true_in <- xg(dur, X0, XINF, BETA, kill(C_PRED, KMAX, EC50)) - xg(dur, X0, XINF, BETA, 0)
  nobs <- N_ANIMALS * length(CONC) * length(days)
  sse_e <- sapply(res, function(r) r$e["sse"]); sse_g <- sapply(res, function(r) r$g["sse"])
  aic_pref_g <- mean((nobs * log(sse_g / nobs) + 2 * 5) < (nobs * log(sse_e / nobs) + 2 * 4), na.rm = TRUE)   # exponential model has 4 parameters, Gompertz 5
  for (m in c("exp", "gomp")) {
    mat <- t(sapply(res, function(r) r[[substr(m, 1, 1)]]))
    ok <- is.finite(mat[, "pred"]) & mat[, "ec50"] < 1e4 & mat[, "kmax"] < 1e3   # estimates at an optimisation bound are flagged
    q <- function(v) quantile(v, c(0.05, 0.5, 0.95), na.rm = TRUE)
    rows[[length(rows) + 1]] <- data.frame(beta = BETA, plateau_volume = exp(XINF), duration_days = dur, model = m, studies = NREP, fit_failed = mean(!is.finite(mat[, "pred"])), at_bound = mean(!ok & is.finite(mat[, "pred"])),
      true_kmax = KMAX, true_ec50 = EC50, true_log_ratio = truth,
      kmax_median = q(mat[ok, "kmax"])[2], kmax_q05 = q(mat[ok, "kmax"])[1], kmax_q95 = q(mat[ok, "kmax"])[3],
      ec50_median = q(mat[ok, "ec50"])[2], ec50_q05 = q(mat[ok, "ec50"])[1], ec50_q95 = q(mat[ok, "ec50"])[3],
      pred_log_ratio_median = q(mat[ok, "pred"])[2], pred_q05 = q(mat[ok, "pred"])[1], pred_q95 = q(mat[ok, "pred"])[3],
      pred_ratio_error_median = median(exp(mat[ok, "pred"] - truth)) , sse_median = median(mat[ok, "sse"]), true_log_ratio_at_last_day = true_in, pred_in_median = median(mat[ok, "pin"]), pred_in_q05 = quantile(mat[ok, "pin"], 0.05), pred_in_q95 = quantile(mat[ok, "pin"], 0.95), observations = nobs, aic_prefers_gompertz = aic_pref_g)
  }
  cat("beta", BETA, "duration", dur, "done", fill = TRUE)
}
}
out <- do.call(rbind, rows); dir.create(file.path(script_dir, "results"), showWarnings = FALSE)
write.csv(out, file.path(script_dir, "results/summary.csv"), row.names = FALSE)
writeLines(capture.output(sessionInfo()), file.path(script_dir, "results/session-info.txt"))
options(width = 230); o <- out[, c(1, 3, 4, 6, 7, 11, 14, 17)]; o[4:8] <- round(o[4:8], 3); print(o, row.names = FALSE)
