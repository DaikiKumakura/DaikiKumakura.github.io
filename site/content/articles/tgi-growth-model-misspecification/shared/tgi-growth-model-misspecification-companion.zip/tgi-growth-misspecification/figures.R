# Figures for the tumour-growth-model article (Okabe-Ito palette). Run: Rscript figures.R (after simulate.R)
script_dir <- dirname(normalizePath(sub("^--file=", "", grep("^--file=", commandArgs(FALSE), value = TRUE)[1]), winslash = "/"))
suppressPackageStartupMessages(library(ggplot2))
o <- read.csv(file.path(script_dir, "results/summary.csv"))
o$model <- factor(o$model, c("exp", "gomp"), c("Exponential growth", "Gompertz growth (correct)"))
o$beta_lab <- factor(o$beta, c(0.02, 0.05, 0.10), c("Gompertz rate 0.02 /day", "Gompertz rate 0.05 /day", "Gompertz rate 0.10 /day"))
cols <- c("Exponential growth" = "#D55E00", "Gompertz growth (correct)" = "#0072B2")
p1 <- ggplot(o, aes(factor(duration_days), kmax_median, colour = model, group = model)) +
  geom_hline(yintercept = 0.2, colour = "grey50") +
  geom_pointrange(aes(ymin = kmax_q05, ymax = kmax_q95), position = position_dodge(width = 0.4), linewidth = 0.7) +
  facet_wrap(~beta_lab) + scale_colour_manual(values = cols, name = "Fitted growth model") +
  labs(x = "Study duration (days)", y = "Maximal kill rate (per day)") + theme_bw(base_size = 12) + theme(legend.position = "bottom")
ggsave(file.path(script_dir, "figures/figure-1-kmax.png"), p1, width = 9.5, height = 4.8, dpi = 160)
e <- o[o$model == "Exponential growth", ]
l <- rbind(data.frame(e[, c("beta_lab", "duration_days")], what = "At the last observation day", ratio = exp(e$pred_in_median - e$true_log_ratio_at_last_day)),
           data.frame(e[, c("beta_lab", "duration_days")], what = "At day 28 (extrapolated unless the study lasts 28 days)", ratio = exp(e$pred_log_ratio_median - e$true_log_ratio)))
p2 <- ggplot(l, aes(factor(duration_days), ratio, colour = what, shape = what, group = what)) +
  geom_hline(yintercept = 1, colour = "grey50") + geom_line(linewidth = 0.6) + geom_point(size = 3) + facet_wrap(~beta_lab) +
  scale_colour_manual(values = c("#009E73", "#D55E00"), name = "Prediction for concentration 5") + scale_shape_manual(values = c(16, 17), name = "Prediction for concentration 5") +
  labs(x = "Study duration (days)", y = "Predicted / true volume ratio (median)") + theme_bw(base_size = 12) + theme(legend.position = "bottom") +
  guides(colour = guide_legend(nrow = 2), shape = guide_legend(nrow = 2))
ggsave(file.path(script_dir, "figures/figure-2-prediction.png"), p2, width = 9.5, height = 5, dpi = 160)
