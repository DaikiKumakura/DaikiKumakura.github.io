"""Original plots from transcribed aggregates and rank-scale arithmetic."""
from pathlib import Path
import csv
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

HERE=Path(__file__).resolve().parent
rows=list(csv.DictReader((HERE/'dnm1-summary.csv').open(encoding='utf-8')))
(HERE/'figures').mkdir(exist_ok=True)
fig,ax=plt.subplots(figsize=(8,4.5))
for status,color,label in [('previously_reported','#a45b32','Previously reported (3)'),('prospective','#166277','Prospective (9)')]:
    selected=[r for r in rows if r['status']==status]
    ax.scatter([int(r['extension_aa']) for r in selected],[float(r['alt_3ss_rate']) for r in selected],c=color,label=label,s=55)
ax.annotate('13 aa; 0.76',(13,.76),xytext=(17,.94),arrowprops={'arrowstyle':'->'},fontsize=10)
ax.set(xlabel='In-frame exon extension (amino acids)',ylabel="Alternative 3' splice-site rate",ylim=(0,1.03))
ax.legend(loc='lower left');ax.grid(alpha=.2)
fig.text(.5,.025,'Selected reporter-assay aggregates from Table S4; not clinical risk or model accuracy.',ha='center',fontsize=9)
fig.tight_layout(rect=(0,.07,1,1));fig.savefig(HERE/'figures/01-dnm1-assay.png',dpi=180)
fig,ax=plt.subplots(figsize=(7,4))
qs=list(range(0,41));ax.plot(qs,[100*10**(-q/10) for q in qs],color='#166277')
ax.scatter([24.7],[100*10**(-24.7/10)],color='#a45b32',zorder=3)
ax.annotate('Reported DNM1 Q=24.7\nUpper fraction ~0.339%',(24.7,100*10**(-24.7/10)),xytext=(7,.035),arrowprops={'arrowstyle':'->'},fontsize=10)
ax.set(xlabel='AVI PHRED score',ylabel='Upper fraction of SNV reference (%)',yscale='log')
ax.grid(alpha=.2);fig.tight_layout();fig.savefig(HERE/'figures/02-phred-rank.png',dpi=180)
