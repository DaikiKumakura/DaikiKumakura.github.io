# Recalculate the published aggregate audit

Run `python analysis.py` using Python 3.11 or newer. This uses only the standard library. For original plots, install matplotlib and run `python plot.py`.

`dnm1-summary.csv` manually transcribes 12 selected aggregate rows from Table S4 of the AlphaGenome Atlas report linked by Google DeepMind in September 2026. Source: https://storage.googleapis.com/deepmind-media/DeepMind.com/Blog/alphagenome-atlas-a-predictive-map-of-every-possible-dna-letter-change-in-the-human-genome/alphagenome-atlas.pdf . Coordinates are GRCh38. The rates are reported reporter-assay summaries, not patient measurements, diagnostic probabilities, or a complete screen. This archive does not include original figures, sequences, individual genomes, model weights or official source code.

The PHRED conversion is arithmetic from the stated rank scale: upper reference fraction = 10^(-Q/10). It does not convert scores to disease probability. Q=24.7 is the author's reported score for chr9:128225994:G>A; no model or Atlas API was run. Contributions on raw scores cannot be added on the PHRED scale.

The checks require 12 unique variants, rates between zero and one, and extension lengths consistent with in-frame codons. Replicate-level measurements were not obtained; no error bars, predictive-performance estimate, or new pathogenicity classifications are calculated.

The MIT license applies to the original calculation and plotting code and accompanying original documentation. The transcribed numerical aggregates are attributed to the report in input-provenance.json; this archive grants no license to the report, model, API or third-party assets.
