"""Audit transcribed DNM1 aggregate data and convert AVI PHRED rank units."""
import csv
import json
import math
import statistics
from pathlib import Path

HERE=Path(__file__).resolve().parent


def upper_fraction(q):
    if not math.isfinite(q) or q < 0:
        raise ValueError('PHRED must be finite and nonnegative')
    return 10 ** (-q / 10)


def main():
    rows=list(csv.DictReader((HERE/'dnm1-summary.csv').open(encoding='utf-8',newline='')))
    assert len(rows)==12 and len({r['variant'] for r in rows})==12
    for row in rows:
        assert int(row['extension_bp'])==3*int(row['extension_aa'])
        assert 0 <= float(row['alt_3ss_rate']) <= 1
    rates=[float(r['alt_3ss_rate']) for r in rows]
    out=HERE/'results';out.mkdir(exist_ok=True)
    result={'variants':len(rows),'previously_reported':sum(r['status']=='previously_reported' for r in rows),
            'prospective':sum(r['status']=='prospective' for r in rows),
            'rate_min':min(rates),'rate_max':max(rates),'rate_median':statistics.median(rates),
            'extension_aa_min':min(int(r['extension_aa']) for r in rows),
            'extension_aa_max':max(int(r['extension_aa']) for r in rows),
            'scope':'Selected Table S4 aggregate values; no replicate uncertainty or diagnostic accuracy estimate'}
    (out/'summary.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
    with (out/'phred-rank.csv').open('w',encoding='utf-8',newline='') as f:
        writer=csv.writer(f);writer.writerow(['phred','upper_fraction','upper_percent','interpretation'])
        for q in [10,20,24.7,30,40]:
            writer.writerow([q,upper_fraction(q),100*upper_fraction(q),'SNV-reference rank fraction; not pathogenicity probability'])
    print(json.dumps(result,indent=2))


if __name__=='__main__':
    main()
