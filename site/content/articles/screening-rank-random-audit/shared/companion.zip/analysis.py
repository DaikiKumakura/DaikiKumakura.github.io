from math import comb, sqrt

for m in (30,90,180):
    zero = comb(882,m)/comb(900,m)
    se = 900*sqrt(.02*.98/m*(900-m)/899)
    print(f"{m}: P(no hits)={zero:.6f}, SE(total)={se:.6f}")
