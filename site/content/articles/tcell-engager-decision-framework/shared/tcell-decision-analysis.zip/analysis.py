from pathlib import Path
import json,sys,platform
import numpy as np
import pandas as pd
from scipy.special import expit
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import pk,design
ROOT=Path(__file__).resolve().parent;SEED=20261006
plt.rcParams.update({'font.size':9,'figure.dpi':120,'axes.spines.top':False,'axes.spines.right':False})
def save(fig,name):fig.tight_layout();fig.savefig(ROOT/'figures'/name);plt.close(fig)
def schedule(prefix,spacing=7):
 doses=[(k*spacing,float(d)) for k,d in enumerate(prefix)]
 target=doses[-1][0];nextday=target+7
 while nextday<28:doses.append((nextday,10.));nextday+=14
 return doses,target
def probability(draw,x,t):
 H=np.zeros((len(draw['alpha']),x.shape[0],len(t)))
 for k in range(len(t)):
  for m in range(k):H[:,:,k]+=x[None,:,m]/(draw['r'][:,None]+x[None,:,m])*np.exp(-np.log(2)*(t[k]-t[m])/draw['Tadapt'][:,None])
 return expit(draw['alpha'][:,None,None]+draw['beta'][:,None,None]*np.log(x)[None,:,:]-draw['gamma'][:,None,None]*H)
def run():
 rng=np.random.default_rng(SEED);eta=rng.multivariate_normal([0,0],pk.OMEGA,5000);cl=.649*np.exp(eta[:,0]);vc=3.44*np.exp(eta[:,1])
 # Regenerate independent public benchmark, same formulas but new seed.
 benchmark=[]
 for window,start,stop,values in [('first_1mg',0,7,[106,314,49]),('first_10mg',7,14,[1100,3190,517])]:
  doses=[(0,1),(7,10),(14,10)];v=np.vstack([(pk.auc_until(stop,doses,cl,vc)-pk.auc_until(start,doses,cl,vc))/(stop-start),pk.concentration([start+pk.T],doses,cl,vc)[:,0],pk.concentration([stop],doses,cl,vc)[:,0]])
  for j,key in enumerate(['Cavg','Cmax','Ctrough']):benchmark.append(dict(window=window,endpoint=key,published_mean=values[j],virtual_mean=v[j].mean(),relative_difference_pct=100*(v[j].mean()/values[j]-1)))
 v=pk.ss(10,14,cl,vc)
 for j,key in enumerate(['Cavg','Cmax','Ctrough']):benchmark.append(dict(window='steady_10mg_Q2W',endpoint=key,published_mean=[1040,3640,472][j],virtual_mean=v[j].mean(),relative_difference_pct=100*(v[j].mean()/[1040,3640,472][j]-1)))
 validation=pd.DataFrame(benchmark);validation.to_csv(ROOT/'results/pk-validation.csv',index=False)
 fig,ax=plt.subplots(figsize=(8,3.5));x=np.arange(9);ax.bar(x-.18,validation.published_mean,width=.36,label='Published mean');ax.bar(x+.18,validation.virtual_mean,width=.36,label='Reference-covariate virtual mean');ax.set(xticks=x,xticklabels=['1:avg','1:max','1:tr','10:avg','10:max','10:tr','SS:avg','SS:max','SS:tr'],ylabel='Concentration (ng/mL)');ax.tick_params(axis='x',rotation=30);ax.legend(fontsize=8);save(fig,'02-pk-validation.png')
 fig,ax=plt.subplots(figsize=(8,3.4));E=np.geomspace(1,10000,500)
 for key,top,ec in [('ORR',.339,57.4),('DCR',.650,49.4)]:ax.plot(E,100*top*E/(ec+E),label=key)
 er=[]
 for dose in [3,10,100]:
  doses=[(0,1),(7,dose),(14,dose)];avg=pk.auc_until(28,doses,cl,vc)/28;med=np.median(avg)
  er.append(dict(target_dose=dose,Cavg_median=med,ORR_at_median=.339*med/(57.4+med),DCR_at_median=.650*med/(49.4+med),ORR_population_mean=np.mean(.339*avg/(57.4+avg)),DCR_population_mean=np.mean(.650*avg/(49.4+avg))))
  ax.axvline(med,ls=':',alpha=.5);ax.text(med,5,f'{dose} mg',rotation=90)
 ax.set(xscale='log',xlabel='Cycle 1 Cavg (ng/mL)',ylabel='Published Emax probability (%)',ylim=(0,75));ax.legend();save(fig,'03-efficacy.png');pd.DataFrame(er).to_csv(ROOT/'results/efficacy-check.csv',index=False)
 counts=pd.DataFrame({'window':['D1–7','D8–14','D15–28'],'events':[54,39,10],'n':[133]*3,'days':[7,7,14]});counts.to_csv(ROOT/'data/crs.csv',index=False)
 fig,axes=plt.subplots(1,2,figsize=(8,3.2));peaks=pk.concentration([pk.T,7+pk.T,14+pk.T],[(0,1),(7,10),(14,10)],cl,vc)/1000
 axes[0].bar(range(3),np.median(peaks,axis=0));axes[0].set(xticks=range(3),xticklabels=['D1','D8','D15'],ylabel='Virtual median peak (µg/mL)');axes[1].bar(range(3),counts.events/counts.n*100);axes[1].set(xticks=range(3),xticklabels=counts.window,ylabel='Observed window CRS (%)');save(fig,'04-crs-evidence.png')
 pred=[];ppc=[];fig,axes=plt.subplots(1,2,figsize=(10,3.7))
 models=['exposure_only','exposure_free','category','history','wide_prior','weight_quarter','weight_one','fast_history','slow_history']
 for i,name in enumerate(models):
  post=np.load(ROOT/'results'/f'{name}-draws.npz');p=post['p'];q=np.quantile(p,[.05,.5,.95],axis=0)
  replicated=rng.binomial(133,p);rq=np.quantile(replicated,[.05,.5,.95],axis=0)
  for k in range(3):ppc.append(dict(model=name,window=counts.window[k],count05=rq[0,k],count_median=rq[1,k],count95=rq[2,k],observed=int(counts.events[k]),interpretation='Marginal replicated counts only; joint window dependence not recovered'))
  for k in range(3):pred.append(dict(model=name,window=counts.window[k],p05=q[0,k],median=q[1,k],p95=q[2,k],observed=counts.events[k]/133))
  if name in ['exposure_only','category','history']:
   offset={'exposure_only':-.13,'category':0,'history':.13}[name];axes[0].errorbar(np.arange(3)+offset,q[1]*100,yerr=np.vstack([q[1]-q[0],q[2]-q[1]])*100,fmt='o',capsize=3,label=name)
  if name in ['history','wide_prior','fast_history','slow_history']:
   tq=np.quantile(post['Tadapt'],[.05,.5,.95]);axes[1].errorbar(tq[1],name,xerr=[[tq[1]-tq[0]],[tq[2]-tq[1]]],fmt='o',capsize=3)
 axes[0].scatter(np.arange(3),counts.events/133*100,marker='x',color='black',label='Observed');axes[0].set(xticks=range(3),xticklabels=counts.window,ylabel='Marginal CRS probability (%)');axes[0].legend(fontsize=7);axes[1].set(xscale='log',xlabel='History half-life (days): 90% interval');save(fig,'05-crs-posterior.png');pd.DataFrame(pred).to_csv(ROOT/'results/crs-predictive.csv',index=False)
 pd.DataFrame(ppc).to_csv(ROOT/'results/crs-ppc.csv',index=False)
 # Prior/posterior and trace: retained independently from predictive fit.
 post=np.load(ROOT/'results/history-draws.npz');fig,axes=plt.subplots(1,2,figsize=(9,3.2));prior=rng.lognormal(np.log(20),.8,20000);axes[0].hist(np.log10(prior),bins=40,density=True,alpha=.4,label='Prior');axes[0].hist(np.log10(post['Tadapt']),bins=40,density=True,alpha=.4,label='Generalized posterior');axes[0].set(xlabel='log10(history half-life / days)',ylabel='Density');axes[0].legend(fontsize=8)
 for chain in post['Tadapt'].reshape(4,-1):axes[1].plot(chain,alpha=.5,lw=.5)
 axes[1].set(yscale='log',xlabel='Draw within chain',ylabel='History half-life (days)');save(fig,'11-prior-trace.png')
 prefixes=[[10],[.1,10],[.3,10],[.5,10],[1,10],[2,10],[3,10],[.3,1,10],[.5,2,10],[1,3,10],[1,5,10],[.3,1,3,10],[.5,2,5,10],[1,3,5,10]]
 samples={k:post[k][::12] for k in ['alpha','beta','gamma','r','Tadapt']};rows=[];sens=[];administrations=[];er_sens=[]
 for prefix in prefixes:
  doses,target=schedule(prefix);times=np.array([d for d,_ in doses]);avg=pk.auc_until(28,doses,cl,vc)/28;peak=pk.concentration(times+pk.T,doses,cl,vc)/1000
  p=probability(samples,peak[::20],times);maxp=p.max(axis=2)
  trough=pk.concentration(times,doses,cl,vc)/1000
  for k,t in enumerate(times):
   pq=np.quantile(p[:,:,k],[.05,.5,.95]);cq=np.quantile(peak[:,k],[.05,.5,.95]);tq=np.quantile(trough[:,k],[.05,.5,.95])
   administrations.append(dict(regimen='→'.join(map(str,prefix)),day=t,dose_mg=doses[k][1],CRS05=pq[0],CRS_median=pq[1],CRS95=pq[2],peak05=cq[0],peak_median=cq[1],peak95=cq[2],predose05=tq[0],predose_median=tq[1],predose95=tq[2],concentration_unit='ug/mL'))
  for key,top,ec50 in [('ORR',.339,[22.5,57.4,146]),('DCR',.650,[20.9,49.4,117])]:
   for ec in ec50:er_sens.append(dict(regimen='→'.join(map(str,prefix)),endpoint=key,EC50_ng_mL=ec,population_mean=np.mean(top*avg/(ec+avg)),interpretation='One-at-a-time EC50 bound; not joint confidence interval'))
  for endpoint,values in [('Cavg',avg),('ORR',.339*avg/(57.4+avg)),('DCR',.650*avg/(49.4+avg)),('max_CRS',maxp.ravel())]:
   q=np.quantile(values,[.05,.5,.95]);rows.append(dict(regimen='→'.join(map(str,prefix)),endpoint=endpoint,p05=q[0],median=q[1],p95=q[2],target_day=target,step_count=len(prefix)-1))
  for name in ['history','wide_prior','weight_quarter','fast_history','slow_history']:
   a=np.load(ROOT/'results'/f'{name}-draws.npz');draw={k:a[k][::24] for k in ['alpha','beta','gamma','r','Tadapt']};v=probability(draw,peak[::50],times).max(axis=2).ravel();q=np.quantile(v,[.05,.5,.95]);sens.append(dict(regimen='→'.join(map(str,prefix)),model=name,p05=q[0],median=q[1],p95=q[2]))
 pd.DataFrame(administrations).to_csv(ROOT/'results/step-up-administrations.csv',index=False);pd.DataFrame(er_sens).to_csv(ROOT/'results/efficacy-sensitivity.csv',index=False)
 r=pd.DataFrame(rows);r.to_csv(ROOT/'results/step-up.csv',index=False);pd.DataFrame(sens).to_csv(ROOT/'results/step-up-sensitivity.csv',index=False)
 med=r.pivot(index='regimen',columns='endpoint',values='median');info=r.groupby('regimen')[['target_day','step_count']].first();front=[]
 for name in med.index:
  dominated=any((med.loc[j,'DCR']>=med.loc[name,'DCR']) and (med.loc[j,'max_CRS']<=med.loc[name,'max_CRS']) and (info.loc[j,'target_day']<=info.loc[name,'target_day']) and (info.loc[j,'step_count']<=info.loc[name,'step_count']) and j!=name for j in med.index)
  front.append(dict(regimen=name,non_dominated=not dominated))
 pd.DataFrame(front).to_csv(ROOT/'results/pareto.csv',index=False)
 fig,ax=plt.subplots(figsize=(9,4));points=ax.scatter(med.max_CRS*100,med.DCR*100,c=info.target_day,s=35+15*info.step_count,cmap='viridis')
 for name in ['10','1→10','0.1→10','0.5→10','0.3→1→10','0.3→1→3→10']:
  offset={'1→10':(3,-15),'0.5→10':(-35,12)}.get(name,(3,5))
  ax.annotate(name,(med.loc[name,'max_CRS']*100,med.loc[name,'DCR']*100),fontsize=8,xytext=offset,textcoords='offset points')
 ax.set(xlabel='Exploratory maximum marginal CRS probability (%)',ylabel='Transferred cycle-1 DCR model (%)');fig.colorbar(points,ax=ax,label='Day target reached');save(fig,'06-step-up.png')
 maint=[];ref=pk.ss(10,14,cl,vc)
 for dose,tau in [(10,14),(15,21),(20,28),(10,21),(10,28),(7.5,14)]:
  v=pk.ss(dose,tau,cl,vc)
  for j,key in enumerate(['Cavg','Cmax','Ctrough']):
   q=np.quantile(v[j]/ref[j],[.05,.5,.95]);maint.append(dict(dose_mg=dose,interval_days=tau,endpoint=key,median=np.median(v[j]),ratio=q[1],ratio05=q[0],ratio95=q[2]))
 m=pd.DataFrame(maint);m.to_csv(ROOT/'results/maintenance.csv',index=False);fig,axes=plt.subplots(1,3,figsize=(10,3.5))
 for ax,key in zip(axes,['Cavg','Cmax','Ctrough']):
  v=m[m.endpoint==key];ax.errorbar(np.arange(6),v.ratio,yerr=np.vstack([v.ratio-v.ratio05,v.ratio95-v.ratio]),fmt='o',capsize=3);ax.axhline(1,color='gray',ls=':');ax.set(title=key,xticks=np.arange(6),xticklabels=['10/14','15/21','20/28','10/21','10/28','7.5/14'],ylabel='Paired ratio to 10 mg Q2W');ax.tick_params(axis='x',rotation=40)
 save(fig,'07-maintenance.png')
 fig,ax=plt.subplots(figsize=(9,2.3));ax.axis('off')
 for i,text in enumerate(['Public evidence\nPK / E-R / CRS','Separate evidence\nfrom assumptions','Simulate and\nstress-test decisions','Specify the next\nmeasurement']):ax.text(.03+i*.25,.5,text,ha='left',va='center',bbox=dict(boxstyle='round,pad=.5',facecolor='#e8f0f4',edgecolor='#215e78'),fontsize=9)
 save(fig,'01-workflow.png')
 diagnostics=[json.loads(p.read_text()) for p in (ROOT/'results').glob('*-diagnostics.json')]
 env={'seed':SEED,'virtual_subjects':5000,'python':sys.version,'platform':platform.platform(),'bayesian_models':diagnostics,'interpretation':'Exploratory generalized posterior; unknown within-subject dependence; no external numeric CRS prior transferred.'}
 (ROOT/'results/environment.json').write_text(json.dumps(env,indent=2),encoding='utf8')
 cov=[]
 for wt in [50,73,100]:
  for form in ['linear_proportional','exponential']:
   factor=lambda beta:1+beta*(wt-73) if form=='linear_proportional' else np.exp(beta*(wt-73))
   for ada,asian in [(0,0),(1,0),(0,1)]:
    c=.649*factor(.00998)*(1+.215*ada);v=3.44*factor(.00810)*(1-.146*asian);values=pk.ss(10,14,c,v)
    cov.append(dict(weight_kg=wt,form=form,ADA=ada,Asian=asian,Cavg=values[0],Cmax=values[1],Ctrough=values[2],status='functional-form bracket, not verified full covariate reproduction'))
 pd.DataFrame(cov).to_csv(ROOT/'results/covariate-brackets.csv',index=False)
 controls=[]
 for prefix in [[10],[.5,10],[1,10],[.3,1,10]]:
  doses,target=schedule(prefix);times=np.array([d for d,_ in doses]);x=pk.concentration(times+pk.T,doses,.649,3.44)/1000
  values=probability(samples,x,times).max(axis=2).ravel()
  controls.append(dict(regimen='→'.join(map(str,prefix)),fixed_PK_CRS_median=np.median(values),fixed_PK_Cavg=pk.auc_until(28,doses,.649,3.44)[0]/28))
 pd.DataFrame(controls).to_csv(ROOT/'results/fixed-pk-control.csv',index=False)
 print('Clinical reconstruction and all eleven original figures completed.')
if __name__=='__main__':run()
