"""Generalized Bayesian sensitivity analysis of overlapping aggregate CRS windows.
The power likelihood is exploratory, not a recovered patient-level likelihood.
"""
from pathlib import Path
import json
import numpy as np
import pandas as pd
import pymc as pm
import arviz as az
import pk
ROOT=Path(__file__).resolve().parent;SEED=20261006
def fit(name,kind='history',weight=.5,width=1,Tcenter=20):
 rng=np.random.default_rng(SEED);eta=rng.multivariate_normal([0,0],pk.OMEGA,256)
 cl=.649*np.exp(eta[:,0]);vc=3.44*np.exp(eta[:,1]);days=np.array([0.,7.,14.])
 x=pk.concentration(days+pk.T,[(0,1),(7,10),(14,10)],cl,vc)/1000 # Cref=1 ug/mL
 with pm.Model() as model:
  alpha=pm.Normal('alpha',np.log(.4/.6),1.5*width)
  beta=pm.Normal('beta',0,1*width) if kind=='free' else pm.LogNormal('beta',np.log(.43),.7*width)
  lin=alpha+beta*np.log(x)
  if kind=='history':
   gamma=pm.LogNormal('gamma',np.log(2),.7*width)
   half=pm.LogNormal('Tadapt',np.log(Tcenter),.8*width)
   r=pm.LogNormal('r',np.log(.1),1.5*width)
   H=pm.math.stack([pm.math.zeros_like(alpha+x[:,0]),x[:,0]/(r+x[:,0])*pm.math.exp(-np.log(2)*7/half), (x[:,0]/(r+x[:,0])*pm.math.exp(-np.log(2)*14/half)+x[:,1]/(r+x[:,1])*pm.math.exp(-np.log(2)*7/half))],axis=1)
   lin=lin-gamma*H
  if kind=='category':
   delta=pm.Normal('delta',0,2,shape=2);lin=lin+pm.math.concatenate([pm.math.zeros(1),delta])
  p=pm.Deterministic('p',pm.math.mean(pm.math.sigmoid(lin),axis=0))
  ll=pm.logp(pm.Binomial.dist(n=133,p=p),np.array([54,39,10]))
  pm.Potential('composite_loglikelihood',weight*pm.math.sum(ll))
  idata=pm.sample(draws=1200,tune=1500,chains=4,cores=1,target_accept=.97,random_seed=SEED,progressbar=False)
 params=['alpha','beta']+(['gamma','Tadapt','r'] if kind=='history' else ['delta'] if kind=='category' else [])
 summary=az.summary(idata,var_names=params,ci_prob=.9);summary.to_csv(ROOT/'results'/f'{name}-summary.csv')
 # Preserve chain ordering in flattened draws (4 successive chains ×1200).
 posterior={key:np.asarray(idata.posterior[key]).reshape(-1,*np.asarray(idata.posterior[key]).shape[2:]) for key in params+['p']}
 np.savez_compressed(ROOT/'results'/f'{name}-draws.npz',**posterior)
 diagnostics={'name':name,'kind':kind,'weight':weight,'width':width,'Tcenter':Tcenter,'rhat_max':float(summary.r_hat.max()),'ess_bulk_min':float(summary.ess_bulk.min()),'divergences':int(idata.sample_stats.diverging.sum())}
 (ROOT/'results'/f'{name}-diagnostics.json').write_text(json.dumps(diagnostics,indent=2),encoding='utf8')
 print(json.dumps(diagnostics),flush=True)
 if diagnostics['rhat_max']>1.02 or diagnostics['ess_bulk_min']<200 or diagnostics['divergences']>0:raise RuntimeError('Sampler diagnostics need repair: '+name)
 return posterior
if __name__=='__main__':
 configs=[('history',{}),('exposure_only',{'kind':'positive'}),('exposure_free',{'kind':'free'}),('category',{'kind':'category'}),('wide_prior',{'width':1.6}),('weight_quarter',{'weight':.25}),('weight_one',{'weight':1}),('fast_history',{'Tcenter':5}),('slow_history',{'Tcenter':60})]
 for name,kwargs in configs:
  if not all((ROOT/'results'/f'{name}-{suffix}').exists() for suffix in ['diagnostics.json','draws.npz']):fit(name,**kwargs)
