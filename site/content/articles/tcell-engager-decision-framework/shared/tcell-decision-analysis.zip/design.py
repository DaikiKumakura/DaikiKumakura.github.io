"""Assumption-based dimensionless molecule, decision value, and sampling design.
None of these probabilities are estimated clinical success/CRS probabilities.
"""
from pathlib import Path
from itertools import product
import json
import numpy as np
import pandas as pd
from scipy.special import expit
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import pk
ROOT=Path(__file__).resolve().parent;SEED=20261006
plt.rcParams.update({'font.size':9,'figure.dpi':120,'axes.spines.top':False,'axes.spines.right':False})
ACTIONS=np.array(list(product([1,2,4,8],[3,7,14,21,28],[.03,.1,.3,.5],[1,2])))
def parameters(n,seed):
 rng=np.random.default_rng(seed)
 return np.exp(rng.normal(np.log([7,1,10,.3,10,2,1,1]),[.55,.35,.7,.7,.7,.5,.3,.3],size=(n,8)))
NAMES=['half_life','TDCC_E90','cytokine_E50','priming_P50','history_half_life','history_strength','target_density_factor','volume_scale']
def scores(theta):
 h,e,cy,pr,th,g,density,v=theta.T
 dose,tau,frac,nstep=ACTIONS.T
 k=np.log(2)/h[:,None];peak=dose[None,:]/v[:,None]/(-np.expm1(-k*tau));trough=peak*np.exp(-k*tau);avg=dose[None,:]/v[:,None]/(k*tau)
 E=e[:,None]*density[:,None]
 efficacy=avg/(avg+E/9)
 # Priming is a bounded response index, not a calibrated probability.
 step=dose[None,:]*frac/v[:,None];priming=step/(pr[:,None]+step)
 H=priming*(np.exp(-np.log(2)*7/th[:,None])+(nstep-1)*np.exp(-np.log(2)*14/th[:,None]))
 first=step/(cy[:,None]+step)
 second_peak=step*(1+np.exp(-k*7))
 second=second_peak/(cy[:,None]+second_peak)*np.exp(-g[:,None]*priming*np.exp(-np.log(2)*7/th[:,None]))
 first=np.maximum(first,np.where(nstep==2,second,first))
 target_peak=dose[None,:]/v[:,None]+step*(np.exp(-k*7)+(nstep-1)*np.exp(-k*14))
 target=target_peak/(cy[:,None]+target_peak)*np.exp(-g[:,None]*H)
 safety=np.maximum(first,target)
 return efficacy,safety,priming,trough/E
def utilities(theta,weights):
 E,S,P,M=scores(theta);wS,wP,wM=weights
 return E-wS*S-wP*np.maximum(.8-P,0)-wM*np.maximum(1-M,0)/(1+np.maximum(1-M,0))-.02*ACTIONS[None,:,3]-.02*7/ACTIONS[None,:,1]
def save(fig,name):fig.tight_layout();fig.savefig(ROOT/'figures'/name);plt.close(fig)
def run():
 rows=[];fig,axes=plt.subplots(1,3,figsize=(10,3.5));halves=[1,3,5,7,10,14,21];tis=[1,2,3,5,10,20,30,50,100]
 rng=np.random.default_rng(SEED);eta=rng.normal(size=(500,2))
 for z,(risk,prime) in enumerate([(.2,.8),(.3,.8),(.4,.6)]):
  grid=np.zeros((len(halves),len(tis)))
  for i,h in enumerate(halves):
   for j,ti in enumerate(tis):
    theta=np.tile([h,1,ti,.3,10,2,1,1],(500,1));theta[:,0]*=np.exp(.35*eta[:,0]);theta[:,7]*=np.exp(.3*eta[:,1]);E,S,P,M=scores(theta)
    valid=((M>1).mean(axis=0)>=.9)&((S<risk).mean(axis=0)>=.8)&((P>=prime).mean(axis=0)>=.8)
    grid[i,j]=valid.sum();rows.append(dict(half_life=h,functional_TI=ti,risk_limit=risk,priming_limit=prime,feasible_actions=int(valid.sum())))
  ax=axes[z];im=ax.imshow(grid>0,origin='lower',aspect='auto',vmin=0,vmax=1,cmap='Blues');ax.set(title=f'Score<{risk}; priming≥{prime}',xticks=np.arange(len(tis)),xticklabels=tis,yticks=np.arange(len(halves)),yticklabels=halves,xlabel='Assumed functional TI',ylabel='Half-life (days)' if z==0 else '')
 fig.colorbar(im,ax=axes.ravel().tolist(),ticks=[0,1],label='At least one feasible grid candidate (1=yes)',fraction=.02,pad=.03)
 fig.subplots_adjust(right=.85,wspace=.35);fig.savefig(ROOT/'figures/08-feasibility.png');plt.close(fig);pd.DataFrame(rows).to_csv(ROOT/'results/feasibility.csv',index=False)
 # Out-of-sample binned conditional-decision approximation, not variance reduction.
 train=parameters(6000,SEED+1);test=parameters(6000,SEED+2);voi=[]
 weights=[(1,1,.3),(2,1,.3),(1,2,.6)]
 for wi,w in enumerate(weights):
  ut=utilities(train,w);uv=utilities(test,w);baseline=int(np.argmax(ut.mean(axis=0)));base=uv[:,baseline]
  evpi=float((uv.max(axis=1)-base).mean())
  voi.append(dict(weights=wi,parameter='ALL',precision_logsd=0,kind='EVPI',gain=evpi,mc_se=float((uv.max(axis=1)-base).std()/np.sqrt(len(test)))))
  for col,name in enumerate(NAMES):
   for noise in [0,.15,.4]:
    rng=np.random.default_rng(SEED+col+10);yt=np.log(train[:,col])+rng.normal(0,noise,len(train));yv=np.log(test[:,col])+rng.normal(0,noise,len(test));edges=np.quantile(yt,np.linspace(0,1,13));edges[0]=-np.inf;edges[-1]=np.inf;bt=np.digitize(yt,edges[1:-1]);bv=np.digitize(yv,edges[1:-1]);decisions=np.array([np.argmax(ut[bt==i].mean(axis=0)) for i in range(12)])
    gain=uv[np.arange(len(test)),decisions[bv]]-base
    voi.append(dict(weights=wi,parameter=name,precision_logsd=noise,kind='binned-EVPPI' if noise==0 else 'binned-EVSI',gain=float(gain.mean()),mc_se=float(gain.std()/np.sqrt(len(test)))))
 v=pd.DataFrame(voi);v.to_csv(ROOT/'results/information-value.csv',index=False)
 fig,axes=plt.subplots(1,3,figsize=(11,3.7))
 for i,ax in enumerate(axes):
  subset=v[(v.weights==i)&(v.precision_logsd==.15)].sort_values('gain');ax.barh(subset.parameter,subset.gain,color='#215e78');ax.errorbar(subset.gain,np.arange(len(subset)),xerr=1.96*subset.mc_se,fmt='none',ecolor='gray');ax.set(title=f'Utility scenario {i+1}',xlabel='Out-of-sample utility gain');ax.axvline(0,color='gray',lw=.7)
 save(fig,'09-information-value.png')
 # Reference 2-comp model local information for CL,Vc,Q,Vp; all estimated.
 schedules={'sparse':[1,6,24,168],'intermediate':[1,4,8,24,48,168],'dense':[1,2,4,8,24,48,72,168],'sparse_late':[1,6,24,168,336,672],'dense_late':[1,2,4,8,24,48,72,168,336,672]};out=[]
 for half_factor in [.3,1,2]:
  pars=np.array([.649/half_factor,3.44,1.11,5.06])
  for key,hours in schedules.items():
   t=np.array(hours)/24
   def obs(p):return pk.concentration(t,[(0,1),(7,10),(14,10)],*p[:2],*p[2:])[0]
   G=np.column_stack([(np.log(obs(pars*np.exp(np.eye(4)[j]*.001)))-np.log(obs(pars*np.exp(-np.eye(4)[j]*.001))))/.002 for j in range(4)])
   F=G.T@G/.3**2;cov=np.linalg.inv(F)
   gradmax=np.array([(np.log(pk.concentration([pk.T],[(0,1)],*(pars*np.exp(np.eye(4)[j]*.001)))[0,0])-np.log(pk.concentration([pk.T],[(0,1)],*(pars*np.exp(-np.eye(4)[j]*.001)))[0,0]))/.002 for j in range(4)])
   out.append(dict(CL_factor=1/half_factor,design=key,postdose_samples=len(t),CL_logse=np.sqrt(cov[0,0]),Vc_logse=np.sqrt(cov[1,1]),Cmax_logse=np.sqrt(gradmax@cov@gradmax),AUC_logse=np.sqrt(cov[0,0]),condition_number=np.linalg.cond(F)))
 sampling=pd.DataFrame(out);sampling.to_csv(ROOT/'results/pk-sampling.csv',index=False)
 rng=np.random.default_rng(SEED);peak=rng.uniform(2,12,20000);shape=.6
 cytokine=[]
 for name,hours in [('sparse',[0,6,24]),('intermediate',[0,2,6,12,24]),('dense',[0,2,4,6,12,24])]:
  times=np.array(hours);profile=np.exp(-.5*(np.log(np.maximum(times,.01)[None,:]/peak[:,None])/shape)**2)
  cytokine.append(dict(design=name,samples=len(hours),capture_within20pct=float((profile.max(axis=1)>=.8).mean()),assumed_peak_min_h=2,assumed_peak_max_h=12))
 cytokine=pd.DataFrame(cytokine);cytokine.to_csv(ROOT/'results/cytokine-sampling.csv',index=False)
 fig,axes=plt.subplots(1,2,figsize=(9,3.7))
 for f in sampling.CL_factor.unique():
  s=sampling[sampling.CL_factor==f];axes[0].plot(np.arange(5),s.CL_logse,marker='o',label=f'CL ×{f:.2f}')
 axes[0].set(xticks=np.arange(5),xticklabels=['4 early','6 early','8 early','4+2 late','8+2 late'],xlabel='Sampling design',ylabel='Local SE of log(CL)',yscale='log');axes[0].tick_params(axis='x',rotation=30);axes[0].legend(fontsize=8);axes[1].bar(cytokine.design,cytokine.capture_within20pct,color='#215e78');axes[1].set(ylabel='Peak captured within 20% (scenario)',ylim=(0,1));save(fig,'10-sampling.png')
 (ROOT/'data/generic-assumptions.json').write_text(json.dumps({'seed':SEED,'parameters':NAMES,'median':[7,1,10,.3,10,2,1,1],'logsd':[.55,.35,.7,.7,.7,.5,.3,.3],'utility_weights':weights,'actions':ACTIONS.tolist(),'PK_log_residual_SD':.3,'cytokine_peak_hours':'uniform(2,12); log-time width .6; no measurement error'},indent=2),encoding='utf8')
 print('Generic design, cross-fitted information value, and sampling completed.',flush=True)
if __name__=='__main__':run()
