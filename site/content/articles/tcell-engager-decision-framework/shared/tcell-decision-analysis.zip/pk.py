"""Published reference-covariate PopPK simulation; no clinical data fitting."""
from pathlib import Path
import json
import numpy as np
import pandas as pd
from scipy.linalg import expm
from scipy.stats import norm
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
ROOT=Path(__file__).resolve().parent
SEED=20261005; N=5000; T=1/24
OMEGA=np.array([[.437**2,.535*.437*.387],[.535*.437*.387,.387**2]])
plt.rcParams.update({'font.size':10,'axes.spines.top':False,'axes.spines.right':False,'figure.dpi':120})
def coefficients(cl,vc,q=1.11,vp=5.06):
 k10=cl/vc;k12=q/vc;k21=q/vp;s=k10+k12+k21
 alpha=(s+np.sqrt(s*s-4*k10*k21))/2;beta=(s-np.sqrt(s*s-4*k10*k21))/2
 return alpha,beta,(alpha-k21)/(alpha-beta)
def concentration(t,doses,cl,vc,q=1.11,vp=5.06):
 t=np.asarray(t);cl=np.atleast_1d(cl);vc=np.atleast_1d(vc);a,b,w=coefficients(cl,vc,q,vp)
 out=np.zeros((len(cl),t.size))
 for day,dose in doses:
  dt=np.maximum(t-day,0)[None,:];u=np.minimum(dt,T);v=np.maximum(dt-T,0)
  out+=dose/(T*vc[:,None])*((w/a)[:,None]*(-np.expm1(-a[:,None]*u))*np.exp(-a[:,None]*v)+((1-w)/b)[:,None]*(-np.expm1(-b[:,None]*u))*np.exp(-b[:,None]*v))
 return out*1000
def auc_until(end,doses,cl,vc,q=1.11,vp=5.06):
 cl=np.atleast_1d(cl);vc=np.atleast_1d(vc);a,b,w=coefficients(cl,vc,q,vp);out=cl*0
 for day,dose in doses:
  dt=max(end-day,0);u=min(dt,T);v=max(dt-T,0)
  def integral(lam):return u/lam+np.expm1(-lam*u)/lam**2+(-np.expm1(-lam*u))*(-np.expm1(-lam*v))/lam**2
  out+=dose/(T*vc)*(w*integral(a)+(1-w)*integral(b))
 return out*1000
def ss(dose,tau,cl,vc,q=1.11,vp=5.06):
 a,b,w=coefficients(np.asarray(cl),np.asarray(vc),q,vp)
 x=dose/(T*np.asarray(vc))*w*(-np.expm1(-a*T))/a/(-np.expm1(-a*tau))
 y=dose/(T*np.asarray(vc))*(1-w)*(-np.expm1(-b*T))/b/(-np.expm1(-b*tau))
 return np.array([dose/np.asarray(cl)/tau*1000,(x+y)*1000,(x*np.exp(-a*(tau-T))+y*np.exp(-b*(tau-T)))*1000])
