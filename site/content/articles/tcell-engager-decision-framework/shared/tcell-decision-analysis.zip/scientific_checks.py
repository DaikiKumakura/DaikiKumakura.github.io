"""Independent mathematical and artifact checks; no patient-risk validation."""
from pathlib import Path
import json
import numpy as np
import pandas as pd
from scipy.linalg import expm
from scipy.integrate import quad
import pk, design
ROOT = Path(__file__).resolve().parent

def run():
    cl, vc, q, vp = .649, 3.44, 1.11, 5.06
    matrix = np.array([[-(cl+q)/vc, q/vp], [q/vc, -q/vp]])
    rate = np.array([1/pk.T, 0.])
    errors = []
    for t in [.01, pk.T, .5, 7, 28]:
        u = min(t, pk.T)
        amount = expm(matrix*max(t-pk.T, 0)) @ np.linalg.solve(matrix, (expm(matrix*u)-np.eye(2)) @ rate)
        expected = amount[0]/vc*1000
        actual = pk.concentration([t], [(0,1)], cl, vc)[0,0]
        errors.append(abs(actual-expected))
    assert max(errors) < 1e-8
    numeric_auc = quad(lambda t: pk.concentration([t], [(0,1)], cl, vc)[0,0], 0, 28, points=[pk.T], epsabs=1e-7)[0]
    assert np.isclose(numeric_auc, pk.auc_until(28, [(0,1)], cl, vc)[0], rtol=1e-9)
    doses = [(14*i, 10) for i in range(100)]
    repeated = pk.concentration([14*99+pk.T, 14*100], doses, cl, vc)[0]
    assert np.allclose(repeated, pk.ss(10,14,cl,vc)[1:], rtol=1e-8)
    assert np.isclose(pk.ss(10,14,cl,vc)[0], pk.ss(20,28,cl,vc)[0])
    diagnostics = [json.loads(p.read_text()) for p in (ROOT/'results').glob('*-diagnostics.json')]
    assert len(diagnostics) == 9
    assert all(d['rhat_max'] < 1.02 and d['ess_bulk_min'] > 200 and d['divergences']==0 for d in diagnostics)
    assert len(design.ACTIONS) == 160
    voi = pd.read_csv(ROOT/'results/information-value.csv')
    for w in range(3):
        v = voi[voi.weights==w]
        assert (v.gain <= float(v[v.kind=='EVPI'].gain.iloc[0])+1e-10).all()
    sampling = pd.read_csv(ROOT/'results/pk-sampling.csv')
    assert np.isfinite(sampling.select_dtypes('number')).all().all()
    reference = sampling[np.isclose(sampling.CL_factor,1)].set_index('design')
    assert reference.loc['dense_late','CL_logse'] < reference.loc['dense','CL_logse']
    administrations = pd.read_csv(ROOT/'results/step-up-administrations.csv')
    assert administrations.regimen.nunique()==14
    assert (administrations.CRS05 <= administrations.CRS_median).all()
    assert (administrations.CRS_median <= administrations.CRS95).all()
    result = {'status':'passed', 'matrix_exponential_max_abs_error_ng_mL':max(errors), 'numeric_auc_ng_day_mL':numeric_auc, 'models_checked':9, 'candidate_actions':160, 'interpretation':'Internal consistency and sampling checks; not external clinical validation.'}
    (ROOT/'results/validation.json').write_text(json.dumps(result,indent=2),encoding='utf8')
    return result

if __name__=='__main__': print(json.dumps(run(),indent=2))
