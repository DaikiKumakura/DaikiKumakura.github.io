from pathlib import Path
import json
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from analysis import load

HERE = Path(__file__).resolve().parent
rows = load()
summary = json.loads((HERE/'results/summary.json').read_text())
kept = summary['scenarios']['x1_y1']['unresolved']
plt.rcParams.update({'font.size': 11, 'axes.spines.top': False, 'axes.spines.right': False})
fig, ax = plt.subplots(figsize=(9, 5.6), layout='constrained')
for r in rows:
    color = '#087f8c' if r['id'] in kept else '#888888'
    ax.errorbar(r['x'], r['y'], xerr=1, yerr=1, fmt='o', color=color, capsize=3)
    offset = (-52, -15) if r['id'] == 'E0080' else (6, 6)
    ax.annotate(r['id'], (r['x'], r['y']), xytext=offset, textcoords='offset points', fontsize=9)
ax.set(xlabel='Impacted genes (approximate count read from poster)',
       ylabel='Mean target knockdown (%)', xlim=(0, 47), ylim=(46, 92),
       title='Gene A: two criteria leave several candidates')
ax.text(.02, .97, 'Bars: reading-error assumptions, not confidence intervals\nTeal: not dominated at +/-1 gene and +/-1 percentage point',
        transform=ax.transAxes, va='top', fontsize=9)
ax.grid(alpha=.15)
(HERE/'figures').mkdir(exist_ok=True)
fig.savefig(HERE/'figures/candidate-tradeoffs.png', dpi=180, metadata={'Software': 'matplotlib'})
plt.close(fig)
