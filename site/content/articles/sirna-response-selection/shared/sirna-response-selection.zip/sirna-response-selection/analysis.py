"""Decision audit of approximate coordinates read from a published poster.

This is not a reanalysis of expression counts or a safety assessment.
"""
from pathlib import Path
import csv
import json

HERE = Path(__file__).resolve().parent


def dominates(a, b, dx=0, dy=0):
    """Conservative interval dominance: lower count, higher knockdown preferred.

dx/dy are symmetric reading-error bounds, not sampling confidence intervals.
"""
    ax, ay = a['x'], a['y']
    bx, by = b['x'], b['y']
    return (ax + dx <= bx - dx and ay - dy >= by + dy
            and (ax + dx < bx - dx or ay - dy > by + dy))


def audit(rows, dx=0, dy=0):
    return {b['id']: [a['id'] for a in rows if a['id'] != b['id']
                     and dominates(a, b, dx, dy)] for b in rows}


def load():
    with (HERE/'inputs/scatter.csv').open(encoding='utf-8', newline='') as f:
        return [{'id': r['sirna'], 'x': float(r['impacted_genes_approx']),
                 'y': float(r['knockdown_percent_approx'])} for r in csv.DictReader(f)]


def main():
    rows = load()
    result = {'input_kind': 'approximate_poster_coordinates_not_raw_data',
              'n_points': len(rows), 'reading_error_not_confidence_interval': True,
              'scenarios': {}}
    for dx, dy in [(0, 0), (1, 1), (2, 2)]:
        comparisons = audit(rows, dx, dy)
        result['scenarios'][f'x{dx}_y{dy}'] = {
            'dominated': [k for k, v in comparisons.items() if v],
            'unresolved': [k for k, v in comparisons.items() if not v],
            'dominators': comparisons}
    # A hypothetical additional assay gate, not a biological recommendation.
    result['illustrative_80_percent_gate'] = {
        'point_estimate_pass': [r['id'] for r in rows if r['y'] >= 80],
        'pass_with_minus_1_percentage_point': [r['id'] for r in rows if r['y'] - 1 >= 80]}
    result['cost_audit_usd_approx'] = {
        'rt_qpcr': 40000, 'drug_seq': 50000, 'bulk_rna_seq': 360000,
        'drug_seq_vs_qpcr_extra': 10000,
        'drug_seq_vs_qpcr_ratio': 50000/40000,
        'drug_seq_vs_bulk_ratio': 50000/360000}
    (HERE/'results').mkdir(exist_ok=True)
    (HERE/'results/summary.json').write_text(json.dumps(result, indent=2)+'\n', encoding='utf-8')
    print(json.dumps(result, indent=2))


if __name__ == '__main__':
    main()
