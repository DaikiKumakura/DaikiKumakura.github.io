import unittest
from analysis import dominates, audit, load


class DecisionTests(unittest.TestCase):
    def test_equal_points_do_not_dominate(self):
        p = {'x': 2, 'y': 80}
        self.assertFalse(dominates(p, p))

    def test_tradeoff_is_unresolved(self):
        a, b = {'x': 2, 'y': 70}, {'x': 5, 'y': 90}
        self.assertFalse(dominates(a, b))
        self.assertFalse(dominates(b, a))

    def test_reading_error_removes_near_dominance(self):
        a, b = {'x': 2, 'y': 81}, {'x': 3, 'y': 80}
        self.assertTrue(dominates(a, b))
        self.assertFalse(dominates(a, b, 1, 1))

    def test_error_cannot_add_dominance(self):
        rows = load()
        exact, bounded = audit(rows), audit(rows, 1, 1)
        for name in exact:
            self.assertTrue(set(bounded[name]) <= set(exact[name]))

    def test_poster_point_mapping_and_direction(self):
        rows = {r['id']: r for r in load()}
        self.assertEqual(len(rows), 10)
        self.assertTrue(dominates(rows['E0078'], rows['E0071'], 1, 1))
        self.assertFalse(dominates(rows['E0078'], rows['E0080']))


if __name__ == '__main__':
    unittest.main()
