# Poster-coordinate decision audit

Python 3.12; plotting requires matplotlib (tested version recorded in requirements.txt).

Run `python analysis.py`, `python -m unittest test_analysis.py`, then `python plot.py`.
The JSON result is deterministic. No network access or API key is required.

## Source and scope

Cox et al., *Smarter siRNA Candidate Selection Through Scalable DRUG-seq Profiling*,
OTS 2026, listed October 13, 2026 at https://datapoints.ginkgo.bio/publications .
Direct poster: https://euphsfcyogalqiqsawbo.supabase.co/storage/v1/object/public/admin-dynamic/uploads/1791896492506-Ginkgo%20Datapoints_2026%20OTS%20Poster_smarter%20siRNA%20candidate%20profiling.pdf

The CSV is a manual reading of ten labelled points in panel 4B, rounded to whole
gene counts and one decimal percentage point. These are approximate figure
coordinates, not original measurements. The original PDF is not redistributed.
The figure's aggregation rule, impacted-gene threshold, and statistical uncertainty
are not recoverable from the available legend. The error bounds used here are
arbitrary reading-error sensitivity assumptions, not confidence intervals.

Lower impacted-gene count and higher mean knockdown define an illustrative
decision preference. It is not evidence that all other transcriptional effects
are off-target, harmful, or unnecessary. Dominance is conditional on that preference,
and does not establish clinical safety, potency at matched knockdown, or a winning drug.

Cost values are approximate scenario estimates reported in poster section 7;
they are not independently measured market prices. No linear extrapolation to
partial RNA-seq follow-up panels is made.
