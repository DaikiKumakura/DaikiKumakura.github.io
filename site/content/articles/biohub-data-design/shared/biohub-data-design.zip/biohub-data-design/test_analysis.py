import unittest
import numpy as np
from analysis import GRID,DESIGNS,matrix,selection,operator,contrast_variance,risk

class DesignTests(unittest.TestCase):
    def test_equal_cells(self):
        for name,k,d,c in DESIGNS:
            self.assertEqual(len(selection(name)),k);self.assertEqual(2*k*d*c,28800)
    def test_all_marginal_levels_present(self):
        for name,*_ in DESIGNS:
            for axis,n in enumerate((4,6,3)):
                self.assertEqual({GRID[i][axis] for i in selection(name)},set(range(n)))
    def test_rank(self):
        x=matrix(GRID)
        for name,*_ in DESIGNS:self.assertEqual(np.linalg.matrix_rank(x[selection(name)]),11)
    def test_exact_additive_recovery(self):
        x=matrix(GRID);truth=x@np.arange(11.)
        for name,*_ in DESIGNS:
            sel=selection(name);a=operator(x,sel)
            np.testing.assert_allclose(a@truth[sel],truth,atol=1e-12)
    def test_observed_rows_direct(self):
        x=matrix(GRID);sel=selection('depth');a=operator(x,sel)
        np.testing.assert_array_equal(a[sel],np.eye(len(sel)))
    def test_full_grid_risk(self):
        x=matrix(GRID);sel=selection('breadth');truth=np.sin(np.arange(72.))
        bias,var,mse=risk(operator(x,sel),truth,sel,.4)
        np.testing.assert_array_equal(bias,np.zeros(72));np.testing.assert_allclose(mse,.4)
    def test_variance_hand_calculation(self):
        self.assertAlmostEqual(contrast_variance(2,100,1),.51)
        self.assertAlmostEqual(contrast_variance(4,50,1),.26)
    def test_depth_cannot_erase_donor_variance(self):
        self.assertGreater(contrast_variance(2,1000000,1),.5)
        self.assertEqual(contrast_variance(2,100,0,0),0)
    def test_nonadditive_missing_information(self):
        sel=selection('depth');truth=np.zeros(72);i=next(i for i in range(72) if i not in sel);truth[i]=1
        bias,_,mse=risk(operator(matrix(GRID),sel),truth,sel,0)
        self.assertEqual(bias[i],-1);self.assertEqual(mse[i],1)
    def test_reject_unidentifiable_and_invalid_inputs(self):
        with self.assertRaises(ValueError):operator(matrix(GRID),np.array([0,1]))
        with self.assertRaises(ValueError):contrast_variance(0,10,1)
        with self.assertRaises(ValueError):selection('unknown')

if __name__=='__main__':unittest.main()
