"""Synthetic finite-grid design audit; no empirical cell data or AI training."""
from pathlib import Path
import csv
import json
import math
import numpy as np

HERE = Path(__file__).resolve().parent
GRID = [(c,p,t) for t in range(3) for c in range(4) for p in range(6)]
DESIGNS = [('depth',18,2,400),('breadth',72,2,100),('replication',36,8,50),('balanced',72,4,50)]
LAMBDAS = (0.,.5,1.,2.)
TAUS = (0.,.5,1.)
TRIALS = 2000

def matrix(grid):
    return np.array([[1]+[float(c==j) for j in range(1,4)]+[float(p==j) for j in range(1,6)]+[float(t==j) for j in range(1,3)] for c,p,t in grid])

def selection(name):
    if name in ('breadth','balanced'): return np.arange(len(GRID))
    if name not in ('depth','replication'): raise ValueError(name)
    return np.array([i for i,(c,p,t) in enumerate(GRID) if c==(p+t)%4 or (name=='replication' and c==((p+t)%4+1)%4)])

def operator(x,selected):
    xs=x[selected]
    if np.linalg.matrix_rank(xs)!=x.shape[1]: raise ValueError('Additive terms are not identifiable')
    a=x@np.linalg.pinv(xs)
    # Observed combinations use their own direct mean; no smoothing there.
    a[selected]=np.eye(len(selected))
    return a

def contrast_variance(donors,cells,tau,sigma=1.):
    if donors<1 or cells<1 or tau<0 or sigma<0: raise ValueError('Invalid variance inputs')
    return tau*tau/donors+2*sigma*sigma/(donors*cells)

def risk(a,truth,selected,variance):
    bias=a@truth[selected]-truth
    var=variance*np.sum(a*a,axis=1)
    return bias,var,bias*bias+var

def dump_csv(name,rows):
    with (HERE/'results'/name).open('w',newline='',encoding='utf-8') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)

def main():
    (HERE/'results').mkdir(exist_ok=True)
    x=matrix(GRID)
    beta=np.array([.2,-.3,.2,.5,-.5,-.2,.1,.3,.6,-.1,.4])
    rng=np.random.default_rng(20261014)
    h=rng.normal(size=len(GRID));h=h-x@np.linalg.lstsq(x,h,rcond=None)[0];h/=np.sqrt(np.mean(h*h))
    # Common independent standard-normal studies permit paired comparisons.
    z=np.random.default_rng(1729).normal(size=(TRIALS,len(GRID)))
    metrics=[];designrows=[];conditions=[]
    for name,k,d,cells in DESIGNS:
        sel=selection(name);assert len(sel)==k
        assert 2*k*d*cells==28800
        a=operator(x,sel);unknown=np.ones(len(GRID),dtype=bool);unknown[sel]=False
        designrows.append(dict(design=name,conditions=k,unmeasured=72-k,donors=d,cells_per_arm=cells,total_cells=2*k*d*cells,arm_samples=2*k*d,additive_rank=int(np.linalg.matrix_rank(x[sel]))))
        for i,(ctx,p,t) in enumerate(GRID):
            conditions.append(dict(design=name,condition=i,context=ctx,perturbation=p,timepoint=t,measured=int(i in sel)))
        for tau in TAUS:
            v=contrast_variance(d,cells,tau)
            noise=(z[:,sel]@a.T)*math.sqrt(v)
            for lam in LAMBDAS:
                truth=x@beta+lam*h
                bias,var,mse=risk(a,truth,sel,v)
                trial_mse=np.mean((noise+bias[None,:])**2,axis=1)
                mean=float(np.mean(trial_mse));se=float(np.std(trial_mse,ddof=1)/math.sqrt(TRIALS))
                metrics.append(dict(design=name,tau=tau,interaction=lam,root_expected_mse=float(np.sqrt(np.mean(mse))),squared_bias=float(np.mean(bias*bias)),prediction_variance=float(np.mean(var)),observed_root_expected_mse=float(np.sqrt(np.mean(mse[sel]))),unmeasured_root_expected_mse=float(np.sqrt(np.mean(mse[unknown]))) if unknown.any() else None,mc_mean_mse=mean,mc_mse_se=se,mc_z=(mean-float(np.mean(mse)))/se))
    floors=[dict(donors=d,cells_per_arm=c,donor_variance=1/d,cell_variance=2/(d*c),root_expected_mse=math.sqrt(contrast_variance(d,c,1.))) for d in (2,4,8) for c in (50,100,200,400,800)]
    costs=[dict(design=r['design'],sample_overhead=h,total_cells=r['total_cells'],arm_samples=r['arm_samples'],effective_cost=r['total_cells']+h*r['arm_samples']) for r in designrows for h in (0,25,100,400)]
    dump_csv('designs.csv',designrows);dump_csv('conditions.csv',conditions);dump_csv('metrics.csv',metrics);dump_csv('precision-floor.csv',floors);dump_csv('cost-sensitivity.csv',costs)
    truthrows=[dict(condition=i,context=c,perturbation=p,timepoint=t,additive=float((x@beta)[i]),interaction_unit=float(h[i])) for i,(c,p,t) in enumerate(GRID)]
    dump_csv('truth.csv',truthrows)
    summary=dict(total_grid=72,total_cells_per_design=28800,coefficient_count=11,trials=TRIALS,truth_seed=20261014,mc_seed=1729,max_abs_mc_z=max(abs(r['mc_z']) for r in metrics),interaction_rms=float(np.sqrt(np.mean(h*h))),interaction_additive_orthogonality=float(np.max(np.abs(x.T@h))),estimand='Population mean paired contrast on equally weighted finite grid; root expected MSE',empirical_data=False,model_training=False)
    (HERE/'results/summary.json').write_text(json.dumps(summary,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(summary,indent=2))

if __name__=='__main__':main()
