# Synthetic finite-grid measurement allocation

No empirical cell data and no foundation model training. This is an original mathematical example inspired by public data-generation announcements, not an evaluation of Biohub's protocol or future data.

Python 3.12, NumPy 1.26.4, Matplotlib 3.9.1 were used. Run:

```sh
python analysis.py
python -m unittest test_analysis.py
python plot.py
```

`results/` contains seven files: designs, condition coverage, metric decomposition, direct-estimator precision floor, hypothetical overhead costs, synthetic truth, and summary. `figures/` contains two original plots. Runtime is small; no network or GPU is required. Different numerical/plotting versions may give insignificant last-digit or image-byte differences.

## Estimand and generated truth

4 contexts x 6 perturbations x 3 timepoints = 72 conditions, each representing a paired treatment-control contrast. Estimate population mean responses over an equally weighted finite grid. No individual-donor prediction or unseen factor-level generalization is assessed. All factor levels occur in every design; only combinations can be unmeasured.

Dummy-coded additive design has 11 columns and full rank in all four selections. Truth = X beta + lambda h. h is a fixed normal draw (seed 20261014), projected onto the orthogonal complement of the full additive design and normalized to RMS 1. lambda = 0, 0.5, 1, 2; tau = 0, 0.5, 1; cell noise SD sigma = 1. These standardized parameters are hypothetical, not estimated from real experiments. Only one interaction realization and four designs are considered; no global optimality or biological robustness is claimed.

Selections, using zero-based context c, perturbation p and time t:

- Depth: c=(p+t) mod 4; 18 combinations, D=2, 400 cells per arm.
- Breadth: all 72; D=2, 100 cells per arm.
- Replication: c=(p+t) mod 4 or c=((p+t) mod 4+1) mod 4; 36 combinations, D=8, 50 cells per arm.
- Balanced: all 72; D=4, 50 cells per arm.

All use 28,800 cells INCLUDING both arms: 2 K D c. They are not equal-cost designs. Donors are repeated across conditions conceptually, but donor-by-condition response deviations are independent across conditions; correlated donor responses, batch effects, shared controls, pools, attrition and count-distribution noise are excluded.

## Estimator and exact risk

At measured conditions use the direct paired donor/cell mean. At unmeasured conditions only, use OLS additive extrapolation from measured means. A maps the selected observations to all 72 estimates; observed rows are identity, missing rows X_full pinv(X_selected). It uses no unmeasured response in fitting. The same rule is used in every design.

Observation variance v=tau^2/D+2 sigma^2/(D*cells). Expected per-condition squared error is bias^2 + v sum_j A_ij^2. Report root(mean expected MSE), NOT mean trial RMSE, and NOT a biological confidence interval. Observed and unmeasured metrics are separate; unmeasured metrics are null when there are no missing combinations. Full-grid risk includes measured conditions and must not be called an unknown-condition generalization score.

Monte Carlo: 2000 independent standardized normal condition-noise vectors, seed1729, shared across designs/settings for paired comparisons. They simulate the exact marginalized contrast distribution above. MC SE is the standard error of the trial MSE mean, not biological variability or a performance CI. The analytic comparison is the primary result; simulation verifies implementation.

## Cost bookkeeping

Count 2 K D distinct arm samples, without shared controls or pooling. Hypothetical per-sample overhead = 0,25,100,400 cell-equivalent units. Effective cost = total cells + overhead x arm samples. This is a sensitivity table, not empirical prices, real library counts, or an optimization under fixed money. Adding modalities requires another model and another cost definition.

## Source context

- Biohub expansion, 2026-10-07: https://biohub.org/news/virtual-biology-initiative-expansion/
- DOE MOU statement, 2026-10-07: https://www.energy.gov/science/articles/doe-nih-and-biohub-partner-build-foundational-data-predictive-biological-super
- Biohub launch, 2026-04-29: https://biohub.org/news/virtual-biology-initiative/

These sources describe plans and infrastructure, not completed universal-cell accuracy. Their figures/data/text are not redistributed in this package. Only original scripts, derived synthetic numbers and original figures are included.
