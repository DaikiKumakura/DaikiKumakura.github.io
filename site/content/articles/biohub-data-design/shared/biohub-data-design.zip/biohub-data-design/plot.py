from pathlib import Path
import csv
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from analysis import DESIGNS

HERE=Path(__file__).resolve().parent
COLORS=['#b47843','#387c88','#8274a2','#398969']
LABELS=['Depth: 18 x 2 x 400','Breadth: 72 x 2 x 100','Replication: 36 x 8 x 50','Balanced: 72 x 4 x 50']

def main():
    (HERE/'figures').mkdir(exist_ok=True)
    plt.rcParams.update({'font.size':11,'axes.spines.top':False,'axes.spines.right':False})
    fig,ax=plt.subplots(figsize=(10,4.7))
    for i,((name,k,d,c),label) in enumerate(zip(DESIGNS,LABELS)):
        ax.barh(i,k,color=COLORS[i]);ax.barh(i,72-k,left=k,color='#e5e5e5')
        ax.text(k/2,i,str(k),ha='center',va='center',color='white',fontweight='bold')
        if k<72:ax.text(k+(72-k)/2,i,f'{72-k} unmeasured',ha='center',va='center')
    ax.set_yticks(range(4),LABELS);ax.invert_yaxis();ax.set_xlim(0,72);ax.set_xlabel('Context x perturbation x time combinations');ax.set_title('All designs use 28,800 cells, including both arms')
    fig.text(.5,.035,'Labels: combinations x donors x cells per arm. Every factor level is represented.\nEqual cell counts do not imply equal preparation costs. Synthetic design, not a Biohub protocol.',ha='center',fontsize=9)
    fig.subplots_adjust(left=.29,bottom=.23,right=.96,top=.88)
    fig.savefig(HERE/'figures/01-design-coverage.png',dpi=150,metadata={'Software':'Matplotlib'});plt.close(fig)
    rows=list(csv.DictReader((HERE/'results/metrics.csv').open(encoding='utf-8')))
    fig,axes=plt.subplots(1,2,figsize=(11,4.8),sharey=True)
    for ax,tau in zip(axes,(0.,1.)):
        for i,(name,*_) in enumerate(DESIGNS):
            r=[r for r in rows if r['design']==name and float(r['tau'])==tau]
            ax.plot([float(x['interaction']) for x in r],[float(x['root_expected_mse']) for x in r],marker='o',color=COLORS[i],label=LABELS[i].split(':')[0])
        ax.set_title(f'Donor-by-condition response SD = {tau:g}');ax.set_xlabel('Nonadditive interaction magnitude');ax.grid(axis='y',alpha=.2);ax.set_xticks([0,.5,1,2])
    axes[0].set_ylabel('Root of expected MSE (response units)');axes[1].legend(frameon=False)
    fig.text(.5,.03,'Population mean contrasts; equal weight over 72 combinations. Exact bias-variance calculation.\nKnown combinations use direct means; unmeasured combinations use additive extrapolation. Synthetic assumptions.',ha='center',fontsize=9)
    fig.subplots_adjust(bottom=.25,top=.87,left=.08,right=.98,wspace=.14)
    fig.savefig(HERE/'figures/02-risk-and-interactions.png',dpi=150,metadata={'Software':'Matplotlib'});plt.close(fig)

if __name__=='__main__':main()
