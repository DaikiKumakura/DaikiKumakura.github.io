"""Calibration of linear PK models to group-level summaries (Dataset A), identifiability tools.

Likelihood (log scale, group g, metric m):  log y_gm = log f_m(theta; dose_g, tau_g) + eta_gm + e_gm,
e_gm ~ N(0, se_gm^2) with se = CV/sqrt(n) (delta method on the arithmetic mean, subjects assumed independent),
eta_gm ~ N(0, tau_m^2) is a between-group heterogeneity term (population, sampling and assay differences between
dose cohorts), estimated per metric type. It is not an inter-individual variance.
"""
from __future__ import annotations

import numpy as np
import pandas as pd
from scipy.optimize import minimize
from scipy.stats import chi2

import ivo_data as D
import pkmodel as K

# which non-redundant summaries enter the calibration (Level 1) and which are only used for checks
CAL_METRICS = ["Cmax", "AUCinf", "Ctau", "thalf"]
THALF_WIN = (3.0, 14.0)   # days; sampling window assumed to represent the NCA terminal phase (A: samples to day 15)
TAU_FLOOR = 1e-3


def build_cal_data(include_cmin_ss: bool = False, include_thalf: bool = True, tinf_h: float = K.TINF_DEFAULT_H) -> pd.DataFrame:
    """Observed group-level summaries used for calibration (single-dose Cmax, AUC0-inf, first-interval trough)."""
    s = D.a_table3(True)
    tr = D.a_troughs()
    rows = []
    for dose, sched in D.A_GROUPS:
        tau = D.TAU[sched]
        g = s[(s.dose == dose) & (s.sched == sched)]
        n = float(g.n.iloc[0])
        for src, name in (("Cmax", "Cmax"), ("AUC0-∞", "AUCinf")):
            r = g[g.param == src].iloc[0]
            rows.append(dict(dose=dose, sched=sched, tau=tau, metric=name, obs=r["mean"], cv=r.sd / r["mean"], n=n, set="cal"))
        if include_thalf:
            r = g[g.param == "t1/2"].iloc[0]
            rows.append(dict(dose=dose, sched=sched, tau=tau, metric="thalf", obs=r["mean"], cv=r.sd / r["mean"], n=n, set="cal"))
        day = 15.0 if sched == "Q2W" else 22.0
        t = tr[(tr.dose == dose) & (tr.sched == sched) & (tr.day == day)].iloc[0]
        rows.append(dict(dose=dose, sched=sched, tau=tau, metric="Ctau", obs=t["mean"], cv=t.sd / t["mean"], n=n, set="cal"))
    if include_cmin_ss:
        ss = D.a_table3(False)
        for dose, sched in D.A_GROUPS:
            g = ss[(ss.dose == dose) & (ss.sched == sched) & (ss.param == "Cmin,ss")].iloc[0]
            rows.append(dict(dose=dose, sched=sched, tau=D.TAU[sched], metric="Cmin_ss", obs=g["mean"], cv=g.sd / g["mean"], n=g.n, set="cal"))
    df = pd.DataFrame(rows)
    df["se"] = df.cv / np.sqrt(df.n)
    return df


def predict_metric(theta: dict, row, tinf_h: float, _cache={}) -> float:
    lam, A = K.micro_to_macro(theta["CL"], theta["V1"], theta.get("Q", 0.0), theta.get("V2", 1.0))
    Tinf = tinf_h / 24.0
    m = row.metric
    if m == "AUCinf":
        return row.dose / theta["CL"]
    if m == "Cmax":
        return float(K.conc_single_infusion(Tinf, row.dose, Tinf, lam, A)[0])
    if m == "Ctau":
        return float(K.conc_single_infusion(row.tau, row.dose, Tinf, lam, A)[0])
    if m == "Cmin_ss":
        return float(K.conc_steady_state(row.tau, row.dose, row.tau, Tinf, lam, A)[0])
    if m == "thalf":
        c = K.conc_single_infusion(np.array([THALF_WIN[0], THALF_WIN[1]]), row.dose, Tinf, lam, A)
        return float(np.log(2.0) * (THALF_WIN[1] - THALF_WIN[0]) / np.log(c[0] / c[1]))
    raise KeyError(m)


def unpack(x, model: str) -> dict:
    if model == "1c":
        return dict(CL=np.exp(x[0]), V1=np.exp(x[1]))
    return dict(CL=np.exp(x[0]), V1=np.exp(x[1]), Q=np.exp(x[2]), V2=np.exp(x[3]))


def n_theta(model: str) -> int:
    return 2 if model == "1c" else 4


def _prepare(data: pd.DataFrame):
    """Index arrays per metric for fast vectorised evaluation."""
    prep = {}
    for m, g in data.groupby("metric"):
        prep[m] = dict(dose=g.dose.values.astype(float), tau=g.tau.values.astype(float), logobs=np.log(g.obs.values.astype(float)),
                       se2=(g.se.values.astype(float)) ** 2)
    return prep


def predict_vec(th: dict, m: str, dose, tau, tinf_h: float):
    lam, A = K.micro_to_macro(th["CL"], th["V1"], th.get("Q", 0.0), th.get("V2", 1.0))
    Tinf = tinf_h / 24.0
    lam_, A_ = lam[None, :], A[None, :]
    dose, tau = np.asarray(dose, float), np.asarray(tau, float)
    if m == "AUCinf":
        return dose / th["CL"]
    if m == "Cmax":   # end of infusion
        return dose / Tinf * np.sum(A_ / lam_ * (-np.expm1(-lam_ * Tinf)), axis=1)
    if m in ("Ctau", "thalf"):
        def c_at(t):
            t = np.asarray(t, float).reshape(-1, 1) * np.ones((len(dose), 1))
            return dose / Tinf * np.sum(A_ / lam_ * np.exp(-lam_ * t) * np.expm1(lam_ * Tinf), axis=1)
        if m == "Ctau":
            return c_at(tau)
        c0, c1 = c_at(THALF_WIN[0]), c_at(THALF_WIN[1])
        return np.log(2.0) * (THALF_WIN[1] - THALF_WIN[0]) / np.log(c0 / c1)
    if m == "Cmin_ss":
        t = tau.reshape(-1, 1)
        acc = 1.0 / (-np.expm1(-lam_ * t))
        return dose / Tinf * np.sum(A_ / lam_ * np.exp(-lam_ * t) * np.expm1(lam_ * Tinf) * acc, axis=1)
    raise KeyError(m)


def nll(z, data: pd.DataFrame, model: str, tinf_h: float, fixed_theta: dict | None = None, tau_fixed=None, _prep={}):
    """Marginal negative log-likelihood. z = [log theta..., log tau_m for each metric type]."""
    key = id(data)
    if key not in _prep or _prep[key][0] is not data:
        _prep[key] = (data, _prepare(data))
    prep = _prep[key][1]
    k = n_theta(model)
    x = np.array(z[:k], float)
    if fixed_theta:
        for i, v in fixed_theta.items():
            x[i] = v
    th = unpack(x, model)
    metrics = sorted(prep)
    tot = 0.0
    for i, m in enumerate(metrics):
        tm = max(np.exp(z[k + i]), TAU_FLOOR) if tau_fixed is None else tau_fixed[m]
        p = prep[m]
        pred = predict_vec(th, m, p["dose"], p["tau"], tinf_h)
        if not np.all(np.isfinite(pred)) or np.any(pred <= 0):
            return 1e12
        v = p["se2"] + tm ** 2
        tot += 0.5 * np.sum(np.log(2 * np.pi * v) + (p["logobs"] - np.log(pred)) ** 2 / v)
    return tot


def fit(data: pd.DataFrame, model: str, tinf_h: float = K.TINF_DEFAULT_H, x0=None, fixed_theta=None, n_starts=4, seed=D.SEED):
    k = n_theta(model)
    metrics = sorted(data.metric.unique())
    rng = np.random.default_rng(seed)
    base = np.array([np.log(0.0065), np.log(0.05)] + ([np.log(0.02), np.log(0.05)] if model == "2c" else []) + [np.log(0.1)] * len(metrics))
    best = None
    starts = [base.copy()] if x0 is None else [np.array(x0, float)]
    for _ in range(n_starts):
        s = base + rng.normal(0, 0.6, size=base.size) * np.r_[np.ones(k), 0.5 * np.ones(len(metrics))]
        starts.append(s)
    for s in starts:
        s = np.array(s, float)
        if fixed_theta:
            for i, v in fixed_theta.items():
                s[i] = v
        free = [i for i in range(len(s)) if not (fixed_theta and i in fixed_theta)]

        def f(zf, s=s, free=free):
            z = s.copy()
            z[free] = zf
            return nll(z, data, model, tinf_h, fixed_theta)
        try:
            r = minimize(f, s[free], method="Nelder-Mead", options=dict(maxiter=2500, maxfev=2500, xatol=1e-6, fatol=1e-8))
            r = minimize(f, r.x, method="Nelder-Mead", options=dict(maxiter=2500, maxfev=2500, xatol=1e-7, fatol=1e-9))
        except Exception:
            continue
        if best is None or r.fun < best[0]:
            z = s.copy()
            z[free] = r.x
            best = (r.fun, z)
    nll_best, z = best
    kk = (n_theta(model) if not fixed_theta else n_theta(model) - len(fixed_theta)) + len(metrics)
    th = unpack(z[:k], model)
    taus = {m: float(max(np.exp(z[k + i]), TAU_FLOOR)) for i, m in enumerate(metrics)}
    return dict(model=model, nll=float(nll_best), z=z, theta=th, taus=taus, k_total=int((n_theta(model) if not fixed_theta else n_theta(model) - len(fixed_theta)) + len(metrics)),
                n_obs=int(len(data)), aic=float(2 * nll_best + 2 * ((n_theta(model) if not fixed_theta else n_theta(model) - len(fixed_theta)) + len(metrics))),
                aicc=float(2 * nll_best + 2 * kk + 2 * kk * (kk + 1) / max(len(data) - kk - 1, 1)))


def num_hessian(fun, x, eps=1e-3):
    n = len(x)
    H = np.zeros((n, n))
    f0 = fun(x)
    for i in range(n):
        for j in range(i, n):
            xi = np.array(x, float)
            xpp, xpm, xmp, xmm = xi.copy(), xi.copy(), xi.copy(), xi.copy()
            xpp[i] += eps; xpp[j] += eps
            xpm[i] += eps; xpm[j] -= eps
            xmp[i] -= eps; xmp[j] += eps
            xmm[i] -= eps; xmm[j] -= eps
            H[i, j] = H[j, i] = (fun(xpp) - fun(xpm) - fun(xmp) + fun(xmm)) / (4 * eps * eps)
    return H


def laplace_cov(res: dict, data: pd.DataFrame, tinf_h: float):
    """Covariance of log-theta from the observed information (heterogeneity SDs held at their ML values)."""
    k = n_theta(res["model"])
    z0 = res["z"].copy()
    metrics = sorted(data.metric.unique())
    taus = res["taus"]

    def f(x):
        return nll(np.r_[x, z0[k:]], data, res["model"], tinf_h, None, tau_fixed=taus)
    H = num_hessian(f, z0[:k])
    ev = np.linalg.eigvalsh(H)
    cov = np.linalg.pinv(H) if ev.min() > 1e-8 else None
    return dict(H=H, eig=ev, cov=cov)


def profile_param(data: pd.DataFrame, model: str, idx: int, grid: np.ndarray, res: dict, tinf_h: float):
    """Profile log-likelihood of log-theta[idx] on `grid`: other parameters and heterogeneity SDs re-optimised,
    sweeping outwards from the optimum with warm starts (one restart from the global optimum per point)."""
    grid = np.asarray(grid, float)
    i0 = int(np.argmin(np.abs(grid - res["z"][idx])))
    out = np.full(len(grid), np.nan)
    for direction in (+1, -1):
        z_prev = res["z"].copy()
        j = i0
        while 0 <= j < len(grid):
            best = None
            for start in (z_prev, res["z"]):
                r = fit(data, model, tinf_h, x0=start, fixed_theta={idx: grid[j]}, n_starts=0)
                if best is None or r["nll"] < best["nll"]:
                    best = r
            out[j] = best["nll"] - res["nll"]
            z_prev = best["z"].copy()
            j += direction
    return out


def mcmc(data: pd.DataFrame, model: str, res: dict, tinf_h: float, n_iter=60000, burn=15000, thin=20, seed=D.SEED, prior_scale=1.0):
    """Adaptive random-walk Metropolis for (log theta, log heterogeneity SDs) with weakly informative priors."""
    k = n_theta(model)
    metrics = sorted(data.metric.unique())
    centre = np.array([np.log(0.01), np.log(0.05), np.log(0.01), np.log(0.05)][:k] + [np.log(0.1)] * len(metrics))
    sd = np.array([2.0] * k + [1.0] * len(metrics)) * prior_scale

    def logpost(z):
        v = nll(z, data, model, tinf_h)
        if v >= 1e11:
            return -np.inf
        return -v - 0.5 * np.sum(((z - centre) / sd) ** 2)
    rng = np.random.default_rng(seed)
    z = res["z"].copy()
    lp = logpost(z)
    dim = len(z)
    cov = np.eye(dim) * 0.02
    chain = []
    acc = 0
    for it in range(n_iter):
        if it > 2000 and it % 500 == 0:
            arr = np.array(chain[-4000:]) if len(chain) > 200 else None
            if arr is not None:
                cov = np.cov(arr.T) * (2.38 ** 2 / dim) + 1e-8 * np.eye(dim)
        prop = rng.multivariate_normal(z, cov)
        lpp = logpost(prop)
        if np.log(rng.random()) < lpp - lp:
            z, lp = prop, lpp
            acc += 1
        chain.append(z.copy())
    arr = np.array(chain[burn::thin])
    return dict(draws=arr, accept=acc / n_iter)


def profile_interval(grid, dnll, level=0.95):
    """Likelihood-ratio interval from a profile; returns (lo, hi, lo_bounded, hi_bounded)."""
    cut = 0.5 * chi2.ppf(level, 1)
    inside = dnll <= cut
    if not inside.any():
        return np.nan, np.nan, False, False
    lo, hi = grid[inside].min(), grid[inside].max()
    return lo, hi, bool(lo > grid.min()), bool(hi < grid.max())


def mcmc_diagnostics(draws: np.ndarray, n_split: int = 4):
    """Split R-hat (single chain cut into n_split segments) and effective sample size (initial positive sequence) per column."""
    n, d = draws.shape
    m = n // n_split
    seg = draws[: m * n_split].reshape(n_split, m, d)
    rhat, ess = [], []
    for j in range(d):
        x = seg[:, :, j]
        w = x.var(axis=1, ddof=1).mean()
        b = m * x.mean(axis=1).var(ddof=1)
        rhat.append(float(np.sqrt(((m - 1) / m * w + b / m) / w)))
        y = draws[:, j] - draws[:, j].mean()
        ac = np.correlate(y, y, mode="full")[n - 1:] / (y @ y)
        tot, k = 0.0, 1
        while k + 1 < n:
            pair = ac[k] + ac[k + 1]
            if pair < 0:
                break
            tot += pair
            k += 2
        ess.append(float(n / (1 + 2 * tot)))
    return dict(split_rhat=rhat, ess=ess, n_draws=int(n))
