"""Linear 1- and 2-compartment PK for an IV infusion, per-kg parameterisation.

Units: dose mg/kg, volume L/kg, clearance L/day/kg, time day, concentration mg/L (= ug/mL).
All closed forms are checked against ODE integration in test_analysis.py.
"""
from __future__ import annotations

import numpy as np
from scipy.integrate import solve_ivp

TINF_DEFAULT_H = 1.5   # assumed infusion duration (A: 60-120 min); sensitivity in analysis.py


def micro_to_macro(CL: float, V1: float, Q: float = 0.0, V2: float = 1.0):
    """Return (lambdas, coefficients) so that the bolus response per unit dose is C(t) = sum A_i exp(-lam_i t)."""
    k10 = CL / V1
    if Q <= 0.0:
        return np.array([k10]), np.array([1.0 / V1])
    k12, k21 = Q / V1, Q / V2
    s = k10 + k12 + k21
    disc = np.sqrt(s * s - 4.0 * k10 * k21)
    alpha, beta = 0.5 * (s + disc), 0.5 * (s - disc)
    A_a = (k21 - alpha) / (V1 * (beta - alpha))
    A_b = (k21 - beta) / (V1 * (alpha - beta))
    return np.array([alpha, beta]), np.array([A_a, A_b])


def conc_single_infusion(t, dose: float, Tinf: float, lam, A):
    """Concentration after one infusion of `dose` over Tinf (days) started at t=0 (t may be an array)."""
    t = np.atleast_1d(np.asarray(t, float))
    R = dose / Tinf
    out = np.zeros_like(t)
    for li, ai in zip(lam, A):
        during = (1.0 - np.exp(-li * np.clip(t, 0.0, None))) / li
        after = np.exp(-li * np.clip(t, 0.0, None)) * np.expm1(li * Tinf) / li
        out += R * ai * np.where(t <= Tinf, during, after)
    out[t < 0] = 0.0
    return out


def conc_schedule(t, dose_times, doses, Tinf: float, lam, A):
    """Superposition for arbitrary dose times (days) and doses (mg/kg)."""
    t = np.atleast_1d(np.asarray(t, float))
    c = np.zeros_like(t)
    for td, d in zip(dose_times, doses):
        c += conc_single_infusion(t - td, d, Tinf, lam, A)
    return c


def conc_steady_state(t, dose: float, tau: float, Tinf: float, lam, A):
    """Steady-state concentration at time t in [0, tau] after the start of an infusion (infinite past dosing)."""
    t = np.atleast_1d(np.asarray(t, float))
    R = dose / Tinf
    out = np.zeros_like(t)
    for li, ai in zip(lam, A):
        g = np.expm1(li * Tinf)
        acc = 1.0 / (-np.expm1(-li * tau))
        during = (1.0 - np.exp(-li * t)) + np.exp(-li * t) * g * np.exp(-li * tau) / (-np.expm1(-li * tau))
        after = np.exp(-li * t) * g * acc
        out += R * ai / li * np.where(t <= Tinf, during, after)
    return out


def auc_first_interval(dose: float, tau: float, Tinf: float, lam, A) -> float:
    """AUC from 0 to tau after the first dose (analytic)."""
    R = dose / Tinf
    tot = 0.0
    for li, ai in zip(lam, A):
        a1 = Tinf - (1.0 - np.exp(-li * Tinf)) / li
        a2 = np.expm1(li * Tinf) * (np.exp(-li * Tinf) - np.exp(-li * tau)) / li
        tot += R * ai / li * (a1 + a2)
    return tot


def single_dose_metrics(p: dict, dose: float, tau: float, Tinf_h: float = TINF_DEFAULT_H) -> dict:
    lam, A = micro_to_macro(p["CL"], p["V1"], p.get("Q", 0.0), p.get("V2", 1.0))
    Tinf = Tinf_h / 24.0
    cmax = float(conc_single_infusion(Tinf, dose, Tinf, lam, A)[0])
    ctau = float(conc_single_infusion(tau, dose, Tinf, lam, A)[0])
    auc_inf = dose / p["CL"]
    c3 = float(conc_single_infusion(3.0, dose, Tinf, lam, A)[0])
    c14 = float(conc_single_infusion(14.0, dose, Tinf, lam, A)[0])
    thalf_app = np.log(2.0) * (14.0 - 3.0) / np.log(c3 / c14)
    thalf_term = np.log(2.0) / float(np.min(lam))
    return dict(Cmax=cmax, Ctau=ctau, AUCinf=auc_inf, AUCtau1=auc_first_interval(dose, tau, Tinf, lam, A),
                thalf_app=thalf_app, thalf_term=thalf_term)


def steady_state_metrics(p: dict, dose: float, tau: float, Tinf_h: float = TINF_DEFAULT_H) -> dict:
    lam, A = micro_to_macro(p["CL"], p["V1"], p.get("Q", 0.0), p.get("V2", 1.0))
    Tinf = Tinf_h / 24.0
    cmax = float(conc_steady_state(Tinf, dose, tau, Tinf, lam, A)[0])
    cmin = float(conc_steady_state(tau, dose, tau, Tinf, lam, A)[0])
    auc = dose / p["CL"]
    return dict(Cmax_ss=cmax, Cmin_ss=cmin, AUCtau_ss=auc, Cavg_ss=auc / tau)


def window_average_ss(p: dict, dose: float, tau: float, window_days: float, Tinf_h: float = TINF_DEFAULT_H,
                      n_grid: int = 4001) -> float:
    """Mean concentration over a common window made of whole dosing intervals (numerical trapezoid)."""
    lam, A = micro_to_macro(p["CL"], p["V1"], p.get("Q", 0.0), p.get("V2", 1.0))
    Tinf = Tinf_h / 24.0
    n_int = int(round(window_days / tau))
    assert abs(n_int * tau - window_days) < 1e-9, "window must hold whole intervals"
    t = np.linspace(0.0, tau, n_grid)
    c = conc_steady_state(t, dose, tau, Tinf, lam, A)
    return float(np.trapezoid(c, t) / tau)


# ---------------------------------------------------------------------------------------------------------------
# ODE reference implementation (used only for verification)
def ode_rhs_factory(CL, V1, Q, V2, rate_fn):
    k10, k12, k21 = CL / V1, (Q / V1 if Q > 0 else 0.0), (Q / V2 if Q > 0 else 0.0)

    def rhs(t, y):
        a1, a2, ael = y
        r = rate_fn(t)
        return [r - (k10 + k12) * a1 + k21 * a2, k12 * a1 - k21 * a2, k10 * a1]
    return rhs


def simulate_ode(p: dict, dose_times, doses, Tinf_days: float, t_eval, rtol=1e-10, atol=1e-12, max_step=np.inf):
    """Amounts (central, peripheral, eliminated) in mg/kg by LSODA; infusion rate piecewise constant."""
    dts, dds = np.asarray(dose_times, float), np.asarray(doses, float)

    def rate(t):
        r = 0.0
        for td, d in zip(dts, dds):
            if td <= t < td + Tinf_days:
                r += d / Tinf_days
        return r
    rhs = ode_rhs_factory(p["CL"], p["V1"], p.get("Q", 0.0), p.get("V2", 1.0), rate)
    breaks = sorted(set(np.concatenate([dts, dts + Tinf_days]).tolist()))
    t_eval = np.asarray(t_eval, float)
    t_end = float(t_eval.max())
    y = np.zeros(3)
    t0 = 0.0
    out = np.zeros((len(t_eval), 3))
    pts = [b for b in breaks if b < t_end] + [t_end]
    for seg_end in pts:
        if seg_end <= t0:
            continue
        mid = 0.5 * (t0 + seg_end)
        sel = (t_eval >= t0) & (t_eval <= seg_end)
        teval_seg = np.unique(np.concatenate([[t0, seg_end], t_eval[sel]]))
        sol = solve_ivp(lambda t, yy: rhs(mid, yy), (t0, seg_end), y, t_eval=teval_seg, method="LSODA",
                        rtol=rtol, atol=atol, max_step=max_step)
        for i, te in enumerate(t_eval):
            if sel[i]:
                j = int(np.argmin(np.abs(sol.t - te)))
                out[i] = sol.y[:, j]
        y = sol.y[:, -1]
        t0 = seg_end
    return out


def simulate_rk4(p: dict, dose_times, doses, Tinf_days: float, t_end: float, dt: float):
    """Fixed-step RK4 on the piecewise-constant-rate ODE (for step-size convergence tests). Returns t, y(N,3)."""
    dts, dds = np.asarray(dose_times, float), np.asarray(doses, float)
    k10 = p["CL"] / p["V1"]
    Q = p.get("Q", 0.0)
    k12 = Q / p["V1"] if Q > 0 else 0.0
    k21 = Q / p["V2"] if Q > 0 else 0.0

    def f(t, y, r):
        return np.array([r - (k10 + k12) * y[0] + k21 * y[1], k12 * y[0] - k21 * y[1], k10 * y[0]])

    n = int(round(t_end / dt))
    y = np.zeros(3)
    ys = np.zeros((n + 1, 3))
    for i in range(n):
        t = i * dt
        r = float(sum(d / Tinf_days for td, d in zip(dts, dds) if td <= t + 0.5 * dt < td + Tinf_days))
        k1 = f(t, y, r)
        k2 = f(t + dt / 2, y + dt / 2 * k1, r)
        k3 = f(t + dt / 2, y + dt / 2 * k2, r)
        k4 = f(t + dt, y + dt * k3, r)
        y = y + dt / 6 * (k1 + 2 * k2 + 2 * k3 + k4)
        ys[i + 1] = y
    return np.arange(n + 1) * dt, ys
