"""PD-1 receptor occupancy and VEGF stages (Dataset A Table 5 plus non-clinical affinity context from Dataset G)."""
from __future__ import annotations

import numpy as np
import pandas as pd
from scipy import stats
from scipy.optimize import least_squares

import ivo_data as D
import pkmodel as K
from analysis import RES, SEED, dump, log, load_fit, PRIMARY_MODEL, REGIMENS

SE_FLOORS = (1.0, 3.0, 5.0)   # percentage points; SD/sqrt(N) can be tiny when SD is reported from one or two subjects
FLOOR_PRIMARY = 3.0


def conc_at_day(theta, dose, sched, day):
    """Typical-subject concentration (ug/mL) at study day `day` (day 1 = first dose) counting doses that started earlier."""
    tau = D.TAU[sched]
    n = int(np.floor((day - 1 - 1e-9) / tau)) + 1 if day > 1 else 0
    if n <= 0:
        return 0.0
    times = 1.0 + tau * np.arange(n)
    lam, A = K.micro_to_macro(theta["CL"], theta["V1"], theta.get("Q", 0.0), theta.get("V2", 1.0))
    return float(K.conc_schedule([day], times, [dose] * n, K.TINF_DEFAULT_H / 24, lam, A)[0])


def kd_to_ug_ml(kd_molar: float, mw_kda: float) -> float:
    """mol/L x g/mol = g/L = 1e3 ug/mL."""
    return kd_molar * (mw_kda * 1e3) * 1e3


def stage_ro():
    cn = D.a_cohort_n()
    th = load_fit(PRIMARY_MODEL)["theta"]
    t5 = D.a_table5("PD-1")
    t5["key"] = [D.gkey(a, b) for a, b in zip(t5.dose, t5.sched)]
    t5["N"] = t5.key.map(cn)
    t5["conc"] = [conc_at_day(th, r.dose, r.sched, r.day) for r in t5.itertuples()]
    t5.to_csv(RES / "ro_table5_with_predicted_conc.csv", index=False)
    out = {"primary_pk_model": PRIMARY_MODEL}
    base = t5[t5.day == 1].set_index("key")
    post = t5[(t5.day > 1)].copy()
    post["baseline"] = post.key.map(base["mean"])
    # --- dose discrimination at the group-mean level
    g = []
    for dose, sched in D.A_GROUPS:
        k = D.gkey(dose, sched)
        x = post[post.key == k]
        d8 = x[x.day == 8]["mean"]
        pre = x[(x.kind == "predose") & (x.day >= 22)]["mean"]
        sdw = x[np.isfinite(x["sd"])]["sd"]
        g.append(dict(key=k, dose=dose, sched=sched, baseline=base.loc[k, "mean"], baseline_sd=base.loc[k, "sd"],
                      day2=x[x.day == 2]["mean"].iloc[0], day8=d8.iloc[0] if len(d8) else np.nan,
                      day8_offset_normalised=(d8.iloc[0] - base.loc[k, "mean"]) / (100.0 - base.loc[k, "mean"]) * 100.0,
                      predose_mean_over_times=pre.mean(), predose_min=pre.min(), predose_n_timepoints=len(pre), mean_within_sd_postdose=sdw.mean()))
    gdf = pd.DataFrame(g)
    gdf.to_csv(RES / "ro_group_summary.csv", index=False)
    out["baseline_range"] = [float(gdf.baseline.min()), float(gdf.baseline.max())]
    out["baseline_spearman_vs_dose_rank"] = float(stats.spearmanr(gdf.dose + 0.01 * (gdf.sched == "Q3W"), gdf.baseline)[0])
    out["day8_range"] = [float(gdf.day8.min()), float(gdf.day8.max())]
    out["predose_mean_range"] = [float(gdf.predose_mean_over_times.min()), float(gdf.predose_mean_over_times.max())]
    out["mean_within_group_sd_postdose"] = float(gdf.mean_within_sd_postdose.mean())
    out["baseline_mean_within_group_sd"] = float(gdf.baseline_sd.mean())
    out["corr_baseline_day8"] = float(np.corrcoef(gdf.baseline, gdf.day8)[0, 1])
    out["day8_offset_normalised_range"] = [float(gdf.day8_offset_normalised.min()), float(gdf.day8_offset_normalised.max())]
    for col in ("day8", "predose_mean_over_times", "day8_offset_normalised"):
        for label, sel in (("Q2W 3-30", gdf.sched == "Q2W"), ("all groups", gdf.sched.notna())):
            x = gdf[sel]
            res = stats.linregress(np.log10(x.dose), x[col])
            tcrit = stats.t.ppf(0.975, len(x) - 2)
            out[f"slope_{col}_{label}"] = dict(pp_per_decade=float(res.slope), lo=float(res.slope - tcrit * res.stderr), hi=float(res.slope + tcrit * res.stderr),
                                              n_groups=int(len(x)))
    # --- 3 mg/kg Q2W versus 30 mg/kg Q2W difference at day 8 relative to baseline noise
    out["day8_30_minus_3"] = float(gdf[gdf.key == "30_Q2W"].day8.iloc[0] - gdf[gdf.key == "3_Q2W"].day8.iloc[0])
    # --- binding-model fit with assay offset: RO = a_g + (b - a_g) * C / (C + EC50), concentration from the PK model
    kd = D.g_kd_molar()
    kd_eq = [kd_to_ug_ml(kd["PD1"], mw) for mw in D.MW_KDA_RANGE]
    out["kd_PD1_M"] = kd["PD1"]
    out["kd_PD1_equiv_ug_ml_range"] = kd_eq
    out["kd_note"] = "KD (mol/L) x assumed molar mass (150-200 kDa, assumption) x 1e3 = ug/mL; in vitro recombinant PD-1, context only"
    pts = post[np.isfinite(post["mean"]) & (post.conc > 0)].copy()
    out["n_points_fit"] = int(len(pts))
    out["conc_min_ug_ml"], out["conc_max_ug_ml"] = float(pts.conc.min()), float(pts.conc.max())
    out["conc_min_over_kd_equiv"] = [float(pts.conc.min() / v) for v in kd_eq]
    out["binding_occupancy_at_min_conc"] = [float(pts.conc.min() / (pts.conc.min() + v)) for v in kd_eq]
    a_g = pts.key.map(base["mean"]).values

    def sigma(floor):
        sd = pts["sd"].values.copy()
        sd = np.where(np.isfinite(sd), sd, np.nanmedian(pts["sd"].values))
        return np.maximum(sd / np.sqrt(pts.N.values.astype(float)), floor)

    def model(logec50, b):
        c = pts.conc.values
        return a_g + (b - a_g) * c / (c + np.exp(logec50))

    prof_rows, fitres = [], {}
    grid = np.linspace(np.log(1e-3), np.log(1e3), 61)
    for floor in SE_FLOORS:
        s_ = sigma(floor)
        y = pts["mean"].values

        def resid_free(par):
            return (y - model(par[0], np.clip(par[1], 80, 100))) / s_
        best = min((least_squares(resid_free, [x0, 98.0], bounds=([np.log(1e-4), 80], [np.log(1e4), 100])) for x0 in (np.log(1e-2), 0.0, np.log(5))),
                   key=lambda r: r.cost)
        chi_best = 2 * best.cost
        prof = []
        for lg in grid:
            r = least_squares(lambda b: (y - model(lg, np.clip(b[0], 80, 100))) / s_, [best.x[1]], bounds=([80], [100]))
            prof.append(2 * r.cost - chi_best)
            prof_rows.append(dict(floor=floor, ec50_ug_ml=float(np.exp(lg)), delta_chi2=2 * r.cost - chi_best))
        prof = np.array(prof)
        inside = prof <= 3.84
        fitres[floor] = dict(ec50_best=float(np.exp(best.x[0])), b_best=float(np.clip(best.x[1], 80, 100)), chi2=float(chi_best), dof=int(len(y) - 2),
                             ec50_upper_95=float(np.exp(grid[inside].max())), ec50_lower_95=float(np.exp(grid[inside].min())),
                             lower_bounded_within_grid=bool(grid[inside].min() > grid.min()), upper_bounded_within_grid=bool(grid[inside].max() < grid.max()))
    pd.DataFrame(prof_rows).to_csv(RES / "ro_ec50_profile.csv", index=False)
    out["binding_fit_by_se_floor"] = fitres
    # primary-floor residual structure (no dose trend in residuals expected if saturated)
    f = fitres[FLOOR_PRIMARY]
    pts["fit"] = model(np.log(f["ec50_best"]), f["b_best"])
    pts["resid"] = pts["mean"] - pts["fit"]
    pts.to_csv(RES / "ro_fit_points.csv", index=False)
    rr = stats.linregress(np.log10(pts.conc), pts.resid)
    out["resid_vs_logconc_slope"] = dict(slope=float(rr.slope), p=float(rr.pvalue))
    # --- time above KD-based occupancy thresholds (hypothetical thresholds from in vitro KD with assumed molar mass)
    kd_mid = float(np.mean(kd_eq))
    rows = []
    for name, (dose, tau) in REGIMENS.items():
        lam, A = K.micro_to_macro(th["CL"], th["V1"], th.get("Q", 0.0), th.get("V2", 1.0))
        t = np.linspace(0, tau, 2001)
        c = K.conc_steady_state(t, dose, tau, K.TINF_DEFAULT_H / 24, lam, A)
        row = dict(regimen=name, Cmin_ss=float(c.min()), Cmin_over_kd=float(c.min() / kd_mid), free_fraction_at_trough=float(kd_mid / (c.min() + kd_mid)))
        for occ in (0.9, 0.99, 0.999):
            thr = occ / (1 - occ) * kd_mid
            row[f"frac_time_ge_{occ:g}"] = float((c[:-1] >= thr).mean())
        rows.append(row)
    pd.DataFrame(rows).to_csv(RES / "ro_time_above_kd_thresholds.csv", index=False)
    out["kd_mid_ug_ml"] = kd_mid
    dump(out, "ro_summary.json")
    log("[ro] done")


def stage_vegf():
    cn = D.a_cohort_n()
    th = load_fit(PRIMARY_MODEL)["theta"]
    t = D.a_table5("VEGF")
    t["key"] = [D.gkey(a, b) for a, b in zip(t.dose, t.sched)]
    t["N"] = t.key.map(cn)
    # concentration at the sampling time: EOI = end of infusion on that day; predose = just before dosing
    conc = []
    lam, A = K.micro_to_macro(th["CL"], th["V1"], th.get("Q", 0.0), th.get("V2", 1.0))
    Tinf = K.TINF_DEFAULT_H / 24
    for r in t.itertuples():
        tau = D.TAU[r.sched]
        if r.kind == "EOI":
            n = int(round((r.day - 1) / tau)) + 1
            times = 1.0 + tau * np.arange(n)
            conc.append(float(K.conc_schedule([1.0 + (n - 1) * tau + Tinf], times, [r.dose] * n, Tinf, lam, A)[0]))
        else:
            conc.append(conc_at_day(th, r.dose, r.sched, r.day))
    t["conc"] = conc
    t.to_csv(RES / "vegf_table5_with_predicted_conc.csv", index=False)
    out = {"assay_note": "Dataset A reports percent change from baseline only; free versus total VEGF is not stated; absolute concentrations are not reported."}
    rng = np.random.default_rng(SEED)
    g = []
    for dose, sched in D.A_GROUPS:
        k = D.gkey(dose, sched)
        x = t[t.key == k]
        eoi = x[x.kind == "EOI"]["mean"]
        pre = x[(x.kind == "predose") & (x.day >= 22)]["mean"]
        g.append(dict(key=k, dose=dose, sched=sched, eoi_mean=eoi.mean(), eoi_min=eoi.min(), eoi_max=eoi.max(), n_eoi=len(eoi),
                      predose_mean=pre.mean(), predose_median=pre.median(), predose_min=pre.min(), predose_max=pre.max(), n_predose=len(pre)))
    gdf = pd.DataFrame(g)
    gdf.to_csv(RES / "vegf_group_summary.csv", index=False)
    out["eoi_range_of_group_means"] = [float(gdf.eoi_mean.min()), float(gdf.eoi_mean.max())]
    out["predose_range_of_group_means"] = [float(gdf.predose_mean.min()), float(gdf.predose_mean.max())]
    # predose % change versus predicted trough concentration: group-time means, cluster bootstrap over dose groups
    pts = t[(t.kind == "predose") & (t.day >= 22) & np.isfinite(t["mean"]) & (t.conc > 0)].copy()
    pts["logc"] = np.log10(pts.conc)

    def slope(df_):
        if df_.logc.nunique() < 2:
            return np.nan
        return np.polyfit(df_.logc, df_["mean"], 1)[0]
    s_hat = slope(pts)
    keys = pts.key.unique()
    boots = []
    for _ in range(2000):
        pick = rng.choice(keys, size=len(keys), replace=True)
        bdf = pd.concat([pts[pts.key == k] for k in pick])
        boots.append(slope(bdf))
    boots = np.array([b for b in boots if np.isfinite(b)])
    out["predose_slope_pp_per_decade"] = dict(est=float(s_hat), lo=float(np.quantile(boots, .025)), hi=float(np.quantile(boots, .975)), n_points=int(len(pts)),
                                              n_groups=int(len(keys)), method="OLS on group-time means; cluster bootstrap over dose groups (2000)")
    out["predose_corr_logconc"] = float(np.corrcoef(pts.logc, pts["mean"])[0, 1])
    pts.to_csv(RES / "vegf_predose_points.csv", index=False)
    # Q2W vs Q3W at equal dose: predose group-time means, bootstrap over time points
    rows = []
    for dose in (10.0, 20.0):
        a = pts[(pts.dose == dose) & (pts.sched == "Q2W")]["mean"].values
        b = pts[(pts.dose == dose) & (pts.sched == "Q3W")]["mean"].values
        diffs = [rng.choice(b, len(b)).mean() - rng.choice(a, len(a)).mean() for _ in range(4000)]
        rows.append(dict(dose=dose, q2w_mean=a.mean(), q3w_mean=b.mean(), n_q2w=len(a), n_q3w=len(b), diff_q3w_minus_q2w=b.mean() - a.mean(),
                         lo=float(np.quantile(diffs, .025)), hi=float(np.quantile(diffs, .975)), q2w_median=float(np.median(a)), q3w_median=float(np.median(b))))
    pd.DataFrame(rows).to_csv(RES / "vegf_q2w_vs_q3w.csv", index=False)
    # 10 mg/kg Q3W first-dose end-of-infusion value (+162%) is documented in the source text as driven by one subject below LLOQ at baseline
    out["note_10_Q3W_day1_EOI"] = float(t[(t.key == "10_Q3W") & (t.timepoint == "Day 1 EOI")]["mean"].iloc[0])
    dump(out, "vegf_summary.json")
    log("[vegf] done")
