"""Sensitivity of regimen ordering to model structure and assumed driver; data-gap matrix."""
from __future__ import annotations

import json

import numpy as np
import pandas as pd

import ivo_data as D
import pkfit as F
import pkmodel as K
from analysis import RES, REGIMENS, HYPOTHETICAL, PRIMARY_MODEL, dump, log, load_fit, load_draws, theta_from_row

DRIVERS = ["Cavg_ss", "Cmax_ss", "Cmin_ss"]


def stage_sens():
    fits = json.loads((RES / "pk_fits.json").read_text(encoding="utf8"))
    variants = []
    for m in ("1c", "2c"):
        for row in fits["tinf_sensitivity"]:
            th = dict(CL=row[f"CL_{m}"], V1=row[f"V1_{m}"])
            if m == "2c":
                th.update(Q=row["Q_2c"], V2=row["V2_2c"])
            variants.append((m, row["tinf_h"], th))
    rows = []
    for m, tinf, th in variants:
        for name, (dose, tau) in REGIMENS.items():
            ss = K.steady_state_metrics(th, dose, tau, tinf)
            rows.append(dict(model=m, tinf_h=tinf, regimen=name, hypothetical=name in HYPOTHETICAL, **{k_: ss[k_] for k_ in DRIVERS}))
    df = pd.DataFrame(rows)
    for k_ in DRIVERS:
        # competition ranking with ties (rounded to 6 digits) so that equal-intensity regimens share a rank
        df[f"rank_{k_}"] = df.groupby(["model", "tinf_h"])[k_].transform(lambda s: s.round(6).rank(ascending=False, method="min"))
    df.to_csv(RES / "sens_regimen_ordering.csv", index=False)
    out = {}
    piv = df[df.tinf_h == 1.5].pivot_table(index="regimen", columns="model", values=[f"rank_{k_}" for k_ in DRIVERS])
    out["ranks_tinf1.5"] = {str(k_): v for k_, v in piv.to_dict().items()}
    # ratios 30Q3W / 20Q2W by structure and infusion duration
    rr = []
    for (m, tinf), g in df.groupby(["model", "tinf_h"]):
        a, b = g[g.regimen == "30 mg/kg Q3W"].iloc[0], g[g.regimen == "20 mg/kg Q2W"].iloc[0]
        rr.append(dict(model=m, tinf_h=tinf, cmax_ratio=a.Cmax_ss / b.Cmax_ss, cmin_ratio=a.Cmin_ss / b.Cmin_ss, cavg_ratio=a.Cavg_ss / b.Cavg_ss))
    pd.DataFrame(rr).to_csv(RES / "sens_ratio_30Q3W_over_20Q2W.csv", index=False)
    # does the Cmin ordering of regimens flip across posterior draws? (typical subject)
    flips = {}
    for m in ("1c", "2c"):
        dr = load_draws(m, 500)
        res = {k_: [] for k_ in REGIMENS}
        for z in dr:
            th = theta_from_row(z, m)
            for name, (dose, tau) in REGIMENS.items():
                res[name].append(K.steady_state_metrics(th, dose, tau)["Cmin_ss"])
        res = {k_: np.array(v) for k_, v in res.items()}
        flips[m] = dict(p_cmin_20Q2W_gt_30Q3W=float((res["20 mg/kg Q2W"] > res["30 mg/kg Q3W"]).mean()),
                        p_cmin_30Q3W_gt_20Q3W=float((res["30 mg/kg Q3W"] > res["20 mg/kg Q3W"]).mean()))
    out["posterior_ordering_probabilities"] = flips
    # crossing of time-above-threshold curves, 20 mg/kg Q2W versus 30 mg/kg Q3W (hypothetical thresholds)
    ta = pd.read_csv(RES / "time_above_threshold.csv")
    cross = {}
    for m in ("1c", "2c"):
        a = ta[(ta.model == m) & (ta.regimen == "20 mg/kg Q2W")].set_index("threshold_ug_ml").frac_time_above
        b = ta[(ta.model == m) & (ta.regimen == "30 mg/kg Q3W")].set_index("threshold_ug_ml").frac_time_above
        d = (a - b)
        thr = d.index.values
        sgn = np.sign(d.values)
        cross[m] = dict(q2w_longer_below_ug_ml=float(thr[(sgn > 0)].max()) if (sgn > 0).any() else None,
                        q3w_longer_above_ug_ml=float(thr[(sgn < 0)].min()) if (sgn < 0).any() else None,
                        max_advantage_q2w=float(d.max()), max_advantage_q3w=float(-d.min()))
    out["time_above_threshold_crossing"] = cross
    dump(out, "sens_summary.json")
    log("[sens] done")


GAP_ROWS = [
    # quantity, A, B, C, D, E, G   (A = available as table, P = partial, N = not available, - = not applicable)
    ("Subject-level data", "N", "N", "N", "N", "N", "-"),
    ("Concentration-time points", "N", "N", "N", "-", "-", "-"),
    ("Group PK summaries (mean, SD)", "A", "A", "N", "-", "-", "-"),
    ("Trough means by day", "A", "N", "N", "-", "-", "-"),
    ("PD-1 occupancy by dose (values)", "A", "N", "N", "-", "-", "-"),
    ("VEGF, absolute concentration", "N", "N", "N", "-", "-", "-"),
    ("VEGF, change from baseline", "A", "N", "N", "-", "-", "-"),
    ("Cooperative-binding parameters", "-", "-", "-", "-", "-", "N"),
    ("Regimen-level n and events (ORR)", "N", "P", "N", "A", "A", "-"),
    ("Regimen-level Grade 3+ TRAE counts", "A", "A", "N", "P", "A", "-"),
    ("PK of 30 mg/kg Q3W", "N", "N", "N", "-", "-", "-"),
    ("Randomised dose comparison", "N", "N", "N", "N", "N", "-"),
]
GAP_COLS = ["A", "B", "C", "D", "E", "G"]


def stage_gap():
    c = D.load_C()
    na = c[c.value.astype(str).str.contains("NOT AVAILABLE")]
    assert len(na) == 28, "regimen-level fields for dataset C are expected to be not available"
    rows = []
    for r in GAP_ROWS:
        for col, v in zip(GAP_COLS, r[1:]):
            rows.append(dict(quantity=r[0], dataset=col, status=v))
    pd.DataFrame(rows).to_csv(RES / "data_gap_matrix.csv", index=False)
    log("[gap] done")
