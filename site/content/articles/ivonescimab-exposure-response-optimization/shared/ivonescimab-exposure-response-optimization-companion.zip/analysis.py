"""Ivonescimab public-data PK / occupancy / regimen-rate analysis. Entry point and PK-side stages.

Run from this folder:  python analysis.py              (all stages; rewrites results/)
                       python analysis.py pk reg       (selected stages)
Stages: pk, reg, ro, vegf, rates, er, sens, gap.  Inputs: inputs/*.csv (tabulated values transcribed from the cited
papers; group-level aggregates only). Random seed 20261105.
"""
from __future__ import annotations

import json
import sys
import time
import warnings
from pathlib import Path

import numpy as np
import pandas as pd
from scipy import stats

import ivo_data as D
import pkfit as F
import pkmodel as K

warnings.filterwarnings("ignore", category=RuntimeWarning)
RES, SEED = D.RES, D.SEED
PRIMARY_MODEL = "2c"   # chosen from the pk stage: delta AIC, bounded profile for Q and V2, trough time course (see article)

REGIMENS = {  # name: (dose mg/kg, interval days, label, status)
    "10 mg/kg Q3W": (10.0, 21.0),
    "15 mg/kg Q3W": (15.0, 21.0),
    "20 mg/kg Q3W": (20.0, 21.0),
    "20 mg/kg Q2W": (20.0, 14.0),
    "30 mg/kg Q3W": (30.0, 21.0),
}
HYPOTHETICAL = {"15 mg/kg Q3W"}
WINDOW_DAYS = 42.0     # common window = 3 x Q2W = 2 x Q3W intervals
TINF_VARIANTS_H = (1.0, 1.5, 2.0)
CV_SCENARIOS = [(0.15, 0.15, 0.0), (0.25, 0.20, 0.0), (0.25, 0.20, 0.5), (0.35, 0.25, 0.5)]  # CV(CL), CV(V1), rho
N_VIRTUAL = 4000


def dump(obj, name):
    RES.mkdir(exist_ok=True)

    def conv(o):
        if isinstance(o, (np.floating, np.integer)):
            return o.item()
        if isinstance(o, np.ndarray):
            return o.tolist()
        raise TypeError(type(o))
    (RES / name).write_text(json.dumps(obj, indent=2, default=conv, ensure_ascii=False), encoding="utf8")


def log(msg):
    print(msg, flush=True)
    with open(RES / "run_log.txt", "a", encoding="utf8") as f:
        f.write(msg + "\n")


def theta_from_row(z, model):
    return F.unpack(z[:F.n_theta(model)], model)


def q(a, lo=2.5, hi=97.5):
    a = np.asarray(a, float)
    return float(np.nanpercentile(a, lo)), float(np.nanpercentile(a, hi))


# ---------------------------------------------------------------------------------------------------------------
def load_fit(model: str):
    d = json.loads((RES / "pk_fits.json").read_text(encoding="utf8"))
    r = d[model]
    r["z"] = np.array(r["z"])
    return r


def load_draws(model: str, n=None) -> np.ndarray:
    """Posterior draws; if n is given, n evenly spaced draws across the whole chain (not the first n)."""
    z = pd.read_csv(RES / f"pk_draws_{model}.csv").values
    if n is None or n >= len(z):
        return z
    return z[np.linspace(0, len(z) - 1, n).astype(int)]


def stage_pk():
    t0 = time.time()
    RES.mkdir(exist_ok=True)
    cal = F.build_cal_data()
    cal.to_csv(RES / "pk_calibration_data.csv", index=False)
    out = {"calibration_metrics": sorted(cal.metric.unique()), "n_obs": int(len(cal)), "tinf_h": K.TINF_DEFAULT_H}
    fits = {m: F.fit(cal, m, n_starts=10) for m in ("1c", "2c")}
    for m, r in fits.items():
        out[m] = dict(z=r["z"], theta=r["theta"], taus=r["taus"], nll=r["nll"], aic=r["aic"], aicc=r["aicc"], k_total=r["k_total"])
    out["delta_aic_2c_minus_1c"] = fits["2c"]["aic"] - fits["1c"]["aic"]
    out["delta_aicc_2c_minus_1c"] = fits["2c"]["aicc"] - fits["1c"]["aicc"]
    wa = np.exp(-0.5 * np.array([fits["1c"]["aicc"], fits["2c"]["aicc"]]) + 0.5 * min(fits["1c"]["aicc"], fits["2c"]["aicc"]))
    out["akaike_weights_aicc_1c_2c"] = (wa / wa.sum()).tolist()
    lr = 2 * (fits["1c"]["nll"] - fits["2c"]["nll"])
    out["lr_stat_1c_vs_2c"] = lr
    # profile likelihood intervals
    prof_rows = []
    for model, names in (("1c", ["CL", "V1"]), ("2c", ["CL", "V1", "Q", "V2"])):
        r = fits[model]
        for idx, nm in enumerate(names):
            c = r["z"][idx]
            half, npt = (0.6, 49) if nm in ("CL", "V1") else (3.0, 31)
            grid = np.linspace(c - half, c + half, npt)
            pr = F.profile_param(cal, model, idx, grid, r, K.TINF_DEFAULT_H)
            lo, hi, lb, hb = F.profile_interval(grid, pr)
            for g_, p_ in zip(grid, pr):
                prof_rows.append(dict(model=model, param=nm, log_value=g_, value=np.exp(g_), delta_nll=p_))
            out[f"profile_{model}_{nm}"] = dict(est=float(np.exp(c)), lo=float(np.exp(lo)), hi=float(np.exp(hi)),
                                                lower_bounded=lb, upper_bounded=hb)
    pd.DataFrame(prof_rows).to_csv(RES / "pk_profiles.csv", index=False)
    # which summary supplies the information on the peripheral compartment? refit without first-interval trough / without t1/2
    ident = {}
    for drop in ("Ctau", "thalf", "none"):
        dd = cal if drop == "none" else cal[cal.metric != drop]
        r2 = F.fit(dd, "2c", n_starts=8)
        r1 = F.fit(dd, "1c", n_starts=4)
        row = dict(dropped=drop, delta_aic_2c_minus_1c=r2["aic"] - r1["aic"], Q=float(r2["theta"]["Q"]), V2=float(r2["theta"]["V2"]))
        for idx, nm in ((2, "Q"), (3, "V2")):
            c = r2["z"][idx]
            grid = np.linspace(c - 3.5, c + 3.5, 29)
            pr = F.profile_param(dd, "2c", idx, grid, r2, K.TINF_DEFAULT_H)
            lo, hi, lb, hb = F.profile_interval(grid, pr)
            row[f"{nm}_lo"], row[f"{nm}_hi"] = float(np.exp(lo)), float(np.exp(hi))
            row[f"{nm}_lower_bounded"], row[f"{nm}_upper_bounded"] = lb, hb
        ident[drop] = row
    out["identification_by_dropped_metric"] = ident
    # leave-one-dose-group-out stability of the 2c peripheral parameters
    loo = []
    for dose, sched in D.A_GROUPS:
        dd = cal[~((cal.dose == dose) & (cal.sched == sched))]
        r2 = F.fit(dd, "2c", n_starts=6)
        r1 = F.fit(dd, "1c", n_starts=3)
        loo.append(dict(left_out=f"{dose:g} mg/kg {sched}", Q=float(r2["theta"]["Q"]), V2=float(r2["theta"]["V2"]),
                        delta_aic=r2["aic"] - r1["aic"]))
    out["leave_one_group_out_2c"] = loo
    # observation-set sensitivity: AUC0-inf treated as unbiased truth in the base fit (NCA extrapolation may bias it), t1/2 window
    sens = []
    variants = {"base": cal, "AUC0-inf excluded": cal[cal.metric != "AUCinf"],
                "AUC0-inf observed x1.10": cal.assign(obs=np.where(cal.metric == "AUCinf", cal.obs * 1.10, cal.obs))}
    for nm, dd in variants.items():
        r1, r2 = F.fit(dd, "1c", n_starts=4), F.fit(dd, "2c", n_starts=6)
        sens.append(dict(variant=nm, CL_1c=r1["theta"]["CL"], V1_1c=r1["theta"]["V1"], CL_2c=r2["theta"]["CL"], V1_2c=r2["theta"]["V1"],
                         Q_2c=r2["theta"]["Q"], V2_2c=r2["theta"]["V2"], delta_aic=r2["aic"] - r1["aic"], delta_aicc=r2["aicc"] - r1["aicc"]))
    old_win = F.THALF_WIN
    F.THALF_WIN = (3.0, 21.0)
    r1, r2 = F.fit(cal, "1c", n_starts=4), F.fit(cal, "2c", n_starts=6)
    F.THALF_WIN = old_win
    sens.append(dict(variant="t1/2 window 3-21 d", CL_1c=r1["theta"]["CL"], V1_1c=r1["theta"]["V1"], CL_2c=r2["theta"]["CL"], V1_2c=r2["theta"]["V1"],
                     Q_2c=r2["theta"]["Q"], V2_2c=r2["theta"]["V2"], delta_aic=r2["aic"] - r1["aic"], delta_aicc=r2["aicc"] - r1["aicc"]))
    out["observation_set_sensitivity"] = sens
    # Tinf sensitivity
    tin = []
    for th_ in TINF_VARIANTS_H:
        r1 = F.fit(cal, "1c", th_, n_starts=4)
        r2 = F.fit(cal, "2c", th_, n_starts=6)
        tin.append(dict(tinf_h=th_, CL_1c=r1["theta"]["CL"], V1_1c=r1["theta"]["V1"], CL_2c=r2["theta"]["CL"], V1_2c=r2["theta"]["V1"],
                        Q_2c=r2["theta"]["Q"], V2_2c=r2["theta"]["V2"], d_aic=r2["aic"] - r1["aic"]))
    out["tinf_sensitivity"] = tin
    # posterior (weakly informative priors) for both structures
    for m in ("1c", "2c"):
        mc = F.mcmc(cal, m, fits[m], K.TINF_DEFAULT_H, n_iter=70000, burn=15000, thin=20)
        pd.DataFrame(mc["draws"]).to_csv(RES / f"pk_draws_{m}.csv", index=False)
        ex = np.exp(mc["draws"][:, :F.n_theta(m)])
        names = ["CL", "V1", "Q", "V2"][:F.n_theta(m)]
        out[f"posterior_{m}"] = {nm: dict(median=float(np.median(ex[:, i])), lo=float(np.quantile(ex[:, i], .025)), hi=float(np.quantile(ex[:, i], .975)))
                                 for i, nm in enumerate(names)}
        out[f"mcmc_accept_{m}"] = mc["accept"]
        out[f"mcmc_diagnostics_{m}"] = F.mcmc_diagnostics(mc["draws"])
    # prior sensitivity of the PK posterior (prior SD on log scale x0.5 and x2) and of the trough ratio
    psens = []
    for scale in (0.5, 1.0, 2.0):
        mc = F.mcmc(cal, "2c", fits["2c"], K.TINF_DEFAULT_H, n_iter=70000, burn=15000, thin=20, prior_scale=scale)
        ex = np.exp(mc["draws"][:, :4])
        sub = mc["draws"][np.linspace(0, len(mc["draws"]) - 1, 300).astype(int)]
        rr = []
        for z in sub:
            th = theta_from_row(z, "2c")
            rr.append(K.steady_state_metrics(th, 30.0, 21.0)["Cmin_ss"] / K.steady_state_metrics(th, 20.0, 14.0)["Cmin_ss"])
        psens.append(dict(prior_sd_scale=scale, Q_med=float(np.median(ex[:, 2])), Q_lo=float(np.quantile(ex[:, 2], .025)), Q_hi=float(np.quantile(ex[:, 2], .975)),
                          V2_med=float(np.median(ex[:, 3])), V2_lo=float(np.quantile(ex[:, 3], .025)), V2_hi=float(np.quantile(ex[:, 3], .975)),
                          cmin_ratio_med=float(np.median(rr)), cmin_ratio_lo=q(rr)[0], cmin_ratio_hi=q(rr)[1]))
    out["pk_prior_sensitivity_2c"] = psens
    dump(out, "pk_fits.json")
    log(f"[pk] done in {time.time() - t0:.0f} s; dAIC(2c-1c) = {out['delta_aic_2c_minus_1c']:.2f}")
    stage_pk_checks()


def all_predictions(draws, model, dose, tau, tinf_h=K.TINF_DEFAULT_H):
    """Typical-subject predictions per posterior draw for single-dose and steady-state metrics."""
    rows = []
    for z in draws:
        th = theta_from_row(z, model)
        s1 = K.single_dose_metrics(th, dose, tau, tinf_h)
        ss = K.steady_state_metrics(th, dose, tau, tinf_h)
        rows.append(dict(Cmax=s1["Cmax"], Ctau=s1["Ctau"], AUCinf=s1["AUCinf"], thalf=s1["thalf_app"], AUCtau1=s1["AUCtau1"],
                         Cmax_ss=ss["Cmax_ss"], Cmin_ss=ss["Cmin_ss"], AUCtau_ss=ss["AUCtau_ss"], Rac_AUC=ss["AUCtau_ss"] / s1["AUCtau1"],
                         Rac_Cmax=ss["Cmax_ss"] / s1["Cmax"]))
    return pd.DataFrame(rows)


def stage_pk_checks():
    cal = pd.read_csv(RES / "pk_calibration_data.csv")
    fits = {m: load_fit(m) for m in ("1c", "2c")}
    draws = {m: load_draws(m, 400) for m in ("1c", "2c")}
    # 1. observed vs fitted (calibration set)
    rows = []
    for m in ("1c", "2c"):
        th = fits[m]["theta"]
        for r in cal.itertuples():
            pred = float(F.predict_vec(th, r.metric, [r.dose], [r.tau], K.TINF_DEFAULT_H)[0])
            rows.append(dict(model=m, dose=r.dose, sched=r.sched, metric=r.metric, obs=r.obs, pred=pred, ratio=r.obs / pred, se_log=r.se))
    pd.DataFrame(rows).to_csv(RES / "pk_obs_vs_fit.csv", index=False)
    # 2. dose proportionality of group means (log-log WLS on Q2W 3-30 mg/kg) from the single-dose summaries
    s = D.a_table3(True)
    prow = []
    for src, nm in (("Cmax", "Cmax"), ("AUC0-∞", "AUC0-inf"), ("AUC0-t", "AUC0-t")):
        for label, sel in (("Q2W 3-30", lambda g: g.sched == "Q2W"), ("all groups", lambda g: g.sched.notna())):
            g = s[(s.param == src)]
            g = g[sel(g)]
            x = np.log(g.dose.values)
            y = np.log(g["mean"].values)
            se = (g.sd / g["mean"] / np.sqrt(g.n)).values
            W = 1 / se ** 2
            X = np.c_[np.ones_like(x), x]
            beta = np.linalg.solve(X.T @ (W[:, None] * X), X.T @ (W * y))
            res = y - X @ beta
            dfree = len(x) - 2
            s2 = max((W * res ** 2).sum() / dfree, 1.0)   # scale up if heterogeneity exceeds reported SE
            cov = s2 * np.linalg.inv(X.T @ (W[:, None] * X))
            tcrit = stats.t.ppf(0.95, dfree)   # 90% CI to match the paper's Table 4 convention
            prow.append(dict(param=nm, groups=label, n_groups=len(x), beta=beta[1], ci90_lo=beta[1] - tcrit * np.sqrt(cov[1, 1]),
                             ci90_hi=beta[1] + tcrit * np.sqrt(cov[1, 1]), scale_factor=s2))
    pd.DataFrame(prow).to_csv(RES / "pk_dose_proportionality.csv", index=False)
    norm = []
    for src, nm in (("Cmax", "Cmax"), ("AUC0-∞", "AUCinf")):
        for r in s[s.param == src].itertuples():
            norm.append(dict(param=nm, dose=r.dose, sched=r.sched, per_dose=r.mean / r.dose, per_dose_se=r.mean / r.dose * r.sd / r.mean / np.sqrt(r.n)))
    pd.DataFrame(norm).to_csv(RES / "pk_dose_normalised.csv", index=False)
    # 3. steady-state checks: reported steady-state NCA versus prediction from single-dose calibration
    ss = D.a_table3(False)
    taus = {m: fits[m]["taus"] for m in fits}
    het = {"Cmax_ss": "Cmax", "Cmin_ss": "Ctau", "AUCtau_ss": "AUCinf"}
    rep = {"Cmax_ss": "Cmax,ss", "Cmin_ss": "Cmin,ss", "AUCtau_ss": "AUC0-τ,ss", "Rac_AUC": "Rac,AUC0-τ", "Rac_Cmax": "Rac,Cmax"}
    rows = []
    for m in ("1c", "2c"):
        for dose, sched in D.A_GROUPS:
            tau = D.TAU[sched]
            P = all_predictions(draws[m], m, dose, tau)
            pt = all_predictions([fits[m]["z"]], m, dose, tau).iloc[0]
            g = ss[(ss.dose == dose) & (ss.sched == sched)].set_index("param")
            for k_, nm in rep.items():
                if nm not in g.index:
                    continue
                obs, sd = g.loc[nm, "mean"], g.loc[nm, "sd"]
                n = g.loc[nm, "n"]
                n = 4 if (dose == 30 and sched == "Q2W" and nm in ("AUC0-τ,ss", "Rac,AUC0-τ")) else n
                se_log = sd / obs / np.sqrt(n)
                pred = float(pt[k_])
                lo, hi = q(P[k_])
                th = taus[m].get(het.get(k_, ""), 0.0)
                par_sd = float(np.std(np.log(P[k_])))
                z = (np.log(obs) - np.log(pred)) / np.sqrt(se_log ** 2 + th ** 2 + par_sd ** 2)
                rows.append(dict(model=m, dose=dose, sched=sched, metric=k_, obs=obs, pred=pred, pred_lo=lo, pred_hi=hi, ratio_obs_pred=obs / pred,
                                 se_log_obs=se_log, z_with_heterogeneity=z, n_obs=n))
    ssdf = pd.DataFrame(rows)
    ssdf.to_csv(RES / "pk_steady_state_check.csv", index=False)
    summ = {}
    for m in ("1c", "2c"):
        for k_ in ("Cmax_ss", "Cmin_ss", "AUCtau_ss", "Rac_AUC", "Rac_Cmax"):
            x = ssdf[(ssdf.model == m) & (ssdf.metric == k_)]
            lr = np.log(x.ratio_obs_pred.values)
            summ[f"{m}_{k_}"] = dict(geo_mean_ratio=float(np.exp(lr.mean())), min_ratio=float(np.exp(lr.min())), max_ratio=float(np.exp(lr.max())),
                                     n_groups=int(len(x)), n_within_95=int((np.abs(x.z_with_heterogeneity) < 1.96).sum()))
    # time dependence: reported AUC0-tau,ss versus AUC0-inf and CLss versus CL (same groups)
    s1 = D.a_table3(True)
    td = []
    for dose, sched in D.A_GROUPS:
        a_inf = s1[(s1.dose == dose) & (s1.sched == sched) & (s1.param == "AUC0-∞")]["mean"].iloc[0]
        a_ss = ss[(ss.dose == dose) & (ss.sched == sched) & (ss.param == "AUC0-τ,ss")]["mean"].iloc[0]
        cl1 = s1[(s1.dose == dose) & (s1.sched == sched) & (s1.param == "CL")]["mean"].iloc[0]
        cl2 = ss[(ss.dose == dose) & (ss.sched == sched) & (ss.param == "CLss")]["mean"].iloc[0]
        td.append(dict(dose=dose, sched=sched, auc_ss_over_auc_inf=a_ss / a_inf, clss_over_cl=cl2 / cl1))
    td = pd.DataFrame(td)
    td.to_csv(RES / "pk_time_dependence.csv", index=False)
    lg = np.log(td.auc_ss_over_auc_inf.values)
    tc = stats.t.ppf(0.975, len(lg) - 1)
    summ["auc_ss_over_inf"] = dict(geo_mean=float(np.exp(lg.mean())), lo=float(np.exp(lg.mean() - tc * lg.std(ddof=1) / np.sqrt(len(lg)))),
                                   hi=float(np.exp(lg.mean() + tc * lg.std(ddof=1) / np.sqrt(len(lg)))))
    lc = np.log(td.clss_over_cl.values)
    summ["clss_over_cl"] = dict(geo_mean=float(np.exp(lc.mean())), lo=float(np.exp(lc.mean() - tc * lc.std(ddof=1) / np.sqrt(len(lc)))),
                                hi=float(np.exp(lc.mean() + tc * lc.std(ddof=1) / np.sqrt(len(lc)))))
    # 4. trough time course (supplementary mean trough concentrations) versus typical-subject prediction
    tr = D.a_troughs()
    cn = D.a_cohort_n()
    rows = []
    for m in ("1c", "2c"):
        th = fits[m]["theta"]
        lam, A = K.micro_to_macro(th["CL"], th["V1"], th.get("Q", 0.0), th.get("V2", 1.0))
        for r in tr.itertuples():
            if r.day <= 1 or not np.isfinite(r.mean) or r.mean <= 0:
                continue
            tau = D.TAU[r.sched]
            n_doses = int(round((r.day - 1) / tau))
            times = 1.0 + tau * np.arange(n_doses)
            pred = float(K.conc_schedule([r.day], times, [r.dose] * n_doses, K.TINF_DEFAULT_H / 24, lam, A)[0])
            flagged = (r.dose == 5 and r.sched == "Q2W" and r.day in (365, 421))   # documented outliers (missed/delayed dosing)
            n = cn[D.gkey(r.dose, r.sched)]
            se = (r.sd / r.mean / np.sqrt(n)) if np.isfinite(r.sd) and r.sd > 0 else np.nan
            rows.append(dict(model=m, dose=r.dose, sched=r.sched, day=r.day, n_doses_before=n_doses, obs=r.mean, pred=pred,
                             ratio=r.mean / pred, se_log_lower_bound=se, flagged_outlier=flagged))
    trdf = pd.DataFrame(rows)
    trdf.to_csv(RES / "pk_trough_check.csv", index=False)
    for m in ("1c", "2c"):
        x = trdf[(trdf.model == m) & (~trdf.flagged_outlier)]
        for lab, sel in (("dose2-3", x.n_doses_before <= 3), ("dose4-9", (x.n_doses_before > 3) & (x.n_doses_before <= 9)), ("dose10plus", x.n_doses_before > 9)):
            lr = np.log(x[sel].ratio.values)
            summ[f"trough_{m}_{lab}"] = dict(geo_mean_ratio=float(np.exp(lr.mean())), n_points=int(len(lr)))
    if (D.INP / "B_jitc_008037_phase1a_AK112-101.csv").exists():
        # 5. external comparison with the Phase Ia study (B): predictions from the A-only calibration
        bs, bss = D.b_pk(True), D.b_pk(False)
        ext = []
        for m in ("1c", "2c"):
            for dose in (3.0, 10.0, 20.0, 30.0):
                P = all_predictions(draws[m], m, dose, 14.0)
                pt = all_predictions([fits[m]["z"]], m, dose, 14.0).iloc[0]
                for tbl, mp in ((bs, {"Cmax": "Cmax", "AUCinf": "AUC0-inf", "thalf": "t1/2"}),
                                (bss, {"Cmax_ss": "Cmax,ss", "Cmin_ss": "Cmin,ss", "AUCtau_ss": "AUC0-tau,ss", "Rac_AUC": "Rac,AUC0-tau", "Rac_Cmax": "Rac,Cmax"})):
                    for k_, nm in mp.items():
                        g = tbl[(tbl.dose == dose) & (tbl.param == nm)]
                        if g.empty or not np.isfinite(g["mean"].iloc[0]):
                            continue
                        obs, sd, n = g["mean"].iloc[0], g.sd.iloc[0], g.n.iloc[0]
                        se_log = sd / obs / np.sqrt(n) if np.isfinite(sd) else np.nan
                        pred = float(pt[k_])
                        lo, hi = q(P[k_])
                        ext.append(dict(model=m, dose=dose, metric=k_, n=n, obs=obs, pred=pred, pred_lo=lo, pred_hi=hi,
                                        ratio_obs_pred=obs / pred, se_log_obs=se_log))
        extdf = pd.DataFrame(ext)
        extdf.to_csv(RES / "pk_external_B.csv", index=False)
        for m in ("1c", "2c"):
            for grp, ms in (("single", ["Cmax", "AUCinf"]), ("ss", ["Cmax_ss", "Cmin_ss", "AUCtau_ss"])):
                x = extdf[(extdf.model == m) & (extdf.metric.isin(ms)) & (extdf.dose >= 10)]
                lr = np.log(x.ratio_obs_pred.values)
                summ[f"ext_{m}_{grp}"] = dict(geo_mean_ratio=float(np.exp(lr.mean())), min_ratio=float(np.exp(lr.min())), max_ratio=float(np.exp(lr.max())), n=int(len(lr)))
        # direct B/A summary ratios at overlapping doses (no model)
        sa, sb = D.a_table3(True), D.b_pk(True)
        dr = []
        for dose in (3.0, 10.0, 20.0, 30.0):
            for pa, pb_ in (("Cmax", "Cmax"), ("AUC0-∞", "AUC0-inf"), ("t1/2", "t1/2")):
                a = sa[(sa.dose == dose) & (sa.sched == "Q2W") & (sa.param == pa)]["mean"].iloc[0]
                b = sb[(sb.dose == dose) & (sb.param == pb_)]["mean"].iloc[0]
                na = sa[(sa.dose == dose) & (sa.sched == "Q2W") & (sa.param == pa)].n.iloc[0]
                nb = sb[(sb.dose == dose) & (sb.param == pb_)].n.iloc[0]
                dr.append(dict(dose=dose, metric=pa, A=a, B=b, ratio_B_over_A=b / a, n_A=na, n_B=nb))
        drdf = pd.DataFrame(dr)
        drdf.to_csv(RES / "pk_B_over_A.csv", index=False)
        x = drdf[(drdf.dose >= 10) & drdf.metric.isin(["Cmax", "AUC0-∞"])]
        summ["B_over_A_geo"] = dict(geo_mean=float(np.exp(np.log(x.ratio_B_over_A).mean())), min=float(x.ratio_B_over_A.min()), max=float(x.ratio_B_over_A.max()))
    else:
        log("[pk-checks] input B not found: external comparison skipped")
    # body-weight context: CL (L/day) implied by the per-kg fit and the group median body weights, against Table 3 CL
    bw = D.a_body_weight_median()
    cl_rows = []
    for dose, sched in D.A_GROUPS:
        cl_tab = s1[(s1.dose == dose) & (s1.sched == sched) & (s1.param == "CL")]["mean"].iloc[0]
        for m in ("1c", "2c"):
            cl_rows.append(dict(model=m, dose=dose, sched=sched, cl_fit_L_day_at_median_bw=fits[m]["theta"]["CL"] * bw[D.gkey(dose, sched)], cl_table3=cl_tab))
    cl_df = pd.DataFrame(cl_rows)
    cl_df.to_csv(RES / "pk_cl_unit_check.csv", index=False)
    for m in ("1c", "2c"):
        r_ = (cl_df[cl_df.model == m].cl_fit_L_day_at_median_bw / cl_df[cl_df.model == m].cl_table3).values
        summ[f"cl_unit_ratio_{m}"] = dict(min=float(r_.min()), max=float(r_.max()), geo_mean=float(np.exp(np.log(r_).mean())))
    dump(summ, "pk_check_summary.json")
    log("[pk-checks] written")


# ---------------------------------------------------------------------------------------------------------------
def regimen_metrics(th, dose, tau, tinf_h):
    ss = K.steady_state_metrics(th, dose, tau, tinf_h)
    ss["Cavg_window"] = K.window_average_ss(th, dose, tau, WINDOW_DAYS, tinf_h)
    return ss


def stage_reg():
    t0 = time.time()
    fits = {m: load_fit(m) for m in ("1c", "2c")}
    draws = {m: load_draws(m, 500) for m in ("1c", "2c")}
    rows, draw_rows = [], []
    for m in ("1c", "2c"):
        for name, (dose, tau) in REGIMENS.items():
            pt = regimen_metrics(fits[m]["theta"], dose, tau, K.TINF_DEFAULT_H)
            ds = pd.DataFrame([regimen_metrics(theta_from_row(z, m), dose, tau, K.TINF_DEFAULT_H) for z in draws[m]])
            row = dict(model=m, regimen=name, dose=dose, tau=tau, intensity_mg_kg_week=dose / tau * 7, hypothetical=name in HYPOTHETICAL)
            for k_ in ("Cmax_ss", "Cmin_ss", "AUCtau_ss", "Cavg_ss", "Cavg_window"):
                row[k_] = pt[k_]
                row[k_ + "_lo"], row[k_ + "_hi"] = q(ds[k_])
            rows.append(row)
            ds["model"], ds["regimen"] = m, name
            draw_rows.append(ds)
    pd.DataFrame(rows).to_csv(RES / "regimen_ss_metrics.csv", index=False)
    dd = pd.concat(draw_rows)
    # ratio 30 mg/kg Q3W / 20 mg/kg Q2W (typical subject), parameter uncertainty only
    rr = []
    for m in ("1c", "2c"):
        a = dd[(dd.model == m) & (dd.regimen == "30 mg/kg Q3W")].reset_index(drop=True)
        b = dd[(dd.model == m) & (dd.regimen == "20 mg/kg Q2W")].reset_index(drop=True)
        for k_ in ("Cmax_ss", "Cmin_ss", "Cavg_ss", "Cavg_window"):
            r_ = (a[k_] / b[k_]).values
            rr.append(dict(model=m, metric=k_, median=float(np.median(r_)), lo=q(r_)[0], hi=q(r_)[1]))
    pd.DataFrame(rr).to_csv(RES / "ratio_30Q3W_over_20Q2W_typical.csv", index=False)
    # variability scenarios (conditional inputs; no covariance structure estimated)
    cl_cv = D.a_table3(True)
    cl_cv = cl_cv[cl_cv.param == "CL"]
    cvs = (cl_cv.sd / cl_cv["mean"]).values
    vz = D.a_table3(True)
    vz = vz[vz.param == "Vz"]
    vcv = (vz.sd / vz["mean"]).values
    rng = np.random.default_rng(SEED)
    scen_rows, sample_store = [], {}
    for m in ("1c", "2c"):
        th0 = fits[m]["theta"]
        for (cvcl, cvv, rho) in CV_SCENARIOS:
            s_cl, s_v = np.sqrt(np.log1p(cvcl ** 2)), np.sqrt(np.log1p(cvv ** 2))
            cov = np.array([[s_cl ** 2, rho * s_cl * s_v], [rho * s_cl * s_v, s_v ** 2]])
            eta = rng.multivariate_normal([0, 0], cov, size=N_VIRTUAL)
            res = {}
            for name in ("20 mg/kg Q2W", "30 mg/kg Q3W"):
                dose, tau = REGIMENS[name]
                vals = []
                for e in eta:
                    th = dict(th0)
                    th["CL"] = th0["CL"] * np.exp(e[0])
                    th["V1"] = th0["V1"] * np.exp(e[1])
                    vals.append(K.steady_state_metrics(th, dose, tau, K.TINF_DEFAULT_H))
                res[name] = pd.DataFrame(vals)
            a, b = res["30 mg/kg Q3W"], res["20 mg/kg Q2W"]
            row = dict(model=m, cv_cl=cvcl, cv_v1=cvv, rho=rho, n_virtual=N_VIRTUAL)
            for k_ in ("Cmax_ss", "Cmin_ss", "AUCtau_ss"):
                r_ = (a[k_] / b[k_]).values
                row[f"ratio_{k_}_median"], (row[f"ratio_{k_}_p025"], row[f"ratio_{k_}_p975"]) = float(np.median(r_)), q(r_)
            row["cavg_diff_paired_max_abs"] = float(np.max(np.abs(2 * a.AUCtau_ss - 3 * b.AUCtau_ss)))  # AUC over the 42-d window, per subject
            row["frac_cmax_higher_30Q3W"] = float((a.Cmax_ss > b.Cmax_ss).mean())
            row["frac_cmin_higher_20Q2W"] = float((b.Cmin_ss > a.Cmin_ss).mean())
            for name, ddf in res.items():
                row[f"{name}_Cmax_p05"], row[f"{name}_Cmax_p95"] = q(ddf.Cmax_ss, 5, 95)
                row[f"{name}_Cmin_p05"], row[f"{name}_Cmin_p95"] = q(ddf.Cmin_ss, 5, 95)
                row[f"{name}_Cmax_median"], row[f"{name}_Cmin_median"] = float(ddf.Cmax_ss.median()), float(ddf.Cmin_ss.median())
            scen_rows.append(row)
            if (cvcl, cvv, rho) == CV_SCENARIOS[1]:
                sample_store[m] = (res["20 mg/kg Q2W"], res["30 mg/kg Q3W"])
    pd.DataFrame(scen_rows).to_csv(RES / "variability_scenarios_20Q2W_vs_30Q3W.csv", index=False)
    # extra scenario (2-compartment only): peripheral parameters also vary (scenario inputs CV(Q) 50%, CV(V2) 30%, independent of CL and V1)
    th0 = fits["2c"]["theta"]
    rng2 = np.random.default_rng(SEED + 1)
    e4 = rng2.normal(size=(N_VIRTUAL, 4)) * np.sqrt(np.log1p(np.array([0.25, 0.20, 0.50, 0.30]) ** 2))
    rr_c, rr_x = [], []
    for e in e4:
        th = dict(CL=th0["CL"] * np.exp(e[0]), V1=th0["V1"] * np.exp(e[1]), Q=th0["Q"] * np.exp(e[2]), V2=th0["V2"] * np.exp(e[3]))
        a_ = K.steady_state_metrics(th, 30.0, 21.0, K.TINF_DEFAULT_H)
        b_ = K.steady_state_metrics(th, 20.0, 14.0, K.TINF_DEFAULT_H)
        rr_c.append(a_["Cmin_ss"] / b_["Cmin_ss"])
        rr_x.append(a_["Cmax_ss"] / b_["Cmax_ss"])
    pd.DataFrame([dict(model="2c", cv_cl=0.25, cv_v1=0.20, cv_q=0.50, cv_v2=0.30, n_virtual=N_VIRTUAL, ratio_Cmin_median=float(np.median(rr_c)),
                       ratio_Cmin_p025=q(rr_c)[0], ratio_Cmin_p975=q(rr_c)[1], ratio_Cmax_median=float(np.median(rr_x)),
                       ratio_Cmax_p025=q(rr_x)[0], ratio_Cmax_p975=q(rr_x)[1])]).to_csv(RES / "variability_scenario_peripheral_2c.csv", index=False)
    for m, (b_, a_) in sample_store.items():
        pd.DataFrame(dict(cmax_q2w=b_.Cmax_ss, cmin_q2w=b_.Cmin_ss, cmax_q3w=a_.Cmax_ss, cmin_q3w=a_.Cmin_ss)).to_csv(RES / f"virtual_subjects_scenario2_{m}.csv", index=False)
    dump(dict(reported_cl_cv_range=[float(cvs.min()), float(cvs.max())], reported_vz_cv_range=[float(vcv.min()), float(vcv.max())],
              scenarios=[dict(cv_cl=a, cv_v1=b, rho=c) for a, b, c in CV_SCENARIOS], note="scenario inputs, not estimates"), "variability_inputs.json")
    # concentration profiles over a common 42-day steady-state window (typical subject; both models)
    t = np.linspace(0, WINDOW_DAYS, 1681)
    prof = {}
    for m in ("1c", "2c"):
        th = fits[m]["theta"]
        lam, A = K.micro_to_macro(th["CL"], th["V1"], th.get("Q", 0.0), th.get("V2", 1.0))
        for name, (dose, tau) in REGIMENS.items():
            tt = np.mod(t, tau)
            prof[f"{m}|{name}"] = K.conc_steady_state(tt, dose, tau, K.TINF_DEFAULT_H / 24, lam, A)
    pd.DataFrame(dict(day=t, **prof)).to_csv(RES / "regimen_profiles_42d.csv", index=False)
    # time above a concentration threshold (hypothetical thresholds)
    thr = np.logspace(-0.5, 2.8, 60)
    rows = []
    for m in ("1c", "2c"):
        for name in REGIMENS:
            c = prof[f"{m}|{name}"]
            for x in thr:
                rows.append(dict(model=m, regimen=name, threshold_ug_ml=x, frac_time_above=float((c[:-1] > x).mean())))
    pd.DataFrame(rows).to_csv(RES / "time_above_threshold.csv", index=False)
    log(f"[reg] done in {time.time() - t0:.0f} s")


STAGES = {"pk": stage_pk, "reg": stage_reg}


def _register():
    import importlib
    for mod, names in (("stages_pd", {"ro": "stage_ro", "vegf": "stage_vegf"}), ("stages_clin", {"rates": "stage_rates", "er": "stage_er"}),
                       ("stages_sens", {"sens": "stage_sens", "gap": "stage_gap"})):
        try:
            m = importlib.import_module(mod)
        except ModuleNotFoundError:
            continue
        for k, v in names.items():
            STAGES[k] = getattr(m, v)


if __name__ == "__main__":
    _register()
    sel = sys.argv[1:] or ["pk", "reg", "ro", "vegf", "rates", "er", "sens", "gap"]
    RES.mkdir(exist_ok=True)
    if not sys.argv[1:] and (RES / "run_log.txt").exists():
        (RES / "run_log.txt").unlink()
    log(f"seed {SEED}; stages {sel}")
    for s in sel:
        STAGES[s]()
