"""Beta-Binomial and stratified logistic (grid) posteriors for group-level counts. No individual-level data."""
from __future__ import annotations

import numpy as np
from scipy import stats
from scipy.special import expit, logit, gammaln

PRIORS = {
    "Jeffreys Beta(0.5, 0.5)": (0.5, 0.5),
    "Uniform Beta(1, 1)": (1.0, 1.0),
    "Weak Beta(2, 2)": (2.0, 2.0),
    "Informative-mean 0.4, ESS 4 Beta(1.6, 2.4)": (1.6, 2.4),
    "Sceptical-low 0.2, ESS 5 Beta(1, 4)": (1.0, 4.0),
}
PRIMARY_PRIOR = "Weak Beta(2, 2)"


def beta_post(events: int, n: int, prior=(2.0, 2.0)):
    return stats.beta(prior[0] + events, prior[1] + n - events)


def cred_interval(dist, level=0.95):
    a = (1 - level) / 2
    return float(dist.ppf(a)), float(dist.ppf(1 - a))


def exact_wilson(events: int, n: int, level=0.95):
    z = stats.norm.ppf(1 - (1 - level) / 2)
    p = events / n
    den = 1 + z * z / n
    c = (p + z * z / (2 * n)) / den
    h = z * np.sqrt(p * (1 - p) / n + z * z / (4 * n * n)) / den
    return c - h, c + h


def diff_posterior(e1, n1, e2, n2, prior=(2.0, 2.0), n_draw=400_000, seed=20261105):
    """Posterior of p2 - p1 and the odds ratio by Monte Carlo from independent Beta posteriors."""
    rng = np.random.default_rng(seed)
    p1 = beta_post(e1, n1, prior).rvs(n_draw, random_state=rng)
    p2 = beta_post(e2, n2, prior).rvs(n_draw, random_state=rng)
    d = p2 - p1
    orr = (p2 / (1 - p2)) / (p1 / (1 - p1))
    return dict(diff_mean=float(d.mean()), diff_lo=float(np.quantile(d, 0.025)), diff_hi=float(np.quantile(d, 0.975)),
                p_pos=float((d > 0).mean()), p_within_10pp=float((np.abs(d) < 0.10).mean()),
                or_median=float(np.median(orr)), or_lo=float(np.quantile(orr, 0.025)), or_hi=float(np.quantile(orr, 0.975)))


def stratified_logistic_slope(strata, prior_sd_slope=1.0, prior_sd_int=2.5, grid=None, n_quad=121):
    """Common log-odds-ratio (dose B vs dose A) across strata, with independent N(0, prior_sd_int^2) stratum intercepts.

    strata: list of (nA, eA, nB, eB). Intercept (logit p_A) is integrated numerically per stratum; the slope is on a grid.
    Returns grid, posterior density (normalised on grid) and the marginal-likelihood (log) at each slope.
    """
    if grid is None:
        grid = np.linspace(-4, 4, 801)
    a = np.linspace(-prior_sd_int * 4, prior_sd_int * 4, n_quad)
    w = stats.norm.pdf(a, 0, prior_sd_int)
    w = w / w.sum()
    loglik = np.zeros_like(grid)
    for (nA, eA, nB, eB) in strata:
        pa = expit(a)[:, None]
        pb = expit(a[:, None] + grid[None, :])
        ll = eA * np.log(pa) + (nA - eA) * np.log1p(-pa) + eB * np.log(pb) + (nB - eB) * np.log1p(-pb)
        m = ll.max(axis=0)
        loglik += m + np.log((w[:, None] * np.exp(ll - m)).sum(axis=0))
    logpost = loglik + stats.norm.logpdf(grid, 0, prior_sd_slope)
    post = np.exp(logpost - logpost.max())
    post = post / np.trapezoid(post, grid)
    return grid, post, loglik


def summarise_grid(grid, post):
    cdf = np.cumsum(post) * (grid[1] - grid[0])
    cdf = cdf / cdf[-1]
    q = lambda p: float(np.interp(p, cdf, grid))
    mean = float(np.trapezoid(grid * post, grid))
    return dict(mean=mean, lo=q(0.025), hi=q(0.975), median=q(0.5), p_pos=float(1 - np.interp(0.0, grid, cdf)))


def logistic_dose_slope_2d(doses, events, ns, x_name="log2 dose", prior_sd_slope=1.0, prior_sd_int=3.0, n=161):
    """Binomial logistic regression logit p = a + b * x with x = log2(dose) centred; posterior on a 2-D grid."""
    x = np.log2(np.asarray(doses, float))
    x = x - x.mean()
    a = np.linspace(-6, 4, n)
    b = np.linspace(-3, 3, n)
    A, B = np.meshgrid(a, b, indexing="ij")
    ll = np.zeros_like(A)
    for xi, e, nn in zip(x, events, ns):
        p = expit(A + B * xi)
        ll += e * np.log(p) + (nn - e) * np.log1p(-p)
    lp = ll + stats.norm.logpdf(A, 0, prior_sd_int) + stats.norm.logpdf(B, 0, prior_sd_slope)
    post = np.exp(lp - lp.max())
    post /= post.sum()
    pb = post.sum(axis=0)
    pb = pb / (pb.sum() * (b[1] - b[0]))
    return dict(b=b, pb=pb, a=a, loglik_max=float(ll.max()), x_centre=float(np.log2(np.asarray(doses, float)).mean()))


def loglik_binomial_logit(covariate, events, ns):
    """Maximised binomial log-likelihood of logit p = a + b * covariate (profile over a,b), for covariate comparison."""
    from scipy.optimize import minimize
    x = np.asarray(covariate, float)
    x = (x - x.mean()) / (x.std() if x.std() > 0 else 1.0)
    e, nn = np.asarray(events, float), np.asarray(ns, float)

    def f(par):
        p = np.clip(expit(par[0] + par[1] * x), 1e-12, 1 - 1e-12)
        return -np.sum(e * np.log(p) + (nn - e) * np.log1p(-p))
    best = min((minimize(f, s, method="Nelder-Mead") for s in ([0, 0], [-1, 0.5], [-1, -0.5])), key=lambda r: r.fun)
    return float(-best.fun), best.x
