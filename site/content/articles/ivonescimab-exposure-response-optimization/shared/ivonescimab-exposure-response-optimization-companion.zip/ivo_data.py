"""Loaders for the transcribed input tables (inputs/*.csv). All values are group-level aggregates."""
from __future__ import annotations

import re
from pathlib import Path

import numpy as np
import pandas as pd

HERE = Path(__file__).resolve().parent
INP = HERE / "inputs"
RES = HERE / "results"
FIG = HERE / "figures"
SEED = 20261105

TAU = {"Q2W": 14.0, "Q3W": 21.0}
A_GROUPS = [(3, "Q2W"), (5, "Q2W"), (10, "Q2W"), (20, "Q2W"), (30, "Q2W"), (10, "Q3W"), (20, "Q3W")]
MW_KDA_RANGE = (150.0, 200.0)   # assumed molar mass range for an IgG-like tetravalent bispecific (unit context only)


def _csv(name: str) -> pd.DataFrame:
    return pd.read_csv(INP / name)


def _num(x):
    return pd.to_numeric(x, errors="coerce")


def gkey(dose, sched) -> str:
    d = float(dose)
    return f"{d:g}_{sched}"


def load_A() -> pd.DataFrame:
    d = _csv("A_cam4_70653_phase1_AK112-102.csv")
    d["dose"] = _num(d["dose_mg_per_kg"])
    d["val"] = _num(d["value"])
    return d


def a_table3(single: bool) -> pd.DataFrame:
    """Table 3 NCA summaries of the Phase I study A in long form with mean, SD, n per group."""
    d = load_A()
    t = d[d.table_or_figure == "Table 3"].copy()
    key = "single dose" if single else "steady-state NCA"
    t = t[t.population.str.contains(key)]
    t["param"] = t.parameter.str.replace("‐", "-", regex=False)
    rows = []
    for (dose, sched), g in t.groupby(["dose", "schedule"]):
        n = g[g.param == "n (PK set)"].val.iloc[0]
        for p, gg in g.groupby("param"):
            if p == "n (PK set)":
                continue
            m = gg[gg.stat == "mean"].val
            s = gg[gg.stat == "SD"].val
            if len(m):
                rows.append(dict(dose=dose, sched=sched, param=p, mean=m.iloc[0],
                                 sd=s.iloc[0] if len(s) else np.nan, n=n))
    return pd.DataFrame(rows)


def a_troughs() -> pd.DataFrame:
    d = load_A()
    t = d[d.table_or_figure == "Supplementary Table S7"].copy()
    t["day"] = t.timepoint.str.extract(r"Day (\d+)").astype(float)
    out = []
    for (dose, sched, day), g in t.groupby(["dose", "schedule", "day"]):
        m = g[g.stat == "mean"].val
        s = g[g.stat == "SD"].val
        out.append(dict(dose=dose, sched=sched, day=day, mean=m.iloc[0] if len(m) else np.nan,
                        sd=s.iloc[0] if len(s) else np.nan))
    return pd.DataFrame(out).sort_values(["dose", "sched", "day"]).reset_index(drop=True)


def a_cohort_n() -> dict:
    d = load_A()
    t = d[(d.table_or_figure == "Table 1") & (d.parameter == "N enrolled/treated") & (d.dose.notna())]
    return {gkey(r.dose, r.schedule): int(r.val) for r in t.itertuples()}


def a_body_weight_median() -> dict:
    d = load_A()
    t = d[(d.table_or_figure == "Table 1") & (d.parameter == "Baseline body weight") & (d.stat == "median") & (d.dose.notna())]
    return {gkey(r.dose, r.schedule): float(r.val) for r in t.itertuples()}


def a_table5(param_substr: str) -> pd.DataFrame:
    d = load_A()
    t = d[(d.table_or_figure == "Table 5") & d.parameter.str.contains(param_substr, regex=False)].copy()
    t["day"] = t.timepoint.str.extract(r"Day (\d+)").astype(float)
    t["kind"] = np.where(t.timepoint.str.contains("EOI"), "EOI", np.where(t.timepoint.str.contains("predose"), "predose", "post"))
    out = []
    for (dose, sched, tp), g in t.groupby(["dose", "schedule", "timepoint"]):
        m, s = g[g.stat == "mean"].val, g[g.stat == "SD"].val
        out.append(dict(dose=dose, sched=sched, timepoint=tp, day=g.day.iloc[0], kind=g.kind.iloc[0],
                        mean=m.iloc[0] if len(m) else np.nan, sd=s.iloc[0] if len(s) else np.nan))
    return pd.DataFrame(out)


def a_ae() -> pd.DataFrame:
    """Grade>=3 TRAE counts and denominators by dose group (Table 2)."""
    d = load_A()
    t = d[(d.table_or_figure == "Table 2") & (d.parameter == "≥ Grade 3 TRAEs") & (d.stat == "n")]
    n = a_cohort_n()
    rows = []
    for r in t.itertuples():
        if pd.isna(r.dose):
            continue
        rows.append(dict(dose=r.dose, sched=r.schedule, events=int(r.val), n=n[gkey(r.dose, r.schedule)]))
    return pd.DataFrame(rows)


# ---------------------------------------------------------------------------------------------------------------
def load_B() -> pd.DataFrame:
    d = _csv("B_jitc_008037_phase1a_AK112-101.csv")
    d["dose"] = _num(d["dose_mg_per_kg"])
    d["val"] = _num(d["value"])
    return d


def b_pk(single: bool) -> pd.DataFrame:
    d = load_B()
    t = d[d.table_or_figure == ("Supplementary Table S2" if single else "Supplementary Table S3")]
    rows = []
    for dose, g in t.groupby("dose"):
        n = g[g.parameter == "n (PK set)"].val.iloc[0]
        for p, gg in g.groupby("parameter"):
            if p == "n (PK set)":
                continue
            m, s = gg[gg.stat == "mean"].val, gg[gg.stat == "SD"].val
            if len(m):
                rows.append(dict(dose=dose, sched="Q2W", param=p, mean=m.iloc[0], sd=s.iloc[0] if len(s) else np.nan, n=n))
    return pd.DataFrame(rows)


def b_ae() -> pd.DataFrame:
    """Grade>=3 TRAE by dose-group band in study B (Table 2). The 0.3-3 mg/kg band is pooled (N=7)."""
    d = load_B()
    t = d[(d.table_or_figure == "Table 2") & (d.parameter == "TRAEs grade>=3")]
    ns = {"0.3-3": 7, "10": 19, "20": 18, "30": 7}
    rows = []
    for r in t[t.stat == "n"].itertuples():
        k = str(r.dose_mg_per_kg)
        if k in ns:
            rows.append(dict(band=k, events=int(r.val), n=ns[k]))
    return pd.DataFrame(rows)


# ---------------------------------------------------------------------------------------------------------------
def load_D() -> pd.DataFrame:
    d = _csv("D_eclinm_102106_AK112-201.csv")
    d["val"] = _num(d["value"])
    return d


def d_orr() -> pd.DataFrame:
    d = load_D()
    t = d[(d.table_or_figure == "Table 2")]
    rows = []
    for coh in (1, 2, 3):
        for dose in ("10 ", "20 "):
            dd = t[(t.dose_mg_per_kg.astype(str).str.strip() == dose.strip()) & t.parameter.str.startswith(f"cohort {coh} ")]
            n = dd[dd.parameter == f"cohort {coh} n (FAS)"].val.iloc[0]
            k = dd[dd.parameter == f"cohort {coh} confirmed ORR responders"].val.iloc[0]
            rows.append(dict(cohort=coh, dose=float(dose), n=int(n), events=int(k)))
    return pd.DataFrame(rows)


def d_trae() -> pd.DataFrame:
    d = load_D()
    t = d[(d.table_or_figure == "Table 3") & (d.parameter == "Any TRAE grade>=3") & (d.stat == "n")]
    s = d[(d.table_or_figure == "Table 3") & (d.parameter == "Safety set N")]
    rows = []
    for dose in ("10 Q3W", "20 Q3W"):
        dd = float(dose.split()[0])
        k = t[t.dose_mg_per_kg.astype(str).str.strip() == str(int(dd))].val.iloc[0]
        n = s[s.dose_mg_per_kg.astype(str).str.strip() == str(int(dd))].val.iloc[0]
        rows.append(dict(dose=dd, events=int(k), n=int(n)))
    return pd.DataFrame(rows)


def load_C() -> pd.DataFrame:
    d = _csv("C_jtho_2023_10_014_harmoni5_AK112-202_abstract_only.csv")
    d["val"] = _num(d["value"])
    return d


def c_orr_percent() -> pd.DataFrame:
    d = load_C()
    t = d[(d.parameter == "ORR") & (d.stat == "percent")]
    return pd.DataFrame(dict(regimen=[f"{r.dose_mg_per_kg} {r.schedule}" for r in t.itertuples()], percent=t.val.values))


def load_E() -> pd.DataFrame:
    d = _csv("E_phase3_harmoni2_harmoni6.csv")
    d["val"] = _num(d["value"])
    return d


def e_trae_counts() -> pd.DataFrame:
    """Grade>=3 TRAE counts with denominators printed in the sources (HARMONi-2 PFS analysis; HARMONi-6 OS analysis)."""
    return pd.DataFrame([
        dict(trial="HARMONi-2", arm="ivonescimab 20 mg/kg Q3W", events=58, n=197),
        dict(trial="HARMONi-2", arm="pembrolizumab 200 mg Q3W", events=31, n=199),
        dict(trial="HARMONi-6", arm="ivonescimab 20 mg/kg Q3W + chemo", events=184, n=266),
        dict(trial="HARMONi-6", arm="tislelizumab 200 mg + chemo", events=156, n=265),
    ])


def load_G() -> pd.DataFrame:
    return _csv("G_iscience_111722_binding.csv")


def g_kd_molar() -> dict:
    g = load_G()
    pd1 = float(g[g.parameter == "PD-1 KD ivonescimab"].value.iloc[0])
    vegf = float(g[g.parameter == "VEGF KD ivonescimab"].value.iloc[0])
    return dict(PD1=pd1, VEGF=vegf)
