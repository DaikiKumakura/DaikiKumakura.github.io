"""Regimen-level clinical rates (Beta-Binomial, stratified logistic grids) and hypothetical exposure-response sensitivity."""
from __future__ import annotations

import numpy as np
import pandas as pd
from scipy import stats
from scipy.special import expit, logit

import ivo_data as D
import pkmodel as K
import rates as R
from analysis import RES, SEED, dump, log, load_fit, PRIMARY_MODEL


def _post_rows(label_cols: dict, events: int, n: int):
    rows = []
    for pname, pr in R.PRIORS.items():
        post = R.beta_post(events, n, pr)
        lo, hi = R.cred_interval(post)
        rows.append(dict(**label_cols, prior=pname, events=events, n=n, observed=events / n, post_mean=float(post.mean()), post_lo=lo, post_hi=hi,
                         wilson_lo=R.exact_wilson(events, n)[0], wilson_hi=R.exact_wilson(events, n)[1]))
    return rows


def stage_rates():
    out = {}
    # ---- Dataset D: ORR by cohort and dose (chemotherapy combination, 10 vs 20 mg/kg Q3W, non-randomised sequential)
    orr = D.d_orr()
    rows = []
    for r in orr.itertuples():
        rows += _post_rows(dict(dataset="D ORR", cohort=r.cohort, dose=r.dose), r.events, r.n)
    pd.DataFrame(rows).to_csv(RES / "rates_D_orr_posteriors.csv", index=False)
    drows = []
    for coh in (1, 2, 3):
        a = orr[(orr.cohort == coh) & (orr.dose == 10.0)].iloc[0]
        b = orr[(orr.cohort == coh) & (orr.dose == 20.0)].iloc[0]
        for pname, pr in R.PRIORS.items():
            d_ = R.diff_posterior(a.events, a.n, b.events, b.n, pr, seed=SEED)
            drows.append(dict(cohort=coh, prior=pname, n10=a.n, k10=a.events, n20=b.n, k20=b.events, **d_))
    pd.DataFrame(drows).to_csv(RES / "rates_D_orr_diff_by_cohort.csv", index=False)
    # pooled over cohorts (crude: mixes cohorts with different baseline response), for display only
    tot = orr.groupby("dose")[["events", "n"]].sum().reset_index()
    pooled = []
    for r in tot.itertuples():
        pooled += _post_rows(dict(dataset="D ORR pooled over cohorts", cohort="all", dose=r.dose), int(r.events), int(r.n))
    pd.DataFrame(pooled).to_csv(RES / "rates_D_orr_pooled.csv", index=False)
    # stratified logistic: common log-odds ratio for 20 vs 10 mg/kg (one doubling), cohort-specific intercepts
    strata = []
    for coh in (1, 2, 3):
        a = orr[(orr.cohort == coh) & (orr.dose == 10.0)].iloc[0]
        b = orr[(orr.cohort == coh) & (orr.dose == 20.0)].iloc[0]
        strata.append((int(a.n), int(a.events), int(b.n), int(b.events)))
    sl = []
    keep = {}
    for sd_ in (0.5, 1.0, 2.0):
        g, post, ll = R.stratified_logistic_slope(strata, prior_sd_slope=sd_)
        s = R.summarise_grid(g, post)
        prior_var = sd_ ** 2
        post_var = float(np.trapezoid((g - s["mean"]) ** 2 * post, g))
        s.update(prior_sd=sd_, post_sd=float(np.sqrt(post_var)), shrinkage_info_fraction=1 - post_var / prior_var,
                 or_median=float(np.exp(s["median"])), or_lo=float(np.exp(s["lo"])), or_hi=float(np.exp(s["hi"])))
        # ORR difference 20 vs 10 at reference ORR of 50% at 10 mg/kg
        d_ = expit(logit(0.5) + g) - 0.5
        cdf = np.cumsum(post) / post.sum()
        s["orr_diff_at_ref50_median"] = float(np.interp(0.5, cdf, d_))
        s["orr_diff_at_ref50_lo"] = float(np.interp(0.025, cdf, d_))
        s["orr_diff_at_ref50_hi"] = float(np.interp(0.975, cdf, d_))
        s["p_abs_diff_lt_10pp_at_ref50"] = float(post[np.abs(d_) < 0.10].sum() / post.sum())
        # extrapolation 20 -> 30 mg/kg Q3W is 0.585 doublings (hypothetical; 30 mg/kg Q3W is not in dataset D)
        d30 = expit(logit(0.5) + 0.585 * g) - 0.5
        s["orr_change_20_to_30_ref50_median"] = float(np.interp(0.5, cdf, d30))
        s["orr_change_20_to_30_ref50_lo"] = float(np.interp(0.025, cdf, d30))
        s["orr_change_20_to_30_ref50_hi"] = float(np.interp(0.975, cdf, d30))
        sl.append(s)
        keep[sd_] = (g, post)
    out["D_orr_common_logOR_20_vs_10"] = sl
    # heterogeneity of the cohort-specific log odds ratios (Haldane-Anscombe 0.5 correction); Cochran Q and DerSimonian-Laird
    lo, vv = [], []
    for (nA, eA, nB, eB) in strata:
        a_, b_, c_, d_ = eB + 0.5, nB - eB + 0.5, eA + 0.5, nA - eA + 0.5
        lo.append(np.log(a_ * d_ / (b_ * c_)))
        vv.append(1 / a_ + 1 / b_ + 1 / c_ + 1 / d_)
    lo, vv = np.array(lo), np.array(vv)
    w = 1 / vv
    mu_fe = float((w * lo).sum() / w.sum())
    Qc = float((w * (lo - mu_fe) ** 2).sum())
    tau2 = max(0.0, (Qc - 2) / (w.sum() - (w ** 2).sum() / w.sum()))
    w_re = 1 / (vv + tau2)
    mu_re = float((w_re * lo).sum() / w_re.sum())
    se_re = float(np.sqrt(1 / w_re.sum()))
    out["D_orr_cohort_heterogeneity"] = dict(cohort_log_or=lo.tolist(), cohort_se=np.sqrt(vv).tolist(), cochran_Q=Qc, p_Q=float(stats.chi2.sf(Qc, 2)),
                                             I2=float(max(0.0, (Qc - 2) / Qc)) if Qc > 0 else 0.0, tau2=tau2, re_pooled_log_or=mu_re,
                                             re_lo=mu_re - 1.96 * se_re, re_hi=mu_re + 1.96 * se_re, note="3 cohorts: low power to detect heterogeneity")
    pd.DataFrame(dict(log_or=keep[1.0][0], density=keep[1.0][1])).to_csv(RES / "rates_D_orr_slope_posterior.csv", index=False)
    # unstratified comparison (cohort effects ignored) for contrast
    tot_ = tot.set_index("dose")
    out["D_orr_pooled_diff"] = R.diff_posterior(int(tot_.loc[10.0, "events"]), int(tot_.loc[10.0, "n"]), int(tot_.loc[20.0, "events"]), int(tot_.loc[20.0, "n"]), seed=SEED)

    # ---- Dataset D: grade >= 3 TRAE (chemotherapy combination, all cohorts pooled, safety set)
    tr = D.d_trae()
    rows = []
    for r in tr.itertuples():
        rows += _post_rows(dict(dataset="D G>=3 TRAE", cohort="all", dose=r.dose), r.events, r.n)
    pd.DataFrame(rows).to_csv(RES / "rates_D_trae_posteriors.csv", index=False)
    a, b = tr.iloc[0], tr.iloc[1]
    out["D_trae_diff"] = {pn: R.diff_posterior(a.events, a.n, b.events, b.n, pr, seed=SEED) for pn, pr in R.PRIORS.items()}

    # ---- Dataset A: grade >= 3 TRAE by dose group (monotherapy phase I, small n)
    ae = D.a_ae()
    rows = []
    for r in ae.itertuples():
        rows += _post_rows(dict(dataset="A G>=3 TRAE", cohort=r.sched, dose=r.dose), r.events, r.n)
    pd.DataFrame(rows).to_csv(RES / "rates_A_trae_posteriors.csv", index=False)
    slopes = {}
    for label, sel in (("Q2W 3-30 mg/kg (5 groups)", ae.sched == "Q2W"), ("all 7 groups", ae.sched.notna())):
        x = ae[sel]
        for sd_ in (0.5, 1.0, 2.0):
            r_ = R.logistic_dose_slope_2d(x.dose.values, x.events.values, x.n.values, prior_sd_slope=sd_)
            s = R.summarise_grid(r_["b"], r_["pb"])
            slopes[f"{label}|prior_sd={sd_}"] = dict(or_per_doubling_median=float(np.exp(s["median"])), or_lo=float(np.exp(s["lo"])), or_hi=float(np.exp(s["hi"])),
                                                     p_slope_positive=s["p_pos"], log_or_lo=s["lo"], log_or_hi=s["hi"])
    out["A_trae_dose_slope"] = slopes
    r_ = R.logistic_dose_slope_2d(ae[ae.sched == "Q2W"].dose.values, ae[ae.sched == "Q2W"].events.values, ae[ae.sched == "Q2W"].n.values)
    pd.DataFrame(dict(log_or_per_doubling=r_["b"], density=r_["pb"])).to_csv(RES / "rates_A_trae_slope_posterior.csv", index=False)

    # ---- Dataset B: grade >= 3 TRAE by dose band (Phase Ia, supplementary context for slope)
    bae = D.b_ae()
    rows = []
    for r in bae.itertuples():
        rows += _post_rows(dict(dataset="B G>=3 TRAE", cohort="Q2W", dose=r.band), r.events, r.n)
    pd.DataFrame(rows).to_csv(RES / "rates_B_trae_posteriors.csv", index=False)
    x = bae[bae.band.isin(["10", "20", "30"])]
    r_ = R.logistic_dose_slope_2d([10, 20, 30], x.events.values, x.n.values)
    s = R.summarise_grid(r_["b"], r_["pb"])
    out["B_trae_dose_slope_10_20_30"] = dict(or_per_doubling_median=float(np.exp(s["median"])), or_lo=float(np.exp(s["lo"])), or_hi=float(np.exp(s["hi"])), p_slope_positive=s["p_pos"])

    # ---- Phase III context (comparator trials, not dose comparisons)
    e = D.e_trae_counts()
    rows, diffs = [], {}
    for r in e.itertuples():
        rows += _post_rows(dict(dataset=f"{r.trial} G>=3 TRAE", cohort=r.arm, dose=np.nan), r.events, r.n)
    pd.DataFrame(rows).to_csv(RES / "rates_phase3_trae_posteriors.csv", index=False)
    for trial in ("HARMONi-2", "HARMONi-6"):
        x = e[e.trial == trial].reset_index(drop=True)
        diffs[trial] = R.diff_posterior(x.events[1], x.n[1], x.events[0], x.n[0], seed=SEED)   # ivonescimab minus comparator
    out["phase3_trae_diff_ivonescimab_minus_comparator"] = diffs

    # ---- HARMONi-5 (AK112-202): printed percentages only; no counts or intervals are derived
    c5 = D.c_orr_percent()
    c5["n_available"] = False
    c5.to_csv(RES / "rates_C_printed_percentages.csv", index=False)
    out["C_note"] = "Only printed ORR percentages by regimen in the PD-L1-positive first-line subset (n = 67 in total); regimen-level n not available; no counts, intervals or slope computed."
    dump(out, "rates_summary.json")
    log("[rates] done")


def _exposure_table(model="primary"):
    m = PRIMARY_MODEL
    th = load_fit(m)["theta"]
    rows = []
    for dose, sched in D.A_GROUPS:
        tau = D.TAU[sched]
        ss = K.steady_state_metrics(th, dose, tau)
        rows.append(dict(dose=dose, sched=sched, intensity=dose / tau * 7, Cavg_ss=ss["Cavg_ss"], Cmax_ss=ss["Cmax_ss"], Cmin_ss=ss["Cmin_ss"]))
    return pd.DataFrame(rows)


def stage_er():
    """Hypothetical, conditional sensitivity analysis: group-level exposure as covariate. Not an exposure-response model."""
    out = {"model": PRIMARY_MODEL}
    ex = _exposure_table()
    ae = D.a_ae()
    df = ex.merge(ae, on=["dose", "sched"])
    df.to_csv(RES / "er_A_trae_exposure_table.csv", index=False)
    covs = {"log dose": np.log(df.dose), "log Cavg,ss": np.log(df.Cavg_ss), "log Cmax,ss": np.log(df.Cmax_ss), "log Cmin,ss": np.log(df.Cmin_ss),
            "log dose intensity": np.log(df.intensity)}
    p0 = df.events.sum() / df.n.sum()
    ll_null = float(np.sum(df.events * np.log(p0) + (df.n - df.events) * np.log1p(-p0)))
    rows = []
    for nm, x in covs.items():
        ll, par = R.loglik_binomial_logit(x.values, df.events.values, df.n.values)
        rows.append(dict(covariate=nm, loglik=ll, delta_loglik_vs_null=ll - ll_null, aic=2 * 2 - 2 * ll, lr_p=float(stats.chi2.sf(2 * (ll - ll_null), 1)),
                         corr_with_log_dose=float(np.corrcoef(x, np.log(df.dose))[0, 1])))
    t = pd.DataFrame(rows)
    t["aic_null"] = 2 * 1 - 2 * ll_null
    t.to_csv(RES / "er_A_trae_covariate_comparison.csv", index=False)
    out["A_trae_covariate_spread_aic"] = float(t.aic.max() - t.aic.min())
    # dataset D: only two dose levels, so exposure ratios equal dose ratios and the slope per doubling of exposure equals the dose slope
    th = load_fit(PRIMARY_MODEL)["theta"]
    s10, s20 = K.steady_state_metrics(th, 10, 21), K.steady_state_metrics(th, 20, 21)
    out["D_exposure_ratio_20_over_10"] = {k_: s20[k_] / s10[k_] for k_ in ("Cmax_ss", "Cmin_ss", "Cavg_ss", "AUCtau_ss")}
    dump(out, "er_summary.json")
    log("[er] done")
