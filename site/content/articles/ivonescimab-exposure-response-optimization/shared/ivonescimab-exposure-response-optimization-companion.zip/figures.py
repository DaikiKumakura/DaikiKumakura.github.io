"""Figures for the ivonescimab note. Reads results/ and inputs/; writes figures/*.png (image text in English)."""
from __future__ import annotations

import json

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from matplotlib.patches import FancyArrowPatch, FancyBboxPatch, Rectangle

import ivo_data as D
import pkmodel as K
from analysis import REGIMENS, PRIMARY_MODEL, load_fit, theta_from_row

RES, FIG = D.RES, D.FIG
FIG.mkdir(exist_ok=True)
OI = dict(black="#000000", orange="#E69F00", sky="#56B4E9", green="#009E73", yellow="#F0E442", blue="#0072B2", verm="#D55E00", pink="#CC79A7", grey="#7f7f7f")
plt.rcParams.update({"font.size": 10, "axes.spines.top": False, "axes.spines.right": False, "figure.dpi": 150, "savefig.dpi": 200,
                     "axes.labelsize": 10, "legend.fontsize": 8.5, "axes.titlesize": 10.5, "axes.titleweight": "bold"})
MODEL_STYLE = {"1c": dict(ls="--", color=OI["orange"], label="1-compartment fit"), "2c": dict(ls="-", color=OI["blue"], label="2-compartment fit (primary)")}
FITS = {m: load_fit(m) for m in ("1c", "2c")}
PRIM = PRIMARY_MODEL


def save(fig, name):
    fig.tight_layout()
    fig.savefig(FIG / name, bbox_inches="tight")
    plt.close(fig)
    print("saved", name)


def box(ax, x, y, w, h, text, fc, fs=9, ec="k", ls="-"):
    ax.add_patch(FancyBboxPatch((x, y), w, h, boxstyle="round,pad=0.04", fc=fc, ec=ec, ls=ls, alpha=0.85))
    ax.text(x + w / 2, y + h / 2, text, ha="center", va="center", fontsize=fs)


def arrow(ax, a, b, txt="", fs=8.5, off=(0, 0.12)):
    ax.add_patch(FancyArrowPatch(a, b, arrowstyle="-|>", mutation_scale=11, lw=1.3, color="k"))
    if txt:
        ax.text((a[0] + b[0]) / 2 + off[0], (a[1] + b[1]) / 2 + off[1], txt, ha="center", fontsize=fs)


# ---------------------------------------------------------------------------------------------------------------
def fig1_structure():
    fig, ax = plt.subplots(figsize=(7.0, 6.2))
    ax.set_xlim(0, 10)
    ax.set_ylim(0, 11)
    ax.axis("off")
    ax.text(0.1, 10.6, "A. Mechanism (non-clinical context)", fontsize=10.5, fontweight="bold")
    box(ax, 0.2, 8.8, 2.6, 1.2, "PD-1 on T cell", OI["sky"])
    box(ax, 3.7, 8.8, 2.6, 1.2, "Ivonescimab\n(PD-1 x VEGF-A)", OI["yellow"])
    box(ax, 7.2, 8.8, 2.6, 1.2, "VEGF-A", OI["green"])
    arrow(ax, (3.7, 9.4), (2.8, 9.4))
    arrow(ax, (6.3, 9.4), (7.2, 9.4))
    ax.text(5.0, 8.3, "In vitro: PD-1 binding rises >18-fold with VEGF present\n(values not tabulated; not estimated here)", ha="center", fontsize=8.5, style="italic")
    ax.text(0.1, 7.4, "B. Linear PK model (calibrated in this note)", fontsize=10.5, fontweight="bold")
    box(ax, 0.2, 5.4, 2.4, 1.3, "Central\nV1 (L/kg)", OI["sky"])
    box(ax, 4.2, 5.4, 2.4, 1.3, "Peripheral\nV2 (L/kg)", OI["sky"], ls="--")
    box(ax, 7.4, 5.4, 2.4, 1.3, "Elimination\nCL (L/day/kg)", OI["orange"])
    ax.text(0.2, 7.0, "IV infusion, dose in mg/kg", fontsize=8.5)
    arrow(ax, (0.9, 6.95), (0.9, 6.7))
    arrow(ax, (2.6, 6.2), (4.2, 6.2), "Q")
    arrow(ax, (4.2, 5.8), (2.6, 5.8))
    arrow(ax, (2.6, 5.6), (2.6, 5.6))
    arrow(ax, (1.4, 5.4), (1.4, 4.9))
    ax.plot([1.4, 8.6, 8.6], [4.9, 4.9, 5.4], color="k", lw=1.3)
    ax.text(5.0, 4.95, "CL", ha="center", va="bottom", fontsize=8.5)
    ax.text(5.4, 4.45, "dashed box: second compartment, weakly identified (Figure 10)", ha="center", fontsize=8.5, style="italic")
    ax.text(0.1, 4.2, "C. Public aggregate observations linked to the model", fontsize=10.5, fontweight="bold")
    box(ax, 0.2, 2.5, 2.9, 1.3, "Group PK summaries\n(Table 3, trough means)\nused to calibrate", OI["sky"], fs=8.5)
    box(ax, 3.55, 2.5, 2.9, 1.3, "PD-1 occupancy\nVEGF % change\nused descriptively", OI["green"], fs=8.5)
    box(ax, 6.9, 2.5, 2.9, 1.3, "ORR, Grade 3+ TRAE\nBeta-Binomial\nby regimen where n exists", OI["pink"], fs=8.5)
    ax.text(5.0, 1.7, "Not linked: subject-level data, tissue VEGF, cooperative-binding parameters, regimen-level n for the Phase Ib/II regimens", ha="center", fontsize=8.5)
    ax.text(5.0, 1.1, "Model outputs: steady-state Cmax, Cmin, Cavg per regimen (typical subject + conditional scenarios)", ha="center", fontsize=8.5)
    save(fig, "fig1_model_structure.png")


# ---------------------------------------------------------------------------------------------------------------
def fig2_pk_groups():
    s = D.a_table3(True)
    tr = D.a_troughs()
    fig, axes = plt.subplots(3, 1, figsize=(6.4, 9.2))
    doses = np.array([3, 5, 10, 20, 30, 10, 20.0])
    for ax, (src, name, ylab) in zip(axes[:2], (("Cmax", "Cmax", "Cmax / dose (ug/mL per mg/kg)"), ("AUC0-∞", "AUC0-inf", "AUC0-inf / dose (day*ug/mL per mg/kg)"))):
        for sched, mk, col in (("Q2W", "o", OI["blue"]), ("Q3W", "s", OI["verm"])):
            g = s[(s.param == src) & (s.sched == sched)]
            y = g["mean"] / g.dose
            se = y * g.sd / g["mean"] / np.sqrt(g.n)
            ax.errorbar(g.dose, y, yerr=1.96 * se, fmt=mk, color=col, capsize=3, label=f"observed mean, {sched} cohorts (+/-1.96 SE)")
        for m in ("1c", "2c"):
            th = FITS[m]["theta"]
            xs = np.array([3.0, 30.0])
            if name == "Cmax":
                ys = [K.single_dose_metrics(th, 1.0, 14.0)["Cmax"]] * 2
            else:
                ys = [1.0 / th["CL"]] * 2
            ax.plot(xs, ys, **MODEL_STYLE[m])
        ax.set_xscale("log")
        ax.set_xlabel("Dose (mg/kg)")
        ax.set_ylabel(ylab)
        ax.set_xticks([3, 5, 10, 20, 30])
        ax.set_xticklabels(["3", "5", "10", "20", "30"])
    axes[0].set_title("Single-dose Cmax per dose")
    axes[1].set_title("Single-dose AUC0-inf per dose")
    axes[0].legend(loc="upper left", frameon=False)
    ax = axes[2]
    for sched, mk, col, day in (("Q2W", "o", OI["blue"], 15.0), ("Q3W", "s", OI["verm"], 22.0)):
        g = tr[(tr.sched == sched) & (tr.day == day)]
        y = g["mean"] / g.dose
        n = np.array([D.a_cohort_n()[D.gkey(d, sched)] for d in g.dose])
        se = y * g.sd / g["mean"] / np.sqrt(n)
        ax.errorbar(g.dose, y, yerr=1.96 * se, fmt=mk, color=col, capsize=3, label=f"observed trough, {sched} (day {int(day)} predose)")
    for m in ("1c", "2c"):
        th = FITS[m]["theta"]
        for tau, ls in ((14.0, "-"), (21.0, ":")):
            ax.plot([3, 30], [K.single_dose_metrics(th, 1.0, tau)["Ctau"]] * 2, color=MODEL_STYLE[m]["color"], ls=ls,
                    label=f"{m} fit, tau = {int(tau)} d" if m == "2c" or True else None, lw=1.6)
    ax.set_xscale("log")
    ax.set_xticks([3, 5, 10, 20, 30])
    ax.set_xticklabels(["3", "5", "10", "20", "30"])
    ax.set_xlabel("Dose (mg/kg)")
    ax.set_ylabel("Trough after first dose / dose")
    ax.set_title("Concentration at the end of the first interval")
    ax.legend(loc="lower right", frameon=False, fontsize=7)
    ax.set_ylim(1.0, 4.6)
    save(fig, "fig2_pk_dose_groups.png")


# ---------------------------------------------------------------------------------------------------------------
def fig3_accumulation_external():
    ss = pd.read_csv(RES / "pk_steady_state_check.csv")
    trc = pd.read_csv(RES / "pk_trough_check.csv")
    ext = pd.read_csv(RES / "pk_external_B.csv")
    tr = D.a_troughs()
    fig, axes = plt.subplots(3, 1, figsize=(6.4, 10.5))
    ax = axes[0]
    labels = {"Cmax_ss": "Cmax,ss", "Cmin_ss": "Cmin,ss", "AUCtau_ss": "AUC0-tau,ss", "Rac_AUC": "Rac (AUC)", "Rac_Cmax": "Rac (Cmax)"}
    for j, m in enumerate(("1c", "2c")):
        for i, k in enumerate(labels):
            x = ss[(ss.model == m) & (ss.metric == k)]
            ax.scatter(np.full(len(x), i + (j - 0.5) * 0.3), x.ratio_obs_pred, color=MODEL_STYLE[m]["color"], s=22,
                       label=MODEL_STYLE[m]["label"] if i == 0 else None, marker="o" if m == "2c" else "^")
    ax.axhline(1, color="k", lw=0.8)
    ax.set_xticks(range(len(labels)))
    ax.set_xticklabels(labels.values(), rotation=20)
    ax.set_yscale("log")
    ax.set_ylabel("Reported / predicted")
    ax.set_title("Steady-state NCA means versus prediction (7 cohorts each)")
    ax.legend(frameon=False, loc="upper right")
    ax = axes[1]
    for sched, col, dose in (("Q2W", OI["blue"], 20.0), ("Q3W", OI["verm"], 20.0)):
        g = tr[(tr.sched == sched) & (tr.dose == dose) & (tr.day > 1)]
        ax.errorbar(g.day, g["mean"], yerr=g.sd.fillna(0), fmt="o" if sched == "Q2W" else "s", color=col, capsize=2, alpha=0.8,
                    label=f"observed mean trough, 20 mg/kg {sched} (+/-SD)")
        tau = D.TAU[sched]
        days = np.arange(1 + tau, 480, tau)
        for m in ("1c", "2c"):
            th = FITS[m]["theta"]
            lam, A = K.micro_to_macro(th["CL"], th["V1"], th.get("Q", 0.0), th.get("V2", 1.0))
            pred = []
            for d in days:
                n = int(round((d - 1) / tau))
                pred.append(K.conc_schedule([d], 1.0 + tau * np.arange(n), [dose] * n, K.TINF_DEFAULT_H / 24, lam, A)[0])
            ax.plot(days, pred, color=MODEL_STYLE[m]["color"], ls="--" if m == "1c" else "-", lw=1.2 if sched == "Q3W" else 1.8, alpha=0.9)
    ax.set_xlabel("Study day (pre-dose sample)")
    ax.set_ylabel("Trough concentration (ug/mL)")
    ax.set_title("Trough time course, 20 mg/kg (solid 2-cmpt, dashed 1-cmpt)", fontsize=9.5)
    ax.legend(frameon=False, fontsize=8)
    ax = axes[2]
    lab = {"Cmax": "Cmax", "AUCinf": "AUC0-inf", "Cmax_ss": "Cmax,ss", "Cmin_ss": "Cmin,ss", "AUCtau_ss": "AUC0-tau,ss"}
    ex = ext[ext.metric.isin(lab) & (ext.dose >= 10)]
    for j, m in enumerate(("1c", "2c")):
        x = ex[ex.model == m]
        for i, k in enumerate(lab):
            xx = x[x.metric == k]
            ax.scatter(np.full(len(xx), i + (j - 0.5) * 0.3), xx.ratio_obs_pred, color=MODEL_STYLE[m]["color"], s=26, marker="o" if m == "2c" else "^")
    ax.axhline(1, color="k", lw=0.8)
    ax.set_xticks(range(len(lab)))
    ax.set_xticklabels(lab.values(), rotation=20)
    ax.set_ylabel("Phase Ia reported / predicted")
    ax.set_title("Held-out comparison: Phase Ia study (10, 20, 30 mg/kg Q2W)")
    save(fig, "fig3_accumulation_external.png")


# ---------------------------------------------------------------------------------------------------------------
def fig4_pd1_occupancy():
    t5 = pd.read_csv(RES / "ro_table5_with_predicted_conc.csv")
    pts = pd.read_csv(RES / "ro_fit_points.csv")
    prof = pd.read_csv(RES / "ro_ec50_profile.csv")
    ro = json.loads((RES / "ro_summary.json").read_text())
    g = pd.read_csv(RES / "ro_group_summary.csv")
    fig, axes = plt.subplots(3, 1, figsize=(6.4, 10.2))
    ax = axes[0]
    x = np.arange(len(g))
    ax.errorbar(x - 0.15, g.baseline, yerr=g.baseline_sd, fmt="o", color=OI["grey"], capsize=3, label="Day 1 pre-dose (baseline), mean +/-SD")
    ax.errorbar(x + 0.15, g.day8, yerr=None, fmt="s", color=OI["blue"], label="Day 8 (group mean)")
    ax.errorbar(x + 0.0, g.predose_mean_over_times, yerr=None, fmt="D", color=OI["verm"], label="Pre-dose, mean of time-point means")
    ax.set_xticks(x)
    ax.set_xticklabels([f"{d:g}\n{s}" for d, s in zip(g.dose, g.sched)])
    ax.set_xlabel("Cohort (mg/kg and schedule)")
    ax.set_ylabel("PD-1 occupancy (%)")
    ax.set_ylim(0, 112)
    ax.set_title("Baseline offset versus post-dose occupancy")
    ax.legend(frameon=False, loc="center right", fontsize=8)
    ax = axes[1]
    colors = {k: c for k, c in zip(sorted(t5.key.unique(), key=lambda s: (s.split("_")[1], float(s.split("_")[0]))), [OI["sky"], OI["blue"], OI["green"], OI["orange"], OI["verm"], OI["pink"], OI["black"]])}
    for k, gg in pts.groupby("key"):
        ax.scatter(gg.conc, gg["mean"], s=16, color=colors[k], alpha=0.8, label=k.replace("_", " mg/kg "))
    f = ro["binding_fit_by_se_floor"]["3.0"]
    cc = np.logspace(-2.5, 3, 300)
    ax.plot(cc, 0 + (f["b_best"]) * cc / (cc + f["ec50_best"]), color="k", lw=1.2, label="Emax curve, no offset (illustration of fit)")
    kd = ro["kd_PD1_equiv_ug_ml_range"]
    ax.axvspan(kd[0], kd[1], color=OI["yellow"], alpha=0.6, label="in vitro KD (PD-1), assumed 150-200 kDa")
    ax.set_xscale("log")
    ax.set_xlim(10 ** -2.5, 10 ** 3)
    ax.set_xlabel("Predicted typical-subject concentration (ug/mL)")
    ax.set_ylabel("PD-1 occupancy, group mean (%)")
    ax.set_title("Group-time means versus model-predicted concentration (n = %d points)" % len(pts))
    ax.legend(frameon=False, fontsize=7, ncol=2, loc="lower right")
    ax = axes[2]
    for floor, col in zip((1.0, 3.0, 5.0), (OI["orange"], OI["blue"], OI["verm"])):
        p = prof[prof.floor == floor]
        ax.plot(p.ec50_ug_ml, np.clip(p.delta_chi2, 0, 30), color=col, label=f"SE floor {floor:g} points")
    ax.axhline(3.84, color="k", ls=":", lw=1)
    ax.axvspan(kd[0], kd[1], color=OI["yellow"], alpha=0.6)
    ax.set_xscale("log")
    ax.set_xlabel("EC50 (ug/mL)")
    ax.set_ylabel("Profile delta chi-square")
    ax.set_title("EC50 profile: the upper bound is stable, the lower bound is not")
    ax.legend(frameon=False)
    save(fig, "fig5_pd1_occupancy.png")


def fig5_vegf():
    t = pd.read_csv(RES / "vegf_table5_with_predicted_conc.csv")
    g = pd.read_csv(RES / "vegf_group_summary.csv")
    pts = pd.read_csv(RES / "vegf_predose_points.csv")
    vg = json.loads((RES / "vegf_summary.json").read_text())
    fig, axes = plt.subplots(2, 1, figsize=(6.4, 7.8))
    ax = axes[0]
    x = np.arange(len(g))
    ax.vlines(x - 0.12, g.eoi_min, g.eoi_max, color=OI["blue"], lw=2)
    ax.scatter(x - 0.12, g.eoi_mean, color=OI["blue"], zorder=3, label="End of infusion: mean (bar = range of time-point means)")
    ax.vlines(x + 0.12, g.predose_min, g.predose_max, color=OI["verm"], lw=2)
    ax.scatter(x + 0.12, g.predose_mean, color=OI["verm"], marker="s", zorder=3, label="Pre-dose: mean (bar = range of time-point means)")
    ax.axhline(0, color="k", lw=0.8)
    ax.set_xticks(x)
    ax.set_xticklabels([f"{d:g}\n{s}" for d, s in zip(g.dose, g.sched)])
    ax.set_xlabel("Cohort (mg/kg and schedule)")
    ax.set_ylabel("Serum VEGF, change from baseline (%)")
    ax.set_title("VEGF change (free vs total not stated)")
    ax.legend(frameon=False, fontsize=8, loc="upper left")
    ax = axes[1]
    for sched, mk, col in (("Q2W", "o", OI["blue"]), ("Q3W", "s", OI["verm"])):
        p = pts[pts.sched == sched]
        ax.scatter(p.conc, p["mean"], marker=mk, color=col, alpha=0.75, s=22, label=f"pre-dose group-time means, {sched}")
    xs = np.linspace(np.log10(pts.conc.min()), np.log10(pts.conc.max()), 50)
    b = np.polyfit(np.log10(pts.conc), pts["mean"], 1)
    ax.plot(10 ** xs, np.polyval(b, xs), color="k", lw=1.2, label="OLS line")
    ax.axhline(0, color="k", lw=0.6)
    ax.set_xscale("log")
    ax.set_xlabel("Predicted pre-dose concentration (ug/mL, typical subject)")
    ax.set_ylabel("VEGF change (%)")
    s_ = vg["predose_slope_pp_per_decade"]
    ax.set_title(f"Slope {s_['est']:.1f} points per decade (cluster-bootstrap 95% interval {s_['lo']:.0f} to {s_['hi']:.0f})", fontsize=9.5)
    ax.legend(frameon=False, fontsize=8)
    save(fig, "fig6_vegf_change.png")


# ---------------------------------------------------------------------------------------------------------------
def virtual_profiles(model, regimen, n=600, cv=(0.25, 0.20, 0.0), seed=D.SEED):
    th0 = FITS[model]["theta"]
    rng = np.random.default_rng(seed)
    s_cl, s_v = np.sqrt(np.log1p(cv[0] ** 2)), np.sqrt(np.log1p(cv[1] ** 2))
    eta = rng.multivariate_normal([0, 0], [[s_cl ** 2, cv[2] * s_cl * s_v], [cv[2] * s_cl * s_v, s_v ** 2]], size=n)
    dose, tau = REGIMENS[regimen]
    t = np.linspace(0, 42, 841)
    tt = np.mod(t, tau)
    out = []
    for e in eta:
        th = dict(th0)
        th["CL"], th["V1"] = th0["CL"] * np.exp(e[0]), th0["V1"] * np.exp(e[1])
        lam, A = K.micro_to_macro(th["CL"], th["V1"], th.get("Q", 0.0), th.get("V2", 1.0))
        out.append(K.conc_steady_state(tt, dose, tau, K.TINF_DEFAULT_H / 24, lam, A))
    return t, np.array(out)


def fig6_regimen_profiles():
    prof = pd.read_csv(RES / "regimen_profiles_42d.csv")
    fig, axes = plt.subplots(3, 1, figsize=(6.4, 10.5))
    ax = axes[0]
    for name, col in (("20 mg/kg Q2W", OI["blue"]), ("30 mg/kg Q3W", OI["verm"])):
        t, V = virtual_profiles(PRIM, name)
        lo, hi = np.percentile(V, [5, 95], axis=0)
        ax.fill_between(t, lo, hi, color=col, alpha=0.18, lw=0)
        ax.plot(prof.day, prof[f"{PRIM}|{name}"], color=col, lw=2, label=f"{name}")
        ax.plot(prof.day, prof[f"1c|{name}"], color=col, lw=1, ls="--")
    ax.set_xlabel("Day within a 42-day steady-state window")
    ax.set_ylabel("Concentration (ug/mL)")
    ax.set_title("Equal dose intensity (10 mg/kg/week): conditional scenario")
    ax.legend(frameon=False, fontsize=8, loc="upper right")
    ax.text(0.01, 0.98, "dashed: 1-compartment typical subject\nband: CV(CL) 25%, CV(V1) 20%, scenario input", transform=ax.transAxes, va="top", fontsize=8)
    ax = axes[1]
    for k, (m, ls) in enumerate((("2c", "-"), ("1c", "--"))):
        v = pd.read_csv(RES / f"virtual_subjects_scenario2_{m}.csv")
        ax.hist(v.cmax_q3w / v.cmax_q2w, bins=40, alpha=0.5, color=OI["blue"] if m == "2c" else OI["orange"], label=f"{m}: Cmax,ss ratio")
    ax.set_xlabel("Paired ratio, 30 mg/kg Q3W / 20 mg/kg Q2W, Cmax,ss")
    ax.set_ylabel("Virtual subjects (n = 4000)")
    ax.set_title("Paired Cmax,ss ratio on the same virtual subjects")
    ax.legend(frameon=False)
    ax = axes[2]
    for m in ("2c", "1c"):
        v = pd.read_csv(RES / f"virtual_subjects_scenario2_{m}.csv")
        ax.hist(v.cmin_q3w / v.cmin_q2w, bins=40, alpha=0.5, color=OI["blue"] if m == "2c" else OI["orange"], label=f"{m}: Cmin,ss ratio")
    ax.set_xlabel("Paired ratio, 30 mg/kg Q3W / 20 mg/kg Q2W, Cmin,ss")
    ax.set_ylabel("Virtual subjects (n = 4000)")
    ax.set_title("Paired Cmin,ss ratio: depends on model structure")
    ax.legend(frameon=False)
    save(fig, "fig4_regimen_profiles.png")


# ---------------------------------------------------------------------------------------------------------------
def interval_panel(ax, labels, mean, lo, hi, obs=None, colors=None, title=""):
    y = np.arange(len(labels))[::-1]
    mean, lo, hi = np.asarray(mean), np.asarray(lo), np.asarray(hi)
    obs = None if obs is None else np.asarray(obs)
    for i, (yy, m, l, h) in enumerate(zip(y, mean, lo, hi)):
        ax.plot([l, h], [yy, yy], color=colors[i] if colors else OI["blue"], lw=2.2)
        ax.scatter([m], [yy], color=colors[i] if colors else OI["blue"], zorder=3, s=30)
        if obs is not None:
            ax.scatter([obs[i]], [yy], marker="x", color="k", zorder=4, s=28)
    ax.set_yticks(y)
    ax.set_yticklabels(labels, fontsize=8.5)
    ax.set_xlim(0, 1)
    ax.set_title(title, fontsize=10)


def fig7_orr():
    p = pd.read_csv(RES / "rates_D_orr_posteriors.csv")
    p = p[p.prior.str.startswith("Weak")]
    df = pd.read_csv(RES / "rates_D_orr_diff_by_cohort.csv")
    df = df[df.prior.str.startswith("Weak")]
    rs = json.loads((RES / "rates_summary.json").read_text())["D_orr_common_logOR_20_vs_10"][1]
    c5 = D.c_orr_percent()
    fig, axes = plt.subplots(3, 1, figsize=(6.4, 10.5), gridspec_kw=dict(height_ratios=[1.35, 1.0, 0.9]))
    ax = axes[0]
    labels = [f"Cohort {r.cohort}: {r.dose:g} mg/kg Q3W (n={r.n})" for r in p.itertuples()]
    interval_panel(ax, labels, p.post_mean, p.post_lo, p.post_hi, obs=p.observed, colors=[OI["sky"] if d == 10 else OI["blue"] for d in p.dose],
                   title="Dataset D (+chemotherapy): ORR posterior mean and 95% CrI, x = observed")
    ax.set_xlabel("Objective response rate")
    ax = axes[1]
    y = np.arange(3)[::-1]
    for yy, r in zip(y, df.itertuples()):
        ax.plot([r.diff_lo, r.diff_hi], [yy, yy], color=OI["green"], lw=2.2)
        ax.scatter([r.diff_mean], [yy], color=OI["green"], s=30, zorder=3)
    ax.axvline(0, color="k", lw=0.8)
    ax.axvspan(-0.1, 0.1, color=OI["grey"], alpha=0.15)
    ax.set_yticks(y)
    ax.set_yticklabels([f"Cohort {c}" for c in df.cohort])
    ax.set_xlabel(f"ORR difference, 20 minus 10 mg/kg (grey: +/-10 percentage points)\nCommon log OR per doubling: median {rs['median']:.2f} (95% CrI {rs['lo']:.2f} to {rs['hi']:.2f})", fontsize=9)
    ax.set_title("Posterior mean and 95% CrI of the ORR difference by cohort", fontsize=9.5)
    ax.set_xlim(-0.6, 0.6)
    ax = axes[2]
    y = np.arange(len(c5))[::-1]
    ax.scatter(c5.percent / 100, y, color=OI["verm"], s=40)
    for yy, r in zip(y, c5.itertuples()):
        ax.text(r.percent / 100 + 0.03, yy, f"{r.percent:.1f}% (n not available)", va="center", fontsize=8.5)
    ax.set_yticks(y)
    ax.set_yticklabels([r.regimen.replace(" ", " mg/kg ") for r in c5.itertuples()])
    ax.set_xlim(0, 1.15)
    ax.set_xlabel("ORR in the abstract (PD-L1+, first line, n = 67 in total, no intervals)")
    ax.set_title("HARMONi-5 (AK112-202, non-randomised cohorts): abstract percentages only", fontsize=9.5)
    save(fig, "fig8_orr_intervals.png")


def fig8_trae():
    a = pd.read_csv(RES / "rates_A_trae_posteriors.csv")
    d = pd.read_csv(RES / "rates_D_trae_posteriors.csv")
    e = pd.read_csv(RES / "rates_phase3_trae_posteriors.csv")
    pr = lambda x: x[x.prior.str.startswith("Weak")]
    a, d, e = pr(a), pr(d), pr(e)
    fig, axes = plt.subplots(3, 1, figsize=(6.4, 10.0), gridspec_kw=dict(height_ratios=[1.3, 0.7, 1.0]))
    interval_panel(axes[0], [f"{r.dose:g} mg/kg {r.cohort} ({r.events}/{r.n})" for r in a.itertuples()], a.post_mean, a.post_lo, a.post_hi, obs=a.observed,
                   colors=[OI["blue"] if c == "Q2W" else OI["verm"] for c in a.cohort], title="Dataset A (monotherapy, Phase I): Grade 3+ TRAE")
    interval_panel(axes[1], [f"{r.dose:g} mg/kg Q3W + chemo ({r.events}/{r.n})" for r in d.itertuples()], d.post_mean, d.post_lo, d.post_hi, obs=d.observed,
                   colors=[OI["sky"], OI["blue"]], title="Dataset D (chemotherapy combination, cohorts pooled)")
    interval_panel(axes[2], [f"{r.dataset.split()[0]}: {r.cohort[:34]}" for r in e.itertuples()], e.post_mean, e.post_lo, e.post_hi, obs=e.observed,
                   colors=[OI["green"], OI["grey"], OI["green"], OI["grey"]], title="Phase III context (comparator trials, not dose comparisons)")
    for ax in axes:
        ax.set_xlabel("Proportion with Grade 3+ TRAE (95% CrI; x = observed)", fontsize=9)
    axes[2].set_xlim(0, 1)
    save(fig, "fig9_trae_intervals.png")


# ---------------------------------------------------------------------------------------------------------------
def fig9_sensitivity():
    df = pd.read_csv(RES / "sens_regimen_ordering.csv")
    df = df[df.tinf_h == 1.5]
    rat = pd.read_csv(RES / "sens_ratio_30Q3W_over_20Q2W.csv")
    reg = pd.read_csv(RES / "ratio_30Q3W_over_20Q2W_typical.csv")
    var = pd.read_csv(RES / "variability_scenarios_20Q2W_vs_30Q3W.csv")
    fig, axes = plt.subplots(2, 1, figsize=(6.4, 8.6))
    ax = axes[0]
    names = list(REGIMENS)
    cols = {"Cavg_ss": OI["black"], "Cmax_ss": OI["verm"], "Cmin_ss": OI["blue"]}
    mk = {"1c": "^", "2c": "o"}
    for j, (k, c) in enumerate(cols.items()):
        for i, m in enumerate(("1c", "2c")):
            for yi, n in enumerate(names):
                r = df[(df.model == m) & (df.regimen == n)][f"rank_{k}"].iloc[0]
                ax.scatter(r + (j - 1) * 0.1 + (i - 0.5) * 0.04, yi, color=c, marker=mk[m], s=36, facecolors=c if m == "2c" else "none")
    ax.set_yticks(range(len(names)))
    ax.set_yticklabels([n + (" (hypothetical)" if n.startswith("15") else "") for n in names], fontsize=8.5)
    ax.set_xticks([1, 2, 3, 4, 5])
    ax.set_xlabel("Rank (1 = highest exposure; ties share a rank)")
    ax.set_title("Ordering depends on the assumed driver (colour), not on model structure (marker)")
    from matplotlib.lines import Line2D
    ax.legend(handles=[Line2D([], [], color=c, marker="o", ls="", label=k.replace("_ss", ",ss")) for k, c in cols.items()] +
              [Line2D([], [], color="k", marker="o", ls="", label="2-cmpt"), Line2D([], [], color="k", marker="^", mfc="none", ls="", label="1-cmpt")],
              frameon=False, fontsize=8, loc="lower right")
    ax.invert_yaxis()
    ax = axes[1]
    xs = {"Cmax_ss": 0, "Cmin_ss": 1}
    for m, col, off in (("1c", OI["orange"], -0.12), ("2c", OI["blue"], 0.12)):
        for k in xs:
            r = reg[(reg.model == m) & (reg.metric == k)].iloc[0]
            ax.errorbar(xs[k] + off, r["median"], yerr=[[r["median"] - r["lo"]], [r["hi"] - r["median"]]], fmt="o", color=col, capsize=4,
                        label=f"{m}: parameter 95% CrI" if k == "Cmax_ss" else None)
            v = var[(var.model == m)]
            lo = v[f"ratio_{k}_p025"].min()
            hi = v[f"ratio_{k}_p975"].max()
            ax.plot([xs[k] + off + 0.05] * 2, [lo, hi], color=col, lw=5, alpha=0.3, solid_capstyle="butt",
                    label=f"{m}: 2.5-97.5% of virtual subjects, 4 scenarios" if k == "Cmax_ss" else None)
    ax.axhline(1, color="k", lw=0.8)
    ax.set_xticks([0, 1])
    ax.set_xticklabels(["Cmax,ss", "Cmin,ss"])
    ax.set_ylabel("30 mg/kg Q3W / 20 mg/kg Q2W")
    ax.set_title("Same weekly dose intensity, different exposure shape")
    ax.legend(frameon=False, fontsize=8, loc="center right")
    save(fig, "fig7_sensitivity_ordering.png")


def fig10_identifiability():
    pr = pd.read_csv(RES / "pk_profiles.csv")
    fits = json.loads((RES / "pk_fits.json").read_text())
    slope = pd.read_csv(RES / "rates_D_orr_slope_posterior.csv")
    a_slope = pd.read_csv(RES / "rates_A_trae_slope_posterior.csv")
    fig, axes = plt.subplots(3, 1, figsize=(6.4, 10.0))
    ax = axes[0]
    for p, col in (("Q", OI["blue"]), ("V2", OI["verm"])):
        x = pr[(pr.model == "2c") & (pr.param == p)]
        ax.plot(x.value / x.value[x.delta_nll.idxmin()], np.clip(x.delta_nll, 0, 12), color=col, label=f"{p} (2-cmpt)")
    ax.axhline(1.92, color="k", ls=":", lw=1)
    ax.set_xscale("log")
    ax.set_xlim(0.03, 30)
    ax.set_xlabel("Value relative to the best estimate")
    ax.set_ylabel("Profile delta log-likelihood")
    ax.set_title("Peripheral-compartment parameters: bounded, but only through the first-interval troughs", fontsize=9.5)
    ax.legend(frameon=False)
    ax = axes[1]
    ax.plot(slope.log_or, slope.density, color=OI["blue"], label="ORR, Dataset D (chemo combination, 20 vs 10 mg/kg Q3W)")
    ax.plot(a_slope.log_or_per_doubling, a_slope.density, color=OI["verm"], label="Grade 3+ TRAE, Dataset A (Q2W 3-30 mg/kg)")
    xs = np.linspace(-3, 3, 400)
    ax.plot(xs, np.exp(-0.5 * xs ** 2) / np.sqrt(2 * np.pi), color=OI["grey"], ls="--", label="prior N(0, 1)")
    ax.axvline(0, color="k", lw=0.8)
    ax.set_xlim(-2.5, 2.5)
    ax.set_xlabel("Log odds ratio per doubling of dose")
    ax.set_ylabel("Posterior density")
    ax.set_title("Dose slopes: intervals still span both directions", fontsize=9.5)
    ax.legend(frameon=False, fontsize=8)
    ax = axes[2]
    ec = pd.read_csv(RES / "ro_ec50_profile.csv")
    for floor, col in zip((1.0, 3.0, 5.0), (OI["orange"], OI["blue"], OI["verm"])):
        p = ec[ec.floor == floor]
        ax.plot(p.ec50_ug_ml, np.clip(p.delta_chi2, 0, 20), color=col, label=f"floor {floor:g}")
    ax.axhline(3.84, color="k", ls=":", lw=1)
    ax.set_xscale("log")
    ax.set_xlabel("PD-1 occupancy EC50 (ug/mL)")
    ax.set_ylabel("Profile delta chi-square")
    ax.set_title("Occupancy EC50 depends on the assumed assay noise floor", fontsize=9.5)
    ax.legend(frameon=False, title="SE floor (points)")
    save(fig, "fig10_identifiability.png")


def fig11_data_gaps():
    g = pd.read_csv(RES / "data_gap_matrix.csv")
    qs = list(dict.fromkeys(g.quantity))
    cols = list(dict.fromkeys(g.dataset))
    code = {"A": ("Available", OI["green"]), "P": ("Partial", OI["yellow"]), "N": ("Not available", OI["verm"]), "-": ("n/a", "#e5e5e5")}
    fig, ax = plt.subplots(figsize=(6.6, 6.4))
    for i, qn in enumerate(qs):
        for j, c in enumerate(cols):
            s = g[(g.quantity == qn) & (g.dataset == c)].status.iloc[0]
            ax.add_patch(Rectangle((j, len(qs) - 1 - i), 1, 1, fc=code[s][1], ec="white", alpha=0.85))
            ax.text(j + 0.5, len(qs) - 1 - i + 0.5, {"A": "yes", "P": "part", "N": "no", "-": ""}[s], ha="center", va="center", fontsize=8.5)
    ax.set_xlim(0, len(cols))
    ax.set_ylim(0, len(qs))
    ax.set_xticks(np.arange(len(cols)) + 0.5)
    ax.set_xticklabels(["A\nPhase I\nCancer Med", "B\nPhase Ia\nJITC", "C\nHARMONi-5\nabstract", "D\nPhase II\n+chemo", "E\nPhase III\nsources", "G\nnon-clinical\niScience"], fontsize=8)
    ax.set_yticks(np.arange(len(qs)) + 0.5)
    ax.set_yticklabels(qs[::-1], fontsize=8.5)
    ax.xaxis.tick_top()
    ax.spines[:].set_visible(False)
    ax.tick_params(length=0)
    save(fig, "fig11_data_gaps.png")


if __name__ == "__main__":
    for f in (fig1_structure, fig2_pk_groups, fig3_accumulation_external, fig4_pd1_occupancy, fig5_vegf, fig6_regimen_profiles, fig7_orr, fig8_trae,
              fig9_sensitivity, fig10_identifiability, fig11_data_gaps):
        f()
