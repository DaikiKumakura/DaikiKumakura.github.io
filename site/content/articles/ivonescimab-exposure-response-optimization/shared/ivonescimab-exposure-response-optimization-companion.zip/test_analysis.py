"""Numerical, structural and input-table checks (pytest). Run: python -m pytest test_analysis.py -q"""
import json

import numpy as np
import pandas as pd
import pytest
from scipy import stats
from scipy.special import expit

import ivo_data as D
import pkfit as F
import pkmodel as K
import rates as R

P2 = dict(CL=0.0065, V1=0.0506, Q=0.0061, V2=0.0427)   # illustrative values of the order of the fitted ones
P1 = dict(CL=0.0063, V1=0.0525)
TINF = 1.5 / 24


def test_unit_consistency_cmax_and_auc():
    # bolus-like limit: Cmax -> dose / V1 (mg/kg per L/kg = mg/L = ug/mL); AUC_inf = dose / CL (mg/kg per L/day/kg)
    m = K.single_dose_metrics(P1, 10.0, 21.0, Tinf_h=1e-4)
    assert m["Cmax"] == pytest.approx(10.0 / P1["V1"], rel=1e-3)
    assert m["AUCinf"] == pytest.approx(10.0 / P1["CL"], rel=1e-12)
    # per-kg clearance times a median body weight reproduces the order of magnitude of the reported CL (L/day)
    cl_l_day = P1["CL"] * 58.0
    assert 0.3 < cl_l_day < 0.5


def test_fitted_clearance_close_to_table3_when_scaled_by_body_weight():
    p = D.RES / "pk_cl_unit_check.csv"
    if not p.exists():
        pytest.skip("run analysis.py pk first")
    d = pd.read_csv(p)
    r = d.cl_fit_L_day_at_median_bw / d.cl_table3
    assert r.between(0.7, 1.35).all()          # per group: -25% to +23% observed for 2c
    for m in ("1c", "2c"):
        g = np.exp(np.log(r[d.model == m]).mean())
        assert 0.85 < g < 1.15                 # geometric mean close to 1: no unit error


def test_zero_dose_gives_zero_everywhere():
    lam, A = K.micro_to_macro(**P2)
    t = np.array([0.0, 1.0, 14.0, 200.0])
    assert np.all(K.conc_schedule(t, [0.0, 14.0], [0.0, 0.0], TINF, lam, A) == 0.0)
    assert np.all(K.conc_steady_state(t[:3], 0.0, 14.0, TINF, lam, A) == 0.0)
    assert K.steady_state_metrics(P2, 0.0, 14.0)["Cmax_ss"] == 0.0


def test_positivity_and_monotone_decay_after_infusion():
    lam, A = K.micro_to_macro(**P2)
    t = np.linspace(0, 60, 1201)
    c = K.conc_schedule(t, [0.0, 14.0, 28.0], [20.0] * 3, TINF, lam, A)
    assert (c >= 0).all()
    i = np.searchsorted(t, 28.0 + 0.1)
    assert (np.diff(c[i:]) < 1e-12).all()


def test_mass_balance_amounts_and_auc_identity():
    times, doses = [0.0, 14.0, 28.0], [20.0, 20.0, 20.0]
    t_eval = np.array([0.0, 100.0, 400.0])
    y = K.simulate_ode(P2, times, doses, TINF, t_eval)
    # all drug is in central + peripheral + eliminated; at late time almost everything is eliminated
    assert y[1].sum() == pytest.approx(sum(doses), rel=1e-6)
    assert y[2, 2] == pytest.approx(sum(doses), rel=1e-6)
    # eliminated amount = CL * AUC for the central concentration
    lam, A = K.micro_to_macro(**P2)
    t = np.linspace(0, 400, 80001)
    c = K.conc_schedule(t, times, doses, TINF, lam, A)
    auc = np.trapezoid(c, t)
    assert P2["CL"] * auc == pytest.approx(sum(doses), rel=2e-3)


def test_analytic_matches_ode_single_and_multiple_dosing():
    times = [0.0, 14.0, 28.0, 42.0]
    doses = [20.0] * 4
    t_eval = np.array([0.05, 0.5, 5.0, 13.9, 28.0 + TINF, 41.0, 60.0])
    y = K.simulate_ode(P2, times, doses, TINF, t_eval)
    lam, A = K.micro_to_macro(**P2)
    ana = K.conc_schedule(t_eval, times, doses, TINF, lam, A)
    assert np.allclose(y[:, 0] / P2["V1"], ana, rtol=1e-5, atol=1e-8)


@pytest.mark.parametrize("params", [P1, P2])
def test_equal_intensity_regimens_have_equal_mean_steady_state_exposure(params):
    """Linear PK: 20 mg/kg Q2W and 30 mg/kg Q3W give the same AUC over a common 42-day window (model-structure consequence)."""
    cav = []
    for dose, tau in ((20.0, 14.0), (30.0, 21.0)):
        # ODE reference: dose until steady state, integrate the last 42 days
        n = int(np.ceil(840.0 / tau))
        times = tau * np.arange(n)
        t_end = times[-1] + 42.0
        grid = np.linspace(times[-1], t_end, 8401)
        y = K.simulate_ode(params, times, [dose] * n, TINF, grid, rtol=1e-10, atol=1e-13)
        c = y[:, 0] / params["V1"]
        # mean concentration over the last dosing interval (one whole interval after the last dose; steady state after ~840 days)
        cav.append(np.trapezoid(c[: int(np.round(tau / 42.0 * 8400)) + 1], grid[: int(np.round(tau / 42.0 * 8400)) + 1]) / tau)
    assert cav[0] == pytest.approx(cav[1], rel=2e-3)
    # analytic: Cavg = intensity / CL
    assert K.steady_state_metrics(params, 20.0, 14.0)["Cavg_ss"] == pytest.approx(K.steady_state_metrics(params, 30.0, 21.0)["Cavg_ss"], rel=1e-12)
    w1 = K.window_average_ss(params, 20.0, 14.0, 42.0)
    w2 = K.window_average_ss(params, 30.0, 21.0, 42.0)
    assert w1 == pytest.approx(w2, rel=1e-6)
    assert w1 == pytest.approx((20.0 / 14.0) / params["CL"], rel=1e-5)


def test_steady_state_closed_form_matches_long_ode_run():
    n = 60
    times = 14.0 * np.arange(n)
    t_eval = times[-1] + np.array([TINF, 3.0, 13.99])
    y = K.simulate_ode(P2, times, [20.0] * n, TINF, t_eval)
    lam, A = K.micro_to_macro(**P2)
    ss = K.conc_steady_state(np.array([TINF, 3.0, 13.99]), 20.0, 14.0, TINF, lam, A)
    assert np.allclose(y[:, 0] / P2["V1"], ss, rtol=2e-4)


def test_step_size_independence_rk4_converges():
    times, doses = [0.0, 14.0], [20.0, 20.0]
    lam, A = K.micro_to_macro(**P2)
    ref = float(K.conc_schedule([20.0], times, doses, TINF, lam, A)[0])
    errs = []
    for dt in (TINF / 4, TINF / 8, TINF / 16):
        t, y = K.simulate_rk4(P2, times, doses, TINF, 20.0, dt)
        errs.append(abs(y[int(round(20.0 / dt)), 0] / P2["V1"] - ref))
    assert errs[2] < errs[1] < errs[0]
    assert errs[2] < 1e-4 * ref + 1e-9


def test_dose_proportionality_of_linear_model():
    a = K.steady_state_metrics(P2, 10.0, 21.0)
    b = K.steady_state_metrics(P2, 30.0, 21.0)
    for k in a:
        assert b[k] == pytest.approx(3.0 * a[k], rel=1e-12)


def test_fast_prediction_matches_slow_prediction():
    cal = F.build_cal_data()
    for r in cal.itertuples():
        slow = F.predict_metric(P2, r, 1.5) if r.metric != "thalf" else None
        fast = float(F.predict_vec(P2, r.metric, [r.dose], [r.tau], 1.5)[0])
        if slow is not None:
            assert fast == pytest.approx(slow, rel=1e-10)


def test_beta_binomial_closed_forms():
    k, n, pr = 13, 24, (2.0, 2.0)
    post = R.beta_post(k, n, pr)
    assert post.mean() == pytest.approx((pr[0] + k) / (pr[0] + pr[1] + n))
    a, b = pr[0] + k, pr[1] + n - k
    assert post.var() == pytest.approx(a * b / ((a + b) ** 2 * (a + b + 1)))
    lo, hi = R.cred_interval(post)
    assert post.cdf(hi) - post.cdf(lo) == pytest.approx(0.95)
    # difference of two Beta posteriors: Monte Carlo mean and sd against closed form
    d = R.diff_posterior(10, 19, 13, 24, pr, n_draw=400_000)
    p1, p2 = R.beta_post(10, 19, pr), R.beta_post(13, 24, pr)
    assert d["diff_mean"] == pytest.approx(p2.mean() - p1.mean(), abs=2e-3)
    assert d["p_pos"] == pytest.approx(np.mean(p2.rvs(400_000, random_state=1) > p1.rvs(400_000, random_state=2)), abs=0.01)


def test_beta_binomial_matches_numerical_integration():
    k, n = 4, 10
    x = np.linspace(1e-6, 1 - 1e-6, 200001)
    dens = stats.binom.pmf(k, n, x) * stats.beta.pdf(x, 0.5, 0.5)
    dens /= np.trapezoid(dens, x)
    post = R.beta_post(k, n, (0.5, 0.5))
    assert np.trapezoid(x * dens, x) == pytest.approx(post.mean(), abs=1e-4)


def test_stratified_logistic_grid_normalised_and_centred_on_empirical_log_or():
    g, post, ll = R.stratified_logistic_slope([(500, 200, 500, 260)], prior_sd_slope=3.0)
    assert np.trapezoid(post, g) == pytest.approx(1.0, abs=1e-6)
    emp = np.log((260 / 240) / (200 / 300))
    assert R.summarise_grid(g, post)["mean"] == pytest.approx(emp, abs=0.08)


def test_reproducibility_with_fixed_seed():
    a = R.diff_posterior(9, 40, 13, 43, seed=D.SEED, n_draw=50000)
    b = R.diff_posterior(9, 40, 13, 43, seed=D.SEED, n_draw=50000)
    assert a == b
    cal = F.build_cal_data()
    f1 = F.fit(cal, "1c", n_starts=2)
    f2 = F.fit(cal, "1c", n_starts=2)
    assert f1["nll"] == f2["nll"]
    m1 = F.mcmc(cal, "1c", f1, 1.5, n_iter=1500, burn=500, thin=10)
    m2 = F.mcmc(cal, "1c", f1, 1.5, n_iter=1500, burn=500, thin=10)
    assert np.array_equal(m1["draws"], m2["draws"])


# ---------------------------------------------------------------------------------------------------------------
# input tables
def test_table3_n_and_internal_consistency():
    s = D.a_table3(True)
    n = s.groupby(["dose", "sched"]).n.first().to_dict()
    assert n == {(3.0, "Q2W"): 10, (5.0, "Q2W"): 10, (10.0, "Q2W"): 9, (20.0, "Q2W"): 12, (30.0, "Q2W"): 6, (10.0, "Q3W"): 6, (20.0, "Q3W"): 6}
    ss = D.a_table3(False)
    for dose, sched in D.A_GROUPS:
        g = ss[(ss.dose == dose) & (ss.sched == sched)].set_index("param")["mean"]
        assert g["AUC0-τ,ss"] / D.TAU[sched] == pytest.approx(g["Cavg"], rel=0.03)    # AUC_tau / tau = Cavg
    # CL (L/day) from Table 3 versus dose x median body weight / AUC0-inf
    bw = D.a_body_weight_median()
    for dose, sched in D.A_GROUPS:
        g = s[(s.dose == dose) & (s.sched == sched)].set_index("param")["mean"]
        implied = dose * bw[D.gkey(dose, sched)] / g["AUC0-∞"]
        assert implied == pytest.approx(g["CL"], rel=0.2)


def test_adverse_event_tables_are_consistent_with_printed_percentages():
    ae = D.a_ae()
    assert ae.events.sum() == 14 and ae.n.sum() == 59
    assert list(ae.events) == [3, 1, 2, 3, 2, 1, 2]
    d = D.d_trae()
    assert list(zip(d.events, d.n)) == [(9, 40), (13, 43)]
    assert round(100 * 9 / 40, 1) == 22.5 and round(100 * 13 / 43, 1) == 30.2
    o = D.d_orr()
    assert o.groupby("dose").n.sum().to_dict() == {10.0: 39, 20.0: 43}
    assert o.groupby("dose").events.sum().to_dict() == {10.0: 22, 20.0: 22}
    for r in o.itertuples():
        assert 0 <= r.events <= r.n


def test_harmoni5_regimen_counts_are_not_available_and_percentages_are_four():
    c = D.load_C()
    na = c[c.value.astype(str).str.contains("NOT AVAILABLE")]
    assert set(na.parameter) >= {"n per regimen", "responders per regimen", "ORR 95% CI"}
    assert len(D.c_orr_percent()) == 4


def test_phase3_counts_match_printed_percentages():
    e = D.e_trae_counts()
    pct = (100 * e.events / e.n).round(0).tolist()
    assert pct == [29.0, 16.0, 69.0, 59.0]


def test_hypothetical_regimen_intensities():
    import analysis as A
    inten = {k: v[0] / v[1] * 7 for k, v in A.REGIMENS.items()}
    assert inten["10 mg/kg Q3W"] == pytest.approx(10 / 3, rel=1e-12)
    assert inten["20 mg/kg Q3W"] == pytest.approx(20 / 3, rel=1e-12)
    assert inten["20 mg/kg Q2W"] == pytest.approx(10.0) and inten["30 mg/kg Q3W"] == pytest.approx(10.0)
    assert inten["15 mg/kg Q3W"] == pytest.approx(5.0)
