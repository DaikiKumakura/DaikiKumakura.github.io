"""Reference calculations for unequal well sizes and descriptive sensitivity."""
import unittest
from analysis import summarize_counts, leave_one_out, fractional_reduction


class ReferenceTests(unittest.TestCase):
    def test_unequal_size_estimands(self):
        r = summarize_counts([{'retained_cells':10,'target_cells':10}, {'retained_cells':90,'target_cells':0}])
        self.assertEqual(r['well_mean'], .5)
        self.assertEqual(r['cell_weighted'], .1)

    def test_sample_sd(self):
        r = summarize_counts([{'retained_cells':10,'target_cells':0}, {'retained_cells':10,'target_cells':10}])
        self.assertAlmostEqual(r['well_sd'], 2 ** -.5)

    def test_leave_one_out(self):
        r = leave_one_out([.1,.2,.3])
        self.assertAlmostEqual(r['loo_min'], .15)
        self.assertAlmostEqual(r['loo_max'], .25)

    def test_zero_target_retained(self):
        r = summarize_counts([{'retained_cells':10,'target_cells':0}, {'retained_cells':5,'target_cells':0}])
        self.assertEqual(r['well_mean'],0)
        self.assertEqual(r['well_sd'],0)

    def test_invalid_counts(self):
        with self.assertRaises(ValueError):
            summarize_counts([{'retained_cells':10,'target_cells':11}] * 2)

    def test_invalid_sensitivity(self):
        with self.assertRaises(ValueError):
            leave_one_out([1.])

    def test_reported_update(self):
        self.assertAlmostEqual(fractional_reduction(.000597,.000487), .1842546063651591)
        with self.assertRaises(ValueError):
            fractional_reduction(0, .1)


if __name__ == '__main__':
    unittest.main()
