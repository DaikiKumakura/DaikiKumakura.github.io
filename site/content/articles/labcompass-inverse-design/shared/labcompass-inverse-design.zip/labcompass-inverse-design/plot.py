"""Original figures from extracted counts and published update summaries."""
from pathlib import Path
import csv
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

HERE = Path(__file__).resolve().parent
OUT = HERE / 'figures'
OUT.mkdir(exist_ok=True)


def read(name):
    with (HERE / name).open(encoding='utf-8') as f:
        return list(csv.DictReader(f))


summaries, wells, updates = read('results/design-summary.csv'), read('well-counts.csv'), read('results/update-summary.csv')
fig, axes = plt.subplots(2, 2, figsize=(10, 7.5))
for ax, target, title in zip(axes.flat, ['late_MgkPro','EryPro','HSCs','preProB'],
                             ['Megakaryocyte progenitors','Erythroid progenitors','Phenotypic HSCs','Pre-ProB']):
    rows = sorted([r for r in summaries if r['target'] == target], key=lambda r: {'low':0,'high_1':1,'high_2':2}[r['selection']])
    for x, r in enumerate(rows):
        sample = [w for w in wells if w['design'] == r['design']]
        values = [100*int(w['target_cells'])/int(w['retained_cells']) for w in sample]
        offsets = [(.16*(i/(len(values)-1)-.5)) for i in range(len(values))]
        color = '#166277' if r['selection'] == 'low' else '#a45b32'
        ax.scatter([x + off for off in offsets], values, color=color, alpha=.65, s=25)
        ax.errorbar(x, 100*float(r['well_mean']), yerr=100*float(r['well_sd']), fmt='D', color=color, capsize=5, markersize=6)
    ax.set_xticks(range(3), [f"{r['design']}\n{'Low' if r['selection']=='low' else 'High'} uncertainty\nn={r['n_wells']} wells" for r in rows], fontsize=9)
    ax.set_title(title + (' (Notebook roles)' if target == 'preProB' else ''), fontsize=12)
    ax.set_ylabel('Annotated target cells (%)')
    ax.grid(axis='y', alpha=.2)
    ymin, ymax = ax.get_ylim(); ax.set_ylim(min(0,ymin), ymax*1.07)
fig.text(.5,.015,'Processed subsample: dots = wells; diamonds = unweighted mean ± sample SD. Panel scales differ. Donors are not resolved.',ha='center',fontsize=9)
fig.tight_layout(rect=(0,.045,1,1));fig.savefig(OUT/'01-candidate-outcomes.png',dpi=180);plt.close(fig)

fig, axes = plt.subplots(1,2,figsize=(9,4.5))
for i,r in enumerate(updates):
    color = ['#166277','#a45b32'][i]
    label = f"Design {r['design']}"
    axes[0].plot([0,1],[100,100*float(r['uncertainty_after'])/float(r['uncertainty_before'])],marker='o',label=label,color=color)
    axes[1].plot([0,1],[float(r['mean_marker_r_before']),float(r['mean_marker_r_after'])],marker='o',label=label,color=color)
for ax in axes:
    ax.set_xticks([0,1],['Before update','After update'])
    ax.grid(alpha=.2);ax.legend(frameon=False)
axes[0].set_ylabel('Reported loss uncertainty (% of before)');axes[0].set_ylim(0,110)
axes[1].set_ylabel('Reported mean-marker Pearson r');axes[1].set_ylim(0,1)
fig.text(.5,.015,'Published model summaries (Supplementary Tables 13–14); arithmetic replot, no model retraining or inference.',ha='center',fontsize=9)
fig.tight_layout(rect=(0,.065,1,1));fig.savefig(OUT/'02-reported-update.png',dpi=180);plt.close(fig)
