# Recalculate the LabCompass Loop 2 diagnostic

Python 3.11+ is sufficient for analysis and tests. Figures additionally require matplotlib.

```text
python analysis.py
python -m unittest test_analysis.py
python plot.py
```

This archive contains original analysis and factual extracted inputs. It does not contain the paper PDF, third-party code, model checkpoints or full cell matrices. No LabCompass model was trained or executed.

`well-counts.csv`: counts of retained annotated cells and target cells per design, plate, well and replicate, extracted read-only from two public processed H5AD files. The source files are annotated and subsampled, not raw cytometry. They contain 999,995 retained cells across 13 designs; design 247 (55,555 cells) is outside the twelve lineage-directed candidates and is excluded. The selected inputs contain 944,440 cells in 67 wells. Designs 246 and 251 have 4 and 3 retained wells, respectively; other designs have 6. No missing wells are imputed. No missing cell labels were observed in the source files.

Both source files have experiment_id LPHO014, date 12-JUN-2026 and source_id pooled. The loop2p5 file contains additional designs rather than independent repetitions of the same designs. Donor identities and donor count cannot be resolved from this metadata. Wells are descriptive culture replicates, not independent donors. Counting cells does not create independent biological replication. No donor-level inference, significance test or confidence interval is computed.

`protocols.csv`: the twelve measured culture protocols in original units, constant within each design. The low/high selection labels are transcribed from the authors' experimental_results_analysis.ipynb (cell 32). The notebook labels design 245 high uncertainty and design 246 low, while the manuscript Loop 3 narrative describes design 245 as low uncertainty. This unresolved discrepancy is disclosed in the article; Pre-ProB roles are notebook-specific and should not be interpreted as a confirmed uncertainty ordering. Target labels are the published annotations: late_MgkPro, EryPro, HSCs and preProB. They denote phenotypic groups, not functional stemness or mature blood-cell function. Different protocols alter multiple factors, so this comparison does not identify a single-factor causal effect.

The primary summary is the arithmetic mean of per-well target fractions, with sample SD and a leave-one-well-out range. The cell-weighted proportion is also saved; these estimands differ if retained well sizes differ. Neither retained cell counts nor fractions estimate absolute cell yield. They do not reconstruct the paper's complete raw measurements or guarantee identical published percentages.

`reported-update.csv`: two reported model-update summaries manually transcribed from Supplementary Tables 13 and 14 on PDF page 79. The code computes relative reduction 1 - after/before in reported loss uncertainty and reproduces the arithmetic average of the two mean-marker correlations. These summaries belong to the published forward models; they are not our own model results or independent confirmation. The reported predictive uncertainty is distinct from the observed well SD. A decline in this uncertainty does not by itself prove calibration or discovery of a better recipe.

The audit is exploratory and was defined after seeing the public data structure. It addresses measured outcomes of selected designs and a separate published model update. It does not reproduce all filtering, the exact identities of generated samples, independent optimality, comparison to random acquisition, clinical utility, lineage tracking or a complete active-learning benchmark.

Sources: Paulas-Condori et al., *Generative inverse design steers human hematopoietic cell fate in vitro*, bioRxiv version 1 posted 2026-10-09, DOI https://doi.org/10.64898/2026.10.07.756550 ; public data https://huggingface.co/datasets/theislab/LabCompass (CC BY 4.0); official analysis https://github.com/theislab/LabCompass-reproducibility . Pinned revision, source-file hashes and input hashes are recorded in input-provenance.json. Original scripts and documentation are MIT licensed. Extracted data retain source attribution and license; no third-party software rights are granted by the MIT license.
