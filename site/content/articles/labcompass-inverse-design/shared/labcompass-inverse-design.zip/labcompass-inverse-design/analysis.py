"""Descriptive recalculation of published annotated wells and reported model updates."""
from pathlib import Path
import csv
import json
import math
import statistics

HERE = Path(__file__).resolve().parent


def summarize_counts(rows):
    if len(rows) < 2:
        raise ValueError('At least two wells are needed for descriptive dispersion')
    values = []
    for r in rows:
        n, k = int(r['retained_cells']), int(r['target_cells'])
        if not 0 <= k <= n or n <= 0:
            raise ValueError('Invalid counts')
        values.append(k / n)
    return {'n_wells': len(values), 'retained_cells': sum(int(r['retained_cells']) for r in rows),
            'target_cells': sum(int(r['target_cells']) for r in rows),
            'well_mean': statistics.mean(values), 'well_sd': statistics.stdev(values),
            'well_min': min(values), 'well_max': max(values),
            'cell_weighted': sum(int(r['target_cells']) for r in rows) / sum(int(r['retained_cells']) for r in rows),
            **leave_one_out(values)}


def leave_one_out(values):
    if len(values) < 2 or any(not math.isfinite(x) for x in values):
        raise ValueError('Invalid sensitivity input')
    means = [(sum(values) - x) / (len(values) - 1) for x in values]
    return {'loo_min': min(means), 'loo_max': max(means)}


def fractional_reduction(before, after):
    if not (math.isfinite(before) and math.isfinite(after) and before > 0 and after >= 0):
        raise ValueError('Invalid uncertainty')
    return 1 - after / before


def read(name):
    with (HERE / name).open(encoding='utf-8', newline='') as f:
        return list(csv.DictReader(f))


def save(name, rows):
    with (HERE / 'results' / name).open('w', encoding='utf-8', newline='') as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0])); w.writeheader(); w.writerows(rows)


def main():
    wells, protocols, updates = read('well-counts.csv'), read('protocols.csv'), read('reported-update.csv')
    assert len(wells) == 67 and len(protocols) == 12 and len(updates) == 2
    keys = [(r['design'], r['plate'], r['well']) for r in wells]
    assert len(keys) == len(set(keys))
    summaries = []
    for p in protocols:
        selected = [r for r in wells if r['design'] == p['design']]
        assert selected and all(r['target'] == p['target'] and r['selection'] == p['selection'] for r in selected)
        summaries.append({k:p[k] for k in ['design', 'target', 'selection']} | summarize_counts(selected))
    update_results = []
    for r in updates:
        before, after = float(r['uncertainty_before']), float(r['uncertainty_after'])
        update_results.append({'design': r['design'], 'target': r['target'],
                               'uncertainty_before': before, 'uncertainty_after': after,
                               'uncertainty_relative_reduction': fractional_reduction(before, after),
                               'mean_marker_r_before': float(r['mean_marker_r_before']),
                               'mean_marker_r_after': float(r['mean_marker_r_after']),
                               'sd_marker_r_before': float(r['sd_marker_r_before']),
                               'sd_marker_r_after': float(r['sd_marker_r_after'])})
    result = {'selected_designs': 12, 'selected_wells': 67,
              'retained_cells': sum(int(r['retained_cells']) for r in wells),
              'n_wells_by_design': {r['design']:r['n_wells'] for r in summaries},
              'mean_reported_marker_r_before': statistics.mean(r['mean_marker_r_before'] for r in update_results),
              'mean_reported_marker_r_after': statistics.mean(r['mean_marker_r_after'] for r in update_results),
              'scope': 'Exploratory arithmetic on annotated subsampled wells from one pooled source collection. SD and leave-one-well-out ranges are descriptive, not donor uncertainty. Published model updates are transcribed summaries, not rerun inference or independent confirmation.'}
    (HERE / 'results').mkdir(exist_ok=True)
    save('design-summary.csv', summaries)
    save('update-summary.csv', update_results)
    (HERE / 'results/summary.json').write_text(json.dumps(result, indent=2) + '\n', encoding='utf-8')
    print(json.dumps(result, indent=2))


if __name__ == '__main__':
    main()
