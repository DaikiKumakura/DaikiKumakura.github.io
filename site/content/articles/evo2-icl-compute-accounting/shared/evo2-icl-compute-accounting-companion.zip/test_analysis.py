import numpy as np

import analysis as an


def test_samples_needed():
    assert abs(an.samples_needed(0.0014) - 64 / 0.0014) < 1e-9


def test_breakeven_matches_equal_cost_point():
    c_icl, s = an.CAS["h_icl"] / an.LIB, 19.0
    n = an.breakeven_n(881.0, c_icl, s / an.LIB)
    assert abs(c_icl * n - (881.0 + s / an.LIB * n)) < 1e-6
    assert 900 < n < 920


def test_no_breakeven_when_icl_marginal_cost_is_lower():
    assert np.isinf(an.breakeven_n(100.0, 0.5, 1.0))


def test_phage_decomposition_adds_up_and_sample_ratio():
    ph = an.phage_table()
    assert np.allclose(ph.ft_fixed_hours_implied + ph.ft_sampling_hours_implied, ph.ft_total_hours)
    assert abs(ph.sample_ratio_ft_over_icl.iloc[0] - (0.0025 / 0.00015)) < 1e-9
