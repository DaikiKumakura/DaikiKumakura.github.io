# Compute accounting for genomic in-context learning: companion code

Arithmetic on compute times and pass rates reported in the Evo 2 in-context learning preprint (Brixi et al., bioRxiv 10.64898/2026.10.28.762643): cost per passing design, break-even library size, and a decomposition of the reported phage hours under an explicit assumption. No model is run; no sequences are involved.

- `analysis.py`: cost model and tables.
- `figures.py`: Figures 1 and 2.
- `test_analysis.py`: checks (`python -m pytest test_analysis.py`).
- `results/`: CSV outputs.

Requires Python 3 with numpy, pandas, matplotlib.
