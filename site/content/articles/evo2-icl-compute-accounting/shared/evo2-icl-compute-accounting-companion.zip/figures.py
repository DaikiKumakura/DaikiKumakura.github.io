"""Figure 1: Cas9-locus design, hours to reach a library of passing designs. Figure 2: phage genomes, decomposition of the reported hours under an assumption."""
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np

import analysis as an

ROOT = Path(__file__).resolve().parent
(ROOT / "figures").mkdir(exist_ok=True)
n = np.logspace(np.log10(32), 4.3, 200)
c_icl = an.CAS["h_icl"] / an.LIB
fig, ax = plt.subplots(figsize=(7.0, 4.2), dpi=150)
ax.plot(n, c_icl * n, color="#0072B2", lw=2, label="In-context learning (81 h per 64 passing designs)")
lo = an.CAS["h_ft_finetune"] + 0.0 * n
hi = an.CAS["h_ft_finetune"] + 40.0 / an.LIB * n
ax.fill_between(n, lo, hi, color="#D55E00", alpha=0.25, label="Fine-tuned: 881 h + sampling (0-40 h per 64 designs)")
ax.plot(n, an.CAS["h_ft_finetune"] + 19.0 / an.LIB * n, color="#D55E00", lw=2, label="Fine-tuned, sampling 19 h per 64 designs")
be = an.breakeven_n(an.CAS["h_ft_finetune"], c_icl, 19.0 / an.LIB)
ax.axvline(be, color="#555555", ls=":", lw=1)
ax.text(be * 1.05, 120, f"break-even ≈ {be:.0f} designs", fontsize=7, color="#555555")
ax.scatter([64, 64], [81, 900], color="black", zorder=5, s=18)
ax.set_xscale("log")
ax.set_yscale("log")
ax.set_xlabel("Number of passing designs in the library")
ax.set_ylabel("H100 hours")
ax.legend(fontsize=7, loc="upper left")
fig.tight_layout()
fig.savefig(ROOT / "figures" / "01-cas9-hours-by-library-size.png")

ph = an.phage_table()
fig, ax = plt.subplots(figsize=(6.4, 3.8), dpi=150)
labels = ["ICL (reported)", "Fine-tuned, evo2-flash", "Fine-tuned, plain engine"]
icl = an.PHAGE["h_icl"]
r = ph[(ph.ft_per_sample_time_relative_to_icl == 1.0)]
samp = r.ft_sampling_hours_implied.values
fixed = r.ft_fixed_hours_implied.values
ax.bar([0], [icl], color="#0072B2")
ax.bar([1, 2], fixed, color="#D55E00", alpha=0.55, label="Fine-tuning and other fixed hours (implied)")
ax.bar([1, 2], samp, bottom=fixed, color="#D55E00", label="Sampling hours (implied, equal time per sample as ICL)")
ax.set_xticks([0, 1, 2])
ax.set_xticklabels(labels, fontsize=8)
ax.set_ylabel("GPU hours for 64 passing designs")
ax.legend(fontsize=7, loc="upper left")
fig.tight_layout()
fig.savefig(ROOT / "figures" / "02-phage-hours-decomposition.png")
