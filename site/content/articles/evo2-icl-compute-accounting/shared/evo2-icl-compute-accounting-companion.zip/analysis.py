"""How much of the reported compute saving of genomic in-context learning (ICL) comes from per-sample yield and how much from amortized fine-tuning cost?

Inputs are numbers reported in the Evo 2 ICL preprint (Brixi et al., bioRxiv 10.64898/2026.10.28.762643, version 1):
  CRISPR-Cas locus design: pooled per-sample pass rate 0.14% (ICL) vs 0.39% (fine-tuned Evo 1); a library of 64 passing designs cost about 81 H100 hours with ICL and
  about 900 H100 hours with fine-tuning, of which 881 H100 hours were the fine-tuning itself (sampling time for the fine-tuned model was estimated by the authors).
  Phage genomes: all-filter pass rate 0.25% (ICL) vs 0.015% (fine-tuned Evo 2); a library of 64 passing designs took about 2.1 GPU hours with ICL and about 200 GPU hours
  (162 with the evo2-flash engine) with fine-tuning including inference.
Cost model: total(N) = F + N * s / p / ... written per passing design: marginal cost c = (hours per sample) / (pass rate); total(N) = F + c * N.
Quantities the preprint does not state (per-sample times, the split of the 162-200 hours) are derived under explicit assumptions and labelled as such.
"""
from pathlib import Path

import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parent
OUT = ROOT / "results"
OUT.mkdir(exist_ok=True)

LIB = 64
CAS = dict(p_icl=0.0014, p_ft=0.0039, h_icl=81.0, h_ft_total=900.0, h_ft_finetune=881.0)
PHAGE = dict(p_icl=0.0025, p_ft=0.00015, h_icl=2.1, h_ft_total_flash=162.0, h_ft_total_plain=200.0)


def samples_needed(p: float, n: int = LIB) -> float:
    return n / p


def breakeven_n(fixed_ft: float, c_icl: float, c_ft: float) -> float:
    """Number of passing designs above which the fine-tuned route (fixed cost + marginal c_ft) is cheaper than ICL (marginal c_icl)."""
    return np.inf if c_icl <= c_ft else fixed_ft / (c_icl - c_ft)


def cas9_table(s_values=(0.0, 10.0, 19.0, 30.0, 40.0, 69.0, 80.0, 81.0)) -> pd.DataFrame:
    c_icl = CAS["h_icl"] / LIB
    rows = []
    for s in s_values:                                   # s: hours of sampling inside the "about 900" fine-tuned total (assumed range around 900 - 881 = 19)
        c_ft = s / LIB
        rows.append(dict(ft_sampling_hours=s, ft_fixed_hours=CAS["h_ft_finetune"], c_icl_per_design=c_icl, c_ft_per_design=c_ft,
                         breakeven_passing_designs=breakeven_n(CAS["h_ft_finetune"], c_icl, c_ft),
                         icl_samples_for_64=samples_needed(CAS["p_icl"]), ft_samples_for_64=samples_needed(CAS["p_ft"]),
                         implied_icl_hours_per_1000_samples=1000 * CAS["h_icl"] / samples_needed(CAS["p_icl"]),
                         implied_ft_hours_per_1000_samples=(1000 * s / samples_needed(CAS["p_ft"])) if s else 0.0))
    return pd.DataFrame(rows)


def phage_table() -> pd.DataFrame:
    n_icl, n_ft = samples_needed(PHAGE["p_icl"]), samples_needed(PHAGE["p_ft"])
    t_icl = PHAGE["h_icl"] / n_icl                      # hours per ICL sample (implied)
    rows = []
    for label, total in (("evo2-flash", PHAGE["h_ft_total_flash"]), ("plain engine", PHAGE["h_ft_total_plain"])):
        for rel in (1.0, 0.5, 0.1):                      # assumed per-sample time of the fine-tuned model relative to ICL
            samp = n_ft * t_icl * rel
            rows.append(dict(engine=label, ft_total_hours=total, ft_per_sample_time_relative_to_icl=rel, ft_sampling_hours_implied=samp,
                             ft_fixed_hours_implied=total - samp, c_icl_per_design=PHAGE["h_icl"] / LIB, c_ft_per_design=samp / LIB,
                             ft_cheaper_per_design_than_icl=bool(samp / LIB < PHAGE["h_icl"] / LIB)))
    df = pd.DataFrame(rows)
    df["samples_icl_for_64"], df["samples_ft_for_64"] = n_icl, n_ft
    df["sample_ratio_ft_over_icl"] = n_ft / n_icl
    df["time_ratio_ft_over_icl"] = df.ft_total_hours / PHAGE["h_icl"]
    return df


def main() -> None:
    cas = cas9_table()
    cas.round(4).to_csv(OUT / "cas9-breakeven.csv", index=False, lineterminator=chr(10))
    pd.set_option("display.width", 250)
    print(cas[["ft_sampling_hours", "c_icl_per_design", "c_ft_per_design", "breakeven_passing_designs", "icl_samples_for_64", "ft_samples_for_64"]].round(3).to_string())
    ph = phage_table()
    ph.round(4).to_csv(OUT / "phage-decomposition.csv", index=False, lineterminator=chr(10))
    print(ph[["engine", "ft_per_sample_time_relative_to_icl", "ft_sampling_hours_implied", "ft_fixed_hours_implied", "c_ft_per_design", "c_icl_per_design", "sample_ratio_ft_over_icl", "time_ratio_ft_over_icl"]].round(3).to_string())
    # per-design yield ratio versus the pooled pass rate comparison in Cas9 (the pooled pass rate of ICL is lower than that of fine-tuning)
    print("Cas9 yield ratio ICL/FT:", CAS["p_icl"] / CAS["p_ft"], " Phage yield ratio ICL/FT:", PHAGE["p_icl"] / PHAGE["p_ft"])
    # cost to reach libraries of different sizes
    rows = []
    c_icl, s = CAS["h_icl"] / LIB, 19.0
    for n in (64, 256, 1000, 4000, 10000):
        rows.append(dict(passing_designs=n, icl_hours=c_icl * n, ft_hours=CAS["h_ft_finetune"] + s / LIB * n))
    pd.DataFrame(rows).round(1).to_csv(OUT / "cas9-library-size.csv", index=False, lineterminator=chr(10))
    print(pd.DataFrame(rows).round(1).to_string())


if __name__ == "__main__":
    main()
