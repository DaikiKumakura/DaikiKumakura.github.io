# Companion archive: real-drug PK mapping on a label-free library

Contents: package source (pkpdspace 0.0.5, GPL-3, development version), scripts (06 mapping and evaluation, 09 synthetic calibration, 11 figures) and result tables (results/).
Not included: the FRDB files and the nlmixr2data files. FRDB has no redistribution licence found; get frdb-pk.tsv and frdb-drugs.tsv from the source in the article (check its terms) and put them in workflows/data-cache/ncats/extracted/frdb/. Get theo_sd.rda and warfarin.rda from the CRAN package nlmixr2data 2.0.10 (data/ folder of the source tarball) and put them in workflows/data-cache/nlmixr2data/.
Requirements: R 4.5.x, pkgload, ggplot2, xgboost (script 09). Run from this directory (results are written to validation/results/ and outputs/figures/):
  Rscript workflows/06_map_real_drugs.R
  Rscript workflows/09_inverse_calibration.R
  Rscript workflows/11_article_figures.R   (needs the result tables, copy results/*.csv to validation/results/ first)
Seeds 20261126 (library, hold-out) and 20261128 (synthetic calibration).
