#!/usr/bin/env Rscript
# Stage D, task T3: calibration of the weighted-candidate (explicit Bayesian) inverse mapping on synthetic drugs,
# compared with a direct point regression (summary -> parameter). Synthetic accuracy says nothing about real drugs.
# Outputs: validation/results/stageD-inverse-*.csv
suppressMessages(if (file.exists("DESCRIPTION")) pkgload::load_all(".", quiet = TRUE) else library(pkpdspace))
seed <- 20261128L; out <- "validation/results"; dir.create(out, FALSE, TRUE)
n_lib <- 100000L; n_test <- 400L; noise <- 0.10; sd_used <- 0.10     # data-generating noise equals the likelihood SD: a calibration check, not robustness
lib <- pk_library(n_lib, seed = seed)
tst <- pk_library(n_test, seed = seed + 1L)                         # held-out virtual drugs (different design, different seed)
s_lib <- pk_summaries(lib, "oral"); s_tst <- pk_summaries(tst, "oral")
set.seed(seed)
obs <- lapply(s_tst, function(v) v * exp(stats::rnorm(n_test, 0, noise)))
tru <- data.frame(CL_F = tst$CL / tst$F, V_F = tst$V / tst$F, ka = tst$ka, F = tst$F)
lp <- data.frame(CL_F = lib$CL / lib$F, V_F = lib$V / lib$F, ka = lib$ka, F = lib$F)
t_bayes <- system.time(rows <- lapply(seq_len(n_test), function(i) {
  z2 <- ((log(s_lib$auc_per_dose) - log(obs$auc_per_dose[i])) / sd_used)^2 + ((log(s_lib$cmax_per_dose) - log(obs$cmax_per_dose[i])) / sd_used)^2 +
        ((log(s_lib$thalf) - log(obs$thalf[i])) / sd_used)^2
  w <- exp(-0.5 * (z2 - min(z2))); w <- w / sum(w)
  r <- vapply(names(tru), function(nm) {
    o <- order(lp[[nm]]); cw <- cumsum(w[o]); q <- function(p) lp[[nm]][o][which(cw >= p)[1]]
    c(rank = sum(w[lp[[nm]] < tru[[nm]][i]]), lo = q(0.05), hi = q(0.95), med = q(0.5))
  }, numeric(4))
  c(ess = 1 / sum(w^2), as.vector(r))
}))[["elapsed"]]
m <- do.call(rbind, rows); nm4 <- as.vector(outer(c("rank", "lo", "hi", "med"), names(tru), paste, sep = "_"))
colnames(m) <- c("ess", nm4)
cov90 <- vapply(names(tru), function(n) mean(tru[[n]] >= m[, paste0("lo_", n)] & tru[[n]] <= m[, paste0("hi_", n)]), numeric(1))
# SBC-style check: ranks of the truth in the posterior should be uniform; report the share in each decile and a chi-square statistic
sbc <- do.call(rbind, lapply(names(tru), function(n) { h <- tabulate(pmin(10L, floor(m[, paste0("rank_", n)] * 10) + 1L), 10); data.frame(parameter = n, decile = 1:10, count = h, expected = n_test / 10) }))
chi <- vapply(names(tru), function(n) { d <- sbc[sbc$parameter == n, ]; sum((d$count - d$expected)^2 / d$expected) }, numeric(1))
width <- vapply(names(tru), function(n) stats::median(log(m[, paste0("hi_", n)] / m[, paste0("lo_", n)])), numeric(1))
bayes_err <- vapply(names(tru), function(n) sqrt(mean((log(m[, paste0("med_", n)]) - log(tru[[n]]))^2)), numeric(1))

# direct point regression (boosted trees on log summaries -> log parameter), trained on 20,000 library draws
ix <- seq_len(20000L); X <- log(as.matrix(s_lib[ix, c("auc_per_dose", "cmax_per_dose", "thalf")])); Xt <- log(cbind(obs$auc_per_dose, obs$cmax_per_dose, obs$thalf))
reg <- vapply(names(tru), function(n) {
  y <- log(lp[[n]][ix]); b <- xgboost::xgb.train(params = list(objective = "reg:squarederror", max_depth = 4, eta = 0.1, nthread = 1, seed = seed), data = xgboost::xgb.DMatrix(X, label = y), nrounds = 200, verbose = 0)
  sqrt(mean((as.numeric(predict(b, xgboost::xgb.DMatrix(Xt))) - log(tru[[n]]))^2))
}, numeric(1))
prior_sd <- vapply(names(tru), function(n) stats::sd(log(lp[[n]])), numeric(1))
res <- data.frame(parameter = names(tru), coverage90 = cov90, sbc_chisq9df = chi, median_log_width90 = width, log_rmse_posterior_median = bayes_err,
                  log_rmse_direct_regression = reg, prior_log_sd = prior_sd, row.names = NULL)
utils::write.csv(res, file.path(out, "stageD-inverse-calibration.csv"), row.names = FALSE)
utils::write.csv(sbc, file.path(out, "stageD-inverse-sbc.csv"), row.names = FALSE)
cat("median ESS", median(m[, "ess"]), "; candidate-set time for", n_test, "drugs:", round(t_bayes, 1), "s\n"); print(res)
