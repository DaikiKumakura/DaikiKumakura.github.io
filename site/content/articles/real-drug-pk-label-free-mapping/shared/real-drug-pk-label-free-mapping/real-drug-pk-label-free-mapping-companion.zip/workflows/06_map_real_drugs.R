#!/usr/bin/env Rscript
# Stage C evaluation on real data.
# Inputs : workflows/data-cache/ncats/extracted/frdb (FRDB, not redistributed),
#          workflows/data-cache/nlmixr2data (CRAN nlmixr2data data files).
# Outputs: validation/results/frdb-audit-*.csv, frdb-oral-mapping.csv, frdb-holdout-cmax*.csv, timecourse-*.csv
suppressMessages(if (file.exists("DESCRIPTION")) pkgload::load_all(".", quiet = TRUE) else library(pkpdspace))
seed <- 20261126L; n_lib <- 100000L; out <- "validation/results"; dir.create(out, FALSE, TRUE)
ev <- import_frdb("workflows/data-cache/ncats/extracted/frdb"); a <- audit_evidence(ev)
for (nm in names(a)) utils::write.csv(a[[nm]], file.path(out, sprintf("frdb-audit-%s.csv", nm)), row.names = FALSE)
lib <- pk_library(n_lib, seed = seed)
cat("rows", nrow(ev$summaries), "drugs", length(unique(ev$summaries$drug_id)), "\n")

# 1. Oral mapping for all drugs (abstentions retained)
m <- annotate_drugs(map_drugs(ev, "Oral", library = lib), ev)
utils::write.csv(m, file.path(out, "frdb-oral-mapping.csv"), row.names = FALSE)
print(table(m$status))

# 2. Hold-out of Cmax: drugs with AUC, Cmax and half-life; Cmax withheld and predicted from AUC + half-life.
cand <- m$drug_id[grepl("auc", m$quantities) & grepl("cmax", m$quantities) & grepl("thalf", m$quantities)]
cand <- cand[seq_len(min(length(cand), 300L))]
s <- ev$summaries
res <- lapply(cand, function(id) {
  mm <- map_drug(ev, id, "Oral", lib, hold_out = "cmax")
  if (is.null(mm$predicted)) return(NULL)
  p <- mm$predicted$cmax
  data.frame(drug_id = id, status = mm$status, observed_cmax_per_dose = drug_summary_evidence(s[s$drug_id == id, ], "Oral")$cmax$gm,
             pred_p05 = p[1], pred_p50 = p[2], pred_p95 = p[3], ess = mm$ess)
})
h <- do.call(rbind, res)
h$log_err <- log(h$pred_p50 / h$observed_cmax_per_dose)
h$baseline <- vapply(seq_len(nrow(h)), function(i) stats::median(h$observed_cmax_per_dose[-i]), numeric(1))
h$log_err_baseline <- log(h$baseline / h$observed_cmax_per_dose)
h$covered90 <- h$observed_cmax_per_dose >= h$pred_p05 & h$observed_cmax_per_dose <= h$pred_p95
utils::write.csv(h, file.path(out, "frdb-holdout-cmax.csv"), row.names = FALSE)
summ <- function(x) data.frame(n = nrow(x), log_rmse_map = sqrt(mean(x$log_err^2)), log_rmse_baseline = sqrt(mean(x$log_err_baseline^2)),
                               within_2fold_map = mean(abs(x$log_err) < log(2)), within_2fold_baseline = mean(abs(x$log_err_baseline) < log(2)), coverage90 = mean(x$covered90))
r <- rbind(cbind(set = "all_evaluated", summ(h)), cbind(set = "status_ok_only", summ(h[h$status == "ok", ])))
utils::write.csv(r, file.path(out, "frdb-holdout-cmax-summary.csv"), row.names = FALSE); print(r)

# 3. Time-course datasets (nlmixr2data)
nd <- "workflows/data-cache/nlmixr2data"
if (dir.exists(nd)) {
  ld <- function(f) get(load(file.path(nd, f)))
  th <- ld("theo_sd.rda")
  tc1 <- import_timecourse(th, "ID", "TIME", "DV", "AMT", evid = "EVID", route = "oral")
  wf <- ld("warfarin.rda"); wf <- wf[wf$dvid == "cp" | wf$evid != 0, ]
  tc2 <- import_timecourse(wf, "id", "time", "dv", "amt", evid = "evid", route = "oral")
  for (nm in c("tc1", "tc2")) {
    e <- evaluate_timecourse(get(nm), lib, "oral"); lab <- c(tc1 = "theophylline", tc2 = "warfarin")[[nm]]
    utils::write.csv(e, file.path(out, sprintf("timecourse-%s.csv", lab)), row.names = FALSE)
    cat(lab, "subjects", nrow(e), "log-RMSE map", signif(sqrt(mean(e$log_rmse_map^2)), 3), "baseline", signif(sqrt(mean(e$log_rmse_baseline^2, na.rm = TRUE)), 3),
        "coverage90", signif(mean(e$coverage90), 3), "\n")
  }
} else cat("NOT EVALUATED: nlmixr2data not found in", nd, "\n")
