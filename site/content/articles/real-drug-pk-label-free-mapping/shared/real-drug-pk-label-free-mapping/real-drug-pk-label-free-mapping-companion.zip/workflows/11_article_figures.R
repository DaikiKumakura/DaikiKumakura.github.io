#!/usr/bin/env Rscript
# Figures for the two articles on real-drug mapping and surrogate evaluation (Okabe-Ito palette).
# Inputs: validation/results/{frdb-holdout-cmax,timecourse-theophylline,timecourse-warfarin,stageD-surrogate-compare}.csv
# Outputs: outputs/figures/map-fig1-holdout-cmax.png, map-fig2-timecourse.png, sur-fig1-rmse-ratio.png
suppressMessages(library(ggplot2))
r <- "validation/results"; fig <- "outputs/figures"; dir.create(fig, FALSE, TRUE)
ok <- c(blue = "#0072B2", vermillion = "#D55E00", green = "#009E73", orange = "#E69F00")
if (file.exists(file.path(r, "frdb-holdout-cmax.csv"))) {
h <- read.csv(file.path(r, "frdb-holdout-cmax.csv"))
h$status <- factor(h$status, c("ok", "not_identifiable"))
p1 <- ggplot(h, aes(observed_cmax_per_dose, pred_p50, colour = status)) +
  geom_abline(slope = 1, intercept = 0, colour = "grey30") +
  geom_abline(slope = 1, intercept = log10(2), colour = "grey60", linetype = "dashed") + geom_abline(slope = 1, intercept = -log10(2), colour = "grey60", linetype = "dashed") +
  geom_linerange(aes(ymin = pred_p05, ymax = pred_p95), alpha = 0.25, linewidth = 0.3) + geom_point(aes(shape = status), size = 1.6, alpha = 0.8) +
  scale_x_log10() + scale_y_log10() + scale_colour_manual(values = c(ok = ok[["blue"]], not_identifiable = ok[["vermillion"]])) +
  labs(x = "Observed Cmax per dose (mg/L per mg)", y = "Predicted Cmax per dose, median and 90% interval (mg/L per mg)", colour = "Mapping status", shape = "Mapping status",
       caption = sprintf("n = %d drugs; Cmax withheld, AUC and half-life used. Solid line: equality; dashed: 2-fold.", nrow(h))) + theme_bw(base_size = 11)
ggsave(file.path(fig, "map-fig1-holdout-cmax.png"), p1, width = 7, height = 5.5, dpi = 150)
tc <- rbind(cbind(set = "Theophylline (n = 12)", read.csv(file.path(r, "timecourse-theophylline.csv"))), cbind(set = "Warfarin (n = 32)", read.csv(file.path(r, "timecourse-warfarin.csv"))))
p2 <- ggplot(tc, aes(log_rmse_baseline, log_rmse_map, colour = set, shape = set)) + geom_abline(slope = 1, intercept = 0, colour = "grey30") + geom_point(size = 2, alpha = 0.85) +
  scale_colour_manual(values = c(ok[["blue"]], ok[["orange"]])) + coord_equal(xlim = c(0, 1.6), ylim = c(0, 1.6)) +
  labs(x = "Log RMSE, population-profile baseline", y = "Log RMSE, label-free mapping", colour = NULL, shape = NULL,
       caption = "Each point is one subject; held-out last 40% of observations. Above the line: mapping is worse.") + theme_bw(base_size = 11)
ggsave(file.path(fig, "map-fig2-timecourse.png"), p2, width = 6.5, height = 5, dpi = 150)
} else cat("Skipped map figures: result tables not found.\n")
if (file.exists(file.path(r, "stageD-surrogate.csv"))) {
s <- read.csv(file.path(r, "stageD-surrogate.csv")); s$target <- factor(s$target, c("auc", "cmax", "mean_effect", "time_above"), c("AUC", "Cmax", "Mean effect", "Time above threshold"))
a <- aggregate(rmse_test ~ structure + target + method, data = s, FUN = median)
w <- reshape(a, idvar = c("structure", "target"), timevar = "method", direction = "wide"); w$ratio <- w$rmse_test.boost / w$rmse_test.linear
w$structure <- factor(w$structure, c("K01xP01", "K01xP04"), c("Direct Emax", "Persistent binding"))
p3 <- ggplot(w, aes(ratio, target, colour = structure, shape = structure)) + geom_vline(xintercept = 0.5, colour = "grey40", linetype = "dashed") + geom_point(size = 3) +
  scale_x_log10() + scale_colour_manual(values = c(ok[["blue"]], ok[["vermillion"]])) +
  labs(x = "Held-out RMSE, boosted trees / quadratic baseline (log scale)", y = NULL, colour = "PD mechanism", shape = "PD mechanism",
       caption = "Median over 5 regimens. Dashed line: pre-set adoption limit (ratio 0.5).") + theme_bw(base_size = 11)
ggsave(file.path(fig, "sur-fig1-rmse-ratio.png"), p3, width = 7, height = 3.8, dpi = 150)
}
cat("done\n")

