"""Figures for the LSA speedup note (reads results/*.csv)."""
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parent
RES, FIG = ROOT / "results", ROOT / "figures"
FIG.mkdir(exist_ok=True)
BLUE, ORANGE = "#0072B2", "#D55E00"


def labels(t):
    return [f"{h}\n{m.split('-')[0]}\n{p}" for h, m, p in zip(t.hardware, t.model, t.parallelism)]


def fig1():
    t = pd.read_csv(RES / "serving.csv")
    x = np.arange(len(t))
    fig, axes = plt.subplots(1, 2, figsize=(10.4, 4.4))
    for ax, a, b, title in ((axes[0], "layer_prefill", "ttft_speedup", "Prefill: one layer vs time to first token"),
                            (axes[1], "layer_decode", "tpot_speedup", "Decode: one layer vs time per output token")):
        ax.scatter(x, t[a], color=BLUE, s=70, label="One attention layer", zorder=3)
        ax.scatter(x, t[b], color=ORANGE, s=70, marker="s", label="Whole model, serving", zorder=3)
        for i in x:
            ax.plot([i, i], [t[b][i], t[a][i]], color="#999999", lw=1)
        ax.set_yscale("log")
        ax.set_xticks(x)
        ax.set_xticklabels(labels(t), fontsize=7)
        ax.set_ylabel("Speedup at 10M tokens (x, log scale)")
        ax.set_title(title, fontsize=10)
        ax.grid(axis="y", alpha=0.25)
    axes[0].legend(fontsize=8, loc="upper right")
    fig.tight_layout()
    fig.savefig(FIG / "01-layer-vs-whole-model-speedup.png", dpi=170)
    plt.close(fig)


def fig2():
    t = pd.read_csv(RES / "serving.csv")
    x = np.arange(len(t))
    fig, ax = plt.subplots(figsize=(8.4, 4.2))
    ax.bar(x - 0.2, 100 * t.implied_prefill_fraction, width=0.38, color=BLUE, label="Prefill")
    ax.bar(x + 0.2, 100 * t.implied_decode_fraction, width=0.38, color=ORANGE, label="Decode")
    ax.set_xticks(x)
    ax.set_xticklabels(labels(t), fontsize=7)
    ax.set_ylabel("Implied accelerated share (%)")
    ax.set_ylim(0, 100)
    ax.set_title("Amdahl-implied accelerated share (my calculation)", fontsize=10)
    ax.legend(fontsize=8)
    ax.grid(axis="y", alpha=0.25)
    fig.tight_layout()
    fig.savefig(FIG / "02-implied-accelerated-share.png", dpi=170)
    plt.close(fig)


if __name__ == "__main__":
    fig1()
    fig2()
