import numpy as np

import analysis as an


def test_amdahl_roundtrip():
    f = an.accelerated_fraction(9.21, 72.4)
    assert abs(an.amdahl_ceiling(f, 72.4) - 9.21) < 1e-9
    assert 0.90 < f < 0.91


def test_fraction_bounds():
    t = an.serving_table()
    assert ((t.implied_prefill_fraction > 0) & (t.implied_prefill_fraction < 1)).all()
    assert ((t.implied_decode_fraction > 0) & (t.implied_decode_fraction < 1)).all()


def test_free_indexer_shares():
    c = an.ceiling_table().set_index("phase")
    assert abs(c.loc["prefill", "share_of_ceiling_multiplicative"] - 22.7 / 58) < 1e-12
    assert abs(c.loc["decode", "share_of_ceiling_multiplicative"] - 4.6 / 8.9) < 1e-12


def test_baseline_ratio_is_small_for_h200_ttft():
    b = an.baseline_comparison().set_index("setting")
    assert abs(b.loc["H200 Qwen TP8+DCP8, TTFT 10M", "dlsa_vs_sparse"] - 9.21 / 8.02) < 1e-12


def test_whole_prefill_speedup_is_below_last_chunk_speedup():
    for below in (1.0, 2.1):
        r = an.last_chunk_vs_whole_prefill(below).iloc[0]
        assert 1 < r.whole_prefill_attention_speedup < r.last_chunk_speedup_10M


def test_ruler_gap_needs_high_within_prompt_correlation_to_be_significant():
    g = an.ruler_gap()
    assert g["z_independent"] < 1.96
    assert 0.7 < g["rho_needed_for_z196"] < 0.85
    p = an.paired_sensitivity().set_index("within_prompt_correlation")
    assert p.loc[0.9, "z"] > 1.96 > p.loc[0.5, "z"]


def test_table7_widths_are_narrower_than_worst_case():
    s = an.sample_size_table()
    assert (s.paper_ci_qwen <= s.worst_case_half_width_p50 + 1e-9).all()


def test_removable_time_shares():
    r = an.removable_time_removed().set_index("phase")
    assert 0.97 < r.loc["prefill", "share_of_removable_time_removed"] < 0.98
    assert 0.87 < r.loc["decode", "share_of_removable_time_removed"] < 0.89


def test_whole_prefill_estimate_range_and_sensitivity():
    r = an.last_chunk_vs_whole_prefill(1.0).iloc[0].whole_prefill_attention_speedup
    assert 13.3 < r < 13.5
    s = an.serving_sensitivity()
    assert (s.share_with_s_eff > s.share_with_last_chunk_s).all()


def test_interval_width_shrinks_with_n():
    assert an.binom_half_width(0.5, 2000) < an.binom_half_width(0.5, 100) < an.binom_half_width(0.5, 60)
