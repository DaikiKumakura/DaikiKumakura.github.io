"""Read the speedup and accuracy numbers of 'Latent Sparse Attention: Towards Subquadratic Ultra-Long Context Attention' (Kubicek et al., arXiv:2610.42147v1, 2026-10-30).

Inputs are numbers printed in the preprint: per-layer speedups at 10M tokens (abstract, Figure 6 text), the production-serving Table 3 (TTFT/TPOT speedups at 10M tokens, H200 and B300),
the 'free indexer' ceilings (58x prefill, 8.9x decode over sparse attention on GLM-5.3-Flash, Figure 2 text), per-layer prefill speedups 2.1x (512k), 3.5x (1M), 22.7x (10M) on GLM-5.3-Flash,
evaluation sizes (Table 6: RULER 20 prompts per task above 1M tokens x 13 tasks, MATH500 100 problems, LongBench v2 60, GPQA-Diamond 198, MMLU-Pro 2,000, PaperTrail 90 questions x 3 repeats),
RULER at 10M (D-LSA 63.9 vs Full Attention 59.9), and the native-training numbers (loss 1.085 vs 1.085; layer 1.1x at 64k and 1.6x at 128k; whole model 1.24x; RULER at 128k 32.2 vs 34.7).
The model assignment of the two B300 per-layer numbers (12.5x/42.9x prefill, 5.2x/18.4x decode) to GLM-5.3-Flash and Qwen-3.8-27B follows the order used elsewhere in the text and is an inference.
Everything here is arithmetic on these numbers (Amdahl's law, binomial intervals, log-log interpolation); there are no random numbers.
"""
from pathlib import Path

import numpy as np
import pandas as pd
from scipy.stats import beta

ROOT = Path(__file__).resolve().parent
OUT = ROOT / "results"
OUT.mkdir(exist_ok=True)

# (hardware, model, parallelism, layer prefill speedup, TTFT speedup of D-LSA(Flat), layer decode speedup, TPOT speedup of D-LSA(Flat)) at 10M tokens
SERVING = [
    ("H200", "Qwen-3.8-27B", "TP8+DCP8", 72.4, 9.21, 42.5, 2.87),
    ("H200", "GLM-5.3-Flash", "CP8", 22.7, 2.24, 4.6, 2.10),
    ("H200", "GLM-5.3-Flash", "TP8", 22.7, 5.83, 4.6, 1.91),
    ("B300", "Qwen-3.8-27B", "TP8", 42.9, 5.73, 18.4, 1.46),
    ("B300", "GLM-5.3-Flash", "CP8", 12.5, 1.56, 5.2, 2.21),
    ("B300", "GLM-5.3-Flash", "TP8", 12.5, 4.76, 5.2, 2.56),
]
FREE_INDEXER = dict(prefill=58.0, decode=8.9)         # potential speedup over sparse attention if the indexer were free, GLM-5.3-Flash, 10M tokens
LAYER_PREFILL_GLM = {512_000: 2.1, 1_000_000: 3.5, 10_000_000: 22.7}


def accelerated_fraction(total_speedup: float, part_speedup: float) -> float:
    """Amdahl: 1/S = (1-f) + f/s  =>  f = (1 - 1/S) / (1 - 1/s). Share of the baseline time that sits in the accelerated part."""
    return (1 - 1 / total_speedup) / (1 - 1 / part_speedup)


def amdahl_ceiling(f: float, s: float) -> float:
    return 1 / ((1 - f) + f / s)


def serving_table() -> pd.DataFrame:
    rows = []
    for hw, model, par, lp, ttft, ld, tpot in SERVING:
        rows.append(dict(hardware=hw, model=model, parallelism=par, layer_prefill=lp, ttft_speedup=ttft, implied_prefill_fraction=accelerated_fraction(ttft, lp),
                         layer_decode=ld, tpot_speedup=tpot, implied_decode_fraction=accelerated_fraction(tpot, ld)))
    return pd.DataFrame(rows)


def ceiling_table() -> pd.DataFrame:
    rows = []
    for phase, got, ceil in (("prefill", 22.7, FREE_INDEXER["prefill"]), ("decode", 4.6, FREE_INDEXER["decode"])):
        rows.append(dict(phase=phase, layer_speedup=got, free_indexer_ceiling=ceil, share_of_ceiling_multiplicative=got / ceil,
                         share_of_ceiling_log=np.log(got) / np.log(ceil)))
    return pd.DataFrame(rows)


def baseline_comparison() -> pd.DataFrame:
    """H200 Qwen-3.8-27B: speedup over Full Attention of Block Sparse Attention (Flat) and of D-LSA (Flat) (Table 3); D-LSA relative to the sparse baseline. B300 uses TP8 where the sparse indexer is not sharded."""
    rows = [dict(setting="H200 Qwen TP8+DCP8, TTFT 10M", sparse_vs_full=8.02, dlsa_vs_full=9.21),
            dict(setting="H200 Qwen TP8+DCP8, TPOT 10M", sparse_vs_full=0.89, dlsa_vs_full=2.87),
            dict(setting="B300 Qwen TP8, TTFT 10M", sparse_vs_full=0.84, dlsa_vs_full=5.73),
            dict(setting="B300 Qwen TP8, TPOT 10M", sparse_vs_full=1.33, dlsa_vs_full=1.46)]
    d = pd.DataFrame(rows)
    d["dlsa_vs_sparse"] = d.dlsa_vs_full / d.sparse_vs_full
    return d


def last_chunk_vs_whole_prefill(below: float = 1.0) -> pd.DataFrame:
    """Illustration: how the speedup of the last 32,768-query chunk relates to that of a whole 10M prefill (attention layer only), GLM-5.3-Flash.

    Per-layer baseline cost of the chunk ending at context t is taken proportional to t (the cost of attending 32,768 queries to t keys); the speedup s(t) is
    log-log interpolated through (512k, 2.1), (1M, 3.5), (10M, 22.7) and set to `below` under 512k. This is a model, not a measurement.
    """
    xs = np.log(np.array(list(LAYER_PREFILL_GLM)))
    ys = np.log(np.array(list(LAYER_PREFILL_GLM.values())))
    t = np.linspace(32_768, 10_000_000, 20000)
    s = np.where(t < 512_000, below, np.exp(np.interp(np.log(t), xs, ys)))
    base = np.trapezoid(t, t)
    new = np.trapezoid(t / s, t)
    return pd.DataFrame([dict(speedup_below_512k=below, last_chunk_speedup_10M=22.7, whole_prefill_attention_speedup=base / new)])


def binom_half_width(p: float, n: int, level: float = 0.95) -> float:
    """Half width of the exact (Clopper-Pearson) interval for proportion p with n trials (k rounded)."""
    k = round(p * n)
    a = (1 - level) / 2
    lo = 0.0 if k == 0 else beta.ppf(a, k, n - k + 1)
    hi = 1.0 if k == n else beta.ppf(1 - a, k + 1, n - k)
    return float((hi - lo) / 2)


PAPER_CI = {"MMLU-Pro": (1.6, 1.5), "GPQA-Diamond": (4.5, 4.9), "MATH500": (2.7, 2.8), "LongBench v2": (11.6, 11.6)}   # Table 7: baseline 95% CI half-widths (Qwen, GLM), points


def sample_size_table() -> pd.DataFrame:
    rows = []
    for name, n in (("MMLU-Pro", 2000), ("GPQA-Diamond", 198), ("MATH500", 100), ("LongBench v2", 60)):
        rows.append(dict(benchmark=name, n=n, worst_case_half_width_p50=100 * binom_half_width(0.5, n), paper_ci_qwen=PAPER_CI[name][0], paper_ci_glm=PAPER_CI[name][1]))
    return pd.DataFrame(rows)


def ruler_gap() -> dict:
    """RULER at 10M, Qwen: D-LSA (Flat) 63.9 vs Full Attention 59.9 on the same 13 x 20 = 260 prompts. Independent-sample SE is an upper bound; the design is paired."""
    n = 260
    d = 63.9 - 59.9
    se_each = 100 * np.sqrt(0.62 * 0.38 / n)
    return dict(difference_points=d, half_width_each_points=100 * binom_half_width(0.62, n), se_each_points=se_each, se_difference_independent_points=np.sqrt(2) * se_each,
                z_independent=d / (np.sqrt(2) * se_each), rho_needed_for_z196=1 - (d / (1.96 * se_each)) ** 2 / 2)


def paired_sensitivity() -> pd.DataFrame:
    g = ruler_gap()
    rows = []
    for rho in (0.0, 0.5, 0.7, 0.8, 0.9):
        se = g["se_each_points"] * np.sqrt(2 * (1 - rho))
        rows.append(dict(within_prompt_correlation=rho, se_difference_points=se, z=g["difference_points"] / se))
    return pd.DataFrame(rows)


def removable_time_removed() -> pd.DataFrame:
    rows = []
    for phase, got, ceil in (("prefill", 22.7, 58.0), ("decode", 4.6, 8.9)):
        rows.append(dict(phase=phase, share_of_removable_time_removed=(1 - 1 / got) / (1 - 1 / ceil)))
    return pd.DataFrame(rows)


def serving_sensitivity(s_eff: float = 13.5) -> pd.DataFrame:
    """GLM-5.3-Flash prefill: implied accelerated share if the effective part speedup is the whole-prefill estimate (about 13.5x) instead of the last-chunk 22.7x."""
    rows = []
    for hw, model, par, lp, ttft, ld, tpot in SERVING:
        if model.startswith("GLM") and hw == "H200":
            rows.append(dict(hardware=hw, parallelism=par, ttft_speedup=ttft, share_with_last_chunk_s=accelerated_fraction(ttft, lp), share_with_s_eff=accelerated_fraction(ttft, s_eff)))
    return pd.DataFrame(rows)


def native_training() -> dict:
    return dict(loss_full=1.085, loss_nlsa=1.085, ruler128_full=34.7, ruler128_nlsa=32.2, ruler_gap=34.7 - 32.2, whole_model_speedup=1.24, layer_speedup_128k=1.6,
                peak_memory_ratio=6.8 / 5.8)


def main() -> None:
    pd.set_option("display.width", 250, "display.max_columns", 30, "display.float_format", lambda v: f"{v:.4g}")
    tables = {"serving": serving_table(), "ceiling": ceiling_table(), "baseline_comparison": baseline_comparison(), "sample_sizes": sample_size_table(), "paired_sensitivity": paired_sensitivity(), "removable_time": removable_time_removed(), "serving_sensitivity": serving_sensitivity(),
              "last_chunk_vs_whole": pd.concat([last_chunk_vs_whole_prefill(b) for b in (1.0, 2.1)], ignore_index=True)}
    for k, v in tables.items():
        v.to_csv(OUT / f"{k}.csv", index=False)
        print(k); print(v); print()
    for k, v in (("ruler_gap", ruler_gap()), ("native_training", native_training())):
        pd.Series(v).to_csv(OUT / f"{k}.csv", header=["value"])
        print(k, v)


if __name__ == "__main__":
    main()
