# Reading the speedups of Latent Sparse Attention: companion code

Arithmetic on numbers printed in the Latent Sparse Attention preprint (Kubicek et al., arXiv:2610.42147): Amdahl-implied accelerated shares from per-layer and whole-model speedups, the share of the free-indexer ceiling, the ratio of D-LSA to an existing sparse baseline, an illustrative estimate of whole-prefill speedup from the last-chunk speedups, and binomial intervals for the evaluation sizes. The released implementation is not run.

- `analysis.py`: all tables.
- `figures.py`: Figures 1 and 2.
- `test_analysis.py`: checks (`python -m pytest test_analysis.py`).
- `results/`: CSV outputs.

Requires Python 3 with numpy, scipy, pandas, matplotlib.
