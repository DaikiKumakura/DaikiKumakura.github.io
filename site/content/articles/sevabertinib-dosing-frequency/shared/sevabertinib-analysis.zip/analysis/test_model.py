"""Checks of estimand, units, dose balance and numerical implementation."""
from pathlib import Path
import json,unittest
import numpy as np
from scipy.integrate import solve_ivp
from scipy.linalg import expm
from model import fit_relative_f,draw_eta,profile,pk_matrices,btr_mapping,single_dose

I=json.loads((Path(__file__).parent/'inputs.json').read_text(encoding='utf8'))
P=I['pk'];ZERO=np.zeros((1,3))

class ModelTests(unittest.TestCase):
    def test_aggregate_estimate_direction_and_interval(self):
        f=fit_relative_f(I['observed_tablet_over_liquid'])
        self.assertAlmostEqual(f['f'],1/1.5545,places=9)
        self.assertAlmostEqual(f['lower90'],1/2.2485,places=4)
        self.assertAlmostEqual(f['upper90'],1/1.0746,places=4)

    def test_auc24_is_not_auc12(self):
        a=profile(P,20,12,ZERO)
        self.assertAlmostEqual(a['auc24'][0],40000/3.09,places=6)
        self.assertAlmostEqual(a['auc24_numeric'][0],a['auc24'][0],delta=.1)

    def test_same_daily_dose_different_peaks(self):
        a=profile(P,20,12,ZERO);b=profile(P,40,24,ZERO)
        np.testing.assert_allclose(a['auc24'],b['auc24'])
        self.assertGreater(b['cmax'][0],a['cmax'][0])
        self.assertLess(b['cmin'][0],a['cmin'][0])

    def test_formulation_balance(self):
        a=profile(P,40,24,ZERO);b=profile(P,40,24,ZERO,True)
        self.assertAlmostEqual(b['auc24'][0]/a['auc24'][0],.639,places=10)

    def test_matrix_solution_vs_independent_ode(self):
        m,f,_=pk_matrices(P,ZERO);delta=np.zeros(7);delta[0]=20*f[0]
        post=np.linalg.solve(np.eye(7)-expm(m[0]*12),delta)
        a=profile(P,20,12,ZERO)
        sol=solve_ivp(lambda t,x:m[0]@x,(0,12),post,t_eval=a['time'],rtol=1e-10,atol=1e-11)
        np.testing.assert_allclose(sol.y[5]/P['vc']*1000,a['conc'][0],rtol=2e-8)

    def test_eta_seed_variance_and_correlation(self):
        a=draw_eta(20000,42,I['omega_diagonal'],.5)
        np.testing.assert_array_equal(a,draw_eta(20000,42,I['omega_diagonal'],.5))
        np.testing.assert_allclose(np.var(a,axis=0),I['omega_diagonal'],rtol=.03)
        self.assertAlmostEqual(np.corrcoef(a[:,:2].T)[0,1],.5,delta=.02)

    def test_covariates_cancel_in_paired_ratios(self):
        a=profile(P,20,12,ZERO,bw=48,albumin_fraction=.49)
        b=profile(P,40,24,ZERO,bw=48,albumin_fraction=.49)
        x=profile(P,20,12,ZERO);y=profile(P,40,24,ZERO)
        np.testing.assert_allclose(b['cmax']/a['cmax'],y['cmax']/x['cmax'])

    def test_absorption_interpretation_sensitivity(self):
        a=profile(P,20,12,ZERO,stages=5);b=profile(P,20,12,ZERO,stages=6)
        np.testing.assert_allclose(a['auc24'],b['auc24'])
        self.assertGreater(b['tmax'][0],a['tmax'][0])

    def test_er_equality_is_structural(self):
        a=profile(P,20,12,ZERO);b=profile(P,40,24,ZERO)
        np.testing.assert_array_equal(btr_mapping(a['auc24'],I['btr_mapping']),btr_mapping(b['auc24'],I['btr_mapping']))

    def test_single_dose_finite_window_and_formulation(self):
        a=single_dose(P,20);b=single_dose(P,20,True)
        self.assertLess(a['auc_0_24'],20000/P['cl'])
        self.assertAlmostEqual(a['auc_0_24']/b['auc_0_24'],1/P['f_liquid'],delta=.01)
        self.assertGreater(a['cmax'],b['cmax'])

if __name__=='__main__':unittest.main()
