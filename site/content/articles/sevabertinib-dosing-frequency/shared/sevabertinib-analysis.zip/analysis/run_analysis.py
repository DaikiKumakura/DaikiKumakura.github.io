"""Run lightweight public-summary estimation and paired conditional simulations."""
from pathlib import Path
import hashlib,json,platform
import numpy as np
import pandas as pd
import scipy,matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from model import fit_relative_f,draw_eta,profile,btr_mapping,single_dose

ROOT=Path(__file__).resolve().parents[1]
INPUT=json.loads((Path(__file__).parent/'inputs.json').read_text(encoding='utf8'))
OUT=ROOT/'outputs';FIG=OUT/'figures';TAB=OUT/'tables'
REGIMENS=[('20 mg TAB BID',20.,12.,False),('40 mg TAB QD',40.,24.,False),('40 mg LSF QD',40.,24.,True)]
COLORS=['#0072B2','#D55E00','#009E73']

def save_json(path,obj):path.write_text(json.dumps(obj,indent=2,ensure_ascii=False)+'\n',encoding='utf8')
def interval(x):return np.quantile(x,[.05,.5,.95])
def main():
    FIG.mkdir(parents=True,exist_ok=True);TAB.mkdir(parents=True,exist_ok=True)
    p=INPUT['pk'];cfg=INPUT['config'];fit=fit_relative_f(INPUT['observed_tablet_over_liquid']);save_json(OUT/'fit.json',fit)
    eta=draw_eta(cfg['n'],cfg['seed'],INPUT['omega_diagonal'])
    typical=[];results=[];curves=[];pop=[];paired=[]
    for name,dose,tau,liq in REGIMENS:
        typ=profile(p,dose,tau,np.zeros((1,3)),liq,cfg['absorption_stages'],cfg['dt'])
        sim=profile(p,dose,tau,eta,liq,cfg['absorption_stages'],cfg['dt']);results.append(sim)
        typical.append(dict(regimen=name,**{k:float(typ[k][0]) for k in ['auc24','cmax','cmin','tmax']},peak_trough=float(typ['cmax'][0]/typ['cmin'][0])))
        for k in ['auc24','cmax','cmin']:
            lo,med,hi=interval(sim[k]);pop.append(dict(regimen=name,endpoint=k,p05=lo,median=med,p95=hi))
        tt=typ['time'];cc=typ['conc'][0]
        t24=np.arange(round(24/cfg['dt'])+1)*cfg['dt'];c24=cc[np.arange(len(t24))%(len(tt)-1)]
        curves.append((t24,c24))
    for j in [1,2]:
        for k in ['auc24','cmax','cmin']:
            lo,med,hi=interval(results[j][k]/results[0][k]);paired.append(dict(regimen=REGIMENS[j][0],endpoint=k,p05=lo,median=med,p95=hi))
    pd.DataFrame(typical).to_csv(TAB/'typical.csv',index=False)
    pd.DataFrame(pop).to_csv(TAB/'population.csv',index=False)
    pd.DataFrame(paired).to_csv(TAB/'paired-ratios.csv',index=False)
    sensitivity=[]
    for stages in [5,6]:
        for rho in [-.5,0,.5]:
            e=draw_eta(512,cfg['seed'],INPUT['omega_diagonal'],rho)
            a=profile(p,20,12,e,False,stages,.1);b=profile(p,40,24,e,False,stages,.1)
            for k in ['cmax','cmin']:
                lo,med,hi=interval(b[k]/a[k]);sensitivity.append(dict(stages=stages,rho_ka_cl=rho,endpoint=k,p05=lo,median=med,p95=hi))
    pd.DataFrame(sensitivity).to_csv(TAB/'structural-sensitivity.csv',index=False)
    covariates=[]
    for bw,alb in [(61,.56),(48,.56),(80,.56),(61,.49),(61,.63)]:
        a=profile(p,20,12,np.zeros((1,3)),False,5,.05,bw,alb)
        b=profile(p,40,24,np.zeros((1,3)),False,5,.05,bw,alb)
        covariates.append(dict(bw=bw,albumin_fraction=alb,auc24=a['auc24'][0],qd_bid_cmax_ratio=b['cmax'][0]/a['cmax'][0],qd_bid_cmin_ratio=b['cmin'][0]/a['cmin'][0]))
    pd.DataFrame(covariates).to_csv(TAB/'covariates.csv',index=False)
    f_rows=[]
    for label,f in [('lower90',fit['lower90']),('fit',fit['f']),('upper90',fit['upper90']),('published',p['f_liquid'])]:
        q={**p,'f_liquid':f};a=profile(q,40,24,np.zeros((1,3)),True,5,.05)
        f_rows.append(dict(estimate=label,f_liquid=f,auc24=a['auc24'][0],cmax=a['cmax'][0],cmin=a['cmin'][0]))
    pd.DataFrame(f_rows).to_csv(TAB/'relative-f-sensitivity.csv',index=False)
    observed=INPUT['observed_tablet_over_liquid']
    single_tab=single_dose(p,20,False,5)
    single_liq=single_dose(p,20,True,5)
    # No independent validation: the clinical ratio also informed the public model.
    consistency=dict(auc_tablet_liquid_model=1/p['f_liquid'],auc_tablet_liquid_reported=observed['auc_ratio'],
                     label_auc12=INPUT['label']['auc_0_12'],typical_auc12=typical[0]['auc24']/2,
                     label_cmax=INPUT['label']['cmax'],typical_cmax=typical[0]['cmax'],
                     single_dose_20mg_tablet=single_tab,single_dose_20mg_liquid=single_liq,
                     finite_auc_tablet_liquid_model=single_tab['auc_0_24']/single_liq['auc_0_24'],
                     single_cmax_tablet_liquid_model=single_tab['cmax']/single_liq['cmax'],
                     single_cmax_tablet_liquid_reported=observed['cmax_ratio'],
                     single_cmax_reported_lower90=observed['cmax_lower90'],
                     single_cmax_reported_upper90=observed['cmax_upper90'],
                     diagnostic='Reference equal-dose single-dose comparison; public aggregate conditions are incompletely specified; Cmax mismatch is NOT resolved')
    save_json(OUT/'consistency.json',consistency)
    pd.DataFrame([dict(endpoint='AUC0-24 TAB/LSF',model=consistency['finite_auc_tablet_liquid_model'],reported=observed['auc_ratio'],lower90=observed['auc_lower90'],upper90=observed['auc_upper90']),dict(endpoint='Cmax TAB/LSF',model=consistency['single_cmax_tablet_liquid_model'],reported=observed['cmax_ratio'],lower90=observed['cmax_lower90'],upper90=observed['cmax_upper90'])]).to_csv(TAB/'aggregate-consistency.csv',index=False)
    fine=profile(p,20,12,np.zeros((1,3)),False,5,.025)
    numeric=max(float(np.max(np.abs(x['auc24_numeric']/x['auc24']-1))) for x in results)
    verify=dict(n_virtual=cfg['n'],seed=cfg['seed'],max_auc_relative_error=numeric,
                max_periodic_error=max(x['periodic_error'] for x in results),
                peak_grid_relative_difference=float(abs(fine['cmax'][0]/typical[0]['cmax']-1)),
                same_formulation_auc_max_deviation=float(np.max(np.abs(results[1]['auc24']/results[0]['auc24']-1))),
                btr_same_auc_max_deviation=float(np.max(abs(btr_mapping(results[1]['auc24'],INPUT['btr_mapping'])-btr_mapping(results[0]['auc24'],INPUT['btr_mapping'])))))
    assert numeric<.001 and verify['max_periodic_error']<1e-8
    save_json(OUT/'verification.json',verify)
    save_json(OUT/'environment.json',dict(python=platform.python_version(),numpy=np.__version__,pandas=pd.__version__,scipy=scipy.__version__,matplotlib=matplotlib.__version__))
    hashes={f.name:hashlib.sha256(f.read_bytes()).hexdigest() for f in (ROOT/'data/raw').glob('*') if f.is_file()}
    if hashes:save_json(OUT/'source-hashes.json',hashes)
    plt.rcParams.update({'font.size':11,'axes.spines.top':False,'axes.spines.right':False,'axes.labelcolor':'#23384d','text.color':'#23384d','axes.titleweight':'bold','figure.facecolor':'white'})
    fig,ax=plt.subplots(figsize=(9,5.2),layout='constrained')
    for j,((t,c),(name,*_)) in enumerate(zip(curves,REGIMENS)):ax.plot(t,c,label=name,color=COLORS[j],ls=['-','--','-.'][j],lw=2)
    ax.set(xlim=(0,24),ylim=(0,None),xlabel='Hours since morning dose at periodic steady state',ylabel='Parent concentration (ng/mL)',title='Same daily dose, different formulation and frequency')
    ax.legend(frameon=False);fig.savefig(FIG/'01-profiles.png',dpi=180);plt.close(fig)
    fig,axes=plt.subplots(1,2,figsize=(10.5,4.8),layout='constrained')
    data=pd.DataFrame(paired)
    for a,name in zip(axes,['40 mg TAB QD','40 mg LSF QD']):
        d=data[data.regimen==name].set_index('endpoint').loc[['auc24','cmax','cmin']]
        a.errorbar(d['median'],np.arange(3),xerr=np.array([d['median']-d.p05,d.p95-d['median']]),fmt='o',capsize=4,color=COLORS[1 if 'TAB' in name else 2])
        a.axvline(1,color='#53616b',ls=':',lw=1);a.set(yticks=np.arange(3),yticklabels=['AUC0-24','Cmax','Cmin'],xlabel='Ratio to 20 mg TAB BID',title=name,xlim=(0,2.1));a.invert_yaxis()
    fig.suptitle('Paired ratios in 4096 conditional virtual patients\nPoints: median; bars: 5th–95th patient percentiles, not confidence intervals',fontsize=12)
    fig.savefig(FIG/'02-paired-ratios.png',dpi=180);plt.close(fig)
    fig,axes=plt.subplots(1,2,figsize=(12,4.8))
    fig.subplots_adjust(left=.21,right=.98,bottom=.17,top=.79,wspace=.55)
    axes[0].errorbar([fit['f']],[0],xerr=[[fit['f']-fit['lower90']],[fit['upper90']-fit['f']]],fmt='o',capsize=5,color=COLORS[0])
    axes[0].scatter([p['f_liquid']],[1],marker='D',color=COLORS[2]);axes[0].set(yticks=[0,1],yticklabels=['Aggregate AUC fit\n90% summary interval','Public PopPK\npoint estimate'],xlim=(0,1.1),xlabel='Liquid / tablet relative F',title='Formulation contrast');axes[0].axvline(1,ls=':',color='#53616b')
    a=np.linspace(0,24000,200);axes[1].plot(a,btr_mapping(a,INPUT['btr_mapping']),color='#53616b')
    for j,row in enumerate(typical):
        aa=row['auc24'];axes[1].scatter([aa],[btr_mapping(np.array(aa),INPUT['btr_mapping'])],marker=['o','x','D'][j],s=[100,100,40][j],color=COLORS[j],label=row['regimen'],zorder=5)
    axes[1].set(xlabel='AUC0-24 (ng h/mL)',ylabel='BTR mapping (% change)',title='Same AUC, same E–R output',ylim=(-65,0));axes[1].legend(frameon=False,fontsize=9)
    fig.suptitle('Aggregate estimation and a structural E–R limitation',fontsize=13,y=.97)
    fig.savefig(FIG/'03-formulation-er.png',dpi=180);plt.close(fig)
    print(json.dumps({'relative_f_fit':fit,'typical':typical,'verification':verify},indent=2))

if __name__=='__main__':main()
