"""Transparent reconstruction of public sevabertinib coefficients; hours, mg, L."""
import numpy as np
from scipy.linalg import expm
from scipy.optimize import minimize_scalar
from scipy.stats import norm


def fit_relative_f(observed: dict) -> dict:
    """Normal summary likelihood on log(tablet/liquid AUC0-24)."""
    y = np.log(observed['auc_ratio'])
    se = np.log(observed['auc_upper90']/observed['auc_lower90'])/(2*norm.ppf(.95))
    result = minimize_scalar(lambda theta: (y+theta)**2/(2*se**2), bounds=(-3,1), method='bounded')
    assert result.success
    theta = float(result.x)
    return dict(log_f=theta, log_se=float(se), f=float(np.exp(theta)),
                lower90=float(np.exp(theta-norm.ppf(.95)*se)),
                upper90=float(np.exp(theta+norm.ppf(.95)*se)),
                method='one aggregate contrast; no individual NLME fit; finite-window AUC approximation')


def draw_eta(n: int, seed: int, omega: list, rho: float = 0.) -> np.ndarray:
    z = np.random.default_rng(seed).normal(size=(n,3))
    z[:,1] = rho*z[:,0]+np.sqrt(1-rho**2)*z[:,1]
    return z*np.sqrt(np.asarray(omega))


def pk_matrices(p: dict, eta: np.ndarray, liquid: bool = False,
                stages: int = 5, bw: float = 61., albumin_fraction: float = .56):
    assert stages >= 1 and bw > 0 and albumin_fraction > 0
    eta = np.atleast_2d(eta)
    n = len(eta); size = stages+2
    ka = p['ka']*np.exp(eta[:,0])*(p['ka_liquid'] if liquid else 1.)
    cl = p['cl']*np.exp(eta[:,1])
    f = np.exp(eta[:,2])*(bw/p['reference_bw'])**p['bw_power']*(albumin_fraction/p['reference_albumin_fraction'])**p['albumin_fraction_power']
    f *= p['f_liquid'] if liquid else 1.
    m = np.zeros((n,size,size))
    for j in range(stages):
        m[:,j,j] = -ka
        m[:,j+1,j] = ka
    m[:,stages,stages] = -(cl+p['q'])/p['vc']
    m[:,stages,stages+1] = p['q']/p['vp']
    m[:,stages+1,stages] = p['q']/p['vc']
    m[:,stages+1,stages+1] = -p['q']/p['vp']
    return m, f, cl


def profile(p: dict, dose: float, tau: float, eta: np.ndarray,
            liquid: bool = False, stages: int = 5, dt: float = .05,
            bw: float = 61., albumin_fraction: float = .56) -> dict:
    """Exact periodic steady state and matrix propagation; peak is grid-resolved."""
    steps = round(tau/dt)
    assert np.isclose(steps*dt,tau) and 24%tau == 0
    m,f,cl = pk_matrices(p,eta,liquid,stages,bw,albumin_fraction)
    delta = np.zeros((len(m),len(m[0])));delta[:,0] = dose*f
    cycle = expm(m*tau)
    post = np.linalg.solve(np.eye(m.shape[-1])[None,:,:]-cycle, delta[...,None])[...,0]
    state = post.copy(); step = expm(m*dt)
    c = np.empty((len(m),steps+1))
    for j in range(steps+1):
        c[:,j] = state[:,stages]/p['vc']*1000.
        if j < steps:state = np.einsum('nij,nj->ni',step,state)
    t = np.arange(steps+1)*dt
    auc = dose*(24/tau)*f/cl*1000.
    assert np.min(c)>-1e-7
    return dict(time=t,conc=c,auc24=auc,cmax=c.max(axis=1),cmin=c.min(axis=1),
                tmax=t[np.argmax(c,axis=1)],auc24_numeric=np.trapz(c,t,axis=1)*(24/tau),
                periodic_error=float(np.max(np.abs(np.einsum('nij,nj->ni',cycle,post)+delta-post))))


def btr_mapping(auc: np.ndarray, p: dict) -> np.ndarray:
    """Published point mapping only, not clinical prediction for a new schedule."""
    return p['emax']*auc/(p['ic50_auc_24']+auc)


def single_dose(p: dict, dose: float, liquid: bool = False,
                stages: int = 5, dt: float = .01) -> dict:
    """Reference single-dose 0–24h diagnostic; not a patient-level replay."""
    m,f,_=pk_matrices(p,np.zeros((1,3)),liquid,stages)
    state=np.zeros(stages+2);state[0]=dose*f[0]
    step=expm(m[0]*dt);time=np.arange(round(24/dt)+1)*dt
    conc=np.empty(len(time))
    for j in range(len(time)):
        conc[j]=state[stages]/p['vc']*1000.
        if j<len(time)-1:state=step@state
    return dict(auc_0_24=float(np.trapz(conc,time)),cmax=float(conc.max()),
                tmax=float(time[np.argmax(conc)]))
