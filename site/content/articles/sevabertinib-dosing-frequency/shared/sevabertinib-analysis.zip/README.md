# Sevabertinib dosing frequency and formulation

Research/learning only; not individual treatment or trial-dose advice.
Python numerical runtime, no downloads or accounts required.
Install the versions in requirements.txt in your chosen environment.
Run: python analysis/run_analysis.py
Tests: python -m unittest discover -s analysis -p "test_*.py" -q
Outputs are regenerated under outputs/.

Sources: FDA NDA219972 MultidisciplineR.pdf, PDF117-118 (reported relative
bioavailability contrast),293 (five transit compartments),300 (PopPK table80),
314 (applicant BTR Emax table85). OtherR.pdf PDF35 (formulation/dose groups).
Current US label: September17,2026, DailyMed setid d7a11334-6e7a-445b-9a16-bdcd9acbe61f.
Source URLs and numeric facts: analysis/inputs.json. Original PDFs are not included.
Source-hashes.json is the saved fingerprint of consulted sources, not proof of
fresh source verification when rerunning without raw files.

New estimation is ONE lognormal aggregate likelihood for liquid/tablet relative F,
using the reported tablet/liquid AUC0-24 LS mean ratio and90%CI. It is NOT a new
individual NLME fit. Interpreting finite-window AUC ratio as F assumes similar
clearance and captured fractions. Same-trial information is not external validation.
The aggregate-formulation interval is not population/patient prediction uncertainty.

Public two-compartment coefficients are reconstructed with five serial pre-central
absorption stages. Six stages is a structural sensitivity. Original NONMEM code is
not replayed. Ka,CL,F variances are public; unlisted correlations are set0, with
rho(Ka,CL)=+-0.5 sensitivity. Common eta across regimens. Fixed reference61kg,
ALB/PROT0.56. No full clinical joint background distribution and no residual error
in true exposure. Relative F can exceed1; it is not absolute bioavailability.

Same-formulation same-daily-dose AUC equality is algebraic, not new evidence of
clinical equivalence. Label AUC6640 refers to0-12h under20mg BID, not0-24h.
Single-dose aggregate Cmax ratio is NOT reproduced (model~1.519, reported2.2699).
Typical steady-state Cmax near label geometric mean is not independent validation.
Unresolved absorption/aggregate-design differences limit absolute peak claims.
Cmin is the within-cycle minimum, not necessarily the predose sample.

4096 paired conditional virtual patients, seed20261019. Additional512-person
structural sensitivity. Patient percentiles are not parameter confidence intervals.
BTR Emax is a published applicant point mapping used ONLY to illustrate that an
AUC-only model cannot distinguish same-AUC schedules. No new efficacy, diarrhea,
cardiac or safety predictions. No metabolite, tumor, target-binding or CNS model.
Public20mg development tablets/LSF are not a new current10mg-tablet equivalence study.

Original code is MIT-licensed (LICENSE). Source numeric facts remain attributed
to their original publications. Original figures and aggregate outputs were generated
by this analysis; no source-paper figure or patient record is redistributed.
