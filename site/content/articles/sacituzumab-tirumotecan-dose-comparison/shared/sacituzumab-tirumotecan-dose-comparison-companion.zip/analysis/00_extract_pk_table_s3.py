"""Extract Table S3 (sac-TMT PK, cycle 1 day 1) from the supplementary Word file into inputs/pk_tableS3.csv.

Usage: python -X utf8 -I analysis/00_extract_pk_table_s3.py <path to 13045_2025_1705_MOESM1_ESM.docx>
The docx is not bundled (see inputs/PROVENANCE.md). The extracted CSV is bundled.
"""
import csv
import re
import sys
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
docx = Path(sys.argv[1])
xml = zipfile.ZipFile(docx).read("word/document.xml").decode("utf8")


def text(s):
    return re.sub(r"\s+", " ", "".join(re.findall(r"<w:t[^>]*>([^<]*)</w:t>", s))).strip()


tables = re.findall(r"<w:tbl>.*?</w:tbl>", xml, flags=re.S)
rows = [[text(c) for c in re.findall(r"<w:tc>.*?</w:tc>", r, flags=re.S)] for r in re.findall(r"<w:tr[ >].*?</w:tr>", tables[2], flags=re.S)]
header, body = rows[0], rows[1:]
out, analyte = [], None
cell = re.compile(r"^\s*([0-9.]+)\s*±\s*([0-9.]+)\s*\(n\s*=\s*(\d+)\)\s*$")
for r in body:
    if r[0]:
        analyte = r[0]
    dose = float(re.match(r"([0-9.]+)", r[1]).group(1))
    for name, v in zip(header[3:], r[3:]):
        if not v:
            continue
        m = cell.match(v.replace("± ", "±"))
        if not m:
            m = re.match(r"^\s*0\s*\(n\s*=\s*(\d+)\)\s*$", v)
            assert m, (analyte, dose, name, v)
            out.append(dict(analyte=analyte, dose_mgkg=dose, parameter=name, mean=0.0, sd=float("nan"), n=int(m.group(1))))
            continue
        out.append(dict(analyte=analyte, dose_mgkg=dose, parameter=name, mean=float(m.group(1)), sd=float(m.group(2)), n=int(m.group(3))))
with (ROOT / "inputs/pk_tableS3.csv").open("w", newline="", encoding="utf-8") as f:
    w = csv.DictWriter(f, fieldnames=list(out[0]))
    w.writeheader()
    w.writerows(out)
print(len(out), "rows written")
