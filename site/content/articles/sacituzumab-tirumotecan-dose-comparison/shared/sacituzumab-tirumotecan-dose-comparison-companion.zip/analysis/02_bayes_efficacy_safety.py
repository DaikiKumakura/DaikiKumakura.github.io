"""Beta-binomial posteriors for the 4 and 5 mg/kg TNBC cohorts, risk differences, and sensitivity analyses.

Input : inputs/clinical_phase2_tnbc.csv (events, n per endpoint and dose; Tables 4 and 5 of Ouyang et al. 2025)
Model : events_j ~ Binomial(n_j, p_j), p_j ~ Beta(a, b), independent across doses (non-randomised cohorts; no borrowing).
        Main prior Beta(0.5, 0.5) (Jeffreys). Sensitivity: Beta(1, 1); and a sceptical shared prior Beta(2, 3) for ORR / Beta(3, 3) for toxicity.
        Posterior draws: 200,000, seed 20261107.
Output: outputs/tables/posterior_summary.csv, risk_difference.csv, benefit_risk_probs.csv, bias_sensitivity.csv, plane_draws.csv (first 20,000)
Run   : python -X utf8 analysis/02_bayes_efficacy_safety.py
Frequentist reference: Fisher exact test and Newcombe (Wilson-score) 95% interval for the risk difference.
The ORR and TRAE posteriors are drawn independently: the joint distribution within patients is unknown (not reported).
"""
import sys
from pathlib import Path

import numpy as np
import pandas as pd
from scipy import stats
from scipy.special import expit, logit

sys.stdout.reconfigure(encoding="utf-8")
SEED = 20261107
NDRAW = 200000
ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "outputs/tables"
df = pd.read_csv(ROOT / "inputs/clinical_phase2_tnbc.csv")
rng = np.random.default_rng(SEED)
PRIORS = {"Jeffreys Beta(0.5,0.5)": (0.5, 0.5), "Uniform Beta(1,1)": (1.0, 1.0)}


def wilson(x, n, z=1.959964):
    p = x / n
    c = (p + z * z / (2 * n)) / (1 + z * z / n)
    h = z * np.sqrt(p * (1 - p) / n + z * z / (4 * n * n)) / (1 + z * z / n)
    return c - h, c + h


def newcombe(x1, n1, x2, n2):
    p1, p2 = x1 / n1, x2 / n2
    l1, u1 = wilson(x1, n1)
    l2, u2 = wilson(x2, n2)
    d = p2 - p1
    return d - np.sqrt((p2 - l2) ** 2 + (u1 - p1) ** 2), d + np.sqrt((u2 - p2) ** 2 + (p1 - l1) ** 2)


post, rd_rows = [], []
draws = {}
for endpoint, g in df.groupby("endpoint", sort=False):
    g = g.set_index("dose_mgkg")
    x4, n4, x5, n5 = int(g.loc[4, "events"]), int(g.loc[4, "n"]), int(g.loc[5, "events"]), int(g.loc[5, "n"])
    lo, hi = newcombe(x4, n4, x5, n5)
    fisher_p = stats.fisher_exact([[x5, n5 - x5], [x4, n4 - x4]])[1]
    for pname, (a, b) in PRIORS.items():
        p4 = rng.beta(a + x4, b + n4 - x4, NDRAW)
        p5 = rng.beta(a + x5, b + n5 - x5, NDRAW)
        if pname.startswith("Jeffreys"):
            draws[endpoint] = (p4, p5)
        d = p5 - p4
        for dose, p, x, n in ((4, p4, x4, n4), (5, p5, x5, n5)):
            post.append(dict(endpoint=endpoint, prior=pname, dose=dose, events=x, n=n, observed=x / n, post_median=np.median(p), lo=np.percentile(p, 2.5), hi=np.percentile(p, 97.5)))
        rd_rows.append(dict(endpoint=endpoint, prior=pname, rd_median=np.median(d), rd_lo=np.percentile(d, 2.5), rd_hi=np.percentile(d, 97.5),
                            p_rd_gt0=float((d > 0).mean()), p_rd_gt_0_05=float((d > 0.05).mean()), p_rd_gt_0_10=float((d > 0.10).mean()),
                            obs_rd=x5 / n5 - x4 / n4, newcombe_lo=lo, newcombe_hi=hi, fisher_p=fisher_p, fisher_p_bonferroni10=min(1.0, fisher_p * 10)))
post = pd.DataFrame(post)
rd = pd.DataFrame(rd_rows)
post.to_csv(OUT / "posterior_summary.csv", index=False)
rd.to_csv(OUT / "risk_difference.csv", index=False)
pd.set_option("display.width", 250)
print("== posterior of each proportion (Jeffreys)")
print(post[post.prior.str.startswith("Jeffreys")].round(3).to_string(index=False))
print("\n== risk difference 5 - 4 mg/kg")
print(rd[rd.prior.str.startswith("Jeffreys")].drop(columns="prior").round(3).to_string(index=False))
print("\n== prior sensitivity: P(RD>0) and median RD, Jeffreys vs uniform")
print(rd.pivot_table(index="endpoint", columns="prior", values=["p_rd_gt0", "rd_median"], sort=False).round(3).to_string())

# Benefit-risk plane: independent draws of (ORR difference, Grade 3-4 TRAE difference)
o4, o5 = draws["ORR (CR+PR)"]
t4, t5 = draws["Grade 3-4 TRAE"]
dO, dT = o5 - o4, t5 - t4
pd.DataFrame(dict(d_orr=dO[:20000], d_g34=dT[:20000])).to_csv(OUT / "plane_draws.csv", index=False)
rows = []
for bthr in (0.0, 0.05, 0.10):
    for tthr in (0.0, 0.10, 0.20):
        rows.append(dict(benefit_gain_ge=bthr, tox_increase_le=tthr, prob=float(((dO >= bthr) & (dT <= tthr)).mean())))
rows.append(dict(benefit_gain_ge="any", tox_increase_le="any", prob=float(((dO > 0) & (dT > 0)).mean())))
br = pd.DataFrame(rows)
br.to_csv(OUT / "benefit_risk_probs.csv", index=False)
print("\n== benefit-risk plane (independent posteriors): P(dORR >= b and dTRAE <= t)")
print(br.to_string(index=False))
print(f"posterior median dORR = {np.median(dO):.3f}, dG34 = {np.median(dT):.3f}; P(dORR>0) = {(dO > 0).mean():.3f}; P(dG34>0) = {(dT > 0).mean():.3f}")

# Bias sensitivity: b is removed from the logit of the 5 mg/kg cohort's rate, so b > 0 means the observed 5 mg/kg rate is HIGHER than the true rate and b < 0 means it is LOWER.
# For ORR, b > 0 = the 5 mg/kg cohort looks better than it is; for toxicity, b > 0 = it looks worse than it is (the direction that works against a toxicity increase).
# The size of b is an arbitrary assumption (no external estimate).
rows = []
for b in np.round(np.arange(-1.0, 1.01, 0.25), 2):
    for name, (p4, p5) in (("ORR (CR+PR)", draws["ORR (CR+PR)"]), ("Grade 3-4 TRAE", draws["Grade 3-4 TRAE"]), ("Grade>=3 neutrophil decreased", draws["Grade>=3 neutrophil decreased"])):
        p5_adj = expit(logit(np.clip(p5, 1e-9, 1 - 1e-9)) - b)
        rows.append(dict(bias_logit=b, endpoint=name, p_5_gt_4=float((p5_adj > p4).mean()), rd_median=float(np.median(p5_adj - p4))))
bias = pd.DataFrame(rows)
bias.to_csv(OUT / "bias_sensitivity.csv", index=False)
print("\n== bias sensitivity: P(true 5 mg/kg rate > 4 mg/kg rate) after removing a logit-scale shift b from the 5 mg/kg cohort")
print(bias.pivot_table(index="bias_logit", columns="endpoint", values="p_5_gt_4").round(3).to_string())
