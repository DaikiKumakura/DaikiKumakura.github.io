"""Dose-normalised exposure and the 5 vs 4 mg/kg exposure ratio from the published Table S3 summaries.

Input : inputs/pk_tableS3.csv (mean, SD, n per analyte x dose x parameter; cycle 1 day 1, phase 1)
Method: the sampling distribution of each group mean is Normal(mean, SD^2/n) (arithmetic mean +/- SD as published).
        Ratio 5/4 mg/kg: parametric bootstrap (seed 20261107, 200,000 draws), percentile 95% interval.
        Dose-proportionality slope: weighted regression of ln(group mean) on ln(dose) across the five dose levels,
        weights from the delta method var(ln mean) = SD^2/(n mean^2); t interval with df = k - 2.
Output: outputs/tables/pk_dose_normalised.csv, pk_ratio_5_vs_4.csv, pk_power_slope.csv
Run   : python -X utf8 analysis/01_pk_dose_proportionality.py
Summary-level analysis; no individual data. Phase 1 patients (mixed solid tumors), not the phase 2 TNBC cohorts.
"""
import sys
from pathlib import Path

import numpy as np
import pandas as pd
from scipy import stats

sys.stdout.reconfigure(encoding="utf-8")
SEED = 20261107
ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "outputs/tables"
df = pd.read_csv(ROOT / "inputs/pk_tableS3.csv")
df["param"] = df.parameter.str.replace(r",.*", "", regex=True).str.replace("a$", "", regex=True).str.strip()
keep = df[df.param.isin(["Cmax", "AUC"])].copy()
keep["mean_per_dose"] = keep["mean"] / keep.dose_mgkg
keep["se_per_dose"] = keep.sd / np.sqrt(keep.n) / keep.dose_mgkg
keep.to_csv(OUT / "pk_dose_normalised.csv", index=False)
piv = keep.pivot_table(index=["analyte", "param"], columns="dose_mgkg", values="mean_per_dose")
print("== dose-normalised group means (per mg/kg)")
print(piv.round(1).to_string())

rng = np.random.default_rng(SEED)
rows = []
for (analyte, param), g in keep.groupby(["analyte", "param"]):
    g = g.set_index("dose_mgkg")
    if 4.0 not in g.index or 5.0 not in g.index:
        continue
    d4 = rng.normal(g.loc[4.0, "mean"], g.loc[4.0, "sd"] / np.sqrt(g.loc[4.0, "n"]), 200000)
    d5 = rng.normal(g.loc[5.0, "mean"], g.loc[5.0, "sd"] / np.sqrt(g.loc[5.0, "n"]), 200000)
    r = d5 / d4
    rows.append(dict(analyte=analyte, param=param, mean4=g.loc[4.0, "mean"], n4=int(g.loc[4.0, "n"]), mean5=g.loc[5.0, "mean"], n5=int(g.loc[5.0, "n"]),
                     ratio=g.loc[5.0, "mean"] / g.loc[4.0, "mean"], lo=np.percentile(r, 2.5), hi=np.percentile(r, 97.5),
                     p_ratio_ge_1_25=float((r >= 1.25).mean()), p_ratio_le_1=float((r <= 1.0).mean())))
ratio = pd.DataFrame(rows)
ratio.to_csv(OUT / "pk_ratio_5_vs_4.csv", index=False)
print("\n== exposure ratio 5 vs 4 mg/kg (dose ratio 1.25)")
print(ratio.round(3).to_string(index=False))

rows = []
for (analyte, param), g in keep.groupby(["analyte", "param"]):
    g = g[g["mean"] > 0].sort_values("dose_mgkg")
    x, y = np.log(g.dose_mgkg.values), np.log(g["mean"].values)
    w = 1 / (g.sd.values ** 2 / (g.n.values * g["mean"].values ** 2))
    X = np.c_[np.ones_like(x), x]
    W = np.diag(w)
    cov = np.linalg.inv(X.T @ W @ X)
    beta = cov @ X.T @ W @ y
    resid = y - X @ beta
    df_res = len(x) - 2
    s2 = float((w * resid ** 2).sum() / df_res)  # residual scale; >1 means more scatter than the published SDs imply
    se = np.sqrt(np.diag(cov) * max(s2, 1.0))
    tcrit = stats.t.ppf(0.975, df_res)
    rows.append(dict(analyte=analyte, param=param, slope=beta[1], lo=beta[1] - tcrit * se[1], hi=beta[1] + tcrit * se[1], df=df_res, residual_scale=s2,
                     slope_includes_1=bool(beta[1] - tcrit * se[1] <= 1 <= beta[1] + tcrit * se[1])))
slope = pd.DataFrame(rows)
slope.to_csv(OUT / "pk_power_slope.csv", index=False)
print("\n== power-model slope (1 = dose-proportional), five dose levels")
print(slope.round(3).to_string(index=False))
