"""Figures for the article (English text in figures). Requires outputs/tables from scripts 01 and 02.
Run: python -X utf8 analysis/03_figures.py   (seed 20261107 for the density grids; no randomness otherwise)
"""
import sys
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from scipy import stats

sys.stdout.reconfigure(encoding="utf-8")
ROOT = Path(__file__).resolve().parents[1]
T, F = ROOT / "outputs/tables", ROOT / "outputs/figures"
C4, C5, CK = "#0072B2", "#E69F00", "#444444"
plt.rcParams.update({"font.size": 9.5, "axes.spines.top": False, "axes.spines.right": False, "figure.dpi": 150})

# Figure 1: dose-normalised exposure
dn = pd.read_csv(T / "pk_dose_normalised.csv")
fig, axes = plt.subplots(1, 3, figsize=(10.5, 3.6))
for ax, (an, pa, ttl, unit) in zip(axes, [("sac-TMT ADC", "AUC", "ADC AUC", "h·µg/mL per mg/kg"), ("sac-TMT ADC", "Cmax", "ADC Cmax", "µg/mL per mg/kg"), ("Payload KL610023", "AUC", "Free payload KL610023 AUC", "h·ng/mL per mg/kg")]):
    g = dn[(dn.analyte == an) & (dn.param == pa)].sort_values("dose_mgkg")
    cols = [C4 if d == 4 else C5 if d == 5 else CK for d in g.dose_mgkg]
    ax.errorbar(g.dose_mgkg, g.mean_per_dose, yerr=1.96 * g.se_per_dose, fmt="none", ecolor="#888", capsize=3)
    ax.scatter(g.dose_mgkg, g.mean_per_dose, c=cols, s=45, zorder=3)
    for x, y, n in zip(g.dose_mgkg, g.mean_per_dose, g.n):
        ax.annotate(f"n={n}", (x, y), textcoords="offset points", xytext=(0, 7), ha="center", fontsize=7)
    ax.set_title(ttl, fontsize=9)
    ax.set_xlabel("Dose (mg/kg)")
    ax.set_ylabel(unit)
    ax.set_ylim(0, None)
fig.suptitle("Dose-normalised exposure, cycle 1 day 1, phase 1 (mean ± 1.96 SE; blue = 4 mg/kg, orange = 5 mg/kg)", fontsize=9)
fig.tight_layout()
fig.savefig(F / "fig1_dose_normalised_exposure.png")
plt.close(fig)

# Figure 2: ratio 5 vs 4
rt = pd.read_csv(T / "pk_ratio_5_vs_4.csv")
rt["label"] = rt.analyte.str.replace("sac-TMT ", "").str.replace("Payload KL610023", "Payload") + " " + rt.param
rt = rt.iloc[::-1]
fig, ax = plt.subplots(figsize=(6.4, 3.8))
y = np.arange(len(rt))
ax.hlines(y, rt.lo, rt.hi, color="#888")
ax.scatter(rt.ratio, y, color=C5, zorder=3)
ax.axvline(1.25, color=CK, ls="--", lw=1)
ax.axvline(1.0, color=CK, ls=":", lw=1)
ax.set_yticks(y)
ax.set_yticklabels(rt.label)
ax.set_xlabel("Exposure ratio, 5 mg/kg group / 4 mg/kg group (95% bootstrap interval)")
ax.set_xscale("log")
ax.set_xticks([0.5, 0.75, 1, 1.25, 1.5, 2, 3])
ax.get_xaxis().set_major_formatter(matplotlib.ticker.ScalarFormatter())
ax.get_xaxis().set_minor_formatter(matplotlib.ticker.NullFormatter())
ax.text(1.27, -0.45, "dose ratio 1.25", fontsize=7.5)
ax.set_title("Group-mean exposure ratio (n = 6–7 per group)", fontsize=9)
fig.tight_layout()
fig.savefig(F / "fig2_exposure_ratio.png")
plt.close(fig)

# Figure 3: posteriors
post = pd.read_csv(T / "posterior_summary.csv")
post = post[post.prior.str.startswith("Jeffreys")]
fig, axes = plt.subplots(1, 3, figsize=(10.5, 3.3))
grid = np.linspace(0, 1, 500)
for ax, ep, ttl in zip(axes, ["ORR (CR+PR)", "Grade 3-4 TRAE", "Grade>=3 neutrophil decreased"], ["Objective response rate", "Grade 3–4 TRAE", "Grade ≥3 decreased neutrophil count"]):
    for dose, col in ((4, C4), (5, C5)):
        r = post[(post.endpoint == ep) & (post.dose == dose)].iloc[0]
        d = stats.beta.pdf(grid, 0.5 + r.events, 0.5 + r.n - r.events)
        ax.plot(grid, d, color=col, lw=2, label=f"{dose} mg/kg: {int(r.events)}/{int(r.n)}")
        ax.fill_between(grid, d, color=col, alpha=0.12)
    ax.set_title(ttl, fontsize=9)
    ax.set_xlabel("Probability")
    ax.set_yticks([])
    ax.legend(frameon=False, fontsize=8)
axes[0].set_ylabel("Posterior density")
fig.suptitle("Beta-binomial posteriors (Jeffreys prior), phase 2 TNBC cohorts", fontsize=9)
fig.tight_layout()
fig.savefig(F / "fig3_posteriors.png")
plt.close(fig)

# Figure 4: benefit-risk plane
pl = pd.read_csv(T / "plane_draws.csv").iloc[:8000]
fig, ax = plt.subplots(figsize=(5.6, 4.4))
ax.scatter(pl.d_orr * 100, pl.d_g34 * 100, s=3, alpha=0.18, color=C5, edgecolors="none")
ax.axhline(0, color=CK, lw=0.8)
ax.axvline(0, color=CK, lw=0.8)
ax.scatter([np.median(pl.d_orr) * 100], [np.median(pl.d_g34) * 100], color="black", s=40, zorder=4, label="posterior median")
ax.set_xlabel("Difference in ORR, 5 − 4 mg/kg (percentage points)")
ax.set_ylabel("Difference in Grade 3–4 TRAE (percentage points)")
ax.set_title("Benefit–risk plane (independent posterior draws, 8,000 of 200,000)", fontsize=9)
ax.legend(frameon=False, fontsize=8, loc="lower right")
fig.tight_layout()
fig.savefig(F / "fig4_benefit_risk_plane.png")
plt.close(fig)

# Figure 5: bias sensitivity
bs = pd.read_csv(T / "bias_sensitivity.csv")
fig, ax = plt.subplots(figsize=(6.0, 3.8))
for ep, col, ls in (("ORR (CR+PR)", C5, "-"), ("Grade 3-4 TRAE", "#D55E00", "--"), ("Grade>=3 neutrophil decreased", "#009E73", "-.")):
    g = bs[bs.endpoint == ep]
    ax.plot(g.bias_logit, g.p_5_gt_4, color=col, ls=ls, lw=2, label=ep.replace("Grade>=3", "Grade ≥3"))
ax.axhline(0.5, color=CK, lw=0.8, ls=":")
ax.set_xlabel("Shift b removed from the 5 mg/kg cohort (logit scale; b > 0: observed 5 mg/kg rate overstated,\ni.e. ORR looks better but toxicity looks worse; b < 0: understated)", fontsize=8)
ax.set_ylabel("P(true 5 mg/kg rate > 4 mg/kg rate)")
ax.set_title("Sensitivity to non-exchangeability of the cohorts", fontsize=9)
ax.legend(frameon=False, fontsize=8)
fig.tight_layout()
fig.savefig(F / "fig5_bias_sensitivity.png")
plt.close(fig)
print("figures written")
