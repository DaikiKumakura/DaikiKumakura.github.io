# Companion materials: sacituzumab tirumotecan 4 vs 5 mg/kg

Scripts, inputs, tables, figures and logs for the article "Is it worth increasing sacituzumab tirumotecan from 4 mg/kg to 5 mg/kg?".

- `inputs/pk_tableS3.csv`: Table S3 of the supplementary material of Ouyang et al., J Hematol Oncol 2025;18:61 (doi:10.1186/s13045-025-01705-2), extracted by `analysis/00_extract_pk_table_s3.py` from the publisher's Word file (not bundled).
- `inputs/clinical_phase2_tnbc.csv`: counts transcribed from Tables 4 and 5 of the same article. See `inputs/PROVENANCE.md`.
- Run (Python 3.12, numpy, pandas, scipy, matplotlib; seed 20261107): `python analysis/01_pk_dose_proportionality.py && python analysis/02_bayes_efficacy_safety.py && python analysis/03_figures.py`.

Exploratory, summary-level analysis of non-randomized cohorts; the results are not causal effects of the dose increase.
