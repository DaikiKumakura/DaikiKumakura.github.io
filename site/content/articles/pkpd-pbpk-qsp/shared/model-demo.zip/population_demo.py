"""Analytic conditional PopPK distributions; no estimation or clinical data."""
from pathlib import Path
import csv
import json
import numpy as np
from scipy.stats import norm
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
ROOT=Path(__file__).resolve().parent
PARAMS={'dose_mg':100.,'volume_l':10.,'cl70_l_h':1.,'weight_exponent':.75,'eta_sd':.25,'weights_kg':[50.,70.,100.]}

def typical_cl(weight):
    return PARAMS['cl70_l_h']*(weight/70.)**PARAMS['weight_exponent']

def concentration_quantile(t, weight, p):
    # C decreases with CL, so its p quantile uses CL's (1-p) quantile.
    cl=typical_cl(weight)*np.exp(PARAMS['eta_sd']*norm.ppf(1-p))
    return PARAMS['dose_mg']/PARAMS['volume_l']*np.exp(-cl/ PARAMS['volume_l']*np.asarray(t))

def main():
    for folder in ('figures','results'): (ROOT/folder).mkdir(exist_ok=True)
    plt.rcParams.update({'font.size':12,'axes.spines.top':False,'axes.spines.right':False})
    t=np.linspace(0,48,961)
    fig,axes=plt.subplots(3,1,figsize=(7,9),sharex=True,sharey=True,layout='constrained')
    rows=[]; bands=[]
    for ax,w in zip(axes,PARAMS['weights_kg']):
        lo=concentration_quantile(t,w,.1); med=concentration_quantile(t,w,.5); hi=concentration_quantile(t,w,.9)
        ax.fill_between(t,lo,hi,color='#0072B2',alpha=.14,label='10th–90th percentile')
        ax.plot(t,med,color='#0072B2',lw=2.2,label='Conditional median')
        ax.set(title=f'Body weight {w:g} kg',ylabel='Concentration (mg/L)',ylim=(0,10.5)); ax.legend(frameon=False,fontsize=10)
        rows.append({'weight_kg':w,'typical_cl_l_h':typical_cl(w),'c24_p10_mg_l':float(concentration_quantile(24,w,.1)),'c24_median_mg_l':float(concentration_quantile(24,w,.5)),'c24_p90_mg_l':float(concentration_quantile(24,w,.9))})
        bands.extend(zip(np.full_like(t,w),t,lo,med,hi))
    axes[-1].set_xlabel('Time after one hypothetical IV dose (h)')
    fig.savefig(ROOT/'figures/population-variability.png',dpi=180); plt.close(fig)
    with (ROOT/'results/population-summary.csv').open('w',newline='',encoding='utf-8') as h:
        wr=csv.DictWriter(h,fieldnames=list(rows[0])); wr.writeheader(); wr.writerows(rows)
    with (ROOT/'results/population-bands.csv').open('w',newline='',encoding='utf-8') as h:
        wr=csv.writer(h); wr.writerow(['weight_kg','time_h','p10_mg_l','median_mg_l','p90_mg_l']); wr.writerows(bands)
    summary={'assumed_parameters':PARAMS,'results':rows,'cl_geometric_cv_percent':100*np.sqrt(np.expm1(PARAMS['eta_sd']**2)),'interpretation':'Conditional between-person distribution at fixed parameters; not confidence interval, observed-data VPC, or fitted NLME model. No residual error or weight-volume relation.'}
    (ROOT/'results/population-summary.json').write_text(json.dumps(summary,indent=2)+'\n',encoding='utf-8'); print(json.dumps(rows,indent=2))

if __name__=='__main__': main()
