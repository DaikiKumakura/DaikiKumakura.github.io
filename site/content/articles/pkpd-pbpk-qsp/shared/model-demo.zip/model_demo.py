"""Original pedagogical diagrams and a hypothetical PK/PD simulation."""
from pathlib import Path
import json
import csv
import numpy as np
from scipy.integrate import solve_ivp
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch

ROOT=Path(__file__).resolve().parent
PARAMS={'dose_mg':100.,'volume_l':10.,'clearance_l_h':1.,'ec50_mg_l':2.,'turnover_h_inv':.05,'duration_h':48.}
BLUE,ORANGE='#0072B2','#D55E00'

def concentration(t, dose=PARAMS['dose_mg'], volume=PARAMS['volume_l'], clearance=PARAMS['clearance_l_h']):
    return dose/volume*np.exp(-clearance/volume*np.asarray(t))

def direct(c, ec50=PARAMS['ec50_mg_l']):
    return np.asarray(c)/(ec50+np.asarray(c))

def simulate(times, rate=PARAMS['turnover_h_inv'], rtol=1e-10, atol=1e-12):
    t=np.asarray(times,dtype=float)
    sol=solve_ivp(lambda x,y: [rate*(float(direct(concentration(x)))-y[0])], [0,float(t[-1])], [0.], t_eval=t, rtol=rtol,atol=atol)
    assert sol.success
    return sol.y[0]

def diagram():
    fig,ax=plt.subplots(figsize=(8,8)); ax.set_xlim(0,10); ax.set_ylim(0,10); ax.axis('off')
    def box(x,y,w,h,label,blue=False):
        ax.add_patch(FancyBboxPatch((x,y),w,h,boxstyle='round,pad=0.08',facecolor='white',edgecolor=BLUE if blue else '#555555',linewidth=1.6))
        ax.text(x+w/2,y+h/2,label,ha='center',va='center',fontsize=12,color='#222222')
    def arrow(x,y,xx,yy):
        ax.annotate('',xy=(xx,yy),xytext=(x,y),arrowprops={'arrowstyle':'->','color':'#555555','lw':1.5})
    ax.text(.2,9.65,'Different questions, connected models',fontsize=18,va='top')
    ax.text(.2,8.9,'PK/PD: dose, exposure and response',fontsize=14)
    for x,label in ((.3,'Dose'),(3.6,'Exposure\n(PK)'),(7.,'Response\n(PD)')): box(x,7.55,2.5,.95,label,x<7)
    arrow(2.85,8.02,3.5,8.02); arrow(6.15,8.02,6.9,8.02)
    ax.text(.2,6.75,'PBPK: physiology within the PK component',fontsize=14)
    box(.3,4.55,2.5,1.5,'Drug properties\n+ physiology',True)
    box(3.6,4.55,2.5,1.5,'Blood flow\nOrgans / tissues\nADME',True)
    box(7.,4.55,2.5,1.5,'Plasma / tissue\nconcentrations',True)
    arrow(2.85,5.3,3.5,5.3); arrow(6.15,5.3,6.9,5.3)
    ax.text(.2,3.65,'QSP: drug action within a biological system',fontsize=14)
    box(.3,1.5,2.5,1.5,'Exposure\n(PK or PBPK)',True)
    box(3.6,1.5,2.5,1.5,'Target / pathway\nCell interactions\nDisease processes')
    box(7.,1.5,2.5,1.5,'Biomarkers\nEfficacy / safety')
    arrow(2.85,2.25,3.5,2.25); arrow(6.15,2.25,6.9,2.25)
    ax.text(.3,.55,'Schematic, not a complexity ladder. Feedback can couple PK and PD.',fontsize=11)
    fig.savefig(ROOT/'figures/model-relationships.png',dpi=180,bbox_inches='tight'); plt.close(fig)

def main():
    for folder in ('figures','results'): (ROOT/folder).mkdir(exist_ok=True)
    plt.rcParams.update({'font.size':12,'axes.spines.top':False,'axes.spines.right':False})
    diagram()
    t=np.linspace(0,PARAMS['duration_h'],961)
    c=concentration(t); e=direct(c); r=simulate(t)
    fig,ax=plt.subplots(2,1,figsize=(7,7),layout='constrained',sharex=True)
    ax[0].plot(t,c,color=BLUE,lw=2.5); ax[0].set(ylabel='Concentration (mg/L)',title='One hypothetical PK profile',ylim=(0,10.5))
    ax[1].plot(t,e,color=BLUE,lw=2.5,label='Direct response')
    ax[1].plot(t,r,color=ORANGE,ls='--',lw=2.5,label='Delayed response')
    ax[1].set(xlabel='Time after dose (h)',ylabel='Normalized response (a.u.)',title='Different PD assumptions',ylim=(0,1)); ax[1].legend(frameon=False)
    fig.savefig(ROOT/'figures/same-pk-different-pd.png',dpi=180); plt.close(fig)
    with (ROOT/'results/trajectories.csv').open('w',newline='',encoding='utf-8') as h:
        w=csv.writer(h); w.writerow(['time_h','concentration_mg_l','direct_response','delayed_response']); w.writerows(zip(t,c,e,r))
    metrics={'parameters':PARAMS,'direct_peak_h':float(t[np.argmax(e)]),'direct_peak':float(e.max()),'delayed_peak_h':float(t[np.argmax(r)]),'delayed_peak':float(r.max()),'pk_auc_0_inf_mg_h_l':PARAMS['dose_mg']/PARAMS['clearance_l_h']}
    (ROOT/'results/summary.json').write_text(json.dumps(metrics,indent=2)+'\n',encoding='utf-8'); print(json.dumps(metrics,indent=2))

if __name__=='__main__': main()
