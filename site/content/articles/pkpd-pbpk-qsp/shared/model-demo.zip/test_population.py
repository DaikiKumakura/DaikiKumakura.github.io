import unittest
import numpy as np
from population_demo import concentration_quantile,typical_cl

class PopulationTests(unittest.TestCase):
    def test_reference_clearance(self): self.assertEqual(typical_cl(70),1)
    def test_initial_quantiles_coincide(self):
        for p in (.1,.5,.9): self.assertEqual(concentration_quantile(0,70,p),10)
    def test_median_matches_typical_curve(self):
        t=np.array([1,12,24]); np.testing.assert_allclose(concentration_quantile(t,70,.5),10*np.exp(-.1*t))
    def test_quantile_order(self):
        t=np.linspace(0,48,100); lo=concentration_quantile(t,70,.1); med=concentration_quantile(t,70,.5); hi=concentration_quantile(t,70,.9)
        self.assertTrue(np.all((lo<=med)&(med<=hi)))
    def test_weight_effect(self):
        self.assertGreater(typical_cl(100),typical_cl(50)); self.assertLess(concentration_quantile(24,100,.5),concentration_quantile(24,50,.5))

if __name__=='__main__': unittest.main()
