import unittest
import numpy as np
from scipy.integrate import quad
from model_demo import concentration,direct,simulate

class DemoTests(unittest.TestCase):
    def test_iv_initial_condition(self): self.assertEqual(concentration(0),10)
    def test_auc_dose_over_clearance(self):
        self.assertAlmostEqual(quad(lambda t: float(concentration(t)),0,np.inf)[0],100,places=7)
    def test_pd_half_max(self): self.assertEqual(float(direct(2)),.5)
    def test_delayed_response_initial_and_bounds(self):
        r=simulate(np.linspace(0,48,961)); self.assertEqual(r[0],0); self.assertTrue(np.all((r>=0)&(r<=1)))
    def test_delayed_peak_is_after_dose(self):
        t=np.linspace(0,48,961); self.assertGreater(t[np.argmax(simulate(t))],0)
    def test_numerical_convergence(self):
        t=np.linspace(0,48,961); np.testing.assert_allclose(simulate(t,rtol=1e-8,atol=1e-10),simulate(t),atol=1e-7)
    def test_ode_matches_convolution(self):
        t=np.array([0.,1.,12.,48.]); r=simulate(t)
        ref=[quad(lambda u:.05*np.exp(-.05*(x-u))*float(direct(concentration(u))),0,x,epsabs=1e-11)[0] for x in t]
        np.testing.assert_allclose(r,ref,atol=1e-8)

if __name__=='__main__': unittest.main()
