# PK/PD, PBPK and QSP illustrations

Original teaching illustrations. No patient data or real-drug predictions.
Executed with Python 3.12.4 and the pinned dependencies in requirements.txt.
Run `python model_demo.py`, then `python -m unittest test_demo.py -q`.
Run `python population_demo.py` for the additional population illustration.
Run `python -m unittest discover -p 'test_*.py' -q` for all tests.
Three figures and CSV/JSON files regenerate without external data or randomness.
The PK/PD example uses a hypothetical instantaneous IV dose, one-compartment
linear elimination, direct saturable response and a normalized turnover increment.
Parameters and time grid are recorded in the script and result files.
This code does not implement or validate an empirical PBPK or QSP model.
The population illustration assumes lognormal clearance, a fixed weight effect
and volume, no residual error and fixed parameters. Its percentile bands are not
confidence intervals, an observed-data VPC or fitted NLME results.
