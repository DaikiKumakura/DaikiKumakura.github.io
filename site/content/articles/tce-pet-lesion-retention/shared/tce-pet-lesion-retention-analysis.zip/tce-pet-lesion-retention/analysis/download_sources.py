from pathlib import Path
import urllib.request,hashlib
ROOT=Path(__file__).resolve().parents[1]
d=ROOT/'data/raw';d.mkdir(parents=True,exist_ok=True)
b=urllib.request.urlopen('https://ndownloader.figshare.com/files/39921902',timeout=120).read()
assert hashlib.sha256(b).hexdigest()=='3f2b91cc4d410310cd8e4710515b33e6dbde4831d8c274d3b93fff87b82b50a4'
(d/'table-s3.docx').write_bytes(b)
print('Supplementary Table S3 acquired and hash verified')
