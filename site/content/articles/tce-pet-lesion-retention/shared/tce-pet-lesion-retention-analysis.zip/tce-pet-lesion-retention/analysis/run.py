"""Parse source Table S3 and benchmark nominal 24-h lesion SUVmax predictions."""
from pathlib import Path
import csv
import hashlib
import json
import zipfile
import xml.etree.ElementTree as ET
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

ROOT=Path(__file__).resolve().parents[1]
SEED=20261028
NS={'w':'http://schemas.openxmlformats.org/wordprocessingml/2006/main'}
METHODS=['Carry 6 h','Continue early log slope','Other-patient retention']


def parse_source() -> list[dict]:
    source=ROOT/'data/raw/table-s3.docx'
    with zipfile.ZipFile(source) as z:
        tree=ET.fromstring(z.read('word/document.xml'))
    tables=tree.findall('.//w:tbl',NS)
    table=next(t for t in tables if 'Supplementary Table S3' in ''.join(t.itertext()))
    rows=[]; patient=None
    for tr in table.findall('w:tr',NS):
        cells=[''.join(c.itertext()).strip() for c in tr.findall('w:tc',NS)]
        if len(cells)!=7 or not cells[1].isdigit():continue
        if cells[0]:patient=int(cells[0])
        assert patient is not None
        numeric=[]
        for text in cells[4:7]:numeric.append(float(text) if text not in ['ND','NE',''] else None)
        complete=all(x is not None and x>0 for x in numeric)
        rows.append(dict(patient=patient,lesion=int(cells[1]),organ=cells[2],long_axis_mm=float(cells[3]) if cells[3] else None,
                         suv3=numeric[0],suv6=numeric[1],suv24=numeric[2],source3=cells[4],source6=cells[5],source24=cells[6],
                         complete=complete,exclusion='' if complete else ('3h not done' if cells[4]=='ND' else '6h technically not evaluable')))
    assert len(rows)==37 and len({(r['patient'],r['lesion']) for r in rows})==37
    return rows


def predict(data: list[dict]) -> list[dict]:
    """The retention factor never uses any lesion from the held-out patient."""
    patients=sorted({r['patient'] for r in data}); out=[]
    for test in patients:
        others=[p for p in patients if p!=test]
        # Equal patient weights; many lesions from one person do not dominate.
        logs=[np.mean([np.log(r['suv24']/r['suv6']) for r in data if r['patient']==p]) for p in others]
        factor=float(np.exp(np.mean(logs)))
        for r in data:
            if r['patient']!=test:continue
            predictions=[r['suv6'],r['suv6']*(r['suv6']/r['suv3'])**6,r['suv6']*factor]
            for method,pred in zip(METHODS,predictions):
                out.append(dict(patient=test,lesion=r['lesion'],organ=r['organ'],method=method,suv3=r['suv3'],suv6=r['suv6'],observed24=r['suv24'],
                                predicted24=float(pred),log_error=float(np.log(pred/r['suv24'])),retention_factor=factor if method==METHODS[2] else None,
                                calibration_patients=','.join(map(str,others)) if method==METHODS[2] else 'none'))
    return out


def scores(predictions: list[dict]) -> tuple[list[dict],list[dict]]:
    bypatient=[];overall=[]
    patients=sorted({r['patient'] for r in predictions})
    for method in METHODS:
        mses=[];maes=[]; biases=[]
        for p in patients:
            r=[z for z in predictions if z['patient']==p and z['method']==method]
            e=np.array([z['log_error'] for z in r]); err=np.array([z['predicted24']-z['observed24'] for z in r])
            mses.append(float(np.mean(e**2)));maes.append(float(np.mean(np.abs(err))));biases.append(float(e.mean()))
            bypatient.append(dict(patient=p,method=method,n_lesions=len(r),log_rmse=float(np.sqrt(np.mean(e**2))),suv_mae=float(np.abs(err).mean()),mean_log_bias=float(e.mean())))
        overall.append(dict(method=method,n_patients=len(patients),n_lesions=sum(r['method']==method for r in predictions),patient_equal_log_rmse=float(np.sqrt(np.mean(mses))),
                            patient_equal_suv_mae=float(np.mean(maes)),patient_equal_log_bias=float(np.mean(biases))))
    return bypatient,overall


def write_csv(path: Path, rows: list[dict]) -> None:
    with path.open('w',newline='',encoding='utf8') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)


def save(fig,name):
    fig.tight_layout();fig.savefig(ROOT/f'outputs/figures/{name}.svg');fig.savefig(ROOT/f'outputs/figures/{name}.png',dpi=170);plt.close(fig)


def main():
    for d in ['data/processed','outputs/tables','outputs/figures']:(ROOT/d).mkdir(parents=True,exist_ok=True)
    allrows=parse_source();data=[r for r in allrows if r['complete']]
    assert len(data)==16 and sorted({r['patient'] for r in data})==[2,3,5,8]
    pred=predict(data);patient,overall=scores(pred)
    write_csv(ROOT/'data/processed/all-lesions.csv',allrows);write_csv(ROOT/'data/processed/complete-lesions.csv',data)
    write_csv(ROOT/'outputs/tables/predictions.csv',pred);write_csv(ROOT/'outputs/tables/patient-scores.csv',patient);write_csv(ROOT/'outputs/tables/overall-scores.csv',overall)
    audit=[]
    for p in sorted({r['patient'] for r in allrows}):
        rr=[r for r in allrows if r['patient']==p];audit.append(dict(patient=p,total_lesions=len(rr),complete=sum(r['complete'] for r in rr),excluded=sum(not r['complete'] for r in rr),reason=next((r['exclusion'] for r in rr if r['exclusion']),'none')))
    write_csv(ROOT/'outputs/tables/cohort-audit.csv',audit)
    plt.rcParams.update({'font.size':10,'svg.fonttype':'none'})
    fig,axes=plt.subplots(1,3,figsize=(11,3.7),sharey=True)
    colors={2:'#0072B2',3:'#D55E00',5:'#009E73',8:'#CC79A7'}
    for ax,method in zip(axes,METHODS):
        rr=[r for r in pred if r['method']==method]
        for p in colors:
            a=[r for r in rr if r['patient']==p];ax.scatter([r['observed24'] for r in a],[r['predicted24'] for r in a],color=colors[p],label=f'Patient {p}',s=30)
        ax.plot([.5,200000],[.5,200000],'k--',lw=.8)
        ax.set(xscale='log',yscale='log',xlim=(.8,5),ylim=(.002,200000),xlabel='Observed 24-h SUVmax',title=method)
        ax.grid(alpha=.2)
    axes[0].set_ylabel('Predicted 24-h SUVmax');axes[2].legend(frameon=False,fontsize=8)
    fig.suptitle('16 lesions from 4 patients; all predictions retained on common scales');save(fig,'prediction-scatter')
    fig,ax=plt.subplots(figsize=(8,4))
    markers=['o','s','^']
    for i,method in enumerate(METHODS):
        rr=[r for r in patient if r['method']==method]
        ax.plot([r['patient'] for r in rr],[r['log_rmse'] for r in rr],marker=markers[i],label=method)
    ax.set(xticks=[2,3,5,8],xlabel='Held-out patient',ylabel='Root mean squared log(predicted / observed)')
    ax.legend(frameon=False);ax.grid(alpha=.2);save(fig,'patient-error')
    fig,axes=plt.subplots(1,4,figsize=(11,3.2),sharey=True)
    for ax,p in zip(axes,[2,3,5,8]):
        for r in data:
            if r['patient']==p:ax.plot([3,6,24],[r['suv3'],r['suv6'],r['suv24']],'o-',alpha=.8,markersize=3)
        ax.set(title=f'Patient {p}',xticks=[3,6,24],xlabel='Nominal hour');ax.grid(alpha=.2)
    axes[0].set_ylabel('Observed lesion SUVmax');fig.suptitle('Same lesion over time; different lesions are not different patients');save(fig,'lesion-trajectories')
    rng=np.random.default_rng(SEED);ranges={m:[] for m in METHODS}
    for _ in range(500):
        perturbed=[dict(r,**{k:float(r[k]+rng.uniform(-.05,.05)) for k in ['suv3','suv6','suv24']}) for r in data]
        _,ss=scores(predict(perturbed))
        for r in ss:ranges[r['method']].append(r['patient_equal_log_rmse'])
    sensitivity=[dict(method=m,min_log_rmse=float(min(v)),max_log_rmse=float(max(v)),scenario='independent +/-0.05 SUV input perturbations; not confidence interval') for m,v in ranges.items()]
    write_csv(ROOT/'outputs/tables/rounding-sensitivity.csv',sensitivity)
    # Post-hoc influence check; the main result retains every complete lesion.
    without_max=[r for r in data if not (r['patient']==3 and r['lesion']==4)]
    _,influence=scores(predict(without_max));write_csv(ROOT/'outputs/tables/influence-exclusion.csv',influence)
    summary={'id':'STCE-19','source_rows':len(allrows),'source_patients':len({r['patient'] for r in allrows}),'complete_lesions':len(data),'complete_patients':4,
             'cohort':audit,'scores':overall,'patient_scores':patient,'rounding_sensitivity':sensitivity,
             'posthoc_without_patient3_lesion4':influence,
             'largest_extrapolation':max(pred,key=lambda r:r['predicted24']),
             'source_sha256':hashlib.sha256((ROOT/'data/raw/table-s3.docx').read_bytes()).hexdigest()}
    (ROOT/'outputs/results.json').write_text(json.dumps(summary,indent=2),encoding='utf8');print(json.dumps(summary,indent=2))


if __name__=='__main__':main()
