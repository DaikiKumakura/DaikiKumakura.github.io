import importlib.util
from pathlib import Path
import unittest
import math

ROOT=Path(__file__).resolve().parents[1]
spec=importlib.util.spec_from_file_location('analysis',ROOT/'analysis/run.py')
m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)


class AnalysisTests(unittest.TestCase):
    def test_source_grain_and_exclusions(self):
        rows=m.parse_source();self.assertEqual(len(rows),37)
        data=[r for r in rows if r['complete']]
        self.assertEqual(len(data),16);self.assertEqual({r['patient'] for r in data},{2,3,5,8})
        self.assertTrue(all(r['suv3'] is None for r in rows if r['patient']==1))
        self.assertTrue(all(r['suv6'] is None for r in rows if r['patient']==7))

    def test_heldout_outcomes_do_not_enter_factor(self):
        data=[r for r in m.parse_source() if r['complete']]
        baseline=[r for r in m.predict(data) if r['patient']==2 and r['method']==m.METHODS[2]]
        changed=[dict(r,suv24=r['suv24']*100 if r['patient']==2 else r['suv24']) for r in data]
        after=[r for r in m.predict(changed) if r['patient']==2 and r['method']==m.METHODS[2]]
        self.assertEqual([r['predicted24'] for r in baseline],[r['predicted24'] for r in after])
        self.assertTrue(all(r['calibration_patients']=='3,5,8' for r in baseline))

    def test_fixed_slope_constant_and_rising_signal(self):
        data=[dict(patient=p,lesion=1,organ='example',suv3=2.,suv6=2.,suv24=2.) for p in range(4)]
        self.assertTrue(all(math.isclose(r['predicted24'],2) for r in m.predict(data)))

    def test_patient_equal_scoring(self):
        predictions=[]
        for method in m.METHODS:
            for p,n,e in [(1,10,0.),(2,1,2.)]:
                for i in range(n):predictions.append(dict(patient=p,lesion=i,method=method,log_error=e,predicted24=math.exp(e),observed24=1.))
        _,overall=m.scores(predictions)
        self.assertTrue(all(math.isclose(r['patient_equal_log_rmse'],math.sqrt(2)) for r in overall))


if __name__=='__main__':unittest.main()
