from math import sqrt

for x in (.1,1,10):
    for b in (1,10):
        m=4
        z=x+b
        monod=m*x/z
        u=2*m*x/(z+sqrt(z*z+4*m*x))
        err=(monod-u)/monod
        assert abs(err-u/(z+u))<1e-12
        print(f"aS={x:g}, b={b:g}: Monod={monod:.6f}, root={u:.6f}, relative_error={err:.6f}")
