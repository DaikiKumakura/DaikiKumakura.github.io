Run python analysis.py with Python 3. No external package is required. Model or published aggregate inputs are declared in the script.
