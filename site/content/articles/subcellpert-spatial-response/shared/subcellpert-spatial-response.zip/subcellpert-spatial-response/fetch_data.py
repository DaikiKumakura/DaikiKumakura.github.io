"""Fetch only the public sample needed for the coordinate diagnostic."""
from pathlib import Path
import urllib.request,hashlib,json
HERE=Path(__file__).resolve().parent
REV='a57b684efe607242a47decb941de4efa7e11954b'
BASE=f'https://huggingface.co/datasets/king159/SubcellPert/resolve/{REV}/'
def main():
    expected=json.loads((HERE/'inputs/provenance.json').read_text())['files']
    h=HERE/'sources';h.mkdir(exist_ok=True)
    for rel,digest in expected.items():
        rel=rel.replace(chr(92),'/')
        target=h/rel;target.parent.mkdir(parents=True,exist_ok=True)
        if rel.startswith('sample1/'):
            remote='datasets/perturbfish_astrocytes/population/shards/0000-sample1/'+target.name
        else:
            remote='datasets/perturbfish_astrocytes/population/manifest.json'
        if not target.exists():urllib.request.urlretrieve(BASE+remote,target)
        if hashlib.sha256(target.read_bytes()).hexdigest()!=digest:raise ValueError(f'Hash mismatch: {rel}')
        print(rel,'verified')
if __name__=='__main__':main()
