from pathlib import Path
import json
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
HERE=Path(__file__).resolve().parent
def main():
    d=json.loads((HERE/'results/summary.json').read_text());rows=d['sensitivity'][0]['by_gene'];genes=sorted({r['gene'] for r in rows})
    fig,axes=plt.subplots(1,2,figsize=(9,4.6));fig.subplots_adjust(left=.09,right=.98,top=.78,bottom=.24,wspace=.32)
    for ax,key,title in zip(axes,['median_sliced_w1','median_radial_w1'],['2D sliced W1','Radial W1 about the all-RNA origin']):
        for kind,offset,color,label in [('bootstrap',-.18,'#aec5ce','Empirical resampling'),('gaussian',.18,'#276880','Gaussian replacement')]:
            values=[next(r[key] for r in rows if r['gene']==g and r['kind']==kind) for g in genes]
            ax.bar([i+offset for i in range(len(genes))],values,width=.35,color=color,label=label)
        ax.set_xticks(range(len(genes)),genes,rotation=30,ha='right');ax.set_title(title,fontsize=10);ax.set_ylabel('Median error (normalized coordinate units)');ax.spines[['top','right']].set_visible(False)
    handles,labels=axes[0].get_legend_handles_labels()
    fig.legend(handles,labels,loc='upper center',bbox_to_anchor=(.5,.93),ncol=2,frameon=False,fontsize=9)
    fig.suptitle('Same RNA counts, centroids and covariance; different arrangements',fontsize=12)
    fig.text(.09,.035,'PF-Astro sample1, ctrl + ASXL3. Five draws averaged per cell-gene cloud; >=20 RNA.\nBoth replacements match target moments. Neither is a perturbation predictor.',fontsize=8)
    (HERE/'figures').mkdir(exist_ok=True);fig.savefig(HERE/'figures/moment-blindspot.png',dpi=180);plt.close(fig)
if __name__=='__main__':main()
