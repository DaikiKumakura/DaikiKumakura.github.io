import unittest
import numpy as np
from geometry import match_moments,moments,scores
class Checks(unittest.TestCase):
    def test_moment_match(self):
        r=np.random.default_rng(17);x=r.standard_t(5,size=(200,2))@np.array([[2.,.3],[0.,1.]])+[1,-2]
        y=match_moments(r.normal(size=x.shape),x)
        a,b=moments(x);c,d=moments(y);np.testing.assert_allclose(a,c,atol=1e-12);np.testing.assert_allclose(b,d,atol=1e-12)
        self.assertGreater(scores(x,y)['sliced_w1'],.01)
    def test_same_moments_do_not_fix_distribution(self):
        # Cross and diagonal four-point clouds have exactly the same mean/covariance.
        x=np.array([[1.,0.],[-1,0],[0,1],[0,-1]])
        y=np.array([[1.,1.],[-1,1],[1,-1],[-1,-1]])/np.sqrt(2)
        s=scores(x,y);self.assertLess(s['centroid_error'],1e-12);self.assertLess(s['covariance_error'],1e-12)
        self.assertGreater(s['sliced_w1'],.1)
        # Radius alone cannot distinguish angular rearrangement.
        self.assertLess(s['radial_w1'],1e-12)
    def test_translation(self):
        x=np.array([[0.,0],[1,0],[0,1]]);y=x+[2.,0.]
        self.assertAlmostEqual(scores(x,y)['centroid_error'],2.)
    def test_identity(self):
        x=np.array([[0.,0],[1,0],[0,1]])
        self.assertEqual(scores(x,x)['sliced_w1'],0.)
    def test_reject_mismatched_counts(self):
        with self.assertRaises(ValueError):scores(np.ones((3,2)),np.ones((4,2)))
if __name__=='__main__':unittest.main()
