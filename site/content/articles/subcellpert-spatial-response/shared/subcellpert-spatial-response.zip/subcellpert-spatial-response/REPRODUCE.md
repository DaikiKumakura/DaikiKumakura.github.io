# Reproducing the independent coordinate diagnostic

The paper is Wang J et al., SubcellPert: Benchmarking Subcellular Perturbation Prediction, https://doi.org/10.64898/2026.10.11.758305, v1 posted 2026-10-17. The released dataset is https://huggingface.co/datasets/king159/SubcellPert, revision a57b684efe607242a47decb941de4efa7e11954b. PF-Astro is reconstructed from Perturb-FISH measurements (Binan et al., 2025); see the paper's data-curation appendix for the primary measurement source. Credit both the measurements and the benchmark reconstruction. The paper is CC BY 4.0 (https://creativecommons.org/licenses/by/4.0/); source data and third-party code retain their own terms. The licence here covers only original diagnostic code and documentation.

This is not a model prediction or an Oracle/Joint benchmark rerun. The artificial clouds use the observed target mean AND covariance, which a predictor would not have. No training/test generalisation or intervention effect is claimed. We pool ctrl and ASXL3 within sample1 for a metric diagnostic, not for a group comparison.

## Recompute summaries and figure

Python 3.12; matplotlib 3.9.1 was used for plotting.

    python analysis.py
    python plot.py

inputs/diagnostics.csv contains derived numerical facts for 4,681 cell-gene clouds (1,194 cells), two replacement types, five draws: 46,810 rows. Five draws are averaged within each cloud, then medians are taken over clouds separately for each gene/type. Cutoffs 20/40/80 RNA are reported with sample sizes; they change the population included. No p-values or biological confidence intervals are estimated. Cell-gene clouds and repeats are not independent biological replicates.

## Recreate the diagnostics from coordinates

Additional dependencies tested: numpy 1.26.4, pandas 2.2.2, pyarrow 23.0.1.

    python fetch_data.py
    python extract.py
    python analysis.py
    python -m unittest test_geometry.py
    python plot.py

fetch_data.py downloads only a manifest and sample1 metadata/arrays, about 38 MB in total. It verifies the exact hashes in provenance.json and does not use credentials. Raw third-party observations remain under sources/ and are not part of this archive. Do not interpret a published dataset README's authenticated-download example as a mandatory gating condition: this snapshot was accessible anonymously.

sample1 has 3,532 cells / 4,247,341 RNA; selection is ctrl (838) and ASXL3 (361). Top five genes are chosen by total control RNA before examining errors: VIM, HIF1A, FKBP10, ITGAV, CDC37. A cloud must contain >=20 RNA. Five of the 1,199 selected cells have no qualifying cloud. Source coordinates already use the per-cell all-RNA centroid and RMS radius. They are 2D relative coordinates, not nuclear-boundary or absolute-distance measurements.

For each selected cloud we draw standard-normal points and an empirical bootstrap cloud, each of the same size. Both are affinely matched to target mean and population covariance (denominator n), using symmetric positive-definite matrix square roots. Covariance eigenvalues <=1e-12 are rejected. The RNG is numpy default_rng(758305), and the extraction follows released cell/gene order; exact floating-point details can vary with numerical libraries. Original points are never shuffled out of their cell/gene labels.

geometry.scores computes mean empirical one-dimensional W1 over 32 directions in [0,pi), plus radial W1 of distance to the original all-RNA origin. Clouds have equal point count and uniform molecular weights, so each 1D W1 is the mean absolute difference of sorted coordinates. The official benchmark instead evaluates population measures with its own unit/cell/gene weighting and coverage conventions; our scores are not its official scores. Euclidean centroid error and Frobenius covariance error check moment preservation.

Bootstrap scores use the observed cloud itself, followed by moment matching. They are a finite-resampling comparison, NOT independent technical replicates, measurement-noise estimates or confidence intervals. Gaussian replacements are not constrained by cell boundaries. The exercise checks what count/centroid/covariance summaries cannot identify, not whether the synthetic arrangements are biologically valid. Minimum-count sensitivity does not remove one-sample limitations.

Tests independently check moment preservation, a cross-versus-diagonal exact counterexample, translation and identity, and count-mismatch rejection. No original paper text or figure, raw molecular coordinates or trained weights are redistributed.
