"""Summarise coordinate stress tests; experimental units are not inferred from cells."""
from pathlib import Path
import csv,json,statistics as st
from collections import defaultdict
HERE=Path(__file__).resolve().parent
def summarize(rows,minimum=20):
    groups=defaultdict(list)
    for r in rows:
        if int(r['n'])>=minimum:groups[(r['cell_id'],r['condition'],r['gene'],r['kind'])].append(r)
    per=[]
    for (cell,condition,gene,kind),rs in sorted(groups.items()):
        assert len(rs)==5 and len({int(r['repeat']) for r in rs})==5
        per.append(dict(cell_id=cell,condition=condition,gene=gene,kind=kind,n=int(rs[0]['n']),
                        **{k:st.mean(float(r[k]) for r in rs) for k in ['sliced_w1','radial_w1','centroid_error','covariance_error']}))
    result=[]
    for gene in sorted({p['gene'] for p in per}):
        for kind in ['gaussian','bootstrap']:
            ps=[p for p in per if p['gene']==gene and p['kind']==kind]
            if not ps:continue
            result.append(dict(gene=gene,kind=kind,clouds=len(ps),cells=len({p['cell_id'] for p in ps}),
                               median_sliced_w1=st.median(p['sliced_w1'] for p in ps),median_radial_w1=st.median(p['radial_w1'] for p in ps)))
    return dict(minimum_rna=minimum,clouds=len({(p['cell_id'],p['gene']) for p in per}),
                cells=len({p['cell_id'] for p in per}),
                maximum_centroid_error=max(float(r['centroid_error']) for r in rows if int(r['n'])>=minimum),
                maximum_covariance_error=max(float(r['covariance_error']) for r in rows if int(r['n'])>=minimum),by_gene=result)
def main():
    with (HERE/'inputs/diagnostics.csv').open(encoding='utf-8') as f:rows=list(csv.DictReader(f))
    result={'scope':'Real-coordinate moment-preservation diagnostic, not a learned model benchmark or intervention-effect estimate',
            'sensitivity':[summarize(rows,n) for n in [20,40,80]]}
    (HERE/'results').mkdir(exist_ok=True);(HERE/'results/summary.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(result,indent=2))
if __name__=='__main__':main()
