"""Independent moment-matched geometry diagnostics; not a SubcellPert predictor."""
import numpy as np
def moments(x):
    center=x.mean(axis=0); y=x-center
    return center,y.T@y/len(x)
def root(cov,inverse=False):
    values,vectors=np.linalg.eigh(cov)
    if values.min()<=1e-12:raise ValueError('degenerate covariance')
    return (vectors*(1/np.sqrt(values) if inverse else np.sqrt(values)))@vectors.T
def match_moments(proposal,target):
    pm,pc=moments(proposal);tm,tc=moments(target)
    return (proposal-pm)@root(pc,True)@root(tc)+tm
def scores(x,y,directions=32):
    """Equal-mass empirical sliced W1 and radial W1, equal point counts."""
    if x.shape!=y.shape:raise ValueError('equal counts required')
    xm,xc=moments(x);ym,yc=moments(y)
    theta=np.arange(directions)*np.pi/directions
    v=np.array([np.cos(theta),np.sin(theta)])
    sw1=np.abs(np.sort(x@v,axis=0)-np.sort(y@v,axis=0)).mean()
    radial=np.abs(np.sort(np.linalg.norm(x,axis=1))-np.sort(np.linalg.norm(y,axis=1))).mean()
    return dict(centroid_error=float(np.linalg.norm(xm-ym)),covariance_error=float(np.linalg.norm(xc-yc)),sliced_w1=float(sw1),radial_w1=float(radial))
