"""Private raw-data extraction is reproducible from public URLs; no model is trained."""
from pathlib import Path
import csv,json,hashlib
import numpy as np
import pandas as pd
from geometry import match_moments,scores
HERE=Path(__file__).resolve().parent
def main():
    h=HERE/'sources';raw=h/'sample1'
    manifest=h/'hf-datasets-perturbfish_astrocytes-population-manifest.json'
    meta=json.loads(manifest.read_text());genes=meta['inventory']['genes']
    cells=pd.read_parquet(raw/'cells.parquet');cp=np.load(raw/'cell_gene_ptr.npy');rp=np.load(raw/'cell_rna_ptr.npy')
    ids=np.load(raw/'gene_ids.npy');counts=np.load(raw/'counts.npy');coords=np.load(raw/'coordinates.npy',mmap_mode='r')
    assert len(cp)==len(rp)==len(cells)+1
    assert int(cp[-1])==len(ids)==len(counts) and int(rp[-1])==len(coords)
    total=np.zeros(len(genes),dtype=np.int64)
    for i in cells.index[cells.condition=='ctrl']:
        a,b=cp[i:i+2];np.add.at(total,ids[a:b],counts[a:b])
    chosen=sorted(range(len(genes)),key=lambda i:(-total[i],genes[i]))[:5]
    rng=np.random.default_rng(758305);out=[];example=None
    for i,row in cells.iterrows():
        if row.condition not in ['ctrl','ASXL3']:continue
        a,b=map(int,cp[i:i+2]);start=int(rp[i]);assert int(counts[a:b].sum())==int(rp[i+1]-rp[i])
        for idx,n in zip(ids[a:b],counts[a:b]):
            n=int(n);x=np.asarray(coords[start:start+n],dtype=np.float64);start+=n
            if idx not in chosen or n<20:continue
            for repeat in range(5):
                for kind,proposal in [('gaussian',rng.standard_normal(x.shape)),('bootstrap',x[rng.integers(0,n,size=n)])]:
                    y=match_moments(proposal,x)
                    s=scores(x,y)
                    out.append(dict(cell_id=row.cell_id,condition=row.condition,gene=genes[idx],n=n,repeat=repeat,kind=kind,**s))
                    if example is None and kind=='gaussian' and genes[idx]==genes[chosen[0]] and row.condition=='ctrl':
                        example=dict(cell_id=row.cell_id,gene=genes[idx],n=n,observed=x.tolist(),gaussian=y.tolist())
    (HERE/'inputs').mkdir(exist_ok=True)
    with (HERE/'inputs/diagnostics.csv').open('w',newline='',encoding='utf-8') as f:
        w=csv.DictWriter(f,fieldnames=list(out[0]));w.writeheader();w.writerows(out)
    # Coordinates are kept private for visual QA. The public figure is our own diagnostic.
    (h/'example.json').write_text(json.dumps(example),encoding='utf-8')
    files=[manifest,*sorted(raw.iterdir())]
    provenance={'paper':'https://doi.org/10.64898/2026.10.11.758305','hf_revision':'a57b684efe607242a47decb941de4efa7e11954b','code_revision':'09d4043a06a8dbd4ed33e7fdae82cc30770e0935','dataset':'perturbfish_astrocytes; sample1 only','source_sample_cells':len(cells),'source_sample_molecules':len(coords),'selected_conditions':cells[cells.condition.isin(['ctrl','ASXL3'])].condition.value_counts().to_dict(),'selected_genes':[genes[i] for i in chosen],'selection':'Top 5 genes by total control RNA in this sample; retain cell-gene clouds with >=20 RNA; 5 fixed-seed Gaussian and moment-matched empirical bootstrap draws per cloud','seed':758305,'scope':'Measured-coordinate diagnostic with target moments supplied. Not a prediction, training/test split, Oracle reproduction or drug-effect inference.','files':{f.relative_to(h).as_posix():hashlib.sha256(f.read_bytes()).hexdigest() for f in files}}
    (HERE/'inputs/provenance.json').write_text(json.dumps(provenance,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({'genes':provenance['selected_genes'],'rows':len(out),'conditions':provenance['selected_conditions']}))
if __name__=='__main__':main()
