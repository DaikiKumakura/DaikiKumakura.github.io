"""Figures from results/ (run analysis.py first)."""
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parent
d = pd.read_csv(ROOT / "results/deals-with-ratios.csv").sort_values("upfront_share")
(ROOT / "figures").mkdir(exist_ok=True)
BLUE, ORANGE, GREY = "#0072B2", "#E69F00", "#777777"
col = [ORANGE if c == "ai_discovery" else BLUE for c in d.category]

fig, ax = plt.subplots(figsize=(8.4, 5.6), constrained_layout=True)
y = np.arange(len(d))
ax.scatter(d.upfront_share * 100, y, c=col, s=55, zorder=3)
alt = d[d.upfront_share_alt.notna()]
ax.scatter(alt.upfront_share_alt * 100, [list(d.deal).index(x) for x in alt.deal], facecolors="none", edgecolors="k", s=70, zorder=3,
           label="alternative upfront definition (e.g. incl. near-term payments)")
for yi, (a, b) in enumerate(zip(d.upfront_share, d.upfront_share_alt.fillna(d.upfront_share))):
    ax.plot([a * 100, b * 100], [yi, yi], color=GREY, linewidth=1, zorder=2)
ax.axvline(d.upfront_share.median() * 100, color=GREY, linestyle=":")
ax.set_yticks(y, [f"{n} (${t:,.0f}M)" for n, t in zip(d.deal, d.total_usd_m)], fontsize=8)
ax.set_xlabel("Upfront payment as % of the headline deal value")
ax.set_title(f"15 deals, upfront disclosed (median {d.upfront_share.median() * 100:.1f}%). Orange: AI discovery; blue: other", fontsize=9)
ax.legend(fontsize=8, loc="lower right")
fig.savefig(ROOT / "figures/01-upfront-share.png", dpi=150)

fig, ax = plt.subplots(figsize=(7, 5), constrained_layout=True)
ax.scatter(d.total_usd_m, d.upfront_usd_m, c=col, s=55, zorder=3)
xs = np.array([800, 20000])
for r in (0.02, 0.05, 0.10, 0.20):
    ax.plot(xs, xs * r, color=GREY, linestyle="--", linewidth=0.8)
    ax.annotate(f"{int(r * 100)}%", (xs[1], xs[1] * r), fontsize=8, color=GREY, xytext=(3, -3), textcoords="offset points")
for _, r in d.iterrows():
    ax.annotate(r.deal.split()[0], (r.total_usd_m, r.upfront_usd_m), fontsize=6.5, xytext=(3, 3), textcoords="offset points")
ax.set_xscale("log")
ax.set_yscale("log")
ax.set_xlabel("Headline deal value (USD million, log scale)")
ax.set_ylabel("Upfront payment (USD million, log scale)")
ax.set_title("Upfront versus headline value; dashed lines are constant upfront shares", fontsize=9)
fig.savefig(ROOT / "figures/02-upfront-vs-total.png", dpi=150)
print("figures written")
