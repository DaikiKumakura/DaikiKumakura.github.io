"""Checks of the ratio calculations."""
import numpy as np
import pandas as pd

import analysis as A


def test_summarise_known_values():
    s = A.summarise([0.01, 0.02, 0.03, 0.04, 0.10], np.random.default_rng(0))
    assert s["n"] == 5 and abs(s["median"] - 0.03) < 1e-12 and s["min"] == 0.01 and s["max"] == 0.10
    assert s["median_lo"] <= s["median"] <= s["median_hi"]


def test_deal_table_is_consistent():
    d = pd.read_csv(A.ROOT / "deals.csv")
    assert d.deal.is_unique and len(d) == 18
    ok = d[d.upfront_usd_m.notna()]
    assert (ok.upfront_usd_m < ok.total_usd_m).all()
    assert (d[d.upfront_alt_usd_m.notna()].upfront_alt_usd_m >= d[d.upfront_alt_usd_m.notna()].upfront_usd_m).all()
    assert d.source_url.str.startswith("http").all()


def test_risk_adjusted_share_is_larger_than_nominal():
    d = pd.read_csv(A.ROOT / "deals.csv").dropna(subset=["upfront_usd_m"])
    nominal = d.upfront_usd_m / d.total_usd_m
    adj = d.upfront_usd_m / (d.upfront_usd_m + A.LOA_PHASE1 * (d.total_usd_m - d.upfront_usd_m))
    assert (adj > nominal).all() and (adj <= 1).all()


def test_headline_numbers_reproduce():
    import json
    A.main.__wrapped__ if hasattr(A.main, "__wrapped__") else None
    s = pd.read_csv(A.ROOT / "results/upfront-share-summary.csv")
    assert abs(s["median"][0] - 0.0409) < 5e-4 and int(s["n"][0]) == 15
    info = json.load(open(A.ROOT / "results/summary.json"))
    assert info["disclosed"] == 15 and abs(info["pooled_share"] - 0.04957) < 5e-5


if __name__ == "__main__":
    for name, fn in list(globals().items()):
        if name.startswith("test_"):
            fn()
    print("all tests passed")
