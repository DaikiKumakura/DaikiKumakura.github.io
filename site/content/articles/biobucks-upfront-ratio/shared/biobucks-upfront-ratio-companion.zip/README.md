# 提携の前払金と「総額」：配布資料

記事「『総額150億ドル』のうち、前払金はいくらか：2026年秋の創薬提携18件を数える」の再実行用資料。

## 含むもの

- `deals.csv`：18件の提携（前払金、総額、定義、出典のURL、出典の種類）。手作業で集めた
- `analysis.py`, `test_analysis.py`, `figures.py`：集計、検査、図
- `validate.R`：Rによる再実装による再計算（同じ筆者による別実装）（前払金の割合と、群の中央値）
- `results/`, `figures/`

出典は、公開の発表や報道である。有料のデータベースは使っていない。数値は、出典の記載をそのまま写しており、出典の種類（公式発表、SEC提出書類、報道）を `source_type` に記録した。公式発表の全文を読めた提携は少ない。

## 実行

`python test_analysis.py && python analysis.py && python figures.py && Rscript validate.R`（Python 3.12、numpy、pandas、scipy、matplotlib；R 4.5.3、jsonlite）

選び方の偏り（前払金と総額の両方が公表された提携が中心）があり、提携全体の分布ではない。
