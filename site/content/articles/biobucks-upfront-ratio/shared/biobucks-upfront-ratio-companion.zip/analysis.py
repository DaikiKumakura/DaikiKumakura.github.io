"""Upfront payment as a share of the headline value in recent biopharma deals (hand-collected, 18 deals)."""
from pathlib import Path
import json

import numpy as np
import pandas as pd
from scipy import stats

ROOT = Path(__file__).resolve().parent
OUT = ROOT / "results"
OUT.mkdir(exist_ok=True)
SEED = 20261030
LOA_PHASE1 = 0.079          # likelihood of approval from phase I, all drugs, 2011-2020 (BIO/Informa/QLS, 2021)


def summarise(x, rng):
    x = np.asarray(x, float)
    boot = [np.median(x[rng.integers(0, len(x), len(x))]) for _ in range(2000)]
    return dict(n=len(x), median=float(np.median(x)), q1=float(np.quantile(x, 0.25)), q3=float(np.quantile(x, 0.75)),
                min=float(x.min()), max=float(x.max()), median_lo=float(np.quantile(boot, 0.025)), median_hi=float(np.quantile(boot, 0.975)))


def main():
    d = pd.read_csv(ROOT / "deals.csv")
    assert d.deal.is_unique and len(d) == 18
    rng = np.random.default_rng(SEED)
    d["upfront_share"] = d.upfront_usd_m / d.total_usd_m
    d["upfront_share_alt"] = d.upfront_alt_usd_m / d.total_usd_m
    d["milestones_usd_m"] = d.total_usd_m - d.upfront_usd_m
    d["risk_adjusted_upfront_share_upper"] = d.upfront_usd_m / (d.upfront_usd_m + LOA_PHASE1 * d.milestones_usd_m)
    disclosed = d[d.upfront_usd_m.notna()].copy()
    assert (disclosed.upfront_share <= 1).all()
    rows = []
    groups = {"all deals with a disclosed upfront": disclosed,
              "AI-discovery collaborations": disclosed[disclosed.category == "ai_discovery"],
              "other deals": disclosed[disclosed.category != "ai_discovery"],
              "Chinese seller": disclosed[disclosed.china_seller],
              "non-Chinese seller": disclosed[~disclosed.china_seller],
              "headline value >= $5B": disclosed[disclosed.total_usd_m >= 5000],
              "headline value < $5B": disclosed[disclosed.total_usd_m < 5000]}
    for name, g in groups.items():
        rows.append(dict(group=name, measure="upfront / headline", **summarise(g.upfront_share, rng)))
    alt = disclosed.assign(s=disclosed.upfront_share_alt.fillna(disclosed.upfront_share))
    rows.append(dict(group="all deals, alternative upfront definition where given", measure="upfront(alt) / headline", **summarise(alt.s, rng)))
    rows.append(dict(group="all deals, crude risk adjustment (milestones x 7.9%)", measure="upfront / (upfront + 0.079 x milestones)",
                     **summarise(disclosed.risk_adjusted_upfront_share_upper, rng)))
    summary = pd.DataFrame(rows)
    summary.round(5).to_csv(OUT / "upfront-share-summary.csv", index=False, lineterminator="\n")
    disclosed.round(5).to_csv(OUT / "deals-with-ratios.csv", index=False, lineterminator="\n")
    ai, other = groups["AI-discovery collaborations"].upfront_share, groups["other deals"].upfront_share
    mw = stats.mannwhitneyu(ai, other, alternative="two-sided")
    sp = stats.spearmanr(np.log(disclosed.total_usd_m), disclosed.upfront_share)
    info = dict(deals=int(len(d)), disclosed=int(len(disclosed)), undisclosed=[x for x in d[d.upfront_usd_m.isna()].deal],
                mannwhitney_ai_vs_other_p=float(mw.pvalue), spearman_total_vs_share=float(sp.statistic), spearman_p=float(sp.pvalue),
                deals_with_alternative_upfront=int(d.upfront_alt_usd_m.notna().sum()),
                max_alt_over_main=float((d.upfront_alt_usd_m / d.upfront_usd_m).max()),
                sum_upfront=float(disclosed.upfront_usd_m.sum()), sum_headline=float(disclosed.total_usd_m.sum()),
                pooled_share=float(disclosed.upfront_usd_m.sum() / disclosed.total_usd_m.sum()), loa=LOA_PHASE1)
    (OUT / "summary.json").write_text(json.dumps(info, indent=2) + "\n", encoding="utf-8")
    pd.set_option("display.width", 200)
    print(summary.round(4).to_string())
    print(disclosed[["deal", "upfront_usd_m", "total_usd_m", "upfront_share", "upfront_share_alt", "risk_adjusted_upfront_share_upper"]].round(3).to_string())
    print(json.dumps(info, indent=1))


if __name__ == "__main__":
    main()
