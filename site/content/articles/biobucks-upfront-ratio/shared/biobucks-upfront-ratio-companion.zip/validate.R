# Independent re-implementation (base R) of the upfront shares and group medians from deals.csv.
# Run from this folder: Rscript validate.R
d <- read.csv("deals.csv", stringsAsFactors = FALSE)
ok <- !is.na(d$upfront_usd_m)
share <- d$upfront_usd_m[ok] / d$total_usd_m[ok]
ai <- d$category[ok] == "ai_discovery"
mine <- c(n = sum(ok), median = median(share), q1 = unname(quantile(share, 0.25)), q3 = unname(quantile(share, 0.75)),
          ai_median = median(share[ai]), other_median = median(share[!ai]),
          pooled = sum(d$upfront_usd_m[ok]) / sum(d$total_usd_m[ok]),
          adj_median = median(d$upfront_usd_m[ok] / (d$upfront_usd_m[ok] + 0.079 * (d$total_usd_m[ok] - d$upfront_usd_m[ok]))))
s <- read.csv("results/upfront-share-summary.csv")
j <- jsonlite::fromJSON("results/summary.json")
theirs <- c(n = s$n[1], median = s$median[1], q1 = s$q1[1], q3 = s$q3[1], ai_median = s$median[2], other_median = s$median[3],
            pooled = j$pooled_share, adj_median = s$median[9])
diff <- abs(mine - theirs)
print(rbind(R = mine, Python = theirs))
pass <- diff["n"] == 0 && all(diff[-1] < 1e-4)
jsonlite::write_json(list(status = if (pass) "pass" else "fail", method = "base R recomputation of shares and medians", max_abs_diff = max(diff)),
                     "results/validation.json", auto_unbox = TRUE, pretty = TRUE)
cat("validation:", if (pass) "pass" else "fail", "\n")
