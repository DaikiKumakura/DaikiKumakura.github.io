# Randomized two-dose comparison: how often is the better dose selected, and does using exposure help?
# Compares (R1) an empirical response-rate rule, (R2) an exposure-response model without a severity marker,
# and (R3) an exposure-response model with a noisy severity marker, when severity also raises clearance
# (confounded exposure) or does not (clean exposure). R 4.5.3, base R only.
# Run: Rscript simulate.R 2000        (trials per scenario and sample size)
script_dir <- dirname(normalizePath(sub("^--file=", "", grep("^--file=", commandArgs(FALSE), value = TRUE)[1]), winslash = "/"))
args <- commandArgs(trailingOnly = TRUE)
SEED <- 20261117L; NREP <- if (length(args) >= 1) as.integer(args[1]) else 2000L
DOSES <- c(1, 2)            # relative dose levels (low, high); allocation 1:1
ETA_SD <- 0.30              # between-patient SD of log clearance (not explained by severity)
PROXY_SD <- 0.8             # noise SD of the severity marker (marker = severity + noise)
TOX_CAP <- 0.25             # highest acceptable true toxicity rate
GAIN <- 0.08                # smallest response gain that justifies the higher dose
N_GRID <- c(20, 30, 40, 60, 100)  # patients per arm
SEV_RESP <- 0.6             # effect of severity on the response logit (worse disease, fewer responses)

# Scenario: slope of response and toxicity logits on log exposure; intercepts are calibrated to set the low-dose rates.
SCEN <- list(
  S1_gain  = list(b_r = 1.4, b_t = 0.8, r_low = 0.25, t_low = 0.10),   # clear response gain, toxicity within the cap
  S2_flat  = list(b_r = 0.2, b_t = 0.8, r_low = 0.35, t_low = 0.10),   # near plateau: low dose preferred
  S3_toxic = list(b_r = 1.4, b_t = 1.6, r_low = 0.25, t_low = 0.15)    # gain, but high-dose toxicity above the cap
)
expit <- function(x) 1 / (1 + exp(-x)); logit <- function(p) log(p / (1 - p))

draw <- function(n, dose, kappa) {
  s <- rnorm(n); eta <- rnorm(n, 0, ETA_SD)
  list(s = s, lc = log(dose) - eta - kappa * s, marker = s + rnorm(n, 0, PROXY_SD))
}
# Intercepts such that the low-dose population rates equal r_low and t_low.
calib <- function(sc, kappa, m = 2e5) {
  p <- draw(m, 1, kappa)
  f <- function(a, b, sev, target) mean(expit(a + b * p$lc - sev * p$s)) - target
  list(a_r = uniroot(f, c(-8, 8), b = sc$b_r, sev = SEV_RESP, target = sc$r_low)$root,
       a_t = uniroot(f, c(-8, 8), b = sc$b_t, sev = 0, target = sc$t_low)$root)
}
truth <- function(sc, cal, kappa, m = 4e5) {
  do.call(rbind, lapply(DOSES, function(d) { p <- draw(m, d, kappa)
    data.frame(dose = d, orr = mean(expit(cal$a_r + sc$b_r * p$lc - SEV_RESP * p$s)), tox = mean(expit(cal$a_t + sc$b_t * p$lc))) }))
}

one_trial <- function(n, sc, cal, kappa) {
  dose <- rep(DOSES, each = n); p <- draw(2 * n, dose, kappa)
  y <- rbinom(2 * n, 1, expit(cal$a_r + sc$b_r * p$lc - SEV_RESP * p$s))
  tx <- rbinom(2 * n, 1, expit(cal$a_t + sc$b_t * p$lc))
  d <- data.frame(dose = dose, y = y, tx = tx, lc = p$lc, m = p$marker)
  pick <- function(orr_l, orr_h, tox_h) as.integer(tox_h <= TOX_CAP && (orr_h - orr_l) >= GAIN)   # 1 = choose the high dose
  # R1: empirical rates by arm
  r1 <- pick(mean(y[dose == 1]), mean(y[dose == 2]), mean(tx[dose == 2]))
  # R2/R3: logistic exposure-response fit on pooled patients; the rate at a dose is the mean predicted probability
  # after shifting every patient's log exposure to that dose (assumes exposure scales with dose, no other change).
  er <- function(form_y, form_t) {
    fy <- suppressWarnings(glm(form_y, binomial, d)); ft <- suppressWarnings(glm(form_t, binomial, d))
    base <- d$lc - ifelse(d$dose == 2, log(2), 0)           # exposure of each patient at the low dose
    at <- function(f, sh) { nd <- d; nd$lc <- base + sh; mean(predict(f, nd, type = "response")) }
    pick(at(fy, 0), at(fy, log(2)), at(ft, log(2)))
  }
  r2 <- er(y ~ lc, tx ~ lc); r3 <- er(y ~ lc + m, tx ~ lc + m)
  c(R1_empirical = r1, R2_exposure = r2, R3_exposure_marker = r3)
}

set.seed(SEED); rows <- list()
for (cn in c("clean", "confounded")) {
  kappa <- if (cn == "clean") 0 else 0.4          # severity raises clearance, lowering exposure when kappa > 0
  for (sn in names(SCEN)) {
    sc <- SCEN[[sn]]; cal <- calib(sc, kappa); tr <- truth(sc, cal, kappa)
    best <- as.integer(tr$tox[2] <= TOX_CAP && (tr$orr[2] - tr$orr[1]) >= GAIN)
    for (n in N_GRID) {
      res <- t(vapply(seq_len(NREP), function(i) one_trial(n, sc, cal, kappa), numeric(3)))
      for (m in colnames(res)) {
        pc <- mean(res[, m] == best)
        rows[[length(rows) + 1]] <- data.frame(config = cn, scenario = sn, n_per_arm = n, rule = m, trials = NREP,
          true_best_high = best, true_orr_low = tr$orr[1], true_orr_high = tr$orr[2], true_tox_low = tr$tox[1], true_tox_high = tr$tox[2],
          pcs = pc, pcs_se = sqrt(pc * (1 - pc) / NREP), chose_high = mean(res[, m]))
      }
    }
    cat(cn, sn, "best_high =", best, " ORR", round(tr$orr, 3), " tox", round(tr$tox, 3), "\n")
  }
}
out <- do.call(rbind, rows); dir.create(file.path(script_dir, "results"), showWarnings = FALSE)
write.csv(out, file.path(script_dir, "results/summary.csv"), row.names = FALSE)
writeLines(capture.output(sessionInfo()), file.path(script_dir, "results/session-info.txt"))
options(width = 200); print(within(out[out$n_per_arm %in% c(30, 60), c(1:4, 11, 12, 13)], { pcs <- round(pcs, 3); pcs_se <- round(pcs_se, 3); chose_high <- round(chose_high, 3) }), row.names = FALSE)
