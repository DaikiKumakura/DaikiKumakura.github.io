# Uses the original two-dose data-generating model. Run from the workspace root.
source_path <- "simulate.R"
definitions <- parse(source_path)
first_run <- which(vapply(definitions, function(expr) {
  is.call(expr) && identical(expr[[1]], quote(set.seed))
}, logical(1)))[1]
stopifnot(!is.na(first_run))
model <- new.env()
model$args <- character()
for (expr in definitions[seq.int(3L, first_run - 1L)]) eval(expr, model)

wilson <- function(p, n, z) {
  center <- (p + z^2 / (2 * n)) / (1 + z^2 / n)
  margin <- z * sqrt(p * (1 - p) / n + z^2 / (4 * n^2)) / (1 + z^2 / n)
  c(max(0, center - margin), min(1, center + margin))
}

evaluate <- function(n, scenario, calibration, kappa) {
  d <- rep(model$DOSES, each = n)
  patient <- model$draw(length(d), d, kappa)
  exposure <- patient$lc
  response <- rbinom(length(d), 1, model$expit(calibration$a_r + scenario$b_r * exposure - model$SEV_RESP * patient$s))
  toxicity <- rbinom(length(d), 1, model$expit(calibration$a_t + scenario$b_t * exposure))
  low <- d == model$DOSES[1]
  r <- c(mean(response[low]), mean(response[!low]))
  t <- c(mean(toxicity[low]), mean(toxicity[!low]))
  gain <- r[2] - r[1]
  choose_high <- function(gain, toxicity) gain >= model$GAIN && toxicity <= model$TOX_CAP
  empirical <- if (choose_high(gain, t[2])) "high" else "low"

  fit_response <- suppressWarnings(glm(response ~ exposure, family = binomial()))
  fit_toxicity <- suppressWarnings(glm(toxicity ~ exposure, family = binomial()))
  baseline <- exposure - log(d / model$DOSES[1])
  at_dose <- function(fit, dose) {
    mean(predict(fit, data.frame(exposure = baseline + log(dose / model$DOSES[1])), type = "response"))
  }
  exposure_rule <- if (choose_high(
    at_dose(fit_response, model$DOSES[2]) - at_dose(fit_response, model$DOSES[1]),
    at_dose(fit_toxicity, model$DOSES[2])
  )) "high" else "low"

  # Nominal 90% one-sided component bounds. This is an exploratory rule,
  # without a guarantee of simultaneous coverage or calibrated error.
  z <- qnorm(0.90)
  r_low <- wilson(r[1], n, z)
  r_high <- wilson(r[2], n, z)
  t_low <- wilson(t[1], n, z)
  t_high <- wilson(t[2], n, z)
  gain_lower <- gain - sqrt((r[2] - r_high[1])^2 + (r_low[2] - r[1])^2)
  gain_upper <- gain + sqrt((r_high[2] - r[2])^2 + (r[1] - r_low[1])^2)
  cautious <- "hold"
  if (gain_lower >= model$GAIN && t_high[2] <= model$TOX_CAP) {
    cautious <- "high"
  } else if (t_low[2] <= model$TOX_CAP && (gain_upper < model$GAIN || t_high[1] > model$TOX_CAP)) {
    cautious <- "low"
  }
  c(empirical = empirical, exposure = exposure_rule, allow_hold = cautious)
}

set.seed(20261122)
replicates <- 2000L
results <- list()
paired <- list()
for (kappa in c(0, 0.4)) {
  for (name in names(model$SCEN)) {
    scenario <- model$SCEN[[name]]
    calibration <- model$calib(scenario, kappa)
    truth <- model$truth(scenario, calibration, kappa)
    stopifnot(truth$tox[1] <= model$TOX_CAP)
    best <- if (truth$tox[2] <= model$TOX_CAP && diff(truth$orr) >= model$GAIN) "high" else "low"
    for (n in c(40L, 100L)) {
      outcomes <- replicate(replicates, evaluate(n, scenario, calibration, kappa))
      common <- data.frame(kappa = kappa, scenario = name, n_per_arm = n, best = best)
      for (rule in rownames(outcomes)) {
        choices <- outcomes[rule, ]
        results[[length(results) + 1L]] <- cbind(common, data.frame(
          rule = rule, trials = replicates, correct = mean(choices == best),
          incorrect = mean(choices != best & choices != "hold"), hold = mean(choices == "hold")
        ))
      }
      difference <- (outcomes["exposure", ] == best) - (outcomes["empirical", ] == best)
      delta <- mean(difference)
      margin <- 1.96 * sd(difference) / sqrt(replicates)
      paired[[length(paired) + 1L]] <- cbind(common, data.frame(
        exposure_minus_empirical = delta, mc_low = delta - margin, mc_high = delta + margin
      ))
    }
  }
}
out <- "."
write.csv(do.call(rbind, results), file.path(out, "dose-decision-results.csv"), row.names = FALSE)
write.csv(do.call(rbind, paired), file.path(out, "dose-decision-paired.csv"), row.names = FALSE)
