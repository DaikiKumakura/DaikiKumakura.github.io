Extract the ZIP and run Rscript dose-decision.R in that directory with R 4.5.3 to regenerate both CSV tables. Base R only.
