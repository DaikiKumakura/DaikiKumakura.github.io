"""Re-estimate aggregate exposure contrasts and simulate conditional parent PK."""
from pathlib import Path
import hashlib,json,platform
import numpy as np
import pandas as pd
import scipy
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from model import parameters,schedule,profile,metrics,window_auc

ROOT=Path(__file__).resolve().parents[1]
NAMES=['intermittent','early','late','continuous']
COLORS=['#0072B2','#D55E00','#009E73','#8a6996']

def contrasts(cfg: dict) -> pd.DataFrame:
    rows=[];ref=cfg['paclitaxel']['monotherapy']
    for arm in ['intermittent','continuous']:
        a=cfg['paclitaxel'][arm]
        for endpoint in ['cmax','auc06']:
            x,y=a[endpoint],ref[endpoint]
            logratio=np.log(x['gm']/a['dose_mg_m2'])-np.log(y['gm']/ref['dose_mg_m2'])
            se=np.sqrt(np.log1p(x['gcv']**2)/x['n']+np.log1p(y['gcv']**2)/y['n'])
            rows.append(dict(arm=arm,endpoint=endpoint,ratio=np.exp(logratio),lower=np.exp(logratio-1.96*se),upper=np.exp(logratio+1.96*se),log_se=se))
    return pd.DataFrame(rows)

def main() -> None:
    cfg=json.loads((ROOT/'analysis/inputs.json').read_text())
    out=ROOT/'outputs';tab=out/'tables';figs=out/'figures'
    tab.mkdir(parents=True,exist_ok=True);figs.mkdir(exist_ok=True)
    plt.rcParams.update({'font.family':'DejaVu Sans','font.size':11,'axes.spines.top':False,'axes.spines.right':False,'savefig.dpi':160})
    c=contrasts(cfg);c.to_csv(tab/'paclitaxel-contrasts.csv',index=False)
    raw=[]
    for arm,a in cfg['paclitaxel'].items():
        for endpoint in ['cmax','auc06']:raw.append(dict(arm=arm,endpoint=endpoint,dose=a['dose_mg_m2'],**a[endpoint]))
    pd.DataFrame(raw).to_csv(tab/'paclitaxel-source.csv',index=False)
    rng=np.random.default_rng(cfg['seed']);sd=np.sqrt(np.log1p(np.array(list(cfg['reported_cv'].values()))**2))
    p=parameters(cfg,rng.normal(size=(cfg['n'],len(sd)))*sd);typ=parameters(cfg)
    assert max(p['duration'])<24
    allm={name:metrics(cfg,p,name) for name in NAMES};ref=allm['intermittent']
    rows=[];ratios=[]
    for name in NAMES:
        for key,v in allm[name].items():
            q=np.quantile(v,[.05,.5,.95]);tv=metrics(cfg,typ,name)[key][0]
            rows.append(dict(regimen=name,metric=key,typical=tv,p05=q[0],median=q[1],p95=q[2]))
            q=np.quantile(v/ref[key],[.05,.5,.95]);ratios.append(dict(regimen=name,metric=key,p05=q[0],median=q[1],p95=q[2]))
    m=pd.DataFrame(rows);r=pd.DataFrame(ratios)
    m.to_csv(tab/'parent-metrics.csv',index=False);r.to_csv(tab/'paired-ratios.csv',index=False)
    sens=[]
    for key,vals in {'duration':[.5,1.66,3.0],'ka':[.4,.775,1.2],'cl':[.75*46.7,46.7,1.25*46.7],'vp':[.75*850,850,1.25*850]}.items():
        for val in vals:
            pp=parameters(cfg,override={key:val});base=metrics(cfg,pp,'intermittent')
            for name in ['early','late']:
                mm=metrics(cfg,pp,name)
                sens.append(dict(parameter=key,value=val,regimen=name,local_auc_ratio=mm['auc_infusion06'][0]/base['auc_infusion06'][0],infusion_concentration_ratio=mm['concentration_at_infusion'][0]/base['concentration_at_infusion'][0]))
    pd.DataFrame(sens).to_csv(tab/'sensitivity.csv',index=False)
    t=np.linspace(0,672,2689);curves={'time_h':t}
    for name in NAMES:
        d,a=schedule(cfg,name);curves[name]=profile(typ,t,d,a,cfg['period_h'])[0]
        assert np.isclose(window_auc(typ,0,672,d,a,672)[0],metrics(cfg,typ,name)['auc_cycle'][0],rtol=1e-9)
    pd.DataFrame(curves).to_csv(tab/'typical-curves.csv',index=False)
    third_t=np.linspace(48,72,2401);first=profile(typ,third_t,np.array([0,24,48]),150)[0]
    benchmark=dict(third_cmax=float(first.max()),third_tmax_after_dose=float(third_t[first.argmax()]-48),label_cmax=720,cmax_ratio=float(first.max()/720),third_auc48_72=float(window_auc(typ,48,72,np.array([0,24,48]),150)[0]),label_auc_window_verified=False)
    d,a=schedule(cfg,'intermittent');start=cfg['phase2_parent']['sampling_time_h'];tt=np.linspace(start,start+24,2401)
    bm=dict(cmax=float(profile(typ,tt,d,a)[0].max()),auc024=float(window_auc(typ,start,start+24,d,a)[0]))
    benchmark['phase2_parent']=dict(**bm,source_cmax=cfg['phase2_parent']['cmax'],source_auc024=cfg['phase2_parent']['auc024'],cmax_ratio=bm['cmax']/cfg['phase2_parent']['cmax'],auc_ratio=bm['auc024']/cfg['phase2_parent']['auc024'])
    fig,ax=plt.subplots(figsize=(8,4.2),layout='constrained')
    for i,row in c.iterrows():
        ax.errorbar(row['ratio'],i,xerr=[[row['ratio']-row['lower']],[row['upper']-row['ratio']]],fmt='o',color=COLORS[0 if row['arm']=='intermittent' else 3],capsize=4)
    ax.set_yticks(range(len(c)),[f"{x.arm}: {'Cmax' if x.endpoint=='cmax' else 'AUC0-6'}" for x in c.itertuples()]);ax.invert_yaxis();ax.axvline(1,color='.5',ls='--');ax.set_xlabel('Paclitaxel dose-normalized geometric mean ratio\nvs monotherapy (approximate 95% CI)');ax.set_title('Phase II aggregate PK; endpoint n = 28-50')
    fig.savefig(figs/'paclitaxel-contrasts.png');plt.close(fig)
    fig,axes=plt.subplots(2,1,figsize=(9,6.7),layout='constrained')
    for name,col in zip(NAMES,COLORS):
        axes[0].plot(t/24,curves[name],label=name,color=col,lw=1.5)
        d,a=schedule(cfg,name);zoom=np.linspace(-48,72,481)
        axes[1].plot(zoom,profile(typ,zoom,d,a,672)[0],label=name,color=col,lw=1.7)
    for at in cfg['infusions_h']:axes[0].axvline(at/24,color='.65',ls=':',lw=1)
    axes[0].set(xlabel='Time within a 28-day cycle (day)',ylabel='Parent relacorilant (ng/mL)',title='Conditional periodic PK: covariate multipliers fixed at 1')
    axes[1].axvspan(0,6,color='#eeeeee',label='Infusion to +6 h');axes[1].axvline(0,color='.4',ls=':');axes[1].set(xlabel='Hours relative to first infusion',ylabel='Parent relacorilant (ng/mL)');axes[0].legend(ncol=4,fontsize=9)
    fig.savefig(figs/'parent-timecourse.png');plt.close(fig)
    fig,axes=plt.subplots(1,3,figsize=(11,3.9),layout='constrained')
    for ax,key,title in zip(axes,['auc_cycle','auc_infusion06','concentration_at_infusion'],['Full-cycle AUC','Sum of infusion +0-6 h AUC','Concentration at infusion']):
        for i,name in enumerate(['early','late','continuous']):
            row=r[(r.regimen==name)&(r.metric==key)].iloc[0]
            ax.errorbar(i,row['median'],yerr=[[row['median']-row['p05']],[row['p95']-row['median']]],fmt='o',capsize=4,color=COLORS[NAMES.index(name)])
        ax.axhline(1,color='.5',ls='--');ax.set_xticks(range(3),['early','late','continuous'],rotation=20);ax.set_title(title,fontsize=11);ax.set_ylabel('Paired ratio vs intermittent');ax.set_ylim(bottom=0)
    fig.suptitle('4096 conditional paired draws; median and 5th-95th percentiles',fontsize=12)
    fig.savefig(figs/'paired-window-ratios.png');plt.close(fig)
    results=dict(n=cfg['n'],seed=cfg['seed'],benchmark=benchmark,contrasts=c.to_dict('records'),typical_metrics=m[['regimen','metric','typical']].to_dict('records'),paired_ratios=r.to_dict('records'))
    (out/'results.json').write_text(json.dumps(results,indent=2)+'\n')
    (out/'environment.json').write_text(json.dumps(dict(python=platform.python_version(),numpy=np.__version__,pandas=pd.__version__,scipy=scipy.__version__,matplotlib=matplotlib.__version__),indent=2)+'\n')
    if (ROOT/'data/raw').exists():
        hashes={f.name:hashlib.sha256(f.read_bytes()).hexdigest() for f in (ROOT/'data/raw').iterdir() if f.is_file()}
        (out/'source-hashes.json').write_text(json.dumps(hashes,indent=2)+'\n')
    print(c.to_string(index=False));print(r[r.metric.isin(['auc_cycle','auc_infusion06','concentration_at_infusion'])].to_string(index=False));print(benchmark)

if __name__=='__main__':main()
