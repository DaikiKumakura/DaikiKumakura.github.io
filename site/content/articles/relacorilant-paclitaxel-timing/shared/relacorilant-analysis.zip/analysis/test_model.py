"""Independent numerical checks of convolution, mass balance and aggregate inference."""
from pathlib import Path
import json,unittest
import numpy as np
from scipy.integrate import solve_ivp
from model import parameters,profile,window_auc,schedule,matrix
from run_analysis import contrasts

CFG=json.loads((Path(__file__).parent/'inputs.json').read_text())

class ModelTests(unittest.TestCase):
    def test_against_direct_ode(self):
        p=parameters(CFG);k=matrix(p)[0];h=p['duration'][0];f=p['relative_f'][0];vc=p['vc'][0]
        times=np.linspace(0,72,289)
        def fun(t,y):return k@y+np.array([150*f/h if t<h else 0,0,0])
        a=solve_ivp(fun,[0,h],[0,0,0],rtol=1e-10,atol=1e-10,dense_output=True)
        b=solve_ivp(lambda t,y:k@y,[h,72],a.y[:,-1],rtol=1e-10,atol=1e-10,dense_output=True)
        expected=np.array([(a.sol(t) if t<=h else b.sol(t))[1]*1000/vc for t in times])
        np.testing.assert_allclose(profile(p,times,np.array([0]),150)[0],expected,rtol=1e-7,atol=1e-5)

    def test_periodic_matches_burnin_and_cycle_mass_balance(self):
        p=parameters(CFG);d,a=schedule(CFG,'early');t=np.array([0,1,6,168,672])
        burn=np.concatenate([d+672*j for j in range(-20,2)])
        np.testing.assert_allclose(profile(p,t,d,a,672),profile(p,t,burn,a),rtol=1e-8,atol=1e-8)
        expected=9*150*1000*2.13/46.7
        self.assertAlmostEqual(window_auc(p,0,672,d,a,672)[0],expected,places=6)

    def test_numerical_quadrature_auc_and_linearity(self):
        p=parameters(CFG);d,a=schedule(CFG,'late');t=np.linspace(0,6,10001)
        self.assertAlmostEqual(np.trapz(profile(p,t,d,a,672)[0],t),window_auc(p,0,6,d,a,672)[0],places=3)
        np.testing.assert_allclose(profile(p,t[::100],d,2*a,672),2*profile(p,t[::100],d,a,672))

    def test_aggregate_ratio_not_clearance_estimate(self):
        c=contrasts(CFG);row=c[(c.arm=='intermittent')&(c.endpoint=='auc06')].iloc[0]
        self.assertAlmostEqual(row['ratio'],(2606/80)/(1964/100),places=12)
        self.assertLess(row['lower'],row['ratio']);self.assertGreater(row['upper'],row['ratio'])

if __name__=='__main__':unittest.main()
