"""Conditional oral two-compartment model, mg/L/h; finite gut input."""
import numpy as np


def parameters(cfg: dict, eta: np.ndarray | None = None, override: dict | None = None) -> dict:
    keys=list(cfg['reported_cv'])
    eta=np.zeros((1,len(keys))) if eta is None else np.atleast_2d(eta)
    p={k:np.full(len(eta),v,dtype=float) for k,v in cfg['pk'].items()}
    for j,k in enumerate(keys):p[k]*=np.exp(eta[:,j])
    if override:
        for k,v in override.items():p[k][:]=v
    return p


def matrix(p: dict) -> np.ndarray:
    k=np.zeros((len(p['cl']),3,3))
    k[:,0,0]=-p['ka'];k[:,1,0]=p['ka'];k[:,1,1]=-(p['cl']+p['q'])/p['vc']
    k[:,1,2]=p['q']/p['vp'];k[:,2,1]=p['q']/p['vc'];k[:,2,2]=-p['q']/p['vp']
    return k


def components(p: dict) -> tuple:
    v,u=np.linalg.eig(matrix(p));assert abs(v.imag).max()<1e-10
    c=(u[:,1,:]*np.linalg.inv(u)[:,:,0]).real
    c*= (1000*p['relative_f']/p['vc'])[:,None]
    return v.real,c


def kernel(p: dict, times: np.ndarray, periodic: float | None = None,
           integral: bool = False) -> np.ndarray:
    """Unit oral dose concentration or cumulative AUC; exact periodic convolution."""
    v,c=components(p);t=np.atleast_1d(times)[None,:];h=p['duration'][:,None]
    if periodic is None:
        age=np.maximum(t,0);turns=np.zeros_like(t)
    else:
        turns=np.floor(t/periodic);age=np.mod(t,periodic)
    out=np.zeros((len(p['cl']),t.shape[1]))
    for j in range(3):
        lam=v[:,j,None];a=np.minimum(age,h);tail=np.maximum(age-h,0)
        first=np.expm1(lam*a)/lam
        if integral:
            term=(first-a)/lam + np.expm1(lam*tail)/lam*np.expm1(lam*h)/lam
        else:
            term=np.exp(lam*tail)*first
        if periodic is not None:
            prior=np.exp(lam*(periodic-h))*np.expm1(lam*h)/lam/(-np.expm1(lam*periodic))
            term+=prior*(np.expm1(lam*age)/lam if integral else np.exp(lam*age))
        out+=c[:,j,None]/h*term
    if integral and periodic is not None:
        out+=turns*(1000*p['relative_f']/p['cl'])[:,None]
    if periodic is None and not integral:out[:,t[0]<0]=0
    return out


def schedule(cfg: dict, name: str) -> tuple:
    if name=='continuous':return np.arange(0,cfg['period_h'],24),100.0
    shifts={'intermittent':0,'early':-24,'late':24}
    if name not in shifts:raise ValueError(name)
    times=np.concatenate([np.array([-24,0,24])+a+shifts[name] for a in cfg['infusions_h']])
    return times,150.0


def profile(p: dict, times: np.ndarray, dosing: np.ndarray, amount: float,
            period: float | None = None) -> np.ndarray:
    return sum(amount*kernel(p,np.asarray(times)-d,periodic=period) for d in dosing)


def window_auc(p: dict, lo: float, hi: float, dosing: np.ndarray,
               amount: float, period: float | None = None) -> np.ndarray:
    a=profile_integral(p,np.array([lo,hi]),dosing,amount,period)
    return a[:,1]-a[:,0]


def profile_integral(p: dict, times: np.ndarray, dosing: np.ndarray,
                     amount: float, period: float | None = None) -> np.ndarray:
    return sum(amount*kernel(p,np.asarray(times)-d,periodic=period,integral=True) for d in dosing)


def metrics(cfg: dict, p: dict, name: str) -> dict:
    dosing,d=schedule(cfg,name);period=cfg['period_h']
    pre=profile(p,np.array(cfg['infusions_h']),dosing,d,period)
    local=sum(window_auc(p,t,t+6,dosing,d,period) for t in cfg['infusions_h'])
    cycle=len(dosing)*d*1000*p['relative_f']/p['cl']
    return dict(auc_cycle=cycle,auc_infusion06=local,
                concentration_at_infusion=pre.mean(axis=1),
                auc_rest=window_auc(p,504,624,dosing,d,period),
                infusion06_fraction=local/cycle)
