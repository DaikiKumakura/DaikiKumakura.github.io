# Relacorilant and nab-paclitaxel timing

Public-data research, not treatment or trial dose instructions.
In an existing Python environment matching requirements.txt:
  python analysis/run_analysis.py
  python -m unittest discover -s analysis -p "test_*.py" -q
No network access, downloads or account required. Inputs are in analysis/inputs.json.

Observed paclitaxel: Colombo et al. JCO2023 DOI10.1200/JCO.22.02624,
supplement TableS3 p18. Geometricmeans/GCV/n by endpoint and arm, not individual
records. Dose-normalized Cmax and partial AUC0-6 ratios and approximate independent
arm lognormal95%intervals are reconstructed, not the study's original adjusted
analysis. Endpoint n differs, missingness cannot be evaluated, no multiplicity
adjustment. Dose normalization is descriptive, not proof of dose proportionality.
Partial AUC0-6 is not AUCinf and is not inverted into total clearance.

Relacorilant: FDA NDA2206412026 multidisciplinaryreview PDF283-284
(printed282-283), oncology two-compartment linear model with sequential
zero-order gut input followed by first-order absorption. Apparent fasted
CL46.7L/h,Vc220L,Q45L/h,Vp850L. Fed ka.775/h,D1=1.66h,relativeF2.13.
RelativeF is applied once on input, not absoluteF. BMI/age multipliers fixed1;
original covariate centering, fullOmega and correlations were not established.
This is a conditional coefficient reconstruction, not the original fullPopPK replay.

4096 paired conditional draws, seed20261022. Published IIV percentages interpreted
asCV: CL54,Vc40,Vp30,ka62,D1=59,relativeF31. Independent lognormal etas using
variance ln(1+CV^2), not verified fullOmega. No representative patient covariate
distribution or residual observation error; percentile ranges are not CIs.
No new individual NLME fit. Aggregate logmean contrasts are estimated separately.

Periodic28day profiles: infusions at0/168/336h. Intermittent150mg -24/0/+24h
around each infusion versus continuous100mgQD, with food. Early/late shift the
entire3dosewindow by -24/+24h and are hypothetical, not missed-dose guidance.
Oral dose and infusion atsameclocktime is an analyst standardization, not a label
requirement. Metrics parent fullcycleAUC, sum of three0-6h postinfusion AUCs,
mean parent concentration atinfusion, and restwindow504-624h. No input in the
restwindow for any intermittent schedule. CycleAUC equality follows linear
mass balance and does not establish efficacy equivalence. Ratios cancelling
IIV by construction are not evidence of precision in individual prediction.

Current2026label source:
https://dailymed.nlm.nih.gov/dailymed/drugInfo.cfm?setid=6fcebfb5-19d6-4f63-b852-999d68a13729
Threefed150mg doses: model conditionalCmax767ng/mL vs reported720, not external
patient-level validation. Label AUC5686 integrationwindow was not verified and
is not assumed equal to our48-72h AUC. No parameter retuning to fit that summary.
PhaseII C1D15 parent Cmax668/AUC0-24=3668 vs conditional firstcycle model744/5742:
+11.3%/+56.5%. Unresolved discrepancy, not a qualified absoluteexposure model.
Ratios are within-model sensitivity, not validated clinical timing predictions.

No coupled dynamic paclitaxel-DDI, CYPinhibition, GRoccupancy or metabolite model.
Parentdrug PK is not a validated PD or enzyme-inhibition proxy. No optimal
pretreatmentday, clinical efficacy/toxicity probability or PFS/OS mediation
estimated. Source trial compares treatment packages, not isolated mechanisms.
Sensitivity ranges are analyst scenarios, not parameterCIs or clinical policies.

The code creates6CSV,3originalPNG,results.json andenvironment.json. Sourcehashes
document the consulted snapshot; originals are not redistributed or reverified
by rerunning. Original code MIT; numeric facts attributed above and in article.
