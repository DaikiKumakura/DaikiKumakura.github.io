"""Figures (English text, Okabe-Ito palette). Requires outputs/tables from scripts 01-03. Run: python -X utf8 analysis/04_figures.py"""
import sys
from datetime import date
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.dates as mdates
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

sys.stdout.reconfigure(encoding="utf-8")
ROOT = Path(__file__).resolve().parents[1]
T, F = ROOT / "outputs/tables", ROOT / "outputs/figures"
BLUE, ORANGE, GREEN, VERM, GREY, SKY = "#0072B2", "#E69F00", "#009E73", "#D55E00", "#666666", "#56B4E9"
plt.rcParams.update({"font.size": 9.5, "axes.spines.top": False, "axes.spines.right": False, "figure.dpi": 150})

# Fig 1: what was public when
ev = [
    (date(2025, 6, 30), "Phase 1 data cutoff\n(2L, 300 mg)", BLUE, 1),
    (date(2025, 9, 10), "8-K disclosure:\nG12X ORR 9/26,\nmedian PFS 8.5 mo, OS 13.1 mo", BLUE, -1),
    (date(2025, 12, 31), "Training cutoff\n(this article)", GREY, 1),
    (date(2026, 2, 10), "Phase 3 data cutoff", VERM, -1),
    (date(2026, 5, 31), "ASCO 2026\n(OncLive report date)", VERM, 1),
    (date(2026, 8, 26), "FDA approval", VERM, -1),
]
fig, ax = plt.subplots(figsize=(10.2, 3.6))
ax.axhline(0, color="#444", lw=1)
ax.axvspan(date(2025, 6, 1), date(2025, 12, 31), color=SKY, alpha=0.18)
ax.axvspan(date(2025, 12, 31), date(2026, 9, 20), color=ORANGE, alpha=0.13)
ax.text(date(2025, 6, 8), -2.55, "Training information (public by 2025-12-31)", color=BLUE, fontsize=8.5)
ax.text(date(2026, 1, 8), -2.55, "Holdout and post-cutoff material", color="#9a6700", fontsize=8.5)
for d, lab, c, s in ev:
    ax.vlines(d, 0, 0.9 * s, color=c, lw=1.4)
    ax.scatter([d], [0], color=c, zorder=3, s=26)
    ax.text(d, 1.0 * s, lab, ha="center", va="bottom" if s > 0 else "top", fontsize=8, color=c)
ax.set_ylim(-3, 2.6)
ax.set_xlim(date(2025, 5, 20), date(2026, 10, 10))
ax.xaxis.set_major_locator(mdates.MonthLocator(interval=2))
ax.xaxis.set_major_formatter(mdates.DateFormatter("%Y-%m"))
ax.get_yaxis().set_visible(False)
ax.spines["left"].set_visible(False)
ax.set_xlabel("Date")
ax.set_title("Evidence timeline: what was public before the Phase 3 result", fontsize=9.5)
fig.tight_layout()
fig.savefig(F / "fig1_timeline.png")
plt.close(fig)

# Fig 2: ORR predictive distribution
pm = pd.read_csv(T / "orr_predictive_pmf.csv")
fig, ax = plt.subplots(figsize=(7.4, 3.8))
cols = {0.0: BLUE, 0.5: VERM}
for tau, c in cols.items():
    g = pm[pm.tau == tau]
    ax.plot(g.ratio * 100, g.pmf * 217 / 100 * 100, color=c, lw=2, label=f"Phase 1-informed, tau = {tau:g}")
bn = pd.read_csv(T / "orr_logscore_benchmarks.csv")
ax.axvline(72 / 217 * 100, color="#222", lw=1.4, ls="--")
ax.text(72 / 217 * 100 + 0.7, ax.get_ylim()[1] * 0.93, "Observed 72/217 = 33.2%\n(count back-calculated)", fontsize=8.5, va="top")
ax.axvline(9 / 26 * 100, color=GREY, lw=1, ls=":")
ax.text(9 / 26 * 100 - 0.7, ax.get_ylim()[1] * 0.55, "Phase 1\n9/26 = 34.6%", fontsize=8, ha="right", color=GREY)
ax.set_xlim(0, 80)
ax.set_xlabel("Phase 3 ORR in the RAS G12 daraxonrasib arm, % (217 evaluable patients)")
ax.set_ylabel("Predictive probability per percentage point, %")
ax.legend(frameon=False, fontsize=8.5, loc="upper right", bbox_to_anchor=(1.0, 0.72))
ax.set_title("Predictive distribution of the Phase 3 ORR from 9/26 (Jeffreys prior)", fontsize=9.5)
fig.tight_layout()
fig.savefig(F / "fig2_orr_predictive.png")
plt.close(fig)

# Fig 3: intervals and log scores by model
sc = pd.read_csv(T / "orr_predictive_scores.csv")
sc = sc[(sc.case == "main_72_of_217") & sc.prior.str.startswith("Jeffreys")]
rows = [(f"Informed, tau = {r.tau:g}", r.lo50, r.hi50, r.lo80, r.hi80, r.lo95, r.hi95, r.gain_vs_b_nats, BLUE) for r in sc.itertuples()]
b = bn[bn.case == "main_72_of_217"]
lab = {"(a)": "(a) Point extrapolation", "(b)": "(b) Weak reference Beta(0.5, 0.5)", "(c)": "(c) Any-RAS 11/38 prior"}
for r in b.itertuples():
    k = r.model[:3]
    if k in lab:
        rows.append((lab[k], r.lo50, r.hi50, r.lo80, r.hi80, r.lo95, r.hi95, r.gain_vs_b_nats, ORANGE))
fig, axes = plt.subplots(1, 2, figsize=(10.2, 3.9), gridspec_kw={"width_ratios": [1.7, 1]})
ax = axes[0]
yy = np.arange(len(rows))[::-1]
for y, r in zip(yy, rows):
    c = r[-1]
    ax.hlines(y, r[5] * 100, r[6] * 100, color=c, lw=1.3)
    ax.hlines(y, r[3] * 100, r[4] * 100, color=c, lw=3.2)
    ax.hlines(y, r[1] * 100, r[2] * 100, color=c, lw=6)
ax.axvline(72 / 217 * 100, color="#222", ls="--", lw=1.2)
ax.set_yticks(yy)
ax.set_yticklabels([r[0] for r in rows], fontsize=8.5)
ax.set_xlabel("Predicted Phase 3 ORR, % (thick 50%, medium 80%, thin 95% predictive interval)")
ax.set_xlim(0, 100)
ax = axes[1]
ax.barh(yy, [r[7] for r in rows], color=[r[-1] for r in rows])
ax.set_yticks(yy)
ax.set_yticklabels([])
ax.set_xlabel("Log predictive score gain over (b), nats")
ax.set_title("Observed 72/217", fontsize=9)
axes[0].set_title("Predictive intervals (dashed line: observed 33.2%)", fontsize=9)
fig.tight_layout()
fig.savefig(F / "fig3_orr_scenarios.png")
plt.close(fig)

# Fig 4: survival medians
sv = pd.read_csv(T / "survival_predictive.csv")
fig, axes = plt.subplots(1, 2, figsize=(10.2, 3.7))
for ax, ep, (obs, lo, hi) in zip(axes, ("PFS", "OS"), ((7.3, 6.3, 8.1), (13.2, 10.0, np.nan))):
    g = sv[(sv.endpoint == ep) & (sv.se_mult == 1.0)]
    taus = list(g.tau)
    y0 = np.arange(len(taus))[::-1].astype(float)
    for y, r in zip(y0, g.itertuples()):
        ax.hlines(y, r.pred95_lo_for_observed, r.pred95_hi_for_observed, color=BLUE, lw=3)
    g2 = sv[(sv.endpoint == ep) & (sv.se_mult == 2.0)]
    for y, r in zip(y0 - 0.22, g2.itertuples()):
        ax.hlines(y, r.pred95_lo_for_observed, r.pred95_hi_for_observed, color=SKY, lw=3)
    ax.set_yticks(y0)
    ax.set_yticklabels([f"tau = {t:g}" for t in taus])
    ax.axvline(obs, color="#222", ls="--", lw=1.2)
    ax.set_xscale("log")
    ax.set_xticks([2, 3, 5, 8, 13, 20, 40, 65])
    ax.get_xaxis().set_major_formatter(matplotlib.ticker.ScalarFormatter())
    ax.get_xaxis().set_minor_formatter(matplotlib.ticker.NullFormatter())
    ax.set_xlabel(f"Median {ep}, months (95% predictive interval\nfor the observed Phase 3 median)")
    t = "Median PFS (Phase 1: 8.5, CI 6.7-10.5; Phase 3 observed 7.3)" if ep == "PFS" else "Median OS (Phase 1: 13.1, CI lower 10.9; Phase 3 observed 13.2)"
    ax.set_title(t, fontsize=8.8)
# the colour key (dark blue: se recovered from the reported CI; light blue: se doubled) is given in the figure caption
fig.tight_layout()
fig.savefig(F / "fig4_survival_medians.png")
plt.close(fig)

# Fig 5: information value
wd = pd.read_csv(T / "info_value_widths.csv")
pr = pd.read_csv(T / "info_value_proceed.csv")
fl = pd.read_csv(T / "info_value_floor.csv").set_index("tau")
fig, axes = plt.subplots(1, 2, figsize=(10.2, 4.6))
ax = axes[0]
g = wd[wd.true_p == 0.35]
ax.plot(g.n1, g.pred_width_tau0 * 100, color=BLUE, marker="o", lw=2, label="tau = 0")
ax.plot(g.n1, g.pred_width_tau05 * 100, color=VERM, marker="o", lw=2, label="tau = 0.5")
ax.axhline(fl.loc[0.5, "width"] * 100, color=VERM, ls=":", lw=1.2)
ax.text(104, fl.loc[0.5, "width"] * 100 - 2.2, "tau = 0.5 floor (n1 → ∞)", color=VERM, fontsize=8, ha="right")
ax.set_xticks([26, 52, 78, 104])
ax.set_ylim(0, 60)
ax.set_xlabel("Phase 1 cohort size n1 (true ORR 0.35)")
ax.set_ylabel("Expected width of the 95% interval\nfor the Phase 3 ORR, percentage points")
ax.legend(frameon=False, fontsize=8.5, loc="upper right")
ax.set_title("Width of the predictive interval vs cohort size", fontsize=9)
ax = axes[1]
for (T_, ls), tt in zip([(0.25, "-"), (0.20, "--")], ["T = 25%", "T = 20%"]):
    for p, c in ((0.25, GREY), (0.30, ORANGE), (0.35, BLUE)):
        g = pr[(pr["T"] == T_) & (pr.true_p == p)]
        ax.plot(g.n1, g.p_proceed, color=c, ls=ls, marker="o", ms=3.5, lw=1.8, label=f"true ORR {p:g}, {tt}")
ax.set_xticks([26, 52, 78, 104])
ax.set_ylim(0, 1.02)
ax.set_xlabel("Phase 1 cohort size n1")
ax.set_ylabel("Probability of a 'proceed' call\n(P(ORR > T | data) ≥ 0.8)")
ax.legend(frameon=False, fontsize=7.6, loc="upper center", bbox_to_anchor=(0.5, -0.2), ncol=2)
ax.set_title("Decision rule scenarios (thresholds are arbitrary)", fontsize=9)
fig.tight_layout()
fig.savefig(F / "fig5_information_value.png")
plt.close(fig)
print("figures written")
