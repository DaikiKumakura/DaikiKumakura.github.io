"""Survival medians (summary level): Phase 1 G12X 2L medians -> Phase 3 RAS G12 daraxonrasib-arm medians.

Inputs : inputs/phase1_training.csv, inputs/phase3_holdout.csv
Model  : log(m3) = log(m1) + delta, delta ~ N(0, tau^2); the reported medians are treated as the estimates of the
         log-median with standard error recovered from the reported 95% CI assuming symmetry on the log scale
         (se = (log(upper) - log(lower)) / (2 * 1.959964)). Observation error of the Phase 3 median is added the same way.
         PFS: both bounds used. OS: the upper bounds are NE, so se is recovered from the lower bound only
         (se = (log(m) - log(lower)) / 1.959964); sensitivity multipliers 1.0, 1.5, 2.0 on the OS se and 1.0, 2.0 on the PFS se
         (with 26 patients an event-count se of the log median is about 1/sqrt(26) = 0.20, above the se recovered from the reported CI).
         Predictive distribution of the observed Phase 3 log-median: N(log m1, se1^2 + tau^2 + se3^2).
Output : outputs/tables/survival_predictive.csv
Run    : python -X utf8 analysis/02_survival_medians.py
Retrospective: Phase 3 values were known. The Phase 3 follow-up (median 8.5 months, whole trial) is shorter than Phase 1 (16.7 months);
the Phase 3 OS median rests on the late part of an immature curve, so the OS check is weak.
"""
import sys
from pathlib import Path

import numpy as np
import pandas as pd
from scipy import stats

sys.stdout.reconfigure(encoding="utf-8")
ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "outputs/tables"
tr = pd.read_csv(ROOT / "inputs/phase1_training.csv")
ho = pd.read_csv(ROOT / "inputs/phase3_holdout.csv")
Z = 1.959964
TAUS = [0.0, 0.25, 0.5, 0.75]


def get(df, pop, ep):
    return df[(df.population == pop) & (df.endpoint == ep)].iloc[0]


p1 = {"PFS": get(tr, "RAS G12X 2L 300 mg", "median PFS"), "OS": get(tr, "RAS G12X 2L 300 mg", "median OS")}
p3 = {"PFS": get(ho, "RAS G12 daraxonrasib arm", "median PFS"), "OS": get(ho, "RAS G12 daraxonrasib arm", "median OS")}
assert (p1["PFS"].value, p1["PFS"].ci_lo, p1["PFS"].ci_hi) == (8.5, 6.7, 10.5)
assert (p3["PFS"].value, p3["PFS"].ci_lo, p3["PFS"].ci_hi) == (7.3, 6.3, 8.1)
assert (p1["OS"].value, p1["OS"].ci_lo) == (13.1, 10.9) and (p3["OS"].value, p3["OS"].ci_lo) == (13.2, 10.0)


def se_two_sided(r):
    return (np.log(r.ci_hi) - np.log(r.ci_lo)) / (2 * Z)


def se_lower_only(r):
    return (np.log(r.value) - np.log(r.ci_lo)) / Z


rows = []
for ep in ("PFS", "OS"):
    for mult in ([1.0, 2.0] if ep == "PFS" else [1.0, 1.5, 2.0]):
        if ep == "PFS":
            s1, s3 = se_two_sided(p1[ep]) * mult, se_two_sided(p3[ep]) * mult
        else:
            s1, s3 = se_lower_only(p1[ep]) * mult, se_lower_only(p3[ep]) * mult
        for tau in TAUS:
            sd = np.sqrt(s1 ** 2 + tau ** 2 + s3 ** 2)
            mu = np.log(p1[ep].value)
            obs = np.log(p3[ep].value)
            z = (obs - mu) / sd
            lo, hi = np.exp(mu - Z * sd), np.exp(mu + Z * sd)
            # interval for the *true* Phase 3 median (without observation error)
            sd_t = np.sqrt(s1 ** 2 + tau ** 2)
            tlo, thi = np.exp(mu - Z * sd_t), np.exp(mu + Z * sd_t)
            rows.append(dict(endpoint=ep, se_mult=mult, tau=tau, m1=p1[ep].value, se1=round(s1, 4), se3=round(s3, 4), obs_m3=p3[ep].value,
                             obs_ratio=round(p3[ep].value / p1[ep].value, 3), pred95_lo_for_observed=round(lo, 2), pred95_hi_for_observed=round(hi, 2),
                             true_m3_lo95=round(tlo, 2), true_m3_hi95=round(thi, 2), z=round(z, 3), pit=round(stats.norm.cdf(z), 3),
                             log_score=round(float(stats.norm.logpdf(obs, mu, sd)), 3), in95=bool(abs(z) <= Z)))
res = pd.DataFrame(rows)
res.to_csv(OUT / "survival_predictive.csv", index=False)
pd.set_option("display.width", 220)
print(res.to_string(index=False))
print("Phase 1 median follow-up 16.7 mo vs Phase 3 whole-trial median follow-up 8.5 mo")
