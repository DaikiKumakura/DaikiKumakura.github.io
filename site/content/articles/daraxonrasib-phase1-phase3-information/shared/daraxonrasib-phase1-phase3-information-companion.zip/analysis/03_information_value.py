"""Information value of the Phase 1 cohort size (preposterior simulation) and calibration under heterogeneity.

Part A  : for Phase 1 sizes n1 in {26, 52, 78, 104} and true Phase 1 ORR scenarios, simulate x1 ~ Binomial(n1, p),
          posterior Beta(0.5 + x1, 0.5 + n1 - x1). Record the width of the 95% credible interval for p1, the width of the 95% predictive
          interval of the Phase 3 rate (n3 = 217, heterogeneity tau in {0, 0.5}) and the probability of a "proceed" call under
          the rule P(p > T | data) >= 0.8, T in {0.15, 0.20, 0.25}. The thresholds are arbitrary scenarios, not clinical criteria.
Part B  : the realised calls for 9/26.
Part C  : the asymptotic floor of the predictive width (p1 known) per tau.
Part D  : calibration over repeated Phase 1 -> Phase 3 pairs, run for a true tau of 0.5 and of 0 (the true tau is assumed by construction in
          both): coverage of the 95% interval and mean log score of (a) point extrapolation, (b) the Phase 1-informed predictive that assumes
          tau = 0.5, (c) the Phase 1-informed predictive that assumes tau = 0. The true-tau-0.5 block runs first and uses the same random
          stream as in the first version of this script; the true-tau-0 block was added after the first results were seen.
Settings: SIMS = 4,000 Phase 1 draws per cell; the predictive-interval widths use every tenth draw (400) with 2,000 posterior draws each;
          Part D uses 3,000 pairs per cell, 400 posterior draws and a 200 x 400 Monte Carlo pmf with a floor of 1e-12 for the log score.
          Monte Carlo error was not quantified.
Retrospective: the Phase 3 result was known when this script was written; no pre-run record of the design exists.
Output  : outputs/tables/info_value_widths.csv, info_value_proceed.csv, info_value_realised.csv, info_value_floor.csv, calibration_repeated_pairs.csv
Run     : python -X utf8 analysis/03_information_value.py   (seed 20261110)
"""
import sys
from pathlib import Path

import numpy as np
import pandas as pd
from scipy import stats
from scipy.special import expit, logit

sys.stdout.reconfigure(encoding="utf-8")
SEED = 20261110
ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "outputs/tables"
rng = np.random.default_rng(SEED)
N3 = 217
SIMS, DRAWS = 4000, 4000
NS = [26, 52, 78, 104]
PS = [0.20, 0.25, 0.30, 0.35, 0.40]
TS = [0.15, 0.20, 0.25]
TAUS = [0.0, 0.5]


def pred_interval_p3(a, b, tau, draws=DRAWS):
    """95% interval of the true Phase 3 rate p3 (not the count), by draws."""
    p1 = rng.beta(a, b, draws)
    p3 = expit(logit(p1) + rng.normal(0, tau, draws)) if tau > 0 else p1
    return np.quantile(p3, [0.025, 0.975])


wrows, prows = [], []
for n1 in NS:
    for p in PS:
        x1 = rng.binomial(n1, p, SIMS)
        a, b = 0.5 + x1, 0.5 + n1 - x1
        cri = stats.beta.ppf(0.975, a, b) - stats.beta.ppf(0.025, a, b)
        wd = {}
        for tau in TAUS:
            w = []
            for i in range(0, SIMS, 10):  # 400 sims per cell for the heavier predictive width
                lo, hi = pred_interval_p3(a[i], b[i], tau, 2000)
                w.append(hi - lo)
            wd[tau] = float(np.mean(w))
        wrows.append(dict(n1=n1, true_p=p, cri_width=float(cri.mean()), pred_width_tau0=wd[0.0], pred_width_tau05=wd[0.5]))
        for T in TS:
            prob = 1 - stats.beta.cdf(T, a, b)
            prows.append(dict(n1=n1, true_p=p, T=T, p_proceed=float((prob >= 0.8).mean())))
pd.DataFrame(wrows).round(4).to_csv(OUT / "info_value_widths.csv", index=False)
pd.DataFrame(prows).round(4).to_csv(OUT / "info_value_proceed.csv", index=False)

# realised
real = []
a, b = 0.5 + 9, 0.5 + 17
for T in [0.15, 0.20, 0.25, 0.30]:
    pr = 1 - stats.beta.cdf(T, a, b)
    real.append(dict(T=T, P_p_gt_T=round(float(pr), 4), proceed_at_0_8=bool(pr >= 0.8)))
pd.DataFrame(real).to_csv(OUT / "info_value_realised.csv", index=False)

# floor (p1 known = 9/26) for the width of the 95% interval of the true p3
fl = []
for tau in [0.0, 0.25, 0.5, 0.75]:
    p3 = expit(logit(9 / 26) + rng.normal(0, tau, 400000)) if tau > 0 else np.full(10, 9 / 26)
    lo, hi = np.quantile(p3, [0.025, 0.975])
    fl.append(dict(tau=tau, lo=round(float(lo), 4), hi=round(float(hi), 4), width=round(float(hi - lo), 4)))
pd.DataFrame(fl).to_csv(OUT / "info_value_floor.csv", index=False)

# calibration over repeated pairs
def calibrate(true_tau, R=3000):
    out = []
    for n1 in NS:
        cov = {"(a) point extrapolation": 0, "(b) predictive assuming tau=0.5": 0, "(c) predictive assuming tau=0": 0}
        ls = {k: 0.0 for k in cov}
        for _ in range(R):
            p1t = rng.beta(0.5 + 9, 0.5 + 17)  # a true Phase 1 rate drawn from the realised posterior (illustrative population of truths)
            x1 = rng.binomial(n1, p1t)
            p3t = expit(logit(p1t) + rng.normal(0, true_tau))
            y3 = rng.binomial(N3, p3t)
            a, b = 0.5 + x1, 0.5 + n1 - x1
            pm = stats.binom.pmf(np.arange(N3 + 1), N3, max(min(x1 / n1, 0.999), 0.001))
            p1d = rng.beta(a, b, 400)
            p3d = expit(logit(p1d) + rng.normal(0, 0.5, 400))
            pmb = np.bincount(rng.binomial(N3, p3d, (200, 400)).ravel(), minlength=N3 + 1) / (200 * 400)
            pmc = stats.betabinom.pmf(np.arange(N3 + 1), N3, a, b)
            for key, pmv in (("(a) point extrapolation", pm), ("(b) predictive assuming tau=0.5", pmb), ("(c) predictive assuming tau=0", pmc)):
                c = np.cumsum(pmv)
                lo, hi = np.searchsorted(c, 0.025), np.searchsorted(c, 0.975)
                cov[key] += int(lo <= y3 <= hi)
                ls[key] += float(np.log(max(pmv[y3], 1e-12)))
        for key in cov:
            out.append(dict(true_tau=true_tau, n1=n1, method=key, coverage95=cov[key] / R, mean_log_score=ls[key] / R))
    return out


cal = calibrate(0.5) + calibrate(0.0)
pd.DataFrame(cal).round(4).to_csv(OUT / "calibration_repeated_pairs.csv", index=False)
pd.set_option("display.width", 200)
print(pd.DataFrame(wrows).round(3).to_string(index=False))
pp = pd.DataFrame(prows).pivot_table(index=["T", "n1"], columns="true_p", values="p_proceed").round(3)
print(pp.to_string())
print(pd.DataFrame(real).to_string(index=False))
print(pd.DataFrame(fl).to_string(index=False))
print(pd.DataFrame(cal).round(3).to_string(index=False))
