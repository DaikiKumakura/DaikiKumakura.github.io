"""ORR: posterior predictive check of the Phase 3 RAS G12 ORR from the Phase 1 G12X cohort (9/26).

Inputs : inputs/phase1_training.csv, inputs/phase3_holdout.csv
Model  : p1 ~ Beta(a + 9, b + 17); logit(p3) = logit(p1) + delta, delta ~ N(0, tau^2); Y3 ~ Binomial(n3, p3).
         tau in {0, 0.25, 0.5, 0.75} are scenarios (not estimated). The predictive pmf is computed by deterministic quadrature
         (4,000 quantile midpoints of the Beta posterior x 41 Gauss-Hermite nodes for delta); no random numbers are used.
Output : outputs/tables/orr_predictive_scores.csv, orr_predictive_pmf.csv, orr_logscore_benchmarks.csv
Run    : python -X utf8 analysis/01_orr_prediction.py
Retrospective: the Phase 3 result was known when this script was written; no pre-run record of the design exists.
Benchmarks (b) and (c), the Beta(1,1) prior and the 228-patient denominator were added after the first results were seen, as explanation.
PIT is the midpoint version for a discrete predictive, F(x-1) + 0.5 p(x), the expectation of the randomized PIT (Czado et al. 2009).
"""
import sys
from pathlib import Path

import numpy as np
import pandas as pd
from scipy import stats
from scipy.special import expit, logit

sys.stdout.reconfigure(encoding="utf-8")
SEED = 20261110
ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "outputs/tables"
tr = pd.read_csv(ROOT / "inputs/phase1_training.csv")
ho = pd.read_csv(ROOT / "inputs/phase3_holdout.csv")
g12 = tr[(tr.population == "RAS G12X 2L 300 mg") & (tr.endpoint == "ORR")].iloc[0]
anyras = tr[(tr.population.str.startswith("RAS mutant")) & (tr.endpoint == "ORR")].iloc[0]
X1, N1 = int(g12.x), int(g12.n)
XA, NA = int(anyras.x), int(anyras.n)
assert (X1, N1, XA, NA) == (9, 26, 11, 38)
obs_main = ho[ho.endpoint == "ORR"].iloc[0]
obs_sens = ho[ho.endpoint == "ORR (sensitivity denominator)"].iloc[0]
cases = {"main_72_of_217": (int(obs_main.x), int(obs_main.n)), "sens_76_of_228": (int(obs_sens.x), int(obs_sens.n))}
assert cases["main_72_of_217"] == (72, 217) and cases["sens_76_of_228"] == (76, 228)
TAUS = [0.0, 0.25, 0.5, 0.75]


GH_X, GH_W = np.polynomial.hermite_e.hermegauss(41)
GH_W = GH_W / GH_W.sum()
Q = (np.arange(4000) + 0.5) / 4000


def pmf_quad(a, b, tau, n3):
    """Predictive pmf of Y3: average Binomial(n3, p3) over the Beta(a, b) posterior of p1 and delta ~ N(0, tau^2)."""
    p1 = stats.beta.ppf(Q, a, b)
    ks = np.arange(n3 + 1)
    if tau == 0:
        return stats.binom.pmf(ks[:, None], n3, p1[None, :]).mean(axis=1)
    out = np.zeros(n3 + 1)
    for x, w in zip(GH_X, GH_W):
        p3 = expit(logit(p1) + tau * x)
        out += w * stats.binom.pmf(ks[:, None], n3, p3[None, :]).mean(axis=1)
    return out


def summarise(pmf, x_obs, n3):
    cdf = np.cumsum(pmf)

    def q(a):
        return int(np.searchsorted(cdf, a))
    lo95, hi95 = q(0.025), q(0.975)
    lo80, hi80 = q(0.10), q(0.90)
    lo50, hi50 = q(0.25), q(0.75)
    pit = (cdf[x_obs - 1] if x_obs > 0 else 0.0) + 0.5 * pmf[x_obs]
    return dict(mean=float((np.arange(n3 + 1) * pmf).sum() / n3), lo95=lo95 / n3, hi95=hi95 / n3, lo80=lo80 / n3, hi80=hi80 / n3,
                lo50=lo50 / n3, hi50=hi50 / n3, p_obs=float(pmf[x_obs]), log_score=float(np.log(max(pmf[x_obs], 1e-300))),
                pit=float(pit), in95=bool(lo95 <= x_obs <= hi95), in80=bool(lo80 <= x_obs <= hi80))


rows, pmfs = [], []
for prior_name, (a, b) in {"Jeffreys Beta(0.5,0.5)": (0.5, 0.5), "Beta(1,1)": (1.0, 1.0)}.items():
    for case, (xo, n3) in cases.items():
        for tau in TAUS:
            pmf = pmf_quad(a + X1, b + N1 - X1, tau, n3)
            s = summarise(pmf, xo, n3)
            s.update(model=f"Phase1-informed, tau={tau}", prior=prior_name, case=case, tau=tau, n3=n3, x_obs=xo)
            rows.append(s)
            if prior_name.startswith("Jeffreys") and case == "main_72_of_217":
                pmfs.append(pd.DataFrame({"tau": tau, "y": np.arange(n3 + 1), "ratio": np.arange(n3 + 1) / n3, "pmf": pmf}))

# benchmarks (Jeffreys; main and sensitivity denominators)
bench = []
for case, (xo, n3) in cases.items():
    # (a) point extrapolation at 9/26
    pm = stats.binom.pmf(np.arange(n3 + 1), n3, X1 / N1)
    s = summarise(pm, xo, n3)
    s.update(model="(a) point extrapolation 9/26", prior="none", case=case, tau=np.nan, n3=n3, x_obs=xo)
    bench.append(s)
    # (b) no Phase 1 information
    pm = stats.betabinom.pmf(np.arange(n3 + 1), n3, 0.5, 0.5)
    s = summarise(pm, xo, n3)
    s.update(model="(b) no Phase 1 information Beta(0.5,0.5)", prior="Jeffreys", case=case, tau=np.nan, n3=n3, x_obs=xo)
    bench.append(s)
    # (c) any-RAS cohort 11/38 as the prior (contains the G12X patients; not independent)
    pm = stats.betabinom.pmf(np.arange(n3 + 1), n3, 0.5 + XA, 0.5 + NA - XA)
    s = summarise(pm, xo, n3)
    s.update(model="(c) any-RAS cohort 11/38 (contains G12X)", prior="Jeffreys", case=case, tau=np.nan, n3=n3, x_obs=xo)
    bench.append(s)
    # exact check of tau=0 Phase1-informed
    pm = stats.betabinom.pmf(np.arange(n3 + 1), n3, 0.5 + X1, 0.5 + N1 - X1)
    s = summarise(pm, xo, n3)
    s.update(model="Phase1-informed, tau=0 (exact beta-binomial)", prior="Jeffreys", case=case, tau=0.0, n3=n3, x_obs=xo)
    bench.append(s)

cols = ["case", "model", "prior", "tau", "n3", "x_obs", "mean", "lo50", "hi50", "lo80", "hi80", "lo95", "hi95", "p_obs", "log_score", "pit", "in80", "in95"]
res = pd.DataFrame(rows)[cols]
bm = pd.DataFrame(bench)[cols]
ref = bm[(bm.model.str.startswith("(b)"))].set_index("case").log_score
bm["gain_vs_b_nats"] = bm.apply(lambda r: r.log_score - ref[r.case], axis=1)
res["gain_vs_b_nats"] = res.apply(lambda r: r.log_score - ref[r.case], axis=1)
res.round(4).to_csv(OUT / "orr_predictive_scores.csv", index=False)
bm.round(4).to_csv(OUT / "orr_logscore_benchmarks.csv", index=False)
pd.concat(pmfs).to_csv(OUT / "orr_predictive_pmf.csv", index=False)

# consistency: MC tau=0 vs exact beta-binomial
mc = res[(res.case == "main_72_of_217") & (res.prior.str.startswith("Jeffreys")) & (res.tau == 0)].iloc[0]
ex = bm[(bm.case == "main_72_of_217") & (bm.model.str.contains("exact"))].iloc[0]
assert abs(mc.log_score - ex.log_score) < 0.01, (mc.log_score, ex.log_score)
post = stats.beta(0.5 + X1, 0.5 + N1 - X1)
print(f"Phase 1 posterior (Jeffreys) mean {post.mean():.3f}, 95% CrI {post.ppf(.025):.3f}-{post.ppf(.975):.3f}")
print("Observed Phase 3: 72/217 =", round(72 / 217, 4))
pd.set_option("display.width", 220)
print(res[res.prior.str.startswith("Jeffreys")][["case", "model", "mean", "lo95", "hi95", "p_obs", "log_score", "pit", "in80", "in95", "gain_vs_b_nats"]].round(3).to_string(index=False))
print(bm[["case", "model", "mean", "lo95", "hi95", "p_obs", "log_score", "pit", "in95", "gain_vs_b_nats"]].round(3).to_string(index=False))
print(res[res.prior == "Beta(1,1)"][["case", "model", "mean", "lo95", "hi95", "log_score", "pit"]].round(3).to_string(index=False))
