# Provenance of the inputs

Read on 2026-11-10 (dates are the dates the pages were read).

## Training (public by 2025-12-31)

- Revolution Medicines, Inc. Form 8-K, 2025-09-10 (https://www.sec.gov/Archives/edgar/data/1628171/000119312525200078/d947102d8k.htm). Read in full as text via the fetch tool.
  - 2L monotherapy, 300 mg once daily, data cutoff 2025-06-30. RAS G12X: ORR 35% (9/26), DCR 92% (24/26), median PFS 8.5 months (95% CI 6.7-10.5), median OS 13.1 months (10.9-NE), median follow-up 16.7 months (10.3-24.6), median DoR 8.2 months (3.8-NE). RAS mutant (G12X, G13X or Q61X): ORR 29% (11/38), median PFS 8.1 (5.9-10.1), median OS 15.6 (10.9-NE).
  - ORR is "per RECIST v1.1" and counts responses that were confirmed or still had the potential to confirm. Whether investigator-assessed is not stated. "2L efficacy evaluable" is not defined in the document. No maximum number of prior lines is stated.
  - The document contains a waterfall plot and interim PFS and OS plots as image files. The images were NOT read or digitized. No numbers at risk are given in the text.
  - The document does not mention RASolute 302.

## Holdout and post-cutoff material

- O'Reilly EM, et al. N Engl J Med 2026;395(4):325-337, doi:10.1056/NEJMoa2605555. Only the Europe PMC metadata and abstract summary were read. The full text returned HTTP 403.
- OncLive, 2026-05-31 (https://www.onclive.com/view/daraxonrasib-meets-all-primary-key-secondary-efficacy-end-points-in-pretreated-pdac). Secondary report. All RAS G12 population numbers used for scoring come from this page: n = 228 and 231; ORR 33.2% (evaluable n = 217) and 11.8% (n = 221); median PFS 7.3 (6.3-8.1) and 3.5 (2.9-3.8); median OS 13.2 (10.0-NE) and 6.6 (5.4-8.2); median follow-up 8.5 months (3.2-15.9), whole trial; data cutoff 2026-02-10. The page does not give response counts. The 72 responders (and 76 in the sensitivity analysis) are back-calculated from the percentage and the denominator, not reported.
- Other pages (Consultant360, targetedonc, ASCO Post, Revolution Medicines press releases) were found by search. The Consultant360 and ASCO Post pages confirm 33.2% vs 11.8%, 7.3 vs 3.5 months, 13.2 vs 6.7 months in the G12 population, but give no G12 denominators. None states whether ORR is confirmed or centrally assessed. The primary endpoints (PFS, OS) were by blinded independent central review.
- FDA, 2026-08-26 (https://www.fda.gov/drugs/cancer-approvals/fda-approves-daraxonrasib-metastatic-pancreatic-adenocarcinoma): states approval on August 26, 2026 and the RASolute 302 population (disease progression after one prior line of systemic therapy); overall population only (500 randomized; OS 13.2 vs 6.7 months; PFS 7.2 vs 3.6; ORR 30% (25-36) vs 11% (7-15)). Not used for scoring.
- Wolpin BM, et al. N Engl J Med 2026;394(18):1790-1802, doi:10.1056/NEJMoa2505783 (Phase 1/2 paper): metadata and abstract summary only (26 patients with RAS G12 at 300 mg, ORR 35%). Post-cutoff; not used for scoring.

## Notes added after review

- The 8-K reports the median follow-up 16.7 (10.3-24.6) months; 10.3-24.6 is a range, not a confidence interval. The OncLive 3.2-15.9 is also a range.
- 72 responders: 0.332 x 217 = 72.04 (71 would give 32.7% and 73 would give 33.6%), so 72 is the only count consistent with the reported 33.2% and the evaluable n of 217; 217 itself rests on one secondary report. 76/228 = 33.3% does not reproduce 33.2% (0.332 x 228 = 75.7), so the 228-patient case is an approximate sensitivity analysis only.
- The Phase 3 response definition (confirmed or not) and the assessor of ORR are not stated in the sources read. The assessor of the Phase 1 ORR is not stated either.
- The 8-K safety set (n = 83) is "2L+"; the efficacy cohort is labelled "2L efficacy evaluable" without a definition.
- The 158 nM (mouse) and about 80 nM (human-equivalent) thresholds were taken from the cited 2024 Cancer Discovery paper as summarized in the earlier article on the site; the paper was not re-read for this article.
- The topline announcement date of 2026-04-13 listed in an earlier version of Figure 1 came from a search-result listing that was not opened; it is not used.
