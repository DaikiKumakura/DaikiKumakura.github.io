# Companion materials: how much the 26-patient Phase 1 cohort of daraxonrasib constrained the Phase 3 result

Scripts, inputs, tables, figures and logs for the article on the information value of the Phase 1 expansion cohort (RAS G12X, second line, 300 mg once daily) for the RASolute 302 RAS G12 population.

## Run

Python 3.12, numpy, pandas, scipy, matplotlib; seed 20261110 (the ORR predictive distribution uses no random numbers):

`python -X utf8 analysis/01_orr_prediction.py && python -X utf8 analysis/02_survival_medians.py && python -X utf8 analysis/03_information_value.py && python -X utf8 analysis/04_figures.py`

`03_information_value.py` takes about two to three minutes.

## Inputs

- `inputs/phase1_training.csv`: values from the Form 8-K of 2025-09-10 (data cutoff 2025-06-30).
- `inputs/phase3_holdout.csv`: RAS G12 population values from a secondary news report; the 72 and 76 responder counts are back-calculated, not reported.
- `inputs/PROVENANCE.md`: what was read, what was not read (the 8-K figures are images and were not read; the NEJM full text was not available).

## Protocol (written after the Phase 3 outcome was known)

This is a retrospective check, not a blinded prediction. The models and benchmarks were designed with the Phase 3 result already known, and no record made before the scripts were run exists. Benchmarks (b) and (c), the Beta(1,1) prior, the 228-patient denominator, the doubled standard errors for survival and the repeated-pair simulation were added after the first results were seen, as explanation. The choice of 2025-12-31 as the training cutoff, and the classification of the 2026 Phase 1 paper as post-cutoff material, are retrospective choices.

1. ORR: p1 ~ Beta(a + 9, b + 17) (Jeffreys; Beta(1,1) as sensitivity); logit(p3) = logit(p1) + delta, delta ~ N(0, tau^2), tau in {0, 0.25, 0.5, 0.75} as scenarios; Y3 ~ Binomial(217, p3) (76/228 as sensitivity). Benchmarks: (a) point extrapolation 9/26, (b) a weak U-shaped reference Beta(0.5, 0.5) (not a realistic no-information prior), (c) any-RAS 11/38 prior. Metrics: predictive intervals, predictive probability of the observed count, log predictive score, midpoint PIT (the expectation of the randomized PIT), coverage.
2. Survival (summary level): log(median3) ~ N(log(median1), se1^2 + tau^2) plus the observation error; se recovered from the reported 95% CI assuming symmetry on the log scale (OS: lower bound only; multipliers 1.5 and 2 for OS, 2 for PFS). No Kaplan-Meier digitization. tau here is on the log-median scale, not the logit scale of the ORR model.
3. Information value: Phase 1 size 26/52/78/104, true ORR 0.20-0.40, width of the 95% interval, probability of a proceed call under P(p > T | data) >= 0.8 for T in {0.15, 0.20, 0.25} (arbitrary scenarios), the width floor for n1 to infinity, and calibration over repeated pairs at a true tau of 0.5 and of 0 (both assumed by construction). Simulation settings are in the docstring of `03_information_value.py`; Monte Carlo error was not quantified.
4. Identifiability audit: qualitative only; no mechanistic model is fitted.

Timeline dates in Figure 1: Phase 1 data cutoff and the 8-K from the 8-K; Phase 3 data cutoff from the secondary report; the ASCO marker is the OncLive article date; the FDA approval date (2026-08-26) from the FDA page. The topline announcement date that appeared in an earlier version was not confirmed from a primary source and was removed.
