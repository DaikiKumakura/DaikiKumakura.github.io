# Repotrectinib escalation timing simulation

Independent implementation of the structural equations in Du et al. (2025),
DOI 10.1002/psp4.70036, final Table2 parameters. Not patient refitting,
observed-data validation or an exact reproduction of the original NONMEM run.
No clinical regimen recommendation or efficacy/safety risk prediction.

Python version and library versions: outputs/environment.json.
Install requirements.txt in your chosen environment.
Run `python analysis/run_analysis.py` to regenerate CSVs and figures.
Run `python -m unittest discover -s analysis -p "test_*.py" -q`.

Adult cancer patient, 70kg, fasted, no interruptions, seed20261011,
256 conditional virtual subjects sharing eta across regimens.
Escalation follows7,14,21 complete days: first BID dose at168,336,504h.
Follow-up ends672h, predose on day29. Doses160mg, QD then BID.
Primary implementation holds exact predose concentration between dosing
events and varies the time factor continuously. The frozen_CL scenario
freezes clearance at dose events; it is not an exact NONMEM implementation.
OMEGA diagonal CL/VC/Q/KA/logitF=.289/.768/.458/.0961/.355; VP fixed0.
Fixed-effect uncertainty uses marginal bounds one parameter at a time;
the resulting range is not a joint confidence interval.
Food categories are model categories, not randomized meal interventions.
EC50=77ng/mL describes induction, not an efficacy threshold.
All figures are original. Source articles and supplements are not redistributed.

peak8_21 uses calendar168-504h, before the delayed-regimen escalation.
post_switch_peak72 uses each regimen's escalation time through72h later.
trough28 means the end of28 complete days, day29 predose, not day28 predose.
The time origin and model populations differ from published EBE summaries.
Clinical label means are not a matched typical-patient validation target.
