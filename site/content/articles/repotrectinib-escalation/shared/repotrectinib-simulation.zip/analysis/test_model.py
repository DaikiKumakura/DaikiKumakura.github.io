import unittest
from dataclasses import replace
import numpy as np
from scipy.linalg import expm
from model import Parameters,simulate,endpoints,dose_times

class ModelTests(unittest.TestCase):
    def test_dose_count(self):
        self.assertEqual([len(dose_times(d)) for d in [7,14,21]],[49,42,35])
    def test_mass_balance(self):
        for d in [7,14,21]:
            self.assertLess(simulate(d,end=672)['mass_error'],1e-7)
    def test_linear_independent(self):
        p=replace(Parameters(),imax=0)
        s=simulate(14,p,end=672,dt=.1)
        m=np.array([[-p.ka,0,0],[p.ka,-(p.cl+p.q)/p.vc,p.q/p.vp],[0,p.q/p.vc,-p.q/p.vp]])
        y=sum((expm(m*(672-t-p.lag))@np.array([160*p.f,0,0]) for t in dose_times(14)),np.zeros(3))
        self.assertAlmostEqual(s['conc'][-1,0],1000*y[1]/p.vc,places=5)
    def test_adaptive_independent_solver(self):
        a=endpoints(simulate(14,dt=.1)); b=endpoints(simulate(14,dt=3,adaptive=True))
        for k in ['auc28','trough28']:
            self.assertLess(abs(a[k][0]/b[k][0]-1),1e-5)
    def test_same_first_week(self):
        a=simulate(7); b=simulate(21)
        np.testing.assert_array_equal(a['conc'][a['time']<=168],b['conc'][b['time']<=168])
    def test_negative_control(self):
        p=replace(Parameters(),imax=0)
        s=simulate(14,p)
        self.assertTrue(np.all(s['cl']==7.1))

if __name__=='__main__': unittest.main()
