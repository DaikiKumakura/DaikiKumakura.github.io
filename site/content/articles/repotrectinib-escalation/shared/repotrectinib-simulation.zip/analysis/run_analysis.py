"""Generate all tables and original figures; fixed public-model simulation."""
from pathlib import Path
from dataclasses import replace
import csv,json,platform
import numpy as np
import scipy
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from model import Parameters, FOOD, OMEGA, CI, simulate, endpoints

ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'outputs'; FIG=OUT/'figures'; TAB=OUT/'tables'
N=256; SEED=20261011
COLORS=['#0072B2','#444444','#D55E00']; STYLES=['-','--',':']

def save_csv(name,rows):
    with (TAB/name).open('w',encoding='utf8',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0])); w.writeheader(); w.writerows(rows)

def style(ax):
    ax.spines[['top','right']].set_visible(False)
    ax.grid(axis='y',alpha=.18); ax.set_axisbelow(True)

def main():
    FIG.mkdir(parents=True,exist_ok=True); TAB.mkdir(parents=True,exist_ok=True)
    p=Parameters(); reg=[7,14,21]; typical={d:simulate(d,p) for d in reg}
    te={d:endpoints(s) for d,s in typical.items()}
    rows=[]
    for d in reg:
        row={'escalate_after_days':d,'dose_mg':typical[d]['dose_mg']}
        row.update({k:float(v[0]) for k,v in te[d].items()}); rows.append(row)
    save_csv('typical.csv',rows)
    eta=np.random.default_rng(SEED).normal(size=(N,5))*np.sqrt(OMEGA)
    population={d:endpoints(simulate(d,p,eta=eta)) for d in reg}
    paired=[]
    for d in [7,21]:
        for k in ['auc28','peak8_21','trough28','predose15','predose22','post_switch_peak72','peak28']:
            x=population[d][k]/population[14][k]; q=np.quantile(x,[.05,.5,.95])
            paired.append({'escalate_after_days':d,'endpoint':k,'p05_ratio':float(q[0]),
                           'median_ratio':float(q[1]),'p95_ratio':float(q[2]),'n':N})
    save_csv('paired.csv',paired)
    sensitivity=[]
    for name,bounds in CI.items():
        for side,val in zip(['low','high'],bounds):
            pp=replace(p,**{name:val}); es={d:endpoints(simulate(d,pp)) for d in reg}
            for d in [7,21]:
                row={'parameter':name,'side':side,'value':val,'escalate_after_days':d}
                row.update({k:float(es[d][k][0]/es[14][k][0]) for k in ['auc28','peak8_21','trough28']})
                sensitivity.append(row)
    save_csv('sensitivity.csv',sensitivity)
    scenarios=[]
    for name,pp,weight,mode in [('fasted',p,70,'continuous'),
          *[(f,replace(p,ka=k,f=b),70,'continuous') for f,(k,b) in FOOD.items() if f!='fasted'],
          ('weight48',p,48,'continuous'),('weight105',p,105,'continuous'),
          ('frozen_CL',p,70,'frozen'),('source_order',p,70,'source_order'),('no_induction',replace(p,imax=0),70,'continuous')]:
        es={d:endpoints(simulate(d,pp,weight=weight,mode=mode)) for d in reg}
        for d in [7,21]:
            row={'scenario':name,'escalate_after_days':d}
            row.update({k:float(es[d][k][0]/es[14][k][0]) for k in ['auc28','peak8_21','trough28']})
            scenarios.append(row)
    save_csv('scenarios.csv',scenarios)
    fine=endpoints(simulate(14,p,dt=.1)); adapt=endpoints(simulate(14,p,dt=3,adaptive=True))
    verification={k:{'step_halving_relative_error':float(abs(te[14][k][0]/fine[k][0]-1)),
                       'adaptive_relative_error':float(abs(te[14][k][0]/adapt[k][0]-1))}
                  for k in ['auc28','trough28']}
    verification['mass_error_mg']=max(s['mass_error'] for s in typical.values())
    verification['early_trace_identity']=bool(np.array_equal(typical[7]['conc'][typical[7]['time']<=168],typical[14]['conc'][typical[14]['time']<=168]))
    (OUT/'verification.json').write_text(json.dumps(verification,indent=2)+'\n')
    (OUT/'environment.json').write_text(json.dumps({'python':platform.python_version(),'numpy':np.__version__,
        'scipy':scipy.__version__,'matplotlib':matplotlib.__version__,'seed':SEED,'n':N},indent=2)+'\n')
    plt.rcParams.update({'font.size':11,'font.family':'DejaVu Sans'})
    fig,axes=plt.subplots(2,1,figsize=(9,7),sharex=True,layout='constrained')
    for d,col,ls in zip(reg,COLORS,STYLES):
        s=typical[d]; label=f'Escalation after {d} days'
        axes[0].plot(s['time']/24,s['conc'][:,0],color=col,ls=ls,lw=1.4,label=label)
        axes[1].plot(s['time']/24,s['cl'][:,0],color=col,ls=ls,lw=1.6)
    axes[0].set(ylabel='Plasma concentration (ng/mL)',ylim=(0,None),title='Concentration and clearance by escalation timing')
    axes[0].legend(fontsize=10,ncol=1)
    axes[1].set(xlabel='Time since first dose (days)',ylabel='Clearance (L/h)',ylim=(0,None),xlim=(0,28))
    fig.suptitle('Typical adult, 70 kg, fasted; published fixed parameters',fontsize=11)
    for ax in axes: style(ax)
    fig.savefig(FIG/'01-timecourse.png',dpi=180); plt.close(fig)
    fig,axes=plt.subplots(1,3,figsize=(10,4),layout='constrained')
    for ax,k,title in zip(axes,['auc28','post_switch_peak72','trough28'],['AUC, days 1–28','Peak, 72 h after escalation','Predose, day 29']):
        for d,col,marker in [(7,COLORS[0],'o'),(21,COLORS[2],'s')]:
            row=next(r for r in paired if r['endpoint']==k and r['escalate_after_days']==d)
            ax.errorbar(row['median_ratio'],d,xerr=[[row['median_ratio']-row['p05_ratio']],[row['p95_ratio']-row['median_ratio']]],fmt=marker,color=col,capsize=4)
        ax.axvline(1,color='#444444',ls='--',lw=1); ax.set(title=title,xlabel='Paired ratio vs 14-day lead-in',yticks=[7,21],yticklabels=['7-day','21-day'],ylim=(25,3),xlim=(.65,1.2))
        style(ax)
    fig.suptitle(f'Conditional virtual patients: n={N}, 70 kg, fasted; median and 5th–95th percentiles',fontsize=11)
    fig.savefig(FIG/'02-paired.png',dpi=180); plt.close(fig)
    fig,axes=plt.subplots(1,2,figsize=(10,4),layout='constrained')
    for ax,d,col in zip(axes,[7,21],[COLORS[0],COLORS[2]]):
        ks=['auc28','peak8_21','trough28']
        for i,k in enumerate(ks):
            vals=[r[k] for r in sensitivity if r['escalate_after_days']==d]
            ax.plot([min(vals),max(vals)],[i,i],color=col,lw=5,alpha=.55)
            ax.plot(te[d][k][0]/te[14][k][0],i,'o',color=col)
        ax.axvline(1,color='#444444',ls='--',lw=1)
        ax.set(yticks=range(3),yticklabels=['AUC, days 1–28','Peak, days 8–21','Predose, day 29'],xlabel='Ratio vs 14-day lead-in',title=f'{d}-day lead-in')
        style(ax)
    fig.suptitle('One-at-a-time fixed-effect sensitivity: marginal parameter bounds, not output CI',fontsize=11)
    fig.savefig(FIG/'03-sensitivity.png',dpi=180); plt.close(fig)
    print(json.dumps({'typical':rows,'paired':paired,'verification':verification},indent=2))

if __name__=='__main__': main()
