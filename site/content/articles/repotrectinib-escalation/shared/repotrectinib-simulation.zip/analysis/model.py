"""Independent implementation of Du2025 Table2 structural model; not NONMEM."""
from dataclasses import dataclass, replace
import numpy as np
from scipy.integrate import solve_ivp

@dataclass(frozen=True)
class Parameters:
    cl: float = 7.1
    vc: float = 19.8
    vp: float = 221.0
    q: float = 4.98
    ka: float = .0541
    f: float = .52
    lag: float = .421
    imax: float = 1.59
    ec50: float = 77.0
    tc50: float = 47.2
    wcl: float = .477
    wv: float = .962

FOOD = {'fasted':(.0541,.52), 'fed':(.124,.76),
        'modified':(.141,.639), 'unknown':(.193,.533)}
OMEGA = np.array([.289,.768,.458,.0961,.355])
CI = {'cl':(6.471,7.729),'vc':(16.12,23.48),'vp':(203.7,238.3),
      'q':(4.347,5.613),'ka':(.0501,.0581),'f':(.4665,.5735),
      'lag':(.4073,.4347),'imax':(1.464,1.716),
      'ec50':(62.93,91.07),'tc50':(26.23,68.17)}

def dose_times(escalation: int, end: float=672.) -> np.ndarray:
    if escalation not in (7,14,21):
        raise ValueError('Escalation must follow 7, 14 or 21 complete days.')
    switch = 24.*escalation
    return np.concatenate([np.arange(0.,switch,24.),np.arange(switch,end,12.)])

def individual(p: Parameters, eta: np.ndarray, weight: float):
    eta=np.atleast_2d(eta)
    if eta.shape[1]!=5 or weight<=0 or not 0<p.f<1:
        raise ValueError('Invalid subject parameters')
    cscale=(weight/70.)**p.wcl; vscale=(weight/70.)**p.wv
    cl=p.cl*cscale*np.exp(eta[:,0]); vc=p.vc*vscale*np.exp(eta[:,1])
    q=p.q*cscale*np.exp(eta[:,2]); ka=p.ka*np.exp(eta[:,3])
    f=1/(1+np.exp(-(np.log(p.f/(1-p.f))+eta[:,4])))
    return cl,vc,np.full(len(eta),p.vp*vscale),q,ka,f

def derivative(t,y,held,pars,p,frozen=None):
    cl0,vc,vp,q,ka,f=pars
    cl=cl0*np.exp(p.imax*held/(p.ec50+held)*t/(p.tc50+t)) if frozen is None else frozen
    absorption=ka*y[:,0]; elimination=cl*y[:,1]/vc
    exchange=q*(y[:,1]/vc-y[:,2]/vp)
    return np.column_stack([-absorption,absorption-elimination-exchange,exchange,
                            1000*y[:,1]/vc,elimination])

def simulate(escalation=14,p=Parameters(),eta=None,weight=70.,dt=.2,
             mode='continuous',adaptive=False,end=672.):
    if eta is None: eta=np.zeros((1,5))
    pars=individual(p,eta,weight); cl0,vc,vp,q,ka,f=pars
    # Keep explicit integration stable even for the small-volume tail.
    rate_bound=np.max(ka+(cl0*np.exp(p.imax)+q)/vc+q/vp)
    if not adaptive: dt=min(dt,.5/rate_bound)
    doses=dose_times(escalation,end)
    grid=np.unique(np.round(np.r_[np.arange(0,end,dt),end,doses,doses+p.lag],9))
    grid=grid[grid<=end]
    dosing={round(x,9) for x in doses}; release={round(x+p.lag,9) for x in doses}
    y=np.zeros((len(cl0),5)); held=np.zeros(len(cl0)); frozen=cl0.copy()
    trace=np.zeros((len(grid),len(cl0))); clearance=np.zeros_like(trace)
    auc=np.zeros_like(trace); mass=0.
    for k,t in enumerate(grid):
        if t in dosing:
            new_held=1000*y[:,1]/vc
            driver=held if mode=='source_order' else new_held
            frozen=cl0*np.exp(p.imax*driver/(p.ec50+driver)*t/(p.tc50+t))
            held=new_held
        if t in release:
            y[:,0]+=160*f; mass+=160.
        trace[k]=1000*y[:,1]/vc; auc[k]=y[:,3]
        clearance[k]=cl0*np.exp(p.imax*held/(p.ec50+held)*t/(p.tc50+t)) if mode=='continuous' else frozen
        if k==len(grid)-1: break
        h=grid[k+1]-t
        frozen_arg=None if mode=='continuous' else frozen
        if adaptive:
            n=len(cl0)
            sol=solve_ivp(lambda tt,yy: derivative(tt,yy.reshape(n,5),held,pars,p,frozen_arg).ravel(),
                          (t,t+h),y.ravel(),rtol=1e-9,atol=1e-10)
            if not sol.success: raise RuntimeError(sol.message)
            y=sol.y[:,-1].reshape(n,5)
        else:
            a=derivative(t,y,held,pars,p,frozen_arg)
            b=derivative(t+h/2,y+h*a/2,held,pars,p,frozen_arg)
            c=derivative(t+h/2,y+h*b/2,held,pars,p,frozen_arg)
            d=derivative(t+h,y+h*c,held,pars,p,frozen_arg)
            y+=h*(a+2*b+2*c+d)/6
    assert np.min(y[:,:3])>=-1e-6
    error=np.max(np.abs(y[:,:3].sum(axis=1)+y[:,4]-mass*f))
    assert error<1e-6
    return {'time':grid,'conc':trace,'auc':auc,'cl':clearance,'dose_mg':mass,'escalation':escalation,
            'mass_error':float(error)}

def endpoints(s):
    t=s['time']; c=s['conc']; a=s['auc']
    def ix(time): return int(np.argmin(np.abs(t-time)))
    switch=24*s['escalation']
    return {'auc28':a[-1], 'auc8_21':a[ix(504)]-a[ix(168)],
            'peak1_7':c[t<=168].max(axis=0),
            'peak8_21':c[(t>=168)&(t<=504)].max(axis=0),
            'peak28':c.max(axis=0),'post_switch_peak72':c[(t>=switch)&(t<=switch+72)].max(axis=0),
            'predose15':c[ix(336)],'predose22':c[ix(504)],
            'trough28':c[-1], 'cl28':s['cl'][-1]}
