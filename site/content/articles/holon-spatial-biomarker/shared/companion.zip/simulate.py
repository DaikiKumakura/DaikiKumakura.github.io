"""Synthetic spatial layout illustration. No patient data or model predictions."""
from pathlib import Path
import csv
import json
import random
import statistics

OUT = Path(__file__).resolve().parent
N = 16
SEED = 20261026

def gradient(a):
    diffs = [abs(a[y*N+x]-a[y*N+x+1]) for y in range(N) for x in range(N-1)]
    diffs += [abs(a[y*N+x]-a[(y+1)*N+x]) for y in range(N-1) for x in range(N)]
    return statistics.mean(diffs)

def main():
    split = [int(x < N//2) for y in range(N) for x in range(N)]
    checker = [(x+y)%2 for y in range(N) for x in range(N)]
    rng = random.Random(SEED)
    shuffled = split.copy()
    scores = []
    for _ in range(1000):
        rng.shuffle(shuffled)
        scores.append(gradient(shuffled))
    result = {"synthetic_only": True, "n": N, "seed": SEED, "iterations": len(scores),
              "mean": statistics.mean(split), "population_variance": statistics.pvariance(split),
              "split_G": gradient(split), "checker_G": gradient(checker),
              "shuffle_mean_G": statistics.mean(scores), "shuffle_sd_G": statistics.stdev(scores),
              "shuffle_expected_G": 128/255}
    (OUT/'summary.json').write_text(json.dumps(result, indent=2)+'\n', encoding='utf-8')
    with (OUT/'shuffles.csv').open('w', newline='', encoding='utf-8') as f:
        w=csv.writer(f); w.writerow(['iteration','G']); w.writerows(enumerate(scores,1))
    svg=['<svg xmlns="http://www.w3.org/2000/svg" width="960" height="440" viewBox="0 0 960 440">',
         '<rect width="960" height="440" fill="#fff"/>',
         '<g font-family="Arial,sans-serif" fill="#172b40">',
         '<text x="30" y="35" font-size="24">Same values. Different spatial arrangement.</text>',
         '<text x="30" y="65" font-size="17">Synthetic illustration only | 16 x 16 | mean 0.5 | variance 0.25</text>']
    for left,a,label in [(70,split,'Split'),(550,checker,'Checkerboard')]:
        for y in range(N):
            for x in range(N):
                color='#167d9a' if a[y*N+x] else '#e8edf1'
                svg.append(f'<rect x="{left+x*16}" y="{95+y*16}" width="15" height="15" fill="{color}"/>')
        svg.append(f'<text x="{left}" y="385" font-size="20">{label}: G = {gradient(a):.4f}</text>')
    svg.append('<text x="30" y="425" font-size="16">G: mean absolute difference over horizontal and vertical edges; no wrapping</text></g></svg>')
    figures=OUT/'figures'; figures.mkdir(exist_ok=True)
    (figures/'spatial-layout.svg').write_text('\n'.join(svg),encoding='utf-8')
    print(json.dumps(result, indent=2))

if __name__ == '__main__':
    main()
