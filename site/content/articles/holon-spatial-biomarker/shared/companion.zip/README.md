# Synthetic spatial-layout illustration

This companion illustrates how two maps with identical values have different local spatial statistics. It is not a replication of Holon-S1 or its gEREG implementation. It contains no patient data, images, predictions, or clinical performance estimates.

Run `python simulate.py` with Python 3.11 or later. Only the standard library is required. Outputs are `summary.json`, `shuffles.csv` and `figures/spatial-layout.svg`.

The 16 by 16 grid contains 128 zeros and 128 ones. G is the mean absolute difference over the 480 horizontal and vertical edges, without periodic boundaries. The split grid has 16 unlike edges (G=1/30); the checkerboard has 480 (G=1). A fixed-seed sequence of 1,000 value-preserving random permutations has mean G=0.5019458. Its theoretical expectation is 128/255. This is an illustration of spatial arrangement, not a biological null model.

The article discusses the public technical report at https://sophont.med/blog/holon/ . Report text and images are not redistributed here. Original companion code and synthetic outputs are provided under the MIT license in LICENSE.txt.
