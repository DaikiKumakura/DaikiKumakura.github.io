import numpy as np
from scipy.integrate import quad

import analysis as an


def test_ka_reproduces_peak():
    k = np.log(2) / 22.0
    ka = an.ka_from_tmax(k)
    assert abs(np.log(ka / k) / (ka - k) - an.TMAX) < 1e-6


def test_average_concentration_equals_auc_over_tau():
    k = np.log(2) / 25.0
    ka = an.ka_from_tmax(k)
    tau, n = 42.0, an.N_DOSES
    t0 = (n - 1) * tau
    auc = quad(lambda t: an.conc(t, tau, k, ka), t0, t0 + tau, limit=200)[0]
    assert abs(auc / tau - an.F / (k * tau)) < 2e-3 * an.F / (k * tau)


def test_implied_half_life_inverts_accumulation():
    h = an.implied_half_life(42.0, 1.6)
    k = np.log(2) / h
    assert abs(an.accumulation_exact(k, an.ka_from_tmax(k), 42.0) - 1.6) < 1e-9


def test_first_interval_auc_matches_quadrature():
    k = np.log(2) / 25.0
    ka = an.ka_from_tmax(k)
    num = quad(lambda t: an.conc(t, 42.0, k, ka, n=1), 0, 42.0)[0]
    assert abs(num - an.auc_first_interval(k, ka, 42.0)) < 1e-6 * num


def test_longer_half_life_raises_trough_over_average():
    assert an.model_values(30.0, 42.0)["trough_over_avg"] > an.model_values(22.0, 42.0)["trough_over_avg"]


def test_population_with_zero_variability_equals_typical_model():
    d = an.simulate_population(cv_cl=0.0, cv_f=0.0, n=50)
    ref = an.model_values(an.HALF_LIFE_LABEL, 42.0)
    assert abs(d.mean_ctrough_over_mean_avg[0] - ref["trough_over_avg"]) < 1e-6
    assert abs(d.accumulation_of_means[0] - ref["accumulation"]) < 1e-6
