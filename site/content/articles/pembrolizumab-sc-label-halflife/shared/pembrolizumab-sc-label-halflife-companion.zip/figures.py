"""Figure 1: model trough/average ratio and accumulation ratio versus half-life, with the label's steady-state values."""
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np

import analysis as an

ROOT = Path(__file__).resolve().parent
(ROOT / "figures").mkdir(exist_ok=True)
hl = np.linspace(15, 40, 51)
fig, axes = plt.subplots(1, 2, figsize=(9.0, 3.8), dpi=150)
colors = {"790 mg every 6 weeks": "#0072B2", "395 mg every 3 weeks": "#D55E00"}
for name, (tau, dose, auc, ctr, acc) in an.LABEL.items():
    vals = [an.model_values(h, tau) for h in hl]
    axes[0].plot(hl, [v["trough_over_avg"] for v in vals], color=colors[name], lw=2, label=name)
    axes[0].axhline(ctr / (auc / tau), color=colors[name], lw=1, ls="--")
    axes[1].plot(hl, [v["accumulation"] for v in vals], color=colors[name], lw=2, label=name)
    axes[1].axhline(acc, color=colors[name], lw=1, ls="--")
for ax, ylab in zip(axes, ("Ctrough / average concentration (steady state)", "Accumulation ratio")):
    ax.axvline(an.HALF_LIFE_LABEL, color="#555555", lw=1, ls=":")
    ax.set_xlabel("Half-life in the model (days)")
    ax.set_ylabel(ylab)
axes[0].text(22.3, 0.40, "label 22 d", fontsize=7, color="#555555")
axes[0].legend(fontsize=7, loc="lower right")
axes[0].set_title("Trough / average (dashed: label)", fontsize=9)
axes[1].set_title("Accumulation ratio (dashed: label)", fontsize=9)
fig.tight_layout()
fig.savefig(ROOT / "figures" / "01-half-life-consistency.png")
