# Subcutaneous pembrolizumab label half-life check: companion code

Compares the steady-state values in the Keytruda Qlex label with a one-compartment model (typical patient and a model with between-patient variability).

- `analysis.py`: model, implied half-lives, variability simulation, result tables.
- `figures.py`: Figure 1.
- `test_analysis.py`: checks (`python -m pytest test_analysis.py`).
- `results/`: CSV outputs.

Inputs are published prescribing-information values. No patient data. Requires Python 3 with numpy, scipy, pandas, matplotlib.
