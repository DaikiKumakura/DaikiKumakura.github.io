"""Is the 22-day half-life in the Keytruda Qlex label consistent with the label's own steady-state values?

Label (section 12.3): at steady state after SC dosing, AUC0-6wk 2,798 ug*day/mL and Ctrough 39 ug/mL (790 mg every 6 weeks),
AUC0-3wk 1,343 ug*day/mL and Ctrough 49 ug/mL (395 mg every 3 weeks); systemic accumulation ratio 1.6 (q6w) and 2.5 (q3w);
bioavailability about 60%, peak by about 4 days, terminal half-life 22 days, steady-state clearance 195 mL/day.
Model: one compartment with first-order absorption (ka from the 4-day peak), typical patient, constant clearance.
The label text read does not define the accumulation ratio; it is taken here as AUC at steady state over AUC of the first dosing interval
(exact expression for a model with first-order absorption).
"""
from pathlib import Path

import numpy as np
import pandas as pd
from scipy.optimize import brentq

ROOT = Path(__file__).resolve().parent
OUT = ROOT / "results"
OUT.mkdir(exist_ok=True)

LABEL = {  # regimen: (tau days, dose mg, AUC ss, Ctrough ss, accumulation ratio)
    "790 mg every 6 weeks": (42.0, 790.0, 2798.0, 39.0, 1.6),
    "395 mg every 3 weeks": (21.0, 395.0, 1343.0, 49.0, 2.5)}
F, TMAX, HALF_LIFE_LABEL, CL_LABEL = 0.60, 4.0, 22.0, 0.195
N_DOSES = 40


def ka_from_tmax(k: float, tmax: float = TMAX) -> float:
    return brentq(lambda a: np.log(a / k) / (a - k) - tmax, k * 1.01, 50.0)


def conc(t: float, tau: float, k: float, ka: float, n: int = N_DOSES, f: float = F) -> float:
    """Concentration x V per unit dose after n doses (superposition)."""
    out = 0.0
    for i in range(n):
        tt = t - i * tau
        if tt > 0:
            out += f * ka / (ka - k) * (np.exp(-k * tt) - np.exp(-ka * tt))
    return out


def auc_first_interval(k, ka, tau, f=F):
    """AUC over the first dosing interval per unit dose and V, one compartment with first-order absorption."""
    return f / k * (1.0 - (ka * np.exp(-k * tau) - k * np.exp(-ka * tau)) / (ka - k))


def accumulation_exact(k, ka, tau, f=F):
    """Steady-state AUC over one interval divided by the AUC of the first interval."""
    return (f / k) / auc_first_interval(k, ka, tau, f)


def model_values(half_life: float, tau: float) -> dict:
    k = np.log(2) / half_life
    ka = ka_from_tmax(k)
    trough = conc(N_DOSES * tau, tau, k, ka)
    avg = F / (k * tau)                      # steady-state average, per unit dose and V
    return dict(trough_over_avg=trough / avg, accumulation=accumulation_exact(k, ka, tau))


def implied_half_life(tau: float, accumulation: float) -> float:
    def gap(h):
        k = np.log(2) / h
        return accumulation_exact(k, ka_from_tmax(k), tau) - accumulation
    return brentq(gap, 8.0, 80.0)


def trough_ratio_cycle3(half_life: float) -> float:
    """SC 790 mg / IV 400 mg, both every 6 weeks: concentration at the end of cycle 3 (IV as boluses), same k in both arms."""
    k = np.log(2) / half_life
    ka = ka_from_tmax(k)
    sc = 790.0 * conc(3 * 42.0, 42.0, k, ka, n=3)
    iv = sum(400.0 * np.exp(-k * (3 * 42.0 - i * 42.0)) for i in range(3))
    return sc / iv


def main() -> None:
    rows = []
    for name, (tau, dose, auc, ctr, acc) in LABEL.items():
        cavg = auc / tau
        rows.append(dict(regimen=name, cavg_ss=cavg, ctrough_over_cavg=ctr / cavg, accumulation_label=acc,
                         half_life_from_accumulation=implied_half_life(tau, acc),
                         half_life_from_trough_over_avg=brentq(lambda h: model_values(h, tau)["trough_over_avg"] - ctr / cavg, 8.0, 80.0),
                         cl_from_auc_f060=F * dose / auc, f_for_cl_195=CL_LABEL * auc / dose))
    lab = pd.DataFrame(rows)
    lab.round(4).to_csv(OUT / "label-implied.csv", index=False, lineterminator=chr(10))
    pd.set_option("display.width", 220)
    print(lab.round(3).T.to_string())
    grid = []
    for h in (22.0, 25.0, 29.0, 30.0):
        for name, (tau, *_rest) in LABEL.items():
            grid.append(dict(half_life=h, regimen=name, **model_values(h, tau)))
    g = pd.DataFrame(grid)
    g.round(4).to_csv(OUT / "model-by-half-life.csv", index=False, lineterminator=chr(10))
    print(g.round(3).to_string())
    tr = pd.DataFrame([dict(half_life=h, cycle3_trough_ratio_sc_iv=trough_ratio_cycle3(h)) for h in (22.0, 26.0, 28.0, 30.0)])
    tr.round(3).to_csv(OUT / "cycle3-trough-ratio-by-half-life.csv", index=False, lineterminator=chr(10))
    print(tr.round(3).to_string())
    print("Cavg ratio q6w/q3w:", lab.cavg_ss[0] / lab.cavg_ss[1])


if __name__ == "__main__":
    main()


# ---- between-patient variability (added after review): arithmetic means of individual values vs the typical-patient model ----
CV_CL, CV_F = 0.40, 0.14
V_L = 6.0
SEED, N_SIM = 20261101, 20000


def lognormal(rng, mean: float, cv: float, n: int):
    s2 = np.log(1 + cv ** 2)
    return rng.lognormal(np.log(mean) - s2 / 2, np.sqrt(s2), n)


def simulate_population(half_life: float = HALF_LIFE_LABEL, cv_cl: float = CV_CL, cv_f: float = CV_F, n: int = N_SIM, seed: int = SEED, anchor: str = "mean") -> pd.DataFrame:
    """Individual CL (lognormal, mean from the label half-life and V), F (lognormal), V fixed; constant clearance; ka from the 4-day peak at the typical k."""
    rng = np.random.default_rng(seed)
    cl_typ = V_L * np.log(2) / half_life
    # anchor: whether the clearance implied by the 22-day half-life is the arithmetic mean or the median of the individual clearances
    cl_mean = cl_typ if anchor == "mean" else cl_typ * np.sqrt(1 + cv_cl ** 2)
    cl = lognormal(rng, cl_mean, cv_cl, n)
    f = np.clip(lognormal(rng, F, cv_f, n), 0.05, 1.0)
    k_all = cl / V_L
    ka = ka_from_tmax(np.log(2) / half_life)
    rows = []
    for name, (tau, dose, auc, ctr, acc) in LABEL.items():
        tr = np.array([conc(N_DOSES * tau, tau, k, ka, f=ff) for k, ff in zip(k_all, f)])
        avg = f / (k_all * tau)
        auc1 = np.array([auc_first_interval(k, ka, tau, ff) for k, ff in zip(k_all, f)])
        rows.append(dict(regimen=name, mean_ctrough_over_mean_avg=tr.mean() / avg.mean(), mean_of_individual_ratios=float(np.mean(tr / avg)),
                         mean_accumulation=float(np.mean((f / k_all) / auc1)), accumulation_of_means=float(np.mean(f / k_all) / np.mean(auc1)),
                         mean_cavg_ug_per_ml=float(np.mean(dose * avg)) / V_L, mean_ctrough_ug_per_ml=float(np.mean(dose * tr)) / V_L))
    return pd.DataFrame(rows)


def run_population() -> None:
    out = []
    for cv, anchor in ((0.0, "mean"), (0.2, "mean"), (0.4, "mean"), (0.4, "median")):
        d = simulate_population(cv_cl=cv, anchor=anchor)
        d.insert(0, "cv_cl", cv)
        d.insert(1, "anchor", anchor)
        out.append(d)
    pop = pd.concat(out)
    pop.round(4).to_csv(OUT / "population-variability.csv", index=False, lineterminator=chr(10))
    print(pop.round(3).to_string())


if __name__ == "__main__":
    run_population()
