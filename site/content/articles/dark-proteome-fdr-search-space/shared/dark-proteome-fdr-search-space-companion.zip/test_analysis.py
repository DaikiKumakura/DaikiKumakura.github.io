import numpy as np
from scipy.stats import norm

import analysis as an


def test_null_max_matches_theoretical_distribution():
    rng = np.random.default_rng(1)
    x = an.null_max(300, 200_000, rng)
    # P(max <= z) = Phi(z)^n
    for z in (2.5, 3.0, 3.5):
        assert abs((x <= z).mean() - norm.cdf(z) ** 300) < 0.005


def test_global_estimated_fdr_equals_target_and_matches_true_fdp():
    d = an.run(10, n_rep=5)
    assert abs(d.global_estimated_fdr.mean() - an.TARGET_FDR) < 0.0015
    assert abs(d.global_true_fdp.mean() - an.TARGET_FDR) < 0.003


def test_without_noncanonical_truth_all_accepted_noncanonical_psms_are_wrong():
    d = an.run(10, n_rep=3, p_nc=0.0)
    assert d.noncanonical_true_fdp.mean() > 0.8


def test_separate_threshold_controls_subset_fdp_near_target():
    d = an.run(30, n_rep=8)
    assert d.nc_separate_true_fdp.mean() < 0.03
