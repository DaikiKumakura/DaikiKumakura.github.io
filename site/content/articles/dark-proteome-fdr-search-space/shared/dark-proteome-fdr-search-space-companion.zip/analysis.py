"""Why a global 1% false discovery rate (FDR) does not bound the error rate among 'novel' peptides found in an enlarged search space.

Simulation of target-decoy competition (TDC) at the level of peptide-spectrum matches (PSM). All parameters are assumptions for illustration.
Each spectrum has a true source: a canonical peptide (probability P_CANON), a noncanonical peptide (P_NONCANON) or none.
A candidate peptide's match score is N(0, 1) for a wrong candidate and N(MU_TRUE, 1) for the true peptide.
A spectrum is compared with N_C canonical candidates and N_C * F noncanonical candidates (F = search-space factor) within the precursor tolerance;
the best wrong score among n candidates is the maximum of n standard normal draws (drawn exactly by inverse CDF).
The decoy database has the same size and composition. TDC: the best of the target and decoy hits is kept; FDR estimate = decoy PSMs / target PSMs above a score threshold.
'True FDP' is the fraction of accepted target PSMs whose best hit is a wrong candidate.
"""
from pathlib import Path

import numpy as np
import pandas as pd
from scipy.stats import norm

ROOT = Path(__file__).resolve().parent
OUT = ROOT / "results"
OUT.mkdir(exist_ok=True)

N_SPECTRA = 200_000
P_CANON, P_NONCANON = 0.30, 0.003      # share of spectra whose true peptide is canonical / noncanonical (assumed)
MU_TRUE = 5.0                          # mean score of a true match (assumed)
N_C = 300                              # canonical candidates per spectrum within the precursor tolerance (assumed)
FACTORS = [1, 10, 30, 100]             # noncanonical candidates = N_C * F
TARGET_FDR = 0.01
SEED, N_REP = 20261103, 20


def null_max(n: float, size: int, rng) -> np.ndarray:
    """Maximum of n iid standard normal scores, drawn exactly (n may be non-integer)."""
    u = rng.random(size)
    return norm.isf(-np.expm1(np.log(u) / n))


def one_replicate(f: int, rng, n_spectra: int = N_SPECTRA, p_canon: float = P_CANON, p_nc: float = P_NONCANON) -> dict:
    n_nc = N_C * f
    cls = rng.choice(3, size=n_spectra, p=[p_canon, p_nc, 1 - p_canon - p_nc])      # 0 canonical, 1 noncanonical, 2 none
    true_score = np.where(cls < 2, rng.normal(MU_TRUE, 1.0, n_spectra), -np.inf)
    t_c, t_n = null_max(N_C, n_spectra, rng), null_max(n_nc, n_spectra, rng)       # best wrong target hit in each part
    d_c, d_n = null_max(N_C, n_spectra, rng), null_max(n_nc, n_spectra, rng)       # best decoy hit in each part
    cand = np.vstack([true_score, t_c, t_n])                                         # origins: true, wrong canonical, wrong noncanonical
    t_best, t_arg = cand.max(axis=0), cand.argmax(axis=0)
    dec = np.vstack([d_c, d_n])
    d_best, d_arg = dec.max(axis=0), dec.argmax(axis=0)
    target_wins = t_best > d_best                                                    # ties have probability zero
    score = np.where(target_wins, t_best, d_best)
    # origin label of each PSM: 'canonical' or 'noncanonical' (true peptide origin for correct hits, database part for wrong hits)
    t_origin = np.where(t_arg == 0, np.where(cls == 1, 1, 0), np.where(t_arg == 1, 0, 1))
    d_origin = d_arg                                                                 # 0 canonical part, 1 noncanonical part
    origin = np.where(target_wins, t_origin, d_origin)
    wrong_target = target_wins & (t_arg != 0)
    return dict(score=score, target=target_wins, origin=origin, wrong=wrong_target)


def threshold_for_fdr(score, target, mask, fdr: float):
    """Lowest score threshold such that (decoys / targets) among masked PSMs is <= fdr; returns threshold or inf."""
    s, tg = score[mask], target[mask]
    order = np.argsort(-s)
    cum_t, cum_d = np.cumsum(tg[order]), np.cumsum(~tg[order])
    ok = np.where(cum_t > 0, cum_d / np.maximum(cum_t, 1) <= fdr, False)
    if not ok.any():
        return np.inf
    return s[order][np.where(ok)[0].max()]


def summarise(r: dict, thr_global: float, thr_nc: float) -> dict:
    sc, tg, org, wr = r["score"], r["target"], r["origin"], r["wrong"]
    out = {}
    for name, mask in (("canonical", org == 0), ("noncanonical", org == 1)):
        acc = tg & mask & (sc >= thr_global)
        dec = (~tg) & mask & (sc >= thr_global)
        out[f"{name}_accepted"] = int(acc.sum())
        out[f"{name}_true_fdp"] = float(wr[acc].mean()) if acc.sum() else np.nan
        out[f"{name}_estimated_fdr"] = float(dec.sum() / acc.sum()) if acc.sum() else np.nan
    allacc = tg & (sc >= thr_global)
    out["global_accepted"] = int(allacc.sum())
    out["global_true_fdp"] = float(wr[allacc].mean())
    out["global_estimated_fdr"] = float(((~tg) & (sc >= thr_global)).sum() / allacc.sum())
    sep = tg & (org == 1) & (sc >= thr_nc)
    out["noncanonical_true_accepted"] = int((tg & (org == 1) & (sc >= thr_global) & ~wr).sum())
    out["nc_separate_true_accepted"] = int((sep & ~wr).sum())
    out["nc_separate_accepted"] = int(sep.sum())
    out["nc_separate_true_fdp"] = float(wr[sep].mean()) if sep.sum() else np.nan
    return out


def run(f: int, seed: int = SEED, n_rep: int = N_REP, **kw) -> pd.DataFrame:
    rows = []
    for i in range(n_rep):
        rng = np.random.default_rng([seed, f, i])
        r = one_replicate(f, rng, **kw)
        thr_g = threshold_for_fdr(r["score"], r["target"], np.ones(len(r["score"]), bool), TARGET_FDR)
        thr_n = threshold_for_fdr(r["score"], r["target"], r["origin"] == 1, TARGET_FDR)
        rows.append(dict(factor=f, rep=i, thr_global=thr_g, thr_noncanonical=thr_n, **summarise(r, thr_g, thr_n)))
    return pd.DataFrame(rows)


def main() -> None:
    allrows = pd.concat([run(f) for f in FACTORS])
    allrows.round(5).to_csv(OUT / "replicates.csv", index=False, lineterminator=chr(10))
    g = allrows.groupby("factor")
    summ = g.agg(["mean", "std"]).round(4)
    summ.columns = ["_".join(c) for c in summ.columns]
    summ.to_csv(OUT / "summary.csv", lineterminator=chr(10))
    pd.set_option("display.width", 250)
    cols = ["global_estimated_fdr_mean", "global_true_fdp_mean", "canonical_true_fdp_mean", "noncanonical_accepted_mean", "noncanonical_estimated_fdr_mean",
            "noncanonical_true_fdp_mean", "noncanonical_true_fdp_std", "nc_separate_accepted_mean", "nc_separate_true_fdp_mean", "noncanonical_true_accepted_mean", "nc_separate_true_accepted_mean"]
    print(summ[cols].to_string())
    # prior sensitivity at F = 30: vary the share of spectra from noncanonical peptides
    rows = []
    for p_nc in (0.0003, 0.001, 0.003, 0.01):
        d = run(30, n_rep=10, p_nc=p_nc)
        rows.append(dict(p_noncanonical=p_nc, noncanonical_true_fdp=d.noncanonical_true_fdp.mean(), noncanonical_true_fdp_std=d.noncanonical_true_fdp.std(),
                         noncanonical_estimated_fdr=d.noncanonical_estimated_fdr.mean(), noncanonical_accepted=d.noncanonical_accepted.mean(),
                         nc_separate_true_fdp=d.nc_separate_true_fdp.mean(), nc_separate_true_fdp_std=d.nc_separate_true_fdp.std()))
    pr = pd.DataFrame(rows)
    pr.round(4).to_csv(OUT / "prior-sensitivity-f30.csv", index=False, lineterminator=chr(10))
    print(pr.round(3).to_string())
    # sensitivity to the score separation and the number of candidates per spectrum (F = 30, noncanonical share 0.003)
    global MU_TRUE, N_C
    mu0, nc0 = MU_TRUE, N_C
    rows = []
    for mu, n_c in ((4.0, 300), (5.0, 300), (6.0, 300), (5.0, 100), (5.0, 1000)):
        MU_TRUE, N_C = mu, n_c
        d = run(30, n_rep=10)
        rows.append(dict(mu_true=mu, canonical_candidates=n_c, noncanonical_true_fdp_global_threshold=d.noncanonical_true_fdp.mean(),
                         nc_separate_true_fdp=d.nc_separate_true_fdp.mean(), nc_separate_true_fdp_std=d.nc_separate_true_fdp.std(),
                         nc_separate_accepted=d.nc_separate_accepted.mean(), noncanonical_true_accepted_global=d.noncanonical_true_accepted.mean()))
    MU_TRUE, N_C = mu0, nc0
    se = pd.DataFrame(rows)
    se.round(4).to_csv(OUT / "score-separation-sensitivity-f30.csv", index=False, lineterminator=chr(10))
    print(se.round(3).to_string())


if __name__ == "__main__":
    main()
