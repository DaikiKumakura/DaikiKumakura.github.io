"""Figure 1: true false discovery proportion among accepted noncanonical PSMs versus search-space factor. Figure 2: effect of the prior share of noncanonical spectra."""
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import pandas as pd

ROOT = Path(__file__).resolve().parent
(ROOT / "figures").mkdir(exist_ok=True)
s = pd.read_csv(ROOT / "results" / "summary.csv", index_col=0)
fig, ax = plt.subplots(figsize=(6.8, 4.0), dpi=150)
ax.errorbar(s.index, 100 * s.noncanonical_true_fdp_mean, yerr=100 * s.noncanonical_true_fdp_std, marker="o", color="#D55E00", lw=2, label="Noncanonical PSMs, global 1% threshold (true FDP)")
ax.plot(s.index, 100 * s.noncanonical_estimated_fdr_mean, "x--", color="#D55E00", label="Same PSMs, FDR estimated from their own decoys")
ax.errorbar(s.index, 100 * s.nc_separate_true_fdp_mean, yerr=100 * s.nc_separate_true_fdp_std, marker="s", color="#0072B2", lw=2, label="Noncanonical PSMs, separate 1% threshold (true FDP)")
ax.axhline(1.0, color="#555555", ls=":", lw=1)
ax.set_xscale("log")
ax.set_xticks([1, 10, 30, 100])
ax.set_xticklabels(["1", "10", "30", "100"])
ax.set_xlabel("Noncanonical candidates per spectrum relative to canonical (F)")
ax.set_ylabel("False discovery proportion (%)")
ax.set_ylim(0, 60)
ax.legend(fontsize=7, loc="center right")
fig.tight_layout()
fig.savefig(ROOT / "figures" / "01-subset-fdp-by-search-space.png")

p = pd.read_csv(ROOT / "results" / "prior-sensitivity-f30.csv")
fig, ax = plt.subplots(figsize=(6.4, 3.8), dpi=150)
ax.errorbar(100 * p.p_noncanonical, 100 * p.noncanonical_true_fdp, yerr=100 * p.noncanonical_true_fdp_std, fmt="o-", color="#D55E00", lw=2, label="Global 1% threshold (true FDP)")
ax.errorbar(100 * p.p_noncanonical, 100 * p.nc_separate_true_fdp, yerr=100 * p.nc_separate_true_fdp_std, fmt="s-", color="#0072B2", lw=2, label="Separate 1% threshold (true FDP)")
ax.set_xscale("log")
ax.set_xlabel("Share of spectra from a noncanonical peptide (%), F = 30")
ax.set_ylabel("False discovery proportion (%)")
ax.legend(fontsize=8)
fig.tight_layout()
fig.savefig(ROOT / "figures" / "02-prior-sensitivity.png")
