# Subset false discovery rate in an enlarged search space: companion code

Peptide-spectrum-match-level simulation of target-decoy competition with canonical and noncanonical candidate pools. Compares the global 1% threshold with a threshold set on the novel part alone, and scans the search-space factor, the prior share of novel peptides and the score separation.

- `analysis.py`: simulation and summary tables.
- `figures.py`: Figures 1 and 2.
- `test_analysis.py`: checks (`python -m pytest test_analysis.py`).
- `results/`: CSV outputs.

All parameters are assumptions. No experimental data. Random seed 20261103. Requires Python 3 with numpy, scipy, pandas, matplotlib.
