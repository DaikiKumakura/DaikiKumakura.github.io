# Capivasertib rest-day placement

Independent Python implementation of published apparent-parameter PK equations.
Main parameter source: Fernandez Teruel et al. (2025), DOI 10.1111/cts.70286,
Table 2 and displayed equations. Sensitivity fit: Fernandez-Teruel et al. (2024),
DOI 10.1007/s40262-024-01407-x, Table 3.
Not patient refitting, original NONMEM equivalence or clinical validation.
No recommendation to change treatment and no efficacy/toxicity/recovery prediction.

Use the Python/library versions recorded in outputs/environment.json.
Install requirements.txt in your chosen environment.
Run python analysis/run_analysis.py to regenerate all CSVs, checks and figures.
Run python -m unittest discover -s analysis -p "test_*.py" -q.
Typical 67 kg, 57 years, tablet, not strict overnight fast, no paclitaxel.
All schedules: 8 doses of 400 mg per 168-hour week. Day numbers in model.py
are zero-based. Primary comparison: week 4 [504,672] hours.
Parallel first/zero-order input, lag only on first-order route; overlapping
zero-order inputs last 45 hours each. Every disposition parameter is apparent;
absolute bioavailability is not multiplied again.
Clearance uses calendar time from treatment start; it does not recover or reset
during rest periods. The planned per-dose amount remains 400 mg in all schedules.
256 conditional paired subjects, seed20261012: independent CL0, Vcentral and
Imax variations only. CV converted to log-normal SD; alternative convention
is a sensitivity scenario. This is not the full clinical population distribution.
Marginal bootstrap bounds vary one structural parameter at a time, not a joint CI.
Low-concentration cutoffs (5-50% of reference typical peak) are diagnostic only,
not established pharmacological thresholds. No E-R regression is extrapolated.
Figures are original; source figures, patient data and supplements are not bundled.
