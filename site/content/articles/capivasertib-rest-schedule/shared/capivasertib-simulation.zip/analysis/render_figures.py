"""Render publication figures from saved tables and typical profiles."""
from pathlib import Path
import csv
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from model import SCHEDULES, simulate
ROOT=Path(__file__).resolve().parents[1]
COLORS=['#0072B2','#E69F00','#009E73']
LABELS=['4 consecutive days','Two 2-day blocks','Alternating 4 days']
def read(name):
    with (ROOT/'outputs/tables'/name).open(encoding='utf8',newline='') as f: return list(csv.DictReader(f))
def main():
    typ=read('typical.csv'); paired=read('paired.csv'); cuts=read('cutoffs.csv')
    plt.rcParams.update({'font.size':10,'axes.spines.top':False,'axes.spines.right':False})
    fig,axs=plt.subplots(2,1,figsize=(9,6.5),sharex=True,layout='constrained',height_ratios=[3,1])
    for n,k in enumerate(SCHEDULES):
        s=simulate(k); use=s['t']>=504; x=(s['t'][use]-504)/24
        axs[0].plot(x,s['c'][use,0],color=COLORS[n],label=LABELS[n],lw=1.6,ls=['-','--',':'][n])
        days=np.array(SCHEDULES[k]); axs[1].scatter(days,np.ones(4)*(2-n),color=COLORS[n],marker='s',s=40,clip_on=False)
        axs[1].scatter(days+.5,np.ones(4)*(2-n),color=COLORS[n],marker='s',s=40)
    threshold=.1*float(typ[0]['cmax'])
    axs[0].axhline(threshold,color='#555555',ls=':',lw=1)
    axs[0].set(ylabel='Capivasertib (ng/mL)',title='Same weekly dose: 400 mg twice daily on four days',ylim=(0,1700))
    axs[0].legend(fontsize=9,ncol=3,loc='upper center')
    axs[1].set(xlabel='Time within week 4 (days)',yticks=[0,1,2],yticklabels=LABELS[::-1],xlim=(0,7),ylim=(-.25,2.25))
    axs[1].set_title('Dose times (8 doses per week)',fontsize=10)
    fig.savefig(ROOT/'outputs/figures/01-schedules.png',dpi=180); plt.close(fig)
    fig,axs=plt.subplots(1,3,figsize=(10,4.3),layout='constrained')
    for ax,key,title in zip(axs,['auc_week','cmax','cmin'],['Weekly AUC difference (%)','Weekly peak ratio','Weekly minimum ratio']):
        for n,k in enumerate(list(SCHEDULES)[1:]):
            r=next(x for x in paired if x['schedule']==k and x['metric']==key)
            xx=np.array([float(r[x]) for x in ['p05','median','p95']])
            typical=float(typ[n+1][key])/float(typ[0][key])
            if key=='auc_week': xx=100*(xx-1); typical=100*(typical-1)
            ax.errorbar(xx[1],1-n,xerr=[[xx[1]-xx[0]],[xx[2]-xx[1]]],fmt='o',color=COLORS[n+1],capsize=4)
            ax.plot(typical,1-n,'x',color='black',ms=7)
        ax.axvline(0 if key=='auc_week' else 1,color='#777777',lw=1,ls=':')
        ax.set(title=title,yticks=[0,1],yticklabels=['Alternating','Two blocks'],ylim=(-.5,1.5))
        ax.ticklabel_format(axis='x',style='plain',useOffset=False)
        if key=='auc_week': ax.set_xlim(-.001,.006); ax.set_xlabel('Percent relative to consecutive')
        elif key=='cmax': ax.set_xlim(.95,1.005); ax.set_xlabel('Ratio to consecutive')
        else: ax.set_xlim(0,13); ax.set_xlabel('Ratio to consecutive')
    fig.suptitle('Conditional paired simulation: n=256; 5th–95th percentiles; x = typical',fontsize=11)
    fig.savefig(ROOT/'outputs/figures/02-paired.png',dpi=180); plt.close(fig)
    fig,axs=plt.subplots(1,2,figsize=(9,4.8),layout='constrained')
    for n,k in enumerate(SCHEDULES):
        rr=[r for r in cuts if r['schedule']==k]
        axs[0].plot([100*float(r['fraction_reference_peak']) for r in rr],[float(r['low_hours']) for r in rr],'-o',color=COLORS[n],label=LABELS[n])
    axs[0].set(xlabel='Cutoff (% of reference typical peak)',ylabel='Hours below cutoff in week 4',ylim=(0,168),title='Diagnostic cutoff sensitivity')
    axs[0].legend(fontsize=8)
    for n,k in enumerate(list(SCHEDULES)[1:]):
        r=next(x for x in paired if x['schedule']==k and x['metric']=='low_hours')
        xx=np.array([float(r[x]) for x in ['p05','median','p95']])
        axs[1].errorbar(xx[1],1-n,xerr=[[xx[1]-xx[0]],[xx[2]-xx[1]]],fmt='o',color=COLORS[n+1],capsize=4)
        axs[1].plot(float(typ[n+1]['low_hours'])-float(typ[0]['low_hours']),1-n,'x',color='black')
    axs[1].axvline(0,color='#777777',lw=1,ls=':')
    axs[1].set(xlabel='Difference from consecutive (hours)',yticks=[0,1],yticklabels=['Alternating','Two blocks'],
               title='Fixed 10% cutoff: paired differences',ylim=(-.5,1.5),xlim=(-50,10))
    fig.savefig(ROOT/'outputs/figures/03-sensitivity.png',dpi=180); plt.close(fig)
    print('Rendered three figures')
if __name__=='__main__': main()
