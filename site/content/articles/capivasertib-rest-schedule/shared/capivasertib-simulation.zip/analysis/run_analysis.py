"""Recompute all reported numbers and original figures."""
from pathlib import Path
from dataclasses import replace, asdict
import csv,json,platform
import numpy as np
import scipy
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from model import BASE,OLD,BOUNDS,SCHEDULES,simulate,metrics,dose_times,clearance

ROOT=Path(__file__).resolve().parents[1]
SEED=20261012; N=256
COLORS=['#0072B2','#E69F00','#009E73']
LABELS=['4 consecutive days','Two 2-day blocks','Alternating 4 days']
KEYS=['auc_week','cmax','cmin','low_hours']

def save_csv(name: str, rows: list[dict]) -> None:
    p=ROOT/'outputs/tables'/name
    with p.open('w',newline='',encoding='utf8') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0])); w.writeheader(); w.writerows(rows)

def scalar(m: dict) -> dict:
    return {k:float(v[0]) for k,v in m.items()}

def main() -> None:
    for d in ['outputs/tables','outputs/figures']: (ROOT/d).mkdir(parents=True,exist_ok=True)
    sims={k:simulate(k) for k in SCHEDULES}
    peak=float(metrics(sims['consecutive'])['cmax'][0]); threshold=.1*peak
    typ={k:scalar(metrics(s,threshold=threshold)) for k,s in sims.items()}
    rows=[]
    for k in SCHEDULES:
        ds=dose_times(k,2); weekd=ds[ds<168]; gap=float(np.diff(np.r_[weekd,168]).max())
        rows.append({'schedule':k,'weekly_mg':3200,'max_dose_gap_h':gap,**typ[k],
                     'auc_first_week':float(metrics(sims[k],week=1)['auc_week'][0])})
    save_csv('typical.csv',rows); print('Typical simulations complete',flush=True)
    rng=np.random.default_rng(SEED); z=rng.normal(size=(N,3)); cv=np.array([.382,1.03,.953])
    eta=z*np.sqrt(np.log1p(cv**2))
    pop={k:metrics(simulate(k,eta=eta),threshold=threshold) for k in SCHEDULES}
    paired=[]
    for k in list(SCHEDULES)[1:]:
        for metric in KEYS:
            x=pop[k][metric]-pop['consecutive'][metric] if metric=='low_hours' else pop[k][metric]/pop['consecutive'][metric]
            q=np.quantile(x,[.05,.5,.95]); paired.append({'schedule':k,'metric':metric,
                 'p05':q[0],'median':q[1],'p95':q[2],'n':N,'comparison':'difference_h' if metric=='low_hours' else 'ratio'})
    save_csv('paired.csv',paired); print('Paired sensitivity complete',flush=True)
    sensitivity=[]
    for name,bounds in BOUNDS.items():
        for side,value in zip(['lower','upper'],bounds):
            p=replace(BASE,**{name:value}); m={k:scalar(metrics(simulate(k,p=p),threshold=threshold)) for k in SCHEDULES}
            for k in list(SCHEDULES)[1:]:
                sensitivity.append({'parameter':name,'bound':side,'value':value,'schedule':k,
                      **{x:(m[k][x]-m['consecutive'][x] if x=='low_hours' else m[k][x]/m['consecutive'][x]) for x in KEYS}})
        print('Parameter',name,'complete',flush=True)
    save_csv('sensitivity.csv',sensitivity)
    scenarios=[]
    for name,p,mode,weeks in [('2024_fit',OLD,'calendar',4),('asymptotic_CL',BASE,'asymptotic',4),
                 ('no_inhibition',BASE,'none',4),('strict_fasted',replace(BASE,lag=0),'calendar',4),
                 ('capsule',replace(BASE,lag=.468),'calendar',4),('week8',BASE,'calendar',8)]:
        m={k:scalar(metrics(simulate(k,p=p,mode=mode,weeks=weeks),week=weeks,threshold=threshold)) for k in SCHEDULES}
        for k in list(SCHEDULES)[1:]: scenarios.append({'scenario':name,'schedule':k,**{x:(m[k][x]-m['consecutive'][x] if x=='low_hours' else m[k][x]/m['consecutive'][x]) for x in KEYS}})
    alt={k:metrics(simulate(k,eta=z*cv),threshold=threshold) for k in SCHEDULES}
    for k in list(SCHEDULES)[1:]:
        scenarios.append({'scenario':'CV_as_SD_paired_median','schedule':k,
                          **{x:float(np.median(alt[k][x]-alt['consecutive'][x] if x=='low_hours' else alt[k][x]/alt['consecutive'][x])) for x in KEYS}})
    save_csv('scenarios.csv',scenarios)
    cuts=[]
    for fraction in [.05,.1,.2,.3,.4,.5]:
        for k in SCHEDULES: cuts.append({'fraction_reference_peak':fraction,'cutoff_ng_ml':fraction*peak,
                  'schedule':k,'low_hours':float(metrics(sims[k],threshold=fraction*peak)['low_hours'][0])})
    save_csv('cutoffs.csv',cuts)
    # Published interval is 252–264 h; same typical covariates as this analysis.
    ref=sims['consecutive']; t=ref['t']; mask=(t>=252)&(t<=264)
    i=np.argmin(abs(t-252)); j=np.argmin(abs(t-264))
    reproduced={'auc12_252_264':float(ref['auc'][j,0]-ref['auc'][i,0]),'cmax12_252_264':float(ref['c'][mask,0].max()),
                 'max_CL_reduction_pct':float(100*(1-clearance(1e10,BASE,np.zeros((1,3)),'calendar')[0]/BASE.cl0)),
                 'vss_L':BASE.vc+BASE.vp1+BASE.vp2}
    half=simulate('consecutive',dt=.1); adaptive=simulate('consecutive',dt=1,adaptive=True)
    verify={'typical_parameters':asdict(BASE),'seed':SEED,'n_conditional':N,'cutoff_ng_ml':threshold,
           'max_mass_balance_error_mg':max(s['mass_error_mg'] for s in sims.values()),
           'half_step_AUC_relative_error':abs(float(metrics(half)['auc_week'][0]/typ['consecutive']['auc_week']-1)),
           'adaptive_AUC_relative_error':abs(float(metrics(adaptive)['auc_week'][0]/typ['consecutive']['auc_week']-1)),
           'published_comparison_unmatched_population':reproduced}
    assert verify['max_mass_balance_error_mg']<1e-6
    assert verify['half_step_AUC_relative_error']<1e-5 and verify['adaptive_AUC_relative_error']<1e-5
    (ROOT/'outputs/verification.json').write_text(json.dumps(verify,indent=2)+'\n',encoding='utf8')
    (ROOT/'outputs/environment.json').write_text(json.dumps({'python':platform.python_version(),'numpy':np.__version__,
                         'scipy':scipy.__version__,'matplotlib':matplotlib.__version__},indent=2)+'\n')
    from render_figures import main as render_figures
    render_figures()
    print(json.dumps(verify,indent=2),flush=True)

if __name__=='__main__': main()
