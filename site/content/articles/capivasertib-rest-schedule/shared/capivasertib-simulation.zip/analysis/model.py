"""Independent apparent-parameter implementation; not an original NONMEM run."""
from dataclasses import dataclass, replace
import numpy as np
from scipy.special import expit
from scipy.integrate import solve_ivp

WEEK = 168.0
DOSE = 400.0
SCHEDULES = {'consecutive': (0, 1, 2, 3), 'two_blocks': (0, 1, 4, 5), 'alternating': (0, 2, 4, 6)}

@dataclass(frozen=True)
class Parameters:
    ka: float = .441
    cl0: float = 59.6
    vc: float = 49.
    vp1: float = 113.
    q1: float = 2.52
    vp2: float = 103.
    q2: float = 23.4
    imax: float = -1.87
    dose_slope: float = -.00213
    t50: float = 126.
    logit_f: float = 1.6
    lag: float = .287
    duration: float = 45.

BASE = Parameters()
OLD = Parameters(ka=.417, cl0=62.2, vc=47.9, vp1=113, q1=2.66,
                 vp2=94.7, q2=21.8, imax=-1.54, dose_slope=-.00183,
                 t50=67.4, logit_f=1.4, lag=.212, duration=45.1)
BOUNDS = {'ka': (.358,.538), 'cl0': (56.8,62), 'vc': (36.7,68.9),
          'vp1': (95.7,137), 'q1': (1.43,3.38), 'vp2': (74,159),
          'q2': (16.5,31.6), 'imax': (-2.53,-1.44),
          'dose_slope': (-.00253,-.00133), 't50': (63.3,144),
          'logit_f': (1.16,2.18), 'lag': (.223,.334), 'duration': (43.6,45.6)}

def dose_times(schedule: str, weeks: int) -> np.ndarray:
    return np.array(sorted(w*WEEK+d*24+h for w in range(weeks)
                           for d in SCHEDULES[schedule] for h in (0,12)), dtype=float)

def clearance(t: float, p: Parameters, eta: np.ndarray, mode: str) -> np.ndarray:
    cl0 = p.cl0*np.exp(eta[:,0])
    if mode == 'none': return cl0
    fraction = np.exp(p.imax*(1+(DOSE-480)*p.dose_slope)*np.exp(eta[:,2]))
    s = 1. if mode == 'asymptotic' else t**5/(p.t50**5+t**5)
    return cl0*(1-fraction*s)

def rhs(t: float, y: np.ndarray, rate: float, p: Parameters, eta: np.ndarray, mode: str) -> np.ndarray:
    cl = clearance(t,p,eta,mode); vc = p.vc*np.exp(eta[:,1])
    c = y[:,1]/vc; c1 = y[:,2]/p.vp1; c2 = y[:,3]/p.vp2
    d = np.zeros_like(y)
    d[:,0] = -p.ka*y[:,0]
    d[:,1] = p.ka*y[:,0]+rate-cl*c-p.q1*(c-c1)-p.q2*(c-c2)
    d[:,2] = p.q1*(c-c1); d[:,3] = p.q2*(c-c2)
    d[:,4] = c; d[:,5] = cl*c
    return d

def simulate(schedule: str, p: Parameters=BASE, weeks: int=4, dt: float=.2,
             eta: np.ndarray | None=None, mode: str='calendar', adaptive: bool=False) -> dict:
    eta = np.zeros((1,3)) if eta is None else np.asarray(eta,dtype=float)
    assert eta.ndim == 2 and eta.shape[1] == 3 and np.isfinite(eta).all()
    if adaptive: assert len(eta)==1
    end = weeks*WEEK; doses = dose_times(schedule,weeks); fraction = float(expit(p.logit_f))
    events = {}
    def event(t: float, gut: float=0., rate: float=0.):
        if t <= end+1e-8:
            t=round(t,9); g,r=events.get(t,(0.,0.)); events[t]=(g+gut,r+rate)
    for t in doses:
        event(t,rate=DOSE*(1-fraction)/p.duration)
        event(t+p.duration,rate=-DOSE*(1-fraction)/p.duration)
        event(t+p.lag,gut=DOSE*fraction)
    grid = np.unique(np.round(np.concatenate([np.arange(0,end,dt),[end],list(events)]),9))
    y=np.zeros((len(eta),6)); rate=0.; ts=[]; cs=[]; auc=[]; balances=[]
    min_amount=0.; max_error=0.
    # Bound explicit step by the largest first-order loss rate.
    loss = p.ka+(p.cl0+p.q1+p.q2)/(p.vc*np.exp(eta[:,1]))+p.q1/p.vp1+p.q2/p.vp2
    max_step = min(dt,.5/float(np.max(loss)))
    for i,t in enumerate(grid):
        g,r=events.get(round(float(t),9),(0.,0.)); y[:,0]+=g; rate+=r
        ts.append(t); cs.append(1000*y[:,1]/(p.vc*np.exp(eta[:,1]))); auc.append(1000*y[:,4].copy())
        # Account for undelivered zero-order/lagged oral input, separately from amounts.
        delivered = DOSE*(fraction*np.sum(doses+p.lag <= t+1e-8)
                          +(1-fraction)*np.sum(np.clip((t-doses)/p.duration,0,1)))
        error=np.max(np.abs(y[:,:4].sum(axis=1)+y[:,5]-delivered))
        max_error=max(max_error,float(error)); min_amount=min(min_amount,float(y[:,:4].min()))
        if i==len(grid)-1: break
        stop=grid[i+1]; htot=stop-t
        if adaptive:
            sol=solve_ivp(lambda x,z: rhs(x,z[None,:],rate,p,eta,mode)[0],
                          (t,stop),y[0],rtol=2e-10,atol=1e-11,method='DOP853')
            assert sol.success; y=sol.y[:,-1][None,:]
        else:
            steps=int(np.ceil(htot/max_step)); h=htot/steps
            for k in range(steps):
                x=t+k*h; a=rhs(x,y,rate,p,eta,mode); b=rhs(x+h/2,y+h*a/2,rate,p,eta,mode)
                c=rhs(x+h/2,y+h*b/2,rate,p,eta,mode); d=rhs(x+h,y+h*c,rate,p,eta,mode)
                y+=h*(a+2*b+2*c+d)/6
    concentration=np.asarray(cs); cumulative=np.asarray(auc)
    assert min_amount > -1e-8 and np.isfinite(concentration).all()
    return {'t':np.array(ts),'c':concentration,'auc':cumulative,'amounts':y[:,:4],
            'mass_error_mg':max_error,'min_amount':min_amount,'max_step':max_step,
            'dose_count':len(doses),'schedule':schedule,'weeks':weeks}

def low_time(t: np.ndarray, c: np.ndarray, threshold: float) -> np.ndarray:
    """Linear crossing interpolation; c shape (time, subjects)."""
    left=c[:-1]; right=c[1:]; both=(left<threshold)&(right<threshold)
    cross=(left<threshold)!=(right<threshold)
    den=right-left
    fraction=np.divide(threshold-left,den,out=np.zeros_like(left),where=np.abs(den)>1e-15)
    fraction=np.where(left<threshold,fraction,1-fraction)
    fraction=np.where(both,1,np.where(cross,np.clip(fraction,0,1),0))
    return (np.diff(t)[:,None]*fraction).sum(axis=0)

def metrics(sim: dict, week: int=4, threshold: float | None=None) -> dict:
    t=sim['t']; a=(week-1)*WEEK; b=week*WEEK
    use=(t>=a-1e-8)&(t<=b+1e-8); c=sim['c'][use]; tw=t[use]
    idxa=int(np.argmin(abs(t-a))); idxb=int(np.argmin(abs(t-b)))
    assert abs(t[idxa]-a)<1e-7 and abs(t[idxb]-b)<1e-7
    out={'auc_week':sim['auc'][idxb]-sim['auc'][idxa], 'cmax':c.max(axis=0),
         'cmin':c.min(axis=0),'week_end':c[-1]}
    if threshold is not None: out['low_hours']=low_time(tw,c,threshold)
    return out
