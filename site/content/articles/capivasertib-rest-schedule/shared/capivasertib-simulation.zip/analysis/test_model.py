"""Independent numerical checks of exposure integration and event handling."""
import unittest
import numpy as np
from scipy.linalg import expm
from model import BASE,SCHEDULES,dose_times,simulate,metrics,clearance,low_time

class ModelTests(unittest.TestCase):
    def test_dose_total_and_week_boundary(self):
        for k in SCHEDULES:
            times=dose_times(k,4)
            self.assertEqual(len(times),32)
            for w in range(4): self.assertEqual(np.sum((times>=168*w)&(times<168*(w+1))),8)
        self.assertEqual(np.diff(np.r_[dose_times('consecutive',1),168]).max(),84)

    def test_clearance_asymptote(self):
        eta=np.zeros((1,3))
        self.assertAlmostEqual(clearance(0,BASE,eta,'calendar')[0],BASE.cl0)
        expected=BASE.cl0*(1-np.exp(BASE.imax*(1-80*BASE.dose_slope)))
        self.assertAlmostEqual(clearance(1e10,BASE,eta,'calendar')[0],expected)
        self.assertGreater(expected,0)

    def test_linear_crossing_duration(self):
        c=np.array([[0.],[2.],[0.]])
        self.assertAlmostEqual(low_time(np.array([0.,2.,4.]),c,1)[0],2)

    def test_event_mass_balance_and_no_exclusions(self):
        eta=np.array([[0.,0.,0.],[.3,-2.,-.7],[-.3,1.5,.7]])
        for k in SCHEDULES:
            s=simulate(k,weeks=1,eta=eta,dt=.5)
            self.assertEqual(s['c'].shape[1],3)
            self.assertLess(s['mass_error_mg'],1e-6)
            self.assertGreaterEqual(s['min_amount'],-1e-8)

    def test_adaptive_solver(self):
        a=simulate('two_blocks',weeks=2,dt=.2)
        b=simulate('two_blocks',weeks=2,dt=.2,adaptive=True)
        for key in ['auc_week','cmax','cmin']:
            tol=1e-4  # 0.01% agreement for concentrations and integrated AUC.
            self.assertLess(abs(metrics(a,week=2)[key][0]/metrics(b,week=2)[key][0]-1),tol)

    def test_constant_clearance_periodic_week(self):
        cl=clearance(0,BASE,np.zeros((1,3)),'asymptotic')[0]
        for k in SCHEDULES:
            s=simulate(k,weeks=8,mode='asymptotic',dt=.5)
            self.assertLess(abs(metrics(s,week=8)['auc_week'][0]/(3200/cl*1000)-1),1e-5)

if __name__=='__main__': unittest.main()
