from math import exp, log

def bisect(fn, low, high):
    assert fn(low)*fn(high) < 0
    for _ in range(70):
        mid = (low+high)/2
        if fn(mid)*fn(low)>0:
            low=mid
        else:
            high=mid
    return (low+high)/2

def survival(t,a,b):
    if abs(a-b)<1e-10:
        return exp(-a*t)*(1+a*t)
    return (b*exp(-a*t)-a*exp(-b*t))/(b-a)

control, treated = [(log(2)/p, o) for p,o in [(4.4,14.0),(6.8,16.8)]]
b = bisect(lambda b: survival(control[1],control[0],b)-.5,.001,5)
counterfactual = bisect(lambda t: survival(t,treated[0],b)-.5,.01,100)
fit_treated = bisect(lambda b: survival(treated[1],treated[0],b)-.5,.001,5)
print(f"Control post-progression median = {log(2)/b:.6f}")
print(f"Treated OS under shared post-progression rate = {counterfactual:.6f}")
print(f"Treated fitted post-progression median = {log(2)/fit_treated:.6f}")
