"""Transparent reduced DDI and PK consistency calculations, not a PBPK model."""
import math

def auc_ratio(fm: float, residual_activity: float, availability_ratio: float = 1.0) -> float:
    if not 0 <= fm <= 1 or not 0 <= residual_activity <= 1 or availability_ratio <= 0:
        raise ValueError("Invalid static-model parameter")
    denominator = 1 - fm + fm * residual_activity
    if denominator <= 0:
        raise ValueError("Zero clearance denominator")
    return availability_ratio / denominator

def fm_for_ratio(ratio: float, residual_activity: float, availability_ratio: float = 1.0) -> float:
    if ratio <= 0 or availability_ratio <= 0 or not 0 <= residual_activity < 1:
        raise ValueError("Invalid inverse-model parameter")
    return (1 - availability_ratio / ratio) / (1 - residual_activity)

def apparent_clearance(dose_mg: float, auc_ng_h_ml: float) -> float:
    if dose_mg <= 0 or auc_ng_h_ml <= 0:
        raise ValueError("Dose and AUC must be positive")
    return dose_mg * 1000 / auc_ng_h_ml

def bolus_peak_average_bound(half_life_h: float, tau_h: float) -> float:
    """Upper bound for linear 1c elimination and nonnegative periodic input."""
    if half_life_h <= 0 or tau_h <= 0:
        raise ValueError("Time must be positive")
    x = math.log(2) * tau_h / half_life_h
    return x / (-math.expm1(-x))

def rounded_reference_interval(prediction: float, sim_observed: float, prediction_digits: int = 2,
                               sim_observed_digits: int = 3) -> tuple[float, float]:
    """Bound unknown reference due only to rounding of printed prediction and S/O."""
    delta_p = 0.5 * 10 ** (-prediction_digits)
    delta_s = 0.5 * 10 ** (-sim_observed_digits)
    if prediction <= delta_p or sim_observed <= delta_s:
        raise ValueError("Cannot invert rounded values")
    return ((prediction - delta_p) / (sim_observed + delta_s),
            (prediction + delta_p) / (sim_observed - delta_s))
