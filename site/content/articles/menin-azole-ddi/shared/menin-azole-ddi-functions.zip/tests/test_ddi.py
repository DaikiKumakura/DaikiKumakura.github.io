"""Independent numerical and domain checks for the reduced analysis."""
from pathlib import Path
import sys
import unittest
import math
import numpy as np
from scipy.integrate import quad

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))
from ddi import auc_ratio, apparent_clearance, fm_for_ratio, bolus_peak_average_bound, rounded_reference_interval

class DDIChecks(unittest.TestCase):
    def test_units(self) -> None:
        # 600 mg / 5512 ng*h/mL = 600000 ug / 5512 ug*h/L.
        self.assertAlmostEqual(apparent_clearance(600, 5512), 108.8534107402032)

    def test_no_inhibition(self) -> None:
        for fm in [0, .5, .7, 1]:
            self.assertEqual(auc_ratio(fm, 1), 1)

    def test_maximal_inhibition(self) -> None:
        self.assertAlmostEqual(auc_ratio(.6, 0), 2.5)
        self.assertAlmostEqual(auc_ratio(.7, 0), 10/3)

    def test_inverse_distinct_mechanisms(self) -> None:
        # Different fm and availability, identical AUC.
        for b in [1, 1.25, 1.5]:
            for r in [0, .1, .25]:
                fm = fm_for_ratio(2.6, r, b)
                self.assertAlmostEqual(auc_ratio(fm, r, b), 2.6)

    def test_bolus_bound_against_integration(self) -> None:
        tau, half_life = 24., 93.6
        k = math.log(2) / half_life
        # Steady-state instantaneous dose with D/V=1.
        peak = 1 / (1 - math.exp(-k*tau))
        area, _ = quad(lambda t: peak * math.exp(-k*t), 0, tau)
        self.assertAlmostEqual(peak/(area/tau), bolus_peak_average_bound(half_life,tau))

    def test_distributed_input_below_bound(self) -> None:
        # Equal daily dose split into two pulses has a lower peak.
        k, tau = math.log(2)/93.6, 24.
        split_peak = .5/(1-math.exp(-k*tau/2))
        split_ratio = split_peak * k * tau
        self.assertLess(split_ratio, bolus_peak_average_bound(93.6,tau))

    def test_long_half_life_bound(self) -> None:
        self.assertAlmostEqual(bolus_peak_average_bound(1e10,24),1,places=8)

    def test_rounding_interval_contains_reference(self) -> None:
        low, high = rounded_reference_interval(2.02,.894)
        self.assertLess(low, 2.26)
        self.assertGreater(high,2.26)

    def test_invalid_parameters(self) -> None:
        for fm, r, b in [(-.1,0,1),(1.1,0,1),(.7,-.1,1),(.7,1.1,1),(.7,.1,0),(1,0,1)]:
            with self.assertRaises(ValueError):
                auc_ratio(fm,r,b)
        with self.assertRaises(ValueError):
            apparent_clearance(0,2)
        with self.assertRaises(ValueError):
            bolus_peak_average_bound(0,24)
        with self.assertRaises(ValueError):
            fm_for_ratio(2,1)

    def test_monotonicity(self) -> None:
        values = [auc_ratio(fm, .1) for fm in np.linspace(0,.95,100)]
        self.assertTrue(all(a < b for a,b in zip(values,values[1:])))

if __name__ == "__main__":
    unittest.main()
