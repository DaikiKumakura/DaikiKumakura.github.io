# M06 checks: (1) the MAR model refitted with an independent implementation (lme4), (2) the delta-adjusted
# mean at delta = 0 against the fixed-effect mean, (3) Monte Carlo stability of the joint model with another seed.
# Run after analyze.R: Rscript validate.R  (writes results/validation.json)
args <- commandArgs(FALSE); root <- dirname(normalizePath(sub("^--file=", "", args[grep("^--file=", args)][1])))
source(file.path(root, "common.R"))
suppressPackageStartupMessages({library(lme4); library(JMbayes2); library(jsonlite)})
d <- load_data(root); f <- fit_mar(d$longi); out <- list()

# (1) lme4, ML, same fixed and random structure
d$longi$yk <- pmax(d$longi$year - K, 0)
g <- lmer(y ~ arm * (year + yk) + (year + yk | id), data = d$longi, REML = FALSE,
          control = lmerControl(optimizer = "bobyqa", optCtrl = list(maxfun = 1e5)))
b1 <- fixef(f); b2 <- fixef(g)
out$lme4 <- list(max_abs_diff_fixef = max(abs(unname(b1) - unname(b2))), loglik_nlme = as.numeric(logLik(f)),
                 loglik_lme4 = as.numeric(logLik(g)), singular = isSingular(g))
q1 <- unlist(summ_mar(f)); names(b2) <- names(b1); q2 <- unlist(lapply(WEEKS, function(w) change_from_beta(b2, w)))
out$lme4$max_abs_diff_quantities <- max(abs(q1 - q2))

# (2) delta = 0 adjustment equals the average of individual predictions; compare with the fixed-effect mean
d0 <- unlist(lapply(WEEKS, function(w) delta_change(f, d$longi, d$surv, 0, 0, w)))
out$delta0_vs_fixed <- list(max_abs_diff = max(abs(d0 - q1)), delta0 = d0, fixed = q1)
# a hand check of the delta formula for one arm at 48 weeks with delta = 1
t <- 48 / WPY; tl <- tapply(d$longi$year, d$longi$id, max)[as.character(d$surv$id)]
seq_ids <- d$surv$arm == 0
co <- coef(f)[as.character(d$surv$id), ]
p48 <- co[, "year"] * t + co[, 4] * (t - K)
manual <- mean((p48 + 1 * pmax(t - tl, 0))[seq_ids])
out$delta_hand_check <- list(manual = manual, function_value = delta_change(f, d$longi, d$surv, 1, 0, 48)[["sequential"]])

# (3) joint model with a different seed
cx <- coxph(Surv(time, dead) ~ arm + who + resection + age60 + age70, data = d$surv)
est <- read.csv(file.path(root, "results/estimates.csv"))
main_jm <- est[est$analysis == "main" & est$model == "joint model ~value(y)", ]
it <- fromJSON(file.path(root, "results/summary.json"))$jm$value$iter
j <- jm(cx, f, time_var = "year", functional_forms = ~ value(y), n_chains = 3, n_iter = it, n_burnin = it / 6, seed = 777)
B <- do.call(rbind, j$mcmc$betas1); colnames(B) <- names(b1)
dr <- colMeans(t(apply(B, 1, function(x) unlist(lapply(WEEKS, function(w) change_from_beta(x, w))))))
out$jm_seed777 <- list(max_abs_diff_posterior_mean = max(abs(dr - main_jm$estimate)), estimates = dr,
                       alpha = as.numeric(j$statistics$Mean$alphas))
writeLines(toJSON(out, auto_unbox = TRUE, digits = 10, pretty = TRUE), file.path(root, "results/validation.json"))
print(out)
