# M06 shared definitions: data preparation, the MAR mixed model and the summaries of mean change.
# R 4.5.3, nlme 3.1-168, survival 3.8-6, JMbayes2 0.6.0 (results identical with R 4.5.1 / survival 3.8-3).
suppressPackageStartupMessages({library(nlme); library(survival)})
WPY <- 52.1775; K <- 24 / WPY; FLOOR <- -10/3; FLOOR_CUT <- -3.33
WEEKS <- c(24, 48); SEED <- 20261005

load_data <- function(root, drop_floor = FALSE, drop_after_nl = FALSE) {
  longi <- read.csv(file.path(root, "raw/colorectalLongi.csv")); ev <- read.csv(file.path(root, "raw/colorectal.csv"))
  ev <- ev[order(ev$id, ev$time1), ]
  surv <- ev[!duplicated(ev$id, fromLast = TRUE), c("id", "time1", "state", "treatment", "age", "who.PS", "prev.resection")]
  first_nl <- tapply(ifelse(ev$new.lesions == 1, ev$time1, Inf), ev$id, min)
  surv$first_nl <- as.numeric(first_nl[as.character(surv$id)])
  # one participant has a measurement after the terminal time; excluded as in M04
  bad <- unique(longi$id[longi$year > surv$time1[match(longi$id, surv$id)] + 1e-9])
  surv <- surv[!surv$id %in% bad, ]; longi <- longi[!longi$id %in% bad, ]
  longi$floor <- longi$tumor.size <= FLOOR_CUT; longi$y <- ifelse(longi$floor, FLOOR, longi$tumor.size)
  if (drop_floor) longi <- longi[!longi$floor | longi$year == 0, ]
  if (drop_after_nl) longi <- longi[longi$year <= surv$first_nl[match(longi$id, surv$id)] + 1e-9, ]
  surv$arm <- as.numeric(surv$treatment == "C"); surv$who <- as.numeric(surv$who.PS != "0")
  surv$resection <- as.numeric(surv$prev.resection == "Yes")
  surv$age60 <- as.numeric(surv$age == "60-69 years"); surv$age70 <- as.numeric(surv$age == ">69 years")
  surv$time <- surv$time1; surv$dead <- surv$state
  longi$arm <- surv$arm[match(longi$id, surv$id)]
  longi <- longi[order(longi$id, longi$year), c("id", "year", "y", "arm", "floor")]
  surv <- surv[order(surv$id), c("id", "time", "dead", "arm", "who", "resection", "age60", "age70", "first_nl")]
  list(longi = longi, surv = surv)
}

# K is written as a literal so that JMbayes2 can re-evaluate the time terms at other times
KS <- format(K, digits = 15)
FIXED <- as.formula(sprintf("y ~ arm * (year + pmax(year - %s, 0))", KS))
RANDOM <- as.formula(sprintf("~ year + pmax(year - %s, 0) | id", KS))

fit_mar <- function(longi) {
  ctl <- lmeControl(maxIter = 200, msMaxIter = 200, niterEM = 50, returnObject = FALSE)
  f <- tryCatch(lme(FIXED, random = RANDOM, data = longi, method = "ML", control = ctl), error = function(e) NULL)
  if (!is.null(f)) { f$cov_structure <- "unstructured"; return(f) }
  rd <- list(id = pdDiag(as.formula(sprintf("~ year + pmax(year - %s, 0)", KS))))
  f <- lme(FIXED, random = rd, data = longi, method = "ML", control = ctl)
  f$cov_structure <- "diagonal"; f
}

# mean change from baseline at week w in each arm, from the four slope coefficients
change_from_beta <- function(b, w) {
  # b order: (Intercept), arm, year, pmax(year - K, 0), arm:year, arm:pmax(year - K, 0)
  b <- unname(b); t <- w / WPY; kk <- max(t - K, 0)
  s <- b[3] * t + b[4] * kk; cmb <- s + b[5] * t + b[6] * kk
  c(sequential = s, combination = cmb, difference = cmb - s)
}
beta_names <- function(b) {
  stopifnot(length(b) == 6, names(b)[3] == "year", startsWith(names(b)[4], "pmax"), names(b)[5] == "arm:year"); b
}
summ_mar <- function(f) {
  b <- beta_names(fixef(f)); out <- lapply(WEEKS, function(w) change_from_beta(b, w)); names(out) <- paste0("w", WEEKS); out
}

# delta-adjusted mean change: individual MAR predictions, worsened by delta per year after each patient's last measurement
delta_change <- function(f, longi, surv, delta_seq, delta_comb, w) {
  t <- w / WPY; kk <- max(t - K, 0)
  co <- coef(f); co <- co[match(surv$id, as.numeric(rownames(co))), ]
  pred <- co[, "year"] * t + co[, 4] * kk + surv$arm * (co[, "arm:year"] * t + co[, 6] * kk)
  tl <- tapply(longi$year, longi$id, max)[as.character(surv$id)]
  delta <- ifelse(surv$arm == 1, delta_comb, delta_seq)
  adj <- pred + delta * pmax(t - tl, 0)
  s <- mean(adj[surv$arm == 0]); cmb <- mean(adj[surv$arm == 1])
  c(sequential = s, combination = cmb, difference = cmb - s)
}
DELTAS <- c(0, 0.5, 1, 2, 3)
delta_grid <- function() {
  g <- rbind(data.frame(apply_to = "both", seq = DELTAS, comb = DELTAS),
             data.frame(apply_to = "sequential_only", seq = DELTAS, comb = 0),
             data.frame(apply_to = "combination_only", seq = 0, comb = DELTAS))
  g$delta <- pmax(g$seq, g$comb); g
}
