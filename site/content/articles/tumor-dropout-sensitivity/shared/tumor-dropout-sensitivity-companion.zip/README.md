# Dropout and tumor-shrinkage estimates: mixed model, joint model and delta adjustment

Companion to the article "When patients stop being measured: how much does dropout change a tumor-shrinkage estimate?"

No participant-level data are included. `acquire.py` downloads CRAN frailtypack 3.8.1 and checks its SHA-256; `export.R` writes the `colorectal` and `colorectalLongi` datasets locally. Check the underlying data rights before redistributing them.

## Run

1. `python acquire.py` (Python 3.12, standard library)
2. `Rscript export.R`
3. `python audit.py` → `results/audit.json`
4. `Rscript analyze.R` (R 4.5.3; nlme 3.1-168, survival 3.8-6, JMbayes2 0.6.0, jsonlite) → `results/estimates.csv`, `delta-sensitivity.csv`, `survival-submodel.csv`, `trajectories.csv`, `observed-means.csv`, `simulation-truth.json`, `summary.json`
5. `Rscript simulate.R 1`, `Rscript simulate.R 2`, `Rscript simulate.R 3` (can run in parallel; each takes about an hour), then `Rscript simulate.R combine` → `results/simulation.csv`, `simulation-summary.csv`
6. `Rscript validate.R` (also lme4) → `results/validation.json`
7. `python figures.py` (matplotlib) → `figures/*.png`

`common.R` holds the data preparation, the mixed model and the delta adjustment used by all R scripts. Seed 20261005. `analysis-plan.md` was fixed before any model was fitted, and its change log records two later corrections; `data-audit.md` records the source checks. The analysis is a research demonstration of sensitivity to dropout assumptions, not a treatment comparison or an identification of the dropout mechanism.
