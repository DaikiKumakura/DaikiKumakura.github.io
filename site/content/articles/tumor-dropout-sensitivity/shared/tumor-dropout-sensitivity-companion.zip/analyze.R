# M06-4/5: MAR mixed model vs joint model with death, and delta-adjusted MNAR sensitivity.
# Run: Rscript analyze.R  (writes results/*.csv, results/*.json; aggregate only)
args <- commandArgs(FALSE); root <- dirname(normalizePath(sub("^--file=", "", args[grep("^--file=", args)][1])))
source(file.path(root, "common.R"))
suppressPackageStartupMessages({library(JMbayes2); library(jsonlite)})
NBOOT <- 1000; out <- list()
suppressPackageStartupMessages(library(parallel))
CL <- makeCluster(max(1, detectCores() - 1)); invisible(clusterCall(CL, function(r) source(file.path(r, "common.R")), root))
logf <- file.path(root, "results/run-log.txt"); cat("", file = logf)
logm <- function(...) { m <- paste0(...); cat(m, "\n"); cat(m, "\n", file = logf, append = TRUE) }

boot_ids <- function(surv, seed) { set.seed(seed); lapply(seq_len(NBOOT), function(b) sample(surv$id, replace = TRUE)) }
resample <- function(d, ids) {
  s <- d$surv[match(ids, d$surv$id), ]; s$orig <- s$id; s$id <- seq_along(ids)
  l <- do.call(rbind, lapply(seq_along(ids), function(k) { x <- d$longi[d$longi$id == ids[k], ]; x$id <- k; x }))
  list(longi = l, surv = s)
}
clusterExport(CL, c("resample", "WEEKS"))
qi <- function(x) unname(quantile(x, c(.025, .975), na.rm = TRUE))

# ---- MAR model with bootstrap (point estimates, delta grid) -------------------------------------
run_mar <- function(d, label, with_delta = FALSE) {
  f <- fit_mar(d$longi); est <- summ_mar(f); grid <- delta_grid()
  dpt <- if (with_delta) t(sapply(seq_len(nrow(grid)), function(i) unlist(lapply(WEEKS, function(w)
    delta_change(f, d$longi, d$surv, grid$seq[i], grid$comb[i], w))))) else NULL
  ids <- boot_ids(d$surv, SEED)
  one <- function(idv) {
    db <- resample(d, idv); fb <- tryCatch(fit_mar(db$longi), error = function(e) NULL)
    if (is.null(fb)) return(NULL)
    list(diag = fb$cov_structure == "diagonal", est = unlist(summ_mar(fb)),
         delta = if (with_delta) t(sapply(seq_len(nrow(grid)), function(i) unlist(lapply(WEEKS, function(w)
           delta_change(fb, db$longi, db$surv, grid$seq[i], grid$comb[i], w))))) else NULL)
  }
  res <- parLapply(CL, ids, one)
  ok <- !vapply(res, is.null, TRUE); nfail <- sum(!ok); ndiag <- sum(vapply(res[ok], function(r) r$diag, TRUE))
  bs <- do.call(rbind, lapply(res[ok], function(r) r$est))
  bd <- if (with_delta) aperm(simplify2array(lapply(res[ok], function(r) r$delta)), c(3, 1, 2)) else NULL
  logm(label, ": MAR cov=", f$cov_structure, "; bootstrap failures=", nfail, ", diagonal fallback=", ndiag)
  nm <- paste(rep(paste0("w", WEEKS), each = 3), c("sequential", "combination", "difference"), sep = "_")
  pt <- unlist(est); names(pt) <- nm
  tab <- data.frame(analysis = label, model = "MAR mixed model", quantity = nm, estimate = pt,
                    lower = apply(bs, 2, function(x) qi(x)[1]), upper = apply(bs, 2, function(x) qi(x)[2]), row.names = NULL)
  dtab <- NULL
  if (with_delta) {
    dtab <- do.call(rbind, lapply(seq_len(nrow(grid)), function(i) data.frame(
      apply_to = grid$apply_to[i], delta_seq = grid$seq[i], delta_comb = grid$comb[i], quantity = nm,
      estimate = dpt[i, ], lower = apply(bd[, i, ], 2, function(x) qi(x)[1]), upper = apply(bd[, i, ], 2, function(x) qi(x)[2]))))
  }
  list(fit = f, table = tab, delta = dtab, boot_fail = nfail, boot_diag = ndiag,
       sigma = f$sigma, D = as.matrix(getVarCov(f)))
}

# ---- joint model -------------------------------------------------------------------------------
run_jm <- function(d, f, label, form = ~ value(y), iter = 12000, burn = 2000) {
  cx <- coxph(Surv(time, dead) ~ arm + who + resection + age60 + age70, data = d$surv)
  for (attempt in 1:3) {
    j <- jm(cx, f, time_var = "year", functional_forms = form, n_chains = 3, n_iter = iter, n_burnin = burn, seed = SEED)
    s <- summary(j); rh <- c(s$Outcome1[, "Rhat"], s$Survival[, "Rhat"])
    logm(label, ": JM iter=", iter, " max Rhat=", round(max(rh), 3))
    if (max(rh) < 1.05) break
    iter <- iter * 2; burn <- burn * 2
  }
  B <- do.call(rbind, j$mcmc$betas1); colnames(B) <- names(fixef(f))
  draws <- t(apply(B, 1, function(b) unlist(lapply(WEEKS, function(w) change_from_beta(b, w)))))
  nm <- paste(rep(paste0("w", WEEKS), each = 3), c("sequential", "combination", "difference"), sep = "_")
  tab <- data.frame(analysis = label, model = paste("joint model", deparse(form)), quantity = nm,
                    estimate = colMeans(draws), lower = apply(draws, 2, function(x) qi(x)[1]),
                    upper = apply(draws, 2, function(x) qi(x)[2]), row.names = NULL)
  surv <- data.frame(analysis = label, model = paste("joint model", deparse(form)), term = rownames(s$Survival),
                     s$Survival[, c("Mean", "2.5%", "97.5%", "Rhat")], row.names = NULL)
  list(table = tab, surv = surv, jm = j, max_rhat = max(rh), iter = iter)
}

# JMbayes2 keeps D as its lower triangle, column by column (d11, d21, d31, d22, d32, d33)
vech_to_matrix <- function(v) { m <- matrix(0, 3, 3); m[lower.tri(m, diag = TRUE)] <- v; m + t(m) - diag(diag(m)) }

# ---- main --------------------------------------------------------------------------------------
d <- load_data(root)
out$data <- list(participants = nrow(d$surv), measurements = nrow(d$longi), deaths = sum(d$surv$dead))
main <- run_mar(d, "main", with_delta = TRUE)
jv <- run_jm(d, main$fit, "main", ~ value(y))
js <- run_jm(d, main$fit, "main", ~ value(y) + slope(y))

sens <- list()
for (s in list(list("floor_excluded", TRUE, FALSE), list("after_new_lesions_excluded", FALSE, TRUE))) {
  ds <- load_data(root, drop_floor = s[[2]], drop_after_nl = s[[3]])
  m <- run_mar(ds, s[[1]]); jj <- run_jm(ds, m$fit, s[[1]], ~ value(y))
  sens[[s[[1]]]] <- list(mar = m, jm = jj, n_meas = nrow(ds$longi))
}

est <- rbind(main$table, jv$table, js$table, do.call(rbind, lapply(sens, function(x) rbind(x$mar$table, x$jm$table))))
write.csv(est, file.path(root, "results/estimates.csv"), row.names = FALSE)
write.csv(main$delta, file.path(root, "results/delta-sensitivity.csv"), row.names = FALSE)
write.csv(rbind(jv$surv, js$surv, do.call(rbind, lapply(sens, function(x) x$jm$surv))),
          file.path(root, "results/survival-submodel.csv"), row.names = FALSE)

# truth for the synthetic-data check: posterior means of the main joint model
pm <- jv$jm$statistics$Mean
truth <- list(betas = setNames(as.numeric(pm$betas1), names(fixef(main$fit))), sigma = as.numeric(pm$sigmas),
              D = vech_to_matrix(as.numeric(pm$D)), gamma_arm = as.numeric(pm$gammas["arm"]),
              alpha = as.numeric(pm$alphas))
logm("JM D (posterior mean) vs MAR D, max abs diff: ", round(max(abs(truth$D - unname(main$D))), 3))
# Weibull shape for the simulation's baseline hazard, from the observed death times
wb <- survreg(Surv(time, dead) ~ arm, data = d$surv, dist = "weibull"); truth$weibull_shape <- 1 / wb$scale
truth$death_fraction <- mean(d$surv$dead); truth$max_follow_up <- max(d$surv$time)
writeLines(toJSON(truth, auto_unbox = TRUE, digits = 10, pretty = TRUE), file.path(root, "results/simulation-truth.json"))

# figure inputs (aggregate only): model mean trajectories and the mean change among patients still measured
grid_w <- seq(0, 96, by = 2)
traj <- function(b, model) do.call(rbind, lapply(grid_w, function(w) { q <- change_from_beta(b, w)
  data.frame(model = model, week = w, arm = c("sequential", "combination"), change = q[1:2]) }))
write.csv(rbind(traj(fixef(main$fit), "MAR mixed model"), traj(as.numeric(pm$betas1), "Joint model (value)")),
          file.path(root, "results/trajectories.csv"), row.names = FALSE)
lg <- d$longi; lg$base <- lg$y[lg$year == 0][match(lg$id, lg$id[lg$year == 0])]; lg$week <- lg$year * WPY
lg$bin <- round(lg$week / 8) * 8; lg <- lg[abs(lg$week - lg$bin) <= 4 & lg$bin <= 96, ]
lg <- lg[!duplicated(lg[, c("id", "bin")]), ]
om <- aggregate(cbind(change = y - base) ~ bin + arm, data = lg, FUN = mean)
om$n <- aggregate(y ~ bin + arm, data = lg, FUN = length)$y
om <- data.frame(week = om$bin, arm = ifelse(om$arm == 1, "combination", "sequential"), n = om$n, mean_change = om$change)
write.csv(om[om$n >= 5, ], file.path(root, "results/observed-means.csv"), row.names = FALSE)

out$mar <- list(cov_structure = main$fit$cov_structure, boot_failures = main$boot_fail, boot_diagonal = main$boot_diag,
                sigma = main$sigma, loglik = as.numeric(logLik(main$fit)))
out$jm <- list(value = list(max_rhat = jv$max_rhat, iter = jv$iter), value_slope = list(max_rhat = js$max_rhat, iter = js$iter))
out$sensitivity_measurements <- lapply(sens, function(x) x$n_meas)
out$sessionInfo <- c(R.version.string, paste("nlme", packageVersion("nlme")), paste("survival", packageVersion("survival")),
                     paste("JMbayes2", packageVersion("JMbayes2")))
writeLines(toJSON(out, auto_unbox = TRUE, digits = 10, pretty = TRUE), file.path(root, "results/summary.json"))
stopCluster(CL)
logm("done")
