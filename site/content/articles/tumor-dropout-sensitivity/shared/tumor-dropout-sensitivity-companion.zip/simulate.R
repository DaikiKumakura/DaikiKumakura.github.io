# M06-3: synthetic-data check. Does the joint model recover the mean tumor trajectory when death depends on
# the current tumor value, and how far does the MAR mixed model drift? Truth = posterior means of the main
# joint model (results/simulation-truth.json, written by analyze.R).
# Run: Rscript simulate.R 1; Rscript simulate.R 2; Rscript simulate.R 3 (one scenario each, can run in parallel),
# then Rscript simulate.R combine  (writes results/simulation.csv, results/simulation-summary.csv)
args <- commandArgs(FALSE); root <- dirname(normalizePath(sub("^--file=", "", args[grep("^--file=", args)][1])))
source(file.path(root, "common.R"))
suppressPackageStartupMessages({library(JMbayes2); library(jsonlite); library(MASS)})
tr <- fromJSON(file.path(root, "results/simulation-truth.json"))
NREP <- 30; N <- 150; CENS_MAX <- 3; DT <- 1 / 365.25; GRID <- seq(DT, CENS_MAX, by = DT)
VISITS <- seq(0, CENS_MAX, by = 8 / WPY)
beta <- tr$betas; D <- matrix(unlist(tr$D), 3, 3, byrow = TRUE); stopifnot(isSymmetric(D))

traj <- function(arm, b, t) {
  (beta[1] + beta[2] * arm + b[1]) + (beta[3] + beta[5] * arm + b[2]) * t + (beta[4] + beta[6] * arm + b[3]) * pmax(t - K, 0)
}
# death time under a Weibull baseline and hazard exp(gamma*arm + alpha*m(t)), by inverting the cumulative hazard on a grid
sim_one <- function(alpha, loglam, seed) {
  set.seed(seed)
  arm <- rep(0:1, length.out = N); b <- mvrnorm(N, c(0, 0, 0), D); cens <- runif(N, 0, CENS_MAX)
  rho <- tr$weibull_shape; h0 <- exp(loglam) * rho * GRID^(rho - 1)
  death <- vapply(seq_len(N), function(i) {
    H <- cumsum(h0 * exp(tr$gamma_arm * arm[i] + alpha * traj(arm[i], b[i, ], GRID))) * DT
    k <- which(H >= -log(runif(1)))[1]; if (is.na(k)) Inf else GRID[k]
  }, 0)
  time <- pmin(death, cens); dead <- as.numeric(death <= cens)
  longi <- do.call(rbind, lapply(seq_len(N), function(i) {
    v <- VISITS[VISITS < time[i]]
    data.frame(id = i, year = v, y = traj(arm[i], b[i, ], v) + rnorm(length(v), 0, tr$sigma), arm = arm[i])
  }))
  surv <- data.frame(id = seq_len(N), time = time, dead = dead, arm = arm)
  list(longi = longi, surv = surv[surv$id %in% longi$id, ])
}
# baseline scale chosen so that the expected death fraction equals the observed one (same dropout amount in every scenario)
calibrate <- function(alpha) {
  f <- function(ll) mean(replicate(4, mean(sim_one(alpha, ll, sample.int(1e6, 1))$surv$dead))) - tr$death_fraction
  set.seed(99); uniroot(f, c(-15, 8), tol = 0.02)$root
}
lin <- function(w) { t <- w / WPY; kk <- max(t - K, 0)
  rbind(sequential = c(0, 0, t, kk, 0, 0), combination = c(0, 0, t, kk, t, kk), difference = c(0, 0, 0, 0, t, kk)) }
truth_q <- unlist(lapply(WEEKS, function(w) change_from_beta(beta, w)))
nm <- paste(rep(paste0("w", WEEKS), each = 3), c("sequential", "combination", "difference"), sep = "_")
names(truth_q) <- nm

scen <- data.frame(scenario = c("alpha_estimated", "alpha_zero_MAR_true", "alpha_doubled"),
                   alpha = c(tr$alpha, 0, 2 * tr$alpha))
RHAT_MAX <- 1.1
cmd <- commandArgs(TRUE)[1]
if (cmd != "combine") {
  s <- as.integer(cmd); rows <- list()
  ll <- calibrate(scen$alpha[s])
  # each replicate is saved as it finishes, so an interrupted run resumes; results do not depend on the restart
  repdir <- file.path(root, sprintf("results/simulation-reps-%d", s)); dir.create(repdir, showWarnings = FALSE)
  for (r in seq_len(NREP)) {
    rf <- file.path(repdir, sprintf("rep-%02d.csv", r))
    if (file.exists(rf)) { rows[[length(rows) + 1]] <- read.csv(rf); next }
    d <- sim_one(scen$alpha[s], ll, 1000 * s + r)
    f <- fit_mar(d$longi); b <- fixef(f); V <- vcov(f)
    L <- do.call(rbind, lapply(WEEKS, lin)); est <- as.numeric(L %*% b); se <- sqrt(diag(L %*% V %*% t(L)))
    cx <- coxph(Surv(time, dead) ~ arm, data = d$surv)
    j <- NULL
    for (attempt in 1:3) {  # the local worker cluster occasionally fails to start; retry the same seeded fit
      j <- tryCatch(jm(cx, f, time_var = "year", functional_forms = ~ value(y), n_chains = 3, n_iter = 12000,
                       n_burnin = 2000, seed = r), error = function(e) { message("retry: ", conditionMessage(e)); NULL })
      if (!is.null(j)) break
      Sys.sleep(20)
    }
    B <- do.call(rbind, j$mcmc$betas1); colnames(B) <- names(b)
    dr <- t(apply(B, 1, function(x) unlist(lapply(WEEKS, function(w) change_from_beta(x, w)))))
    rh <- max(c(summary(j)$Outcome1[, "Rhat"], summary(j)$Survival[, "Rhat"]))
    common <- data.frame(scenario = scen$scenario[s], rep = r, quantity = nm, truth = truth_q, deaths = sum(d$surv$dead),
                         mar_cov = f$cov_structure, jm_max_rhat = rh)
    one <- rbind(cbind(common, model = "MAR", estimate = est, lower = est - 1.96 * se, upper = est + 1.96 * se),
                 cbind(common, model = "joint", estimate = colMeans(dr),
                       lower = apply(dr, 2, quantile, .025), upper = apply(dr, 2, quantile, .975)))
    write.csv(one, rf, row.names = FALSE); rows[[length(rows) + 1]] <- read.csv(rf)
    cat(scen$scenario[s], r, round(rh, 3), "\n")
  }
  res <- do.call(rbind, rows); rownames(res) <- NULL
  write.csv(res, file.path(root, sprintf("results/simulation-%d.csv", s)), row.names = FALSE)
  writeLines(toJSON(list(scenario = scen$scenario[s], log_lambda = ll), auto_unbox = TRUE, digits = 8),
             file.path(root, sprintf("results/simulation-calibration-%d.json", s)))
  quit(save = "no")
}
res <- do.call(rbind, lapply(1:3, function(s) read.csv(file.path(root, sprintf("results/simulation-%d.csv", s)))))
write.csv(res, file.path(root, "results/simulation.csv"), row.names = FALSE)
summ <- function(x, set) data.frame(scenario = x$scenario[1], model = x$model[1], quantity = x$quantity[1], set = set,
  truth = x$truth[1], bias = mean(x$estimate - x$truth), mc_se_bias = sd(x$estimate) / sqrt(nrow(x)),
  rmse = sqrt(mean((x$estimate - x$truth)^2)), coverage = mean(x$lower <= x$truth & x$truth <= x$upper),
  mean_deaths = mean(x$deaths), reps = nrow(x))
conv <- res$jm_max_rhat < RHAT_MAX
agg <- rbind(
  do.call(rbind, lapply(split(res, list(res$scenario, res$model, res$quantity), drop = TRUE), summ, set = "all reps")),
  do.call(rbind, lapply(split(res[conv, ], list(res$scenario[conv], res$model[conv], res$quantity[conv]), drop = TRUE),
                        summ, set = "joint converged (Rhat < 1.1)")))
rownames(agg) <- NULL
write.csv(agg, file.path(root, "results/simulation-summary.csv"), row.names = FALSE)
print(agg[agg$set != "all reps" | agg$model == "MAR", ])
