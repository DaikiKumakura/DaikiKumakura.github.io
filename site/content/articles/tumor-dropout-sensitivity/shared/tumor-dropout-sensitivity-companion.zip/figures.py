"""M06 figures from aggregate results only. Run after analyze.R and simulate.R: python figures.py"""
import csv
from pathlib import Path
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

R = Path(__file__).resolve().parent
F = R / "figures"
F.mkdir(exist_ok=True)
ARMS = {"sequential": ("Sequential", "#3b6ea8"), "combination": ("Combination", "#c2622d")}
plt.rcParams.update({"font.size": 10, "axes.spines.top": False, "axes.spines.right": False})


def rows(name):
    with open(R / "results" / name, newline="") as f:
        return list(csv.DictReader(f))


def fig_trajectories():
    tr, ob = rows("trajectories.csv"), rows("observed-means.csv")
    fig, axes = plt.subplots(2, 2, figsize=(9.2, 5.2), sharex=True, gridspec_kw={"height_ratios": [3, 1]})
    for k, (arm, (label, col)) in enumerate(ARMS.items()):
        ax, axn = axes[0, k], axes[1, k]
        o = [r for r in ob if r["arm"] == arm and int(r["n"]) >= 10]
        ax.plot([float(r["week"]) for r in o], [float(r["mean_change"]) for r in o], "o", color=col, ms=4,
                label="Mean of patients still measured (n ≥ 10)")
        for model, ls in (("MAR mixed model", "-"), ("Joint model (value)", "--")):
            t = [r for r in tr if r["arm"] == arm and r["model"] == model]
            ax.plot([float(r["week"]) for r in t], [float(r["change"]) for r in t], ls, color="black", lw=1.4, label=model)
        ax.axhline(0, color="grey", lw=.6); ax.set_title(label); ax.set_ylim(-2.6, 0.3)
        axn.bar([float(r["week"]) for r in ob if r["arm"] == arm], [int(r["n"]) for r in ob if r["arm"] == arm],
                width=6, color=col, alpha=.6)
        axn.set_xlabel("Weeks from randomization"); axn.set_xlim(-4, 100)
    axes[0, 1].sharey(axes[0, 0]); axes[1, 1].sharey(axes[1, 0])
    axes[0, 0].set_ylabel("Change from baseline\n(transformed tumor size)")
    axes[1, 0].set_ylabel("Patients\nmeasured")
    axes[0, 0].legend(frameon=False, fontsize=8, loc="lower left")
    fig.tight_layout(); fig.savefig(F / "01-trajectories.png", dpi=160); plt.close(fig)


def fig_delta():
    d = rows("delta-sensitivity.csv")
    fig, axes = plt.subplots(1, 2, figsize=(9.2, 3.6))
    ax = axes[0]
    for arm, (label, col) in ARMS.items():
        x = [r for r in d if r["apply_to"] == "both" and r["quantity"] == f"w48_{arm}"]
        dl = [float(r["delta_seq"]) for r in x]
        ax.plot(dl, [float(r["estimate"]) for r in x], "o-", color=col, label=label)
        ax.fill_between(dl, [float(r["lower"]) for r in x], [float(r["upper"]) for r in x], color=col, alpha=.15)
    ax.axhline(0, color="grey", lw=.6); ax.set_xlabel("δ, both arms (per year after last measurement)")
    ax.set_ylabel("Mean change at 48 weeks"); ax.legend(frameon=False, fontsize=8); ax.set_title("Shrinkage under MNAR shifts")
    ax = axes[1]
    for key, label, col in (("sequential_only", "δ in sequential arm only", "#3b6ea8"),
                            ("combination_only", "δ in combination arm only", "#c2622d")):
        for w, mk in (("w24", "s"), ("w48", "o")):
            x = [r for r in d if r["apply_to"] == key and r["quantity"] == f"{w}_difference"]
            dl = [float(r["delta_seq"]) + float(r["delta_comb"]) for r in x]
            ax.errorbar(dl, [float(r["estimate"]) for r in x],
                        yerr=[[float(r["estimate"]) - float(r["lower"]) for r in x], [float(r["upper"]) - float(r["estimate"]) for r in x]],
                        fmt=mk + ("-" if w == "w48" else ":"), color=col, ms=4, capsize=2, lw=1,
                        label=f"{label}, {w[1:]} wk")
    ax.axhline(0, color="grey", lw=.6); ax.set_xlabel("δ (per year)"); ax.set_ylabel("Combination − sequential")
    ax.legend(frameon=False, fontsize=7); ax.set_title("Arm difference: tipping point")
    fig.tight_layout(); fig.savefig(F / "02-delta-sensitivity.png", dpi=160); plt.close(fig)


def fig_simulation():
    s = [r for r in rows("simulation-summary.csv") if r["set"] == "joint converged (Rhat < 1.1)"]
    scen = [("alpha_zero_MAR_true", "α = 0\n(MAR true)"), ("alpha_estimated", "α estimated"), ("alpha_doubled", "α doubled")]
    qs = [("w48_sequential", "Sequential, 48 wk"), ("w48_combination", "Combination, 48 wk"), ("w48_difference", "Difference, 48 wk")]
    fig, axes = plt.subplots(1, 3, figsize=(9.6, 3.3), sharey=True)
    for ax, (q, title) in zip(axes, qs):
        for k, (model, col, off) in enumerate((("MAR", "#777777", -.12), ("joint", "#2a7f62", .12))):
            x = [r for sc, _ in scen for r in s if r["scenario"] == sc and r["model"] == model and r["quantity"] == q]
            ax.errorbar([i + off for i in range(len(x))], [float(r["bias"]) for r in x],
                        yerr=[1.96 * float(r["mc_se_bias"]) for r in x], fmt="o", color=col, capsize=2,
                        label="MAR mixed model" if model == "MAR" else "Joint model")
        ax.axhline(0, color="grey", lw=.6); ax.set_xticks(range(3)); ax.set_xticklabels([l for _, l in scen], fontsize=8)
        ax.set_title(title, fontsize=9)
    axes[0].set_ylabel("Bias (estimate − truth)\n±1.96 Monte Carlo SE"); axes[0].legend(frameon=False, fontsize=8)
    fig.suptitle("Replicates with converged joint model (Rhat < 1.1); MAR on the same replicates", fontsize=9)
    fig.tight_layout(); fig.savefig(F / "03-simulation.png", dpi=160); plt.close(fig)


if __name__ == "__main__":
    fig_trajectories(); fig_delta(); fig_simulation()
    print(sorted(p.name for p in F.glob("*.png")))
