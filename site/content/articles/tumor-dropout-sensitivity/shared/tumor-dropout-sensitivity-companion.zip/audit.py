"""M06-1 audit: how tumor follow-up ends, and whether the end relates to tumor size and death. Writes results/audit.json (aggregate only)."""
import csv, json, statistics as st
from collections import defaultdict
from pathlib import Path

R = Path(__file__).resolve().parent
WPY = 52.1775
FLOOR_CUT = -3.33


def load():
    longi = defaultdict(list)
    arm = {}
    with open(R / "raw/colorectalLongi.csv", newline="") as f:
        for r in csv.DictReader(f):
            i = int(r["id"])
            longi[i].append((float(r["year"]), float(r["tumor.size"])))
            arm[i] = r["treatment"]
    ev = defaultdict(list)
    with open(R / "raw/colorectal.csv", newline="") as f:
        for r in csv.DictReader(f):
            ev[int(r["id"])].append(r)
    pt = {}
    for i, rows in ev.items():
        rows.sort(key=lambda r: float(r["time1"]))
        last = rows[-1]
        nl = [float(r["time1"]) for r in rows if r["new.lesions"] == "1"]
        pt[i] = {"end": float(last["time1"]), "dead": int(last["state"]), "first_nl": min(nl) if nl else None,
                 "n_nl": len(nl), "arm": last["treatment"]}
    for v in longi.values():
        v.sort()
    return longi, pt


def q(xs):
    xs = sorted(xs)
    if not xs:
        return None
    k = lambda p: xs[min(len(xs) - 1, int(round(p * (len(xs) - 1))))]
    return {"n": len(xs), "q25": round(k(.25), 3), "median": round(k(.5), 3), "q75": round(k(.75), 3)}


def main():
    longi, pt = load()
    out = {"participants": len(longi), "measurements": sum(map(len, longi.values())),
           "deaths": sum(p["dead"] for p in pt.values()),
           "with_new_lesions": sum(p["first_nl"] is not None for p in pt.values())}
    # 1. Is a dropout reason recorded? Only these columns exist.
    with open(R / "raw/colorectalLongi.csv", newline="") as f:
        out["longi_columns"] = next(csv.reader(f))
    with open(R / "raw/colorectal.csv", newline="") as f:
        out["event_columns"] = next(csv.reader(f))
    # 2. How measurement follow-up ends relative to new lesions and death/censoring
    cats = defaultdict(int)
    gap_death, gap_cens, after_nl_counts, n_meas = [], [], [], defaultdict(list)
    slope_last = {"dead_within_6m": [], "other": []}
    level_last = {"dead_within_6m": [], "other": []}
    per_arm = defaultdict(lambda: defaultdict(int))
    for i, v in longi.items():
        p = pt[i]
        tl = v[-1][0]
        n_meas[p["arm"]].append(len(v))
        after_nl = [t for t, _ in v if p["first_nl"] is not None and t > p["first_nl"] + 1e-9]
        after_nl_counts.append(len(after_nl))
        post_end = any(t > p["end"] + 1e-9 for t, _ in v)
        if post_end:
            c = "measurement_after_terminal_time"
        elif p["first_nl"] is not None and tl <= p["first_nl"] + 14 / 365.25:
            c = "stops_at_or_before_new_lesions"
        elif p["first_nl"] is not None:
            c = "continues_after_new_lesions"
        else:
            c = "no_new_lesions"
        cats[c] += 1
        per_arm[p["arm"]][c] += 1
        g = (p["end"] - tl) * WPY
        (gap_death if p["dead"] else gap_cens).append(g)
        if len(v) >= 2:
            (t1, y1), (t2, y2) = v[-2], v[-1]
            key = "dead_within_6m" if p["dead"] and (p["end"] - tl) <= 0.5 else "other"
            slope_last[key].append((y2 - y1) / (t2 - t1))
            level_last[key].append(y2 - v[0][1])
    out["followup_end_category"] = dict(cats)
    out["followup_end_category_by_arm"] = {a: dict(d) for a, d in per_arm.items()}
    out["weeks_last_measurement_to_death"] = q(gap_death)
    out["weeks_last_measurement_to_censoring"] = q(gap_cens)
    out["measurements_after_first_new_lesions"] = {"participants_with_any": sum(c > 0 for c in after_nl_counts),
                                                   "total": sum(after_nl_counts)}
    out["measurements_per_participant_by_arm"] = {a: q(x) for a, x in n_meas.items()}
    out["last_interval_slope_per_year"] = {k: q(x) for k, x in slope_last.items()}
    out["last_value_minus_baseline"] = {k: q(x) for k, x in level_last.items()}
    out["floor_censored_measurements"] = sum(1 for v in longi.values() for _, y in v if y <= FLOOR_CUT)
    # 3. Retention: participants still measured at each scheduled window, by arm
    ret = {}
    for w in (8, 16, 24, 32, 48, 72):
        L = w / WPY
        ret[w] = {a: sum(1 for i, v in longi.items() if pt[i]["arm"] == a and v[-1][0] >= L - 4 / WPY) for a in ("S", "C")}
    out["still_measured_at_week"] = ret
    out["arm_size"] = {a: sum(1 for p in pt.values() if p["arm"] == a) for a in ("S", "C")}
    (R / "results/audit.json").write_text(json.dumps(out, indent=2) + "\n")
    print(json.dumps(out, indent=2))


if __name__ == "__main__":
    main()
