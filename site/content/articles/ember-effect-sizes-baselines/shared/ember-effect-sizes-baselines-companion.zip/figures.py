"""Figure 1: AUPRC of EMBER against baselines by regime and cell line. Figure 2: genetic-interaction metrics, EMBER-GI against STRING (GNN)."""
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parent
(ROOT / "figures").mkdir(exist_ok=True)
s5 = pd.read_csv(ROOT / "inputs" / "table-s5-selected-rows.csv")
regs = ["Unseen cell line, unseen perturbations", "Unseen cell line, seen perturbations", "Seen cell line, unseen perturbations"]
titles = ["Unseen cell line and perturbations", "Unseen cell line, seen perturbations", "Seen cell line, unseen perturbations"]
cells = ["HepG2", "Jurkat", "K562", "RPE1"]
fig, axes = plt.subplots(1, 3, figsize=(11.0, 3.8), dpi=150, sharey=True)
for ax, reg, ttl in zip(axes, regs, titles):
    g = s5[s5.regime == reg]
    for j, cl in enumerate(cells):
        c = g[g.cell_line == cl]
        def val(role=None, model=None):
            r = c[c.role == role] if role else c[c.model == model]
            return r.iloc[0] if len(r) else None
        items = [("Noise floor", val(model="Random (Noise Floor)"), "#999999", -0.27), ("STRING (GNN)", val(model="STRING (GNN)"), "#CC79A7", -0.09),
                 ("Best external", val(role="best external baseline by AUPRC (selected from the table)"), "#0072B2", 0.09), ("EMBER", val(model="EMBER"), "#D55E00", 0.27)]
        for lab, r, col, off in items:
            if r is None:
                continue
            ax.errorbar(j + off, r.auprc, yerr=r.auprc_sd, fmt="o", color=col, ms=5, capsize=2, label=lab if j == 0 else None)
    ax.set_xticks(range(len(cells)))
    ax.set_xticklabels(cells, fontsize=8)
    ax.set_title(ttl, fontsize=9)
axes[0].set_ylabel("Test AUPRC (mean ± SD over 10 partitions)")
axes[0].legend(fontsize=7, loc="upper left")
fig.tight_layout()
fig.savefig(ROOT / "figures" / "01-perturbation-auprc.png")

g = pd.read_csv(ROOT / "results" / "genetic-interaction-vs-string-gnn.csv")
labels = {"auprc_any": "AUPRC, any interaction", "auroc_any": "AUROC, any interaction", "pearson": "Pearson r (signed qGI)", "spearman": "Spearman rho (signed qGI)"}
fig, axes = plt.subplots(1, 4, figsize=(10.5, 3.2), dpi=150)
for ax, (_, r) in zip(axes, g.iterrows()):
    ax.bar([0, 1], [r.string_gnn, r.ember_gi], yerr=[r.string_gnn_sd, r.ember_gi_sd], color=["#CC79A7", "#D55E00"], capsize=3)
    ax.set_xticks([0, 1])
    ax.set_xticklabels(["STRING (GNN)", "EMBER-GI"], fontsize=7)
    ax.set_title(labels[r.metric], fontsize=8)
    if r.metric == "auprc_any":
        ax.axhline(0.089, color="#555555", ls=":", lw=1)
        ax.text(1.45, 0.092, "chance 0.089", fontsize=6, ha="right")
    if r.metric == "auroc_any":
        ax.axhline(0.5, color="#555555", ls=":", lw=1)
        ax.set_ylim(0.4, 0.66)
fig.tight_layout()
fig.savefig(ROOT / "figures" / "02-genetic-interaction-metrics.png")
