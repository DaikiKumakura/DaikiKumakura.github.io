"""How large are EMBER's improvements relative to baselines and to split-to-split variation?

Inputs (inputs/): mean +/- s.d. across 10 random partitions, transcribed from Tables S5 (perturbation-response prediction, AUPRC) and S6 (genetic-interaction
prediction on the HAP1 map) of the EMBER preprint (Ho, Xing, Ma; bioRxiv 10.64898/2026.10.28.762655). Rows in table-s5-selected-rows.csv are EMBER, its static ablation,
STRING (GNN), the trivial baselines, and the best external baseline by AUPRC that I selected from the full table for each regime and cell line.
Everything computed here is arithmetic on those reported means and standard deviations; no model is re-run, and no p-value is recomputed
(the partitions overlap, so they are not independent replicates; the preprint says so as well).
"""
from pathlib import Path

import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parent
OUT = ROOT / "results"
OUT.mkdir(exist_ok=True)


def pooled_sd(a: float, b: float) -> float:
    return float(np.sqrt((a ** 2 + b ** 2) / 2))


def regime_table(s5: pd.DataFrame) -> pd.DataFrame:
    rows = []
    for (reg, cl), g in s5.groupby(["regime", "cell_line"], sort=False):
        pick = lambda role: g[g.role == role]
        e = g[g.model == "EMBER"].iloc[0]
        best = pick("best external baseline by AUPRC (selected from the table)").iloc[0]
        static = g[g.model == "EMBER (Static)"].iloc[0]
        noise = g[g.model == "Random (Noise Floor)"].iloc[0]
        train_mean = g[g.model == "Train Mean"].iloc[0]
        ctx = g[g.model == "Context Mean"]
        rows.append(dict(
            regime=reg, cell_line=cl, ember=e.auprc, ember_sd=e.auprc_sd, best_external=best.model, best_external_auprc=best.auprc, best_external_sd=best.auprc_sd,
            delta_vs_best=e.auprc - best.auprc, d_vs_best=(e.auprc - best.auprc) / pooled_sd(e.auprc_sd, best.auprc_sd),
            delta_vs_static=e.auprc - static.auprc, noise_floor=noise.auprc, ember_above_noise=e.auprc - noise.auprc,
            best_above_noise=best.auprc - noise.auprc, share_of_ember_gain_by_best=(best.auprc - noise.auprc) / (e.auprc - noise.auprc),
            train_mean=train_mean.auprc, share_by_best_train_mean_anchor=(best.auprc - train_mean.auprc) / (e.auprc - train_mean.auprc),
            context_mean=float(ctx.auprc.iloc[0]) if len(ctx) else np.nan, delta_vs_context_mean=(e.auprc - float(ctx.auprc.iloc[0])) if len(ctx) else np.nan,
            share_by_best_context_mean_anchor=((best.auprc - float(ctx.auprc.iloc[0])) / (e.auprc - float(ctx.auprc.iloc[0]))) if len(ctx) else np.nan))
    return pd.DataFrame(rows)


def gi_table(s6: pd.DataFrame) -> pd.DataFrame:
    e = s6[s6.model == "EMBER-GI"].iloc[0]
    s = s6[s6.model == "STRING (GNN)"].iloc[0]
    rows = []
    for metric in ("auprc_any", "auroc_any", "pearson", "spearman"):
        de = e[metric] - s[metric]
        rows.append(dict(metric=metric, ember_gi=e[metric], ember_gi_sd=e[metric + "_sd"], string_gnn=s[metric], string_gnn_sd=s[metric + "_sd"], delta=de,
                         d=de / pooled_sd(e[metric + "_sd"], s[metric + "_sd"])))
    return pd.DataFrame(rows)


def main() -> None:
    s5 = pd.read_csv(ROOT / "inputs" / "table-s5-selected-rows.csv")
    s6 = pd.read_csv(ROOT / "inputs" / "table-s6-selected-rows.csv")
    rt = regime_table(s5)
    rt.round(4).to_csv(OUT / "perturbation-by-regime-and-cell-line.csv", index=False, lineterminator=chr(10))
    pd.set_option("display.width", 250)
    print(rt[["regime", "cell_line", "ember", "best_external", "best_external_auprc", "delta_vs_best", "d_vs_best", "delta_vs_context_mean", "share_of_ember_gain_by_best"]].round(3).to_string())
    avg = rt.groupby("regime", sort=False).agg(ember=("ember", "mean"), best_external=("best_external_auprc", "mean"), delta_vs_best=("delta_vs_best", "mean"),
                                               delta_min=("delta_vs_best", "min"), delta_max=("delta_vs_best", "max"), d_min=("d_vs_best", "min"), d_max=("d_vs_best", "max"),
                                               delta_vs_static=("delta_vs_static", "mean"), static_min=("delta_vs_static", "min"), static_max=("delta_vs_static", "max"),
                                               noise_floor=("noise_floor", "mean"), train_mean=("train_mean", "mean"),
                                               share_of_ember_gain_by_best=("share_of_ember_gain_by_best", "mean"),
                                               share_train_mean_anchor=("share_by_best_train_mean_anchor", "mean"),
                                               share_context_mean_anchor=("share_by_best_context_mean_anchor", "mean"),
                                               context_mean_diff_min=("delta_vs_context_mean", "min"), context_mean_diff_max=("delta_vs_context_mean", "max")).reset_index()
    avg.round(4).to_csv(OUT / "perturbation-regime-averages.csv", index=False, lineterminator=chr(10))
    print(avg.round(3).to_string())
    gt = gi_table(s6)
    gt.round(4).to_csv(OUT / "genetic-interaction-vs-string-gnn.csv", index=False, lineterminator=chr(10))
    print(gt.round(3).to_string())


if __name__ == "__main__":
    main()
