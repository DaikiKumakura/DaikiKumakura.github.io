import numpy as np
import pandas as pd

import analysis as an


def test_regime_averages_match_values_stated_in_the_text_of_the_preprint():
    s5 = pd.read_csv(an.ROOT / "inputs" / "table-s5-selected-rows.csv")
    rt = an.regime_table(s5)
    avg = rt.groupby("regime").ember.mean()
    assert abs(avg["Unseen cell line, unseen perturbations"] - 0.425) < 0.0006
    assert abs(avg["Unseen cell line, seen perturbations"] - 0.486) < 0.0006
    assert abs(avg["Seen cell line, unseen perturbations"] - 0.494) < 0.0006


def test_pooled_sd_and_standardised_difference():
    assert abs(an.pooled_sd(0.003, 0.004) - np.sqrt((0.003 ** 2 + 0.004 ** 2) / 2)) < 1e-12
    gt = an.gi_table(pd.read_csv(an.ROOT / "inputs" / "table-s6-selected-rows.csv"))
    r = gt[gt.metric == "auprc_any"].iloc[0]
    assert abs(r.delta - (0.181 - 0.156)) < 1e-9 and abs(r.d - 0.025 / 0.008) < 1e-6


def test_share_of_gain_is_between_zero_and_one_for_every_row():
    rt = an.regime_table(pd.read_csv(an.ROOT / "inputs" / "table-s5-selected-rows.csv"))
    assert ((rt.share_of_ember_gain_by_best > 0) & (rt.share_of_ember_gain_by_best < 1)).all()
