# EMBER gains against baselines and split variability: companion code

Arithmetic on the means and standard deviations (10 random partitions) in Supplementary Tables S5 and S6 of the EMBER preprint (Ho, Xing, Ma; bioRxiv 10.64898/2026.10.28.762655). No model is re-run.

- `inputs/`: rows transcribed (only the columns used) from the supplementary tables of a preprint released under CC BY-NC-ND 4.0; source: Ho N, Xing EP, Ma J, bioRxiv 2026, doi:10.64898/2026.10.28.762655; (EMBER, static ablation, STRING (GNN), trivial baselines, the best external baseline selected by AUPRC).
- `analysis.py`: differences, standardized differences, share of the gain captured by the best external baseline.
- `figures.py`: Figures 1 and 2.
- `test_analysis.py`: checks (`python -m pytest test_analysis.py`).
- `results/`: CSV outputs.

Requires Python 3 with numpy, pandas, matplotlib.
