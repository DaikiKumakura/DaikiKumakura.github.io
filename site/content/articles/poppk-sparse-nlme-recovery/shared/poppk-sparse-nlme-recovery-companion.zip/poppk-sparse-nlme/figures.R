# Figures for the sparse-sampling population PK article (Okabe-Ito palette). Run: Rscript figures.R (after simulate.R)
script_dir <- dirname(normalizePath(sub("^--file=", "", grep("^--file=", commandArgs(FALSE), value = TRUE)[1]), winslash = "/"))
suppressPackageStartupMessages(library(ggplot2))
o <- read.csv(file.path(script_dir, "results/summary.csv")); o <- o[o$analysis == "main" & o$subset == "returned", ]; o$n <- factor(o$n_subjects)
cols <- c("20" = "#E69F00", "40" = "#009E73", "80" = "#0072B2")
r <- o[o$variant == "random_ka" & o$parameter %in% c("CL", "V", "ka"), ]
r$parameter <- factor(r$parameter, c("CL", "V", "ka"), c("Typical CL", "Typical V", "Typical ka"))
p1 <- ggplot(r, aes(samples_per_subject, 100 * rel_bias_median, colour = n, fill = n, group = n)) +
  geom_hline(yintercept = 0, colour = "grey50") + geom_ribbon(aes(ymin = 100 * rel_bias_q05, ymax = 100 * rel_bias_q95), alpha = 0.15, colour = NA) +
  geom_line(linewidth = 0.8) + geom_point(size = 2) + facet_wrap(~parameter) + scale_x_continuous(breaks = c(2, 3, 4, 6)) +
  scale_colour_manual(values = cols, name = "Subjects") + scale_fill_manual(values = cols, name = "Subjects") +
  labs(x = "Samples per subject", y = "Relative error of the estimate (%)") + theme_bw(base_size = 12) + theme(legend.position = "bottom")
ggsave(file.path(script_dir, "figures/figure-1-typical-values.png"), p1, width = 9.5, height = 4.6, dpi = 160)
w <- o[o$variant == "random_ka" & o$parameter %in% c("w_CL", "w_V", "w_ka"), ]
w$parameter <- factor(w$parameter, c("w_CL", "w_V", "w_ka"), c("SD of random effect on CL", "SD of random effect on V", "SD of random effect on ka"))
p2 <- ggplot(w, aes(samples_per_subject, share_within_20pct, colour = n, group = n)) + geom_line(linewidth = 0.8) + geom_point(size = 2) + facet_wrap(~parameter) +
  scale_x_continuous(breaks = c(2, 3, 4, 6)) + scale_y_continuous(limits = c(0, 1)) + scale_colour_manual(values = cols, name = "Subjects") +
  labs(x = "Samples per subject", y = "Share of studies within 20% of the true SD") + theme_bw(base_size = 12) + theme(legend.position = "bottom")
ggsave(file.path(script_dir, "figures/figure-2-random-effects.png"), p2, width = 9.5, height = 4.6, dpi = 160)
