# Companion: what nlme recovers from sparse sampling in a one-compartment oral PK model

Simulation code and results for the article "What does nlme recover from sparse sampling in a population pharmacokinetic analysis? Simulated studies with 20 to 80 subjects and 2 to 6 samples per subject". No subject-level data are used.

## Files

- `simulate.R`: simulates one-compartment oral PK studies (20, 40 or 80 subjects; 2, 3, 4 or 6 samples per subject from four time windows), fits them with nlme with random effects on CL, V and ka or on CL and V only, and records, for each study, whether nlme returned a fit and whether it gave a convergence warning, with the estimates. Two extra sets of 400 studies at 40 subjects check fixed sampling windows and the starting values (`Rscript simulate.R 400`; seed 20261123; writes `results/raw.csv`, `results/summary.csv` and `results/session-info.txt`). Uses the nlme package and base R (parallel).
- `figures.R`: draws Figures 1 and 2 from `results/summary.csv` (requires ggplot2).
- `results/raw.csv`: the result of every simulated study (the estimates and the flags).
- `results/summary.csv`: aggregate results for every cell and parameter, for returned fits and for clean fits (Tables 1 to 5 and the text).
- `results/session-info.txt`: R 4.5.3 session information and the nlme version.

## Reproduce

```
Rscript simulate.R 400
Rscript figures.R
```

Each study uses its own seed derived from the base seed, so the results do not depend on the number of cores used. The output depends on the random-number stream of the R version used.
