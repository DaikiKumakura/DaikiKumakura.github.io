# Sparse sampling in a population pharmacokinetic analysis: what does nlme recover? One-compartment oral model, nlme (Lindstrom-Bates
# linearisation), with and without a random effect on the absorption rate constant. R 4.5.3, packages nlme (recommended package shipped with R) and parallel.
# Run: Rscript simulate.R 400       (studies per cell; seed 20261123; each study uses set.seed(SEED + study index * 1000 + cell), so results do not depend on the number of cores)
# Main grid: 3 subject numbers x 4 sample numbers x 2 models, windows chosen at random per subject. Extra cells (40 subjects, full model) check (a) fixed sampling windows
# and (b) the starting values. Every study's raw estimates are saved (results/raw.csv); nlme is run with returnObject = TRUE, so a study is "returned" when no error occurred
# and "clean" when, in addition, no convergence warning was issued (nlme warns when the iteration limit is reached, when step halving fails or when a precision matrix is singular).
# The structural warning "fewer observations than random effects in all level 1 groups" (2 samples per subject, 3 random effects) is recorded separately and does not make a study unclean.
script_dir <- dirname(normalizePath(sub("^--file=", "", grep("^--file=", commandArgs(FALSE), value = TRUE)[1]), winslash = "/"))
args <- commandArgs(trailingOnly = TRUE)
SEED <- 20261123L; NREP <- if (length(args) >= 1) as.integer(args[1]) else 400L
NCORES <- if (length(args) >= 2) as.integer(args[2]) else max(1L, parallel::detectCores() - 1L)
DOSE <- 100; TCL <- 5; TV <- 50; TKA <- 1        # mg, L/h, L, 1/h
OMEGA <- c(CL = 0.30, V = 0.20, ka = 0.50)         # SD of the log-scale random effects
SIGMA <- 0.15                                      # SD of the residual error on the log concentration
WINDOWS <- list(c(0.25, 2), c(2, 6), c(6, 12), c(12, 24))   # sampling windows (h); window 1 is the absorption phase
N_GRID <- c(20, 40, 80); NS_GRID <- c(2, 3, 4, 6)  # subjects; samples per subject
START <- list(default = c(lCL = log(3), lV = log(30), lka = log(0.5)), truth = c(lCL = log(5), lV = log(50), lka = log(1)), ka2 = c(lCL = log(3), lV = log(30), lka = log(2)))

simulate_data <- function(n, ns, fixed_windows) {
  do.call(rbind, lapply(seq_len(n), function(i) {
    cl <- TCL * exp(rnorm(1, 0, OMEGA["CL"])); v <- TV * exp(rnorm(1, 0, OMEGA["V"])); ka <- TKA * exp(rnorm(1, 0, OMEGA["ka"]))
    idx <- if (!is.null(fixed_windows)) fixed_windows else if (ns <= 4) sort(sample(4, ns)) else sort(rep(1:4, length.out = ns))
    t <- sapply(idx, function(k) runif(1, WINDOWS[[k]][1], WINDOWS[[k]][2])); ke <- cl / v
    conc <- DOSE * ka / (v * (ka - ke)) * (exp(-ke * t) - exp(-ka * t))
    data.frame(id = i, t = t, y = log(conc) + rnorm(length(t), 0, SIGMA), absorb = any(idx == 1))
  }))
}
one_study <- function(task) {
  suppressPackageStartupMessages(library(nlme))
  set.seed(SEED + task$rep * 1000L + task$cell)
  d <- simulate_data(task$n, task$ns, task$fixed_windows)
  model <- function(t, lCL, lV, lka) { cl <- exp(lCL); v <- exp(lV); ka <- exp(lka); ke <- cl / v; log(DOSE * ka / (v * (ka - ke)) * (exp(-ke * t) - exp(-ka * t))) }
  assign("model", model, envir = globalenv()); assign("DOSE", DOSE, envir = globalenv())
  re <- if (task$variant == "random_ka") pdDiag(lCL + lV + lka ~ 1) else pdDiag(lCL + lV ~ 1)
  warn_conv <- FALSE; warn_few <- FALSE
  f <- try(withCallingHandlers(nlme(y ~ model(t, lCL, lV, lka), data = d, fixed = lCL + lV + lka ~ 1, random = re, groups = ~id,
    start = START[[task$start]], control = nlmeControl(maxIter = 100, msMaxIter = 200, returnObject = TRUE)),
    warning = function(w) { if (grepl("fewer observations than random effects", conditionMessage(w))) warn_few <<- TRUE else warn_conv <<- TRUE; invokeRestart("muffleWarning") }), silent = TRUE)
  out <- c(returned = 0, warned = NA, warn_few = NA, sd_na = NA, CL = NA, V = NA, ka = NA, w_CL = NA, w_V = NA, w_ka = NA, sigma = NA, absorb_share = mean(tapply(d$absorb, d$id, any)))
  if (inherits(f, "try-error")) return(out)
  sds <- suppressWarnings(as.numeric(VarCorr(f)[, "StdDev"])); fx <- fixef(f)
  out[c("returned", "warned", "warn_few")] <- c(1, as.numeric(warn_conv), as.numeric(warn_few)); out["sd_na"] <- as.numeric(any(is.na(sds)))
  out[c("CL", "V", "ka", "sigma")] <- c(exp(fx[["lCL"]]), exp(fx[["lV"]]), exp(fx[["lka"]]), f$sigma)
  out["w_CL"] <- sds[1]; out["w_V"] <- sds[2]; if (task$variant == "random_ka") out["w_ka"] <- sds[3]
  out
}

cells <- rbind(
  data.frame(analysis = "main", variant = rep(c("random_ka", "fixed_ka"), times = length(N_GRID) * length(NS_GRID)), n = rep(N_GRID, each = 2 * length(NS_GRID)), ns = rep(rep(NS_GRID, each = 2), times = length(N_GRID)), start = "default", windows = "random", stringsAsFactors = FALSE),
  data.frame(analysis = c("fixed_windows", "fixed_windows", "start", "start", "start", "start"), variant = "random_ka", n = 40, ns = c(2, 3, 2, 2, 3, 3),
             start = c("default", "default", "truth", "ka2", "truth", "ka2"), windows = c("1,3", "1,2,4", "random", "random", "random", "random"), stringsAsFactors = FALSE))
cells$cell <- seq_len(nrow(cells))
tasks <- do.call(c, lapply(seq_len(nrow(cells)), function(i) lapply(seq_len(NREP), function(r) list(rep = r, cell = cells$cell[i], variant = cells$variant[i], n = cells$n[i], ns = cells$ns[i], start = cells$start[i],
  fixed_windows = if (cells$windows[i] == "random") NULL else as.integer(strsplit(cells$windows[i], ",")[[1]])))))
cl <- parallel::makeCluster(NCORES); parallel::clusterExport(cl, c("SEED", "DOSE", "TCL", "TV", "TKA", "OMEGA", "SIGMA", "WINDOWS", "START", "simulate_data"))
res <- parallel::parLapplyLB(cl, tasks, one_study); parallel::stopCluster(cl)
mat <- do.call(rbind, res)
raw <- data.frame(cell = rep(cells$cell, each = NREP), rep = rep(seq_len(NREP), times = nrow(cells)), mat); dir.create(file.path(script_dir, "results"), showWarnings = FALSE)
write.csv(raw, file.path(script_dir, "results/raw.csv"), row.names = FALSE)
truth <- c(CL = TCL, V = TV, ka = TKA, w_CL = OMEGA[["CL"]], w_V = OMEGA[["V"]], w_ka = OMEGA[["ka"]], sigma = SIGMA)
rows <- list()
for (i in seq_len(nrow(cells))) {
  m <- mat[seq((i - 1) * NREP + 1, i * NREP), , drop = FALSE]
  for (sub in c("returned", "clean")) {
    ok <- if (sub == "returned") m[, "returned"] == 1 else (m[, "returned"] == 1 & m[, "warned"] == 0)
    for (p in names(truth)) {
      if (p == "w_ka" && cells$variant[i] == "fixed_ka") next
      r <- m[ok, p] / truth[[p]] - 1
      rows[[length(rows) + 1]] <- data.frame(analysis = cells$analysis[i], variant = cells$variant[i], n_subjects = cells$n[i], samples_per_subject = cells$ns[i], start = cells$start[i], windows = cells$windows[i],
        subset = sub, studies = NREP, share_returned = mean(m[, "returned"] == 1), share_clean = mean(m[, "returned"] == 1 & m[, "warned"] == 0), share_sd_na = mean(m[ok, "sd_na"] == 1),
        absorb_share_mean = mean(m[, "absorb_share"]), parameter = p, true_value = truth[[p]], n_used = sum(ok), rel_bias_median = median(r, na.rm = TRUE), rel_bias_q05 = quantile(r, 0.05, na.rm = TRUE), rel_bias_q95 = quantile(r, 0.95, na.rm = TRUE),
        share_at_zero_0.1pct = mean(m[ok, p] < 1e-3 * truth[[p]], na.rm = TRUE), share_at_zero_1pct = mean(m[ok, p] < 1e-2 * truth[[p]], na.rm = TRUE), share_at_zero_10pct = mean(m[ok, p] < 0.1 * truth[[p]], na.rm = TRUE),
        share_within_20pct = mean(abs(r) <= 0.2, na.rm = TRUE))
    }
  }
}
out <- do.call(rbind, rows); rownames(out) <- NULL
write.csv(out, file.path(script_dir, "results/summary.csv"), row.names = FALSE)
writeLines(c(capture.output(sessionInfo()), paste("nlme", as.character(packageVersion("nlme")))), file.path(script_dir, "results/session-info.txt"))
options(width = 230); o <- out[out$parameter %in% c("CL", "ka") & out$n_subjects == 40 & out$subset == "returned", c(1, 2, 4, 5, 6, 9, 10, 11, 14, 17)]; o[7:10] <- round(o[7:10], 3); print(o, row.names = FALSE)
