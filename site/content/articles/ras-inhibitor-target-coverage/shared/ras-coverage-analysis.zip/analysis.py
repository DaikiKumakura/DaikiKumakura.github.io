from pathlib import Path
import json,platform
import numpy as np,pandas as pd,scipy,matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from scipy.integrate import solve_ivp
from scipy.stats import qmc,norm,rankdata,pearsonr
from scipy.optimize import minimize,brentq
from scipy.special import expit
from models import profile,metrics,persistent,tat
ROOT=Path(__file__).resolve().parent
plt.rcParams.update({'font.size':10,'axes.spines.top':False,'axes.spines.right':False,'figure.dpi':140})
def save(fig,name):
    fig.tight_layout();fig.savefig(ROOT/'figures'/f'{name}.png',bbox_inches='tight');fig.savefig(ROOT/'figures'/f'{name}.svg',bbox_inches='tight');plt.close(fig)
def csv(df,name):df.to_csv(ROOT/'results'/f'{name}.csv',index=False)

def anchor():
    p=json.loads((ROOT/'data/published-parameters.json').read_text());df=pd.read_csv(ROOT/'data/published-group-means.csv');rows=[];curves=[]
    fig,axes=plt.subplots(2,3,figsize=(12,6.6))
    selected=['25mg/kg_study8','25mg/kg_study8r']
    for group,g in df.groupby('group',sort=False):
        doses=g[g.dose_nmol_per_kg>0];times=doses.time_h.to_numpy();amounts=doses.dose_nmol_per_kg.to_numpy();k=p['cl']/p['v']
        def blood(t):
            d=np.maximum(t-times,0);return np.sum((t>=times)*amounts/p['v']*p['ka']/(p['ka']-k)*(np.exp(-k*d)-np.exp(-p['ka']*d)))
        end=g.time_h.max(); grid=np.linspace(0,end,int(end*8)+1)
        for variant,bpic in [('methods',1819),('table_literal',1.8187635)]:
            def rhs(t,y):
                c=blood(t);bp=5.5-5.2*c/(bpic+c)
                return [115*.011*c/bp-.1*y[0],100*p['kout']*(1-y[0]/(y[0]+p['ic50']))-p['kout']*y[1]]
            sol=solve_ivp(rhs,[0,end],[0,100],rtol=1e-8,atol=1e-8,max_step=.2,dense_output=True)
            assert sol.success
            for _,r in g.iterrows():
                ct,e=sol.sol(r.time_h)
                for endpoint,pred in [('blood_nM',blood(r.time_h)),('tumor_nM',ct),('dusp6_percent',e)]:
                    obs=r[endpoint]
                    if pd.notna(obs) and obs>0:rows.append(dict(group=group,variant=variant,time_h=r.time_h,endpoint=endpoint,observed=obs,predicted=pred,relative_error=(pred-obs)/obs))
            if group in selected:
                i=selected.index(group); offset=216 if group.endswith('8r') else 0;tt=grid[grid>=offset];yy=sol.sol(tt)
                for j,(yyj,endpoint) in enumerate([(np.array([blood(t) for t in tt]),'blood_nM'),(yy[0],'tumor_nM'),(yy[1],'dusp6_percent')]):
                    ax=axes[i,j];ax.plot(tt-offset,yyj,label='Methods equation' if variant=='methods' else 'Literal table',ls='-' if variant=='methods' else '--')
                    if variant=='methods':ax.scatter(g.time_h-offset,g[endpoint],color='black',s=22,label='Published means');ax.set_title(('Single dose' if i==0 else '10th daily dose')+' — '+['blood (nM)','tumor (nM)','DUSP6 (%)'][j]);ax.set_xlabel('Time since dose (h)');ax.set_yscale('log');ax.set_xlim(0,24)
                    curves.extend(dict(group=group,variant=variant,time_h=t,endpoint=endpoint,predicted=v) for t,v in zip(tt,yyj))
    axes[0,0].legend(fontsize=8);save(fig,'01-public-model');out=pd.DataFrame(rows);csv(out,'anchor-residuals');csv(pd.DataFrame(curves),'anchor-curves')
    summary=out.groupby(['variant','endpoint']).agg(n=('relative_error','size'),median_absolute_relative_error=('relative_error',lambda x:np.median(abs(x))),median_log_bias=('predicted',lambda x:0)).reset_index().drop(columns='median_log_bias');csv(summary,'anchor-summary')
    # Deliberately limited one-compartment label check, not a fitted PopPK reconstruction.
    kh=np.log(2)/9.2;cl=80.4;v=cl/kh;ka=brentq(lambda a:np.log(a/kh)/(a-kh)-2.2,.08,5)
    tt=np.linspace(0,24,2001);cc=300000/v*ka/(ka-kh)*(np.exp(-kh*tt)/(-np.expm1(-kh*24))-np.exp(-ka*tt)/(-np.expm1(-ka*24)))
    csv(pd.DataFrame([dict(endpoint='AUC ng*h/mL',label=3760,approximation=300000/cl),dict(endpoint='Cmax ng/mL',label=365,approximation=cc.max())]),'human-approximation')

def virtual():
    rows=[];pairs=[]
    for half in [2,4,8,12,24]:
        for mechanism in ['reversible','covalent','indirect']:
            for freq in [1,2,3]:
                row,cov=metrics(half=half,freq=freq,mechanism=mechanism);rows.append(row)
                if freq==1:base=(cov>=.9).astype(int)
                else:
                    d=(cov>=.9).astype(int)-base;pairs.append(dict(half=half,mechanism=mechanism,freq=freq,delta_ptc90=d.mean(),paired_mcse=d.std(ddof=1)/np.sqrt(len(d))))
    csv(pd.DataFrame(rows),'reference');csv(pd.DataFrame(pairs),'paired')
    fig,axes=plt.subplots(1,3,figsize=(12,3.9))
    rr=pd.DataFrame(rows)
    for ax,mech in zip(axes,['reversible','covalent','indirect']):
        for f in [1,2,3]:
            s=rr[(rr.mechanism==mech)&(rr.freq==f)];ax.plot(s.half,s.ptc90*100,'o-',label=['QD','BID','TID'][f-1])
        ax.set(title=mech,xlabel='Plasma half-life (h)',ylabel='PTC90 (%)',ylim=(0,100));ax.legend()
    save(fig,'02-mechanism')
    # Grid uses 2,000 paired subjects; probabilities are simulation estimates.
    hs=np.geomspace(2,24,14);rs=np.geomspace(.25,8,18);phase=[]
    for h in hs:
        for r in rs:
            for f in [1,2]:
                row,_=metrics(half=h,ratio=r,freq=f,n=2000);phase.append(row)
    ph=pd.DataFrame(phase);csv(ph,'phase');fig,axes=plt.subplots(1,3,figsize=(12,4))
    q=ph[ph.freq==1].ptc90.to_numpy().reshape(len(hs),len(rs)).T;b=ph[ph.freq==2].ptc90.to_numpy().reshape(len(hs),len(rs)).T
    for ax,m,title in zip(axes,[q,b,b-q],['QD PTC90','BID PTC90','BID − QD PTC90']):
        im=ax.pcolormesh(hs,rs,m*100,shading='nearest',vmin=0,vmax=100 if title[0]!='B' or '−' not in title else 60,cmap='viridis');ax.set(xscale='log',yscale='log',xlabel='Half-life (h)',ylabel='Reference mean / threshold',title=title);ax.set_xticks([2,4,8,12,24],labels=['2','4','8','12','24']);ax.set_yticks([.25,.5,1,2,4,8],labels=['0.25','0.5','1','2','4','8']);ax.minorticks_off();fig.colorbar(im,ax=ax,label='%' if '−' not in title else 'percentage points')
    save(fig,'03-phase')
    checks=[]
    for cv in [.2,.4,.6]:
        for kp in [.5,1,2]:
            for eq in [None,2,8]:
                for f in [1,2]:
                    row,_=metrics(cv=cv,kp=kp,eqhalf=eq,freq=f);row.update(kp=kp,eqhalf=eq or 0);checks.append(row)
    for turn in [6,24,72]:
        for f in [1,2]:
            row,_=metrics(mechanism='covalent',turnover=turn,freq=f);row.update(kp=1,eqhalf=0);checks.append(row)
    csv(pd.DataFrame(checks),'mechanism-sensitivity')
    # Pareto comparison includes administration burden, no toxicity conversion.
    pareto=[]
    for ratio in [.75,1.5,3,4.5,6,9,12]:
        for f in [1,2,3]:pareto.append(metrics(ratio=ratio,freq=f)[0])
    pa=pd.DataFrame(pareto);obj=np.column_stack([-pa.ptc90,pa.auc,pa.peak,pa.freq]);pa['nondominated']=[not any(np.all(v<=u+1e-10) and np.any(v<u-1e-10) for v in obj) for u in obj];csv(pa,'pareto')
    fig,ax=plt.subplots(figsize=(7,4))
    for f in [1,2,3]:
        s=pa[pa.freq==f];ax.plot(s.auc,s.ptc90*100,'o-',label=['QD','BID','TID'][f-1])
    ax.set(xlabel='Normalized daily systemic AUC',ylabel='PTC90 (%)',title='Coverage and exposure cost (hypothetical)');ax.legend();save(fig,'04-pareto')
    return rr

def sensitivity():
    names=['half','clscale','fscale','kp','potency','ka','turnover']; bounds=np.array([[2,24],[.5,2],[.5,1.5],[.25,4],[.5,2],[.5,2],[6,72]])
    xx=qmc.LatinHypercube(7,seed=431).random(400);xx=np.exp(np.log(bounds[:,0])+xx*np.log(bounds[:,1]/bounds[:,0]));rows=[]
    for x in xx:
        h,cl,f,kp,pot,ka,turn=x;kw=dict(half=h,clscale=cl,fscale=f,kp=kp,potency=pot,ka=ka,turnover=turn,n=512)
        # Hold DAILY AMOUNT fixed while half-life changes: ratio=k_ref/k(h)*3.
        kw['ratio']=3*h/4
        for mech in ['reversible','covalent']:
            q=metrics(freq=1,mechanism=mech,**kw)[0];b=metrics(freq=2,mechanism=mech,**kw)[0]
            rows.append(dict(zip(names,x))|dict(mechanism=mech,qd_ptc90=q['ptc90'],bid_ptc90=b['ptc90'],delta=b['ptc90']-q['ptc90']))
    df=pd.DataFrame(rows);csv(df,'global-design');out=[]
    for mech,g in df.groupby('mechanism'):
        ranks=np.array([rankdata(g[col]) for col in names]).T
        for endpoint in ['qd_ptc90','delta']:
            yr=rankdata(g[endpoint])
            for i,name in enumerate(names):
                z=np.column_stack([np.ones(len(g)),np.delete(ranks,i,axis=1)]);xr=ranks[:,i]-z@np.linalg.lstsq(z,ranks[:,i],rcond=None)[0];y=yr-z@np.linalg.lstsq(z,yr,rcond=None)[0]
                out.append(dict(mechanism=mech,endpoint=endpoint,parameter=name,prcc=pearsonr(xr,y).statistic))
    out=pd.DataFrame(out);csv(out,'prcc');fig,axes=plt.subplots(1,2,figsize=(10,4))
    for ax,mech in zip(axes,['reversible','covalent']):
        s=out[(out.mechanism==mech)&(out.endpoint=='delta')];ax.barh(s.parameter,s.prcc);ax.set(xlim=(-1,1),xlabel='Partial rank correlation',title=mech+' BID − QD')
    save(fig,'05-sensitivity')

def stress():
    half=4;k=np.log(2)/half;ka=1;t=np.linspace(-24,72,961);curves=[];fig,axes=plt.subplots(1,2,figsize=(11,4))
    for ax,f in zip(axes,[1,2]):
        tau=24/f;doses=np.arange(-240,73,tau);D=3*k*tau
        for scenario in ['reference','missed dose','4 h delay','24 h interruption','48 h interruption']:
            schedule=doses.copy()
            if scenario=='missed dose':schedule=schedule[schedule!=0]
            elif scenario=='4 h delay':schedule[schedule==0]=4
            elif 'interruption' in scenario:schedule=schedule[(schedule<0)|(schedule>=int(scenario.split()[0]))]
            d=np.maximum(t[:,None]-schedule,0);c=np.sum((t[:,None]>=schedule)*D*ka/(ka-k)*(np.exp(-k*d)-np.exp(-ka*d)),axis=1)
            ax.plot(t,c,label=scenario);curves.extend(dict(freq=f,scenario=scenario,time_h=tt,c=cc) for tt,cc in zip(t,c))
        ax.axhline(1,color='black',ls=':');ax.set(xlabel='Time relative to perturbation (h)',ylabel='Concentration / assumed C90',title=['QD','BID'][f-1],ylim=(0,10))
    axes[1].legend(fontsize=8);save(fig,'06-interruptions');csv(pd.DataFrame(curves),'stress-curves')
    # Saturating absorption contrasts equal daily dose with unequal exposure.
    rows=[]
    for daily in np.geomspace(.25,8,21):
        for freq in [1,2,3]:
            each=daily/freq;relf=1/(1+each/2);rows.append(dict(daily=daily,freq=freq,relative_f=relf,auc_relative=daily*relf,elasticity=relf))
    df=pd.DataFrame(rows);csv(df,'saturation');fig,ax=plt.subplots(figsize=(7,4))
    for f in [1,2,3]:
        g=df[df.freq==f];ax.plot(g.daily,g.auc_relative,label=['QD','BID','TID'][f-1])
    ax.set(xlabel='Normalized daily amount',ylabel='Relative systemic exposure',title='Assumed saturating absorption: Dsat = 2 per dose');ax.legend();save(fig,'07-absorption')

def confounding():
    rng=np.random.default_rng(997);n=20000;z=rng.normal(size=n);x=.8*z+rng.normal(0,.6,n);y=rng.binomial(1,expit(-.5+.6*x-1.5*z));rows=[]
    for label,design in [('naive',np.column_stack([np.ones(n),x])),('severity adjusted',np.column_stack([np.ones(n),x,z]))]:
        def loss(b):p=design@b;return np.sum(np.logaddexp(0,p)-y*p)
        fit=minimize(loss,np.zeros(design.shape[1]),jac=lambda b:design.T@(expit(design@b)-y),method='BFGS',options={'gtol':1e-5})
        assert np.max(abs(design.T@(expit(design@fit.x)-y)))<1e-3
        rows.append(dict(model=label,exposure_log_odds=fit.x[1],generating_exposure_coefficient=.6))
    csv(pd.DataFrame(rows),'confounding-estimates');df=pd.DataFrame(dict(log_exposure=x,severity=z,response=y));df['bin']=pd.qcut(x,10,labels=False);g=df.groupby('bin').agg(log_exposure=('log_exposure','mean'),response=('response','mean'),severity=('severity','mean')).reset_index();csv(g,'confounding-bins');fig,ax=plt.subplots(figsize=(7,4));ax.plot(g.log_exposure,g.response,'o-',label='Marginal simulated observations');ax.plot(g.log_exposure,expit(-.5+.6*g.log_exposure),'--',label='Generating model at severity = 0');ax.set(xlabel='Synthetic log exposure',ylabel='Response probability',title='Confounding can reverse an exposure–response association');ax.legend();save(fig,'08-confounding')

def run():
    anchor();virtual();sensitivity();stress();confounding()
    versions=dict(python=platform.python_version(),numpy=np.__version__,pandas=pd.__version__,scipy=scipy.__version__,matplotlib=matplotlib.__version__)
    (ROOT/'results/runtime.json').write_text(json.dumps(versions,indent=2));print('Generated eight figures and result tables',versions)
if __name__=='__main__':run()
