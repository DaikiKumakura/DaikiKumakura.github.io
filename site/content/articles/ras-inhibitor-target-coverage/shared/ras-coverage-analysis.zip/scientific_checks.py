from pathlib import Path
import json,numpy as np,pandas as pd
from scipy.integrate import solve_ivp
from models import profile,metrics,tat,persistent,population
ROOT=Path(__file__).resolve().parent
def run():
    tests={};t,c,ct=profile(n=1,eqhalf=2,steps=960)
    cl,f=population(1);k=np.log(2)/4*cl[0];D=3*np.log(2)/4*24;kt=np.log(2)/2
    def rhs(t,y):return [-y[0],y[0]-k*y[1],kt*(y[1]-y[2])]
    y=np.zeros(3)
    for day in range(70):
        y[0]+=D*f[0];sol=solve_ivp(rhs,[0,24],y,rtol=1e-10,atol=1e-11,dense_output=True);y=sol.y[:,-1]
    numeric=sol.sol(t);err=max(np.max(abs(c[0]-numeric[1])),np.max(abs(ct[0]-numeric[2])));tests['independent_ode_max_abs_error']=float(err);assert err<1e-7
    aucs=[]
    for freq in [1,2,3]:
        tt,cc,_=profile(freq=freq,n=100,steps=1920);auc=np.trapezoid(cc,tt,axis=1)*freq;cl,f=population(100);theory=72*f/cl
        error=np.max(abs(auc/theory-1));assert error<2e-5;aucs.append(auc);tests['auc_relative_error_'+str(freq)]=float(error)
    assert np.max(abs(aucs[0]-aucs[1]))<.002
    xx=np.array([[0,2],[2,0],[2,2],[0,0]],float);a,d=tat(xx);assert np.allclose(a,[.5,.5,1,0]) and np.allclose(d,[.25,.25,0,1]);tests['exact_crossing_passed']=True
    refinements=[]
    for mech in ['reversible','covalent','indirect']:
        coarse,x=metrics(mechanism=mech);fine,y=metrics(mechanism=mech,steps=960)
        delta=abs(coarse['ptc90']-fine['ptc90']);assert delta<.003
        refinements.append(dict(mechanism=mech,coarse_ptc90=coarse['ptc90'],fine_ptc90=fine['ptc90'],max_tat_abs_error=np.max(abs(x-y))))
    pd.DataFrame(refinements).to_csv(ROOT/'results/refinement.csv',index=False)
    # Exact constant-exposure equilibrium confirms potency calibration.
    t=np.linspace(0,24,241);te=persistent(np.ones((1,241)),t);assert np.max(abs(te-.9))<1e-10;tests['covalent_constant_c90_equilibrium']=float(te[0,0])
    rr=pd.read_csv(ROOT/'results/reference.csv');assert rr.ptc90.between(0,1).all() and rr.mean_tat.between(0,1).all()
    phase=pd.read_csv(ROOT/'results/phase.csv');merged=phase[phase.freq==1].merge(phase[phase.freq==2],on=['half','ratio'],suffixes=('_qd','_bid'));delta=merged.ptc90_bid-merged.ptc90_qd
    pd.DataFrame([dict(threshold_pp=q,grid_fraction_above=(delta>=q/100).mean()) for q in [5,10,20]]).to_csv(ROOT/'results/material-threshold.csv',index=False)
    # Monte Carlo and grid refinement at three boundary/reference points.
    rows=[]
    for half,ratio in [(4,3),(8,2),(12,1.5)]:
        for f in [1,2]:
            small,_=metrics(half=half,ratio=ratio,freq=f,n=2000);large,_=metrics(half=half,ratio=ratio,freq=f,n=10000,steps=960);rows.append(dict(half=half,ratio=ratio,freq=f,small_ptc90=small['ptc90'],large_ptc90=large['ptc90'],small_mcse=small['ptc90_mcse']))
    pd.DataFrame(rows).to_csv(ROOT/'results/grid-check.csv',index=False)
    report=dict(status='passed',checks=tests,qualification='Numerical checks only; source-model agreement and clinical transportability are separate.')
    (ROOT/'results/validation.json').write_text(json.dumps(report,indent=2));print(report);return report
if __name__=='__main__':run()
