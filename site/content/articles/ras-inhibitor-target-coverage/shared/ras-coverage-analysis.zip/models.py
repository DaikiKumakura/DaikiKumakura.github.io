"""Normalized hypothetical models; none of these parameters are clinical estimates."""
import numpy as np

def population(n=10000, cv=.4, seed=20261007):
    z=np.random.default_rng(seed).standard_normal((n,2))
    return np.exp(z[:,0]*np.sqrt(np.log1p(cv*cv))), np.exp(z[:,1]*np.sqrt(np.log1p(.3**2)))

def profile(half=4, ratio=3, freq=1, n=10000, cv=.4, kp=1, eqhalf=None, steps=240, clscale=1, fscale=1, potency=1, ka=1):
    cl,f=population(n,cv); k0=np.log(2)/half; k=k0*cl*clscale
    tau=24/freq; t=np.linspace(0,tau,steps+1)[None,:]
    k=k[:,None]; dose=ratio*k0*tau; factor=dose*ka*f[:,None]*fscale/(ka-k)
    def e(rate):return np.exp(-rate*t)/(-np.expm1(-rate*tau))
    c=factor*(e(k)-e(ka))
    if eqhalf is None:ct=c*kp/potency
    else:
        kt=np.log(2)/eqhalf
        def conv(rate):
            delta=kt-rate
            if np.isscalar(delta):
                if abs(delta)<1e-8:return t*e(rate)+tau*np.exp(-rate*(t+tau))/(-np.expm1(-rate*tau))**2
                return (e(rate)-e(kt))/delta
            near=abs(delta)<1e-8; safe=np.where(near,1,delta)
            return np.where(near,t*e(rate)+tau*np.exp(-rate*(t+tau))/(-np.expm1(-rate*tau))**2,(e(rate)-e(kt))/safe)
        ct=kp*factor*kt*(conv(k)-conv(ka))/potency
    return t[0],c,ct

def persistent(c,t,turnover=24,kinact=None,ki=1,indirect=False):
    """Exact affine steps for midpoint-frozen input; periodic boundary solution."""
    rate=np.log(2)/turnover; dt=t[1]-t[0]; mid=(c[:,:-1]+c[:,1:])/2
    if indirect:
        a=np.full_like(mid,np.exp(-rate*dt)); b=(1-mid/(1/9+mid))*(1-a)
    else:
        if kinact is None:kinact=18*np.log(2)/24 # C=1 gives TE=.9 at reference turnover=24 h
        total=rate+kinact*mid/(ki+mid); a=np.exp(-total*dt); b=rate/total*(-np.expm1(-total*dt))
    acc=np.zeros(len(c)); prod=np.ones(len(c))
    for j in range(len(t)-1):acc=a[:,j]*acc+b[:,j]; prod*=a[:,j]
    u=acc/(1-prod); out=[u.copy()]
    for j in range(len(t)-1):u=a[:,j]*u+b[:,j]; out.append(u.copy())
    return 1-np.array(out).T

def tat(x):
    a=x[:,:-1]; b=x[:,1:]; da=1-a; db=1-b
    both=(a>=1)&(b>=1); rise=(a<1)&(b>=1); fall=(a>=1)&(b<1)
    cross=np.divide(1-a,b-a,out=np.zeros_like(a),where=abs(b-a)>1e-14)
    frac=both.astype(float)+rise*(1-cross)+fall*cross
    deficit=np.where((a<1)&(b<1),(da+db)/2,0)+np.where(rise,da*cross/2,0)+np.where(fall,db*(1-cross)/2,0)
    return frac.mean(axis=1),deficit.mean(axis=1)

def metrics(half=4,ratio=3,freq=1,n=10000,cv=.4,mechanism='reversible',turnover=24,steps=240,**kwargs):
    t,c,ct=profile(half,ratio,freq,n,cv,steps=steps,**kwargs)
    te=ct/(1/9+ct) if mechanism=='reversible' else persistent(ct,t,turnover,indirect=mechanism=='indirect')
    coverage,deficit=tat(ct if mechanism=='reversible' else te/.9)
    row=dict(half=half,ratio=ratio,freq=freq,cv=cv,mechanism=mechanism,turnover=turnover,n=n,
        mean_tat=coverage.mean(),deficit=deficit.mean(),auc=np.trapezoid(c,t,axis=1).mean()*freq,
        peak=np.max(c,axis=1).mean(),trough=np.min(ct,axis=1).mean())
    for q in [.8,.9,.95]:
        p=(coverage>=q).mean(); name='ptc'+str(int(q*100));row[name]=p;row[name+'_mcse']=np.sqrt(p*(1-p)/n)
    return row,coverage
