"""Hypothetical nonstationary-clearance stress test, not a clinical drug model."""
from pathlib import Path
import numpy as np,pandas as pd
from scipy.integrate import solve_ivp
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from analysis import save,csv
def run():
    rows=[];fig,axes=plt.subplots(1,2,figsize=(11,4));k=np.log(2)/4
    for ax,freq in zip(axes,[1,2]):
        tau=24/freq;D=3*k*tau
        for changing in [False,True]:
            y=np.zeros(2)
            for t0 in np.arange(0,24*14,tau):
                y[0]+=D
                def rhs(t,y):
                    kt=k*(.5+.5*np.exp(-np.log(2)*t/(3.5*24))) if changing else k
                    return [-y[0],y[0]-kt*y[1]]
                tt=np.linspace(t0,t0+tau,121);s=solve_ivp(rhs,[t0,t0+tau],y,t_eval=tt,rtol=1e-9,atol=1e-10);y=s.y[:,-1]
                rows.extend(dict(freq=freq,changing=changing,time_h=t,c=c) for t,c in zip(tt,s.y[1]))
            df=pd.DataFrame([r for r in rows if r['freq']==freq and r['changing']==changing]);ax.plot(df.time_h/24,df.c,label='CL decreases to 50%' if changing else 'constant CL')
        ax.set(xlabel='Day',ylabel='Concentration / C90',title=['QD','BID'][freq-1]);ax.legend(fontsize=8)
    save(fig,'09-changing-clearance');csv(pd.DataFrame(rows),'changing-clearance')
if __name__=='__main__':run()
