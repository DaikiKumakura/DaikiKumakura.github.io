n=137
primary, metastasis=27,54
tables=[]
# a is the number of pairs negative in both sampled sites.
for a in range(max(0,primary+metastasis-n),min(primary,metastasis)+1):
    b,c,d=primary-a,metastasis-a,n-primary-metastasis+a
    assert min(a,b,c,d)>=0
    tables.append((a,b,c,d))
for a,b,c,d in (tables[0],tables[-1]):
    print((a,b,c,d), f"discordant={b+c}/{n}; metastatic-negative among primary-positive={c}/{n-primary}")
assert all(c-b==27 for _,b,c,_ in tables)
