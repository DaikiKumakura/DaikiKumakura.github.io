"""Original figures from the article's descriptive score audit."""
import csv
from pathlib import Path
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

HERE = Path(__file__).resolve().parent
OUT = HERE / 'figures'
OUT.mkdir(exist_ok=True)
with (HERE / 'results/drug-comparisons.csv').open(encoding='utf-8', newline='') as f:
    rows = sorted(csv.DictReader(f), key=lambda r: float(r['recomputed_mean_difference']))
fig, ax = plt.subplots(figsize=(9, 6.4))
for i, row in enumerate(rows):
    ax.plot([float(row['evaluation_difference_min']), float(row['evaluation_difference_max'])], [i, i], color='#a6bcc4', lw=3)
    ax.scatter(float(row['recomputed_mean_difference']), i, color='#166277', s=45, zorder=3)
ax.axvline(0, color='#8a5733', lw=1)
ax.set_yticks(range(len(rows)), [r['drug'] for r in rows])
ax.set_xlabel('MAP minus comparator: top-50 DE Pearson delta correlation')
ax.grid(axis='x', alpha=.2)
fig.text(.5, .015, 'Dot: mean of five rounded evaluations. Line: observed min-max, not a confidence interval.\nComparator per drug selected by published All mean; fixed test set.', ha='center', fontsize=9)
fig.tight_layout(rect=(0, .07, 1, 1))
fig.savefig(OUT / '01-drug-advantages.png', dpi=180)
plt.close(fig)
with (HERE / 'results/knowledge-stages.csv').open(encoding='utf-8', newline='') as f:
    stages = list(csv.DictReader(f))
fig, ax = plt.subplots(figsize=(8, 4.6))
names = ['Random encoders', '+ MoleculeSTM', '+ PrimeKG', '+ MAP-KG']
values = [float(r['reported_mean']) for r in stages]
ax.bar(names, values, color=['#a6bcc4', '#507c8b', '#316c7e', '#166277'], width=.62)
for i, value in enumerate(values):
    ax.text(i, value + .018, f'{value:.3f}', ha='center')
ax.set(ylabel='Top-50 DE Pearson delta correlation (unprofiled drugs)', ylim=(0, 1))
ax.grid(axis='y', alpha=.2)
ax.set_axisbelow(True)
fig.text(.5, .025, 'Reported Fig_5a aggregates. Stages change pretraining and information together; not causal attribution.', ha='center', fontsize=8.5)
fig.tight_layout(rect=(0, .07, 1, 1))
fig.savefig(OUT / '02-knowledge-stages.png', dpi=180)
plt.close(fig)
