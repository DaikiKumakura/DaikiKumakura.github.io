"""Recalculate descriptive comparisons of published MAP evaluation scores."""
import csv
import json
import math
import statistics
from pathlib import Path

HERE = Path(__file__).resolve().parent
METHODS = {'MAP', 'CRISP', 'ChemCPA', 'PRnet', 'trainMean', 'XPert'}


def load_scores(filename, key_fields):
    scores = {}
    with (HERE / filename).open(encoding='utf-8', newline='') as f:
        for row in csv.DictReader(f):
            key = tuple(row[k] for k in key_fields)
            if key in scores:
                raise ValueError(f'Duplicate score: {key}')
            score = float(row['correlation'])
            if not math.isfinite(score) or not -1 <= score <= 1:
                raise ValueError(f'Invalid correlation: {key}')
            scores[key] = score
    return scores


def write_csv(path, rows):
    with path.open('w', encoding='utf-8', newline='') as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0]))
        w.writeheader()
        w.writerows(rows)


def main():
    scores = load_scores('drug-evaluations.csv', ['evaluation', 'drug', 'method'])
    drugs = sorted({k[1] for k in scores})
    expected = {(e, d, m) for e in ['All', '1', '2', '3', '4', '5'] for d in drugs for m in METHODS}
    if len(drugs) != 16 or set(scores) != expected:
        raise ValueError('Incomplete 16-drug, six-method, six-block data')
    audit = []
    for drug in drugs:
        for method in sorted(METHODS):
            recomputed = statistics.mean(scores[str(e), drug, method] for e in range(1, 6))
            difference = scores['All', drug, method] - recomputed
            audit.append({'drug': drug, 'method': method, 'reported_mean': scores['All', drug, method],
                          'recomputed_mean': recomputed, 'difference': difference,
                          'exceeds_rounding_tolerance_0_0011': abs(difference) > 0.0011})
    discrepancies = [abs(r['difference']) for r in audit]
    comparisons = []
    for drug in drugs:
        baseline = max(sorted(METHODS - {'MAP'}), key=lambda m: scores['All', drug, m])
        differences = [scores[str(e), drug, 'MAP'] - scores[str(e), drug, baseline] for e in range(1, 6)]
        comparisons.append({'drug': drug, 'map_reported_mean': scores['All', drug, 'MAP'],
                            'map_recomputed_mean': statistics.mean(scores[str(e), drug, 'MAP'] for e in range(1, 6)),
                            'best_baseline_by_reported_mean': baseline,
                            'baseline_reported_mean': scores['All', drug, baseline],
                            'mean_difference': scores['All', drug, 'MAP'] - scores['All', drug, baseline],
                            'recomputed_mean_difference': statistics.mean(differences),
                            'evaluation_difference_min': min(differences),
                            'evaluation_difference_max': max(differences),
                            'positive_evaluations': sum(x > 0 for x in differences),
                            'evaluations': len(differences)})
    knowledge = load_scores('knowledge-evaluations.csv', ['evaluation', 'condition'])
    order = ['no knowledge', '+ MoleculeSTM', '+ PrimeKG entities', '+ MAP-KG entities']
    if set(knowledge) != {(e, c) for e in ['All', '1', '2', '3', '4', '5'] for c in order}:
        raise ValueError('Incomplete knowledge data')
    knowledge_discrepancies = [abs(knowledge['All', c] - statistics.mean(knowledge[str(e), c] for e in range(1, 6))) for c in order]
    if max(knowledge_discrepancies) > 0.0011:
        raise ValueError('Knowledge summary and rounded evaluations disagree')
    stages = [{'condition': c, 'reported_mean': knowledge['All', c],
               'difference_from_previous': '' if i == 0 else knowledge['All', c] - knowledge['All', order[i-1]]}
              for i, c in enumerate(order)]
    result = {'drugs': len(drugs), 'methods': len(METHODS), 'evaluations_per_drug': 5,
              'mean_advantage_positive': sum(r['mean_difference'] > 0 for r in comparisons),
              'positive_in_all_five_evaluations': sum(r['positive_evaluations'] == 5 for r in comparisons),
              'recomputed_mean_advantage_positive': sum(r['recomputed_mean_difference'] > 0 for r in comparisons),
              'mean_difference_min': min(r['mean_difference'] for r in comparisons),
              'mean_difference_median': statistics.median(r['mean_difference'] for r in comparisons),
              'mean_difference_max': max(r['mean_difference'] for r in comparisons),
              'map_reported_min': min(r['map_reported_mean'] for r in comparisons),
              'map_reported_max': max(r['map_reported_mean'] for r in comparisons),
              'maximum_rounded_mean_discrepancy': max(discrepancies + knowledge_discrepancies),
              'aggregation_discrepancies_beyond_rounding': [r for r in audit if r['exceeds_rounding_tolerance_0_0011']],
              'scope': 'Descriptive audit on a fixed published test set; no new biological replicates, efficacy estimate, p-value, or confidence interval.'}
    out = HERE / 'results'
    out.mkdir(exist_ok=True)
    write_csv(out / 'drug-comparisons.csv', comparisons)
    write_csv(out / 'aggregation-audit.csv', audit)
    write_csv(out / 'knowledge-stages.csv', stages)
    (out / 'summary.json').write_text(json.dumps(result, indent=2) + '\n', encoding='utf-8')
    print(json.dumps(result, indent=2))


if __name__ == '__main__':
    main()
