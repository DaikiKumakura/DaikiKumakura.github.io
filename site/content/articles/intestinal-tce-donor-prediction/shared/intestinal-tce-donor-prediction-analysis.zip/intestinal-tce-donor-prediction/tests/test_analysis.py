"""Checks for donor grouping, source correspondence and held-out estimation."""
from pathlib import Path
import importlib.util
import unittest
import numpy as np

ROOT=Path(__file__).resolve().parents[1]
spec=importlib.util.spec_from_file_location("analysis_run",ROOT/"analysis/run.py")
run=importlib.util.module_from_spec(spec)
spec.loader.exec_module(run)


class AnalysisTests(unittest.TestCase):
    def test_source_audit_and_regions(self):
        rows,audit=run.import_data()
        self.assertEqual(len(rows),14)
        self.assertEqual(sum(r["region"]=="colon" for r in rows),7)
        self.assertEqual(sum(r["response_disagrees"] for r in audit),9)
        self.assertEqual(sum(r["target_disagrees"] for r in audit),13)

    def test_heldout_outcome_not_in_fit(self):
        x=np.column_stack([np.ones(6),np.arange(6)])
        y=np.array([1.,3.,2.,5.,5.,8.])
        original=run.loo(x,y)
        y[2]=9999
        changed=run.loo(x,y)
        self.assertAlmostEqual(original[2],changed[2])

    def test_mean_baseline_is_training_mean(self):
        y=np.array([1.,2.,5.])
        np.testing.assert_allclose(run.loo(np.ones((3,1)),y),[3.5,3.,1.5])

    def test_linear_recovery(self):
        x=np.column_stack([np.ones(6),np.arange(6)])
        y=2+3*np.arange(6)
        np.testing.assert_allclose(run.loo(x,y),y,atol=1e-10)


if __name__=="__main__":
    unittest.main()
