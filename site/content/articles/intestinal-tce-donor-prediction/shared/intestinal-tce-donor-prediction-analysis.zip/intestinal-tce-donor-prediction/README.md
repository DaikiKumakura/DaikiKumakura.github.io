# Intestinal CEA TCB response across organoid donors

Aggregate donor-level reanalysis of Harter et al., Nature Biomedical Engineering
8, 345–360 (2024), DOI:10.1038/s41551-023-01156-5. Original workbook and article
are CC BY 4.0. The new analysis transforms the source table, fits small regressions,
evaluates leave-one-organoid-donor-out predictions and makes new figures.

Run in an existing Python environment with the packages in requirements.txt:

```sh
python analysis/download_sources.py
python analysis/run.py
python -m unittest discover -s tests
```

No package installation is performed by the scripts. Raw sources are never
overwritten. The downloader verifies the archived workbook SHA-256.

The outcome is 48 h caspase-3/7 signal normalized to the non-targeting TCB,
not a dead-cell fraction. Concentration is fixed at 0.5 microgram/mL.
Fourteen organoid donors (seven small intestine, seven colon) are the modelling
units. Organoids counted for IHC are not treated as independent donor replicates.
PBMC-donor generalization is not evaluated. In-sample fit is distinct from
internal donor cross-validation; neither is an independent-cohort validation.

CEA(hi) donor pairing agrees across the source response and expression sheets.
EpCAM is excluded because donor-linked values disagree between source sheets;
see outputs/tables/excluded_epcam_audit.csv. No labels are silently corrected.
The CEA(lo) condition lacks its own explicit linked expression-response table
in Figure 5f and is outside this model comparison.

data/processed/donors.csv is regenerated from the workbook. outputs/summary.json
contains all manuscript numbers; output tables contain every held-out prediction,
all four model scores, donor-deletion sensitivity and donor-level bootstrap
coefficient intervals. The bootstrap is conditional on the linear model and the
small observed donor sample, not a clinical prediction interval.

The workbook, not individual donor medical data, is the public input. The model
does not estimate human toxicity incidence, a therapeutic window or clinical dose.
