"""Download the open source workbook; never overwrite an existing raw input."""
from pathlib import Path
import hashlib
import json
import urllib.request
import zipfile
from io import BytesIO

ROOT = Path(__file__).resolve().parents[1]
URL = "https://www.ebi.ac.uk/europepmc/webservices/rest/PMC11087266/supplementaryFiles"
NAME = "41551_2023_1156_MOESM8_ESM.xlsx"
EXPECTED = "8073a1fc230bddf15200a218e6524fc70b778a9c3b789267f4351266ec80b3e2"


def main() -> None:
    path = ROOT / "data/raw/figure5.xlsx"
    path.parent.mkdir(parents=True, exist_ok=True)
    if not path.exists():
        response = urllib.request.urlopen(URL, timeout=90)
        archive = zipfile.ZipFile(BytesIO(response.read()))
        name = next(n for n in archive.namelist() if n.endswith(NAME))
        payload = archive.read(name)
        assert hashlib.sha256(payload).hexdigest() == EXPECTED
        with path.open("xb") as handle:
            handle.write(payload)
    assert hashlib.sha256(path.read_bytes()).hexdigest() == EXPECTED
    print(json.dumps({"source_file":str(path.relative_to(ROOT)), "sha256":EXPECTED}))


if __name__ == "__main__":
    main()
