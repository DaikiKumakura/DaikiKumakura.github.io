"""Reanalyse published donor-level CEA TCB responses without image digitization."""
from pathlib import Path
import csv
import hashlib
import json
import platform
import sys

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import openpyxl

ROOT = Path(__file__).resolve().parents[1]
SEED = 20261028
BOOTSTRAPS = 2000
SOURCE = "https://www.nature.com/articles/s41551-023-01156-5#Sec30"
MODELS = ("mean", "region", "CEA", "CEA+region")


def design(x: np.ndarray, region: np.ndarray, model: str) -> np.ndarray:
    columns = [np.ones(len(x))]
    if "CEA" in model:
        columns.append(x)
    if "region" in model:
        columns.append(region)
    return np.column_stack(columns)


def fit_predict(x: np.ndarray, y: np.ndarray, test: np.ndarray) -> np.ndarray:
    return test @ np.linalg.lstsq(x, y, rcond=None)[0]


def loo(x: np.ndarray, y: np.ndarray) -> np.ndarray:
    return np.array([fit_predict(np.delete(x, i, 0), np.delete(y, i), x[i:i+1])[0]
                     for i in range(len(y))])


def write_csv(path: Path, rows: list[dict]) -> None:
    with path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def import_data() -> tuple[list[dict], list[dict]]:
    book = openpyxl.load_workbook(ROOT / "data/raw/figure5.xlsx", data_only=True)
    f = book["Fig5_tab_f"]
    cea_d = book["Fig5_tab_d_CEA"]
    means = {}
    for col in range(1, 29, 2):
        donor = int(cea_d.cell(2, col).value.split()[-1])
        values = [cea_d.cell(row, col).value for row in range(3, cea_d.max_row + 1)
                  if isinstance(cea_d.cell(row, col).value, (int, float))]
        means[donor] = (float(np.mean(values)), len(values))
    # Figure 5e gives seven regional means in its two labelled columns.
    e = book["Fig5_tab_e"]
    regional = {name: [float(e.cell(row, col).value) for row in range(3, 10)]
                for name, col in [("small_intestine", 1), ("colon", 2)]}
    b = book["Fig5_tab_b"]
    b_donors = {int(b.cell(1, col).value.split()[-1]): col for col in range(2, 30, 2)}
    rows = []
    for row in range(20, 34):
        donor, rounded_cea, response = [f.cell(row, col).value for col in (1, 2, 3)]
        cea, count = means[int(donor)]
        assert abs(cea - rounded_cea) <= 0.006
        assert abs(float(response) - b.cell(7, b_donors[int(donor)]).value) < 1e-8
        matches = [name for name, values in regional.items()
                   if any(abs(rounded_cea - value) < 0.006 for value in values)]
        assert len(matches) == 1
        rows.append(dict(donor=int(donor), region=matches[0],
                         cea_positive_area_percent=cea, ihc_organoids=count,
                         caspase_fold_nt_48h=float(response),
                         source_response_cell=f"Fig5_tab_f!C{row}"))
    assert len(rows) == 14 and len({r["donor"] for r in rows}) == 14
    assert sum(r["region"] == "colon" for r in rows) == 7
    # Audit rather than silently repair conflicting EpCAM source labels.
    ed = book["Fig5_tab_d_EpCAM"]
    emean = {int(ed.cell(2, col).value.split()[-1]):
             np.mean([ed.cell(r, col).value for r in range(3, ed.max_row+1)
                      if isinstance(ed.cell(r, col).value, (int, float))])
             for col in range(1, 29, 2)}
    audit = []
    for row in range(3, 17):
        donor, target, response = [f.cell(row, col).value for col in (1, 2, 3)]
        audit.append(dict(donor=int(donor),
            response_f=float(response), response_b=float(b.cell(4, b_donors[int(donor)]).value),
            target_f=float(target), target_d=float(emean[int(donor)]),
            response_disagrees=abs(float(response)-b.cell(4, b_donors[int(donor)]).value)>1e-6,
            target_disagrees=abs(float(target)-emean[int(donor)])>0.011))
    return rows, audit


def main() -> None:
    processed = ROOT / "data/processed"
    tables = ROOT / "outputs/tables"
    figures = ROOT / "outputs/figures"
    for path in (processed, tables, figures):
        path.mkdir(parents=True, exist_ok=True)
    rows, audit = import_data()
    write_csv(processed / "donors.csv", rows)
    write_csv(tables / "excluded_epcam_audit.csv", audit)
    x = np.array([r["cea_positive_area_percent"] for r in rows])
    y = np.array([r["caspase_fold_nt_48h"] for r in rows])
    region = np.array([r["region"] == "colon" for r in rows], dtype=float)
    prediction_rows = []
    metrics = []
    predictions = {}
    for name in MODELS:
        X = design(x, region, name)
        pred = loo(X, y)
        predictions[name] = pred
        residual = y-pred
        full = fit_predict(X, y, X)
        metrics.append(dict(model=name, parameters=X.shape[1], donors=len(y),
            loo_rmse=float(np.sqrt(np.mean(residual**2))),
            loo_mae=float(np.mean(abs(residual))),
            loo_max_absolute_error=float(max(abs(residual))),
            training_rmse=float(np.sqrt(np.mean((full-y)**2)))))
        prediction_rows.extend(dict(donor=rows[i]["donor"],model=name,
            observed=float(y[i]), predicted=float(pred[i]), error=float(residual[i]))
            for i in range(len(y)))
    write_csv(tables / "model_metrics.csv", metrics)
    write_csv(tables / "heldout_predictions.csv", prediction_rows)
    # Re-run the complete cross-validation after deleting one donor; this is
    # influence sensitivity, not fourteen independent external validations.
    influence = []
    for i in range(len(y)):
        keep = np.arange(len(y)) != i
        for name in MODELS:
            p = loo(design(x[keep],region[keep],name), y[keep])
            influence.append(dict(deleted_donor=rows[i]["donor"], model=name,
                rmse=float(np.sqrt(np.mean((y[keep]-p)**2)))))
    write_csv(tables / "donor_deletion_sensitivity.csv", influence)
    # Percentile case bootstrap at the donor level. Never resample stained
    # organoids as though they were independent donor observations.
    X = design(x, region, "CEA")
    coef = np.linalg.lstsq(X,y,rcond=None)[0]
    rng = np.random.default_rng(SEED)
    draws = []
    for _ in range(BOOTSTRAPS):
        ix = rng.integers(0,len(y),len(y))
        if np.linalg.matrix_rank(X[ix]) == X.shape[1]:
            draws.append(np.linalg.lstsq(X[ix],y[ix],rcond=None)[0])
    intervals = np.quantile(draws,[0.025,0.975],axis=0)
    coefficients = [dict(parameter=p,estimate=float(coef[i]),
        bootstrap_lower=float(intervals[0,i]),bootstrap_upper=float(intervals[1,i]))
        for i,p in enumerate(["intercept", "slope_per_percentage_point"])]
    write_csv(tables / "cea_coefficients.csv", coefficients)
    summary = dict(donors=len(y), small_intestine=7,colon=7,
        included_donor_response_records=14, excluded_epcam_response_records=14,
        epcam_response_label_disagreements=sum(r["response_disagrees"] for r in audit),
        epcam_target_label_disagreements=int(sum(r["target_disagrees"] for r in audit)),
        cea_min=float(min(x)), cea_max=float(max(x)),response_min=float(min(y)),
        response_max=float(max(y)),seed=SEED,bootstrap_draws=len(draws),
        metrics=metrics,coefficients=coefficients,
        rmse_reduction_vs_mean=1-metrics[2]["loo_rmse"]/metrics[0]["loo_rmse"],
        deletion_cea_better_mean=int(sum(
            next(r["rmse"] for r in influence if r["deleted_donor"]==d["donor"] and r["model"]=="CEA") <
            next(r["rmse"] for r in influence if r["deleted_donor"]==d["donor"] and r["model"]=="mean")
            for d in rows)),
        python=platform.python_version(), numpy=np.__version__,
        source_sha256=hashlib.sha256((ROOT/"data/raw/figure5.xlsx").read_bytes()).hexdigest())
    (ROOT/"outputs/summary.json").write_text(json.dumps(summary,indent=2),encoding="utf-8")
    plt.rcParams.update({"font.size":10,"axes.spines.top":False,"axes.spines.right":False})
    colors = np.where(region==1,"#D55E00","#0072B2")
    fig, ax = plt.subplots(figsize=(6.4,4.2),layout="constrained")
    for val,label,col in [(0,"Small intestine (n=7)","#0072B2"),(1,"Colon (n=7)","#D55E00")]:
        sel=region==val
        ax.scatter(x[sel],y[sel],label=label,color=col,s=45)
    grid=np.linspace(min(x),max(x),200)
    ax.plot(grid,coef[0]+coef[1]*grid,color="black",lw=1,label="All-donor linear fit")
    for i,r in enumerate(rows):
        ax.annotate(str(r["donor"]),(x[i],y[i]),xytext=(4,3),textcoords="offset points",fontsize=8)
    ax.set(xlabel="CEA-positive IHC area (%)",ylabel="48 h caspase signal / NT control",title="CEA(hi) TCB: 0.5 microgram/mL; 14 organoid donors")
    ax.legend(fontsize=8)
    fig.savefig(figures/"cea-response.svg")
    fig.savefig(figures/"cea-response.png",dpi=180)
    plt.close(fig)
    fig,axs=plt.subplots(1,2,figsize=(9.2,4),layout="constrained")
    for name,col in [("mean","#999999"),("CEA","#0072B2")]:
        axs[0].scatter(y,predictions[name],label=name,color=col,s=38)
    lim=[0.9,3.1]
    axs[0].plot(lim,lim,"k--",lw=1)
    axs[0].set(xlim=lim,ylim=lim,xlabel="Observed normalized caspase",ylabel="Held-out donor prediction",title="Leave-one-organoid-donor-out")
    axs[0].legend()
    axs[1].bar([r["model"] for r in metrics],[r["loo_rmse"] for r in metrics],color=["#999999","#E69F00","#0072B2","#009E73"])
    axs[1].set(ylabel="Held-out RMSE (caspase fold units)",title="Four candidate small models")
    fig.savefig(figures/"heldout-prediction.svg")
    fig.savefig(figures/"heldout-prediction.png",dpi=180)
    plt.close(fig)
    fig,ax=plt.subplots(figsize=(6.4,4.1),layout="constrained")
    for j,name in enumerate(MODELS):
        vals=[r["rmse"] for r in influence if r["model"]==name]
        ax.scatter(np.full(14,j)+np.linspace(-.12,.12,14),vals,s=24,color=["#999999","#E69F00","#0072B2","#009E73"][j])
    ax.set(xticks=range(4),xticklabels=MODELS,ylabel="Nested donor-deletion RMSE",title="One donor removed before repeating cross-validation")
    fig.savefig(figures/"donor-sensitivity.svg")
    fig.savefig(figures/"donor-sensitivity.png",dpi=180)
    plt.close(fig)
    print(json.dumps(summary,ensure_ascii=False,indent=2))


if __name__ == "__main__":
    main()
