# Daraxonrasib dose fractionation

Public-data research and learning; not treatment or clinical dose instructions.
Run in an environment matching requirements.txt:
  python analysis/run_analysis.py
  python -m unittest discover -s analysis -p "test_model.py" -q
No download, account, or network required. Original source PDF is not included.

Source: FDA NDA220910 multidisciplinary review, 2026, Table59 PDF242,
Tables65-67 PDF260-261:
https://www.accessdata.fda.gov/drugsatfda_docs/nda/2026/220910Orig1s000MultidisciplineR.pdf
Whole-blood ng/mL, not plasma, unbound or tumor concentration.
Apparent CL/F53.8L/h,Vc/F516L,Q/F26.1L/h,Vp/F255L,ka.735/h,lag.305h.
Reference65years,70kg,PDAC,totalbilirubin8micromol/L,prior metastatictherapy.
Eta variance CL.139,Vc.168,ka.847; CL-Vc covariance.0949;
other covariances assumed0. 4096 paired conditional individuals, seed20261022.
No new patient-data NLME fit, representative covariate distribution, observation
error, full fixed-effect uncertainty or causal effect estimated.

Steady relativeF=1-.357. FirstcycleF(t)=1-.357*t/(5.90+t), or
1-.357*(1-2**(-t/5.90)), tdays, at each dose event. These finite-time functions
are assumptions; original exact F equation not verified from public review.
Lowdose ka effect1.49 interpreted through1+theta*indicator =>2.49fold.
Per-administration <=160mg branch main; daily-total alternative. QD source data
cannot establish how the branch behaves under BID. All BID regimens hypothetical.
No CYP mechanism, target occupancy threshold or efficacy preservation inferred.

Compare300QD,150BID,200QD,100BID,200+100mg12hapart. Steady daily AUC equality
at same amount is linear mass balance, not independent efficacy evidence.
Cmin is24h minimum with absorption-start cusps included; predose proxy separately.
Intervals5th-95th percentiles are conditional IIV, not confidence intervals.
Independent ODE, long-history, numerical quadrature and grid checks are tests
of implementation, not clinical predictive validation.

Table65 TEAEgrade>=3 slope.013/ng/mL*Cmin; Table66 TRAEgrade>=3
slope.00363/ng/mL*Cmax; Table67 anygradeTRAEleadingdosechange slope1.25*lnCavg.
Report same-person conditional odds ratios; intercept and fixed covariates cancel.
Absolute probabilities not computed: source covariate centering not established.
Different endpoints are not combined. QD associations projected to BID are not
causal clinical effects or risk ratios. Marginal coefficient-CI scenarios are
separate from IIV; no full coefficient covariance available.

Model conditional geometricmean Cmax~292.6 vs reported365ng/mL (about20%low),
AUC24ss~3580vs label totalAUC3760ng*h/mL. Label12.3 does not specify the latter
integration window or Cmax sampling occasion; not a matched endpoint validation.
Label: https://www.accessdata.fda.gov/drugsatfda_docs/nda/2026/220910Orig1s000Lbl.pdf
Reference covariates differ from source full population.
Discrepancy unresolved, no retuning; not a qualified absolute-exposure model.
Relative odds still depend on absolute concentration differences; cancellation of
intercepts does not resolve calibration uncertainty.
No valid efficacy E-R transport to BID established. Hypothesis-generating PK
comparison only. Fixed-effect RSE and covariate scenarios are not joint CIs.

Outputs:8CSV,3originalPNG,results.json,environment.json. Source SHA256 records
consulted snapshot; rerun does not download or independently reverify original.
Original code MIT; numerical source facts attributed to FDA review.
