"""Analytic oral two-compartment response, apparent mg/L/h parameters."""
import numpy as np

def parameters(cfg: dict, eta: np.ndarray | None = None, cov: dict | None = None,
               override: dict | None = None) -> dict:
    eta=np.zeros((1,3)) if eta is None else np.atleast_2d(eta)
    p={k:np.full(len(eta),v,dtype=float) for k,v in cfg['pk'].items()}
    for j,k in enumerate(['cl','vc','ka']):p[k]*=np.exp(eta[:,j])
    x=cfg['reference']| (cov or {});r=cfg['reference'];cc=cfg['covariates']
    p['cl']*=(x['age']/r['age'])**cc['age_cl']*(x['bilirubin']/r['bilirubin'])**cc['bilirubin_cl']
    p['vc']*=(x['weight']/r['weight'])**cc['weight_vc']
    if override:
        for k,v in override.items():p[k][:]=v
    return p

def response(p: dict, t: np.ndarray, ka_multiplier: float=1,
             period: float | None=None, integral: bool=False) -> np.ndarray:
    """Unit oral dose, F=1, including lag; periodic integral has arbitrary origin."""
    k10=p['cl']/p['vc'];k12=p['q']/p['vc'];k21=p['q']/p['vp']
    total=k10+k12+k21;disc=np.sqrt(total**2-4*k10*k21)
    alpha=(total+disc)/2;beta=(total-disc)/2
    weights=[(alpha-k21)/disc,(k21-beta)/disc]
    age=np.asarray(t)[None,:]-p['lag'][:,None];ka=p['ka'][:,None]*ka_multiplier
    if period is None:age=np.maximum(age,0);turns=0
    else:turns=np.floor(age/period);age=np.mod(age,period)
    def g(rate):
        if period is None:
            return -np.expm1(-rate*age)/rate if integral else np.exp(-rate*age)
        den=-np.expm1(-rate*period)
        return turns/rate-np.expm1(-rate*age)/(rate*den) if integral else np.exp(-rate*age)/den
    base=g(ka);out=np.zeros((len(p['cl']),age.shape[1]))
    for rate,w in zip([alpha,beta],weights):
        rate=rate[:,None];out+=w[:,None]*ka/(ka-rate)*(g(rate)-base)
    return out*1000/p['vc'][:,None]

def ka_factor(cfg: dict, dose: float, daily: float, branch: str) -> float:
    value=dose if branch=='per_dose' else daily
    return 1+cfg['covariates']['low_dose_ka_effect'] if value<=cfg['covariates']['low_dose_boundary_mg'] else 1.0

def f_time(cfg: dict, day: float, shape: str='emax') -> float:
    em=cfg['pk']['em'];half=cfg['pk']['et50_day']
    if shape=='emax':return 1-em*day/(half+day)
    if shape=='exponential':return 1-em*(1-2**(-day/half))
    raise ValueError(shape)

def profile(cfg: dict,p: dict,t: np.ndarray,reg: dict,branch: str='per_dose',
            steady: bool=True,shape: str='emax') -> np.ndarray:
    out=np.zeros((len(p['cl']),len(t)));daily=sum(reg['doses'])
    events=list(zip(reg['times'],reg['doses']))
    if not steady:events=[(day*24+at,d) for day in range(int(max(t)//24)+1) for at,d in events if day*24+at<=max(t)]
    for at,d in events:
        factor=ka_factor(cfg,d,daily,branch)
        f=1-cfg['pk']['em'] if steady else f_time(cfg,at/24,shape)
        out+=d*f*response(p,np.asarray(t)-at,factor,period=24 if steady else None)
    return out

def finite_auc(cfg: dict,p: dict,reg: dict,end: float,shape: str='emax',branch: str='per_dose') -> np.ndarray:
    out=np.zeros(len(p['cl']));daily=sum(reg['doses'])
    for day in range(int(end//24)+1):
        for at,d in zip(reg['times'],reg['doses']):
            when=day*24+at
            if when>end:continue
            out+=d*f_time(cfg,when/24,shape)*response(p,np.array([end-when]),ka_factor(cfg,d,daily,branch),integral=True)[:,0]
    return out

def metrics(cfg: dict,p: dict,reg: dict,branch: str='per_dose',step: float | None=None) -> dict:
    t=np.arange(0,24+1e-8,step or cfg['step_h'])
    # Absorption starts at these cusps; a uniform grid can miss the minimum.
    t=np.unique(np.r_[t,[(at+lag)%24 for at in reg['times'] for lag in np.unique(p['lag'])]])
    c=profile(cfg,p,t,reg,branch)
    pre=profile(cfg,p,np.array(reg['times'],dtype=float),reg,branch)
    auc=sum(reg['doses'])*(1-cfg['pk']['em'])*1000/p['cl']
    return dict(cmax=c.max(axis=1),cmin=c.min(axis=1),predose=pre.min(axis=1),auc24=auc,cavg=auc/24)

def odds(cfg: dict,alt: dict,ref: dict,slope: str='slope',min_key: str='cmin') -> dict:
    out={}
    for key,x in cfg['er'].items():
        m=min_key if x['metric']=='cmin' else x['metric'];b=x[slope]
        out[key]=(alt[m]/ref[m])**b if m=='cavg' else np.exp(np.clip(b*(alt[m]-ref[m]),-700,700))
    return out
