"""Public coefficient reuse, paired regimen PK and conditional relative odds."""
from pathlib import Path
import hashlib,json,platform
import numpy as np
import pandas as pd
import scipy
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from model import parameters,profile,metrics,finite_auc,odds

ROOT=Path(__file__).resolve().parents[1]
COLORS=['#0072B2','#D55E00','#009E73','#8a6996','#E69F00']

def quantiles(v: np.ndarray) -> dict:
    q=np.quantile(v,[.05,.5,.95]);return dict(p05=q[0],median=q[1],p95=q[2])

def main() -> None:
    cfg=json.loads((ROOT/'analysis/inputs.json').read_text());out=ROOT/'outputs';tab=out/'tables';figs=out/'figures'
    tab.mkdir(parents=True,exist_ok=True);figs.mkdir(exist_ok=True)
    plt.rcParams.update({'font.family':'DejaVu Sans','font.size':11,'axes.spines.top':False,'axes.spines.right':False,'savefig.dpi':160})
    rng=np.random.default_rng(cfg['seed']);omega=np.array(cfg['omega']);assert min(np.linalg.eigvalsh(omega))>0
    eta=rng.multivariate_normal(np.zeros(3),omega,size=cfg['n']);p=parameters(cfg,eta);typ=parameters(cfg)
    names=list(cfg['regimens']);allm={};rows=[];rat=[];orrows=[]
    for branch in ['per_dose','daily_dose']:
        allm[branch]={name:metrics(cfg,p,reg,branch) for name,reg in cfg['regimens'].items()};ref=allm[branch]['300QD']
        for name,reg in cfg['regimens'].items():
            m=allm[branch][name];tm=metrics(cfg,typ,reg,branch)
            assert all(np.isfinite(v).all() and (v>0).all() for v in m.values())
            for key,v in m.items():
                rows.append(dict(branch=branch,regimen=name,metric=key,typical=tm[key][0],geomean=np.exp(np.log(v).mean()),**quantiles(v)))
                rat.append(dict(branch=branch,regimen=name,metric=key,**quantiles(v/ref[key])))
            for slope in ['lower','slope','upper']:
                for key,v in odds(cfg,m,ref,slope).items():orrows.append(dict(branch=branch,regimen=name,endpoint=key,coefficient=slope,**quantiles(v)))
            # Separate source-Cmin proxy sensitivity, not additional clinical endpoints.
            v=odds(cfg,m,ref,min_key='predose')['g3_teae'];orrows.append(dict(branch=branch,regimen=name,endpoint='g3_teae_predose_proxy',coefficient='slope',**quantiles(v)))
    mm=pd.DataFrame(rows);rr=pd.DataFrame(rat);oo=pd.DataFrame(orrows)
    mm.to_csv(tab/'steady-metrics.csv',index=False);rr.to_csv(tab/'paired-ratios.csv',index=False);oo.to_csv(tab/'relative-odds.csv',index=False)
    grid=[]
    for branch in ['per_dose','daily_dose']:
        ref=allm[branch]['300QD']
        for first in [50,100,150,200,250]:
            reg=dict(times=[0,12],doses=[first,300-first]);m=metrics(cfg,p,reg,branch)
            grid.append(dict(branch=branch,first_mg=first,second_mg=300-first,peak_ratio_median=np.median(m['cmax']/ref['cmax']),minimum_ratio_median=np.median(m['cmin']/ref['cmin']),fraction_peak_lower=np.mean(m['cmax']<ref['cmax']),fraction_minimum_higher=np.mean(m['cmin']>ref['cmin'])))
    pd.DataFrame(grid).to_csv(tab/'split-grid.csv',index=False)
    finite=[]
    for shape in ['emax','exponential']:
        base={day:finite_auc(cfg,p,cfg['regimens']['300QD'],day*24,shape) for day in [14,42]}
        for name,reg in cfg['regimens'].items():
            for day in [14,42]:
                v=finite_auc(cfg,p,reg,day*24,shape)
                finite.append(dict(shape=shape,regimen=name,days=day,typical_auc=finite_auc(cfg,typ,reg,day*24,shape)[0],**quantiles(v/base[day])))
    pd.DataFrame(finite).to_csv(tab/'finite-auc-scenarios.csv',index=False)
    sensitivity=[]
    for key,rse in cfg['rse'].items():
        for sign in [-1,1]:
            cc=json.loads(json.dumps(cfg));cc['pk'][key]*=np.exp(sign*1.96*rse)
            pp=parameters(cc);base=metrics(cc,pp,cc['regimens']['300QD']);m=metrics(cc,pp,cc['regimens']['150BID'])
            sensitivity.append(dict(parameter=key,sign=sign,cmax_ratio=m['cmax'][0]/base['cmax'][0],cmin_ratio=m['cmin'][0]/base['cmin'][0],teae_odds=odds(cc,m,base)['g3_teae'][0],trae_odds=odds(cc,m,base)['g3_trae'][0]))
    for cov in [dict(age=80),dict(weight=50),dict(weight=100),dict(bilirubin=24)]:
        pp=parameters(cfg,cov=cov);base=metrics(cfg,pp,cfg['regimens']['300QD']);m=metrics(cfg,pp,cfg['regimens']['150BID'])
        sensitivity.append(dict(parameter='covariate:'+str(cov),sign=0,cmax_ratio=m['cmax'][0]/base['cmax'][0],cmin_ratio=m['cmin'][0]/base['cmin'][0],teae_odds=odds(cfg,m,base)['g3_teae'][0],trae_odds=odds(cfg,m,base)['g3_trae'][0]))
    for sign in [-1,1]:
        cc=json.loads(json.dumps(cfg));cc['covariates']['low_dose_ka_effect']*=np.exp(sign*1.96*.195)
        base=metrics(cc,typ,cc['regimens']['300QD']);m=metrics(cc,typ,cc['regimens']['150BID'])
        sensitivity.append(dict(parameter='low_dose_ka_effect',sign=sign,cmax_ratio=m['cmax'][0]/base['cmax'][0],cmin_ratio=m['cmin'][0]/base['cmin'][0],teae_odds=odds(cc,m,base)['g3_teae'][0],trae_odds=odds(cc,m,base)['g3_trae'][0]))
    pd.DataFrame(sensitivity).to_csv(tab/'sensitivity.csv',index=False)
    benchmark=[]
    for metric,source in [('cmax',365),('auc24',3760)]:
        row=mm[(mm.branch=='per_dose')&(mm.regimen=='300QD')&(mm.metric==metric)].iloc[0]
        benchmark.append(dict(metric=metric,reported_gm=source,source_definition='Label12.3 Cmax; timepoint unspecified' if metric=='cmax' else 'Label12.3 total AUC; integration window unspecified, not verified AUC24ss',conditional_typical=row['typical'],conditional_gm=row['geomean'],typical_ratio=row['typical']/source,gm_ratio=row['geomean']/source))
    pd.DataFrame(benchmark).to_csv(tab/'benchmark.csv',index=False)
    t=np.linspace(0,24,481);curves={'hours':t}
    for name,reg in cfg['regimens'].items():curves[name]=profile(cfg,typ,t,reg)[0]
    pd.DataFrame(curves).to_csv(tab/'typical-curves.csv',index=False)
    fig,axes=plt.subplots(1,2,figsize=(10,4),layout='constrained')
    for name,col in zip(names,COLORS):axes[0].plot(t,curves[name],color=col,label=name)
    axes[0].set(xlabel='Hours in a 24-hour day',ylabel='Whole-blood concentration (ng/mL)',title='Conditional steady-state PK');axes[0].legend(fontsize=9)
    z=np.linspace(0,72,721)
    for shape,ls in [('emax','-'),('exponential','--')]:
        for name,col in zip(['300QD','150BID'],COLORS):axes[1].plot(z/24,profile(cfg,typ,z,cfg['regimens'][name],steady=False,shape=shape)[0],color=col,ls=ls,label=name+'/'+shape)
    axes[1].set(xlabel='Days from first dose',ylabel='Whole-blood concentration (ng/mL)',title='Early PK under assumed F(t) functions');axes[1].legend(fontsize=8)
    fig.savefig(figs/'whole-blood-profiles.png');plt.close(fig)
    fig,axes=plt.subplots(1,3,figsize=(11,4),layout='constrained')
    for ax,key,title in zip(axes,['cmax','cmin','cavg'],['Cmax','24 h minimum','Cavg']):
        for i,name in enumerate(names[1:]):
            row=rr[(rr.branch=='per_dose')&(rr.regimen==name)&(rr.metric==key)].iloc[0]
            ax.errorbar(i,row['median'],yerr=[[row['median']-row['p05']],[row['p95']-row['median']]],fmt='o',capsize=4,color=COLORS[i+1])
        ax.axhline(1,color='.5',ls='--');ax.set_xticks(range(4),names[1:],rotation=25);ax.set_title(title);ax.set_ylabel('Paired ratio vs 300QD');ax.set_ylim(bottom=0)
    fig.suptitle('4096 conditional paired individuals; median and 5th-95th percentiles',fontsize=12)
    fig.savefig(figs/'paired-exposure.png');plt.close(fig)
    fig,axes=plt.subplots(1,2,figsize=(10,4),layout='constrained')
    for ax,endpoint,title in zip(axes,['g3_teae','g3_trae'],['Grade >=3 TEAE: Cmin association','Grade >=3 TRAE: Cmax association']):
        for i,name in enumerate(names[1:]):
            row=oo[(oo.branch=='per_dose')&(oo.regimen==name)&(oo.endpoint==endpoint)&(oo.coefficient=='slope')].iloc[0]
            ax.errorbar(i,row['median'],yerr=[[row['median']-row['p05']],[row['p95']-row['median']]],fmt='o',capsize=4,color=COLORS[i+1])
            alt=oo[(oo.branch=='daily_dose')&(oo.regimen==name)&(oo.endpoint==endpoint)&(oo.coefficient=='slope')].iloc[0]
            ax.plot(i,alt['median'],'x',color='#333333',ms=7)
        ax.axhline(1,color='.5',ls='--');ax.set_xticks(range(4),names[1:],rotation=25);ax.set_yscale('log');ax.set_ylabel('Conditional relative odds vs 300QD');ax.set_title(title,fontsize=11)
    fig.suptitle('Points: per-dose ka branch; x: daily-dose branch; not clinical risk ratios',fontsize=11)
    fig.savefig(figs/'conditional-odds.png');plt.close(fig)
    results=dict(n=cfg['n'],seed=cfg['seed'],benchmark=benchmark,typical=mm[(mm.branch=='per_dose')][['regimen','metric','typical']].to_dict('records'),paired=rr.to_dict('records'),odds=oo.to_dict('records'),split_grid=grid)
    (out/'results.json').write_text(json.dumps(results,indent=2)+'\n')
    (out/'environment.json').write_text(json.dumps(dict(python=platform.python_version(),numpy=np.__version__,pandas=pd.__version__,scipy=scipy.__version__,matplotlib=matplotlib.__version__),indent=2)+'\n')
    source=ROOT.parent/'oncology-trend-ideas-2026-10-22/data/daraxonrasib-fda.pdf'
    if source.exists():(out/'source-hashes.json').write_text(json.dumps({'FDA-NDA220910.pdf':hashlib.sha256(source.read_bytes()).hexdigest()},indent=2)+'\n')
    print(pd.DataFrame(benchmark).to_string(index=False));print(rr[(rr.branch=='per_dose')&rr.metric.isin(['cmax','cmin','cavg'])].to_string(index=False));print(oo[(oo.branch=='per_dose')&(oo.coefficient=='slope')].to_string(index=False))

if __name__=='__main__':main()
