"""Independent ODE, periodicity, quadrature and statistical invariant checks."""
from pathlib import Path
import json,unittest
import numpy as np
from scipy.integrate import solve_ivp
from model import parameters,response,profile,metrics,ka_factor,finite_auc,odds

C=json.loads((Path(__file__).parent/'inputs.json').read_text())

class ModelTests(unittest.TestCase):
    def test_single_dose_against_ode(self):
        rng=np.random.default_rng(17);eta=rng.multivariate_normal(np.zeros(3),C['omega'],size=8);p=parameters(C,eta)
        for i in range(8):
            cl,vc,q,vp,ka=(p[k][i] for k in ['cl','vc','q','vp','ka']);ka*=2.49
            k=np.array([[-ka,0,0],[ka,-(cl+q)/vc,q/vp],[0,q/vc,-q/vp]])
            t=np.linspace(0,48,97);sol=solve_ivp(lambda t,y:k@y,[0,48],[1,0,0],t_eval=t,rtol=1e-10,atol=1e-12)
            pi={key:value[i:i+1] for key,value in p.items()};pred=response(pi,t+p['lag'][i],2.49)[0]
            np.testing.assert_allclose(pred,sol.y[1]*1000/vc,rtol=1e-6,atol=1e-8)

    def test_periodic_against_long_history(self):
        p=parameters(C);t=np.linspace(0,24,49);reg=C['regimens']['150BID'];expected=np.zeros_like(t)
        for day in range(-40,1):
            for at,d in zip(reg['times'],reg['doses']):expected+=d*(1-C['pk']['em'])*response(p,t-day*24-at,2.49)[0]
        np.testing.assert_allclose(profile(C,p,t,reg)[0],expected,rtol=1e-10,atol=1e-8)

    def test_auc_balance_by_quadrature(self):
        p=parameters(C);t=np.linspace(0,24,24001)
        for name in ['300QD','150BID','200+100']:
            m=metrics(C,p,C['regimens'][name]);a=np.trapz(profile(C,p,t,C['regimens'][name])[0],t)
            self.assertAlmostEqual(a,m['auc24'][0],places=3)

    def test_integral_and_first_cycle_no_history(self):
        p=parameters(C);t=np.linspace(0,24,24001);r=C['regimens']['150BID']
        a=np.trapz(profile(C,p,t,r,steady=False)[0],t)
        self.assertAlmostEqual(a,finite_auc(C,p,r,24)[0],places=3)
        self.assertEqual(profile(C,p,np.array([0]),r,steady=False)[0,0],0)

    def test_omega_and_dose_branch(self):
        self.assertTrue((np.linalg.eigvalsh(C['omega'])>0).all())
        self.assertEqual(ka_factor(C,160,320,'per_dose'),2.49);self.assertEqual(ka_factor(C,160.01,320,'per_dose'),1)
        self.assertEqual(ka_factor(C,150,300,'daily_dose'),1)

    def test_grid_resolution(self):
        p=parameters(C)
        for r in C['regimens'].values():
            a=metrics(C,p,r);b=metrics(C,p,r,step=.005)
            for key in ['cmax','cmin']:np.testing.assert_allclose(a[key],b[key],rtol=.0002)

    def test_odds_cancels_intercept_and_baseline(self):
        p=parameters(C);a=metrics(C,p,C['regimens']['150BID']);b=metrics(C,p,C['regimens']['300QD'])
        o=odds(C,a,b);self.assertAlmostEqual(o['dose_modification'][0],1)
        logit_a=-18.3+.013*a['cmin'][0]+.035*65
        logit_b=-18.3+.013*b['cmin'][0]+.035*65
        self.assertAlmostEqual(o['g3_teae'][0],np.exp(logit_a-logit_b))

    def test_grid_random_individuals(self):
        eta=np.random.default_rng(201).multivariate_normal(np.zeros(3),C['omega'],size=32)
        p=parameters(C,eta)
        for branch in ['per_dose','daily_dose']:
            for r in C['regimens'].values():
                a=metrics(C,p,r,branch);b=metrics(C,p,r,branch,step=.0025)
                for key in ['cmax','cmin']:np.testing.assert_allclose(a[key],b[key],rtol=.001)

if __name__=='__main__':unittest.main()
