# Measurement examples for an immune-aging protein proxy

Original hypothetical calculations; no empirical participants, original model coefficients, disease outcomes or UK Biobank records. The paper's cell frequencies, exact ratio implementation and protein model are not reproduced.

Python 3.12, NumPy 1.26.4, Matplotlib 3.9.1 were used:

```sh
python analysis.py
python -m unittest test_analysis.py
python plot.py
```

Offline, no GPU. Results: ratio-sampling.csv, proxy-agreement.csv, summary.json. Two PNGs in figures/. Seeds and preset parameters are recorded in the summary. Differences in library versions can change final digits, random streams or plot bytes.

## Cell capture

Multinomial K/B/other frequencies .02/.01/.97, independent perfectly classified capture, N=200,1000,5000. 100000 draws each, seed20261014, one continuing NumPy Generator. B=0 makes raw K/B undefined. K=0 or B=0 makes log ratio undefined. Report those counts explicitly. Central95% ratio ranges are conditional on BOTH positive counts; they are not confidence intervals for biological ratios. Exact P(B=0)=.99^N; Monte Carlo estimates differ. Delta log-SD sqrt(1/(N pK)+1/(N pB)) uses the multinomial covariance; poor at small counts. No donor heterogeneity, annotation error, selective loss or within-sample dependence.

## Protein proxy

Independent Z,e ~ N(0,1), 20000 draws each, seed314159. W=Z+.5e. Scenarios W, W+.75,1.5W use the SAME synthetic subjects to isolate positive affine shifts. Z is an arbitrary standardized latent cell-state score, not a cell percentage. Cutoff1 is arbitrary, not clinical. No clinical outcome is generated.

Exact correlation = 1/sqrt(1.25), unchanged by both shifts. For offset a and positive scale b, measured score a+bW has bias a and RMSE sqrt(a^2+(b-1)^2+(b*.5)^2) relative to Z. Flag fraction = normal survival probability at1 with mean a and SD b*sqrt1.25. Figure B and manuscript table use exact population values. Simulated rows separately record Monte Carlo values. Oracle correction (score-a)/b recovers W using known constants; it is not a fitted or externally validated recalibration procedure. Agreement to cell state is distinct from calibration of disease probabilities.

## Source context

Terekhova et al., Immunity, DOI10.1016/j.immuni.2026.09.012, 2026-10-09. Public abstract: https://kclpure.kcl.ac.uk/portal/en/publications/single-cell-analyses-of-global-cohorts-outline-determinants-of-im/ . Original institutional announcement: https://medicine.washu.edu/news/immune-cell-map-uncovers-how-individual-aging-trajectories-diverge/ . Sources checked 2026-10-14. Publisher full text/supplements were not accessed. Original paper figures, text, data and code are not redistributed.
