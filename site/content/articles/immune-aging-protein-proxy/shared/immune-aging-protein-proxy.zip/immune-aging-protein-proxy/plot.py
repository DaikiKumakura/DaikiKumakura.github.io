"""Original figures from the controlled measurement examples."""
from pathlib import Path
import json
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from analysis import ratio_summary

HERE=Path(__file__).resolve().parent
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':11,'axes.spines.top':False,'axes.spines.right':False})
COLORS=['#327f79','#b56847','#687caa']


def main():
    (HERE/'figures').mkdir(exist_ok=True)
    data=json.loads((HERE/'results/summary.json').read_text())
    rng=np.random.default_rng(20261014)
    fig,axes=plt.subplots(1,2,figsize=(10.8,4.6),gridspec_kw={'width_ratios':[1.7,1]})
    for n,color in zip((200,1000,5000),COLORS):
        row,lr=ratio_summary(n,100000,rng);values=np.sort(np.exp(lr));prob=np.arange(1,len(values)+1)/len(values)
        axes[0].step(values,prob,where='post',color=color,label=f'{n:,} captured cells')
    axes[0].set_xscale('log');axes[0].axvline(2,color='#888888',linestyle=':',label='True K/B = 2')
    axes[0].set(xlabel='Observed K/B (log scale)',ylabel='Cumulative fraction of valid samples',title='A. Same biology, different capture depths')
    axes[0].legend(fontsize=9,loc='lower right')
    rows=data['ratios'];axes[1].bar([str(r['captured_cells']) for r in rows],[100*r['denominator_zero_exact'] for r in rows],color=COLORS)
    for i,r in enumerate(rows):axes[1].text(i,100*r['denominator_zero_exact']+.35,f"{100*r['denominator_zero_exact']:.3g}%",ha='center',fontsize=10)
    axes[1].set(xlabel='Captured cells per sample',ylabel='P(B count = 0), %',title='B. Undefined raw ratios');axes[1].set_ylim(0,16)
    fig.suptitle('Cell ratios depend on how many relevant cells were captured',fontsize=14)
    fig.text(.5,.025,'Original multinomial example: K 2%, B 1%; 100,000 samples per setting.\nPanel A excludes K=0 or B=0; ranges are sampling variation, not biological confidence intervals.',ha='center',fontsize=9)
    fig.tight_layout(rect=(0,.12,1,.93));fig.savefig(HERE/'figures/01-ratio-sampling.png',dpi=180);plt.close(fig)

    rng=np.random.default_rng(314159);z=rng.normal(size=20000);e=rng.normal(size=20000);w=z+.5*e
    fig,axes=plt.subplots(1,2,figsize=(10.8,4.6),gridspec_kw={'width_ratios':[1.1,1]})
    for offset,color,label in [(0,COLORS[0],'Reference'),(.75,COLORS[1],'Offset +0.75')]:
        axes[0].scatter(z[:240],(w+offset)[:240],s=11,alpha=.45,color=color,label=label)
    axes[0].plot([-3,3],[-3,3],color='#888',linestyle=':');axes[0].set(xlabel='Latent cell-state score Z',ylabel='Protein proxy score W',title='A. Correlation is unchanged');axes[0].legend(fontsize=9)
    rows=data['proxies'];labels=['Reference','Offset\n+0.75','Scale\n×1.5']
    axes[1].bar(labels,[100*r['exact_flag_fraction'] for r in rows],color=COLORS)
    for i,r in enumerate(rows):axes[1].text(i,100*r['exact_flag_fraction']+.6,f"{100*r['exact_flag_fraction']:.1f}%",ha='center')
    axes[1].set(ylabel='Population fraction above score cutoff 1, %',title='B. The same cutoff flags different fractions',ylim=(0,49))
    fig.suptitle('The same correlation does not imply the same measurement scale',fontsize=14)
    fig.text(.5,.025,'Original normal-score example, not the published predictor. Noise SD 0.5; all population correlations = 0.894.\nOffset and scale changes use the same synthetic individuals. Cutoff 1 is arbitrary, not clinical.',ha='center',fontsize=9)
    fig.tight_layout(rect=(0,.12,1,.93));fig.savefig(HERE/'figures/02-proxy-shift.png',dpi=180);plt.close(fig)


if __name__=='__main__':main()
