import math, unittest
import numpy as np
from analysis import zero_probability,log_ratio_sd,normal_tail,proxy_population,proxy_summaries,ratio_summary


class MeasurementTests(unittest.TestCase):
    def test_zero_probability(self):
        self.assertAlmostEqual(zero_probability(200,.01),.13397967485796172)

    def test_delta_uses_multinomial_covariance(self):
        n=1000;pk=.02;pb=.01
        # Direct delta expression including negative covariance.
        variance=(1-pk)/(n*pk)+(1-pb)/(n*pb)+2/n
        self.assertAlmostEqual(log_ratio_sd(n,pk,pb)**2,variance)

    def test_normal_symmetry(self):
        self.assertEqual(normal_tail(0,0,1),.5)
        self.assertAlmostEqual(normal_tail(1,0,1)+normal_tail(-1,0,1),1)

    def test_population_offset_rmse(self):
        r=proxy_population(.75,1)
        self.assertAlmostEqual(r['exact_rmse'],math.sqrt(.8125))

    def test_population_scale_rmse(self):
        self.assertAlmostEqual(proxy_population(0,1.5)['exact_rmse'],math.sqrt(.8125))

    def test_affine_correlation(self):
        rng=np.random.default_rng(99);r=proxy_summaries(rng.normal(size=5000),rng.normal(size=5000))
        self.assertAlmostEqual(r[0]['pearson'],r[1]['pearson'])
        self.assertAlmostEqual(r[0]['pearson'],r[2]['pearson'])

    def test_oracle_returns_reference(self):
        z=np.array([-2.,-.1,.5,1.,2.]);e=np.array([1.,0.,-.2,.8,0.]);r=proxy_summaries(z,e)
        self.assertTrue(all(x['oracle_corrected_flag_fraction']==r[0]['flag_fraction'] for x in r))

    def test_ratio_exclusions_accounted(self):
        r,_=ratio_summary(200,1000,np.random.default_rng(1))
        self.assertEqual(r['valid_log_ratio_count']+r['log_ratio_invalid_count'],1000)
        self.assertGreaterEqual(r['log_ratio_invalid_count'],r['denominator_zero_count'])

    def test_sampling_matches_exact(self):
        r,_=ratio_summary(200,100000,np.random.default_rng(123))
        self.assertLess(abs(r['denominator_zero_fraction']-r['denominator_zero_exact']),.004)

    def test_flag_shift(self):
        base=proxy_population(0,1)['exact_flag_fraction']
        self.assertGreater(proxy_population(.75,1)['exact_flag_fraction'],base)
        self.assertGreater(proxy_population(0,1.5)['exact_flag_fraction'],base)

    def test_invalid_inputs(self):
        with self.assertRaises(ValueError):zero_probability(0,.1)
        with self.assertRaises(ValueError):log_ratio_sd(100,.8,.8)
        with self.assertRaises(ValueError):proxy_population(0,0)


if __name__=='__main__':unittest.main()
