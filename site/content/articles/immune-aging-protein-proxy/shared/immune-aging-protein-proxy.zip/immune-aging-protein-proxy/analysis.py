"""Original measurement examples; no empirical participants or disease outcomes."""
from pathlib import Path
import csv, json, math
import numpy as np

HERE = Path(__file__).resolve().parent


def zero_probability(n, p):
    if n < 1 or not 0 <= p <= 1:
        raise ValueError('Positive sample size and probability required')
    return (1-p)**n


def log_ratio_sd(n, p_k, p_b):
    if n < 1 or min(p_k, p_b) <= 0 or p_k+p_b > 1:
        raise ValueError('Valid multinomial frequencies required')
    return math.sqrt(1/(n*p_k)+1/(n*p_b))


def ratio_summary(n, draws, rng):
    counts = rng.multinomial(n, [.02, .01, .97], size=draws)
    k, b = counts[:, 0], counts[:, 1]
    good = (k > 0) & (b > 0)
    ratios = k[good]/b[good]
    low, median, high = np.quantile(ratios, [.025, .5, .975])
    row = dict(captured_cells=n,draws=draws,expected_k=n*.02,expected_b=n*.01,
               denominator_zero_count=int((b==0).sum()),
               denominator_zero_fraction=float((b==0).mean()),
               denominator_zero_exact=zero_probability(n,.01),
               log_ratio_invalid_count=int((~good).sum()),
               valid_log_ratio_count=int(good.sum()),
               conditional_ratio_p025=float(low),conditional_ratio_median=float(median),
               conditional_ratio_p975=float(high),delta_log_sd=log_ratio_sd(n,.02,.01))
    return row, np.log(ratios)


def normal_tail(cutoff, mean, sd):
    if sd <= 0:
        raise ValueError('Positive standard deviation required')
    return .5*math.erfc((cutoff-mean)/(sd*math.sqrt(2)))


def proxy_population(offset, scale, noise_sd=.5, cutoff=1.):
    if scale <= 0 or noise_sd < 0:
        raise ValueError('Positive scale and nonnegative noise required')
    variance = scale**2*(1+noise_sd**2)
    # W = offset + scale*(Z + noise_sd*e); Z and e independent N(0,1).
    return dict(exact_bias=offset,
                exact_rmse=math.sqrt(offset**2+(scale-1)**2+(scale*noise_sd)**2),
                exact_pearson=1/math.sqrt(1+noise_sd**2),
                exact_flag_fraction=normal_tail(cutoff,offset,math.sqrt(variance)))


def proxy_summaries(z, noise):
    base = z+.5*noise
    rows=[]
    for name,offset,scale in [('reference',0.,1.),('offset_shift',.75,1.),('scale_shift',0.,1.5)]:
        observed = offset+scale*base
        corrected = (observed-offset)/scale
        error = observed-z
        rows.append(dict(setting=name,n=len(z),offset=offset,scale=scale,cutoff=1.,
                         mean_error=float(error.mean()),rmse=float(np.sqrt(np.mean(error**2))),
                         pearson=float(np.corrcoef(z,observed)[0,1]),
                         flag_fraction=float((observed>1).mean()),
                         oracle_corrected_flag_fraction=float((corrected>1).mean()),
                         **proxy_population(offset,scale)))
    return rows


def write_csv(path, rows):
    with path.open('w',encoding='utf-8',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)


def main():
    out=HERE/'results';out.mkdir(exist_ok=True)
    rng=np.random.default_rng(20261014)
    ratios=[ratio_summary(n,100000,rng)[0] for n in (200,1000,5000)]
    rng=np.random.default_rng(314159);z=rng.normal(size=20000);e=rng.normal(size=20000)
    proxies=proxy_summaries(z,e)
    write_csv(out/'ratio-sampling.csv',ratios);write_csv(out/'proxy-agreement.csv',proxies)
    summary=dict(empirical_data_analyzed=False,original_model_reproduced=False,
                 ratio=dict(p_k=.02,p_b=.01,samples_per_setting=100000,seed=20261014,
                            interval='central95 sampling range conditional on both counts positive'),
                 proxy=dict(latent_distribution='N(0,1)',noise_sd=.5,n=20000,seed=314159,
                            cutoff=1.,cutoff_is_clinical=False,paired_scenarios=True),
                 ratios=ratios,proxies=proxies)
    (out/'summary.json').write_text(json.dumps(summary,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(summary,indent=2))


if __name__=='__main__':
    main()
