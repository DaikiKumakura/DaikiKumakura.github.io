# Reproduction

Use R 4.5.3. Put Spatial_coordinates1.RDS, Spatial_coordinates2.RDS and Cell_annotation.csv from the [pinned study release](https://github.com/ZhoulabCPH/SCLC-LNM-SMI/tree/1c6ed2c985a79ee55371865f3ccc9a10f9d64581) beside audit.R, then run Rscript audit.R.

Expected SHA-256:

    c71e89d4afc2d8d2ce50d3e2e316e7a427cd3570716b7ef347c85b151cde6727 Spatial_coordinates1.RDS
    977a095469021fff1e91e815e157613bf9305db0cccd86bbf44785231e0878ba Spatial_coordinates2.RDS
    e523f40d39708d8ec1b1d846d2ef4245adf7a8a1c706e798833d2e5da567a4e8 Cell_annotation.csv
