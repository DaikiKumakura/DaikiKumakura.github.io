# Run from the workspace root. Only aggregate outputs leave this directory.
root <- "."
files <- file.path(root, c("Spatial_coordinates1.RDS", "Spatial_coordinates2.RDS"))
coords <- lapply(files, readRDS)
annotations <- read.csv(file.path(root, "Cell_annotation.csv"), colClasses = "character")
stopifnot(identical(names(annotations), c("slide", "cell_id", "cell_type")))
key <- function(slide, cell_id) paste(slide, cell_id, sep = ":")
overlap <- length(intersect(coords[[1]]$cell_id, coords[[2]]$cell_id))
matrix <- do.call(rbind, lapply(seq_along(coords), function(i) {
  x <- coords[[i]]
  stopifnot(identical(names(x), c("cell_id", "x", "y")), all(is.finite(x$x)), all(is.finite(x$y)))
  do.call(rbind, lapply(sort(unique(annotations$slide)), function(slide) {
    a <- annotations[annotations$slide == slide, ]
    data.frame(
      coordinate_file = basename(files[i]), annotation_slide = slide,
      coordinate_rows = nrow(x), coordinate_duplicate_ids = sum(duplicated(x$cell_id)),
      annotation_rows = nrow(a), annotation_duplicate_ids = sum(duplicated(a$cell_id)),
      matched_annotation_rows = sum(a$cell_id %in% x$cell_id),
      matched_coordinate_rows = sum(x$cell_id %in% a$cell_id),
      xmin = min(x$x), xmax = max(x$x), ymin = min(x$y), ymax = max(x$y)
    )
  }))
}))
write.csv(matrix, file.path(root, "join-audit.csv"), row.names = FALSE)
slide2 <- annotations[annotations$slide == "Slide2", ]
stopifnot(all(grepl("_2$", slide2$cell_id)))
candidate <- sub("_2$", "_1", slide2$cell_id)
stopifnot(!anyDuplicated(candidate))
suffix_audit <- data.frame(
  coordinate_file = basename(files),
  slide2_rows = nrow(slide2),
  matched_after_suffix_change = vapply(coords, function(x) sum(candidate %in% x$cell_id), integer(1))
)
write.csv(suffix_audit, file.path(root, "slide2-suffix-audit.csv"), row.names = FALSE)
counts <- as.data.frame(table(annotations$slide, annotations$cell_type))
names(counts) <- c("slide", "cell_type", "count")
write.csv(counts, file.path(root, "annotation-counts.csv"), row.names = FALSE)
cat("Shared unique coordinate IDs between files:", overlap, "\n")
cat("Duplicate annotation slide+cell keys:", sum(duplicated(key(annotations$slide, annotations$cell_id))), "\n")
print(matrix)
print(suffix_audit)
slide1 <- annotations[annotations$slide == "Slide1", ]
other <- match(candidate, slide1$cell_id)
collision <- !is.na(other)
agrees <- slide2$cell_type[collision] == slide1$cell_type[other[collision]]
defined <- slide2$cell_type[collision] != "Undefined" &
           slide1$cell_type[other[collision]] != "Undefined"
label_audit <- data.frame(
  annotated_cross_slide_collision = sum(collision),
  labels_differ = sum(!agrees),
  both_labels_defined = sum(defined),
  defined_labels_differ = sum(!agrees & defined)
)
write.csv(label_audit, file.path(root, "label-collision-audit.csv"), row.names = FALSE)
print(label_audit)
