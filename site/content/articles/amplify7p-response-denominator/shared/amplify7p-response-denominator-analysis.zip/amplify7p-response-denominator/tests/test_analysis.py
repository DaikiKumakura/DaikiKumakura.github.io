import unittest,importlib.util
from pathlib import Path
from openpyxl import load_workbook
p=Path(__file__).resolve().parents[1];s=importlib.util.spec_from_file_location('a',p/'analysis/run.py');m=importlib.util.module_from_spec(s);s.loader.exec_module(m)
class Tests(unittest.TestCase):
 def test_wilson_boundaries(self):
  self.assertAlmostEqual(m.wilson(0,10)[0],0);self.assertAlmostEqual(m.wilson(10,10)[1],1)
 def test_selected_positive_panels(self):
  w=load_workbook(p/'data/raw/figure5.xlsx',data_only=True);a=m.read_positive(w,'Fig 5b');b=m.read_positive(w,'Fig. 5i');self.assertEqual(len(a),89);self.assertEqual(len(b),78);self.assertTrue(set(b)<=set(a))
 def test_ascertainment_range(self):
  self.assertLess(78/96,78/90);self.assertLess(84/96,1);self.assertEqual(96-90,6)
if __name__=='__main__':unittest.main()
