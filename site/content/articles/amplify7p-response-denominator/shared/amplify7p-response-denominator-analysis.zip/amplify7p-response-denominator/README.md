# AMPLIFY-7P denominator audit

Independent aggregate calculations from George et al., Nature Medicine (2026), doi:10.1038/s41591-026-04734-7. Source: CC BY-NC-ND 4.0. Original workbook and participant-level derivatives are excluded.

Python 3.12 with requirements.txt. Run `python analysis/download_sources.py`, `python analysis/run.py`, then `python -m unittest discover -s tests -v`. Numeric summaries and figures are regenerated from the hash-verified workbook. Figure5b and5i contain selected positive summaries, not complete records for all90 participants. Bounds are ascertainment scenarios, not confidence intervals. No clinical efficacy or causal effect is estimated.
