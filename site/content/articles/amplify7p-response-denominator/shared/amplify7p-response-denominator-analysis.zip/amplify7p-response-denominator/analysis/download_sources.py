from pathlib import Path
import urllib.request,hashlib
p=Path(__file__).resolve().parents[1]/'data/raw/figure5.xlsx'
p.parent.mkdir(parents=True,exist_ok=True)
if not p.exists():
 b=urllib.request.urlopen('https://media.springernature.com/original/springer-static/esm/art%3A10.1038%2Fs41591-026-04734-7/MediaObjects/41591_2026_4734_MOESM6_ESM.xlsx',timeout=120).read()
 assert hashlib.sha256(b).hexdigest()=='699640da92229395d0ccfe1aee4141dab2940feabfb037827abbbf3e9105e2df'
 p.write_bytes(b)
assert hashlib.sha256(p.read_bytes()).hexdigest()=='699640da92229395d0ccfe1aee4141dab2940feabfb037827abbbf3e9105e2df'
print('Verified public Figure 5 Source Data')
