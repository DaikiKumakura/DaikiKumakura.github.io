"""Audit reported response denominators and paired positive-response summaries."""
from pathlib import Path
import json,csv,hashlib
import numpy as np
from scipy.stats import norm
from openpyxl import load_workbook
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
ROOT=Path(__file__).resolve().parents[1]
N_RANDOMIZED=96
N_EVALUABLE=90

def wilson(k,n):
 z=norm.ppf(.975);p=k/n;c=(p+z*z/(2*n))/(1+z*z/n);h=z*np.sqrt(p*(1-p)/n+z*z/(4*n*n))/(1+z*z/n)
 return float(c-h),float(c+h)

def read_positive(w,name):
 rows=list(w[name].values)[1:];out={}
 for row in rows:
  key=row[0];v=row[2]
  if isinstance(key,str) and key.startswith('2-') and isinstance(v,(int,float)):
   assert key not in out and v>0;out[key]=float(v)
 return out

def table(name,rows):
 f=ROOT/'outputs/tables'/name
 with f.open('w',newline='',encoding='utf8') as out:
  d=csv.DictWriter(out,fieldnames=list(rows[0]));d.writeheader();d.writerows(rows)

def figure(fig,name):
 fig.tight_layout();fig.savefig(ROOT/f'outputs/figures/{name}.png',dpi=170);fig.savefig(ROOT/f'outputs/figures/{name}.svg');plt.close(fig)

def main():
 for d in ['outputs/tables','outputs/figures']:(ROOT/d).mkdir(parents=True,exist_ok=True)
 src=ROOT/'data/raw/figure5.xlsx';w=load_workbook(src,data_only=True)
 anyp=read_positive(w,'Fig 5b');own=read_positive(w,'Fig. 5i')
 assert len(anyp)==89 and len(own)==78 and set(own)<=set(anyp)
 assert all(v>=2 for v in anyp.values()) and all(v>=2 for v in own.values())
 counts=[('Any vaccine peptide / evaluable',89,90),('Own-tumor peptide / any responder',78,89),('Own-tumor peptide / evaluable',78,90)]
 rates=[]
 for label,k,n in counts:
  lo,hi=wilson(k,n);rates.append(dict(estimand=label,positive=k,denominator=n,rate=k/n,wilson_low=lo,wilson_high=hi))
 table('response-denominators.csv',rates)
 bounds=[]
 for label,k in [('Any vaccine peptide',89),('Own-tumor peptide',78)]:
  bounds.append(dict(estimand=label,known_positive=k,immune_evaluable=90,randomized=96,unascertained=6,all_randomized_lower=k/96,all_randomized_upper=(k+6)/96))
 table('ascertainment-bounds.csv',bounds)
 ids=sorted(own);x=np.array([anyp[k] for k in ids]);y=np.array([own[k] for k in ids]);ratio=y/x
 assert np.all(y<=x+.02)
 summary=dict(n_positive_paired=len(ids),panel_median=float(np.median(x)),own_median=float(np.median(y)),own_over_panel_median=float(np.median(ratio)),own_over_panel_q1=float(np.quantile(ratio,.25)),own_over_panel_q3=float(np.quantile(ratio,.75)),n_panel_above_9_17=sum(v>9.17 for v in anyp.values()))
 table('paired-positive-summary.csv',[summary])
 audit=dict(any_positive_rows=len(anyp),own_positive_rows=len(own),own_ids_outside_any=0,unobserved_pair_rows=12,warning='Figure 5i contains 78 positive summaries, not 90 complete tumor-specific measurements. Missing rows must not be assigned zero.',source_antigen_counts={'2025_release_positive':540,'2025_release_total':630,'2026_article_positive':543,'2026_article_total':623},source_grain='Selected per-participant maximum fold-change summaries, not synchronized serial assays. No unreported negative participant rows are reconstructed.')
 (ROOT/'outputs/data-quality-audit.json').write_text(json.dumps(audit,indent=2)+'\n',encoding='utf8')
 result=dict(id='NEXT-04',source_sha256=hashlib.sha256(src.read_bytes()).hexdigest(),rates=rates,bounds=bounds,paired_positive=summary,any_minus_own_among_evaluable_pp=100*(89-78)/90,source_data_audit=audit)
 (ROOT/'outputs/results.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf8')
 plt.rcParams.update({'font.size':10,'svg.fonttype':'none'})
 fig,ax=plt.subplots(figsize=(8,4));pos=np.arange(3);v=np.array([r['rate'] for r in rates]);lo=np.array([r['wilson_low'] for r in rates]);hi=np.array([r['wilson_high'] for r in rates]);ax.barh(pos,v*100,color=['#0072B2','#009E73','#D55E00']);ax.errorbar(v*100,pos,xerr=np.array([v-lo,hi-v])*100,fmt='none',color='black',capsize=4);ax.set(yticks=pos,yticklabels=[f"{r['estimand']} ({r['positive']}/{r['denominator']})" for r in rates],xlim=(0,105),xlabel='Recorded response (%)',title='Different denominators describe different questions');ax.invert_yaxis();figure(fig,'response-denominators')
 fig,ax=plt.subplots(figsize=(5.7,4.6));ax.scatter(x,y,s=25,alpha=.7,color='#0072B2');limit=max(x.max(),y.max())*1.3;ax.plot([2,limit],[2,limit],'k--',lw=1);ax.set(xscale='log',yscale='log',xlim=(2,limit),ylim=(2,limit),xlabel='Maximum response across vaccine peptides (fold)',ylabel='Maximum own-tumor peptide response (fold)',title='78 participants with positive summaries in both panels');figure(fig,'paired-positive-folds')
 fig,ax=plt.subplots(figsize=(7,3.5))
 for n,r in enumerate(bounds):
  lo=r['all_randomized_lower']*100;hi=r['all_randomized_upper']*100;ax.plot([lo,hi],[n,n],lw=8,color=['#0072B2','#D55E00'][n]);ax.text(hi+1,n,f'{lo+1e-8:.1f}–{hi+1e-8:.1f}%',va='center')
 ax.set(yticks=[0,1],yticklabels=['Any peptide','Own-tumor peptide'],xlim=(0,110),ylim=(-.6,1.6),xlabel='Fraction of all 96 randomized vaccine-arm participants (%)',title='Bounds for six unascertained participants; not confidence intervals');figure(fig,'ascertainment-bounds')
 print(json.dumps(result,indent=2))
if __name__=='__main__':main()
