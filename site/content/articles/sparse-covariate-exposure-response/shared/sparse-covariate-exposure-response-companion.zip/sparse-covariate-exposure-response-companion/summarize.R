# Summaries and figures for simulate.R (reads results/replicates.csv).
suppressPackageStartupMessages(library(ggplot2))
script_dir <- dirname(normalizePath(sub("^--file=", "", grep("^--file=", commandArgs(FALSE), value = TRUE)[1]), winslash = "/"))
d <- read.csv(file.path(script_dir, "results/replicates.csv")); stopifnot(!anyNA(d[, c("correct", "err_orr", "err_ae")]))
truth <- read.csv(file.path(script_dir, "results/truth.csv")); print(truth)
lab <- c(full = "Full model (all 20 covariates)", stepwise = "Backward stepwise (AIC)", horseshoe = "Horseshoe prior (Bayesian)")
d$method <- factor(lab[d$model], levels = lab); d$nlab <- factor(paste0("n = ", d$n), levels = paste0("n = ", sort(unique(d$n))))
agg <- do.call(rbind, lapply(split(d, list(d$model, d$n), drop = TRUE), function(x) {
  R <- nrow(x); p <- mean(x$correct)
  data.frame(model = x$model[1], n = x$n[1], reps = R, correct = p, correct_se = sqrt(p * (1 - p) / R),
             d1 = mean(x$chosen == 1), d2 = mean(x$chosen == 2), d3 = mean(x$chosen == 3),
             err_orr = mean(x$err_orr), err_ae = mean(x$err_ae),
             power_orr = mean(x$power_orr), false_orr = mean(x$false_orr), power_ae = mean(x$power_ae), false_ae = mean(x$false_ae),
             true_err_orr = mean(x$true_err_orr), true_err_ae = mean(x$true_err_ae),
             noise_abs_orr = mean(x$noise_abs_orr), noise_abs_ae = mean(x$noise_abs_ae),
             theta_orr = mean(x$theta_orr), theta_ae = mean(x$theta_ae),
             pb_ge80 = if (x$model[1] == "horseshoe") mean(x$prob_best >= 0.8) else NA, pb_le20 = if (x$model[1] == "horseshoe") mean(x$prob_best <= 0.2) else NA,
             pb_mean = if (x$model[1] == "horseshoe") mean(x$prob_best) else NA)
}))
agg <- agg[order(agg$n, match(agg$model, names(lab))), ]; rownames(agg) <- NULL
write.csv(agg, file.path(script_dir, "results/summary.csv"), row.names = FALSE)
options(width = 220); print(within(agg, { for (v in setdiff(names(agg), c("model", "n", "reps"))) assign(v, round(get(v), 3)) }), row.names = FALSE)

okabe <- c("#999999", "#E69F00", "#0072B2"); names(okabe) <- lab
a <- agg; a$method <- factor(lab[a$model], levels = lab); a$nlab <- factor(paste0("n = ", a$n), levels = paste0("n = ", sort(unique(a$n))))
g1 <- ggplot(a, aes(x = method, y = correct, fill = method)) + geom_col(width = 0.65) +
  geom_errorbar(aes(ymin = correct - 1.96 * correct_se, ymax = pmin(correct + 1.96 * correct_se, 1)), width = 0.2) +
  geom_text(aes(y = 0.04, label = sprintf("%.0f%%", 100 * correct)), size = 3.6, colour = "black", fontface = "bold") +
  facet_wrap(~nlab) + scale_fill_manual(values = okabe, guide = "none") + scale_x_discrete(labels = c("Full model", "Stepwise (AIC)", "Horseshoe")) + scale_y_continuous(limits = c(0, 1), labels = scales::percent_format(accuracy = 1)) +
  labs(x = NULL, y = "Trials choosing the best feasible dose (relative dose 2)", title = "Dose decision after each covariate strategy",
       subtitle = "Error bars: 95% range given 150 trials per sample size") +
  theme_bw(base_size = 11) + theme(panel.grid.minor = element_blank())
ggsave(file.path(script_dir, "figures/figure-2-dose-decision.png"), g1, width = 9, height = 4.8, dpi = 160)

long <- rbind(data.frame(a[c("method", "nlab")], endpoint = "Response", false = a$false_orr, power = a$power_orr),
              data.frame(a[c("method", "nlab")], endpoint = "Toxicity", false = a$false_ae, power = a$power_ae))
g2 <- ggplot(long, aes(x = false, y = power, colour = method, shape = method)) + geom_point(size = 3.2) +
  facet_grid(endpoint ~ nlab) + scale_colour_manual(values = okabe) + scale_shape_manual(values = c(16, 17, 15)) +
  scale_y_continuous(limits = c(0, 1), labels = scales::percent_format(accuracy = 1)) + scale_x_continuous(limits = c(0, 4.6)) +
  labs(x = "Mean number of inactive covariates declared important per trial (17 for response, 18 for toxicity)", y = "Share of true covariates declared important",
       colour = NULL, shape = NULL, title = "Covariate selection: false inclusions against detected true effects",
       subtitle = "Full model: p < 0.05. Stepwise: kept in the final model. Horseshoe: 90% credible interval excludes 0") +
  theme_bw(base_size = 11) + theme(legend.position = "bottom", panel.grid.minor = element_blank())
ggsave(file.path(script_dir, "figures/figure-3-selection.png"), g2, width = 9, height = 5.6, dpi = 160)

h <- d[d$model == "horseshoe", ]
g3 <- ggplot(h, aes(x = prob_best)) + geom_histogram(binwidth = 0.1, boundary = 0, fill = "#0072B2", colour = "white") + facet_wrap(~nlab) +
  scale_x_continuous(breaks = seq(0, 1, 0.2)) +
  labs(x = "Posterior probability that relative dose 2 is the best feasible dose", y = "Number of trials (of 150)",
       title = "How certain the Bayesian analysis is about the dose", subtitle = "Relative dose 2 is the best feasible dose in every simulated trial (the truth)") +
  theme_bw(base_size = 11) + theme(panel.grid.minor = element_blank())
ggsave(file.path(script_dir, "figures/figure-4-posterior-certainty.png"), g3, width = 9, height = 4.2, dpi = 160)
cat("figures written\n")

# Paired differences between methods within the same simulated trials (same data for all three methods).
d$trial <- ave(seq_along(d$n), d$model, d$n, FUN = seq_along)
paired <- do.call(rbind, lapply(c("err_orr", "err_ae", "correct"), function(v) do.call(rbind, lapply(sort(unique(d$n)), function(nn) {
  w <- reshape(d[d$n == nn, c("trial", "model", v)], idvar = "trial", timevar = "model", direction = "wide"); names(w) <- sub(paste0(v, "."), "", names(w), fixed = TRUE)
  do.call(rbind, lapply(c("full", "stepwise"), function(o) { x <- w$horseshoe - w[[o]]; data.frame(metric = v, n = nn, comparison = paste("horseshoe -", o), mean_diff = mean(x), se = sd(x) / sqrt(length(x))) })) }))))
write.csv(paired, file.path(script_dir, "results/paired.csv"), row.names = FALSE); print(within(paired, { mean_diff <- round(mean_diff, 4); se <- round(se, 4) }), row.names = FALSE)
