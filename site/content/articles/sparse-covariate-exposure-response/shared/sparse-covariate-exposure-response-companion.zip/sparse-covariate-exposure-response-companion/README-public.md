# Companion: sparse covariate strategies and the exposure-response dose decision

Simulation code and results for the article "Does sparse shrinkage of covariate effects change an exposure–response dose decision? Simulated dose-ranging trials with 20 candidate covariates". No patient data are used.

## Files

- `common.R`: shared definitions (data-generating model, calibration of intercepts) and the Gibbs sampler for the probit model with a horseshoe prior (Albert-Chib data augmentation; Makalic-Schmidt scale mixture). Base R and MASS only.
- `simulate.R`: the simulation (`Rscript simulate.R 150 1200`; about 12 minutes; seed 20261115). Writes `results/replicates.csv` (one row per trial and method) and `results/truth.csv`.
- `validate.R`: checks of the sampler for both endpoints (agreement with maximum likelihood probit at n = 20,000; R-hat across two chains).
- `exposure_check.R`: diagnostic of the exposure-effect estimates at n = 120 (full model, exposure only, horseshoe, normal prior; seed 20261117; about 10 minutes). Writes `results/exposure-check.csv` and `results/exposure-check-summary.csv`.
- `summarize.R`: summaries (`results/summary.csv`, `results/paired.csv`) and the figures.
- `results/`: replicate-level results, aggregate results, true dose-specific rates and the session information (R 4.5.3, MASS 7.3-65).

## Reproduce

```
Rscript simulate.R 150 1200
Rscript summarize.R
Rscript validate.R
```

The scripts find their own folder. Running `simulate.R` overwrites `results/replicates.csv`; the summaries in `results/summary.csv` can be regenerated from the included `results/replicates.csv` with `Rscript summarize.R` without rerunning the simulation.
