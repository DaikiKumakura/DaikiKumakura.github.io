# Summaries of simulate_extra.R (lasso and Firth-type methods, two toxicity margins).
script_dir <- dirname(normalizePath(sub("^--file=", "", grep("^--file=", commandArgs(FALSE), value = TRUE)[1]), winslash = "/"))
d <- do.call(rbind, lapply(c("orig", "narrow"), function(c) read.csv(file.path(script_dir, paste0("results/replicates-extra-", c, ".csv")))))
cat("Fits that produced no rates (failed):\n"); print(aggregate(failed ~ config + model + n, d, sum))
d <- d[d$failed == 0, ]
a <- do.call(rbind, lapply(split(d, list(d$config, d$model, d$n), drop = TRUE), function(x) {
  p <- mean(x$correct)
  data.frame(config = x$config[1], n = x$n[1], model = x$model[1], reps = nrow(x), correct = p, correct_se = sqrt(p * (1 - p) / nrow(x)),
             err_orr = mean(x$err_orr), err_ae = mean(x$err_ae), false_orr = mean(x$false_orr), power_orr = mean(x$power_orr),
             false_ae = mean(x$false_ae), power_ae = mean(x$power_ae), theta_ae_median = median(x$theta_ae), theta_orr_median = median(x$theta_orr))
}))
a <- a[order(a$config, a$n, a$model), ]; rownames(a) <- NULL
write.csv(a, file.path(script_dir, "results/summary-extra.csv"), row.names = FALSE)
options(width = 220); print(within(a, for (v in names(a)[5:14]) assign(v, round(get(v), 3))), row.names = FALSE)

# Paired differences (same trials) between the horseshoe model and the other methods.
d$trial <- ave(seq_along(d$n), d$config, d$model, d$n, FUN = seq_along)
paired <- do.call(rbind, lapply(split(d, list(d$config, d$n), drop = TRUE), function(x) {
  w <- reshape(x[, c("trial", "model", "correct", "err_ae", "err_orr")], idvar = "trial", timevar = "model", direction = "wide")
  do.call(rbind, lapply(c("full", "stepwise", "lasso", "firth"), function(o) do.call(rbind, lapply(c("correct", "err_ae", "err_orr"), function(v) {
    h <- w[[paste0(v, ".horseshoe")]]; b <- w[[paste0(v, ".", o)]]; ok <- !is.na(h) & !is.na(b); z <- h[ok] - b[ok]
    data.frame(config = x$config[1], n = x$n[1], metric = v, comparison = paste("horseshoe -", o), pairs = sum(ok), mean_diff = mean(z), se = sd(z) / sqrt(length(z))) }))))
}))
rownames(paired) <- NULL; write.csv(paired, file.path(script_dir, "results/paired-extra.csv"), row.names = FALSE)
print(within(paired[paired$metric == "correct", ], { mean_diff <- round(mean_diff, 3); se <- round(se, 3) }), row.names = FALSE)
