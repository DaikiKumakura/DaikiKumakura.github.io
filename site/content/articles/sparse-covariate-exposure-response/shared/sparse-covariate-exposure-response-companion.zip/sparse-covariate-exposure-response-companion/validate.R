# Checks of the Gibbs sampler: (1) agreement with maximum likelihood probit at large n, where the prior is negligible,
# (2) convergence across two chains (Gelman-Rubin R-hat) on simulated datasets of the study's size.
script_dir <- dirname(normalizePath(sub("^--file=", "", grep("^--file=", commandArgs(FALSE), value = TRUE)[1]), winslash = "/"))
source(file.path(script_dir, "common.R")); set.seed(20261116)
cal <- calibrate(); a_r <- cal[["a_r"]]
gen <- function(n) { pat <- draw_patients(n); dose <- sample(DOSES, n, TRUE); le <- log(dose) - pat$lncl
  list(y = rbinom(n, 1, pnorm(a_r + THETA_R * le + pat$X %*% B_R)), le = le, X = pat$X) }
# (1) large-n agreement
d <- gen(20000L); ml <- glm(y ~ ., data.frame(y = d$y, lexp = d$le, d$X), family = binomial("probit"))
hs <- probit_horseshoe(d$y, d$le, d$X, iter = 1500L, burn = 500L)
cmp <- data.frame(term = colnames(hs$draws)[1:6], ml = round(coef(ml)[1:6], 3), gibbs = round(colMeans(hs$draws)[1:6], 3))
print(cmp, row.names = FALSE); cat("max |ML - posterior mean| over all coefficients:", round(max(abs(coef(ml) - colMeans(hs$draws))), 4), "\n")
# (2) R-hat with two chains
rhat <- function(a, b) { m <- 2; n <- length(a); W <- mean(c(var(a), var(b))); Bn <- n * var(c(mean(a), mean(b))); sqrt(((n - 1) / n * W + Bn / n) / W) }
out <- t(sapply(1:20, function(k) { d <- gen(120L); c1 <- probit_horseshoe(d$y, d$le, d$X, iter = 1200L, burn = 400L); c2 <- probit_horseshoe(d$y, d$le, d$X, iter = 1200L, burn = 400L)
  c(lexp = rhat(c1$draws[, "lexp"], c2$draws[, "lexp"]), x3 = rhat(c1$draws[, "x3"], c2$draws[, "x3"]), x10 = rhat(c1$draws[, "x10"], c2$draws[, "x10"]), tau = rhat(c1$tau, c2$tau)) }))
cat("R-hat over 20 datasets (n = 120, 2 chains of 800 retained draws): median and maximum\n"); print(round(rbind(median = apply(out, 2, median), max = apply(out, 2, max)), 3))

# (3) The same two checks for the toxicity endpoint (rarer events, steeper exposure slope).
a_s <- cal[["a_s"]]
gen_tox <- function(n) { pat <- draw_patients(n); dose <- sample(DOSES, n, TRUE); le <- log(dose) - pat$lncl
  list(y = rbinom(n, 1, pnorm(a_s + THETA_S * le + pat$X %*% B_S)), le = le, X = pat$X) }
d <- gen_tox(20000L); ml <- glm(y ~ ., data.frame(y = d$y, lexp = d$le, d$X), family = binomial("probit"))
hs <- probit_horseshoe(d$y, d$le, d$X, iter = 1500L, burn = 500L)
cat("Toxicity, n = 20000: max |ML - posterior mean| over all coefficients:", round(max(abs(coef(ml) - colMeans(hs$draws))), 4), "\n")
out <- t(sapply(1:20, function(k) { d <- gen_tox(120L); c1 <- probit_horseshoe(d$y, d$le, d$X, iter = 1200L, burn = 400L); c2 <- probit_horseshoe(d$y, d$le, d$X, iter = 1200L, burn = 400L)
  c(lexp = rhat(c1$draws[, "lexp"], c2$draws[, "lexp"]), x6 = rhat(c1$draws[, "x6"], c2$draws[, "x6"]), x10 = rhat(c1$draws[, "x10"], c2$draws[, "x10"]), tau = rhat(c1$tau, c2$tau)) }))
cat("Toxicity, R-hat over 20 datasets (n = 120, 2 chains of 800 retained draws): median and maximum\n"); print(round(rbind(median = apply(out, 2, median), max = apply(out, 2, max)), 3))
