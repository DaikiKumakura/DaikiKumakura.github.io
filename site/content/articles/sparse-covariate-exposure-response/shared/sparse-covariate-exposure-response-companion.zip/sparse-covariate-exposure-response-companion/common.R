# Shared definitions for the sparse Bayesian exposure-response simulation.
# Probit models fitted by exact Gibbs sampling (Albert-Chib data augmentation) with a horseshoe prior
# on the covariate effects (Makalic-Schmidt inverse-gamma scale mixture). Only base R and MASS are used.
suppressPackageStartupMessages(library(MASS))
P_COV <- 20L                       # candidate baseline covariates
DOSES <- c(1, 2, 3)                # relative dose levels, randomized with equal allocation
AE_LIMIT <- 0.25                   # tolerable grade >=3 adverse-event rate
RHO <- 0.25                        # equicorrelation between candidate covariates
SD_LNCL <- 0.30                    # between-patient SD of log clearance not explained by covariates
CL_EFFECT <- c(x1 = 0.30, x2 = -0.20)         # covariates that change clearance
BETA_R <- c(x3 = 0.50, x4 = -0.40, x5 = 0.30)  # covariates with a direct effect on response
BETA_S <- c(x6 = 0.40, x7 = -0.30)             # covariates with a direct effect on toxicity
THETA_R <- 0.45; THETA_S <- 0.90               # exposure effects per unit log exposure (probit scale)
chol_x <- chol(matrix(RHO, P_COV, P_COV) + diag(1 - RHO, P_COV))

draw_patients <- function(n) {
  X <- matrix(rnorm(n * P_COV), n) %*% chol_x; colnames(X) <- paste0("x", seq_len(P_COV))
  lncl <- as.numeric(X[, names(CL_EFFECT)] %*% CL_EFFECT) + rnorm(n, 0, SD_LNCL)
  list(X = X, lncl = lncl)
}
coef_vec <- function(effects) { b <- rep(0, P_COV); names(b) <- paste0("x", seq_len(P_COV)); b[names(effects)] <- effects; b }
B_R <- coef_vec(BETA_R); B_S <- coef_vec(BETA_S)

# Intercepts are set so that the population response / toxicity rates at dose 1 are fixed (see calibrate()).
true_rates <- function(a_r, a_s, pat, doses = DOSES) {
  sapply(doses, function(d) { le <- log(d) - pat$lncl
    c(orr = mean(pnorm(a_r + THETA_R * le + pat$X %*% B_R)), ae = mean(pnorm(a_s + THETA_S * le + pat$X %*% B_S))) })
}
calibrate <- function(target_orr1 = 0.25, target_ae1 = 0.08, n = 400000L) {
  pat <- draw_patients(n); le <- -pat$lncl
  f <- function(a, th, B, tgt) mean(pnorm(a + th * le + pat$X %*% B)) - tgt
  c(a_r = uniroot(f, c(-3, 2), th = THETA_R, B = B_R, tgt = target_orr1)$root,
    a_s = uniroot(f, c(-4, 2), th = THETA_S, B = B_S, tgt = target_ae1)$root)
}

# Albert-Chib probit Gibbs sampler. beta[1] = intercept (N(0, 10^2)), beta[2] = log exposure (N(0, 2^2)),
# beta[3:] = covariate effects with a horseshoe prior (global scale tau, local scales lambda_j).
rinvgamma <- function(n, shape, rate) 1 / rgamma(n, shape = shape, rate = rate)
probit_horseshoe <- function(y, lexp, X, iter = 1500L, burn = 500L, seed_state = TRUE) {
  n <- length(y); Z <- cbind(1, lexp, X); q <- ncol(Z); pc <- ncol(X)
  XtX <- crossprod(Z)
  lam2 <- rep(1, pc); nu <- rep(1, pc); tau2 <- 1; xi <- 1; beta <- rep(0, q)
  keep <- iter - burn; out <- matrix(0, keep, q); tau_out <- numeric(keep)
  for (it in seq_len(iter)) {
    eta <- as.numeric(Z %*% beta)
    u <- runif(n); lo <- ifelse(y == 1, pnorm(-eta), 0); hi <- ifelse(y == 1, 1, pnorm(-eta))
    zl <- eta + qnorm(pmin(pmax(lo + u * (hi - lo), 1e-12), 1 - 1e-12))
    prec <- c(1 / 100, 1 / 4, 1 / (tau2 * lam2))
    A <- XtX + diag(prec); R <- chol(A)
    m <- backsolve(R, forwardsolve(t(R), crossprod(Z, zl)))
    beta <- as.numeric(m + backsolve(R, rnorm(q)))
    bc <- beta[-(1:2)]
    lam2 <- rinvgamma(pc, 1, 1 / nu + bc^2 / (2 * tau2)); nu <- rinvgamma(pc, 1, 1 + 1 / lam2)
    tau2 <- rinvgamma(1, (pc + 1) / 2, 1 / xi + sum(bc^2 / lam2) / 2); xi <- rinvgamma(1, 1, 1 + 1 / tau2)
    if (it > burn) { out[it - burn, ] <- beta; tau_out[it - burn] <- sqrt(tau2) }
  }
  colnames(out) <- c("intercept", "lexp", colnames(X)); list(draws = out, tau = tau_out)
}

# Same sampler with a fixed normal (ridge-type) prior on the covariate effects instead of the horseshoe.
probit_ridge <- function(y, lexp, X, ridge_sd = 1, iter = 1200L, burn = 400L) {
  n <- length(y); Z <- cbind(1, lexp, X); q <- ncol(Z); beta <- rep(0, q)
  XtX <- crossprod(Z); prec <- diag(c(1 / 100, 1 / 4, rep(1 / ridge_sd^2, ncol(X)))); R <- chol(XtX + prec)
  out <- matrix(0, iter - burn, q)
  for (it in seq_len(iter)) {
    eta <- as.numeric(Z %*% beta); u <- runif(n); lo <- ifelse(y == 1, pnorm(-eta), 0); hi <- ifelse(y == 1, 1, pnorm(-eta))
    zl <- eta + qnorm(pmin(pmax(lo + u * (hi - lo), 1e-12), 1 - 1e-12))
    m <- backsolve(R, forwardsolve(t(R), crossprod(Z, zl))); beta <- as.numeric(m + backsolve(R, rnorm(q)))
    if (it > burn) out[it - burn, ] <- beta
  }
  colnames(out) <- c("intercept", "lexp", colnames(X)); list(draws = out)
}
