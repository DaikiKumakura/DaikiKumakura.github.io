# Diagnostic for the exposure-effect estimates at n = 120: is the overestimate by the full model a small-sample
# property of maximum likelihood, and does a plain normal (ridge-type) prior on the covariates remove it?
script_dir <- dirname(normalizePath(sub("^--file=", "", grep("^--file=", commandArgs(FALSE), value = TRUE)[1]), winslash = "/"))
source(file.path(script_dir, "common.R")); set.seed(20261117L)
NREP <- 150L; N <- 120L; cal <- calibrate(); a_r <- cal[["a_r"]]; a_s <- cal[["a_s"]]
rows <- lapply(seq_len(NREP), function(k) {
  pat <- draw_patients(N); dose <- sample(DOSES, N, TRUE); le <- log(dose) - pat$lncl
  y <- list(orr = rbinom(N, 1, pnorm(a_r + THETA_R * le + pat$X %*% B_R)), ae = rbinom(N, 1, pnorm(a_s + THETA_S * le + pat$X %*% B_S)))
  do.call(rbind, lapply(names(y), function(ep) {
    d <- data.frame(y = y[[ep]], lexp = le, pat$X)
    full <- suppressWarnings(glm(y ~ ., d, family = binomial("probit")))
    only <- suppressWarnings(glm(y ~ lexp, d, family = binomial("probit")))
    hs <- probit_horseshoe(y[[ep]], le, pat$X, iter = 1200L, burn = 400L); rg <- probit_ridge(y[[ep]], le, pat$X, 1, 1200L, 400L)
    data.frame(trial = k, endpoint = ep, full_ml = coef(full)["lexp"], exposure_only_ml = coef(only)["lexp"],
               horseshoe = mean(hs$draws[, "lexp"]), ridge_sd1 = mean(rg$draws[, "lexp"]), row.names = NULL)
  }))
})
res <- do.call(rbind, rows); write.csv(res, file.path(script_dir, "results/exposure-check.csv"), row.names = FALSE)
tru <- c(orr = THETA_R, ae = THETA_S)
sm <- do.call(rbind, lapply(split(res, res$endpoint), function(x) do.call(rbind, lapply(c("full_ml", "exposure_only_ml", "horseshoe", "ridge_sd1"), function(m)
  data.frame(endpoint = x$endpoint[1], method = m, true = tru[[x$endpoint[1]]], mean = mean(x[[m]]), median = median(x[[m]]), sd = sd(x[[m]]), se_mean = sd(x[[m]]) / sqrt(nrow(x)))))))
write.csv(sm, file.path(script_dir, "results/exposure-check-summary.csv"), row.names = FALSE); print(within(sm, { mean <- round(mean, 3); median <- round(median, 3); sd <- round(sd, 3); se_mean <- round(se_mean, 3) }), row.names = FALSE)
