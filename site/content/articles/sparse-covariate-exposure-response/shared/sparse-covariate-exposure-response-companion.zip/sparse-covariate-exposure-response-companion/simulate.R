# Sparse covariate selection in exposure-response models and the dose decision (probit, 20 candidate covariates).
# Run: Rscript simulate.R [reps] [iterations]    (defaults: 200 replicates per sample size, 1500 Gibbs iterations)
script_dir <- dirname(normalizePath(sub("^--file=", "", grep("^--file=", commandArgs(FALSE), value = TRUE)[1]), winslash = "/"))
source(file.path(script_dir, "common.R"))
args <- commandArgs(trailingOnly = TRUE)
NREP <- if (length(args) >= 1) as.integer(args[1]) else 200L
ITER <- if (length(args) >= 2) as.integer(args[2]) else 1500L
SEED <- 20261115L; NS <- c(120L, 300L); N_VAL <- 3000L; N_DRAW <- 200L
set.seed(SEED)
cal <- calibrate(); a_r <- cal[["a_r"]]; a_s <- cal[["a_s"]]
truth_pat <- draw_patients(400000L); TRUTH <- true_rates(a_r, a_s, truth_pat)
rownames(TRUTH) <- c("orr", "ae"); colnames(TRUTH) <- paste0("dose", DOSES)
feasible_true <- TRUTH["ae", ] <= AE_LIMIT; BEST <- which.max(ifelse(feasible_true, TRUTH["orr", ], -Inf))
stopifnot(BEST == 2)
write.csv(data.frame(endpoint = rownames(TRUTH), round(TRUTH, 4)), file.path(script_dir, "results/truth.csv"), row.names = FALSE)

pick <- function(orr, ae) { f <- ae <= AE_LIMIT; if (!any(f)) 1L else which.max(ifelse(f, orr, -Inf)) }
pred_probit <- function(beta_mat, pat, d) {            # beta_mat: draws x (2 + p); returns draws x patients
  lexp <- log(d) - pat$lncl; pnorm(beta_mat[, 1] + outer(beta_mat[, 2], lexp) + tcrossprod(beta_mat[, -(1:2), drop = FALSE], pat$X))
}
select_flags <- function(est, se, true_idx) {          # est/se over the covariate coefficients only
  sig <- abs(est / se) > 1.96
  c(power = mean(sig[true_idx]), false = sum(sig[-true_idx]))
}

one_rep <- function(n) {
  pat <- draw_patients(n); dose <- sample(DOSES, n, replace = TRUE); le <- log(dose) - pat$lncl
  y_r <- rbinom(n, 1, pnorm(a_r + THETA_R * le + pat$X %*% B_R)); y_s <- rbinom(n, 1, pnorm(a_s + THETA_S * le + pat$X %*% B_S))
  val <- draw_patients(N_VAL); rows <- list()
  true_r <- which(names(B_R) %in% names(BETA_R)); true_s <- which(names(B_S) %in% names(BETA_S))
  fit_set <- function(y, which_ep) {
    tr_idx <- if (which_ep == "orr") true_r else true_s; th <- if (which_ep == "orr") THETA_R else THETA_S
    d <- data.frame(y = y, lexp = le, pat$X)
    full <- glm(y ~ ., d, family = binomial("probit"))
    step <- suppressWarnings(stepAIC(full, scope = list(lower = y ~ lexp), direction = "backward", trace = 0))
    hs <- probit_horseshoe(y, le, pat$X, iter = ITER, burn = ITER / 3)
    # predictions at each dose for the validation patients
    cf <- coef(full); cf[is.na(cf)] <- 0
    pf <- sapply(DOSES, function(dd) mean(pnorm(cf[1] + cf[2] * (log(dd) - val$lncl) + val$X %*% cf[-(1:2)])))
    cs <- setNames(rep(0, 2 + P_COV), names(cf)); cs[names(coef(step))] <- coef(step)
    ps <- sapply(DOSES, function(dd) mean(pnorm(cs[1] + cs[2] * (log(dd) - val$lncl) + val$X %*% cs[-(1:2)])))
    idx <- sample(nrow(hs$draws), N_DRAW); bd <- hs$draws[idx, , drop = FALSE]
    ph <- sapply(DOSES, function(dd) rowMeans(pred_probit(bd, val, dd)))          # draws x doses
    hs_mean <- colMeans(ph)
    sf <- summary(full)$coefficients[-(1:2), , drop = FALSE]
    flags_full <- select_flags(sf[, 1], sf[, 2], tr_idx)
    kept <- setdiff(names(coef(step)), c("(Intercept)", "lexp"))
    flags_step <- c(power = mean(names(B_R)[tr_idx] %in% kept), false = sum(!(kept %in% names(B_R)[tr_idx])))
    q <- apply(hs$draws[, -(1:2)], 2, quantile, c(0.05, 0.95)); sig <- q[1, ] > 0 | q[2, ] < 0
    flags_hs <- c(power = mean(sig[tr_idx]), false = sum(sig[-tr_idx]))
    list(pred = list(full = pf, stepwise = ps, horseshoe = hs_mean), post = ph, flags = list(full = flags_full, stepwise = flags_step, horseshoe = flags_hs),
         theta = list(full = cf[2], stepwise = cs[2], horseshoe = mean(hs$draws[, 2])), true_theta = th,
         noise_abs = list(full = mean(abs(cf[-(1:2)][-tr_idx])), stepwise = mean(abs(cs[-(1:2)][-tr_idx])), horseshoe = mean(abs(colMeans(hs$draws[, -(1:2)])[-tr_idx]))),
         true_abs_err = list(full = mean(abs(cf[-(1:2)][tr_idx] - (if (which_ep == "orr") BETA_R else BETA_S))), stepwise = mean(abs(cs[-(1:2)][tr_idx] - (if (which_ep == "orr") BETA_R else BETA_S))),
                             horseshoe = mean(abs(colMeans(hs$draws[, -(1:2)])[tr_idx] - (if (which_ep == "orr") BETA_R else BETA_S)))),
         ess_tau = NA)
  }
  r <- fit_set(y_r, "orr"); s <- fit_set(y_s, "ae")
  do.call(rbind, lapply(c("full", "stepwise", "horseshoe"), function(m) {
    orr <- r$pred[[m]]; ae <- s$pred[[m]]; ch <- pick(orr, ae)
    prob_best <- NA_real_
    if (m == "horseshoe") { # posterior probability that each dose is the best feasible one
      sel <- vapply(seq_len(nrow(r$post)), function(k) pick(r$post[k, ], s$post[k, ]), 1L); prob_best <- mean(sel == BEST) }
    data.frame(model = m, n = n, chosen = ch, correct = as.integer(ch == BEST), prob_best = prob_best,
               err_orr = mean(abs(orr - TRUTH["orr", ])), err_ae = mean(abs(ae - TRUTH["ae", ])),
               ae_dose2 = ae[2], ae_dose3 = ae[3],
               power_orr = r$flags[[m]]["power"], false_orr = r$flags[[m]]["false"], power_ae = s$flags[[m]]["power"], false_ae = s$flags[[m]]["false"],
               noise_abs_orr = r$noise_abs[[m]], noise_abs_ae = s$noise_abs[[m]], true_err_orr = r$true_abs_err[[m]], true_err_ae = s$true_abs_err[[m]],
               theta_orr = r$theta[[m]], theta_ae = s$theta[[m]], row.names = NULL)
  }))
}
res <- list()
for (n in NS) { t0 <- Sys.time()
  for (k in seq_len(NREP)) { r <- one_rep(n); r$rep <- k; res[[length(res) + 1]] <- r }
  cat("n =", n, format(round(difftime(Sys.time(), t0, units = "mins"), 1)), "\n") }
res <- do.call(rbind, res)
write.csv(res, file.path(script_dir, "results/replicates.csv"), row.names = FALSE)
writeLines(capture.output(sessionInfo()), file.path(script_dir, "results/session-info.txt"))
