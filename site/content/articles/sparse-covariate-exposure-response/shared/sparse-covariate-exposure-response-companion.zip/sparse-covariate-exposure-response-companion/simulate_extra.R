# Extra comparison for the sparse-covariate study: adds a lasso (glmnet, logit link, exposure unpenalized, lambda.1se)
# and a Jeffreys-penalized (Firth-type) probit to the full / stepwise / horseshoe methods, and varies the toxicity margin.
# Run: Rscript simulate_extra.R <config: orig|narrow> [reps=150] [iterations=1200]
suppressPackageStartupMessages(library(glmnet))
script_dir <- dirname(normalizePath(sub("^--file=", "", grep("^--file=", commandArgs(FALSE), value = TRUE)[1]), winslash = "/"))
source(file.path(script_dir, "common.R"))
args <- commandArgs(trailingOnly = TRUE); CONFIG <- args[1]; NREP <- if (length(args) >= 2) as.integer(args[2]) else 150L; ITER <- if (length(args) >= 3) as.integer(args[3]) else 1200L
stopifnot(CONFIG %in% c("orig", "narrow"))
SEED <- if (CONFIG == "orig") 20261118L else 20261119L; NS <- c(120L, 300L); N_VAL <- 3000L
set.seed(SEED)
cal <- calibrate(target_ae1 = if (CONFIG == "orig") 0.08 else 0.10); a_r <- cal[["a_r"]]; a_s <- cal[["a_s"]]
TRUTH <- true_rates(a_r, a_s, draw_patients(400000L)); rownames(TRUTH) <- c("orr", "ae")
BEST <- which.max(ifelse(TRUTH["ae", ] <= AE_LIMIT, TRUTH["orr", ], -Inf)); stopifnot(BEST == 2)
write.csv(data.frame(config = CONFIG, endpoint = rownames(TRUTH), round(TRUTH, 4)), file.path(script_dir, paste0("results/truth-extra-", CONFIG, ".csv")), row.names = FALSE)
pick <- function(orr, ae) { f <- ae <= AE_LIMIT; if (!any(f)) 1L else which.max(ifelse(f, orr, -Inf)) }

# Jeffreys-penalized probit: maximize loglik + 0.5 log det(Z' W Z), W = phi(eta)^2 / (Phi (1 - Phi)).
firth_probit <- function(y, Z, start) {
  f <- function(b) { eta <- as.numeric(Z %*% b); p <- pmin(pmax(pnorm(eta), 1e-10), 1 - 1e-10); w <- dnorm(eta)^2 / (p * (1 - p))
    -(sum(y * log(p) + (1 - y) * log(1 - p)) + 0.5 * as.numeric(determinant(crossprod(Z, Z * w), logarithm = TRUE)$modulus)) }
  optim(start, f, method = "BFGS", control = list(maxit = 200, reltol = 1e-9))$par
}
one_rep <- function(n) {
  pat <- draw_patients(n); dose <- sample(DOSES, n, TRUE); le <- log(dose) - pat$lncl
  Y <- list(orr = rbinom(n, 1, pnorm(a_r + THETA_R * le + pat$X %*% B_R)), ae = rbinom(n, 1, pnorm(a_s + THETA_S * le + pat$X %*% B_S)))
  val <- draw_patients(N_VAL); Zv <- function(dd) cbind(1, log(dd) - val$lncl, val$X)
  est <- list()
  for (ep in c("orr", "ae")) {
    y <- Y[[ep]]; Z <- cbind(1, le, pat$X); d <- data.frame(y = y, lexp = le, pat$X)
    full <- suppressWarnings(glm(y ~ ., d, family = binomial("probit"))); cf <- coef(full); cf[is.na(cf)] <- 0
    step <- suppressWarnings(MASS::stepAIC(full, scope = list(lower = y ~ lexp), direction = "backward", trace = 0)); cs <- setNames(rep(0, length(cf)), names(cf)); cs[names(coef(step))] <- coef(step)
    hs <- probit_horseshoe(y, le, pat$X, iter = ITER, burn = ITER / 3); ch <- colMeans(hs$draws); names(ch) <- names(cf)
    pf <- c(1, rep(0, 0)); cvf <- cv.glmnet(cbind(le, pat$X), y, family = "binomial", penalty.factor = c(0, rep(1, P_COV)), nfolds = 5)
    cl <- as.numeric(coef(cvf, s = "lambda.1se")); names(cl) <- names(cf)
    cj <- tryCatch(firth_probit(y, Z, start = ifelse(is.finite(cf), cf, 0) * 0.5), error = function(e) rep(NA_real_, length(cf))); names(cj) <- names(cf)
    est[[ep]] <- list(full = cf, stepwise = cs, horseshoe = ch, lasso = cl, firth = cj)
  }
  rows <- lapply(c("full", "stepwise", "horseshoe", "lasso", "firth"), function(m) {
    pr <- function(ep, dd) { b <- est[[ep]][[m]]; if (m == "lasso") plogis(b[1] + b[2] * (log(dd) - val$lncl) + val$X %*% b[-(1:2)]) else pnorm(Zv(dd) %*% b) }
    orr <- sapply(DOSES, function(dd) mean(pr("orr", dd))); ae <- sapply(DOSES, function(dd) mean(pr("ae", dd)))
    sel <- function(ep, true_names) { b <- est[[ep]][[m]][-(1:2)]; kept <- if (m %in% c("horseshoe", "full", "firth")) NA else names(b)[b != 0]
      if (m == "stepwise" || m == "lasso") c(power = mean(true_names %in% kept), false = sum(!(kept %in% true_names))) else c(power = NA, false = NA) }
    sr <- sel("orr", names(BETA_R)); sa <- sel("ae", names(BETA_S))
    failed <- anyNA(orr) || anyNA(ae) || any(!is.finite(c(orr, ae)))   # a fit that did not produce rates (counted, not hidden)
    ch <- if (failed) NA_integer_ else pick(orr, ae)
    data.frame(config = CONFIG, model = m, n = n, failed = as.integer(failed), chosen = ch, correct = as.integer(ch == BEST), err_orr = mean(abs(orr - TRUTH["orr", ])), err_ae = mean(abs(ae - TRUTH["ae", ])),
               false_orr = sr[["false"]], power_orr = sr[["power"]], false_ae = sa[["false"]], power_ae = sa[["power"]],
               theta_orr = est$orr[[m]][2], theta_ae = est$ae[[m]][2], row.names = NULL)
  })
  do.call(rbind, rows)
}
res <- list()
for (n in NS) { t0 <- Sys.time(); for (k in seq_len(NREP)) { r <- one_rep(n); r$rep <- k; res[[length(res) + 1]] <- r }; cat(CONFIG, "n =", n, format(round(difftime(Sys.time(), t0, units = "mins"), 1)), "\n") }
write.csv(do.call(rbind, res), file.path(script_dir, paste0("results/replicates-extra-", CONFIG, ".csv")), row.names = FALSE)
