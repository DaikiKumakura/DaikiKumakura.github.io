# Which exposure metric drives toxicity, and can an exposure-response analysis tell? Single-schedule versus multi-schedule dose-finding studies.
# One-compartment oral PK with between-subject variability; steady-state metrics AUC (weekly), Cmax and Cmin; logistic toxicity driven by one true metric.
# R 4.5.3, base R only (parallel for the study loop).
# Run: Rscript simulate.R 2000 [cores]   (studies per cell; seed 20261124; each study uses set.seed(SEED + index), so results do not depend on the number of cores)
script_dir <- dirname(normalizePath(sub("^--file=", "", grep("^--file=", commandArgs(FALSE), value = TRUE)[1]), winslash = "/"))
args <- commandArgs(trailingOnly = TRUE)
SEED <- 20261124L; NREP <- if (length(args) >= 1) as.integer(args[1]) else 2000L
NCORES <- if (length(args) >= 2) as.integer(args[2]) else 6L
TCL <- 5; TV <- 170; TKA <- 1                 # L/h, L, 1/h (elimination half-life about 24 h)
OMEGA <- c(CL = 0.30, V = 0.20, ka = 0.50)    # between-subject SD on the log scale
WEEKLY <- c(70, 140, 280, 560)                # mg per week
SCHED <- list(BID = 14, QD = 7, QW = 1)       # doses per week (twice daily, daily, once weekly)
SLOPES <- c(1.5, 0.75)                        # log-odds of toxicity per natural-log unit of the true metric (main, shallower)
TOX_REF <- 0.20; REF_ID <- "QD_280"           # toxicity rate of the reference regimen in the PK bank (sets the intercept)
CAP <- 0.25                                   # highest acceptable toxicity rate
N_TOTAL <- c(48, 96, 192, 384)                # patients per study
DESIGNS <- list(single = "QD", two = c("QD", "QW"), three = c("BID", "QD", "QW"), qdbid = c("BID", "QD"))   # schedules randomized in the study (each with the four weekly doses)
BANK_N <- 20000L                              # individuals in the PK bank; studies draw from it, predictions use the first 5000
METRICS <- c("AUC", "Cmax", "Cmin")
expit <- function(x) 1 / (1 + exp(-x))

make_bank <- function() {
  set.seed(SEED)
  list(cl = TCL * exp(rnorm(BANK_N, 0, OMEGA["CL"])), v = TV * exp(rnorm(BANK_N, 0, OMEGA["V"])), ka = TKA * exp(rnorm(BANK_N, 0, OMEGA["ka"])))
}
# Steady-state metrics of a regimen with n_per_week equal oral doses at equal intervals (first-order absorption and elimination, bioavailability 1).
# Within a dosing interval of tau hours, C(t) = dose*ka / (V*(ka-ke)) * (exp(-ke t)/(1-exp(-ke tau)) - exp(-ka t)/(1-exp(-ka tau))). AUC is the weekly AUC, weekly dose / CL.
# Cmax and Cmin are the maximum and minimum over one steady-state dosing interval (0.25 h grid).
metrics_for <- function(bank, weekly, n_per_week) {
  ke <- bank$cl / bank$v; ka <- bank$ka; v <- bank$v
  dose <- weekly / n_per_week; tau <- 168 / n_per_week; tg <- seq(0.25, tau, by = 0.25)
  cmax <- cmin <- numeric(length(ke))
  chunk <- split(seq_along(ke), ceiling(seq_along(ke) / 2000))
  for (idx in chunk) {
    conc <- dose * ka[idx] / (v[idx] * (ka[idx] - ke[idx])) * (exp(-outer(ke[idx], tg)) / (1 - exp(-ke[idx] * tau)) - exp(-outer(ka[idx], tg)) / (1 - exp(-ka[idx] * tau)))
    cmax[idx] <- apply(conc, 1, max); cmin[idx] <- apply(conc, 1, min)
  }
  data.frame(AUC = weekly / bank$cl, Cmax = cmax, Cmin = cmin)
}
regimens <- expand.grid(sched = names(SCHED), weekly = WEEKLY, stringsAsFactors = FALSE)
regimens$id <- paste0(regimens$sched, "_", regimens$weekly)

bank <- make_bank()
MET <- lapply(seq_len(nrow(regimens)), function(i) log(metrics_for(bank, regimens$weekly[i], SCHED[[regimens$sched[i]]])))   # log metrics per regimen
names(MET) <- regimens$id
# Intercept for each slope and true metric: toxicity of the reference regimen in the bank equals TOX_REF
intercepts <- lapply(SLOPES, function(s) sapply(METRICS, function(m) uniroot(function(a) mean(expit(a + s * MET[[REF_ID]][[m]])) - TOX_REF, c(-30, 30))$root))
names(intercepts) <- as.character(SLOPES)
true_tox <- function(s, truth) sapply(regimens$id, function(id) mean(expit(intercepts[[as.character(s)]][[truth]] + s * MET[[id]][[truth]])))
TRUE_TOX <- lapply(SLOPES, function(s) { x <- lapply(METRICS, function(m) true_tox(s, m)); names(x) <- METRICS; x }); names(TRUE_TOX) <- as.character(SLOPES)
PRED_IDX <- 1:5000
# Choice of regimen from predicted toxicity: highest weekly dose with predicted rate <= CAP; ties broken by fewest doses (QW, QD, BID) or by most doses
choose_set <- function(pred) {   # regimens with the highest weekly dose among those with predicted toxicity <= CAP
  ok <- which(pred <= CAP); if (length(ok) == 0) return(integer(0))
  ok[regimens$weekly[ok] == max(regimens$weekly[ok])]
}
choose <- function(pred, tie = "fewest") {
  best <- choose_set(pred); if (length(best) == 0) return(NA_integer_)
  nd <- unlist(SCHED[regimens$sched[best]]); best[if (tie == "fewest") which.min(nd) else which.max(nd)]
}
OPT <- lapply(SLOPES, function(s) { x <- lapply(METRICS, function(m) list(fewest = choose(TRUE_TOX[[as.character(s)]][[m]], "fewest"), most = choose(TRUE_TOX[[as.character(s)]][[m]], "most"))); names(x) <- METRICS; x })
names(OPT) <- as.character(SLOPES)
design_arms <- function(design) regimens[regimens$sched %in% DESIGNS[[design]], ]
one_study <- function(task) {
  set.seed(SEED + task$index)
  arms <- design_arms(task$design); arm <- rep(seq_len(nrow(arms)), length.out = task$n)
  ind <- sample(BANK_N, task$n)
  X <- sapply(METRICS, function(m) sapply(seq_len(task$n), function(j) MET[[arms$id[arm[j]]]][[m]][ind[j]]))
  y <- rbinom(task$n, 1, expit(intercepts[[as.character(task$slope)]][[task$truth]] + task$slope * X[, task$truth]))
  fits <- lapply(METRICS, function(m) suppressWarnings(glm(y ~ x, binomial, data.frame(y = y, x = X[, m]))))
  names(fits) <- METRICS; aic <- sapply(fits, AIC)
  sel <- METRICS[which.min(aic)]; gap <- unname(sort(aic)[2] - sort(aic)[1])
  pr <- lapply(METRICS, function(m) { b <- coef(fits[[m]]); sapply(regimens$id, function(id) mean(expit(b[[1]] + b[[2]] * MET[[id]][[m]][PRED_IDX]))) })
  names(pr) <- METRICS
  tt_all <- TRUE_TOX[[as.character(task$slope)]][[task$truth]]
  out <- c(corr_AUC_Cmax = cor(X[, "AUC"], X[, "Cmax"]), corr_AUC_Cmin = cor(X[, "AUC"], X[, "Cmin"]), corr_Cmax_Cmin = cor(X[, "Cmax"], X[, "Cmin"]),
           selected = match(sel, METRICS), gap = gap, correct = as.numeric(sel == task$truth))
  for (rule in c("selected", "AUC", "Cmax", "Cmin", "oracle")) for (tie in c("fewest", "most")) {
    m <- switch(rule, selected = sel, oracle = task$truth, rule); ch <- choose(pr[[m]], tie)
    out[paste0(rule, "_", tie, "_true_tox")] <- if (is.na(ch)) NA_real_ else tt_all[ch]
    out[paste0(rule, "_", tie, "_weekly")] <- if (is.na(ch)) 0 else regimens$weekly[ch]
  }
  for (rule in c("selected", "AUC", "Cmax", "Cmin", "oracle")) {   # ties resolved at random: expected share of overdose over the tied regimens
    m <- switch(rule, selected = sel, oracle = task$truth, rule); set <- choose_set(pr[[m]])
    out[paste0(rule, "_random_over")] <- if (length(set) == 0) NA_real_ else mean(tt_all[set] > CAP + 0.05)
  }
  out
}

cells <- rbind(expand.grid(slope = SLOPES, truth = METRICS, design = c("single", "two", "three"), n = N_TOTAL, stringsAsFactors = FALSE),
               expand.grid(slope = SLOPES, truth = METRICS, design = "qdbid", n = N_TOTAL, stringsAsFactors = FALSE))   # the QD-and-BID design is appended so that the other cells keep their seeds
cells$cell <- seq_len(nrow(cells))
tasks <- do.call(c, lapply(seq_len(nrow(cells)), function(i) lapply(seq_len(NREP), function(r) list(index = (i - 1) * NREP + r, slope = cells$slope[i], truth = cells$truth[i], design = cells$design[i], n = cells$n[i]))))
if (!exists("PROBE_ONLY")) {
  cl <- parallel::makeCluster(NCORES)
  parallel::clusterExport(cl, c("SEED", "BANK_N", "METRICS", "regimens", "MET", "intercepts", "TRUE_TOX", "PRED_IDX", "CAP", "SCHED", "DESIGNS", "expit", "choose_set", "choose", "design_arms", "one_study"))
  res <- parallel::parLapplyLB(cl, tasks, one_study); parallel::stopCluster(cl)
  mat <- do.call(rbind, res)
  dir.create(file.path(script_dir, "results"), showWarnings = FALSE)
  rows <- list()
  for (i in seq_len(nrow(cells))) {
    m <- mat[seq((i - 1) * NREP + 1, i * NREP), , drop = FALSE]
    r <- data.frame(slope = cells$slope[i], truth = cells$truth[i], design = cells$design[i], n_total = cells$n[i], studies = NREP,
      corr_AUC_Cmax = mean(m[, "corr_AUC_Cmax"]), corr_AUC_Cmin = mean(m[, "corr_AUC_Cmin"]), corr_Cmax_Cmin = mean(m[, "corr_Cmax_Cmin"]),
      p_correct_metric = mean(m[, "correct"]), p_correct_gap2 = mean(m[, "correct"] == 1 & m[, "gap"] >= 2), p_ambiguous = mean(m[, "gap"] < 2),
      share_AUC = mean(m[, "selected"] == 1), share_Cmax = mean(m[, "selected"] == 2), share_Cmin = mean(m[, "selected"] == 3))
    for (rule in c("selected", "AUC", "Cmax", "Cmin", "oracle")) for (tie in c("fewest", "most")) {
      tt <- m[, paste0(rule, "_", tie, "_true_tox")]; wk <- m[, paste0(rule, "_", tie, "_weekly")]
      r[[paste0(rule, "_", tie, "_over_cap5")]] <- mean(!is.na(tt) & tt > CAP + 0.05)
      r[[paste0(rule, "_", tie, "_true_tox_mean")]] <- mean(tt, na.rm = TRUE)
      r[[paste0(rule, "_", tie, "_weekly_mean")]] <- mean(wk)
      r[[paste0(rule, "_", tie, "_none")]] <- mean(is.na(tt))
    }
    for (rule in c("selected", "AUC", "Cmax", "Cmin", "oracle")) r[[paste0(rule, "_random_over_cap5")]] <- mean(m[, paste0(rule, "_random_over")], na.rm = TRUE)
    rows[[i]] <- r
  }
  out <- do.call(rbind, rows)
  write.csv(out, file.path(script_dir, "results/summary.csv"), row.names = FALSE)
  tx <- do.call(rbind, lapply(SLOPES, function(s) data.frame(slope = s, regimens[, c("id", "sched", "weekly")], tox_AUC = TRUE_TOX[[as.character(s)]]$AUC, tox_Cmax = TRUE_TOX[[as.character(s)]]$Cmax, tox_Cmin = TRUE_TOX[[as.character(s)]]$Cmin)))
  write.csv(tx, file.path(script_dir, "results/true-toxicity.csv"), row.names = FALSE)
  cal <- do.call(rbind, lapply(SLOPES, function(s) data.frame(slope = s, truth = METRICS, intercept = unlist(intercepts[[as.character(s)]]),
    opt_fewest = regimens$id[sapply(OPT[[as.character(s)]], `[[`, "fewest")], opt_most = regimens$id[sapply(OPT[[as.character(s)]], `[[`, "most")])))
  write.csv(cal, file.path(script_dir, "results/calibration.csv"), row.names = FALSE)
  corr <- do.call(rbind, lapply(names(MET), function(id) data.frame(regimen = id, mean_log_AUC = mean(MET[[id]]$AUC), mean_log_Cmax = mean(MET[[id]]$Cmax), mean_log_Cmin = mean(MET[[id]]$Cmin))))
  write.csv(corr, file.path(script_dir, "results/regimen-metric-means.csv"), row.names = FALSE)
  writeLines(capture.output(sessionInfo()), file.path(script_dir, "results/session-info.txt"))
  options(width = 250); o <- out[out$slope == 1.5, c("truth", "design", "n_total", "corr_AUC_Cmax", "p_correct_metric", "p_ambiguous", "selected_fewest_over_cap5", "AUC_fewest_over_cap5", "oracle_fewest_over_cap5")]; print(o, digits = 3, row.names = FALSE)
}
