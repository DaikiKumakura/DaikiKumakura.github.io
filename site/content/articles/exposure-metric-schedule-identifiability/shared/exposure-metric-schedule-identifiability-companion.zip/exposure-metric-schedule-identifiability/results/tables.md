@@T1
| Regimen | Weekly dose (mg) | True driver AUC | True driver Cmax | True driver Cmin |
| --- | --- | --- | --- | --- |
| BID | 70 | 0.031 | 0.025 | 0.041 |
| QD | 70 | 0.031 | 0.031 | 0.032 |
| QW | 70 | 0.031 | 0.166 | 0.002 |
| BID | 140 | 0.083 | 0.068 | 0.107 |
| QD | 140 | 0.083 | 0.082 | 0.085 |
| QW | 140 | 0.083 | 0.356 | 0.005 |
| BID | 280 | 0.200 | 0.169 | 0.245 |
| QD | 280 | 0.200 | 0.200 | 0.200 |
| QW | 280 | 0.200 | 0.606 | 0.013 |
| BID | 560 | 0.404 | 0.358 | 0.465 |
| QD | 560 | 0.404 | 0.408 | 0.397 |
| QW | 560 | 0.404 | 0.811 | 0.032 |
@@T2
| Design | Log AUC and log Cmax | Log AUC and log Cmin | Log Cmax and log Cmin |
| --- | --- | --- | --- |
| One schedule (QD) | 0.994 | 0.987 | 0.963 |
| Two schedules (BID, QD) | 0.992 | 0.985 | 0.955 |
| Two schedules (QD, QW) | 0.761 | 0.483 | −0.174 |
| Three schedules (BID, QD, QW) | 0.772 | 0.483 | −0.162 |
@@T3
| True driver | Design | 48 patients | 96 patients | 192 patients | 384 patients |
| --- | --- | --- | --- | --- | --- |
| AUC | One schedule (QD) | 0.146 | 0.205 | 0.286 | 0.402 |
| AUC | Two schedules (BID, QD) | 0.153 | 0.231 | 0.319 | 0.433 |
| AUC | Two schedules (QD, QW) | 0.756 | 0.907 | 0.981 | 0.999 |
| AUC | Three schedules (BID, QD, QW) | 0.749 | 0.887 | 0.973 | 0.998 |
| Cmax | One schedule (QD) | 0.539 | 0.603 | 0.630 | 0.669 |
| Cmax | Two schedules (BID, QD) | 0.557 | 0.574 | 0.638 | 0.684 |
| Cmax | Two schedules (QD, QW) | 0.926 | 0.977 | 0.998 | 1.000 |
| Cmax | Three schedules (BID, QD, QW) | 0.905 | 0.973 | 0.999 | 1.000 |
| Cmin | One schedule (QD) | 0.596 | 0.610 | 0.692 | 0.748 |
| Cmin | Two schedules (BID, QD) | 0.611 | 0.657 | 0.702 | 0.757 |
| Cmin | Two schedules (QD, QW) | 0.938 | 0.981 | 0.998 | 1.000 |
| Cmin | Three schedules (BID, QD, QW) | 0.946 | 0.979 | 1.000 | 1.000 |
@@T4
| True driver | Design | 48 patients | 96 patients | 192 patients | 384 patients |
| --- | --- | --- | --- | --- | --- |
| AUC | One schedule (QD) | 0.978 | 0.956 | 0.912 | 0.870 |
| AUC | Two schedules (BID, QD) | 0.972 | 0.939 | 0.888 | 0.842 |
| AUC | Two schedules (QD, QW) | 0.404 | 0.152 | 0.035 | 0.003 |
| AUC | Three schedules (BID, QD, QW) | 0.386 | 0.171 | 0.035 | 0.002 |
| Cmax | One schedule (QD) | 0.984 | 0.941 | 0.857 | 0.730 |
| Cmax | Two schedules (BID, QD) | 0.962 | 0.926 | 0.842 | 0.683 |
| Cmax | Two schedules (QD, QW) | 0.109 | 0.032 | 0.002 | 0.000 |
| Cmax | Three schedules (BID, QD, QW) | 0.136 | 0.030 | 0.002 | 0.000 |
| Cmin | One schedule (QD) | 0.968 | 0.905 | 0.768 | 0.551 |
| Cmin | Two schedules (BID, QD) | 0.946 | 0.848 | 0.706 | 0.492 |
| Cmin | Two schedules (QD, QW) | 0.139 | 0.029 | 0.004 | 0.000 |
| Cmin | Three schedules (BID, QD, QW) | 0.105 | 0.029 | 0.002 | 0.001 |
@@T6
| True driver | Design | 48 patients | 96 patients | 192 patients | 384 patients |
| --- | --- | --- | --- | --- | --- |
| AUC | One schedule (QD) | 0.093 | 0.121 | 0.161 | 0.232 |
| AUC | Two schedules (BID, QD) | 0.099 | 0.142 | 0.181 | 0.250 |
| AUC | Two schedules (QD, QW) | 0.492 | 0.652 | 0.813 | 0.923 |
| AUC | Three schedules (BID, QD, QW) | 0.495 | 0.644 | 0.802 | 0.936 |
| Cmax | One schedule (QD) | 0.514 | 0.538 | 0.534 | 0.586 |
| Cmax | Two schedules (BID, QD) | 0.524 | 0.533 | 0.570 | 0.593 |
| Cmax | Two schedules (QD, QW) | 0.678 | 0.840 | 0.942 | 0.980 |
| Cmax | Three schedules (BID, QD, QW) | 0.689 | 0.819 | 0.933 | 0.979 |
| Cmin | One schedule (QD) | 0.541 | 0.585 | 0.620 | 0.654 |
| Cmin | Two schedules (BID, QD) | 0.569 | 0.590 | 0.612 | 0.682 |
| Cmin | Two schedules (QD, QW) | 0.842 | 0.945 | 0.984 | 1.000 |
| Cmin | Three schedules (BID, QD, QW) | 0.856 | 0.945 | 0.988 | 0.998 |
@@T5
| True driver | Patients | Mean deviance, AUC model | Cmax model | Cmin model | Lowest deviance, AUC model | Cmax model | Cmin model | True model minus the lower of the other two (median) |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| AUC | 96 | 72.25 | 72.46 | 72.62 | 0.204 | 0.394 | 0.403 | 0.45 |
| AUC | 192 | 146.65 | 147.07 | 147.42 | 0.285 | 0.376 | 0.340 | 0.44 |
| AUC | 384 | 295.74 | 296.60 | 297.25 | 0.417 | 0.309 | 0.274 | 0.25 |
| Cmax | 96 | 73.22 | 73.02 | 74.09 | 0.182 | 0.575 | 0.244 | −0.15 |
| Cmax | 192 | 148.79 | 148.36 | 150.63 | 0.214 | 0.624 | 0.163 | −0.44 |
| Cmax | 384 | 299.42 | 298.57 | 303.07 | 0.243 | 0.678 | 0.080 | −0.89 |
| Cmin | 96 | 70.82 | 71.58 | 70.42 | 0.166 | 0.198 | 0.637 | −0.40 |
| Cmin | 192 | 144.41 | 145.95 | 143.62 | 0.217 | 0.105 | 0.679 | −0.79 |
| Cmin | 384 | 290.39 | 293.57 | 288.66 | 0.195 | 0.042 | 0.764 | −1.77 |
@@T7
| True driver | Design | Patients | AUC always: fewest doses | random | most doses | AIC choice: fewest doses | random | most doses | True metric known: fewest doses |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Cmax | One schedule (QD) | 96 | 1.000 | 0.361 | 0.042 | 0.445 | 0.344 | 0.294 | 0.086 |
| Cmax | One schedule (QD) | 384 | 1.000 | 0.333 | 0.000 | 0.334 | 0.163 | 0.078 | 0.004 |
| Cmax | Two schedules (QD, QW) | 96 | 0.705 | 0.236 | 0.000 | 0.053 | 0.039 | 0.033 | 0.034 |
| Cmax | Two schedules (QD, QW) | 384 | 0.833 | 0.278 | 0.000 | 0.000 | 0.000 | 0.000 | 0.000 |
| Cmax | Three schedules (BID, QD, QW) | 96 | 0.961 | 0.321 | 0.001 | 0.066 | 0.047 | 0.038 | 0.039 |
| Cmax | Three schedules (BID, QD, QW) | 384 | 1.000 | 0.333 | 0.000 | 0.000 | 0.000 | 0.000 | 0.000 |
| AUC | One schedule (QD) | 96 | 0.034 | 0.034 | 0.034 | 0.399 | 0.399 | 0.399 | 0.034 |
| AUC | One schedule (QD) | 384 | 0.001 | 0.001 | 0.001 | 0.278 | 0.278 | 0.278 | 0.001 |
| AUC | Two schedules (QD, QW) | 96 | 0.042 | 0.042 | 0.042 | 0.121 | 0.121 | 0.121 | 0.042 |
| AUC | Two schedules (QD, QW) | 384 | 0.001 | 0.001 | 0.001 | 0.003 | 0.003 | 0.003 | 0.001 |
| AUC | Three schedules (BID, QD, QW) | 96 | 0.037 | 0.037 | 0.037 | 0.125 | 0.125 | 0.125 | 0.037 |
| AUC | Three schedules (BID, QD, QW) | 384 | 0.000 | 0.000 | 0.000 | 0.002 | 0.002 | 0.002 | 0.000 |
| Cmin | One schedule (QD) | 96 | 0.000 | 0.017 | 0.026 | 0.015 | 0.026 | 0.035 | 0.000 |
| Cmin | One schedule (QD) | 384 | 0.000 | 0.000 | 0.000 | 0.000 | 0.000 | 0.000 | 0.000 |
| Cmin | Two schedules (QD, QW) | 96 | 0.000 | 0.426 | 0.639 | 0.000 | 0.048 | 0.081 | 0.000 |
| Cmin | Two schedules (QD, QW) | 384 | 0.000 | 0.491 | 0.737 | 0.000 | 0.001 | 0.002 | 0.000 |
| Cmin | Three schedules (BID, QD, QW) | 96 | 0.000 | 0.146 | 0.219 | 0.000 | 0.024 | 0.043 | 0.000 |
| Cmin | Three schedules (BID, QD, QW) | 384 | 0.000 | 0.040 | 0.061 | 0.000 | 0.001 | 0.002 | 0.000 |
@@T8
| Design | Patients | Regimens chosen by the AUC model (share of studies; ties toward the fewest doses) |
| --- | --- | --- |
| One schedule (QD) | 96 | QW 280 mg (82.3%); QW 140 mg (14.1%); QW 560 mg (3.6%) |
| One schedule (QD) | 384 | QW 280 mg (98.0%); QW 140 mg (2.1%) |
| Two schedules (QD, QW) | 96 | QW 140 mg (70.1%); QW 70 mg (29.3%); none acceptable (0.5%); QW 280 mg (0.2%) |
| Two schedules (QD, QW) | 384 | QW 140 mg (82.5%); QW 70 mg (17.5%) |
| Three schedules (BID, QD, QW) | 96 | QW 140 mg (89.9%); QW 280 mg (6.3%); QW 70 mg (3.8%) |
| Three schedules (BID, QD, QW) | 384 | QW 140 mg (99.7%); QW 280 mg (0.3%) |
@@T9
| Cap | Design | Patients | AUC always: fewest doses | random | most doses | AIC choice: fewest doses | random | True metric known: fewest doses |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 0.15 | One schedule (QD) | 96 | 0.971 | 0.324 | 0.001 | 0.405 | 0.300 | 0.002 |
| 0.15 | One schedule (QD) | 384 | 1.000 | 0.333 | 0.000 | 0.333 | 0.162 | 0.000 |
| 0.15 | Two schedules (QD, QW) | 96 | 0.054 | 0.023 | 0.000 | 0.003 | 0.001 | 0.000 |
| 0.15 | Two schedules (QD, QW) | 384 | 0.001 | 0.000 | 0.000 | 0.000 | 0.000 | 0.000 |
| 0.15 | Three schedules (BID, QD, QW) | 96 | 0.297 | 0.105 | 0.000 | 0.016 | 0.006 | 0.000 |
| 0.15 | Three schedules (BID, QD, QW) | 384 | 0.126 | 0.042 | 0.000 | 0.000 | 0.000 | 0.000 |
| 0.25 | One schedule (QD) | 96 | 1.000 | 0.361 | 0.042 | 0.445 | 0.344 | 0.086 |
| 0.25 | One schedule (QD) | 384 | 1.000 | 0.333 | 0.000 | 0.334 | 0.163 | 0.004 |
| 0.25 | Two schedules (QD, QW) | 96 | 0.705 | 0.236 | 0.000 | 0.053 | 0.039 | 0.034 |
| 0.25 | Two schedules (QD, QW) | 384 | 0.833 | 0.278 | 0.000 | 0.000 | 0.000 | 0.000 |
| 0.25 | Three schedules (BID, QD, QW) | 96 | 0.961 | 0.321 | 0.001 | 0.066 | 0.047 | 0.039 |
| 0.25 | Three schedules (BID, QD, QW) | 384 | 1.000 | 0.333 | 0.000 | 0.000 | 0.000 | 0.000 |
| 0.35 | One schedule (QD) | 96 | 1.000 | 0.428 | 0.000 | 0.567 | 0.375 | 0.257 |
| 0.35 | One schedule (QD) | 384 | 1.000 | 0.372 | 0.000 | 0.381 | 0.192 | 0.086 |
| 0.35 | Two schedules (QD, QW) | 96 | 0.184 | 0.062 | 0.000 | 0.169 | 0.084 | 0.168 |
| 0.35 | Two schedules (QD, QW) | 384 | 0.043 | 0.014 | 0.000 | 0.032 | 0.016 | 0.032 |
| 0.35 | Three schedules (BID, QD, QW) | 96 | 0.733 | 0.250 | 0.000 | 0.208 | 0.101 | 0.196 |
| 0.35 | Three schedules (BID, QD, QW) | 384 | 0.889 | 0.296 | 0.000 | 0.040 | 0.020 | 0.040 |
