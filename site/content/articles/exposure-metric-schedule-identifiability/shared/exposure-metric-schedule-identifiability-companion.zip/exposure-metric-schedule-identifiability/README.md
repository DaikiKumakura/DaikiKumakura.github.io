# Companion: can an exposure-response analysis tell AUC from Cmax and Cmin?

Simulation code and aggregate results for the article "Can an exposure-response analysis tell AUC from Cmax and Cmin? Simulated dose-finding studies with one, two or three dosing schedules". No patient data are used.

## Files

- `simulate.R`: simulates one-compartment oral PK (bank of 20,000 individuals), computes steady-state AUC, Cmax and Cmin for 12 regimens (four weekly doses x BID, QD, QW), simulates dose-finding studies of 48 to 384 patients with one, two (BID and QD, or QD and QW) or three schedules and a toxicity driven by one true metric, fits one logistic model per metric, compares them by AIC, and evaluates the regimen chosen (`Rscript simulate.R 2000 8`; seed 20261124; writes everything in `results/`). Base R only.
- `diagnose_extra.R`: diagnostic and sensitivity runs: deviances of the three metric models in the one-schedule design, regimens chosen by the AUC model, spread of the log metrics, and the overdose shares with other toxicity caps (`Rscript diagnose_extra.R 8`; writes `results/diagnostic-*.csv` and `results/sensitivity-cap.csv`).
- `mk_tables.R`: builds the markdown tables of the article from `results/summary.csv` (writes `results/tables.md`).
- `figures.R`: draws Figures 1 and 2 from `results/summary.csv` (requires ggplot2).
- `results/summary.csv`: results for every cell (slope, true driver, design, patients): correlations, probability of selecting the true metric, share of ambiguous studies, and overdose shares for each decision rule and tie rule.
- `results/diagnostic-deviance.csv`, `results/diagnostic-choice.csv`, `results/diagnostic-metric-spread.csv`, `results/sensitivity-cap.csv`: the diagnostic and sensitivity results.
- `results/true-toxicity.csv`, `results/calibration.csv`, `results/regimen-metric-means.csv`: the true toxicity of each regimen, the intercepts and optimal regimens, and the mean log metrics of each regimen.
- `results/session-info.txt`: R 4.5.3 session information.

## Reproduce

```
Rscript simulate.R 2000 8
Rscript diagnose_extra.R 8
Rscript mk_tables.R
Rscript figures.R
```

Each study uses its own seed derived from the base seed, so the results do not depend on the number of cores used. The output depends on the random-number stream of the R version used.
