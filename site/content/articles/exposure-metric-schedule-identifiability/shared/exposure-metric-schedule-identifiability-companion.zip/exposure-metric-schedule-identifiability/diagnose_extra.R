# Diagnostics and sensitivity analyses for the exposure-metric article. Reuses the definitions of simulate.R (sourced without running its study loop).
# (a) deviance of the three metric models in the one-schedule design (why the true metric is selected in fewer than one third of AUC-driver studies);
# (b) the weekly dose and schedule chosen by the AUC model when Cmax is the driver; (c) spread of the log metrics by regimen (stability of log Cmin);
# (d) sensitivity of the overdose shares to the toxicity cap (0.15 and 0.35 instead of 0.25; overdose = true toxicity above the cap + 0.05).
# Run: Rscript diagnose_extra.R [cores]   (seed 20261124 + study index; writes results/diagnostic-*.csv and results/sensitivity-cap.csv)
script_dir <- dirname(normalizePath(sub("^--file=", "", grep("^--file=", commandArgs(FALSE), value = TRUE)[1]), winslash = "/"))
PROBE_ONLY <- TRUE
argv <- commandArgs(trailingOnly = TRUE); NCORES2 <- if (length(argv) >= 1) as.integer(argv[1]) else 4L
local_args <- commandArgs; commandArgs <- function(trailingOnly = FALSE) if (trailingOnly) character(0) else local_args(FALSE)
source(file.path(script_dir, "simulate.R"), local = FALSE)
NREP2 <- 2000L

# (c) spread of the log metrics by regimen
spread <- do.call(rbind, lapply(regimens$id, function(id) data.frame(regimen = id, sd_log_AUC = sd(MET[[id]]$AUC), sd_log_Cmax = sd(MET[[id]]$Cmax), sd_log_Cmin = sd(MET[[id]]$Cmin),
  min_log_Cmin = min(MET[[id]]$Cmin), max_log_Cmin = max(MET[[id]]$Cmin), mean_Cmax_over_QD = NA_real_, mean_Cmin_over_QD = NA_real_)))
for (i in seq_len(nrow(spread))) { qd <- paste0("QD_", regimens$weekly[i])
  spread$mean_Cmax_over_QD[i] <- mean(exp(MET[[regimens$id[i]]]$Cmax)) / mean(exp(MET[[qd]]$Cmax)); spread$mean_Cmin_over_QD[i] <- mean(exp(MET[[regimens$id[i]]]$Cmin)) / mean(exp(MET[[qd]]$Cmin)) }
write.csv(spread, file.path(script_dir, "results/diagnostic-metric-spread.csv"), row.names = FALSE)

# Common study generator for (a) and (b)
gen_study <- function(index, truth, design, n, slope = 1.5) {
  set.seed(SEED + 5000000L + index)
  arms <- design_arms(design); arm <- rep(seq_len(nrow(arms)), length.out = n); ind <- sample(BANK_N, n)
  X <- sapply(METRICS, function(m) sapply(seq_len(n), function(j) MET[[arms$id[arm[j]]]][[m]][ind[j]]))
  y <- rbinom(n, 1, expit(intercepts[[as.character(slope)]][[truth]] + slope * X[, truth]))
  list(X = X, y = y)
}
dev_rows <- list(); ch_rows <- list(); k <- 0L
for (truth in METRICS) for (n in c(96, 192, 384)) {
  dv <- matrix(NA_real_, NREP2, 3, dimnames = list(NULL, METRICS))
  for (r in seq_len(NREP2)) { k <- k + 1L; st <- gen_study(k, truth, "single", n)
    for (m in METRICS) dv[r, m] <- deviance(suppressWarnings(glm(y ~ x, binomial, data.frame(y = st$y, x = st$X[, m])))) }
  best <- apply(dv, 1, which.min)
  dev_rows[[length(dev_rows) + 1]] <- data.frame(truth = truth, n_total = n, studies = NREP2, mean_dev_AUC = mean(dv[, "AUC"]), mean_dev_Cmax = mean(dv[, "Cmax"]), mean_dev_Cmin = mean(dv[, "Cmin"]),
    share_best_AUC = mean(best == 1), share_best_Cmax = mean(best == 2), share_best_Cmin = mean(best == 3),
    median_dev_true_minus_best_other = median(dv[, truth] - apply(dv[, setdiff(METRICS, truth)], 1, min)), share_true_within_2_of_best = mean(dv[, truth] - apply(dv, 1, min) < 2))
}
write.csv(do.call(rbind, dev_rows), file.path(script_dir, "results/diagnostic-deviance.csv"), row.names = FALSE)

# (b) choices of the AUC model when Cmax is the driver (ties toward the fewest doses)
for (design in c("single", "two", "three")) for (n in c(96, 384)) {
  tab <- list(); for (r in seq_len(NREP2)) { k <- k + 1L; st <- gen_study(k, "Cmax", design, n); f <- suppressWarnings(glm(y ~ x, binomial, data.frame(y = st$y, x = st$X[, "AUC"]))); b <- coef(f)
    pred <- sapply(regimens$id, function(id) mean(expit(b[[1]] + b[[2]] * MET[[id]]$AUC[PRED_IDX]))); ch <- choose(pred, "fewest"); tab[[r]] <- if (is.na(ch)) "none" else regimens$id[ch] }
  tt <- table(unlist(tab)) / NREP2
  ch_rows[[length(ch_rows) + 1]] <- data.frame(design = design, n_total = n, regimen = names(tt), share = as.numeric(tt), true_tox_Cmax = unname(TRUE_TOX[["1.5"]]$Cmax[match(names(tt), regimens$id)]))
}
write.csv(do.call(rbind, ch_rows), file.path(script_dir, "results/diagnostic-choice.csv"), row.names = FALSE)

# (d) sensitivity to the cap
one_study_cap <- function(task) { assign("CAP", task$cap, envir = globalenv()); one_study(task) }
caps <- c(0.15, 0.35)
cells2 <- expand.grid(cap = caps, truth = c("AUC", "Cmax"), design = c("single", "two", "three"), n = c(96, 384), stringsAsFactors = FALSE)
tasks2 <- do.call(c, lapply(seq_len(nrow(cells2)), function(i) lapply(seq_len(NREP2), function(r) list(index = 7000000L + (i - 1) * NREP2 + r, slope = 1.5, truth = cells2$truth[i], design = cells2$design[i], n = cells2$n[i], cap = cells2$cap[i]))))
cl <- parallel::makeCluster(NCORES2)
parallel::clusterExport(cl, c("SEED", "BANK_N", "METRICS", "regimens", "MET", "intercepts", "TRUE_TOX", "PRED_IDX", "CAP", "SCHED", "DESIGNS", "expit", "choose_set", "choose", "design_arms", "one_study", "one_study_cap"))
res2 <- parallel::parLapplyLB(cl, tasks2, one_study_cap); parallel::stopCluster(cl); mat2 <- do.call(rbind, res2)
rows2 <- list()
for (i in seq_len(nrow(cells2))) {
  m <- mat2[seq((i - 1) * NREP2 + 1, i * NREP2), , drop = FALSE]; cp <- cells2$cap[i]
  ov <- function(rule, tie) { tt <- m[, paste0(rule, "_", tie, "_true_tox")]; mean(!is.na(tt) & tt > cp + 0.05) }
  rows2[[i]] <- data.frame(cap = cp, truth = cells2$truth[i], design = cells2$design[i], n_total = cells2$n[i], studies = NREP2,
    AUC_fewest = ov("AUC", "fewest"), AUC_most = ov("AUC", "most"), AUC_random = mean(m[, "AUC_random_over"], na.rm = TRUE),
    selected_fewest = ov("selected", "fewest"), selected_random = mean(m[, "selected_random_over"], na.rm = TRUE), oracle_fewest = ov("oracle", "fewest"), p_correct_metric = mean(m[, "correct"]))
}
write.csv(do.call(rbind, rows2), file.path(script_dir, "results/sensitivity-cap.csv"), row.names = FALSE)
cat("done\n")
