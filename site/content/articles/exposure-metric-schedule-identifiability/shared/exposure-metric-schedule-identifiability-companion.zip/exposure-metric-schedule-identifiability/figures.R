# Figures for the exposure-metric article (Okabe-Ito palette). Run: Rscript figures.R (after simulate.R)
script_dir <- dirname(normalizePath(sub("^--file=", "", grep("^--file=", commandArgs(FALSE), value = TRUE)[1]), winslash = "/"))
suppressPackageStartupMessages(library(ggplot2))
o <- read.csv(file.path(script_dir, "results/summary.csv")); dir.create(file.path(script_dir, "figures"), showWarnings = FALSE)
o$design <- factor(o$design, c("single", "qdbid", "two", "three"), c("One schedule (QD)", "Two schedules (BID, QD)", "Two schedules (QD, QW)", "Three schedules (BID, QD, QW)"))
o$truth <- factor(o$truth, c("AUC", "Cmax", "Cmin"), c("True driver: AUC", "True driver: Cmax", "True driver: Cmin"))
cols <- c("One schedule (QD)" = "#D55E00", "Two schedules (BID, QD)" = "#CC79A7", "Two schedules (QD, QW)" = "#E69F00", "Three schedules (BID, QD, QW)" = "#0072B2")
m <- o[o$slope == 1.5, ]
p1 <- ggplot(m, aes(n_total, p_correct_metric, colour = design, shape = design, group = design)) +
  geom_hline(yintercept = 1 / 3, colour = "grey50", linetype = "dashed") + geom_line(linewidth = 0.8) + geom_point(size = 2.5) + facet_wrap(~truth) +
  scale_x_continuous(trans = "log2", breaks = c(48, 96, 192, 384)) + scale_y_continuous(limits = c(0, 1)) +
  scale_colour_manual(values = cols, name = "Study design") + scale_shape_manual(values = c(16, 18, 17, 15), name = "Study design") +
  labs(x = "Patients per study (log scale)", y = "Probability that AIC selects the true metric") + theme_bw(base_size = 12) + theme(legend.position = "bottom") + guides(colour = guide_legend(nrow = 2), shape = guide_legend(nrow = 2))
ggsave(file.path(script_dir, "figures/figure-1-metric-selection.png"), p1, width = 9.5, height = 4.8, dpi = 160)
long <- rbind(data.frame(m[, c("truth", "design", "n_total")], rule = "Metric chosen by AIC", over = m$selected_fewest_over_cap5),
              data.frame(m[, c("truth", "design", "n_total")], rule = "AUC always", over = m$AUC_fewest_over_cap5),
              data.frame(m[, c("truth", "design", "n_total")], rule = "True metric known", over = m$oracle_fewest_over_cap5))
long$rule <- factor(long$rule, c("AUC always", "Metric chosen by AIC", "True metric known"))
p2 <- ggplot(long[long$design %in% c("One schedule (QD)", "Three schedules (BID, QD, QW)"), ], aes(n_total, over, colour = rule, linetype = design, group = interaction(rule, design))) +
  geom_line(linewidth = 0.8) + geom_point(size = 2) + facet_wrap(~truth) +
  scale_x_continuous(trans = "log2", breaks = c(48, 96, 192, 384)) + scale_y_continuous(limits = c(0, 1)) +
  scale_colour_manual(values = c("#D55E00", "#009E73", "#000000"), name = "Model used for the decision") + scale_linetype_manual(values = c("solid", "dashed"), name = "Study design") +
  labs(x = "Patients per study (log scale)", y = "Share with overdose (toxicity above 30%)") + theme_bw(base_size = 12) + theme(legend.position = "bottom", legend.box = "vertical")
ggsave(file.path(script_dir, "figures/figure-2-overdose.png"), p2, width = 9.5, height = 5.4, dpi = 160)
