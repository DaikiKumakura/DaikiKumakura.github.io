# Builds the markdown tables of the article from the results files (Run: Rscript mk_tables.R; writes results/tables.md). Rounding is half-up.
script_dir <- dirname(normalizePath(sub("^--file=", "", grep("^--file=", commandArgs(FALSE), value = TRUE)[1]), winslash = "/"))
rd <- function(f) read.csv(file.path(script_dir, "results", f))
o <- rd("summary.csv"); tx <- rd("true-toxicity.csv"); dv <- rd("diagnostic-deviance.csv"); ch <- rd("diagnostic-choice.csv"); sc <- rd("sensitivity-cap.csv")
rnd <- function(x, d) floor(x * 10^d + 0.5 + 1e-9) / 10^d
f3 <- function(x) formatC(rnd(x, 3), format = "f", digits = 3)
f2 <- function(x) formatC(rnd(x, 2), format = "f", digits = 2)
dn <- c(single = "One schedule (QD)", qdbid = "Two schedules (BID, QD)", two = "Two schedules (QD, QW)", three = "Three schedules (BID, QD, QW)")
out <- c()
out <- c(out, "@@T1", "| Regimen | Weekly dose (mg) | True driver AUC | True driver Cmax | True driver Cmin |", "| --- | --- | --- | --- | --- |")
t1 <- tx[tx$slope == 1.5, ]
for (i in seq_len(nrow(t1))) out <- c(out, sprintf("| %s | %d | %s | %s | %s |", t1$sched[i], t1$weekly[i], f3(t1$tox_AUC[i]), f3(t1$tox_Cmax[i]), f3(t1$tox_Cmin[i])))
out <- c(out, "@@T2", "| Design | Log AUC and log Cmax | Log AUC and log Cmin | Log Cmax and log Cmin |", "| --- | --- | --- | --- |")
for (d in names(dn)) { x <- o[o$slope == 1.5 & o$design == d & o$n_total == 384 & o$truth == "AUC", ]
  out <- c(out, sprintf("| %s | %s | %s | %s |", dn[[d]], f3(x$corr_AUC_Cmax), f3(x$corr_AUC_Cmin), f3(x$corr_Cmax_Cmin))) }
tab_by_design <- function(s, tag, col) {
  r <- c(tag, "| True driver | Design | 48 patients | 96 patients | 192 patients | 384 patients |", "| --- | --- | --- | --- | --- | --- |")
  for (tr in c("AUC", "Cmax", "Cmin")) for (d in names(dn)) { x <- o[o$slope == s & o$truth == tr & o$design == d, ]; x <- x[order(x$n_total), ]
    r <- c(r, sprintf("| %s | %s | %s |", tr, dn[[d]], paste(f3(x[[col]]), collapse = " | "))) }
  r }
out <- c(out, tab_by_design(1.5, "@@T3", "p_correct_metric"), tab_by_design(1.5, "@@T4", "p_ambiguous"), tab_by_design(0.75, "@@T6", "p_correct_metric"))
out <- c(out, "@@T5", "| True driver | Patients | Mean deviance, AUC model | Cmax model | Cmin model | Lowest deviance, AUC model | Cmax model | Cmin model | True model minus the lower of the other two (median) |", "| --- | --- | --- | --- | --- | --- | --- | --- | --- |")
for (i in seq_len(nrow(dv))) out <- c(out, sprintf("| %s | %d | %s | %s | %s | %s | %s | %s | %s |", dv$truth[i], dv$n_total[i], f2(dv$mean_dev_AUC[i]), f2(dv$mean_dev_Cmax[i]), f2(dv$mean_dev_Cmin[i]),
  f3(dv$share_best_AUC[i]), f3(dv$share_best_Cmax[i]), f3(dv$share_best_Cmin[i]), f2(dv$median_dev_true_minus_best_other[i])))
out <- c(out, "@@T7", "| True driver | Design | Patients | AUC always: fewest doses | random | most doses | AIC choice: fewest doses | random | most doses | True metric known: fewest doses |", "| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |")
for (tr in c("Cmax", "AUC", "Cmin")) for (d in c("single", "two", "three")) for (n in c(96, 384)) { x <- o[o$slope == 1.5 & o$truth == tr & o$design == d & o$n_total == n, ]
  out <- c(out, sprintf("| %s | %s | %d | %s | %s | %s | %s | %s | %s | %s |", tr, dn[[d]], n, f3(x$AUC_fewest_over_cap5), f3(x$AUC_random_over_cap5), f3(x$AUC_most_over_cap5),
    f3(x$selected_fewest_over_cap5), f3(x$selected_random_over_cap5), f3(x$selected_most_over_cap5), f3(x$oracle_fewest_over_cap5))) }
out <- c(out, "@@T8", "| Design | Patients | Regimens chosen by the AUC model (share of studies; ties toward the fewest doses) |", "| --- | --- | --- |")
for (d in c("single", "two", "three")) for (n in c(96, 384)) { x <- ch[ch$design == d & ch$n_total == n, ]; x <- x[order(-x$share), ]
  lab <- sapply(seq_len(nrow(x)), function(i) { id <- x$regimen[i]; if (id == "none") sprintf("none acceptable (%s%%)", formatC(rnd(100 * x$share[i], 1), format = "f", digits = 1)) else
    sprintf("%s %s mg (%s%%)", sub("_.*", "", id), sub(".*_", "", id), formatC(rnd(100 * x$share[i], 1), format = "f", digits = 1)) })
  out <- c(out, sprintf("| %s | %d | %s |", dn[[d]], n, paste(lab, collapse = "; "))) }
out <- c(out, "@@T9", "| Cap | Design | Patients | AUC always: fewest doses | random | most doses | AIC choice: fewest doses | random | True metric known: fewest doses |", "| --- | --- | --- | --- | --- | --- | --- | --- | --- |")
for (cp in c(0.15, 0.25, 0.35)) for (d in c("single", "two", "three")) for (n in c(96, 384)) {
  if (cp == 0.25) { x <- o[o$slope == 1.5 & o$truth == "Cmax" & o$design == d & o$n_total == n, ]
    v <- c(x$AUC_fewest_over_cap5, x$AUC_random_over_cap5, x$AUC_most_over_cap5, x$selected_fewest_over_cap5, x$selected_random_over_cap5, x$oracle_fewest_over_cap5)
  } else { x <- sc[sc$cap == cp & sc$truth == "Cmax" & sc$design == d & sc$n_total == n, ]; v <- c(x$AUC_fewest, x$AUC_random, x$AUC_most, x$selected_fewest, x$selected_random, x$oracle_fewest) }
  out <- c(out, sprintf("| %s | %s | %d | %s |", formatC(cp, format = "f", digits = 2), dn[[d]], n, paste(f3(v), collapse = " | "))) }
writeLines(out, file.path(script_dir, "results/tables.md"), useBytes = TRUE)
