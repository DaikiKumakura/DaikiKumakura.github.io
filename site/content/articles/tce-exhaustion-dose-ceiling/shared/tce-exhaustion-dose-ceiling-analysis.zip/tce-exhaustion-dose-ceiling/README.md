# Can increasing TCE concentration compensate for impaired T-cell function?

Reanalysis of published aggregate means, DOI:10.1080/2162402X.2025.2526444.
The source is licensed under CC BY-NC 4.0; full source URL and SHA-256 are in source-provenance.json.
Original source figures and articles are not included in the companion.
Digitization is approximate and is not original individual-level data.

Use the scientific Python versions in requirements.txt in an existing environment. From this directory:

```sh
python analysis/download_sources.py
python analysis/run.py
python -m unittest discover -s tests
```

The outputs are regenerated from manually recorded observed-symbol pixel centers and explicit axis calibration. Connecting/fitted lines are not extra observations. Reading scenarios are not biological confidence intervals. Full methods and limits are in the Japanese and English manuscripts.

The endpoint is baseline-subtracted luminescence in RLU/s, not percentage lysis. Two donors are biological units; technical duplicates do not increase donor count. The highest positive concentration is withheld in a separate retrospective extrapolation test. No patient dose or functional recovery is inferred.
