"""Digitize observed symbols and compare potency with response ceilings."""
from pathlib import Path
import csv
import json
import hashlib
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from scipy.optimize import least_squares

ROOT = Path(__file__).resolve().parents[1]
SEED = 20261028
# Figure 6b, full JPEG coordinates. Only observed filled MART1 symbols are read.
# Zero is plotted on a broken/symlog-like left region and is not log-transformed.
PANELS = {
    'Donor 1': {'ticks_x': [191.7, 230], 'zero_y': 341.5, 'top_y': 226,
                'x': [183, 207, 232, 257, 281],
                'Teff': [339, 338, 324, 248, 243],
                'Tex': [345, 345, 339, 314, 312],
                'baseline': {'Teff': 342, 'Tex': 342}},
    'Donor 2': {'ticks_x': [433.7, 472], 'zero_y': 341.5, 'top_y': 226,
                'x': [425, 449, 474, 499, 523],
                'Teff': [340, 337, 317, 263, 258],
                'Tex': [342, 343, 333, 296, 296],
                'baseline': {'Teff': 342, 'Tex': 342}}
}


def response(c: np.ndarray, e: float, ec: float, h: float) -> np.ndarray:
    """Incremental luminescence, in millions of RLU/s."""
    c = np.asarray(c, dtype=float)
    return e * np.where(c > 0, 1 / (1 + (ec / np.maximum(c, 1e-30)) ** h), 0)


def fit(c: np.ndarray, y: np.ndarray) -> np.ndarray:
    """Equal-weight constrained least squares on the aggregate marker means."""
    fits = []
    for ec in [0.003, 0.02, 0.1]:
        f = least_squares(lambda p: response(c, *np.exp(p)) - y,
                          np.log([max(y.max(), .1), ec, 1.5]),
                          bounds=(np.log([.001, 1e-6, .1]), np.log([5, 100, 10])))
        fits.append(f)
    return np.exp(min(fits, key=lambda f: sum(f.fun**2)).x)


def read_markers() -> list[dict]:
    rows = []
    for donor, p in PANELS.items():
        scale = 1.5 / (p['zero_y'] - p['top_y'])
        for state in ['Teff', 'Tex']:
            baseline = (p['zero_y'] - p['baseline'][state]) * scale
            for j, (x, y) in enumerate(zip(p['x'], p[state])):
                c = 10 ** (-4 + (x-p['ticks_x'][0]) * 2 / np.diff(p['ticks_x'])[0])
                rows.append(dict(donor=donor, state=state, point=j+1, x_px=x,
                                 y_px=y, concentration_nm=c,
                                 signal_million_rlu=(p['zero_y']-y)*scale,
                                 baseline_million_rlu=baseline,
                                 incremental_million_rlu=(p['baseline'][state]-y)*scale,
                                 role='heldout_highest' if j == 4 else 'training'))
    return rows


def write_csv(path: Path, rows: list[dict]) -> None:
    with path.open('w', newline='', encoding='utf-8') as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0])); w.writeheader(); w.writerows(rows)


def main() -> None:
    out = ROOT/'outputs'; (out/'figures').mkdir(parents=True, exist_ok=True)
    (out/'tables').mkdir(exist_ok=True); (ROOT/'data/processed').mkdir(parents=True, exist_ok=True)
    rows = read_markers(); write_csv(ROOT/'data/processed/markers.csv', rows)
    plt.rcParams.update({'font.size': 10, 'svg.fonttype': 'none'})
    fig, axes = plt.subplots(1, 2, figsize=(9, 3.7), sharey=True)
    params, comparison, heldout, nested_params = [], [], [], []
    sensitivity = []
    rng = np.random.default_rng(SEED)
    colors = {'Teff':'#0072B2', 'Tex':'#D55E00'}
    for ax, (donor, p) in zip(axes, PANELS.items()):
        curves = {}
        for state in ['Teff','Tex']:
            r = [x for x in rows if x['donor']==donor and x['state']==state]
            c = np.array([x['concentration_nm'] for x in r]); y = np.array([x['incremental_million_rlu'] for x in r])
            theta = fit(c,y); train = fit(c[:-1], y[:-1]); curves[state]=(c,y,theta)
            params.append(dict(donor=donor,state=state,emax_million_rlu=theta[0],ec50_nm=theta[1],hill=theta[2]))
            pred=float(response(c[-1:],*train)[0]); obs=float(y[-1])
            heldout.append(dict(donor=donor,state=state,observed=obs,predicted=pred,error=pred-obs))
            grid=np.geomspace(c.min(),c.max(),200)
            ax.plot(grid,response(grid,*theta),color=colors[state]);ax.scatter(c,y,color=colors[state],label=state,zorder=3)
            ax.scatter(c[-1],y[-1],s=110,facecolors='none',edgecolors='black',zorder=4)
        c,y,eff=curves['Teff']; _,z,tex=curves['Tex']
        # Nested model: a common ceiling and common slope; state-specific EC50s.
        def common_loss(v):
            e, ec_e, ec_x, h=np.exp(v)
            return np.r_[response(c,e,ec_e,h)-y,response(c,e,ec_x,h)-z]
        f=least_squares(common_loss,np.log([1,.02,.05,1.5]),bounds=(np.log([.001,1e-6,1e-6,.1]),np.log([5,100,100,10])))
        common_rmse=float(np.sqrt(np.mean(f.fun**2)))
        # Relax only Emax while retaining a common Hill slope for a nested comparison.
        def separate_ceiling_loss(v):
            e_e,e_x,ec_e,ec_x,h=np.exp(v)
            return np.r_[response(c,e_e,ec_e,h)-y,response(c,e_x,ec_x,h)-z]
        candidates=[least_squares(separate_ceiling_loss,
                      np.log([max(y.max(),.1),max(z.max(),.1),ec,ec,1.5]),
                      bounds=(np.log([.001,.001,1e-6,1e-6,.1]),np.log([5,5,100,100,10])))
                    for ec in [.003,.02,.1]]
        nested=min(candidates,key=lambda a:sum(a.fun**2))
        e_e,e_x,ec_e,ec_x,h=np.exp(nested.x)
        nested_params.append(dict(donor=donor,teff_ceiling=e_e,tex_ceiling=e_x,
                                  teff_ec50_nm=ec_e,tex_ec50_nm=ec_x,shared_hill=h))
        nested_rmse=float(np.sqrt(np.mean(nested.fun**2)))
        free_rmse=float(np.sqrt(np.mean(np.r_[response(c,*eff)-y,response(c,*tex)-z]**2)))
        comparison.append(dict(donor=donor,observed_high_ratio=z[-1]/y[-1],fitted_ceiling_ratio=tex[0]/eff[0],potency_only_rmse=common_rmse,shared_hill_separate_ceiling_rmse=nested_rmse,free_ceiling_rmse=free_rmse,
                               observed_Teff_high=y[-1],observed_Tex_high=z[-1]))
        # A documented reading scenario, not a donor bootstrap or confidence interval.
        scale=1.5/(p['zero_y']-p['top_y'])
        high_ratios=[]
        for _ in range(2000):
            high_ratios.append((z[-1]+rng.uniform(-2,2)*scale)/(y[-1]+rng.uniform(-2,2)*scale))
        sensitivity.append(dict(donor=donor,min_ratio=float(min(high_ratios)),max_ratio=float(max(high_ratios)),pixel_halfwidth=2))
        ax.set(xscale='log',xlabel='TCB concentration (nM; digitized)',title=donor,ylim=(-.07,1.5));ax.grid(alpha=.2);ax.legend(frameon=False)
    axes[0].set_ylabel('Baseline-subtracted signal (million RLU/s)')
    fig.suptitle('Human TYRP1 assay at 48 h; two biological donors\nCircles outlined in black were excluded from high-dose prediction')
    fig.tight_layout();fig.savefig(out/'figures/dose-curves.svg');fig.savefig(out/'figures/dose-curves.png',dpi=170);plt.close(fig)
    write_csv(out/'tables/parameters.csv',params);write_csv(out/'tables/ceiling-comparison.csv',comparison)
    write_csv(out/'tables/nested-parameters.csv',nested_params)
    write_csv(out/'tables/heldout-prediction.csv',heldout);write_csv(out/'tables/reading-sensitivity.csv',sensitivity)
    fig, ax=plt.subplots(figsize=(6,3.6))
    for i,r in enumerate(comparison):
        ax.bar(i-.15,r['observed_high_ratio'],width=.28,color='#009E73',label='Observed highest-concentration ratio' if i==0 else '')
        ax.bar(i+.15,r['fitted_ceiling_ratio'],width=.28,color='#E69F00',label='Fitted incremental ceiling ratio' if i==0 else '')
    ax.axhline(1,color='black',linestyle='--');ax.set(xticks=[0,1],xticklabels=list(PANELS),ylabel='Tex / matched MART1 Teff',ylim=(0,1.08))
    ax.legend(frameon=False,fontsize=8);fig.tight_layout();fig.savefig(out/'figures/ceiling-ratios.svg');fig.savefig(out/'figures/ceiling-ratios.png',dpi=170);plt.close(fig)
    summary={'article_id':'STCE-13','n_donors':2,'n_digitized_means':len(rows),'n_training_means':16,'n_heldout_means':4,'results':comparison,'heldout':heldout,'sensitivity':sensitivity,
             'source_sha256':hashlib.sha256((ROOT/'data/raw/source-figure.jpg').read_bytes()).hexdigest()}
    (out/'results.json').write_text(json.dumps(summary,indent=2),encoding='utf8')
    print(json.dumps(summary,indent=2))


if __name__=='__main__': main()
