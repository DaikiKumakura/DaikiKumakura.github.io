"""Fetch the public figure without overwriting an existing raw file."""
from pathlib import Path
import hashlib
import json
import urllib.request
ROOT=Path(__file__).resolve().parents[1]
p=json.loads((ROOT/'source-provenance.json').read_text(encoding='utf8'))
target=ROOT/'data/raw/source-figure.jpg'
if target.exists():
    assert hashlib.sha256(target.read_bytes()).hexdigest()==p['source_figure_sha256'], 'Existing raw file differs; do not overwrite.'
else:
    target.parent.mkdir(parents=True,exist_ok=True)
    payload=urllib.request.urlopen(p['source_figure_url'],timeout=60).read()
    assert hashlib.sha256(payload).hexdigest()==p['source_figure_sha256'], 'Public source changed; audit before using.'
    target.write_bytes(payload)
print('Source figure verified:',p['source_figure_sha256'])
