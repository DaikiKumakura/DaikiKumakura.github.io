import importlib.util
from pathlib import Path
import unittest
import numpy as np
import csv

P=Path(__file__).resolve().parents[1]
spec=importlib.util.spec_from_file_location('analysis',P/'analysis/run.py')
m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)


class AnalysisTest(unittest.TestCase):
    def test_response_limits(self):
        np.testing.assert_allclose(m.response(np.array([0,.1,1e10]),2,.1,1),[0,1,2])

    def test_independent_units(self):
        r=m.read_markers()
        self.assertEqual(len(r),20)
        self.assertEqual(len({x['donor'] for x in r}),2)
        self.assertEqual(sum(x['role']=='heldout_highest' for x in r),4)
        self.assertTrue(all(x['concentration_nm']>0 for x in r))

    def test_fit_known_curve(self):
        c=np.geomspace(1e-4,10,15);y=m.response(c,.7,.02,1.8)
        np.testing.assert_allclose(m.fit(c,y),[.7,.02,1.8],rtol=1e-4)

    def test_corrected_log_axis_and_nested_comparison(self):
        points=m.read_markers()
        self.assertTrue(4 < max(p['concentration_nm'] for p in points) < 6)
        with (P/'outputs/tables/ceiling-comparison.csv').open(encoding='utf-8') as f:
            for row in csv.DictReader(f):
                self.assertLessEqual(float(row['free_ceiling_rmse']),float(row['shared_hill_separate_ceiling_rmse'])+1e-7)
                self.assertLessEqual(float(row['shared_hill_separate_ceiling_rmse']),float(row['potency_only_rmse'])+1e-7)


if __name__=='__main__':unittest.main()
