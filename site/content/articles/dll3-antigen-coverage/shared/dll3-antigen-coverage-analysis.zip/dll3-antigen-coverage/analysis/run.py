"""Sample-level additional RNA coverage with a frozen rule and sensitivity checks."""
from pathlib import Path
import sys,csv,json,hashlib,platform
import numpy as np
import scipy
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'src'))
from coverage import derive,bootstrap_mean,leave_one_out_means,TOLERANCE

SEED=2026102502
REPLICATES=10000
EPS=1e-6
OUT=ROOT/'outputs'
TABLES=OUT/'tables';FIGURES=OUT/'figures'
TABLES.mkdir(parents=True,exist_ok=True);FIGURES.mkdir(parents=True,exist_ok=True)
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':11,'axes.spines.top':False,
    'axes.spines.right':False,'svg.fonttype':'none','svg.hashsalt':'dll3-antigen-coverage'})
COLORS={'b7h3':'#0072B2','sez6':'#D55E00','dll3':'#555555'}


def write(name: str,rows: list[dict]) -> None:
    with (TABLES/name).open('w',newline='',encoding='utf-8') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)


def save(fig,name: str,footer: str) -> None:
    fig.get_layout_engine().set(rect=(0,.09,1,.91))
    fig.text(.02,.018,footer,fontsize=9,va='bottom')
    fig.savefig(FIGURES/(name+'.png'),dpi=180,bbox_inches='tight',facecolor='white')
    fig.savefig(FIGURES/(name+'.svg'),bbox_inches='tight',facecolor='white',metadata={'Date':None})
    svg=FIGURES/(name+'.svg')
    svg.write_text('\n'.join(x.rstrip() for x in svg.read_text(encoding='utf-8').splitlines())+'\n',encoding='utf-8')
    plt.close(fig)


with (ROOT/'data/processed/coexpression.csv').open(encoding='utf-8',newline='') as f:
    source=list(csv.DictReader(f))
assert len(source)==29
rows=[dict(cohort=r['cohort'],sample=r['sample'],subtype=r['subtype'],treatment=r['treatment'],
           primary_excluded=int(r['primary_excluded']),**derive(r)) for r in source]
write('sample_coverage.csv',rows)
primary=[r for r in rows if not r['primary_excluded']]
assert len(primary)==28 and sum(r['cohort']=='B' for r in primary)==10

metrics=['dll3','gain_b7h3','gain_sez6','difference_b_minus_s','union_d_b','union_d_s',
         'union_three','none_three','third_b_after_s','third_s_after_b']
summaries=[]
groups=[('B_primary',[r for r in primary if r['cohort']=='B']),
        ('C_primary',[r for r in primary if r['cohort']=='C']),
        ('C_include_pleural',[r for r in rows if r['cohort']=='C']),
        ('C_SCLC_A',[r for r in primary if r['cohort']=='C' and r['subtype']=='SCLC-A'])]
for gi,(name,rs) in enumerate(groups):
    for mi,metric in enumerate(metrics):
        x=np.array([r[metric] for r in rs])
        lo,hi=bootstrap_mean(x,SEED+gi*100+mi,REPLICATES)
        loo=leave_one_out_means(x)
        summaries.append(dict(group=name,n=len(rs),metric=metric,mean=float(x.mean()),
            median=float(np.median(x)),min=float(x.min()),max=float(x.max()),
            bootstrap_lower95=lo,bootstrap_upper95=hi,loo_mean_min=float(loo.min()),loo_mean_max=float(loo.max())))
write('group_summaries.csv',summaries)

# Derive the rule from cohort B only; this is not a prospectively blinded validation.
b=[r for r in primary if r['cohort']=='B']
c=[r for r in primary if r['cohort']=='C']
chosen='b7h3' if np.mean([r['difference_b_minus_s'] for r in b])>0 else 'sez6'
policy=[]
for name,rs in [('B_primary',b),('C_primary',c)]:
    fixed=np.array([r['gain_'+chosen] for r in rs])
    hindsight=np.array([max(r['gain_b7h3'],r['gain_sez6']) for r in rs])
    policy.append(dict(group=name,n=len(rs),B_rule=chosen,fixed_mean_gain=float(fixed.mean()),
        within_table_hindsight_gain=float(hindsight.mean()),
        hindsight_minus_fixed=float((hindsight-fixed).mean()),
        b7h3_larger_count=sum(r['difference_b_minus_s']>EPS for r in rs),
        sez6_larger_count=sum(r['difference_b_minus_s']<-EPS for r in rs)))
write('frozen_rule_comparison.csv',policy)

audit=[]
for name,rs in groups:
    audit.append(dict(group=name,n=len(rs),naive=sum(r['treatment']=='Naive' for r in rs),
        treated=sum(r['treatment']=='Treated' for r in rs),
        SCLC_A=sum(r['subtype']=='SCLC-A' for r in rs),SCLC_N=sum(r['subtype']=='SCLC-N' for r in rs),
        SCLC_P=sum(r['subtype']=='SCLC-P' for r in rs)))
write('cohort_audit.csv',audit)

fig,axes=plt.subplots(1,2,figsize=(10,6.7),layout='constrained',gridspec_kw={'width_ratios':[1,1.35]})
for ax,rs,label in zip(axes,[b,c],['B: 10 samples','C: 18 donor-labelled rows']):
    ordered=sorted(rs,key=lambda r:r['difference_b_minus_s'])
    for y,r in enumerate(ordered):
        ax.plot([100*r['gain_sez6'],100*r['gain_b7h3']],[y,y],color='#aaaaaa',lw=1)
        ax.scatter(100*r['gain_b7h3'],y,color=COLORS['b7h3'],s=28,label='B7-H3' if y==0 else None,zorder=3)
        ax.scatter(100*r['gain_sez6'],y,color=COLORS['sez6'],s=28,marker='s',label='SEZ6' if y==0 else None,zorder=3)
    ax.set(yticks=range(len(ordered)),yticklabels=[r['sample'] for r in ordered],
        xlabel='Additional detected-cell coverage (pp)',xlim=(0,45),title=label)
    ax.legend(frameon=False,fontsize=9,loc='upper right')
save(fig,'additional-coverage','RNA detection > 0 in author-annotated malignant cells. Samples are equally weighted; no protein or efficacy model.')

fig,ax=plt.subplots(figsize=(8.5,5),layout='constrained')
state_order=['100','110','101','111','010','011','001','000']
state_labels=['DLL3 only','DLL3 + SEZ6','DLL3 + B7-H3','All three','SEZ6 only','SEZ6 + B7-H3','B7-H3 only','None detected']
palette=['#555555','#009E73','#56B4E9','#CC79A7','#D55E00','#F0E442','#0072B2','#dddddd']
for y,(rs,label) in enumerate([(b,'B (n=10)'),(c,'C (n=18)')]):
    left=0
    for state,color,leg in zip(state_order,palette,state_labels):
        value=100*np.mean([r['atom_'+state] for r in rs])
        if abs(value)<100*TOLERANCE: value=max(0,value)
        ax.barh(y,value,left=left,color=color,label=leg if y==0 else None,height=.5)
        left+=value
    assert abs(left-100)<1e-4
ax.set(yticks=[0,1],yticklabels=['B (n=10)','C (n=18)'],xlabel='Equal-sample mean cell fraction (%)',xlim=(0,100),
    title='Eight mutually exclusive transcript-detection states')
ax.legend(frameon=False,fontsize=9,ncol=4,loc='upper center',bbox_to_anchor=(.5,-.18))
save(fig,'detection-states','States reconstructed by inclusion-exclusion from S2 fractions. None detected does not establish protein negativity.')

fig,ax=plt.subplots(figsize=(8.5,4.6),layout='constrained')
for y,name in enumerate(['B_primary','C_primary','C_include_pleural','C_SCLC_A']):
    r=next(r for r in summaries if r['group']==name and r['metric']=='difference_b_minus_s')
    ax.plot([100*r['bootstrap_lower95'],100*r['bootstrap_upper95']],[y,y],color='#0072B2',lw=2)
    ax.scatter(100*r['mean'],y,color='#0072B2',s=35,zorder=3)
ax.axvline(0,color='#555555',ls='--',lw=1)
ax.set(yticks=range(4),yticklabels=['B primary (n=10)','C primary (n=18)','C + pleural row (n=19)','C SCLC-A only (n=12)'],
    xlabel='Mean additional coverage: B7-H3 minus SEZ6 (pp)',title='Paired row-level difference and sensitivity analyses')
ax.invert_yaxis()
save(fig,'ranking-uncertainty','Pointwise percentile bootstrap intervals (10,000 resamples), not clinical prediction intervals. No cell-level resampling.')

result=dict(extracted_rows=29,primary_rows=28,primary_B=10,primary_C=18,excluded_row='PleuralEffusion',
    threshold='Author-defined RNA detection >0; not a protein-density cutoff',bootstrap_seed=SEED,bootstrap_replicates=REPLICATES,
    B_frozen_additional_target=chosen,primary_estimand='Equal-unit mean paired additional-coverage difference B7-H3 minus SEZ6',
    inference_scope='Exploratory row-level sampling uncertainty, conditional on published cell annotations and transcript detection',
    primary_summary=[r for r in summaries if r['group'] in ['B_primary','C_primary']],policy=policy,
    minimum_atom=float(min(r['atom_'+s] for r in rows for s in state_order)),
    input_sha256=hashlib.sha256((ROOT/'data/processed/coexpression.csv').read_bytes()).hexdigest(),
    environment=dict(python=platform.python_version(),numpy=np.__version__,scipy=scipy.__version__,matplotlib=matplotlib.__version__))
(OUT/'results.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
print(json.dumps(dict(extracted_rows=29,primary_rows=28,policy=policy,minimum_atom=result['minimum_atom']),indent=2))
