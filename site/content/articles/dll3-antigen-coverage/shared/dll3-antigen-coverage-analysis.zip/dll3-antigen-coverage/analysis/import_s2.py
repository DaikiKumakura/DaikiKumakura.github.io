"""Extract the two labelled S2 blocks without altering the source workbook."""
from pathlib import Path
import csv
import hashlib
import json
import openpyxl

ROOT=Path(__file__).resolve().parents[1]
RAW=ROOT/'data/raw/cd-25-1483_supplementary_data_s2_suppsd2.xlsx'
workbook=openpyxl.load_workbook(RAW,read_only=True,data_only=True)
sheet=workbook['target_gene_in_primary_tumor']
values=list(sheet.values)
fields=['sample','source_cohort','subtype','treatment','Pdll3','Psez6','Pb7h3','Psind','Pbind','P2ind','Pany3']
rows=[]
for cohort,start,stop in [('B',3,12),('C',16,34)]:
    assert values[start-2][0]=='Sample'
    assert values[start-2][4:11]==('Pdll3','Psez6','Pb7h3','Psind','Pbind','P2ind','Pany3')
    for rownum in range(start,stop+1):
        row=dict(zip(fields,values[rownum-1][:11]))
        assert row['sample'] and all(isinstance(row[k],(int,float)) for k in fields[4:])
        row.update(cohort=cohort,source_row=rownum,primary_excluded=int(row['sample']=='PleuralEffusion'))
        rows.append(row)
assert len(rows)==29 and len({(r['cohort'],r['sample']) for r in rows})==29
out=ROOT/'data/processed'
out.mkdir(parents=True,exist_ok=True)
with (out/'coexpression.csv').open('w',encoding='utf-8',newline='') as f:
    w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
provenance=dict(title='Supplementary Data S2, Mishra et al. (2026)',
    doi='10.1158/2159-8290.32728810',url='https://ndownloader.figshare.com/files/65673136',
    license='CC BY 4.0',license_url='https://creativecommons.org/licenses/by/4.0/',
    accessed='2026-10-25',filename=RAW.name,sha256=hashlib.sha256(RAW.read_bytes()).hexdigest(),
    worksheet=sheet.title,blocks={'B':'A3:K12','C':'A16:K34'},
    original_article='https://doi.org/10.1158/2159-8290.CD-25-1483',
    adaptation='Extracted sample-level fractions; derived additional union coverage. The workbook is unmodified.')
(ROOT/'source-provenance.json').write_text(json.dumps(provenance,indent=2)+'\n',encoding='utf-8')
print(json.dumps(dict(extracted_rows=len(rows),cohort_B=10,cohort_C=19,primary_excluded=1)))
