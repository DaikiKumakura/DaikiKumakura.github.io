"""Algebra on author-reported coexpression fractions, not drug-effect models."""
import numpy as np

TOLERANCE=1e-7


def derive(row: dict) -> dict:
    d,s,b=(float(row[x]) for x in ['Pdll3','Psez6','Pb7h3'])
    ds=d*float(row['Psind'])
    db=d*float(row['Pbind'])
    dsb=d*float(row['P2ind'])
    union=float(row['Pany3'])
    sb=d+s+b-ds-db+dsb-union
    atoms={'000':1-union,'100':d-ds-db+dsb,'010':s-ds-sb+dsb,
           '001':b-db-sb+dsb,'110':ds-dsb,'101':db-dsb,
           '011':sb-dsb,'111':dsb}
    if min(atoms.values()) < -TOLERANCE or abs(sum(atoms.values())-1)>TOLERANCE:
        raise ValueError('Inconsistent coexpression fractions')
    gain_b=b-db
    gain_s=s-ds
    out=dict(dll3=d,sez6=s,b7h3=b,gain_b7h3=gain_b,gain_sez6=gain_s,
             difference_b_minus_s=gain_b-gain_s,union_d_b=d+gain_b,union_d_s=d+gain_s,
             union_three=union,none_three=1-union,
             third_b_after_s=atoms['001'],third_s_after_b=atoms['010'])
    out.update({'atom_'+k:v for k,v in atoms.items()})
    assert out['union_d_b']<=union+TOLERANCE and out['union_d_s']<=union+TOLERANCE
    return out


def bootstrap_mean(values: np.ndarray, seed: int, replicates: int=10000) -> tuple[float,float]:
    """Resample research-unit rows; do not bootstrap individual cells."""
    x=np.asarray(values,dtype=float)
    if x.ndim!=1 or len(x)<2: raise ValueError('At least two units required')
    rng=np.random.default_rng(seed)
    draws=rng.integers(0,len(x),size=(replicates,len(x)))
    lo,hi=np.quantile(x[draws].mean(axis=1),[.025,.975])
    return float(lo),float(hi)


def leave_one_out_means(values: np.ndarray) -> np.ndarray:
    x=np.asarray(values,dtype=float)
    if len(x)<2: raise ValueError('At least two units required')
    return (x.sum()-x)/(len(x)-1)
