# DLL3, B7-H3 and SEZ6 transcript-detection coverage

STCE-02 reanalyzes the published sample-level coexpression fractions in Mishra et al., Cancer Discovery (2026), Supplementary Data S2, DOI 10.1158/2159-8290.32728810 (CC BY 4.0).

This is an analysis of transcript detection among author-annotated malignant cells. It is not a reprocessing of raw scRNA-seq, a protein-density analysis, a treatment-response prediction or a dosing comparison. The primary analysis uses ten cohort-B sample rows and eighteen cohort-C donor-labelled rows. The ambiguously linked PleuralEffusion row is excluded from the primary analysis and included only in sensitivity analysis.

## Reproduce

The existing workspace Python environment already has the versions in `requirements.txt`.

```sh
python analysis/import_s2.py
python analysis/run.py
python -m unittest discover -s tests -v
```

The input workbook is preserved unchanged in `data/raw/`. The script extracts the two labelled blocks into `data/processed/coexpression.csv`; each derived row retains its original worksheet row. Only these two blocks are analyzed; published p-value tables are not used as observations. All outputs are regenerated from the extracted data.

Source download URLs, licensing and hashes are in `source-provenance.json`. The manuscript is on the accompanying website. Output CSVs are in `outputs/tables/`; numerical summaries and the fixed bootstrap seed are in `outputs/results.json`. A sample identifier is an author-provided research label, not a direct personal identifier.
