from pathlib import Path
import sys,unittest,itertools
import numpy as np
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'src'))
from coverage import derive,bootstrap_mean,leave_one_out_means


class CoverageTests(unittest.TestCase):
    def source_from_atoms(self,atoms):
        d=sum(v for s,v in atoms.items() if s[0]=='1')
        return dict(Pdll3=d,Psez6=sum(v for s,v in atoms.items() if s[1]=='1'),
            Pb7h3=sum(v for s,v in atoms.items() if s[2]=='1'),
            Psind=sum(v for s,v in atoms.items() if s[:2]=='11')/d,
            Pbind=sum(v for s,v in atoms.items() if s[0]=='1' and s[2]=='1')/d,
            P2ind=atoms['111']/d,Pany3=1-atoms['000'])

    def test_recovers_arbitrary_joint_distribution(self):
        states=[''.join(s) for s in itertools.product('01',repeat=3)]
        atoms=dict(zip(states,np.arange(1,9)/36))
        got=derive(self.source_from_atoms(atoms))
        for s,p in atoms.items(): self.assertAlmostEqual(got['atom_'+s],p,places=12)

    def test_additional_union_counts_each_cell_once(self):
        atoms={'000':.2,'001':.1,'010':.1,'011':.1,'100':.2,'101':.1,'110':.1,'111':.1}
        out=derive(self.source_from_atoms(atoms))
        self.assertAlmostEqual(out['gain_b7h3'],.2)
        self.assertAlmostEqual(out['gain_sez6'],.2)
        self.assertAlmostEqual(out['third_b_after_s'],.1)
        self.assertAlmostEqual(out['third_s_after_b'],.1)

    def test_rejects_impossible_marginals(self):
        with self.assertRaises(ValueError):
            derive(dict(Pdll3=.2,Psez6=.1,Pb7h3=.1,Psind=.8,Pbind=.9,P2ind=.1,Pany3=.3))

    def test_bootstrap_seed_and_constant(self):
        a=bootstrap_mean(np.arange(10),77,1000)
        self.assertEqual(a,bootstrap_mean(np.arange(10),77,1000))
        self.assertEqual(bootstrap_mean(np.ones(5)*.2,77),(0.2,0.2))

    def test_leave_one_out_matches_direct_calculation(self):
        x=np.array([.1,.5,-.1,.2])
        np.testing.assert_allclose(leave_one_out_means(x),[np.delete(x,i).mean() for i in range(len(x))])

    def test_actual_sources_have_valid_partitions(self):
        import csv
        p=Path(__file__).resolve().parents[1]/'data/processed/coexpression.csv'
        with p.open(encoding='utf-8') as f: rows=list(csv.DictReader(f))
        self.assertEqual(len(rows),29)
        for r in rows:
            x=derive(r)
            self.assertAlmostEqual(sum(x[k] for k in x if k.startswith('atom_')),1,places=10)
            self.assertAlmostEqual(x['union_d_b']+x['third_s_after_b'],x['union_three'],places=10)


if __name__=='__main__': unittest.main()
