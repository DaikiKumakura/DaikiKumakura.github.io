"""Independent numerical checks for clinically material timing and unit choices."""
import unittest
import numpy as np
import pandas as pd
from scipy.integrate import solve_ivp
from scipy.linalg import expm
from analysis import ROOT,Model,DOSES,TINF,REF

class IndependentChecks(unittest.TestCase):
 def test_predose_peak_and_auc_match_independent_ode(self):
  fitted=pd.read_csv(ROOT/'results/parameters.csv').estimate.to_numpy()
  for p in [REF,fitted]:
   cl,vc,vp,q=p
   def step(x,dt,rate):
    def rhs(t,a):
     c,per=a[0]/vc,a[1]/vp
     return [rate-cl*c-q*(c-per),q*(c-per),c]
    return solve_ivp(rhs,(0,dt),x,rtol=1e-10,atol=1e-11).y[:,-1]
   x=np.zeros(3);prev=0;found={};auc_start={}
   for td,d in DOSES:
    x=step(x,td-prev,0) if td>prev else x
    if td in (28,42):
     found[(td,'predose')]=x[0]/vc;auc_start[td]=x[2]
    if td==42:found[(28,'auc')]=(x[2]-auc_start[28])*24
    x=step(x,TINF,d/TINF)
    if td in (28,42):found[(td,'cmax')]=x[0]/vc
    prev=td+TINF
   x=step(x,56-prev,0);found[(42,'auc')]=(x[2]-auc_start[42])*24
   expected=[found[(td,ep)] for td in [28,42] for ep in ['predose','cmax','auc']]
   np.testing.assert_allclose(Model(p).summary(),expected,rtol=1e-8,atol=1e-8)

 def test_steady_cycle_satisfies_periodicity_and_mass_balance(self):
  cl,vc,vp,q=pd.read_csv(ROOT/'results/parameters.csv').estimate.to_numpy()
  k=np.array([[-(cl+q)/vc,q/vp],[q/vc,-q/vp]])
  for tau,dose in [(14,10),(21,10),(28,10),(21,15),(28,20)]:
   gain=np.linalg.solve(k,(expm(k*TINF)-np.eye(2))@np.array([dose/TINF,0]))
   initial=np.linalg.solve(np.eye(2)-expm(k*tau),expm(k*(tau-TINF))@gain)
   def rhs(rate):return lambda t,a:np.r_[k@a[:2]+[rate,0],a[0]/vc]
   peak=solve_ivp(rhs(dose/TINF),(0,TINF),np.r_[initial,0],rtol=1e-10,atol=1e-11).y[:,-1]
   end=solve_ivp(rhs(0),(TINF,tau),peak,rtol=1e-10,atol=1e-11).y[:,-1]
   np.testing.assert_allclose(end[:2],initial,rtol=1e-8)
   self.assertAlmostEqual(cl*end[2],dose,delta=1e-7)
   np.testing.assert_allclose(Model([cl,vc,vp,q]).steady(tau,dose),[peak[0]/vc,end[2]/tau,initial[0]/vc],rtol=1e-8)

if __name__=='__main__':unittest.main()
