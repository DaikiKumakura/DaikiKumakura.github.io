# Tarlatamab summary-data PK analysis

Public aggregate data reconstruction for research and learning. Not a patient-level PopPK analysis or a clinical dosing tool.

## Run
```bash
python -m pip install -r requirements.txt
python analysis.py
python -m unittest test_analysis.py
```
Fixed seed: 20261003. Input: data/observations.csv. Outputs: results/ and figures/.
The primary concentrations are pre-infusion geometric means on days 28 and 42, not concentrations at the end of the following interval.
Bootstrap intervals are conditional on the structural model, independent summary errors, planned dosing, and parameter bounds; they are not future-patient prediction intervals.

## Public sources
- PMDA label, 16.1.1 Table 1: https://www.pmda.go.jp/PmdaSearch/iyakuDetail/112292_4291477D1029_1_04
- PMDA review, Table 23: https://www.pmda.go.jp/drugs/2025/P20250114001/112292000_30600AMX00310_A100_1.pdf
- FDA review, Table 66 (external benchmark only): https://www.accessdata.fda.gov/drugsatfda_docs/nda/2024/761344Orig1s000MultidisciplineR.pdf
