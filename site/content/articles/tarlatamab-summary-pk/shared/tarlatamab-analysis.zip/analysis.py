"""Summary-data PK calibration, not a patient-level PopPK analysis.
Run: python analysis.py. Fixed seed; inputs and all outputs are local.
"""
from pathlib import Path
import json, platform
import numpy as np
import pandas as pd
from scipy.optimize import least_squares
from scipy.integrate import solve_ivp
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

ROOT=Path(__file__).resolve().parent
OBS=pd.read_csv(ROOT/'data/observations.csv')
SE=np.sqrt(np.log1p((OBS.cv_percent.to_numpy()/100)**2)/OBS.n.to_numpy())
Y=OBS.value.to_numpy(); SEED=20261003
LO=np.log([.05,.3,.1,.01]); HI=np.log([5,30,300,20])
REF=np.array([.649,3.44,5.06,1.11]) # CL,Vc,Vp,Q; external comparison only
NAMES=['CL','Vc','Vp','Q']; TINF=1/24
DOSES=[(0,1),(7,10),(14,10),(28,10),(42,10)]

class Model:
 def __init__(self,p):
  self.cl,self.vc=p[:2]
  if len(p)==2:self.K=np.array([[-self.cl/self.vc]])
  else:
   vp,q=p[2:];self.K=np.array([[-(self.cl+q)/self.vc,q/vp],[q/self.vc,-q/vp]])
  self.n=len(self.K);self.inv=np.linalg.inv(self.K)
  self.lam,self.vec=np.linalg.eig(self.K);self.ivec=np.linalg.inv(self.vec)
 def trans(self,dt):return (self.vec*np.exp(self.lam*dt))@self.ivec
 def advance(self,a,dt,rate=0):
  e=self.trans(dt);b=np.zeros(self.n);b[0]=rate
  return e@a+self.inv@(e-np.eye(self.n))@b
 def integrated(self,a,dt,rate=0):
  e=self.trans(dt);b=np.zeros(self.n);b[0]=rate
  return (self.inv@(e-np.eye(self.n))@a+self.inv@(self.inv@(e-np.eye(self.n))-dt*np.eye(self.n))@b)[0]/self.vc
 def before(self,t):
  a=np.zeros(self.n)
  for td,d in DOSES:
   if td<t-1e-9:a+=self.advance(self.advance(np.zeros(self.n),TINF,d/TINF),t-td-TINF)
  return a
 def summary(self):
  out=[]
  for day in [28,42]:
   a=self.before(day);b=self.advance(a,TINF,10/TINF)
   out.extend([a[0]/self.vc,b[0]/self.vc,24*(self.integrated(a,TINF,10/TINF)+self.integrated(b,14-TINF))])
  return np.array(out)
 def steady(self,tau,dose=10):
  gain=self.advance(np.zeros(self.n),TINF,dose/TINF)
  a=np.linalg.solve(np.eye(self.n)-self.trans(tau),self.trans(tau-TINF)@gain)
  peak=self.advance(a,TINF,dose/TINF)[0]/self.vc
  return np.array([peak,dose/(self.cl*tau),a[0]/self.vc])
 def conc(self,times):
  out=[]
  for t in times:
   a=np.zeros(self.n)
   for td,d in DOSES:
    if t>=td:
     u=min(t-td,TINF);part=self.advance(np.zeros(self.n),u,d/TINF)
     a+=self.advance(part,max(0,t-td-TINF))
   out.append(a[0]/self.vc)
  return np.array(out)

def fit(y,start,mask=None):
 mask=np.ones(6,dtype=bool) if mask is None else mask
 return least_squares(lambda z:(np.log(Model(np.exp(z)).summary()[mask])-np.log(y[mask]))/SE[mask],start,bounds=(LO,HI),max_nfev=500,ftol=1e-10,xtol=1e-10,gtol=1e-10)

def main():
 rng=np.random.default_rng(SEED)
 for d in ['results','figures']:(ROOT/d).mkdir(exist_ok=True)
 fits=[fit(Y,rng.uniform(LO+.1,HI-.1)) for _ in range(30)]
 best=min(fits,key=lambda x:np.sum(x.fun**2));z=best.x;p=np.exp(z);model=Model(p)
 one=least_squares(lambda x:(np.log(Model(np.exp(x)).summary())-np.log(Y))/SE,np.log([.7,4]),bounds=(LO[:2],HI[:2]),max_nfev=500)
 pred=model.summary();comparison=OBS.copy();comparison['predicted']=pred;comparison['percent_error']=100*(pred/Y-1);comparison.to_csv(ROOT/'results/fit.csv',index=False)
 pd.DataFrame({'parameter':NAMES,'estimate':p,'external_reference':REF,'unit':['L/day','L','L','L/day']}).to_csv(ROOT/'results/parameters.csv',index=False)
 boots=[];success=[]
 for i in range(300):
  # Conditional on the fitted summary model; independent endpoint errors are an assumption.
  by=np.exp(np.log(pred)+rng.normal(size=6)*SE);b=fit(by,z)
  boots.append(np.exp(b.x));success.append(bool(b.success))
 boots=np.array(boots);pd.DataFrame(boots,columns=NAMES).to_csv(ROOT/'results/bootstrap.csv',index=False)
 profiles=[]
 for k in range(4):
  for value in np.unique(np.r_[np.linspace(LO[k]+.001,HI[k]-.001,31),np.linspace(max(LO[k]+.001,z[k]-.7),min(HI[k]-.001,z[k]+.7),31),z[k]]):
   keep=np.arange(4)!=k
   def residual(x):
    zz=z.copy();zz[k]=value;zz[keep]=x
    return (np.log(Model(np.exp(zz)).summary())-np.log(Y))/SE
   f=least_squares(residual,np.clip(z[keep],LO[keep]+1e-6,HI[keep]-1e-6),bounds=(LO[keep],HI[keep]),max_nfev=300)
   profiles.append([NAMES[k],np.exp(value),np.sum(f.fun**2)-np.sum(best.fun**2)])
 profiles=pd.DataFrame(profiles,columns=['parameter','value','delta_objective']);profiles.to_csv(ROOT/'results/profiles.csv',index=False)
 rows=[];bmetrics=np.array([[Model(b).steady(t) for t in [14,21,28]] for b in boots]);metrics=np.array([model.steady(t) for t in [14,21,28]])
 for j,t in enumerate([14,21,28]):
  for k,endpoint in enumerate(['Cmax','Cavg','Ctrough']):
   ratios=bmetrics[:,j,k]/bmetrics[:,0,k];lo,hi=np.quantile(ratios,[.025,.975])
   rows.append([t,endpoint,metrics[j,k],metrics[j,k]/metrics[0,k],lo,hi])
 pd.DataFrame(rows,columns=['interval_days','endpoint','ug_ml','ratio_to_Q2W','conditional_p025','conditional_p975']).to_csv(ROOT/'results/maintenance.csv',index=False)
 intensity=[]
 for t,d in [(14,10),(21,15),(28,20)]:
  value=model.steady(t,d);ratio=value/metrics[0]
  intensity.append([t,d,*value,*ratio])
 pd.DataFrame(intensity,columns=['interval_days','dose_mg','Cmax','Cavg','Ctrough','Cmax_ratio','Cavg_ratio','Ctrough_ratio']).to_csv(ROOT/'results/equal_intensity.csv',index=False)
 hold=[]
 for day in [28,42]:
  mask=OBS.day.to_numpy()!=day;h=fit(Y,z,mask);hp=Model(np.exp(h.x)).summary()
  for i in np.where(~mask)[0]:hold.append([day,OBS.endpoint.iloc[i],Y[i],hp[i],100*(hp[i]/Y[i]-1)])
 pd.DataFrame(hold,columns=['held_day','endpoint','observed','predicted','percent_error']).to_csv(ROOT/'results/holdout.csv',index=False)
 # Independent numerical ODE and quadrature check, split at infusion boundaries.
 a=np.zeros(3);prev=0;errors=[]
 for td,d in DOSES:
  if td>prev:
   f=solve_ivp(lambda t,x:np.r_[model.K@x[:2],x[0]/model.vc],(prev,td),a,rtol=1e-10,atol=1e-11);a=f.y[:,-1]
  start_a=a.copy()
  f=solve_ivp(lambda t,x:np.r_[model.K@x[:2]+[d/TINF,0],x[0]/model.vc],(td,td+TINF),a,rtol=1e-10,atol=1e-11);a=f.y[:,-1]
  errors.append(float(np.max(np.abs(a[:2]-model.advance(start_a[:2],TINF,d/TINF)))))
  prev=td+TINF
 numerical_auc=solve_ivp(lambda t,x:np.r_[model.K@x[:2],x[0]/model.vc],(prev,56),a,rtol=1e-10,atol=1e-11).y[2,-1]-start_a[2]
 analytic_auc=model.summary()[-1]/24
 assert max(errors)<1e-7 and abs(numerical_auc-analytic_auc)<1e-7
 for t in [14,21,28]:
  np.testing.assert_allclose(model.steady(t)[1],10/(p[0]*t),rtol=1e-12)
 info={'seed':SEED,'bootstrap_replicates':300,'bootstrap_converged':sum(success),'multistart_success':sum(f.success for f in fits),'multistart_objective_min':float(np.sum(best.fun**2)),'multistart_objective_max':float(max(np.sum(f.fun**2) for f in fits)),'one_comp_objective':float(np.sum(one.fun**2)),'one_comp_parameters':np.exp(one.x).tolist(),'max_abs_percent_error':float(max(abs(100*(pred/Y-1)))),'terminal_half_life_day':float(-np.log(2)/max(model.lam)),'bootstrap_upper_bound_fraction':dict(zip(NAMES,(np.mean(boots>np.exp(HI)*.999,axis=0)).tolist())),'bootstrap_lower_bound_fraction':dict(zip(NAMES,(np.mean(boots<np.exp(LO)*1.001,axis=0)).tolist())),'independent_ode_max_amount_error_mg':max(errors),'independent_auc_error_ug_day_ml':float(abs(numerical_auc-analytic_auc)),'bounds_lower':np.exp(LO).tolist(),'bounds_upper':np.exp(HI).tolist(),'python':platform.python_version(),'numpy':np.__version__}
 sensitivity=[]
 for rho in [0,.5,.8]:
  block=np.full((3,3),rho);np.fill_diagonal(block,1)
  cor=np.zeros((6,6));cor[:3,:3]=block;cor[3:,3:]=block
  chol=np.linalg.cholesky(SE[:,None]*cor*SE[None,:])
  f=least_squares(lambda x:np.linalg.solve(chol,np.log(Model(np.exp(x)).summary())-np.log(Y)),z,bounds=(LO,HI),max_nfev=500)
  mm=Model(np.exp(f.x));ratio=mm.steady(28)/mm.steady(14)
  sensitivity.append([rho,*np.exp(f.x),*ratio])
 pd.DataFrame(sensitivity,columns=['within_cycle_rho',*NAMES,'Q4W_Cmax_ratio','Q4W_Cavg_ratio','Q4W_Ctrough_ratio']).to_csv(ROOT/'results/correlation_sensitivity.csv',index=False)
 (ROOT/'results/validation.json').write_text(json.dumps(info,indent=2),encoding='utf-8')
 plt.rcParams.update({'font.size':10,'axes.spines.top':False,'axes.spines.right':False,'savefig.dpi':160})
 fig,axs=plt.subplots(3,1,figsize=(6.6,8.2))
 for k,ep in enumerate(['predose','cmax','auc']):
  sub=comparison[comparison.endpoint==ep];sj=np.sqrt(np.log1p((sub.cv_percent.to_numpy()/100)**2)/sub.n.to_numpy());lower=sub.value.to_numpy()*np.exp(-1.96*sj);upper=sub.value.to_numpy()*np.exp(1.96*sj)
  axs[k].errorbar(sub.day-.12,sub.value,yerr=[sub.value-lower,upper-sub.value],label='Observed GM (approx. 95% interval)',color='#18324a',fmt='o',capsize=4);axs[k].scatter(sub.day+.12,sub.predicted,label='Model',marker='x',color='#dc7b42',s=70);axs[k].set(title={'predose':'Pre-infusion concentration','cmax':'Maximum concentration','auc':'AUC over 336 hours'}[ep],xlabel='Time from first dose (day)',ylabel='h × µg/mL' if ep=='auc' else 'µg/mL',xticks=[28,42])
 for ax in axs:ax.set_ylim(bottom=0)
 axs[0].legend();fig.tight_layout();fig.savefig(ROOT/'figures/01-observed-fit.png');plt.close(fig)
 times=np.unique(np.r_[np.linspace(0,56,1600),*[td+TINF for td,d in DOSES]])
 fig,ax=plt.subplots(figsize=(7,4.5));ax.plot(times,model.conc(times),label='Fitted representative curve')
 for ep,m in [('predose','o'),('cmax','^')]:
  sub=OBS[OBS.endpoint==ep];ax.scatter(sub.day+(TINF if ep=='cmax' else 0),sub.value,label='Observed GM '+ep,marker=m,s=55)
 ax.set(xlabel='Time from first dose (day)',ylabel='Concentration (µg/mL)',ylim=(0,None));ax.legend(loc='upper center',bbox_to_anchor=(.5,1.28),fontsize=9);fig.tight_layout();fig.savefig(ROOT/'figures/02-time-course.png');plt.close(fig)
 fig,axs=plt.subplots(2,2,figsize=(7,6))
 for name,ax in zip(NAMES,axs.flat):
  sub=profiles[profiles.parameter==name];ax.plot(sub.value,sub.delta_objective);ax.axhline(3.84,color='#888',ls='--');ax.set(xscale='log',xlabel=name,ylabel='Delta weighted log SSE',ylim=(0,12))
 fig.tight_layout();fig.savefig(ROOT/'figures/03-profiles.png');plt.close(fig)
 fig,axs=plt.subplots(3,1,figsize=(6.6,8.2));table=pd.DataFrame(rows,columns=['tau','ep','value','ratio','lo','hi'])
 for ep,ax in zip(['Cmax','Cavg','Ctrough'],axs):
  sub=table[table.ep==ep];ax.fill_between(sub.tau,sub.lo,sub.hi,alpha=.18);ax.plot(sub.tau,sub.ratio,'o-');ax.set(title=ep,xlabel='Interval (day)',ylabel='Ratio to 10 mg Q2W',xticks=[14,21,28],ylim=(0,1.15))
 fig.tight_layout();fig.savefig(ROOT/'figures/04-maintenance.png');plt.close(fig)
 fig,ax=plt.subplots(figsize=(6.6,4.5));x=np.arange(3)
 for k,(label,color) in enumerate([('Cmax','#3478b8'),('Cavg','#18324a'),('Ctrough','#dc7b42')]):
  rr=np.array(intensity)[:,5+k];ax.plot(x,rr,'o-',label=label,color=color)
 ax.axhline(1,color='#888',ls='--');ax.set(xticks=x,xticklabels=['10 mg Q2W','15 mg Q3W','20 mg Q4W'],ylabel='Ratio to 10 mg Q2W',ylim=(0,2),title='Same average exposure, different peaks and troughs');ax.legend();fig.tight_layout();fig.savefig(ROOT/'figures/05-equal-intensity.png');plt.close(fig)
 print(json.dumps(info,indent=2))

if __name__=='__main__':main()
