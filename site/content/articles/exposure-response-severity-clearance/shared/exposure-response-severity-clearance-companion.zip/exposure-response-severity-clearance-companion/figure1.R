# Figure 1: causal structure assumed in the simulation (drawn, not estimated).
suppressPackageStartupMessages(library(ggplot2))
script_dir <- dirname(normalizePath(sub("^--file=", "", grep("^--file=", commandArgs(FALSE), value = TRUE)[1]), winslash = "/"))
nodes <- data.frame(label = c("Randomized dose", "Exposure\n(dose / clearance)", "Survival", "Clearance (CL)", "Disease severity\n(worsens over time)", "Baseline severity\nmarker (noisy)"),
  x = c(1.3, 5, 8.7, 5, 5, 1.3), y = c(1.2, 1.2, 1.2, 3.0, 4.7, 4.7),
  fill = c("#F5C45E", "#FFFFFF", "#FFFFFF", "#FFFFFF", "#E8A07A", "#E8A07A"), stringsAsFactors = FALSE)
edges <- data.frame(x0 = c(2.35, 6.1, 5, 5, 5.9, 3.95), y0 = c(1.2, 1.2, 4.1, 2.45, 4.35, 4.7), x1 = c(3.9, 7.95, 5, 5, 8.4, 2.4), y1 = c(1.2, 1.2, 3.55, 1.85, 1.65, 4.7),
  col = c("black", "#0072B2", "#D55E00", "black", "#D55E00", "#777777"), stringsAsFactors = FALSE)
labs_df <- data.frame(x = c(7.0, 5.15, 7.7, 3.2), y = c(1.5, 3.8, 3.35, 4.95), label = c("effect of interest", "raises CL", "raises hazard", "measured with error"),
  col = c("#0072B2", "#D55E00", "#D55E00", "#777777"), hj = c(0.5, 0, 0.5, 0.5), stringsAsFactors = FALSE)
g <- ggplot() +
  geom_segment(data = edges, aes(x = x0, y = y0, xend = x1, yend = y1, colour = col), arrow = arrow(length = unit(0.14, "inches"), type = "closed"), linewidth = 0.8) +
  geom_label(data = nodes, aes(x = x, y = y, label = label, fill = fill), size = 3.5, label.padding = unit(0.5, "lines"), colour = "black") +
  geom_text(data = labs_df, aes(x = x, y = y, label = label, colour = col, hjust = hj), size = 3.2, fontface = "italic") +
  scale_colour_identity() + scale_fill_identity() +
  coord_cartesian(xlim = c(0, 10), ylim = c(0.5, 5.4)) + theme_void(base_size = 11) +
  labs(title = "Disease severity raises clearance and hazard", subtitle = "Dose is randomized and independent of severity; exposure is not, so exposure and survival are associated even without a drug effect")
ggsave(file.path(script_dir, "figures/figure-1-dag.png"), g, width = 10, height = 4.6, dpi = 160, bg = "white")
