# Summaries and figures for the simulation in simulate.R (reads results/replicates.csv).
suppressPackageStartupMessages(library(ggplot2))
script_dir <- dirname(normalizePath(sub("^--file=", "", grep("^--file=", commandArgs(FALSE), value = TRUE)[1]), winslash = "/"))
d <- read.csv(file.path(script_dir, "results/replicates.csv"))
for (extra in list.files(file.path(script_dir, "results"), pattern = "^replicates-extra.*[.]csv$", full.names = TRUE)) { e <- read.csv(extra); for (v in setdiff(names(e), names(d))) d[[v]] <- NA; for (v in setdiff(names(d), names(e))) e[[v]] <- NA; d <- rbind(d, e[names(d)]) }
stopifnot(!anyNA(d$coef), !anyNA(d$se))
L2 <- log(2)
labels <- c(baseline_exposure = "Baseline exposure, unadjusted",
            baseline_exposure_adj_marker = "Baseline exposure, adjusted for severity marker",
            baseline_exposure_adj_true_severity = "Baseline exposure, adjusted for true severity",
            time_varying_exposure = "Time-varying exposure",
            dose_arm = "Randomized dose")
d$model_label <- factor(labels[d$model], levels = labels[c("baseline_exposure", "baseline_exposure_adj_marker", "baseline_exposure_adj_true_severity", "time_varying_exposure", "dose_arm")])
agg <- do.call(rbind, lapply(split(d, list(d$scenario, d$model), drop = TRUE), function(x) {
  z <- x$coef / x$se; R <- nrow(x)
  data.frame(scenario = x$scenario[1], model = x$model[1], n = x$n[1], beta_true = x$beta[1], gamma = x$gamma[1], kappa = x$kappa[1], proxy_sd = x$proxy_sd[1],
             reps = R, events_mean = mean(x$events),
             hr_double_true = exp(x$beta[1] * L2), hr_double_mean = exp(mean(x$coef) * L2),
             hr_double_q025 = exp(quantile(x$coef, 0.025) * L2), hr_double_q975 = exp(quantile(x$coef, 0.975) * L2),
             bias_coef = mean(x$coef) - x$beta[1], bias_mcse = sd(x$coef) / sqrt(R),
             sd_coef = sd(x$coef), mean_se = mean(x$se),
             coverage = mean(abs(x$coef - x$beta[1]) < 1.96 * x$se),
             protective_sig = mean(z < -1.96), harmful_sig = mean(z > 1.96))
}))
agg <- agg[order(agg$scenario, agg$model), ]
rownames(agg) <- NULL
write.csv(agg, file.path(script_dir, "results/summary.csv"), row.names = FALSE)
print(within(agg[, c("scenario", "model", "events_mean", "hr_double_true", "hr_double_mean", "bias_coef", "bias_mcse", "coverage", "protective_sig", "sd_coef", "mean_se")],
             {events_mean <- round(events_mean); hr_double_mean <- round(hr_double_mean, 3); hr_double_true <- round(hr_double_true, 3); bias_coef <- round(bias_coef, 3); bias_mcse <- round(bias_mcse, 3);
               coverage <- round(coverage, 3); protective_sig <- round(protective_sig, 3); sd_coef <- round(sd_coef, 3); mean_se <- round(mean_se, 3)}), row.names = FALSE)

okabe <- c("#999999", "#E69F00", "#009E73", "#D55E00", "#0072B2")
shapes <- c(16, 17, 15, 18, 8); names(okabe) <- levels(d$model_label)
main <- grep("^[AB][123] ", unique(d$scenario), value = TRUE)
p <- agg[agg$scenario %in% main, ]; p$model_label <- factor(labels[p$model], levels = levels(d$model_label))
p$panel <- factor(sub(" ", "\n", sub("^([AB][123]) ", "\1 ", p$scenario)), levels = unique(sub(" ", "\n", p$scenario)))
p$panel <- factor(paste0(ifelse(p$beta_true == 0, "No drug effect", "Drug effect (HR 0.84 per doubling)"), "; ", c("0", "0.3", "0.6")[match(p$gamma, c(0, 0.3, 0.6))] , " = log HR per SD severity"), levels = unique(paste0(ifelse(p$beta_true == 0, "No drug effect", "Drug effect (HR 0.84 per doubling)"), "; ", c("0", "0.3", "0.6")[match(p$gamma, c(0, 0.3, 0.6))], " = log HR per SD severity")))
p$gamma_label <- factor(paste0("Severity effect: log HR ", p$gamma, " per SD"))
p$effect_label <- factor(ifelse(p$beta_true == 0, "No drug effect (true HR = 1)", "Drug effect (true HR = 0.84 per doubling)"), levels = c("No drug effect (true HR = 1)", "Drug effect (true HR = 0.84 per doubling)"))
g1 <- ggplot(p, aes(x = hr_double_mean, y = model_label, colour = model_label, shape = model_label)) +
  geom_vline(aes(xintercept = hr_double_true), linetype = 2, colour = "black") +
  geom_errorbar(aes(xmin = hr_double_q025, xmax = hr_double_q975), orientation = "y", width = 0.25, linewidth = 0.5) + geom_point(size = 2.4) +
  facet_grid(gamma_label ~ effect_label, labeller = labeller(gamma_label = label_wrap_gen(12))) + scale_colour_manual(values = okabe, guide = "none") + scale_shape_manual(values = shapes, guide = "none") +
  scale_y_discrete(limits = rev(levels(d$model_label))) + scale_x_continuous(limits = c(0.35, 1.3), breaks = c(0.4, 0.6, 0.8, 1, 1.2)) +
  labs(x = "Hazard ratio of death per doubling of exposure (mean and central 95% range over 1,000 simulated trials)", y = NULL,
       title = "Estimated exposure effect on survival by estimator", subtitle = "Dashed line: true value. Each trial has 400 patients randomized 1:1:1 to relative doses 1, 2 and 4") +
  theme_bw(base_size = 11) + theme(panel.grid.minor = element_blank(), strip.text = element_text(size = 9))
ggsave(file.path(script_dir, "figures/figure-2-estimates.png"), g1, width = 10, height = 6.2, dpi = 160)

q <- p; q$what <- ifelse(q$beta_true == 0, "Declared higher exposure protective, p < 0.05 (no drug effect: false positive)", "Declared higher exposure protective, p < 0.05 (drug effect present: power)"); q$what <- factor(q$what, levels = unique(q$what[order(q$beta_true)]))
g2 <- ggplot(q, aes(x = protective_sig, y = model_label, fill = model_label)) + geom_col(width = 0.65) +
  geom_text(aes(label = sprintf("%.0f%%", 100 * protective_sig)), hjust = -0.15, size = 3) +
  facet_grid(gamma_label ~ what, labeller = labeller(what = label_wrap_gen(38), gamma_label = label_wrap_gen(12))) + scale_fill_manual(values = okabe, guide = "none") +
  scale_y_discrete(limits = rev(levels(d$model_label))) + scale_x_continuous(limits = c(0, 1.12), labels = scales::percent_format(accuracy = 1)) +
  labs(x = "Share of 1,000 simulated trials", y = NULL, title = "How often each estimator reports a protective exposure effect") +
  theme_bw(base_size = 11) + theme(panel.grid.minor = element_blank(), strip.text = element_text(size = 9))
ggsave(file.path(script_dir, "figures/figure-3-decisions.png"), g2, width = 10, height = 6.2, dpi = 160)
cat("figures written\n")
