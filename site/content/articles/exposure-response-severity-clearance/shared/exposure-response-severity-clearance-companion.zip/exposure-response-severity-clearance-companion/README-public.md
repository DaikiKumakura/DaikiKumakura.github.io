# Companion: exposure-response analysis when severity drives clearance

Simulation code and aggregate results for the article "How often does an exposure–response analysis find a drug effect that is not there? Simulated trials with severity-driven clearance". No patient data are used.

## Files

- `simulate.R`: simulates the randomized dose-ranging trials and fits the five Cox models (`Rscript simulate.R 1000` for scenarios A1 to S4, about 15 minutes, seed 20261115, writes `results/replicates.csv`, about 6 MB; `Rscript simulate.R 1000 S5,S6,S7,S8` for the extra sensitivity scenarios, seed 20261116, writes `results/replicates-extra.csv`). Do not edit the script while it runs.
- `summarize.R`: summarizes the replicates (`results/summary.csv`) and draws Figures 2 and 3.
- `figure1.R`: draws Figure 1 (the assumed causal structure).
- `results/summary.csv`: aggregate results for all fourteen scenarios (the numbers in Tables 1 and 2 and the text).
- `results/session-info.txt`: R 4.5.3 and package versions used (survival 3.8-6).

## Reproduce

```
Rscript simulate.R 1000
Rscript summarize.R
Rscript figure1.R
```

The scripts find their own folder, so they can be run from any directory.
