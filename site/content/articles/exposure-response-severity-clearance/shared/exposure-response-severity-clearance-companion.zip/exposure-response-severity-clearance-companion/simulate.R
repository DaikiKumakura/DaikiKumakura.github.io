# Simulation of exposure-survival analysis when clearance depends on disease severity.
# Question: how large is the bias of common exposure-response estimators, and how often do they
# wrongly report that higher exposure prolongs survival when the drug has no effect?
# R 4.5.3, survival (see sessionInfo in results/session-info.txt). Run: Rscript simulate.R 1000   (main scenarios A1-S4);
# Rscript simulate.R 1000 S5,S6,S7,S8   (extra sensitivity scenarios, written to results/replicates-extra.csv). Original line: Rscript simulate.R
suppressPackageStartupMessages(library(survival))
args <- commandArgs(trailingOnly = TRUE)
script_dir <- dirname(normalizePath(sub("^--file=", "", grep("^--file=", commandArgs(FALSE), value = TRUE)[1]), winslash = "/"))
SEED <- 20261115L; NREP <- if (length(args) >= 1) as.integer(args[1]) else 1000L
H0 <- 0.04            # baseline hazard per month at severity 0, exposure 1
FOLLOW <- 24L         # months of follow-up (administrative censoring)
DROP <- 0.01          # independent dropout hazard per month
DOSES <- c(1, 2, 4)   # randomized dose levels (relative units), equal allocation
PK_SD <- 0.10         # residual error of log concentration
G_MEAN <- 0.04; G_SD <- 0.03   # drift of severity per month (SD units): the disease worsens

sim_trial <- function(n, beta, gamma, kappa, eta_sd, proxy_sd, doses = DOSES, pk_sd = PK_SD, g_mean = G_MEAN) {
  dose <- sample(doses, n, replace = TRUE)
  s0 <- rnorm(n); g <- rnorm(n, g_mean, G_SD); eta <- rnorm(n, 0, eta_sd)
  b <- s0 + rnorm(n, 0, proxy_sd)                    # imperfect baseline severity marker
  t_ev <- rep(NA_real_, n); t_dr <- rep(NA_real_, n)
  grid <- vector("list", FOLLOW)                     # log concentration at each monthly visit
  alive <- rep(TRUE, n)
  for (m in 0:(FOLLOW - 1)) {
    s <- s0 + g * m
    lc <- log(dose) - kappa * s - eta                # log steady-state concentration = log(dose / CL)
    grid[[m + 1]] <- lc + rnorm(n, 0, pk_sd)
    h <- H0 * exp(gamma * s + beta * lc)
    ev <- alive & (runif(n) < 1 - exp(-h)); dr <- alive & !ev & (runif(n) < 1 - exp(-DROP))
    t_ev[ev] <- m + runif(sum(ev)); t_dr[dr] <- m + runif(sum(dr))
    alive <- alive & !ev & !dr
  }
  time <- ifelse(!is.na(t_ev), t_ev, ifelse(!is.na(t_dr), t_dr, FOLLOW))
  status <- as.integer(!is.na(t_ev))
  list(d = data.frame(id = seq_len(n), time = time, status = status, ldose = log(dose),
                      e0 = grid[[1]], b = b, s0 = s0), grid = grid)
}

fit_one <- function(tr) {
  d <- tr$d; out <- list()
  take <- function(f, nm, term) { s <- summary(f)$coefficients[term, ]; out[[nm]] <<- c(s["coef"], s["se(coef)"]) }
  take(coxph(Surv(time, status) ~ e0, d), "baseline_exposure", "e0")
  take(coxph(Surv(time, status) ~ e0 + b, d), "baseline_exposure_adj_marker", "e0")
  take(coxph(Surv(time, status) ~ e0 + s0, d), "baseline_exposure_adj_true_severity", "e0")
  take(coxph(Surv(time, status) ~ ldose, d), "dose_arm", "ldose")
  # time-varying exposure: monthly intervals, covariate = concentration at the start of the interval
  last <- pmin(ceiling(d$time), FOLLOW); n_int <- pmax(last, 1L)
  rows <- rep(seq_len(nrow(d)), n_int); k <- sequence(n_int) - 1L
  start <- k; stop <- pmin(k + 1, d$time[rows])
  keep <- stop > start
  lc <- vapply(seq_along(rows), function(i) tr$grid[[k[i] + 1]][rows[i]], numeric(1))
  ev <- as.integer(d$status[rows] == 1 & (k + 1) >= d$time[rows])
  tv <- data.frame(start = start, stop = stop, ev = ev, lc = lc)[keep, ]
  take(coxph(Surv(start, stop, ev) ~ lc, tv), "time_varying_exposure", "lc")
  out
}

run_scenario <- function(name, n = 400, beta = 0, gamma = 0.3, kappa = 0.25, eta_sd = 0.25, proxy_sd = 0.8, doses = DOSES, pk_sd = PK_SD, g_mean = G_MEAN, nrep = NREP) {
  res <- lapply(seq_len(nrep), function(r) {
    tr <- sim_trial(n, beta, gamma, kappa, eta_sd, proxy_sd, doses, pk_sd, g_mean)
    fits <- fit_one(tr)
    do.call(rbind, lapply(names(fits), function(m) data.frame(rep = r, model = m, coef = fits[[m]][1], se = fits[[m]][2],
                                                               events = sum(tr$d$status))))
  })
  res <- do.call(rbind, res); res$scenario <- name
  res$n <- n; res$beta <- beta; res$gamma <- gamma; res$kappa <- kappa; res$eta_sd <- eta_sd; res$proxy_sd <- proxy_sd
  res$dose_span <- max(doses) / min(doses); res$pk_sd <- pk_sd; res$g_mean <- g_mean
  res
}

ONLY <- if (length(args) >= 2) strsplit(args[2], ",")[[1]] else NULL   # e.g. "S5,S6,S7,S8": run only these scenarios
set.seed(if (is.null(ONLY)) SEED else SEED + 1L)   # extra scenarios use their own seed so that the main results are unchanged
scen <- list(
  list(name = "A1 null, no confounding", beta = 0, gamma = 0),
  list(name = "A2 null, moderate confounding", beta = 0, gamma = 0.3),
  list(name = "A3 null, strong confounding", beta = 0, gamma = 0.6),
  list(name = "B1 effect, no confounding", beta = -0.25, gamma = 0),
  list(name = "B2 effect, moderate confounding", beta = -0.25, gamma = 0.3),
  list(name = "B3 effect, strong confounding", beta = -0.25, gamma = 0.6),
  list(name = "S1 null, moderate, n=1000", beta = 0, gamma = 0.3, n = 1000),
  list(name = "S2 null, moderate, kappa=0.5", beta = 0, gamma = 0.3, kappa = 0.5),
  list(name = "S3 null, moderate, kappa=0.1", beta = 0, gamma = 0.3, kappa = 0.1),
  list(name = "S4 null, moderate, marker SD 0.3", beta = 0, gamma = 0.3, proxy_sd = 0.3),
  list(name = "S5 null, moderate, dose span 2", beta = 0, gamma = 0.3, doses = c(1, 1.5, 2)),
  list(name = "S6 null, moderate, PK error SD 0.3", beta = 0, gamma = 0.3, pk_sd = 0.3),
  list(name = "S7 null, moderate, clearance variability SD 0.5", beta = 0, gamma = 0.3, eta_sd = 0.5),
  list(name = "S8 null, moderate, no severity drift", beta = 0, gamma = 0.3, g_mean = 0),
  list(name = "S9 null, moderate, combined changes", beta = 0, gamma = 0.3, doses = c(1, 1.5, 2), pk_sd = 0.3, eta_sd = 0.5, g_mean = 0),
  list(name = "S10 effect, moderate, combined changes", beta = -0.25, gamma = 0.3, doses = c(1, 1.5, 2), pk_sd = 0.3, eta_sd = 0.5, g_mean = 0))
if (is.null(ONLY)) scen <- scen[1:10] else scen <- scen[sub(" .*", "", vapply(scen, function(x) x$name, "")) %in% ONLY]
all <- do.call(rbind, lapply(scen, function(s) { t0 <- Sys.time(); r <- do.call(run_scenario, s); cat(s$name, format(round(difftime(Sys.time(), t0, units = "mins"), 1)), "\n"); r }))
dir.create(file.path(script_dir, "results"), showWarnings = FALSE)
write.csv(all, file.path(script_dir, if (is.null(ONLY)) "results/replicates.csv" else if (identical(ONLY, c("S5", "S6", "S7", "S8"))) "results/replicates-extra.csv" else paste0("results/replicates-extra-", paste(ONLY, collapse = "-"), ".csv")), row.names = FALSE)
if (is.null(ONLY)) writeLines(capture.output(sessionInfo()), file.path(script_dir, "results/session-info.txt"))
