"""Fetch the three public input files at pinned revisions and verify their SHA-256 (input-provenance.json)."""
from pathlib import Path
import hashlib
import json

import requests

ROOT = Path(__file__).resolve().parent
GH = "https://raw.githubusercontent.com/kosonocky/bits-to-binders/43eeeaf7e6ab629e796c9fe8d20b0ef70a3610d9/"
HF = "https://huggingface.co/datasets/Anthropic/scorpion-toxin-binder-design/resolve/0bac3d0286f7f83b5339f5b4f1e67fbe47a6e7c1/"
FILES = {"inputs/repo/data/12k_all_results.csv": GH + "data/12k_all_results.csv",
         "inputs/repo/data/individual/master_data_teams.csv": GH + "data/individual/master_data_teams.csv",
         "inputs/claude-hf/design.csv": HF + "design.csv"}
SHA = {
       "inputs/repo/data/12k_all_results.csv": "de271331891d3c0a1830ca387ea4c17b8e252c745a8d961474297e64b9d598e6",
       "inputs/repo/data/individual/master_data_teams.csv": "43c63c4176df1a49e36d401c02ae0c9018b93c3c3441badd000903e096537402",
       "inputs/claude-hf/design.csv": "3eb9dc87ee7582120c6a1cf74164d0c611ba269d76a85487b846acd688bfd604"}


def main():
    for rel, url in FILES.items():
        dest = ROOT / rel
        if not dest.exists():
            dest.parent.mkdir(parents=True, exist_ok=True)
            r = requests.get(url, timeout=120)
            r.raise_for_status()
            dest.write_bytes(r.content)
        # line endings are normalised (CRLF -> LF) before hashing: raw GitHub serves LF, a Windows checkout may hold CRLF
        assert hashlib.sha256(dest.read_bytes().replace(bytes([13, 10]), bytes([10]))).hexdigest() == SHA[rel], f"checksum mismatch: {rel}"
    print("inputs verified")


if __name__ == "__main__":
    main()
