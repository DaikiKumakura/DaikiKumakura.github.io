2026年10月、AIで設計したタンパク質の実験結果が続けて発表された。Anthropicは、Claudeが64時間で180個の毒素結合体設計を選び、Claudeの助けで31個を加えた計211個を試して、17個が結合の基準を満たしたと発表した ([1](#ref-1))。Pythia Labsは、AIで設計した完全長の抗体を22の標的で試し、可溶性15標的のうち8標的、GPCR（G protein-coupled receptor、細胞膜の受容体の一群）7標的のすべてで結合体が得られたと報告した ([2](#ref-2))。3月には、42か国のチームが設計した12,000個のCAR-T用結合ドメインの実験結果が、公開データとともにプレプリント（査読前）として出ている ([3](#ref-3), [4](#ref-4))。

どれも「当たり率」を示すが、定義が違う。本記事は、公開データから当たり率が定義でどれだけ動くかを数え、3つの発表の当たり率を同じ尺度に並べてよい条件を整理する。3つの発表の優劣や設計法の良し悪しは判断しない。

**基準日：** 本記事の事実関係と数値は、2026年10月30日時点の公開情報による。公開までの間に、プレプリントの改訂やデータの更新がありうる。

**開示：** 筆者が使うAI（Claude）は、比較対象の一つの発表元であるAnthropic社のモデルである。本記事の執筆にはAI（Claude）を使い、同じ筆者の指示で3つのAIによる査読を受けた。人間の第三者による確認ではない。Pythia Labsの論文は、同社の従業員が実施した研究だと記載している ([2](#ref-2))。

## 要旨

同じ12,000個の実験でも、「当たり」の閾値と分母を変えると当たり率は0.7%から16.7%まで動いた（閾値と分母の両方を動かした最大幅で、16.7%は分母が回収された6,814設計の場合）。Claudeの毒素結合体は、公表の基準で17/211（8.1%）であり、基準を緩めると検査機関1つで18.5〜19.4%、どちらか一方で23.2%になった。Bits to Bindersのチーム別の当たり率0.6〜38.4%は一つの物差しではなく、1チームの寄与が大きく、低い側には回収が少ないチームと、濃縮より減少が多いチームが含まれる。Pythia-1は設計ごとの数が確認できず、当たり率を計算できなかった。3つの発表は、測定法・閾値・反復・対照・事前の選別・分母の6条件で異なる。

## 対象と確認範囲

表1に、扱った3つの発表と、公開されている情報を示す。

表1　扱った発表と入手できた情報。

| Report | Targets and scale | Information used here |
| --- | --- | --- |
| Bits to Binders (report by Kosonocky et al. ([3](#ref-3))) | One target (CD20), 12,000 designs (80 amino acids), 28 teams | Sequences, pooled-screen results and team information ([4](#ref-4)) |
| Anthropic (report on scorpion-toxin binders ([1](#ref-1))) | 5 toxins, 211 designs, 2 laboratories | Table of results for all 211 designs (CC BY 4.0) ([5](#ref-5)) |
| Pythia-1 (Pythia Labs report ([2](#ref-2))) | 22 targets (15 soluble, 7 GPCR) | Numbers in the main text; no per-design table was found in the portion read |

データの区別を述べる。「64時間」「42か国」「Claudeが選んだ180個に、Claudeの助けで後から加えた31個を足して211個」「プールで3反復」は、発表元の記事や論文の記載であり、公開データからの再計算ではない。「IL11は48個のうち5個」もPythia Labsの論文本文の記載である ([2](#ref-2))。ほかの当たり数と区間は、固定した版の公開データから `analysis.py` で計算した。

確認できた一次資料の範囲は次のとおりである。Anthropicの記事は全文、Bits to Bindersの論文はアブストラクト（要旨）の記載、Pythia Labsの論文v1は本文の該当部分（2.3節、2.5.1節、図1の凡例、5.16節）を、筆者が2026年10月30日に確認した。ただしAI査読では本文を取得できず、Pythia-1の本文の数値は第三者による確認を経ていない。Anthropicが挙げる報告書PDFと、Pythia Labsの論文のうち「可溶性の結合体31個の12個がKDで1桁〜2桁nM」の記述は確認していない。Bits to Bindersの論文の本文は、本記事の数値の照合に用いていない。

## 方法

**当たり率の区間：** 当たり数と試験数から、95%のウィルソン区間（二項割合の信頼区間の一種）を計算した。この区間は、設計ごとの結果が互いに独立だと仮定する。

**Bits to Binders：** 公開のプール選別（CAR-Tの増殖で濃縮された配列を数える方法）の結果から、「Up」（FDR（false discovery rate、偽発見割合の期待値）0.05未満、濃縮が2倍超）の数を再現した。707個で、発表と一致した。閾値と分母を変えて数え直した。「Down」（濃縮と逆向きの変化）の数も、反対方向の観測結果として集計した。チーム間の当たり率の差には、設計の独立を仮定したχ²検定を用いた。

**Claude：** 公開の表で、検査機関ごとの結果から、基準を変えて数え直した。KDは結合の強さを表す解離定数で、小さいほど結合が強い。測定は表面プラズモン共鳴（SPR）などの結合測定による。KDの閾値別の件数は、Adaptyv Bioで結合と判定され、かつ平均KD（算術平均）が閾値以下の設計を数えた。

**Pythia-1：** 論文に書かれた数値だけを用いた。設計ごとの結果は確認できていない。

**解析の位置づけ：** 解析の計画は、計算の前に固定したものではない。公開データの構造を見ながら範囲を決めた。閾値の感度分析、チーム別・手法別の内訳、最大のチームを除いた分析は、結果を見た後に加えた（事後・探索的）。`analysis-plan.md` に記録した。

## 結果

### Bits to Binders：同じ12,000個でも定義で当たり率は動く

図1に、28チームの結果を示す。

![Bits to Binders 28チームの当たり率、回収率、UpとDownの数](figures/01-team-hit-rates.png)

図1　Bits to Bindersのチーム別の結果。縦軸は各チーム。A：Upの数を提出数で割った当たり率（%、95%ウィルソン区間）。B：プール選別で検出された設計の割合（%）。C：UpとDownの設計数（対称対数軸）。点の色は、青がUpのほうが多いチーム、赤がDownのほうが多いか同数のチームを表す。運営の対照配列を含め、提出数は12,000個。

表2に、閾値と分母による当たり数と当たり率を示す。

表2　Bits to Binders：「当たり」の定義による当たり数と当たり率（FDR 0.05未満）。

| Definition | Hits | Denominator: all 12,000 | Denominator: 6,814 recovered |
| --- | ---: | ---: | ---: |
| Direction of enrichment only (no fold condition) | 1,137 | 9.5% | 16.7% |
| Enrichment above 2-fold (the report's definition) | 707 | 5.9% | 10.4% |
| Enrichment above 4-fold | 86 | 0.7% | 1.3% |

- **分母：** 12,000個のうち、プール選別で検出されたのは6,814個で、5,186個（43%）は回収されなかった。回収されなかった設計は、合成や発現の失敗かもしれず、設計の良し悪しを反映しているとは限らない。
- **閾値：** 濃縮の条件を2倍から4倍にすると、当たりは707個から86個になる。FDRを0.001未満にすると、473個（3.9%）になる。

**チームの差：**
- **全体：** 28チーム（運営の対照配列を除く11,984個、704個がUp）の当たり率は、0.6%（Perforators）から38.4%（Nucleate UK London）まで、中央値は3.8%だった。
- **ばらつき：** 設計の独立を仮定した粗い検定では、チームごとの当たり率は偶然のばらつきでは説明できなかった（χ² 1,054、自由度27）。最大のチームを除いても同じだった（χ² 288、自由度26）。二項分布の想定に対するばらつきは約39倍だった（`summary.json`）。チーム内の設計間の相関を無視しているため、p値の大きさは強い根拠として読まない。
- **集中：** Nucleate UK London（言語モデル）は、設計の3.5%（414個）で、Upの22.6%（159個）を出した。上位3チームで39.2%、上位5チームで51.4%である。

**低い側の中身：**
- **回収が少ない：** Perforators（回収9.3%）とEvaneil（回収10.5%）は、設計の9割が選別で検出されなかった。当たり率が低いのは、検出できた設計が少ないためで、設計の力とは言い切れない。
- **濃縮よりも減少が多い：** CAD Pro（Up 4、Down 50）、Team Anonymous（7、35）、Picaso Protein（15、29）、Bryant Lab（6、11）の4チームは、UpよりDownが多かった。この大小関係だけから、雑音を超えた濃縮の有無は判定できない。
- **UpとDownの数：** 全体では、Up 707個に対しDown 166個で、比は4.3対1。「Up−Down」で数えると541個（4.5%）になる。707個の5%は約35個だが、これは単純な掛け算であり、この実験の偽陽性数の期待値ではない。FDRは繰り返した解析での偽発見割合の期待値を対象とする ([6](#ref-6))。実現したUpの数に0.05を掛けても個別実験の偽陽性数は決まらない。Downには本当に減る設計も含まれるので、Down 166個も偽陽性数や雑音量の定量推定としては使えない。

**方法の違い：** 言語モデルを使ったチームの当たり率は10.7%（194/1,812）、拡散モデル系は5.4%（495/9,192）だった。ただし、言語モデル系からNucleateを除くと2.5%（35/1,398）になり、順位が逆になる。方法の差を、1チームの結果と分けて読むことはできない。チーム、計算資源、戦略が方法と交絡するため、方法が当たり率を変えたという因果の読みは支持されない。

### Claude：基準を変えると当たり率は8.1%から23.2%になる

図2の右は、Anthropicの公開の表を、基準を変えて数え直したものである。

![同じ実験で、「当たり」の定義を変えたときの当たり率](figures/02-definition-sensitivity.png)

図2　「当たり」の定義による当たり率（95%ウィルソン区間）。左：Bits to Binders（12,000個、1標的）。右：Claudeのサソリ毒素の試験（211個、5毒素）。横軸は当たり率（%）。

公表の基準は、データセットの説明によれば4条件である ([5](#ref-5))。(1)毒素に対し、両方の検査機関で全反復の結合、(2)主スクリーンのKDがすべて1 µM以下、(3)Twist Bioscienceの応答の最大値（Rmax）が理論値以内、(4)無関係なタンパク質CLEC12Aに信号がない。LqhIIIはAdaptyv Bioのみで測定されたため、そこでの結合と(2)(4)を求める。公表の17個は、公開の表で結合体と判定された列（`binder_against`）の件数であり、(3)のRmax条件を本記事が入力の表から独立に再現したものではない。以下で「公表の基準」と記すのは、この17個を指す。

表3に、基準を変えた当たり数と当たり率を示す。

表3　Claudeの毒素結合体211個：基準を変えた当たり数と当たり率。

| Criterion | Hits | Hit rate (95% interval) |
| --- | ---: | ---: |
| Published criteria (from the `binder_against` column; both laboratories, all replicates, KD 1 µM or tighter, Rmax condition, CLEC12A negative) | 17 | 8.1% (5.1–12.5%) |
| Binding at both laboratories (no other criteria) | 34 | 16.1% (11.8–21.7%) |
| Binding at one laboratory (Twist) | 39 | 18.5% (13.8–24.3%) |
| Binding at one laboratory (Adaptyv) | 41 | 19.4% (14.7–25.3%) |
| Binding at either laboratory | 49 | 23.2% (18.0–29.4%) |
| Either laboratory, including "weak or ambiguous" (reference) | 62 | 29.4% (23.7–35.9%) |

注：LqhIIIはAdaptyv Bioのみで測定されたため、「Twist」「Adaptyv」「両方」の分母はいずれも211個だが、LqhIIIの扱いが非対称である。「Twistで結合」の39件は検査機関の判定そのものではなく、Anthropicが事後に適用した固定の規則による判定である ([5](#ref-5))。「弱い・曖昧」の62件も同様の規則による。主な幅は8.1–23.2%で、29.4%は基準の拡張の参考値である。区間は設計の独立を仮定し、事前の選別と毒素・設計セットによる群構造に由来する不確かさを含まない。

- **KDの閾値：** Adaptyvの結果で、平均KDが10 nM以下は6個（2.8%）、100 nM以下は23個（10.9%）、1 µM以下は35個（16.6%）。
- **設計の種類：** 設計時に狙った毒素の数で分けると、1つの毒素向けの設計（60個）は11個（18.3%、10.6–29.9%）、2〜3種向けの設計（60個）は5個（8.3%）、5種すべて向けの設計（91個）は1個（1.1%）。複数の毒素向けに設計されたものも、基準を満たしたのは1つの毒素についてだけで、Anthropicの記述と一致する ([1](#ref-1))。
- **毒素ごと：** Cn2 7個、AaH II 4個、AaH I 4個、LqhIII 2個、Ts-1 0個。
- **2つの検査機関のKD：** 17個のうち、2つの機関のKDが得られた15個（LqhIIIの2個は1機関のみ）で、2つの機関の値の違いは中央値2.0倍、最大50.6倍だった。KDの閾値を厳しくするほど、検査機関による違いの影響が大きくなる。

**対照の意味：** 複数の毒素について両方の検査機関で結合判定が出た設計は4個あった。うち1個（AaHII-B4）は、Ts-1ではRmax条件で除かれ、AaH IIの結合体として17個に含まれる。ほかの3個は、無関係なタンパク質（CLEC12A）にも、Twistの2回の実行の両方で結合していた。「どれにでもくっつく」設計は、対照を置かなければ当たりに数えられる。公表の基準は、この種の設計を除く効果を持つ。

### Pythia-1：基準の違いと設計ごとの当たり率の欠如

論文本文の数値は次のとおりである ([2](#ref-2))。第三者による確認は経ていない。
- **標的と試験数：** 22標的（可溶性15、GPCR 7）。各標的で、選別した最大48個を試験した（CCR8は6個）。
- **成功した標的：** 可溶性は15標的のうち8標的で31個の結合体（うち12個がKDで1桁〜2桁nM、この12個は未確認）。GPCRは7標的すべてで18個。
- **標的ごとの例：** IL11は48個のうち5個。
- **基準：** 可溶性の一次の当たりは、BLI（bio-layer interferometry、バイオレイヤー干渉法）の応答が150秒で0.06 nm超。確認された結合体は、5濃度のBLIでKDが5 µM未満。GPCRは、フローサイトメトリーのzスコアが10超（確認はEC50が1 µM未満）。

Claudeの基準（KD 1 µM以下、2つの検査機関、全反復、対照）より緩い定義で、事前に絞った最大48個の中から数えている。設計ごとの当たり率は、標的ごとの試験数が分からないので、本記事では計算できない。標的単位の成功（15標的中8標的）は、設計単位の当たり率とは別の量である。

### 3つの発表で異なる6つの条件

表4に、3つの発表の条件を示す。

表4　3つの発表で異なる6つの条件。

| Condition | Bits to Binders | Claude | Pythia-1 |
| --- | --- | --- | --- |
| Assay | Enrichment under CAR-T proliferation (pooled) | SPR (2 laboratories, some BLI) | BLI, flow cytometry |
| Threshold | FDR below 0.05, enrichment above 2-fold | KD 1 µM or tighter | Response above 0.06 nm, KD below 5 µM |
| Replication | 3 replicates in the pool | Binding in all replicates | Five BLI concentrations (a concentration series, not replicates) |
| Controls or opposite-direction comparison | Down calls; not a calibrated negative control | CLEC12A, OVA | Not confirmed in the main text |
| Prior selection | Depends on the team | 180 chosen by Claude plus 31 added later with Claude's help | After narrowing to at most 48 |
| Denominator | Total submitted and recovered counted separately | 211 tested | At most 48 per target |

この表以外にも、標的の難しさ、結合体の長さと形式（80アミノ酸のCAR結合ドメイン、毒素への結合体、完全長の抗体）、サンプルの大きさが異なる。サンプルの大きさだけでも、当たり率約8%の95%区間は、12個で1.5–35%、60個で3.6–18%、211個で5.1–12.5%、466個で5.8–10.8%と、大きく違う（区間幅の例は、各nに0.08をかけた整数の当たり数による）。

## 考察

「当たり率」は、閾値・分母・反復・対照を書かなければ比べられない量である。同じ実験でも、定義により0.7–16.7%（Bits to Binders）、8.1–23.2%（Claude）の範囲に動いた。Bits to Bindersの幅は、閾値と分母の両方を変えた最大幅である。

Bits to Bindersの「0.6〜38.4%」は、設計力の幅とは読めない。低い側には、検出が少ないために低いチームと、UpがDownを上回らないチームが混ざり、高い側は1チームの寄与が大きい。方法の比較も1チームの結果に左右される。

Claudeの17個のうち15個は2つの検査機関の両方で、LqhIIIの2個はAdaptyv Bioのみで確認された結合である。公表の基準による該当数は、表3の他の基準より少ない。基準を緩めた集計は、基準の優劣ではなく、定義に対する感度を示す。

Pythia-1は、基準が他の2つより緩く、事前選別の後の数であり、設計単位の当たり率が出せない。3つを一つの尺度に並べることは、本記事のデータでは支持されない。本記事が示したのは、条件の異なる発表の当たり率が並べにくいことにとどまり、条件が書かれた発表が比べやすいかは検討していない。

## 限界

- **優劣：** 3つの発表は、標的も測定法も違うので、どれが優れているかは言えない。
- **Claudeの結果：** 公表の基準による17個のうち15個は2つの検査機関の両方で、LqhIIIの2個はAdaptyv Bioのみで確認された結合である。結合は中和ではなく、動物での効果の試験もない。Anthropicの記事が、結合の中和は確認していないと述べている ([1](#ref-1))。
- **Pythia-1：** 設計ごとの当たり率と、対照の扱いは、本記事では確認できていない。
- **Bits to Binders：** Downは本当に減る設計も含むので、雑音や偽陽性の数を定量的に推定できない。チーム間の検定は設計の独立を仮定し、同一チーム内の相関を無視する。
- **関係者と開示：** 本記事は、公開データの再集計である。筆者が使うAI（Claude）はAnthropic社のモデルで、比較対象の一つは、Anthropicが発表したClaudeの結果である。このため、Claudeの結果は、公開データと公表の基準だけで数え、評価や推測は加えていない。Pythia Labsの論文は、同社の従業員が実施した研究である ([2](#ref-2))。
- **区間の前提：** ウィルソン区間は、設計ごとの結果が独立だと仮定する。Claudeの211個は、事前に選別され、同じ標的・設計の群に分かれているので、実際の不確かさは、示した区間より広い可能性がある。
- **検証の範囲：** 再計算は同じ筆者（AI支援を含む）による別実装であり、第三者の確認ではない。Rでの再計算は件数、Up・Down、Claudeの17個と11個、ウィルソン区間（17/211）を対象とし、チーム別、χ²、方法別、感度分析は含まない。

## 結論

同じ実験の当たり率は、閾値と分母の定義だけで、Bits to Bindersでは0.7–16.7%、Claudeの毒素結合体では8.1–23.2%（参考として「弱い・曖昧」を含めると29.4%）に動いた。3つの発表は、測定法・閾値・反復・対照・事前の選別・分母の6条件で異なり、本記事のデータでは、3つを同じ尺度に並べる根拠は得られなかった。

2026-11-02訂正：FDRの定義と、Down数を雑音の定量推定に使えないことを明確にした。当たり数・当たり率・区間の計算値は変更していない。

## データとコードの公開状況

入力は次の公開データの固定した版である。Bits to Bindersの `data/12k_all_results.csv` と `data/individual/master_data_teams.csv`（GitHub、コミット 43eeeaf7e6ab629e796c9fe8d20b0ef70a3610d9）([4](#ref-4))、Anthropicの `design.csv`（Hugging Face、リビジョン 0bac3d0286f7f83b5339f5b4f1e67fbe47a6e7c1、CC BY 4.0）([5](#ref-5))。入力はSHA-256で固定し（`input-provenance.json`）、データそのものは配布資料へ同梱しない。Pythia-1は論文の数値を `results/pythia-reported.csv` に転記した。

解析コードは `acquire.py`、`analysis.py`、`figures.py`、`test_analysis.py`（単体の検査5件）、`validate.R`、出力は `results/` にある。再実行：`python acquire.py && python test_analysis.py && python analysis.py && python figures.py && Rscript validate.R`（Python 3.12、numpy、pandas、scipy、matplotlib、requests；R 4.5.3、jsonlite）。乱数は用いず、再実行すると結果ファイルがバイト単位で一致した。

再実行用の資料一式は[配布資料](bits-to-binders-hit-rates-companion.zip)に置いた。


## 参照

<span id="ref-1"></span>1. Anthropic. How Claude designed protein binders against scorpion neurotoxins [Internet]. Anthropic; 2026 Oct 20 [cited 2026 Oct 30]. Available from: https://anthropic.com/research/claude-scorpion-toxin-binder-design

<span id="ref-2"></span>2. Aglietti RA, Ansari R, Bowers PM, Buelles TH, Chauvin H, Duplay TM, et al. Design of full-length agonist and antagonist antibodies for hard targets [Preprint]. bioRxiv; 2026. Version 1, posted 2026 Oct 26; not peer reviewed. [doi:10.64898/2026.10.21.760573](https://doi.org/10.64898/2026.10.21.760573)

<span id="ref-3"></span>3. Kosonocky CW, Abel AM, Feller AL, Cifuentes Rieffer AE, Woolley PR, Lála J, et al. Validation and analysis of 12,000 AI-driven CAR-T designs in the Bits to Binders competition [Preprint]. bioRxiv; 2026. Version 1, posted 2026 Mar 3; not peer reviewed. [doi:10.64898/2026.03.03.709355](https://doi.org/10.64898/2026.03.03.709355)

<span id="ref-4"></span>4. Kosonocky CW, et al. bits-to-binders [Dataset and software]. GitHub; 2026. Commit 43eeeaf7e6ab629e796c9fe8d20b0ef70a3610d9 [cited 2026 Oct 30]. [https://github.com/kosonocky/bits-to-binders](https://github.com/kosonocky/bits-to-binders)

<span id="ref-5"></span>5. Anthropic. scorpion-toxin-binder-design [Dataset]. Hugging Face; 2026. Revision 0bac3d0286f7f83b5339f5b4f1e67fbe47a6e7c1. CC BY 4.0 [cited 2026 Oct 30]. [https://huggingface.co/datasets/Anthropic/scorpion-toxin-binder-design](https://huggingface.co/datasets/Anthropic/scorpion-toxin-binder-design)

<span id="ref-6"></span>6. Benjamini Y, Hochberg Y. Controlling the false discovery rate: a practical and powerful approach to multiple testing. Journal of the Royal Statistical Society: Series B (Methodological). 1995;57(1):289–300. [doi:10.1111/j.2517-6161.1995.tb02031.x](https://doi.org/10.1111/j.2517-6161.1995.tb02031.x).
