# AI設計タンパク質の当たり率：配布資料

記事「AI設計タンパク質の当たり率を比べる条件 Bits to Binders・Claude・Pythia-1の公開値の再集計」（日本語版 article.md、英語版 article.en.md）の再実行用資料。

## 含むもの
- `acquire.py`, `input-provenance.json`：公開データ（GitHubのBits to Binders、Hugging FaceのClaude毒素結合体データ）の固定した版のURLとSHA-256。データそのものは同梱しない
- `analysis.py`, `test_analysis.py`, `figures.py`, `validate.R`
- `results/`, `figures/`

## 実行
`python acquire.py && python test_analysis.py && python analysis.py && python figures.py && Rscript validate.R`（Python 3.12、numpy、pandas、scipy、matplotlib、requests；R 4.5.3、jsonlite）

Pythia-1は公表値のみで、設計ごとの当たり率は計算できていない。
