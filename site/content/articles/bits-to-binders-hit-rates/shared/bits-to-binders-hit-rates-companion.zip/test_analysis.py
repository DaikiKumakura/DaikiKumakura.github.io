"""Checks of the hit-rate calculations."""
import numpy as np

import analysis as A


def test_wilson_matches_known_value():
    lo, hi = A.wilson(17, 211)
    assert abs(lo - 0.0509) < 5e-4 and abs(hi - 0.1252) < 5e-4


def test_wilson_edges():
    lo, hi = A.wilson(0, 50)
    assert lo == 0 and 0.05 < hi < 0.09
    assert np.isnan(A.wilson(0, 0)[0])


def test_published_counts_reproduce():
    over, sens, teams, meth, conc = A.b2b()
    assert int(over.hits[0]) == 707 and int(over.n[0]) == 12000 and int(over.n[1]) == 6814
    assert conc["net_up_minus_down"] == 541
    assert teams[teams.team != "Leah_labs"].shape[0] == 28


def test_claude_published_count():
    crit, grp, by_tox, kd, info = A.claude()
    assert int(crit.hits[0]) == 17
    assert int(grp.hits[0]) == 11 and int(grp.n[0]) == 60
    assert by_tox.binders.sum() == 17


def test_looser_definition_never_lowers_the_count():
    crit, *_ = A.claude()
    h = dict(zip(crit.label, crit.hits))
    assert h["hit at either lab"] >= h["hit at Adaptyv Bio on any toxin"] >= h["hit at both labs on the same toxin (LqhIII: Adaptyv only)"]


if __name__ == "__main__":
    for name, fn in list(globals().items()):
        if name.startswith("test_"):
            fn()
    print("all tests passed")
