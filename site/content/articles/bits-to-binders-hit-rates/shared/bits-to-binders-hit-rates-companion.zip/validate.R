# Independent re-implementation (base R) of the main counts and intervals.
# Run from this folder: Rscript validate.R
r <- read.csv("inputs/repo/data/12k_all_results.csv", stringsAsFactors = FALSE)
d <- subset(r, leah_12k_detected %in% c(TRUE, "True"))
up <- sum(d$leah_12k_FDR < 0.05 & d$leah_12k_logFC > 1)
down <- sum(d$leah_12k_FDR < 0.05 & d$leah_12k_logFC < -1)
wilson <- function(k, n) { z <- qnorm(0.975); p <- k / n; dd <- 1 + z^2 / n
  c((p + z^2 / (2 * n) - z * sqrt(p * (1 - p) / n + z^2 / (4 * n^2))) / dd, (p + z^2 / (2 * n) + z * sqrt(p * (1 - p) / n + z^2 / (4 * n^2))) / dd) }
cl <- read.csv("inputs/claude-hf/design.csv", stringsAsFactors = FALSE, colClasses = c(uuid = "character"))
strict <- sum(!is.na(cl$binder_against) & cl$binder_against != "")
single <- sum(!is.na(cl$binder_against) & cl$binder_against != "" & cl$design_set <= 5)
mine <- c(n = nrow(r), recovered = nrow(d), up = up, down = down, strict = strict, single = single,
          up_rate_all = up / nrow(r), strict_lo = wilson(strict, nrow(cl))[1], strict_hi = wilson(strict, nrow(cl))[2])
ref <- read.csv("results/b2b-overall.csv"); cr <- read.csv("results/claude-criteria.csv")
theirs <- c(n = ref$n[1], recovered = ref$n[2], up = ref$hits[1], down = 166, strict = cr$hits[1], single = 11,
            up_rate_all = ref$rate[1], strict_lo = cr$lo[1], strict_hi = cr$hi[1])
diff <- abs(mine - theirs)
print(rbind(R = mine, Python = theirs))
ok <- all(diff[c("n", "recovered", "up", "down", "strict", "single")] == 0) && all(diff[-(1:6)] < 1e-4)
jsonlite::write_json(list(status = if (ok) "pass" else "fail", method = "base R recount and Wilson intervals", max_abs_diff = max(diff)),
                     "results/validation.json", auto_unbox = TRUE, pretty = TRUE)
cat("validation:", if (ok) "pass" else "fail", "\n")
