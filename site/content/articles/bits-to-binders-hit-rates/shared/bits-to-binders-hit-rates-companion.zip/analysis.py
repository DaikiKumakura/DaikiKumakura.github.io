"""How much does a protein-design "hit rate" depend on its definition? Bits to Binders (12,000 CD20 binders) and
Anthropic's scorpion-toxin binder campaign (211 designs), plus the numbers reported for Pythia-1.

Inputs (public, pinned in input-provenance.json):
  inputs/repo/data/12k_all_results.csv, data/individual/master_data_teams.csv   (kosonocky/bits-to-binders)
  inputs/claude-hf/design.csv                                                    (Hugging Face Anthropic/scorpion-toxin-binder-design, CC BY 4.0)
"""
from pathlib import Path
import json

import numpy as np
import pandas as pd
from scipy import stats

ROOT = Path(__file__).resolve().parent
OUT = ROOT / "results"
OUT.mkdir(exist_ok=True)
Z = 1.959964


def wilson(k, n):
    if n == 0:
        return (np.nan, np.nan)
    p = k / n
    d = 1 + Z * Z / n
    c = (p + Z * Z / (2 * n)) / d
    h = Z * np.sqrt(p * (1 - p) / n + Z * Z / (4 * n * n)) / d
    return (c - h, c + h)


def row(label, k, n, **kw):
    lo, hi = wilson(k, n)
    return dict(label=label, hits=int(k), n=int(n), rate=k / n if n else np.nan, lo=lo, hi=hi, **kw)


def b2b():
    r = pd.read_csv(ROOT / "inputs/repo/data/12k_all_results.csv")
    t = pd.read_csv(ROOT / "inputs/repo/data/individual/master_data_teams.csv")
    assert len(r) == 12000 and r.global_id.is_unique
    n, det = len(r), int(r.leah_12k_detected.sum())
    up, down = int((r.fourclass == "Up").sum()), int((r.fourclass == "Down").sum())
    # the published call is FDR < 0.05 and log2 fold change > 1 (checked against the data)
    chk = r[r.fourclass == "Up"]
    assert chk.leah_12k_logFC.min() > 1 and chk.leah_12k_FDR.max() < 0.05
    d = r[r.leah_12k_detected]
    called = (d.leah_12k_FDR < 0.05) & (d.leah_12k_logFC > 1)
    assert int(called.sum()) == up

    over = [row("all submitted designs (published call)", up, n),
            row("designs recovered in the pooled screen", up, det)]
    sens = []
    for fdr, lfc in [(0.05, 0.0), (0.05, 1.0), (0.01, 1.0), (0.05, 2.0), (0.001, 1.0)]:
        k = int(((d.leah_12k_FDR < fdr) & (d.leah_12k_logFC > lfc)).sum())
        sens.append(row(f"FDR<{fdr}, log2FC>{lfc}, denominator = all 12,000", k, n, fdr=fdr, lfc=lfc, denominator="all"))
        sens.append(row(f"FDR<{fdr}, log2FC>{lfc}, denominator = recovered", k, det, fdr=fdr, lfc=lfc, denominator="recovered"))
    sens = pd.DataFrame(sens)

    # up vs down: under a symmetric null the number of 'Down' calls estimates how many 'Up' calls are noise
    sig_down = int(((d.leah_12k_FDR < 0.05) & (d.leah_12k_logFC < -1)).sum())
    assert sig_down == down

    teams = []
    for team, g in r.groupby("team"):
        n_t = len(g)
        det_t = int(g.leah_12k_detected.sum())
        u, dn = int((g.fourclass == "Up").sum()), int((g.fourclass == "Down").sum())
        teams.append(dict(team=team, n=n_t, recovered=det_t, recovery_rate=det_t / n_t, up=u, down=dn,
                          rate_all=u / n_t, rate_all_lo=wilson(u, n_t)[0], rate_all_hi=wilson(u, n_t)[1],
                          rate_recovered=u / det_t if det_t else np.nan, up_per_down=u / dn if dn else np.inf,
                          net_up_minus_down=u - dn, net_rate=(u - dn) / n_t, signal_above_noise=bool(u > dn)))
    teams = pd.DataFrame(teams).merge(t[["team", "primary_method_type"]], on="team", how="left").sort_values("rate_all", ascending=False)
    comp = teams[teams.team != "Leah_labs"]            # organiser control sequences excluded
    p0 = comp.up.sum() / comp.n.sum()
    chi2 = float((((comp.up - comp.n * p0) ** 2) / (comp.n * p0 * (1 - p0))).sum())
    df = len(comp) - 1
    share = comp.sort_values("up", ascending=False)
    conc = dict(teams=int(len(comp)), designs=int(comp.n.sum()), hits=int(comp.up.sum()), pooled_rate=p0,
                chi2_homogeneity=chi2, df=df, p_homogeneity=float(stats.chi2.sf(chi2, df)),
                dispersion=chi2 / df,
                top1_share_hits=float(share.up.iloc[0] / comp.up.sum()), top1_share_designs=float(share.n.iloc[0] / comp.n.sum()),
                top3_share_hits=float(share.up.iloc[:3].sum() / comp.up.sum()), top5_share_hits=float(share.up.iloc[:5].sum() / comp.up.sum()),
                top_team=share.team.iloc[0],
                median_team_rate=float(comp.rate_all.median()), min_team_rate=float(comp.rate_all.min()), max_team_rate=float(comp.rate_all.max()),
                spearman_recovery_vs_rate=float(stats.spearmanr(comp.recovery_rate, comp.rate_all).statistic),
                spearman_recovery_vs_rate_p=float(stats.spearmanr(comp.recovery_rate, comp.rate_all).pvalue),
                up_per_down_overall=up / down, net_up_minus_down=up - down, net_rate_all=(up - down) / n,
                teams_with_more_down_than_up=int((comp.down > comp.up).sum()),
                teams_below_5pct_recovery_or_no_net_signal=int(((comp.recovery_rate < 0.15) | (comp.up <= comp.down)).sum()))
    # same, without the largest team
    rest = comp[comp.team != conc["top_team"]]
    p1 = rest.up.sum() / rest.n.sum()
    chi1 = float((((rest.up - rest.n * p1) ** 2) / (rest.n * p1 * (1 - p1))).sum())
    conc.update(chi2_without_top=chi1, df_without_top=len(rest) - 1, p_without_top=float(stats.chi2.sf(chi1, len(rest) - 1)),
                pooled_rate_without_top=p1)

    def group(m):
        m = str(m)
        if m.startswith("LM"):
            return "language model"
        if "BindCraft" in m and "Diffusion" not in m:
            return "BindCraft"
        if m.startswith("Diffusion"):
            return "diffusion-based"
        return "other"
    comp = comp.assign(method_group=comp.primary_method_type.map(group))
    meth = (comp.groupby("method_group").agg(teams=("team", "size"), n=("n", "sum"), up=("up", "sum")).reset_index())
    meth["rate"] = meth.up / meth.n
    meth["lo"] = [wilson(u, n_)[0] for u, n_ in zip(meth.up, meth.n)]
    meth["hi"] = [wilson(u, n_)[1] for u, n_ in zip(meth.up, meth.n)]
    rest_m = comp[comp.team != conc["top_team"]].groupby("method_group").agg(teams=("team", "size"), n=("n", "sum"), up=("up", "sum")).reset_index()
    rest_m["rate"] = rest_m.up / rest_m.n
    rest_m["lo"] = [wilson(u, n_)[0] for u, n_ in zip(rest_m.up, rest_m.n)]
    rest_m["hi"] = [wilson(u, n_)[1] for u, n_ in zip(rest_m.up, rest_m.n)]
    rest_m.round(5).to_csv(OUT / "b2b-methods-excluding-top-team.csv", index=False, lineterminator="\n")
    return pd.DataFrame(over), sens, teams, meth, conc


def claude():
    d = pd.read_csv(ROOT / "inputs/claude-hf/design.csv", dtype={"uuid": str})
    assert len(d) == 211 and d.uuid.is_unique
    tox = [c[:-len("_Adaptyv_result")] for c in d.columns if c.endswith("_Adaptyv_result")]  # toxin names as they appear in the dataset columns
    assert len(tox) == 5, tox
    ad = pd.DataFrame({t: d[f"{t}_Adaptyv_result"].eq("hit") for t in tox})
    tw = pd.DataFrame({t: d[f"{t}_Twist_result"].eq("hit") for t in tox if f"{t}_Twist_result" in d})
    tw_weak = pd.DataFrame({t: d[f"{t}_Twist_result"].isin(["hit", "weak or ambiguous"]) for t in tox if f"{t}_Twist_result" in d})
    kd = pd.DataFrame({t: pd.to_numeric(d[f"{t}_Adaptyv_KD_nM"], errors="coerce") for t in tox})
    strict = d.binder_against.notna()
    n = len(d)
    rows = [row("published criteria (both labs, all replicates, KD <= 1 uM, CLEC12A negative)", strict.sum(), n)]
    rows.append(row("hit at Adaptyv Bio on any toxin", ad.any(axis=1).sum(), n))
    rows.append(row("hit at Twist Bioscience on any toxin", tw.any(axis=1).sum(), n))
    both = pd.DataFrame({t: ad[t] & tw[t] if t in tw else ad[t] for t in tox}).any(axis=1)
    rows.append(row("hit at both labs on the same toxin (LqhIII: Adaptyv only)", both.sum(), n))
    either = ad.any(axis=1) | tw.any(axis=1)
    rows.append(row("hit at either lab", either.sum(), n))
    rows.append(row("either lab, Twist 'weak or ambiguous' counted", (ad.any(axis=1) | tw_weak.any(axis=1)).sum(), n))
    for thr in (10, 100, 1000, 10000):
        k = (ad & (kd <= thr)).any(axis=1).sum()
        rows.append(row(f"Adaptyv hit with mean KD <= {thr} nM", k, n))
    crit = pd.DataFrame(rows)
    # single-toxin vs multi-toxin designs
    single = d.design_set.between(1, 5)
    two_three = d.design_set.isin([6, 7])
    allfive = d.design_set.isin([8, 9, 10])
    grp = pd.DataFrame([row("single-toxin designs (sets 1-5)", strict[single].sum(), single.sum()),
                        row("two- or three-toxin designs (sets 6-7)", strict[two_three].sum(), two_three.sum()),
                        row("all-five designs (sets 8-10)", strict[allfive].sum(), allfive.sum())])
    by_tox = d[strict].binder_against.value_counts().rename_axis("toxin").reset_index(name="binders")
    multi = int((d[strict & ~single].binder_against.notna()).sum())
    # does any binder bind more than one toxin at both labs?
    both_lab = ad & tw.reindex(columns=tox, fill_value=False)
    multi_toxin = int((both_lab.sum(axis=1) > 1).sum())
    multi_rows = d[both_lab.sum(axis=1) > 1][["name", "design_set", "binder_against", "CLEC12A_Twist_result_run_1", "CLEC12A_Twist_result_run_2"]]
    multi_rows.to_csv(OUT / "claude-multi-toxin-both-labs.csv", index=False, lineterminator="\n")
    print(multi_rows.to_string())
    # per-lab calls among the 17 strict binders: do the labs agree on KD?
    both_kd = []
    for t in ["Cn2", "AaHII", "AaHI"]:
        sub = d[d.binder_against.eq(t.replace("AaHII", "AaH II").replace("AaHI", "AaH I"))]
        for _, r_ in sub.iterrows():
            both_kd.append(dict(toxin=t, name=r_["name"], adaptyv_kd_nM=r_[f"{t}_Adaptyv_KD_nM"], twist_kd_nM=r_[f"{t}_Twist_KD_nM"]))
    kd_tab = pd.DataFrame(both_kd)
    kd_tab["kd_ratio_adaptyv_over_twist"] = kd_tab.adaptyv_kd_nM / kd_tab.twist_kd_nM
    ratio = np.maximum(kd_tab.kd_ratio_adaptyv_over_twist, 1 / kd_tab.kd_ratio_adaptyv_over_twist)
    return crit, grp, by_tox, kd_tab, dict(designs=n, strict=int(strict.sum()), multi_toxin_designs_binding_more_than_one=multi_toxin,
                                           kd_fold_difference_min=float(ratio.min()), kd_fold_difference_median=float(ratio.median()),
                                           kd_fold_difference_max=float(ratio.max()), kd_pairs=int(len(kd_tab)))


def main():
    over, sens, teams, meth, conc = b2b()
    crit, grp, by_tox, kd_tab, cinfo = claude()
    over.round(5).to_csv(OUT / "b2b-overall.csv", index=False, lineterminator="\n")
    sens.round(5).to_csv(OUT / "b2b-threshold-sensitivity.csv", index=False, lineterminator="\n")
    teams.round(5).to_csv(OUT / "b2b-teams.csv", index=False, lineterminator="\n")
    meth.round(5).to_csv(OUT / "b2b-methods.csv", index=False, lineterminator="\n")
    crit.round(5).to_csv(OUT / "claude-criteria.csv", index=False, lineterminator="\n")
    grp.round(5).to_csv(OUT / "claude-by-design-set.csv", index=False, lineterminator="\n")
    by_tox.to_csv(OUT / "claude-by-toxin.csv", index=False, lineterminator="\n")
    kd_tab.to_csv(OUT / "claude-binder-kd.csv", index=False, lineterminator="\n")
    # numbers reported for Pythia-1 (bioRxiv 10.64898/2026.10.21.760573); no per-design table is public in the text read
    py = pd.DataFrame([
        dict(item="targets", value=22, note="15 soluble/ectodomain, 7 GPCR"),
        dict(item="designs tested per target", value="at most 48", note="after filtering; CCR8: 6 tested"),
        dict(item="soluble targets with a hit", value="8 of 15", note="31 hits; 12 of 31 with single- to double-digit nM KD"),
        dict(item="GPCR targets with a hit", value="7 of 7", note="18 hits"),
        dict(item="soluble hit definition", value="BLI response > 0.06 nm at 150 s (primary); KD < 5 uM (confirmed)", note=""),
        dict(item="GPCR hit definition", value="flow cytometry z > 10 (primary); EC50 < 1 uM (confirmed)", note="")])
    py.to_csv(OUT / "pythia-reported.csv", index=False, lineterminator="\n")
    # width of a 95% Wilson interval at several sample sizes, rate 8%
    width = pd.DataFrame([dict(n=n_, rate=0.08, lo=wilson(round(0.08 * n_), n_)[0], hi=wilson(round(0.08 * n_), n_)[1]) for n_ in (12, 60, 211, 466, 12000)])
    width.round(5).to_csv(OUT / "interval-width.csv", index=False, lineterminator="\n")
    summary = dict(conc=conc, claude=cinfo)
    (OUT / "summary.json").write_text(json.dumps(summary, indent=2, default=float) + "\n", encoding="utf-8")
    pd.set_option("display.width", 220)
    print(over.round(4).to_string())
    print(sens.round(4).to_string())
    print(teams[["team", "n", "recovery_rate", "up", "down", "rate_all", "rate_recovered", "primary_method_type"]].round(3).to_string())
    print(meth.round(4).to_string())
    print(json.dumps(conc, indent=1, default=float))
    print(crit.round(4).to_string())
    print(grp.round(4).to_string())
    print(by_tox.to_string())
    print(kd_tab.to_string())
    print(cinfo)


if __name__ == "__main__":
    main()
