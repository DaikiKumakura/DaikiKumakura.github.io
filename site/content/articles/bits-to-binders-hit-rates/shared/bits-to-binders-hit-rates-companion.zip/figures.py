"""Figures from results/ (run analysis.py first)."""
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parent
R = ROOT / "results"
(ROOT / "figures").mkdir(exist_ok=True)
BLUE, ORANGE, GREY, GREEN, RED = "#0072B2", "#E69F00", "#999999", "#009E73", "#D55E00"

# Figure 1: team hit rates, recovery and up/down counts
t = pd.read_csv(R / "b2b-teams.csv")
t = t[t.team != "Leah_labs"].sort_values("rate_all")
y = np.arange(len(t))
fig, ax = plt.subplots(1, 3, figsize=(11, 8), sharey=True, constrained_layout=True, gridspec_kw=dict(width_ratios=[1.3, 1, 1.2]))
col = [BLUE if s else RED for s in t.up_exceeds_down]
ax[0].errorbar(t.rate_all * 100, y, xerr=[(t.rate_all - t.rate_all_lo) * 100, (t.rate_all_hi - t.rate_all) * 100], fmt="none", ecolor=GREY, capsize=2)
ax[0].scatter(t.rate_all * 100, y, c=col, zorder=3, s=28)
ax[0].set_yticks(y, [f"{n} (n={k})" for n, k in zip(t.team, t.n)], fontsize=7.5)
ax[0].set_xlabel("Up / submitted (%), 95% CI")
ax[0].set_title("A. Published-style hit rate", fontsize=9)
ax[1].barh(y, t.recovery_rate * 100, color=ORANGE)
ax[1].set_xlabel("Designs recovered in the screen (%)")
ax[1].set_xlim(0, 100)
ax[1].set_title("B. Recovery", fontsize=9)
ax[2].barh(y - 0.2, t.up, height=0.4, color=BLUE, label="Up (enriched)")
ax[2].barh(y + 0.2, t.down, height=0.4, color=RED, label="Down (depleted)")
ax[2].set_xscale("symlog", linthresh=5)
ax[2].set_xlabel("Number of designs (symlog)")
ax[2].set_title("C. Up vs Down calls", fontsize=9)
ax[2].legend(fontsize=7.5, loc="lower right")
fig.suptitle("Bits to Binders: 28 teams, same assay (blue dot: more Up than Down; red: Down >= Up)", fontsize=10)
fig.savefig(ROOT / "figures/01-team-hit-rates.png", dpi=150)

# Figure 2: the same campaigns under different definitions
s = pd.read_csv(R / "b2b-threshold-sensitivity.csv")
c = pd.read_csv(R / "claude-criteria.csv")
fig, axes = plt.subplots(1, 2, figsize=(12, 4.6), constrained_layout=True, sharex=True)
sub = s[s.lfc.isin([0.0, 1.0, 2.0]) & s.fdr.isin([0.05])].copy()
sub["lab"] = [f"FDR<0.05, log2FC>{int(l)}\n{'all 12,000' if d == 'all' else 'recovered only'}" for l, d in zip(sub.lfc, sub.denominator)]
axes[0].barh(range(len(sub)), sub.rate * 100, color=[BLUE if d == "all" else GREEN for d in sub.denominator],
             xerr=[(sub.rate - sub.lo) * 100, (sub.hi - sub.rate) * 100], ecolor="k", capsize=2)
axes[0].set_yticks(range(len(sub)), sub.lab, fontsize=8)
axes[0].invert_yaxis()
axes[0].set_title("Bits to Binders (12,000 designs, one target)", fontsize=9.5)
axes[0].set_xlabel("Hit rate (%)")
lab = {"published criteria (both labs, all replicates, KD <= 1 uM, CLEC12A negative)": "Published: both labs, all replicates,\nKD<=1 uM, off-target control negative",
       "hit at both labs on the same toxin (LqhIII: Adaptyv only)": "Hit at both labs (no other criteria)",
       "hit at Adaptyv Bio on any toxin": "Hit at Adaptyv Bio only",
       "hit at Twist Bioscience on any toxin": "Hit at Twist Bioscience only",
       "hit at either lab": "Hit at either lab",
       "either lab, Twist 'weak or ambiguous' counted": "Either lab, 'weak/ambiguous' counted"}
cc = c[c.label.isin(lab)].copy()
cc["lab"] = cc.label.map(lab)
axes[1].barh(range(len(cc)), cc.rate * 100, color=[RED if "Published" in l else ORANGE for l in cc.lab],
             xerr=[(cc.rate - cc.lo) * 100, (cc.hi - cc.rate) * 100], ecolor="k", capsize=2)
axes[1].set_yticks(range(len(cc)), cc.lab, fontsize=8)
axes[1].invert_yaxis()
axes[1].set_title("Claude scorpion-toxin campaign (211 designs, 5 toxins)", fontsize=9.5)
axes[1].set_xlabel("Hit rate (%)")
fig.suptitle("Same experiment, different definition of a hit (95% Wilson intervals)", fontsize=10.5)
fig.savefig(ROOT / "figures/02-definition-sensitivity.png", dpi=150)
print("figures written")
