"""Independent aggregation of released scores, not Boltz-2 inference or training."""
from pathlib import Path
import hashlib
import json
import numpy as np
import pandas as pd
from sklearn.metrics import average_precision_score
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from acquire import TARGETS, COMMIT

ROOT = Path(__file__).resolve().parent


def verify_inputs():
    provenance=json.loads((ROOT/'input-provenance.json').read_text(encoding='utf-8'))
    if provenance['commit'] != COMMIT:
        raise ValueError('Input commit mismatch')
    for entry in provenance['files']:
        path=ROOT/'inputs'/entry['path']
        if hashlib.sha256(path.read_bytes()).hexdigest()!=entry['sha256']:
            raise ValueError(f"Input checksum mismatch: {entry['path']}")


def rank(scores, order=None):
    scores = np.asarray(scores, dtype=float)
    if not np.isfinite(scores).all():
        raise ValueError('Nonfinite scores')
    if order is None:
        order = np.arange(len(scores))
    return np.lexsort((np.asarray(order), -scores))


def top_hits(labels, scores, k, order=None):
    if not 0 < k <= len(labels):
        raise ValueError('Invalid selection size')
    return int(np.asarray(labels)[rank(scores, order)[:k]].sum())


def cascade(labels, initial, adjusted, m, k, order=None):
    if not k <= m <= len(labels):
        raise ValueError('Invalid rescoring budget')
    labels = np.asarray(labels)
    if order is None:
        order = np.arange(len(labels))
    survivors = rank(initial, order)[:m]
    selected = survivors[rank(np.asarray(adjusted)[survivors], np.asarray(order)[survivors])[:k]]
    return int(labels[selected].sum()), int(labels[survivors].sum())


def summarize(metrics, budgets):
    output = []
    for n in (40, 100, 300):
        subset = metrics[metrics.label_budget.eq(n)]
        grouped = subset.groupby('method')
        base = grouped.get_group('No-FT').set_index('target')
        ft = grouped.get_group('Head-FT').set_index('target')
        output.append(dict(label_budget=n, targets=len(base),
            ap_noft=float(base.ap.mean()), ap_headft=float(ft.ap.mean()),
            ap_geomean_ratio=float(np.exp(np.log(ft.ap / base.ap).mean())),
            ef_geomean_ratio=float(np.exp(np.log(ft.ef1 / base.ef1).mean())),
            hits100_noft=float(base.hits100.mean()), hits100_headft=float(ft.hits100.mean()),
            hits100_cascade5000=float(budgets[(budgets.label_budget.eq(n)) & budgets.m.eq(5000)].hits100.mean())))
    return pd.DataFrame(output)


def main():
    verify_inputs()
    results, figures = ROOT / 'results', ROOT / 'figures'
    results.mkdir(exist_ok=True)
    figures.mkdir(exist_ok=True)
    control = pd.read_csv(ROOT/'inputs/figures/data/trainer_control.csv', dtype={'target': str})
    ref_cascade = pd.read_csv(ROOT/'inputs/figures/data/cascade.csv', dtype={'target': str})
    manifest = json.loads((ROOT/'inputs/data/predictions/manifest.json').read_text())
    rows, budget_rows, populations, checks = [], [], [], []
    for target in TARGETS:
        df = pd.read_csv(ROOT/f'inputs/data/predictions/{target}.csv.gz', float_precision='round_trip')
        info = manifest['targets'][target]
        assert len(df) == info['n_rows']
        assert df.complex_id.is_unique and df.is_binder.isin([0, 1]).all()
        assert np.array_equal(~df.train_300, df.is_eval)
        ev = df[df.is_eval].sort_values('eval_order')
        assert np.array_equal(ev.eval_order, np.arange(len(ev)))
        y, initial = ev.is_binder.to_numpy(int), ev.no_ft.to_numpy(float)
        assert len(ev) == info['n_eval'] and int(y.sum()) == info['n_active_eval']
        populations.append(dict(target=target, n_eval=len(ev), actives=int(y.sum()),
            active_rate=float(y.mean()), **{f'training_actives_{n}':int(df.loc[df[f'train_{n}'], 'is_binder'].sum()) for n in (40,100,300)}))
        for n in (40,100,300):
            assert int(df[f'train_{n}'].sum()) == n
            assert not (df[f'train_{n}'] & df.is_eval).any()
            adjusted = ev[f'headft_N{n}'].to_numpy(float)
            for method, scores in [('No-FT', initial), ('Head-FT', adjusted)]:
                ap = float(average_precision_score(y, scores))
                # Match the archived NumPy protocol for EF; top-k uses explicit tie order.
                h = int(y[np.argsort(-scores)[:max(1,round(.01*len(y)))]].sum())
                ef = h/max(1,round(.01*len(y)))/y.mean()
                ref = control[(control.target.eq(target)) & control.arm.eq('base' if method=='No-FT' else 'lightning') & control.n_train.eq(0 if method=='No-FT' else n)].iloc[0]
                assert np.isclose(ap, ref.auprc, rtol=1e-10, atol=1e-12)
                assert np.isclose(ef, ref.ef_1pct, rtol=1e-10, atol=1e-12)
                rows.append(dict(target=target,label_budget=n,method=method,ap=ap,ef1=float(ef),
                    hits100=top_hits(y,scores,100),hits500=top_hits(y,scores,500)))
                checks.append(dict(target=target,budget=n,method=method,ap_matches=True,ef_matches=True))
            for m in (500,1000,2500,5000,10000,25000,len(y)):
                hits, ceiling = cascade(y,initial,adjusted,m,100)
                ref = ref_cascade[ref_cascade.target.eq(target) & ref_cascade.n_train.eq(n) & ref_cascade.budget_k.eq(100) & ref_cascade.cut_M.eq(m)].iloc[0]
                assert hits == ref.hits and ceiling == ref.ceiling
                budget_rows.append(dict(target=target,label_budget=n,m=m,is_full=m==len(y),hits100=hits,
                    retained_actives=ceiling,retained_active_fraction=ceiling/int(y.sum()),
                    oracle_hit_ceiling100=min(100,ceiling)))
    metrics, budgets = pd.DataFrame(rows), pd.DataFrame(budget_rows)
    summary = summarize(metrics,budgets)
    metrics.to_csv(results/'target-metrics.csv',index=False)
    budgets.to_csv(results/'cascade.csv',index=False)
    pd.DataFrame(populations).to_csv(results/'populations.csv',index=False)
    summary.to_csv(results/'summary.csv',index=False)
    # Aggregate author-supplied scaffold annotations; no independent RDKit analysis.
    scaffold = pd.read_csv(ROOT/'inputs/figures/data/si_analyses/hit_scaffold_recovery.csv',dtype={'target':str})
    scaffold = scaffold[scaffold.N.eq(300) & scaffold.k.eq(100)]
    scaffold.groupby('model')[['hits','unseen_hits','unique_unseen_scaffolds']].mean().to_csv(results/'author-scaffold-summary.csv')
    (results/'verification.json').write_text(json.dumps({'source_commit':COMMIT,
        'kind':'released-score reaggregation; no inference or training',
        'metric_checks':len(checks)*2,'cascade_checks':len(budget_rows)*2,
        'numpy':np.__version__, 'checks':checks},indent=2)+'\n',encoding='utf-8')
    plt.rcParams.update({'font.size':10,'axes.spines.top':False,'axes.spines.right':False})
    fig,ax=plt.subplots(figsize=(7.5,4.2))
    for i,n in enumerate((40,100,300)):
        base=metrics[(metrics.label_budget.eq(n)) & metrics.method.eq('No-FT')].set_index('target')
        ft=metrics[(metrics.label_budget.eq(n)) & metrics.method.eq('Head-FT')].set_index('target')
        ratio=ft.ap/base.ap
        ax.scatter(np.full(len(ratio),i),ratio,color='#335f8a',alpha=.65,s=28)
        ax.scatter(i,np.exp(np.log(ratio).mean()),marker='D',s=75,color='#b44929',zorder=4)
    ax.axhline(1,color='.5',linestyle='--')
    ax.set(xticks=[0,1,2],xticklabels=['40','100','300'],xlabel='Training labels per target',
        ylabel='AP ratio: Head-FT / No-FT',title='Eight targets: released-score reaggregation')
    ax.plot([],[],'.',color='#335f8a',label='Individual target')
    ax.plot([],[],'D',color='#b44929',label='Geometric mean')
    ax.legend(frameon=False)
    fig.tight_layout();fig.savefig(figures/'01-label-budget.png',dpi=180);plt.close(fig)
    fig,ax=plt.subplots(figsize=(7.5,4.2))
    subset=budgets[budgets.label_budget.eq(300)]
    for target in TARGETS:
        x=subset[subset.target.eq(target)]
        ax.plot(x.m,x.hits100,color='#335f8a',alpha=.25,lw=1)
    common=subset[~subset.is_full].groupby('m').hits100.mean()
    full=subset[subset.is_full]
    ax.plot(common.index,common.values,'o-',color='#b44929',label='Mean across targets')
    ax.scatter(full.m.mean(),full.hits100.mean(),color='#b44929')
    ax.axhline(summary.iloc[2].hits100_noft,color='.4',linestyle='--',label='No-FT mean')
    ax.axhline(full.hits100.mean(),color='#b44929',linestyle=':',label='Full Head-FT mean')
    ax.set(xscale='log',xlabel='Compounds rescored (M)',ylabel='Actives among next 100',
        title='300 training labels; initial inference cost excluded')
    ax.legend(frameon=False);fig.tight_layout();fig.savefig(figures/'02-rescoring-budget.png',dpi=180);plt.close(fig)
    print(summary.to_string(index=False))
    print('Scaffold annotations: author-supplied, aggregated only')
    print((results/'author-scaffold-summary.csv').read_text())


if __name__ == '__main__':
    main()
