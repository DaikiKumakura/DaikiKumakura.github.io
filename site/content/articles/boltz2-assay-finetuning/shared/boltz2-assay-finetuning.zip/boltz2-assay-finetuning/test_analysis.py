import unittest
import tempfile
from pathlib import Path
from unittest.mock import patch
import numpy as np
from analysis import rank,top_hits,cascade
import acquire


class SelectionTests(unittest.TestCase):
    def test_ties_use_evaluation_order(self):
        self.assertEqual(rank([.8,.8,.2],[4,2,1]).tolist(),[1,0,2])

    def test_pruned_active_cannot_return(self):
        # The active outside the first-stage set has the best adjusted score.
        hits,ceiling=cascade([0,1,1],[.9,.8,.1],[.1,.5,1.],2,2)
        self.assertEqual((hits,ceiling),(1,1))

    def test_full_rescoring_equals_direct_selection(self):
        y=[0,1,0,1];s1=[.9,.8,.4,.1];s2=[.2,.7,.5,.9]
        self.assertEqual(cascade(y,s1,s2,4,2)[0],top_hits(y,s2,2))

    def test_strictly_monotone_transform_preserves_selection(self):
        s=np.array([-.5,.5,2.,1.]);y=[1,0,1,0]
        self.assertEqual(top_hits(y,s,2),top_hits(y,np.exp(s),2))

    def test_invalid_budget(self):
        with self.assertRaises(ValueError):cascade([0,1],[.2,.3],[.2,.3],1,2)

    def test_recovery_is_not_monotone_in_rescoring_budget(self):
        # Expanding the candidate pool can introduce a high-scoring false positive.
        y=[1,0,0];s1=[.9,.8,.7];s2=[.8,.7,1.]
        self.assertEqual(cascade(y,s1,s2,2,1)[0],1)
        self.assertEqual(cascade(y,s1,s2,3,1)[0],0)

    def test_cached_input_tampering_is_rejected(self):
        with tempfile.TemporaryDirectory(dir=Path(__file__).resolve().parent) as tmp:
            root=Path(tmp);(root/'inputs').mkdir();(root/'inputs/x.csv').write_bytes(b'changed')
            with patch.object(acquire,'ROOT',root),patch.object(acquire,'EXPECTED',{'x.csv':'0'*64}):
                with self.assertRaisesRegex(ValueError,'checksum mismatch'):acquire.fetch('x.csv')

    def test_bad_score_is_rejected(self):
        with self.assertRaisesRegex(ValueError,'Nonfinite'):rank([.1,float('nan')])


if __name__=='__main__':unittest.main()
