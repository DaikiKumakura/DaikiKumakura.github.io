# Boltz-2 released-score reaggregation

This package independently aggregates public scores. It does not run Boltz-2,
fine-tune any model, generate new predictions, or perform laboratory experiments.

Tested with Python 3.12.4 and the versions in requirements.txt.

```bash
python -m pip install -r requirements.txt
python acquire.py
python analysis.py
python -m unittest test_analysis.py -q
```

Run from the extracted package directory. `acquire.py` retrieves about 98 MB of
compressed compound predictions plus supporting files from the fixed BoltzFT
commit a31c79a8420c1156a876f007dbdc52107cd0e957. It checks SHA-256 hashes against
input-provenance.json. Full compound predictions are not included in this ZIP.
The provided input-provenance.json is the expected manifest for this package.

`analysis.py` writes results/ and figures/. It verifies 96 AP/EF comparisons and
336 cascade hit/ceiling comparisons against archived author outputs. These are
consistency checks on released predictions, not independent validation of model
training or prospective efficacy. Eight small tests check selection behavior
and rejection of corrupted inputs/nonfinite scores. Analysis also checks input
hashes before calculating results.

AP uses scikit-learn average_precision_score. EF@1% follows the archived NumPy
1.26.4 argsort convention. Top-k selection explicitly uses eval_order to break
ties, including after first-stage pruning. All label budgets share the released
evaluation set excluding the initial top 300 candidates.

results/author-scaffold-summary.csv only aggregates author-supplied annotations;
scaffolds, Tanimoto similarities and the nearest-active baseline are not
independently recomputed. LightGBM and DrugCLIP are not re-trained here.

References:
- https://arxiv.org/abs/2609.24302v1
- https://github.com/ohuelab/BoltzFT/tree/a31c79a8420c1156a876f007dbdc52107cd0e957

Author-supplied reference tables in inputs/ are redistributed with their MIT
license at inputs/LICENSE. The authors' full repository and private editorial
records are excluded. Original code in this package is licensed under the
included LICENSE.
