"""Fetch pinned public prediction files; never runs model training."""
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
import hashlib
import json
import requests

ROOT = Path(__file__).resolve().parent
COMMIT = 'a31c79a8420c1156a876f007dbdc52107cd0e957'
BASE = f'https://raw.githubusercontent.com/ohuelab/BoltzFT/{COMMIT}/'
TARGETS = ['1053173-743445', '434954-2097', '463203-2650', '493248-485317',
           '504329', '540297-493091', '588689', '624273-588549']
EXPECTED = {}


def fetch(relative):
    dest = ROOT / 'inputs' / relative
    dest.parent.mkdir(parents=True, exist_ok=True)
    if not dest.exists():
        response = requests.get(BASE + relative, timeout=90)
        response.raise_for_status()
        dest.write_bytes(response.content)
    digest = hashlib.sha256(dest.read_bytes()).hexdigest()
    if relative in EXPECTED and digest != EXPECTED[relative]:
        raise ValueError(f'Input checksum mismatch: {relative}')
    return {'path': relative, 'bytes': dest.stat().st_size, 'sha256': digest}


def main():
    provenance = ROOT / 'input-provenance.json'
    if provenance.exists():
        pinned = json.loads(provenance.read_text(encoding='utf-8'))
        if pinned['commit'] != COMMIT:
            raise ValueError('Provenance commit mismatch')
        EXPECTED.update({r['path']:r['sha256'] for r in pinned['files']})
    files = [f'data/predictions/{t}.csv.gz' for t in TARGETS]
    files += ['data/predictions/README.md', 'data/predictions/manifest.json', 'LICENSE',
              'evaluation/recompute_predictions.py', 'evaluation/metrics.py',
              'figures/data/trainer_control.csv', 'figures/data/cascade.csv',
              'figures/data/si_analyses/hit_scaffold_recovery.csv']
    with ThreadPoolExecutor(max_workers=8) as pool:
        records = list(pool.map(fetch, files))
    if not provenance.exists():
        provenance.write_text(json.dumps(
            {'repository': 'https://github.com/ohuelab/BoltzFT', 'commit': COMMIT,
             'files': records}, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    print(f'Fetched {len(records)} files at {COMMIT}')


if __name__ == '__main__':
    main()
