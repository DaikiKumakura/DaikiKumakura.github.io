import numpy as np

import analysis as an


def test_responder_counts_match_printed_percentages():
    t = an.lung06_table().iloc[0]
    assert t.x_sac == 115 and t.x_chemo == 107
    assert abs(t.pct_sac - 50.2) < 0.05 and abs(t.pct_chemo - 47.3) < 0.1


def test_newcombe_contains_difference_and_orr_not_significant():
    t = an.lung06_table().iloc[0]
    assert t.ci_low_points < t.diff_points < t.ci_high_points
    assert t.ci_low_points < 0 < t.ci_high_points


def test_deep_response_difference_is_positive():
    t = an.lung06_table().iloc[1]
    assert t.ci_low_points > 0


def test_mirova_counts_and_denominator_sensitivity():
    m = an.mirova_table()
    assert abs(m.pct_mirv.iloc[0] - 66.2) < 0.1 and abs(m.pct_chemo.iloc[0] - 32.8) < 0.1
    assert m.pct_mirv.iloc[1] < m.pct_mirv.iloc[0] and m.pct_chemo.iloc[1] < m.pct_chemo.iloc[0]
    assert (m.ci_low_points > 0).all()


def test_pfs_hr_relations():
    p = an.lung06_pfs_table()
    assert abs(p["hr_exponential_from_medians"] - 0.38) < 1e-12
    assert 0.44 < p["hr_from_12m_pfs"] < 0.47
    assert abs(an.landmark_hr(0.5, 0.5) - 1) < 1e-12


def test_mirova_bound_is_still_positive():
    m = an.mirova_table()
    assert len(m) == 3 and abs(m.diff_points.iloc[2] - 21.2) < 1.0 and m.ci_low_points.iloc[2] > 0
