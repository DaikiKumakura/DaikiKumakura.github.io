"""Figures for the ORR-versus-PFS note (reads results/*.csv)."""
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parent
RES, FIG = ROOT / "results", ROOT / "figures"
FIG.mkdir(exist_ok=True)
BLUE, ORANGE = "#0072B2", "#D55E00"


def fig1():
    c = pd.read_csv(RES / "contrast.csv")
    x = np.arange(len(c))
    fig, ax = plt.subplots(figsize=(7.0, 4.2))
    ax.bar(x - 0.2, c.orr_exp, width=0.38, color=BLUE, label="Experimental arm")
    ax.bar(x + 0.2, c.orr_ctl, width=0.38, color=ORANGE, label="Control arm")
    for i, r in c.iterrows():
        ax.text(i - 0.2, r.orr_exp + 1.2, f"{r.orr_exp:.1f}", ha="center", fontsize=8)
        ax.text(i + 0.2, r.orr_ctl + 1.2, f"{r.orr_ctl:.1f}", ha="center", fontsize=8)
    ax.set_xticks(x)
    ax.set_xticklabels(c.trial)
    ax.set_ylim(0, 80)
    ax.set_ylabel("Objective response rate (%)")
    ax.set_title("Response rates: nearly equal in one trial, doubled in the other", fontsize=10)
    ax.legend(fontsize=8)
    ax.grid(axis="y", alpha=0.25)
    fig.tight_layout()
    fig.savefig(FIG / "01-response-rates.png", dpi=170)
    plt.close(fig)


def fig2():
    c = pd.read_csv(RES / "contrast.csv")
    lo = np.array([0.36, 0.68])
    hi = np.array([0.65, 1.46])
    fig, ax = plt.subplots(figsize=(8.0, 3.8))
    y = np.arange(len(c))
    ax.errorbar(c.pfs_hr, y, xerr=[c.pfs_hr - lo, hi - c.pfs_hr], fmt="o", color=BLUE, capsize=4)
    for i, r in c.iterrows():
        ax.text(hi[i] * 1.04, i, f"HR {r.pfs_hr:.2f} ({lo[i]:.2f} to {hi[i]:.2f})", va="center", fontsize=8)
    ax.axvline(1.0, color="#666666", ls="--")
    ax.set_xscale("log")
    ax.minorticks_off()
    ax.set_xlim(0.3, 3.2)
    ax.set_yticks(y)
    ax.set_yticklabels(c.trial)
    ax.invert_yaxis()
    ax.set_xticks([0.4, 0.5, 0.7, 1.0, 1.4, 2.0])
    ax.set_xticklabels(["0.4", "0.5", "0.7", "1.0", "1.4", "2.0"])
    ax.set_xlabel("PFS hazard ratio (95% CI, log scale); below 1 favours the experimental arm")
    ax.set_title("PFS hazard ratios of the same two trials", fontsize=10)
    ax.grid(axis="x", alpha=0.25)
    fig.tight_layout()
    fig.savefig(FIG / "02-pfs-hazard-ratios.png", dpi=170)
    plt.close(fig)


if __name__ == "__main__":
    fig1()
    fig2()
