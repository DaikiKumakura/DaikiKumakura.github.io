"""Read the response-rate and PFS numbers of two randomized trials together: OptiTROP-Lung06 (sacituzumab tirumotecan + pembrolizumab vs chemotherapy + pembrolizumab, PD-L1-negative nonsquamous NSCLC;
Zhou et al., N Engl J Med 2026, DOI 10.1056/NEJMoa2611280) and MIROVA / AGO-OVAR 2.34 (carboplatin + mirvetuximab soravtansine vs carboplatin + chemotherapy, FRalpha-high platinum-eligible recurrent ovarian cancer;
ESMO Gynaecological Cancers 2026, abstract 108O; JCO 2026;44(suppl 16):5506).

Inputs are numbers printed in the NEJM abstract (Europe PMC record), ESMO 2026 coverage (Targeted Oncology) and the OncLive report of the MIROVA presentation:
  OptiTROP-Lung06: 455 patients (229 vs 226); ORR 50.2% vs 47.3% (no CI in the sources read); deep response 28.8% vs 17.3% (definition not given in the coverage read); median DoR 13.6 vs 6.8 months (HR 0.47); median PFS 15.0 vs 5.7 months, HR 0.49
  (95% CI 0.36-0.65); 12-month PFS 51.1% vs 22.8%; OS HR 0.58 (95% CI 0.38-0.88) immature, median follow-up 9.7 months; grade >= 3 TEAE 47.6% vs 60.6%; dose reductions 4.8% vs 19.9%.
  MIROVA: PFS analysis 75 vs 70 patients; ORR (evaluable) 66.2% of 71 vs 32.8% of 61 (47 and 20 responders); median PFS 9.53 vs 9.79 months, HR 1.0 (95% CI 0.68-1.46); median follow-up 9.2 vs 8.9 months;
  TFST HR 0.64 (0.41-0.98); OS maturity 48.3%, 35.7% of the control arm crossed over; discontinuation for reasons other than progression 10.8% vs 30.2%.
Everything here is arithmetic on printed numbers (Newcombe intervals, landmark-implied hazard ratio, exponential-median hazard ratio); there are no random numbers. Full texts were not available.
"""
from pathlib import Path

import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parent
OUT = ROOT / "results"
OUT.mkdir(exist_ok=True)


def wilson(x: int, n: int, z: float = 1.96) -> tuple[float, float]:
    p = x / n
    d = 1 + z * z / n
    c = p + z * z / (2 * n)
    h = z * np.sqrt(p * (1 - p) / n + z * z / (4 * n * n))
    return (c - h) / d, (c + h) / d


def newcombe_diff(x1: int, n1: int, x0: int, n0: int, z: float = 1.96) -> tuple[float, float, float]:
    p1, p0 = x1 / n1, x0 / n0
    l1, u1 = wilson(x1, n1, z)
    l0, u0 = wilson(x0, n0, z)
    return p1 - p0, p1 - p0 - np.sqrt((p1 - l1) ** 2 + (u0 - p0) ** 2), p1 - p0 + np.sqrt((u1 - p1) ** 2 + (p0 - l0) ** 2)


def landmark_hr(s1: float, s0: float) -> float:
    return float(np.log(s1) / np.log(s0))


def lung06_table() -> pd.DataFrame:
    n1, n0 = 229, 226
    x1, x0 = round(0.502 * n1), round(0.473 * n0)           # 115 and 107 responders implied by the printed percentages
    d1, d0 = round(0.288 * n1), round(0.173 * n0)           # 66 and 39 deep responders
    rows = []
    for label, a, b in (("ORR", (x1, n1), (x0, n0)), ("Deep response (definition not stated)", (d1, n1), (d0, n0))):
        d, lo, hi = newcombe_diff(a[0], a[1], b[0], b[1])
        rows.append(dict(measure=label, x_sac=a[0], n_sac=a[1], x_chemo=b[0], n_chemo=b[1], pct_sac=100 * a[0] / a[1], pct_chemo=100 * b[0] / b[1],
                         diff_points=100 * d, ci_low_points=100 * lo, ci_high_points=100 * hi))
    return pd.DataFrame(rows)


def lung06_pfs_table() -> dict:
    return dict(median_ratio=15.0 / 5.7, hr_exponential_from_medians=5.7 / 15.0, reported_hr=0.49, hr_from_12m_pfs=landmark_hr(0.511, 0.228),
                dor_hr_exponential=6.8 / 13.6, dor_hr_reported=0.47)


def mirova_table() -> pd.DataFrame:
    rows = []
    for label, xb, nb, xa, na in (("ORR among evaluable patients", 47, 71, 20, 61), ("ORR with all PFS-analysis patients as denominator (non-evaluable = non-responders)", 47, 75, 20, 70)):
        d, lo, hi = newcombe_diff(xb, nb, xa, na)
        rows.append(dict(measure=label, x_mirv=xb, n_mirv=nb, x_chemo=xa, n_chemo=na, pct_mirv=100 * xb / nb, pct_chemo=100 * xa / na, ratio=(xb / nb) / (xa / na),
                         diff_points=100 * d, ci_low_points=100 * lo, ci_high_points=100 * hi))
    # bound: all 9 non-evaluable control patients counted as responders (most favourable to the control arm), experimental arm non-evaluable as non-responders
    d, lo, hi = newcombe_diff(47, 75, 20 + 9, 70)
    rows.append(dict(measure="Bound: control non-evaluable all counted as responders", x_mirv=47, n_mirv=75, x_chemo=29, n_chemo=70, pct_mirv=100 * 47 / 75, pct_chemo=100 * 29 / 70,
                     ratio=(47 / 75) / (29 / 70), diff_points=100 * d, ci_low_points=100 * lo, ci_high_points=100 * hi))
    return pd.DataFrame(rows)


def mirova_pfs() -> dict:
    lo, hi = 0.68, 1.46
    return dict(hr=1.0, ci_low=lo, ci_high=hi, excluded_benefit_below_hr=lo, median_diff_months=9.53 - 9.79, median_followup_mirv=9.2, median_followup_chemo=8.9,
                evaluable_missing_mirv=75 - 71, evaluable_missing_chemo=70 - 61)


def contrast_table() -> pd.DataFrame:
    return pd.DataFrame([
        dict(trial="OptiTROP-Lung06", orr_exp=50.2, orr_ctl=47.3, orr_ratio=50.2 / 47.3, pfs_hr=0.49, pfs_hr_ci="0.36-0.65", median_pfs_exp=15.0, median_pfs_ctl=5.7),
        dict(trial="MIROVA", orr_exp=66.2, orr_ctl=32.8, orr_ratio=66.2 / 32.8, pfs_hr=1.0, pfs_hr_ci="0.68-1.46", median_pfs_exp=9.53, median_pfs_ctl=9.79)])


def main() -> None:
    pd.set_option("display.width", 250, "display.max_columns", 30, "display.float_format", lambda v: f"{v:.4g}")
    for k, v in (("lung06_response", lung06_table()), ("mirova_response", mirova_table()), ("contrast", contrast_table())):
        v.to_csv(OUT / f"{k}.csv", index=False)
        print(k); print(v); print()
    for k, v in (("lung06_pfs", lung06_pfs_table()), ("mirova_pfs", mirova_pfs())):
        pd.Series(v).to_csv(OUT / f"{k}.csv", header=["value"])
        print(k, v)


if __name__ == "__main__":
    main()
