"""Recalculate reported-count intervals and an explicitly hypothetical selection example."""
import csv
import math
from pathlib import Path

HERE = Path(__file__).resolve().parent


def wilson(hits, total, z=1.959963984540054):
    if total <= 0 or hits < 0 or hits > total:
        raise ValueError('Require 0 <= hits <= total and total > 0')
    p = hits / total
    denominator = 1 + z * z / total
    center = (p + z * z / (2 * total)) / denominator
    half = z * math.sqrt(p * (1-p) / total + z*z / (4*total*total)) / denominator
    return center - half, center + half


def main():
    out = HERE / 'results'
    out.mkdir(exist_ok=True)
    with (HERE/'counts.csv').open(encoding='utf-8', newline='') as f:
        rows = list(csv.DictReader(f))
    for row in rows:
        hits, total = int(row['hits']), int(row['total'])
        low, high = wilson(hits, total)
        row.update(fraction=hits/total, wilson_low=low, wilson_high=high)
    with (out/'intervals.csv').open('w',encoding='utf-8',newline='') as f:
        writer=csv.DictWriter(f,fieldnames=list(rows[0]))
        writer.writeheader(); writer.writerows(rows)
    scenarios = [('moderate',20,8),('strict',4,3)]
    with (out/'hypothetical.csv').open('w',encoding='utf-8',newline='') as f:
        writer=csv.writer(f); writer.writerow(['scenario','pool','selected','hits','precision','unused_budget'])
        for name, selected, hits in scenarios:
            writer.writerow([name,100,selected,hits,hits/selected,20-selected])
    print((out/'intervals.csv').read_text(encoding='utf-8'))


if __name__ == '__main__':
    main()
