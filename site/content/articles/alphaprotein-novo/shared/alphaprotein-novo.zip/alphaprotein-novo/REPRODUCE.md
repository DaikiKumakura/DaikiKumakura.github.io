# Reported counts and a hypothetical selection example

Run `python analysis.py`. The standard library is sufficient. To recreate the figure, install matplotlib and run `python plot.py`.

`counts.csv` transcribes two separate aggregates from Wu et al., bioRxiv v1 (2026), DOI [10.64898/2026.10.01.756017](https://doi.org/10.64898/2026.10.01.756017). Neither row is an overall generator success rate. Reactions, thresholds and selection stages differ; do not compare them as performance estimates.

Wilson 95% intervals use z=1.959963984540054 and an independent homogeneous binomial model. They illustrate count uncertainty only, omit retrospective selection bias and dependence, and are not prospective prediction intervals.

The moderate/strict scenarios are invented, not experimental data. Their only purpose is to distinguish precision from the number of recovered hits and unused experimental capacity. No model weights, protein sequences or original figures are included. The AP Novo model was not run.
