"""Plot separate count summaries; these are not comparable performance estimates."""
import csv
from pathlib import Path
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

HERE=Path(__file__).resolve().parent
rows=list(csv.DictReader((HERE/'results/intervals.csv').open(encoding='utf-8')))
fig, axes=plt.subplots(1,2,figsize=(9,3.8),sharey=True)
labels=['Serine esterase\nRetrospective selection: 5 / 9', 'Kemp elimination\nFinal round, stricter activity: 5 / 90']
for ax,row,label in zip(axes,rows,labels):
    p,lo,hi=[float(row[x])*100 for x in ['fraction','wilson_low','wilson_high']]
    ax.errorbar([0],[p],yerr=[[p-lo],[hi-p]],fmt='o',capsize=7,color='#166277')
    ax.set_xlim(-.7,.7);ax.set_ylim(0,100);ax.set_xticks([]);ax.set_title(label,fontsize=11)
    ax.grid(axis='y',alpha=.2);ax.text(.1,p,f'{p:.1f}%',va='center')
axes[0].set_ylabel('Reported proportion (%)')
fig.text(.5,.035,'Different reactions and success criteria. Wilson intervals omit selection bias.',ha='center',fontsize=9)
fig.tight_layout(rect=(0,.08,1,1))
(HERE/'figures').mkdir(exist_ok=True)
fig.savefig(HERE/'figures/01-denominators.png',dpi=180)
